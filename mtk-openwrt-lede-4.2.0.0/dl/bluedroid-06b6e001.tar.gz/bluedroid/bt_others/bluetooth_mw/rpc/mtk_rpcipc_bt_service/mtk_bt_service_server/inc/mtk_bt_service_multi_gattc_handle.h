/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2016-2017. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */


#ifndef _MTK_BT_SERVICE_MULTI_GATTC_HANDLE_H_
#define _MTK_BT_SERVICE_MULTI_GATTC_HANDLE_H_

#include "u_rpcipc_types.h"
#include "mtk_bt_service_multi_gattc_wrapper.h"
#include "ri_common.h"

extern INT32 c_rpc_reg_mtk_bt_service_multi_gattc_op_hndlrs(VOID);

/******************************************************************************************************************/
/*    Gatt multi client register                              */
/*******************************************/
#define GattClientRegMax     16         //the max client register num
#define UuidLengthMax        37         //the max uuid len
#define ConnLinkMax          4          //the max value of the gattc support the connection with server

//gatt client conn infomation
typedef struct
{
    BOOL  in_use;
    INT32 conn_id;
    CHAR  btaddr[MAX_BDADDR_LEN];
}GATTCConnInfo;

//gatt client struct infomation
typedef struct
{
    CHAR bt_gattc_uuid[UuidLengthMax];
    RPC_ID_T t_id;
    INT32 client_if;
    GATTCConnInfo conn_info[ConnLinkMax];
    BOOL scan_flag;
    MTKRPCAPI_BT_APP_MULTI_GATTC_CB_FUNC_T app_func;
}GattClientInfo;

//gatt client register callback node
typedef struct GATT_CLIENT_REG_CB_NODE
{
    GattClientInfo gattc_info;
    struct GATT_CLIENT_REG_CB_NODE *next;
}GattcRegCbNode;

//gatt client register callback linklist
typedef struct
{
    GattcRegCbNode* pHead;
    INT32 i4_size;
}GattcRegCbLinkList;

#endif
