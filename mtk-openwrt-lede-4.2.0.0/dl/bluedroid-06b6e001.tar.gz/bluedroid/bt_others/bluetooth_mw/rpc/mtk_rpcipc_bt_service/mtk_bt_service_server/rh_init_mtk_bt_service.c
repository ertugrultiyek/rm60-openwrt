/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2016-2017. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */


#include "ri_common.h"
#include "rh_init_mtk_bt_service.h"
#include "mtk_bt_service_gattc_handle.h"
#include "mtk_bt_service_multi_gattc_handle.h"
#include "mtk_bt_service_gatt_handle.h"
#include "mtk_bt_service_gatts_handle.h"
#include "mtk_bt_service_multi_gatts_handle.h"
#include "mtk_bt_service_avrcp_handle.h"
#include "mtk_bt_service_a2dp_handle.h"
#include "mtk_bt_service_gap_handle.h"
#include "mtk_bt_service_hidh_handle.h"
#include "mtk_bt_service_hfclient_handle.h"
#include "mtk_bt_service_dbg_handle.h"
#include "mtk_bt_service_spp_handle.h"

//for ble setup
#if defined(MTK_LINUX_C4A_BLE_SETUP)
#include "Mtkc4a_bt_setup_server.h"
#include "IMtkC4a_bt_setup.h"
#endif

#include "mtk_bt_service_mesh_handle.h"

EXPORT_SYMBOL RPC_ID_T c_rpc_start_mtk_bt_service_server(VOID)
{
  return bt_rpc_open_server("mtk_bt_service");
}

EXPORT_SYMBOL INT32 c_rpc_init_mtk_bt_service_server(VOID)
{
    c_rpc_server_init();
    c_rpc_reg_mtk_bt_service_gatt_op_hndlrs();
    c_rpc_reg_mtk_bt_service_gattc_op_hndlrs();
    c_rpc_reg_mtk_bt_service_gatts_op_hndlrs();
    c_rpc_reg_mtk_bt_service_multi_gattc_op_hndlrs();
    c_rpc_reg_mtk_bt_service_multi_gatts_op_hndlrs();
#if defined(MTK_LINUX_C4A_BLE_SETUP)
    c_rpc_reg_mtkc4a_bt_setup_op_hndlrs();
#endif
    c_rpc_reg_mtk_bt_service_avrcp_op_hndlrs();
    c_rpc_reg_mtk_bt_service_a2dp_op_hndlrs();
    c_rpc_reg_mtk_bt_service_gap_op_hndlrs();
    c_rpc_reg_mtk_bt_service_hidh_op_hndlrs();
    c_rpc_reg_mtk_bt_service_hfclient_op_hndlrs();
    c_rpc_reg_mtk_bt_service_spp_op_hndlrs();
#if defined(BT_RPC_DBG_SERVER)
    c_rpc_reg_mtk_bt_service_dbg_op_hndlrs();
#endif
    c_rpc_reg_mtk_bt_service_mesh_op_hndlrs();

    return 0;
}

