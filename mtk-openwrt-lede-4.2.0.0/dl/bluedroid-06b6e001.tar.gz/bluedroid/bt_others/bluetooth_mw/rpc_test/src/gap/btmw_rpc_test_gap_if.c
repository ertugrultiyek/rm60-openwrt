/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2016-2017. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <string.h>
#include <unistd.h>

#include "btmw_rpc_test_cli.h"
#include "btmw_rpc_test_debug.h"
#include "btmw_rpc_test_gap_if.h"
#include "mtk_bt_service_gap_wrapper.h"
#include "mtk_bt_service_a2dp_wrapper.h"

#define BLUETOOTH_RPC_TEST_NAME             "audio_bt"
#define BT_NAME_SUF_RPC_TEST_LEN              5

typedef struct
{
    UINT8 address[6];
} __attribute__((packed))BT_ADDR_T;

void btmw_rpc_btaddr_stoh(char *btaddr_s, BT_ADDR_T *bdaddr_h)
{
    int i;
    for (i = 0; i < 6; i++)
    {
        bdaddr_h->address[i] = strtoul(btaddr_s, &btaddr_s, 16);
        btaddr_s++;
    }
}

int btmw_rpc_btaddr_htos(BT_ADDR_T *bdaddr_h, char *btaddr_s)
{
    if (NULL == btaddr_s || NULL == bdaddr_h)
    {
        return -1;
    }
    snprintf(btaddr_s, 18, "%02X:%02X:%02X:%02X:%02X:%02X",
             bdaddr_h->address[0],
             bdaddr_h->address[1],
             bdaddr_h->address[2],
             bdaddr_h->address[3],
             bdaddr_h->address[4],
             bdaddr_h->address[5]);
    btaddr_s[17] = '\0';
    return 0;
}

static void btmw_rpc_test_gap_event_callback(tBTMW_GAP_STATE *bt_event, void* pv_tag)
{
    BTMW_RPC_TEST_Logi("[GAP] %s(), bt_gap_event =%d\n",  __func__, bt_event->state);
    switch (bt_event->state)
     {
     case GAP_STATE_ON:
        BTMW_RPC_TEST_Logi("[GAP] %s(), bt_gap_event = state on\n",  __func__);
        break;
     case GAP_STATE_OFF:
        BTMW_RPC_TEST_Logi("[GAP] %s(), bt_gap_event = state off\n",  __func__);
        break;

     case GAP_STATE_ACL_CONNECTED:
        BTMW_RPC_TEST_Logi("[GAP] %s(), bt_gap_event = acl connected:%s link_type:%d\n",
                            __func__, bt_event->bd_addr, bt_event->link_type);
        break;

     case GAP_STATE_ACL_DISCONNECTED:
        if(bt_event->reason)
        {
             if (0x08 == bt_event->reason)
             {
                 BTMW_RPC_TEST_Logi("[GAP] %s(), bt_gap_event = connect lost:%s link_type:%d\n",
                                    __func__, bt_event->bd_addr, bt_event->link_type);
             }
        }
        else
        {
            BTMW_RPC_TEST_Logi("[GAP] %s(), bt_gap_event = acl is disconnected:%s link_type:%d\n",
                                __func__, bt_event->bd_addr, bt_event->link_type);
        }
        break;

     case GAP_STATE_BONDED:
        break;
     case GAP_STATE_BONDING:
        break;
     case GAP_STATE_NO_BOND:
        break;
     case GAP_STATE_DISCOVERY_STARTED:
         BTMW_RPC_TEST_Logi("[GAP] %s(), GAP_STATE_DISCOVERY_STARTED\n",  __func__);
        break;
     case GAP_STATE_DISCOVERY_STOPED:
         BTMW_RPC_TEST_Logi("[GAP] %s(), GAP_STATE_DISCOVERY_STOPED\n",  __func__);
        break;
     default:
        BTMW_RPC_TEST_Logi("[GAP] %s(), undefined bt_gap_event \n",  __func__);
        break;
     }

    return;
}

static void btmw_rpc_test_gap_get_pairing_key_callback(pairing_key_value_t *bt_pairing_key, UINT8 *fg_accept, void* pv_tag)
{
    BTMW_RPC_TEST_Logi("[GAP] %s(), bt_pairing_key->pin_code =%s,  key_value = %lu, fg_accept = %u\n",  __func__, bt_pairing_key->pin_code, bt_pairing_key->key_value, *fg_accept);
    return;
}

static void btmw_rpc_test_gap_app_inquiry_callback(tBTMW_GAP_DEVICE_INFO *pt_result, void* pv_tag)
{
    if (NULL == pt_result)
    {
        return;
    }

    BTMW_RPC_TEST_Logi("[GAP] %s() \n", __func__);
    BTMW_RPC_TEST_Logi("device_kind:     %d\n", pt_result->device_kind);
    BTMW_RPC_TEST_Logi("name:     %s\n", pt_result->device.name);
    BTMW_RPC_TEST_Logi("cod:      0x%2lx\n", pt_result->device.cod);
    BTMW_RPC_TEST_Logi("bdAddr:   %s\n", pt_result->device.bdAddr);
    BTMW_RPC_TEST_Logi("rssi:   %d\n", pt_result->device.rssi);
    BTMW_RPC_TEST_Logi("service:   0x%x\n", pt_result->device.service);
}


int btmw_rpc_test_gap_bt_base_init(MTKRPCAPI_BT_APP_CB_FUNC *func, void *pv_tag)
{
    BTMW_RPC_TEST_Logi("[GAP] btmw_rpc_test_gap_bt_base_init\n");
    return a_mtkapi_gap_bt_base_init(func, pv_tag);
}

int btmw_rpc_test_gap_set_local_name(VOID)
{
    //INT32 i4_ret;
    //CHAR ac_bdAddr[MAX_BDADDR_LEN]={0};
    //CHAR ac_name[MAX_NAME_LEN] = {0};
    //CHAR bt_mac_suf[MAX_BDADDR_LEN] = {0};
    //BT_GAP_LOCAL_PROPERTIES_RESULT t_local_info;
    //memset(&t_local_info, 0, sizeof(BT_GAP_LOCAL_PROPERTIES_RESULT));

    //get local mac address
    //i4_ret = a_mtkapi_bt_gap_get_local_dev_info(&t_local_info);
   // strncpy(ac_bdAddr, t_local_info.bdAddr, MAX_BDADDR_LEN);

     //only use the last 5 characters of the bluetooth device mac address
    //strncpy(bt_mac_suf, ac_bdAddr + (strlen(ac_bdAddr)-BT_NAME_SUF_RPC_TEST_LEN), BT_NAME_SUF_RPC_TEST_LEN);

    //strncpy(ac_name, BLUETOOTH_RPC_TEST_NAME, strlen(BLUETOOTH_RPC_TEST_NAME));

    //the bluetooth name: ac_name = BLUETOOTH_RPC_TEST_NAME + (bt_mac_suf)
    //strcat(ac_name,"(");
    //strcat(ac_name,bt_mac_suf);
    //strcat(ac_name,")");
    //a_mtkapi_bt_gap_set_name(ac_name);
    //return i4_ret;
    return 0;
}

int btmw_rpc_test_gap_set_dbg_level_cli(int argc, char **argv)
{
    if (argc != 2)
    {
        BTMW_RPC_TEST_Loge("Usage :\n");
        BTMW_RPC_TEST_Loge("layer <0~8> means set target layer to level\n");
        BTMW_RPC_TEST_Loge("if layer is 9 means set all layer to level\n");
        BTMW_RPC_TEST_Loge("level <0~5>\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    a_mtkapi_bt_gap_set_dbg_level(atoi(argv[0]), atoi(argv[1]));
    return BT_SUCCESS;
}

int btmw_rpc_test_gap_set_power_cli(int argc, char **argv)
{
    if (argc != 1)
    {
        BTMW_RPC_TEST_Loge("0 means off, 1 means on\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    if (0 == strcmp("0" , argv[0]))
    {
        return a_mtkapi_bt_gap_on_off(FALSE);
    }
    else if (0 == strcmp("1" , argv[0]))
    {
        return a_mtkapi_bt_gap_on_off(TRUE);
    }
    else
    {
        return BT_ERR_STATUS_PARM_INVALID;
    }

    return BT_SUCCESS;
}

int btmw_rpc_test_gap_set_name_cli(int argc, char **argv)
{
    INT32 i4_ret = BT_SUCCESS, i = 0;
    CHAR name[64];

    if (argc < 1)
    {
        BTMW_RPC_TEST_Logd("please attach name after commond just append one string\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    memset(name, 0, sizeof(name));
    for (i = 0; i < argc; i++)
    {
        snprintf(name+strlen(name), sizeof(name) - strlen(name), "%s", argv[i]);
        if (i < (argc - 1))
            snprintf(name+strlen(name), sizeof(name) - strlen(name), "%s", " ");
    }

    BTMW_RPC_TEST_Logd("name is: %s\n", name);
    i4_ret = a_mtkapi_bt_gap_set_name(name);
    if (BT_SUCCESS == i4_ret)
    {
        BTMW_RPC_TEST_Logd("set name ok!\n");
    }

    return BT_SUCCESS;
}

int btmw_rpc_test_gap_set_conn_disc_cli(int argc, char **argv)
{
    if (2 == argc)
    {
        if (0 == strcmp("1" , argv[0]))
        {
            if (0 == strcmp("1" , argv[1]))
            {
                return a_mtkapi_bt_gap_set_connectable_and_discoverable(TRUE, TRUE);
            }
            else if (0 == strcmp("0" , argv[1]))
            {
                return a_mtkapi_bt_gap_set_connectable_and_discoverable(TRUE, FALSE);
            }
            else
            {
                BTMW_RPC_TEST_Loge("input error, 0 means off, 1 means on\n");
                return BT_ERR_STATUS_PARM_INVALID;
            }
        }
        else if (0 == strcmp("0" , argv[0]))
        {
            if (0 == strcmp("1" , argv[1]))
            {
                return a_mtkapi_bt_gap_set_connectable_and_discoverable(FALSE, TRUE);
            }
            else if (0 == strcmp("0" , argv[1]))
            {
                return a_mtkapi_bt_gap_set_connectable_and_discoverable(FALSE, FALSE);
            }
            else
            {
                BTMW_RPC_TEST_Loge("input error, 0 means off, 1 means on\n");
                return BT_ERR_STATUS_PARM_INVALID;
            }
        }
    }
    else
    {
        BTMW_RPC_TEST_Loge("0 means off, other integer:on");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }
    return BT_SUCCESS;
}

int btmw_rpc_test_gap_get_dev_info_cli(int argc, char **argv)
{
    BLUETOOTH_DEVICE dev_info;
    INT32 i4_ret = BT_SUCCESS;

    if (argc != 1)
    {
        BTMW_RPC_TEST_Loge("no parameter in this command\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    if (NULL == argv[0])
    {
        BTMW_RPC_TEST_Logd("addr is null \n");
        return BT_ERR_STATUS_NULL_POINTER;
    }
    if (17 != strlen(argv[0]))
    {
        BTMW_RPC_TEST_Logd("mac length should be 17\n");
        return BT_ERR_STATUS_PARM_INVALID;
    }

    i4_ret = a_mtkapi_bt_gap_get_dev_info(&dev_info, argv[0]);

    if(i4_ret == BT_SUCCESS)
    {
        BTMW_RPC_TEST_Logd("get device info ok!\n");
        BTMW_RPC_TEST_Logd("bdAddr:      %s\n", dev_info.bdAddr);
        BTMW_RPC_TEST_Logd("name:        %s\n", dev_info.name);
        i4_ret = a_mtkapi_bt_gap_get_bond_state(argv[0]);
        BTMW_RPC_TEST_Logd("bonded:      %s\n", i4_ret == BT_SUCCESS?"yes":"no");
    }

    return BT_SUCCESS;
}

int btmw_rpc_test_gap_get_local_dev_info_cli(int argc, char **argv)
{
    BT_LOCAL_DEV ps_dev_info;
    INT32 i4_ret = BT_SUCCESS;
    CHAR gatt_client_bdAddr[MAX_BDADDR_LEN];
    CHAR gatt_server_bdAddr[MAX_BDADDR_LEN];
    BT_ADDR_T temp_bdaddr;

    if (argc != 0)
    {
        BTMW_RPC_TEST_Loge("no parameter in this command\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    a_mtkapi_bt_gap_get_local_dev_info(&ps_dev_info);

    if (BT_SUCCESS == i4_ret)
    {
        btmw_rpc_btaddr_stoh(ps_dev_info.bdAddr, &temp_bdaddr);
        /* mask off the 2 MSB */
        temp_bdaddr.address[0] |= 0xc0;
        //temp_bdaddr.address[4] -= 1;
        btmw_rpc_btaddr_htos(&temp_bdaddr, gatt_server_bdAddr);
        temp_bdaddr.address[4] += 0xff;
        btmw_rpc_btaddr_htos(&temp_bdaddr, gatt_client_bdAddr);
        BTMW_RPC_TEST_Logd("get local device info ok!\n");
        BTMW_RPC_TEST_Logd("ps_dev_info.bdAddr:      %s\n", ps_dev_info.bdAddr);
        BTMW_RPC_TEST_Logd("gatt client address:      %s\n", gatt_client_bdAddr);
        BTMW_RPC_TEST_Logd("gatt server address:      %s\n", gatt_server_bdAddr);
        BTMW_RPC_TEST_Logd("ps_dev_info.name:        %s\n", ps_dev_info.name);
        BTMW_RPC_TEST_Logd("ps_dev_info.powered:     %s\n", (ps_dev_info.state == GAP_STATE_ON) ? "on" : (ps_dev_info.state == GAP_STATE_OFF) ? "off" : "unknown");
        BTMW_RPC_TEST_Logd("ps_dev_info.scan_mode:   %ld\n", (unsigned long)ps_dev_info.scan_mode);
    }
    else
    {
        BTMW_RPC_TEST_Logd("get local device info failed!\n");
    }

    return BT_SUCCESS;
}

int btmw_rpc_test_gap_inquiry_cli(int argc, char **argv)
{
    UINT32 ui4_filter_type = BT_INQUIRY_FILTER_TYPE_ALL;
    if (argc != 1)
    {
        BTMW_RPC_TEST_Loge("no parameter in this command\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    /* <all|src|sink|hfp|hid> */
    if (0 == strcmp(argv[0], "all"))
    {
        ui4_filter_type = BT_INQUIRY_FILTER_TYPE_ALL;
    }
    else if (0 == strcmp(argv[0], "src"))
    {
        ui4_filter_type = BT_INQUIRY_FILTER_TYPE_A2DP_SRC;
    }
    else if (0 == strcmp(argv[0], "sink"))
    {
        ui4_filter_type = BT_INQUIRY_FILTER_TYPE_A2DP_SNK;
    }
    else if (0 == strcmp(argv[0], "hfp"))
    {
        ui4_filter_type = BT_INQUIRY_FILTER_TYPE_HFP;
    }
    else if (0 == strcmp(argv[0], "hid"))
    {
        ui4_filter_type = BT_INQUIRY_FILTER_TYPE_HID;
    }

    a_mtkapi_bt_gap_start_inquiry_scan(ui4_filter_type);
    return 0;
}

int btmw_rpc_test_gap_stop_inquiry_cli(int argc, char **argv)
{
    if (argc != 0)
    {
        BTMW_RPC_TEST_Loge("no parameter in this command\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    return a_mtkapi_bt_gap_stop_inquiry_scan();
}

int btmw_rpc_test_gap_pair_cli (int argc, char **argv)
{
    UINT32 transport;

    if (argc != 2)
    {
        BTMW_RPC_TEST_Logd("parameter num error,please enter two parameter: addr and transport \n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }
    if (NULL == argv[0])
    {
        BTMW_RPC_TEST_Logd("addr is null \n");
        return BT_ERR_STATUS_NULL_POINTER;
    }

    if (17 != strlen(argv[0]))
    {
        BTMW_RPC_TEST_Logd("mac length should be 17\n");
        return BT_ERR_STATUS_PARM_INVALID;
    }
    transport = atol(argv[1]);
    return a_mtkapi_bt_gap_pair(argv[0], transport);

}

int btmw_rpc_test_gap_remove_paired_dev_cli(int argc, char **argv)
{
    if (argc != 1)
    {
        BTMW_RPC_TEST_Logd("please attach MAC after commond just append one string\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }
    if (NULL == argv[0])
    {
        BTMW_RPC_TEST_Logd("please attach MAC after commond just append one string\n");
        return BT_ERR_STATUS_NULL_POINTER;
    }
    if (17 != strlen(argv[0]))
    {
        BTMW_RPC_TEST_Logd("mac length should be 17\n");
        return BT_ERR_STATUS_PARM_INVALID;
    }

    return a_mtkapi_bt_gap_unpair(argv[0]);
}

int btmw_rpc_test_gap_get_rssi_cli (int argc, char **argv)
{
    CHAR ps_target_mac[18];
    INT16 rssi_value;

    if (1 == argc)
    {
        memset(ps_target_mac, 0, sizeof(ps_target_mac));
        if (17 != strlen(argv[0]))
        {
            BTMW_RPC_TEST_Logd("mac length should be 17\n");
            return BT_ERR_STATUS_PARM_INVALID;
        }
        strncpy(ps_target_mac,argv[0],sizeof(ps_target_mac)-1);
    }
    else
    {
        BTMW_RPC_TEST_Logd("please input get_rssi [MAC address]\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    a_mtkapi_bt_gap_get_rssi(ps_target_mac, &rssi_value);
    //you can use the rssi_value  callback here
    BTMW_RPC_TEST_Logd("rpc test app get_rssi=%d\n", rssi_value);
    return BT_SUCCESS;
}

int btmw_rpc_test_gap_set_virtual_sniffer_cli(int argc, char **argv)
{

    INT32 flag;

    if (argc != 1)
    {
        BTMW_RPC_TEST_Logd("A parameter is required!\n");
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    flag = atoi(argv[0]);
    a_mtkapi_bt_gap_set_virtual_sniffer(flag);

    return BT_SUCCESS;
}

int btmw_rpc_test_gap_send_hci(int argc, char **argv)
{
    CHAR *hci_cmd;

    if (argc != 1)
        return BT_ERR_STATUS_INVALID_PARM_NUMS;

    hci_cmd = (CHAR *)argv[0];
    a_mtkapi_bt_gap_send_hci(hci_cmd);
    return BT_SUCCESS;
}

int btmw_rpc_test_gap_set_lhdc_license_key(int argc, char **argv)
{
    CHAR *name;
    UINT8 key[128] = {0};
    int i=0;

    if (argc != 2)
        return BT_ERR_STATUS_INVALID_PARM_NUMS;

    name = (CHAR *)argv[0];

    for(i=0;i<strlen(argv[1])/2;i++)
    {
        int value = 0;
        sscanf(argv[1]+i*2, "%02x", &value);
        key[i] = value;
        if (i >= 128)break;
    }

    BTMW_RPC_TEST_Logd("[LHDC] license name=%s", name);
    BTMW_RPC_TEST_Logd("[LHDC] key=%s(key[0]=0x%02x), i=%d", argv[1], key[0], i);

    a_mtkapi_bt_gap_set_lhdc_key_data(name, key, i);

    return BT_SUCCESS;
}

int btmw_rpc_test_gap_factory_reset(int argc, char **argv)
{
    if (argc != 0)
        return BT_ERR_STATUS_INVALID_PARM_NUMS;

    a_mtkapi_bt_bluetooth_factory_reset();
    return BT_SUCCESS;
}

INT32 btmw_rpc_test_gap_enable_stack_log(int argc, char *argv[])
{
    CHAR *section_name;
    UINT8 trace_level = 0;

    if (argc != 2)
    {
        return BT_ERR_STATUS_INVALID_PARM_NUMS;
    }

    section_name = (CHAR *)argv[0];
    trace_level = atoi(argv[1]);
    a_mtkapi_bt_mw_log_setStackLevel((const char*)section_name, trace_level);
    return BT_SUCCESS;
}

INT32 btmw_rpc_test_gap_test_mode(int argc, char *argv[])
{
    UINT32 test_cnt = 0;
    UINT32 interval_ms = 0;
    test_cnt = atoi(argv[1]);
    interval_ms = atoi(argv[2]);
    BTMW_RPC_TEST_Logd("test_cnt=%d, interval_ms=%d\n", test_cnt, interval_ms);

    if (0 == strcmp(argv[0], "power"))
    {
        while(test_cnt)
        {
            BTMW_RPC_TEST_Logd("start test_cnt=%d, on_off=%d\n", test_cnt, test_cnt&1);
            a_mtkapi_bt_gap_on_off(test_cnt&1);
            BTMW_RPC_TEST_Logd("end test_cnt=%d, on_off=%d\n", test_cnt, test_cnt&1);

            /* if it's power on */
            if (test_cnt&1)
            {
                if (argc > 3)
                {
                    if (0 == strcmp(argv[3], "a2dp_conn"))
                    {
                        BTMW_RPC_TEST_Logd("a2dp conn %s\n", argv[4]);
                        a_mtkapi_a2dp_connect(argv[4], BT_A2DP_ROLE_SINK);
                    }
                }
                a_mtkapi_a2dp_sink_start_player();
            }
            BTMW_RPC_TEST_Logd("start sleep interval_ms=%d\n", interval_ms);
            usleep(interval_ms*1000);
            BTMW_RPC_TEST_Logd("end sleep interval_ms=%d\n", interval_ms);
            test_cnt--;
        }
    }

    return BT_SUCCESS;
}



static BTMW_RPC_TEST_CLI btmw_rpc_test_gap_cli_commands[] = {
    { (const char *)"dbg_level",            btmw_rpc_test_gap_set_dbg_level_cli,          (const char *)" = dbg_level <0~9> <0~5>"},
    { (const char *)"power",                btmw_rpc_test_gap_set_power_cli,              (const char *)" = power_on local device, 0:off, 1:on"},
    { (const char *)"name",                 btmw_rpc_test_gap_set_name_cli,               (const char *)" = bt set local dev name, name <xxx>"},
    { (const char *)"set_conn_disc",        btmw_rpc_test_gap_set_conn_disc_cli,          (const char *)" = set device connectable and discoverable, set_conn_disc <1|0> <1|0>, 1:enable, 0: unable"},
    { (const char *)"get_dev_info",         btmw_rpc_test_gap_get_dev_info_cli,           (const char *)" = get device info "},
    { (const char *)"info",                 btmw_rpc_test_gap_get_local_dev_info_cli,     (const char *)" = info <local|update>"},
    { (const char *)"inquiry",              btmw_rpc_test_gap_inquiry_cli,                (const char *)" = start device discovery <all|src|sink|hfp|hid>"},
    { (const char *)"stop_inquiry",         btmw_rpc_test_gap_stop_inquiry_cli,           (const char *)" = stop device discovery"},
    { (const char *)"pair",                 btmw_rpc_test_gap_pair_cli,                   (const char *)" = pair a remote device <addr> <transport> 0:unknown,1:BR/EDR,2:BLE"},
    { (const char *)"unpair",               btmw_rpc_test_gap_remove_paired_dev_cli,      (const char *)" = remove paired device <addr>"},
    { (const char *)"get_rssi",             btmw_rpc_test_gap_get_rssi_cli,               (const char *)" = get_rssi <addr>"},
    { (const char *)"enable_hci_log",       btmw_rpc_test_gap_set_virtual_sniffer_cli,    (const char *)" = enable_hci_log <1|0>. save bluetooth hci snoop log to btsnoop_hci.log"},
    { (const char *)"send_hci",             btmw_rpc_test_gap_send_hci,                   (const char *)" = send_hci <buffer>"},
    { (const char *)"set_lhdc_key",         btmw_rpc_test_gap_set_lhdc_license_key,       (const char *)" = set_lhdc_key <name> <key_hex>"},
    { (const char *)"factory_reset",        btmw_rpc_test_gap_factory_reset,              (const char *)" = delete bluetooth files for factory reset"},
    { (const char *)"enable_stack_log",     btmw_rpc_test_gap_enable_stack_log,           (const char *)" = enable_stack_log <trace_name> <level:0~6>"},
    { (const char *)"test",                 btmw_rpc_test_gap_test_mode,                  (const char *)" = test { power <N> } <interval:ms> [a2dp_conn <addr>]"},

    { NULL, NULL, NULL }
};

int btmw_rpc_test_gap_cmd_handler(int argc, char **argv)
{
    BTMW_RPC_TEST_CLI *cmd, *match = NULL;
    int ret = 0;
    int count;

    count = 0;
    cmd = btmw_rpc_test_gap_cli_commands;

    BTMW_RPC_TEST_Logi("[GAP] argc: %d, argv[0]: %s\n", argc, argv[0]);

    while (cmd->cmd)
    {
        if (!strcmp(cmd->cmd, argv[0]))
        {
            match = cmd;
            count = 1;
            break;
        }
        cmd++;
    }

    if (count == 0)
    {
        btmw_rpc_test_print_cmd_help(BTMW_RPC_TEST_CMD_KEY_GAP, btmw_rpc_test_gap_cli_commands);
        ret = -1;
    }
    else
    {
        match->handler(argc - 1, &argv[1]);
    }

    return ret;
}

int btmw_rpc_test_gap_init()
{
    int ret = 0;
    BTMW_RPC_TEST_MOD btmw_rpc_test_gap_mod = {0};

    btmw_rpc_test_gap_mod.mod_id = BTMW_RPC_TEST_MOD_GAP;
    strncpy(btmw_rpc_test_gap_mod.cmd_key, BTMW_RPC_TEST_CMD_KEY_GAP, sizeof(btmw_rpc_test_gap_mod.cmd_key));
    btmw_rpc_test_gap_mod.cmd_handler = btmw_rpc_test_gap_cmd_handler;
    btmw_rpc_test_gap_mod.cmd_tbl = btmw_rpc_test_gap_cli_commands;

    ret = btmw_rpc_test_register_mod(&btmw_rpc_test_gap_mod);
    BTMW_RPC_TEST_Logi("[GAP] btmw_rpc_test_register_mod() returns: %d\n", ret);

    if (!g_cli_pts_mode)
    {
        MTKRPCAPI_BT_APP_CB_FUNC func;
        char pv_tag[2] = {0};
        memset(&func, 0, sizeof(MTKRPCAPI_BT_APP_CB_FUNC));
        func.bt_event_cb = btmw_rpc_test_gap_event_callback;
        func.bt_get_pairing_key_cb = btmw_rpc_test_gap_get_pairing_key_callback;
        func.bt_dev_info_cb = btmw_rpc_test_gap_app_inquiry_callback;
        btmw_rpc_test_gap_bt_base_init(&func, (void *)pv_tag);
        a_mtkapi_bt_gap_on_off(TRUE);
        a_mtkapi_bt_gap_set_name("MTK_BLE");
        a_mtkapi_bt_gap_set_connectable_and_discoverable(FALSE, FALSE);
    }
    return 0;
}

