/***************************************************************************
 * MediaTek Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 1997-2012, MediaTek, Inc.
 *
 * All rights reserved. MediaTek source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek Technology, Inc. is obtained.
 ***************************************************************************

*/

#include "rt_config.h"
#include "mcu/mt_cmd.h"

#ifdef FQ_SCH_SUPPORT
INT fq_reset_list_entry(RTMP_ADAPTER *pAd, UCHAR qidx, UCHAR wcid);
static INT fq_add_list(RTMP_ADAPTER *pAd, UCHAR qidx, STA_TR_ENTRY *tr_entry);
static INT fq_clean_list(RTMP_ADAPTER *pAd, UCHAR qidx);
static INT fq_schedule_tx_que(RTMP_ADAPTER *pAd);
static INT fq_bss_clean_queue(struct _RTMP_ADAPTER *ad, struct wifi_dev *wdev);
static INT fq_sta_clean_queue(RTMP_ADAPTER *pAd, UCHAR wcid);
static INT32 fq_deq_data_pkt(RTMP_ADAPTER *pAd, TX_BLK *tx_blk, INT32 max_cnt, struct dequeue_info *info);
static INT fq_enq_dataq_pkt(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, PNDIS_PACKET pkt, UCHAR q_idx);

INT fq_enq_req(RTMP_ADAPTER *pAd, NDIS_PACKET *pkt, UCHAR qidx,
		STA_TR_ENTRY *tr_entry, QUEUE_HEADER *pPktQueue);

extern INT32 fp_fair_enq_dataq_pkt(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, PNDIS_PACKET pkt, UCHAR q_idx);
extern INT32 fp_enq_dataq_pkt(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, PNDIS_PACKET pkt, UCHAR q_idx);
extern struct qm_ops ge_qm_ops;
extern struct qm_ops fp_qm_ops;
extern struct qm_ops fp_fair_qm_ops;
struct qm_ops ge_fair_qm_ops;

INT fq_init(RTMP_ADAPTER *pAd)
{
	INT i, j;
	STA_TR_ENTRY *tr_entry;
	struct fq_stainfo_type *pfq_sta = NULL;
	UCHAR fq_en = 0, factor = 0;
	ULONG IrqFlags = 0;
	RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct qm_ops **qm_ops = &pAd->qm_ops;

#ifdef FQ_SCH_DBG_SUPPORT
	for (i = 0; i < WMM_NUM_OF_AC; i++) {
		pAd->fq_ctrl.prev_wcid[i] = -1;
		pAd->fq_ctrl.prev_kick_cnt[i] = 0;
	}
	pAd->fq_ctrl.prev_qidx = -1;
#endif

	if ((pAd->fq_ctrl.enable & FQ_EN) == 0)
		return 0;

	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
		("Fair Queueing Scheduler Initializatio...\n"));
	fq_en = pAd->fq_ctrl.enable;
	factor = pAd->fq_ctrl.factor;
	os_zero_mem(&pAd->fq_ctrl, sizeof(struct fq_ctrl_type));
	pAd->fq_ctrl.enable = fq_en;
	pAd->fq_ctrl.factor = factor;


	for (i = 0; i < WMM_NUM_OF_AC; i++) {
		RTMP_IRQ_LOCK(&pAd->tx_swq_lock[i], IrqFlags);
		InitializeQueueHeader(&pAd->fq_ctrl.fq[i]);
		for (j = 0; j < (MAX_LEN_OF_MAC_TABLE/(sizeof(UINT32)*8)); j++) {
			pAd->fq_ctrl.list_map[i][j] = 0;
			pAd->fq_ctrl.no_packet_chk_map[i][j] = 0;
		}
		RTMP_IRQ_UNLOCK(&pAd->tx_swq_lock[i], IrqFlags);
	}
	for (j = 0; j < MAX_LEN_OF_MAC_TABLE ; j++) {
		tr_entry = &pAd->MacTab.tr_entry[j];
		pfq_sta = &tr_entry->fq_sta_rec;
		for (i = 0; i < WMM_NUM_OF_AC; i++) {
			os_zero_mem(pfq_sta, sizeof(struct fq_stainfo_type));
			NdisAllocateSpinLock(pAd, &pfq_sta->lock[i]);
		}
		fq_reset_list_entry(pAd, WMM_NUM_OF_AC, j);
	}

	for (i = 0; i < WMM_NUM_OF_AC; i++) {
		RTMP_IRQ_LOCK(&pAd->tx_swq_lock[i], IrqFlags);
		for (j = 0; j < MAX_LEN_OF_MAC_TABLE ; j++) {
			tr_entry = &pAd->MacTab.tr_entry[j];
			if (tr_entry) {
				RTMP_SPIN_LOCK(&tr_entry->txq_lock[i]);
				if (tr_entry->tx_queue[i].Number > 0)
					fq_add_list(pAd, i, tr_entry);
				RTMP_SPIN_UNLOCK(&tr_entry->txq_lock[i]);
			}
		}
		RTMP_IRQ_UNLOCK(&pAd->tx_swq_lock[i], IrqFlags);
	}

	if (cap->qm == FAST_PATH_FAIR_QM) {
		(*qm_ops)->enq_dataq_pkt = fp_fair_enq_dataq_pkt;
		(*qm_ops)->schedule_tx_que = fq_schedule_tx_que;
		(*qm_ops)->sta_clean_queue = fq_sta_clean_queue;
		(*qm_ops)->bss_clean_queue = fq_bss_clean_queue;
		(*qm_ops)->deq_data_pkt = fq_deq_data_pkt;

		pAd->TxSwQMaxLen = MAX_PACKETS_IN_QUEUE;

		for (i = 0; i < WMM_NUM_OF_AC; i++)
			NdisAllocateSpinLock(pAd, &pAd->tx_swq_lock[i]);

		os_zero_mem(pAd->tx_swq, sizeof(pAd->tx_swq));
	} else {
		(*qm_ops)->enq_dataq_pkt = fq_enq_dataq_pkt;
		(*qm_ops)->schedule_tx_que = fq_schedule_tx_que;
		(*qm_ops)->sta_clean_queue = fq_sta_clean_queue;
		(*qm_ops)->bss_clean_queue = fq_bss_clean_queue;
		(*qm_ops)->deq_data_pkt = fq_deq_data_pkt;
	}

	pAd->fq_ctrl.enable |= FQ_READY;

	return NDIS_STATUS_SUCCESS;

}

INT fq_deinit(RTMP_ADAPTER *pAd)
{
	struct tx_swq_fifo *fifo_swq = NULL;
	STA_TR_ENTRY *tr_entry = NULL;
	QUEUE_ENTRY *pEntry = NULL;
	struct fq_stainfo_type *pfq_sta = NULL;
	INT enq_idx = 0;
	INT remain;
	INT quota[2] = {8, SQ_ENQ_RESERVE_PERAC};
	INT i, j, n;
	ULONG IrqFlags = 0;
	struct qm_ops *qm = pAd->qm_ops;

	for (i = 0; i < WMM_NUM_OF_AC; i++) {
		RTMP_IRQ_LOCK(&pAd->tx_swq_lock[i], IrqFlags);
		fifo_swq = &pAd->tx_swq[i];
		fifo_swq->enqIdx = 0;
		fifo_swq->deqIdx = 0;
		for (j = 0; j < (MAX_LEN_OF_MAC_TABLE/(sizeof(UINT32)*8)); j++)
				pAd->fq_ctrl.list_map[i][j] = 0;

		remain = 0;
		os_zero_mem(fifo_swq->swq, sizeof(UCHAR)*TX_SWQ_FIFO_LEN);
		for (n = 0; n < 2; n++) {
			if (pAd->fq_ctrl.fq[i].Head) {
				pEntry = pAd->fq_ctrl.fq[i].Head;
				enq_idx = fifo_swq->enqIdx;

				while (pEntry) {
					pfq_sta = container_of(pEntry, struct fq_stainfo_type, Entry[i]);
					pfq_sta->status[i] = FQ_UN_CLEAN_STA;
					tr_entry = &pAd->MacTab.tr_entry[pfq_sta->wcid];
					RTMP_SPIN_LOCK(&tr_entry->txq_lock[i]);

					remain = tr_entry->tx_queue[i].Number;

					for (j = 0; j < quota[n]; j++) {
						fifo_swq->swq[enq_idx] = tr_entry->wcid;
						if ((fifo_swq->swq[enq_idx] == 0) && (tr_entry->enq_cap)) {
							INC_RING_INDEX(fifo_swq->enqIdx, TX_SWQ_FIFO_LEN);
							remain--;
						} else {
							RTMP_SPIN_UNLOCK(&tr_entry->txq_lock[i]);
							goto NEXT_AC_QUEUE;
						}
						if (remain <= 0)
							break;
					}
					RTMP_SPIN_UNLOCK(&tr_entry->txq_lock[i]);
					pEntry = pEntry->Next;
				}
			}
		}
NEXT_AC_QUEUE:
		InitializeQueueHeader(&pAd->fq_ctrl.fq[i]);
		RTMP_IRQ_UNLOCK(&pAd->tx_swq_lock[i], IrqFlags);
	}

	fq_clean_list(pAd, WMM_NUM_OF_AC);

	os_zero_mem(&pAd->fq_ctrl, sizeof(struct fq_ctrl_type));

	qm->sta_clean_queue(pAd, WCID_ALL);

	for (i = 0; i < WMM_NUM_OF_AC; i++)
		NdisFreeSpinLock(&pAd->tx_swq_lock[i]);

	pAd->fq_ctrl.enable = 0;

	return 0;
}

INT fq_exit(RTMP_ADAPTER *pAd)
{
	if (pAd->fq_ctrl.enable & FQ_EN)
		fq_deinit(pAd);

	return NDIS_STATUS_SUCCESS;
}

static INT fq_add_list(RTMP_ADAPTER *pAd, UCHAR qidx, STA_TR_ENTRY *tr_entry)
{
	struct fq_stainfo_type *pfq_sta = NULL;
	UINT32 IsHit = 0;
	INT ret = 1;

	pfq_sta = &tr_entry->fq_sta_rec;
	IsHit = pAd->fq_ctrl.list_map[qidx][tr_entry->wcid>>5] & (1<<(tr_entry->wcid & 0x1F));

	if (pfq_sta && (IsHit == 0)) {
		InsertTailQueue(&pAd->fq_ctrl.fq[qidx], &(pfq_sta->Entry[qidx]));
		pAd->fq_ctrl.list_map[qidx][tr_entry->wcid>>5] |= (1<<(tr_entry->wcid & 0x1F));
		pfq_sta->kickPktCnt[qidx] = 0;
		pfq_sta->status[qidx] = FQ_IN_LIST_STA;
		ret = 0;
	}

	return ret;
}

UCHAR fq_del_list(RTMP_ADAPTER *pAd, struct dequeue_info *info, CHAR deq_qid)
{
	INT tot_sta;
	UCHAR deq_wcid = 0, wcid = 0;
	BOOLEAN IsPowSave = FALSE;
	QUEUE_ENTRY *pEntry = NULL, *pPrevEntry = NULL;
	STA_TR_ENTRY *tr_entry = NULL;
	struct fq_stainfo_type *pfq_sta = NULL;
	INT32 quota = 0;

	if (info->q_max_cnt[deq_qid] == 0)
		return 0;

	if (pAd->fq_ctrl.fq[deq_qid].Number == 0)
		return 0;

	if ((!(pAd->fq_ctrl.enable & FQ_SKIP_SINGLE_STA_CASE)) &&
		(pAd->fq_ctrl.fq[deq_qid].Number == 1) && (pAd->fq_ctrl.nactive == 1)) {
		pEntry = pAd->fq_ctrl.fq[deq_qid].Head;
		pfq_sta = container_of(pEntry, struct fq_stainfo_type, Entry[deq_qid]);
		deq_wcid = pfq_sta->wcid;
			goto EXIT;
	}

	tot_sta = pAd->fq_ctrl.fq[deq_qid].Number;

	pEntry = pAd->fq_ctrl.fq[deq_qid].Head;
	pPrevEntry = pEntry;
	while (tot_sta > 0) {
		tot_sta--;
		if (pEntry) {
			pfq_sta = container_of(pEntry, struct fq_stainfo_type, Entry[deq_qid]);
			wcid = pfq_sta->wcid;
			tr_entry = &pAd->MacTab.tr_entry[wcid];

			if ((IS_ENTRY_NONE(tr_entry)) || (tr_entry->tx_queue[deq_qid].Number <= 0)
				|| (tr_entry->PsMode == PWR_SAVE)) {
				if (tr_entry->tx_queue[deq_qid].Number <= 0) {
					if (pEntry->Next == NULL) {
						deq_wcid = 0;
						if (!(pAd->fq_ctrl.enable & FQ_NO_PKT_STA_KEEP_IN_LIST)) {
							pEntry = RemoveTailQueue(&pAd->fq_ctrl.fq[deq_qid]);
							pfq_sta->status[deq_qid] = FQ_UN_CLEAN_STA;
							pAd->fq_ctrl.list_map[deq_qid][wcid>>5] &= ~(1<<(wcid & 0x1F));
						}
					} else {
						deq_wcid = pfq_sta->wcid;
						if (IsPowSave) {
							PickFromQueue(&pAd->fq_ctrl.fq[deq_qid], pPrevEntry, pEntry);
						} else {
							pEntry = RemoveHeadQueue(&pAd->fq_ctrl.fq[deq_qid]);
						}
						InsertTailQueue(&pAd->fq_ctrl.fq[deq_qid], &(pfq_sta->Entry[deq_qid]));
						if (IsPowSave)
							pEntry = pPrevEntry->Next;
						else
							pEntry = pAd->fq_ctrl.fq[deq_qid].Head;
					}
				} else if (tr_entry->PsMode == PWR_SAVE) {
					if (pAd->fq_ctrl.fq[deq_qid].Number <= 1)
						deq_wcid = 0;
					else
						deq_wcid = wcid;
					IsPowSave = TRUE;
					pPrevEntry = pEntry;
					pEntry = pEntry->Next;
				}
				if (deq_wcid == 0)
					break;
				deq_wcid = 0;
				continue;
			}
			if ((pEntry->Next == NULL) && (IsPowSave == FALSE))
				if (pAd->fq_ctrl.fq[deq_qid].Number > 1)
					pAd->fq_ctrl.fq[deq_qid].Number = 1;

			quota = (pfq_sta->thMax[deq_qid]<<pAd->fq_ctrl.factor) - pfq_sta->macQLen[deq_qid];
			IsPowSave = FALSE;
			if (quota > 0)
				info->q_max_cnt[deq_qid] = quota;
			else
				info->q_max_cnt[deq_qid] = MIN_HT_THMAX;
			deq_wcid = wcid;
			break;
		}
		deq_wcid = 0;
		break;
	} /* while */
EXIT:
	return deq_wcid;
}


INT fq_del_report(RTMP_ADAPTER *pAd, struct dequeue_info *info)
{
	ULONG IrqFlags = 0;
	UCHAR qidx = info->cur_q;
	UCHAR wcid = info->cur_wcid;
	struct fq_stainfo_type *pfq_sta = NULL;
	QUEUE_ENTRY *pEntry = NULL;
	STA_TR_ENTRY *tr_entry = NULL;
	INT prev_wcid_tmp = -1;

	RTMP_IRQ_LOCK(&pAd->tx_swq_lock[qidx], IrqFlags);

#ifdef FQ_SCH_DBG_SUPPORT
	if (pAd->fq_ctrl.dbg_en&FQ_DBG_DUMP_STA_LOG) {
		if (pAd->fq_ctrl.prev_qidx >= 0) {
			UCHAR the_prev_qidx = pAd->fq_ctrl.prev_qidx;

			if (the_prev_qidx == qidx)
				prev_wcid_tmp = pAd->fq_ctrl.prev_wcid[qidx];
			else
				prev_wcid_tmp = pAd->fq_ctrl.prev_wcid[the_prev_qidx];

			if ((prev_wcid_tmp > 0) && (prev_wcid_tmp < MAX_LEN_OF_MAC_TABLE)) {
				if ((pAd->fq_ctrl.prev_wcid[qidx] == wcid) &&
					((pAd->fq_ctrl.fq[qidx].Number >= 1) || (!pAd->fq_ctrl.enable)
					|| (pAd->fq_ctrl.nactive == 1))) {
					tr_entry = &pAd->MacTab.tr_entry[wcid];
					pfq_sta = &tr_entry->fq_sta_rec;
					pAd->fq_ctrl.prev_kick_cnt[qidx] += info->deq_pkt_cnt;
					RTMP_SEM_LOCK(&pfq_sta->lock[qidx]);
					if (pfq_sta->KMAX < pAd->fq_ctrl.prev_kick_cnt[qidx])
						pfq_sta->KMAX = pAd->fq_ctrl.prev_kick_cnt[qidx];
					RTMP_SEM_UNLOCK(&pfq_sta->lock[qidx]);
				} else {
					tr_entry = &pAd->MacTab.tr_entry[pAd->fq_ctrl.prev_wcid[qidx]];
					pfq_sta = &tr_entry->fq_sta_rec;
					RTMP_SEM_LOCK(&pfq_sta->lock[qidx]);
					if (pfq_sta->KMAX < pAd->fq_ctrl.prev_kick_cnt[the_prev_qidx])
						pfq_sta->KMAX = pAd->fq_ctrl.prev_kick_cnt[the_prev_qidx];
					pAd->fq_ctrl.prev_kick_cnt[qidx] = info->deq_pkt_cnt;
					RTMP_SEM_UNLOCK(&pfq_sta->lock[qidx]);
				}
			} else
				pAd->fq_ctrl.prev_kick_cnt[qidx] = info->deq_pkt_cnt;
		} else
			pAd->fq_ctrl.prev_kick_cnt[qidx] = info->deq_pkt_cnt;
		pAd->fq_ctrl.prev_wcid[qidx] = wcid;
		pAd->fq_ctrl.prev_qidx = qidx;
	}
#endif

	tr_entry = &pAd->MacTab.tr_entry[info->cur_wcid];
	pfq_sta = &tr_entry->fq_sta_rec;

	if (info->deq_pkt_cnt > 0) {
		RTMP_SEM_LOCK(&pfq_sta->lock[qidx]);
		pfq_sta->kickPktCnt[qidx] += info->deq_pkt_cnt;
		pfq_sta->macQLen[qidx] += info->deq_pkt_cnt;
		if (pAd->fq_ctrl.frm_cnt[qidx] >= info->deq_pkt_cnt)
			pAd->fq_ctrl.frm_cnt[qidx] -= info->deq_pkt_cnt;
		else
			pAd->fq_ctrl.frm_cnt[qidx] = 0;
		RTMP_SEM_UNLOCK(&pfq_sta->lock[qidx]);
	}

	if (!(pAd->fq_ctrl.enable & FQ_READY)) {
		pfq_sta->kickPktCnt[qidx] = info->deq_pkt_cnt;
		RTMP_IRQ_UNLOCK(&pAd->tx_swq_lock[qidx], IrqFlags);
		goto DEQ_REP_EXIT;
	}
	RTMP_SPIN_LOCK(&tr_entry->txq_lock[qidx]);
	if (tr_entry->tx_queue[info->cur_q].Number > 0) {
		if ((pfq_sta->thMax[qidx]<<pAd->fq_ctrl.factor) <= pfq_sta->macQLen[qidx]) {
			pfq_sta->kickPktCnt[qidx] = 0;
			if (pAd->fq_ctrl.fq[qidx].Number > 1) {
				pEntry = RemoveHeadQueue(&pAd->fq_ctrl.fq[qidx]);
				InsertTailQueue(&pAd->fq_ctrl.fq[qidx], &(pfq_sta->Entry[qidx]));
				pfq_sta->kickPktCnt[qidx] = 0;
			}
		}
	} else {
		if (pAd->fq_ctrl.enable & FQ_NO_PKT_STA_KEEP_IN_LIST) {
			if (pAd->fq_ctrl.fq[qidx].Number > 1) {
				pEntry = RemoveHeadQueue(&pAd->fq_ctrl.fq[qidx]);
				InsertTailQueue(&pAd->fq_ctrl.fq[qidx], &(pfq_sta->Entry[qidx]));
				pfq_sta->kickPktCnt[qidx] = 0;
			}
		} else {
			if (pAd->fq_ctrl.fq[qidx].Head) {
				pEntry = RemoveHeadQueue(&pAd->fq_ctrl.fq[qidx]);
				pAd->fq_ctrl.list_map[qidx][wcid>>5] &= ~(1<<(wcid & 0x1F));
				pfq_sta->status[qidx] = FQ_UN_CLEAN_STA;
				pfq_sta->kickPktCnt[qidx] = 0;
			}
		}
	}
	RTMP_SPIN_UNLOCK(&tr_entry->txq_lock[qidx]);
	RTMP_IRQ_UNLOCK(&pAd->tx_swq_lock[qidx], IrqFlags);
DEQ_REP_EXIT:
	if (info->deq_pkt_cnt <= 0)
		return NDIS_STATUS_FAILURE;
	else
		return NDIS_STATUS_SUCCESS;
}

INT fq_reset_list_entry(RTMP_ADAPTER *pAd, UCHAR qidx, UCHAR wcid)
{
	int i;
	struct fq_stainfo_type *pfq_sta = NULL;
	STA_TR_ENTRY *tr_entry = NULL;

	if (wcid > MAX_LEN_OF_TR_TABLE)
		return NDIS_STATUS_FAILURE;
	if (qidx > WMM_NUM_OF_AC)
		return NDIS_STATUS_FAILURE;

	tr_entry = &pAd->MacTab.tr_entry[wcid];
	pfq_sta = &tr_entry->fq_sta_rec;

	if (qidx < WMM_NUM_OF_AC) {
		/* pfq_sta->thMax[qidx] = DEFAULT_THMAX; */
		pfq_sta->Entry[qidx].Next = NULL;
		pfq_sta->macQLen[qidx] = 0;
		pfq_sta->kickPktCnt[qidx] = 0;
		pfq_sta->status[qidx] = FQ_EMPTY_STA;
	} else {
		for (i = 0; i < WMM_NUM_OF_AC; i++) {
			pfq_sta->thMax[i] = DEFAULT_THMAX;
			pfq_sta->Entry[i].Next = NULL;
			pfq_sta->macQLen[i] = 0;
			pfq_sta->kickPktCnt[i] = 0;
			pfq_sta->status[i] = FQ_EMPTY_STA;
		}
		pfq_sta->wcid = wcid;
		pfq_sta->mpduTime =  RED_MPDU_TIME_INIT;
		pfq_sta->KMAX = 0;
	}

	return NDIS_STATUS_SUCCESS;
}

static INT fq_clean_list(RTMP_ADAPTER *pAd, UCHAR qidx)
{
	ULONG	IrqFlags = 0;
	UCHAR qidx_c, qidx_s, qidx_e;
	struct fq_stainfo_type *pfq_sta = NULL;
	QUEUE_ENTRY *pEntry = NULL, *pPrevEntry = NULL;

	if (qidx > WMM_NUM_OF_AC)
		return NDIS_STATUS_FAILURE;
	if (qidx == WMM_NUM_OF_AC) {
		qidx_s = 0;
		qidx_e = WMM_NUM_OF_AC-1;
	} else {
		qidx_s = qidx;
		qidx_e = qidx;
	}
	for (qidx_c = qidx_s; qidx_c <= qidx_e; qidx_c++) {
		RTMP_IRQ_LOCK(&pAd->tx_swq_lock[qidx_c], IrqFlags);
		pEntry = pAd->fq_ctrl.fq[qidx_c].Head;
		pPrevEntry = pEntry;
		while (pEntry) {
			pfq_sta = container_of(pEntry, struct fq_stainfo_type, Entry[qidx_c]);
			RTMP_SEM_LOCK(&pfq_sta->lock[qidx_c]);
			if (pfq_sta->status[qidx_c] == FQ_UN_CLEAN_STA) {
				PickFromQueue(&pAd->fq_ctrl.fq[qidx_c], pPrevEntry, pEntry);
				pfq_sta = container_of(pEntry, struct fq_stainfo_type, Entry[qidx_c]);
				pAd->fq_ctrl.list_map[qidx_c][pfq_sta->wcid>>5]
						&= ~(1<<(pfq_sta->wcid & 0x1F));
				if (fq_reset_list_entry(pAd, qidx_c, pfq_sta->wcid)) {
					RTMP_SEM_UNLOCK(&pfq_sta->lock[qidx_c]);
					break;
				}
			}
			RTMP_SEM_UNLOCK(&pfq_sta->lock[qidx_c]);
			pPrevEntry = pEntry;
			pEntry = pEntry->Next;
		}
		RTMP_IRQ_UNLOCK(&pAd->tx_swq_lock[qidx_c], IrqFlags);
	}

	return NDIS_STATUS_SUCCESS;
}

INT fq_update_thMax(RTMP_ADAPTER *pAd, STA_TR_ENTRY *tr_entry, UINT8 wcid, INT32 mpduTime)
{
	UINT32  max_thMax = 0, max_amptu_len = 0, max_ampdu_num = 0;
	UINT32 Value[WMM_NUM_OF_AC], txop[WMM_NUM_OF_AC], txop_usec, thMax, dwrr_idx, dwrr_quantum, dwrr_time;
	INT i, not_active[WMM_NUM_OF_AC];
	struct fq_stainfo_type *pfq_sta = NULL;

	if (pAd->fq_ctrl.enable & FQ_READY) {
		pfq_sta = &tr_entry->fq_sta_rec;
		pfq_sta->mpduTime =  (mpduTime <= 1) ? MAX_FQ_PPDU_TIME : mpduTime;
		if (mpduTime <= 1) {
			for (i = 0; i < WMM_NUM_OF_AC; i++)
				if (tr_entry->tx_queue[i].Number == 0)
					pfq_sta->macQPktLen[i] = 0;
				pfq_sta->tx_msdu_cnt = 0;
			return NDIS_STATUS_FAILURE;
		}
		pfq_sta->tx_msdu_cnt = 0;
		if (pAd->vow_watf_en)
			RTMP_IO_READ32(pAd, UMAC_AIRTIME_QUANTUM_SETTING0, &dwrr_quantum);
		for (i = 0; i < WMM_NUM_OF_AC; i++) {
			not_active[i] = 0;
			RTMP_SEM_LOCK(&pfq_sta->lock[i]);
			if (pfq_sta->macQLen[i] < 0)
				pfq_sta->macQLen[i] = 0;
			if ((pfq_sta->macQPktLen[i] < 64) && (pfq_sta->macQLen[i] == 0) &&
				(pfq_sta->thMax[i] <= DEFAULT_THMAX)) {
				not_active[i] = 1;
				if (pAd->fq_ctrl.enable & FQ_NO_PKT_STA_KEEP_IN_LIST) {
					if ((pAd->fq_ctrl.no_packet_chk_map[i][wcid>>5] & (1<<(wcid & 0x1F))) &&
							(pAd->fq_ctrl.list_map[i][wcid>>5] & (1<<(wcid & 0x1F))) &&
							(tr_entry->tx_queue[i].Number <= 0)) {
						pfq_sta->status[i] = FQ_UN_CLEAN_STA;
						pAd->fq_ctrl.no_packet_chk_map[i][wcid>>5] &= ~(1<<(wcid & 0x1F));
					} else if ((pAd->fq_ctrl.list_map[i][wcid>>5] & (1<<(wcid & 0x1F))) &&
							(tr_entry->tx_queue[i].Number <= 0))
						pAd->fq_ctrl.no_packet_chk_map[i][wcid>>5] |= (1<<(wcid & 0x1F));
				}
				RTMP_SEM_UNLOCK(&pfq_sta->lock[i]);
				continue;
			} else
				pAd->fq_ctrl.no_packet_chk_map[i][wcid>>5] &= (1<<(wcid & 0x1F));
			RTMP_IO_READ32(pAd, TMAC_ACTXOPLR0+(i<<2), &Value[i]);
			if (i&0x1)
				txop[i] = GET_AC1LIMIT(Value[i]);
			else
				txop[i] = GET_AC0LIMIT(Value[i]);
			txop_usec = txop[i]<<5;
			if (txop_usec > MAX_FQ_PPDU_TIME)
				txop_usec = MAX_FQ_PPDU_TIME;
			if (txop_usec == 0)
				txop_usec = 2000;
			if (pAd->vow_watf_en) {
				dwrr_idx = pAd->vow_sta_cfg[wcid].dwrr_quantum[i];
				dwrr_time = ((dwrr_quantum >> (dwrr_idx * UMAX_AIRTIME_QUANTUM_OFFSET))
						& UMAX_AIRTIME_QUANTUM_MASK) << 8;
				if ((txop_usec > dwrr_time) || (txop_usec == 0))
					thMax = dwrr_time / pfq_sta->mpduTime;
				else
					thMax = txop_usec / pfq_sta->mpduTime;
			} else
				thMax = txop_usec/pfq_sta->mpduTime;

			/* TODO: should use STA's link to compute */
			max_ampdu_num = (IS_MT7615(pAd)) ? MAX_FQ_VHT_AMPDU_NUM : MAX_FQ_HT_AMPDU_NUM;
			max_amptu_len = (IS_MT7615(pAd)) ? MAX_FQ_VHT_AMPDU_LEN : MAX_FQ_HT_AMPDU_LEN;

			if (pfq_sta->macQPktLen[i] >= 64)
				max_thMax = max_amptu_len/pfq_sta->macQPktLen[i];

			max_thMax = (max_thMax > max_ampdu_num) ? max_ampdu_num : max_thMax;

			if (thMax > max_thMax)
				pfq_sta->thMax[i] = max_thMax;
			else if (thMax < MIN_HT_THMAX)
				pfq_sta->thMax[i] = MIN_HT_THMAX;
			else
				pfq_sta->thMax[i] = thMax;

			if (tr_entry->tx_queue[i].Number == 0)
				pfq_sta->macQPktLen[i] = 0;
			RTMP_SEM_UNLOCK(&pfq_sta->lock[i]);
		}
		if (pAd->fq_ctrl.enable & FQ_NO_PKT_STA_KEEP_IN_LIST)
			fq_clean_list(pAd, WMM_NUM_OF_AC);

		if ((not_active[0] == 0) || (not_active[1] == 0) || (not_active[2] == 0) || (not_active[3] == 0))
			return NDIS_STATUS_SUCCESS;
		else {
			return NDIS_STATUS_FAILURE;
		}
	}
	return NDIS_STATUS_SUCCESS;
}

static INT fq_schedule_tx_que(RTMP_ADAPTER *pAd)
{
	struct tm_ops *tm_ops = pAd->tm_qm_ops;
	UINT i;
	UCHAR need_schedule = 0;

	for (i = 0; i < WMM_NUM_OF_AC; i++)
		if ((pAd->fq_ctrl.list_map[i][0] != 0) || (pAd->fq_ctrl.list_map[i][1] != 0)
			|| (pAd->fq_ctrl.list_map[i][2] != 0) || (pAd->fq_ctrl.list_map[i][3] != 0)) {
			need_schedule = 1;
			break;
		}

	if ((need_schedule != 0) || (pAd->mgmt_que.Number > 0) ||
		(pAd->high_prio_que.Number > 0)) {
		tm_ops->schedule_task(pAd, TX_DEQ_TASK);
	}

	return NDIS_STATUS_SUCCESS;
}

static INT fq_sta_clean_queue(RTMP_ADAPTER *pAd, UCHAR wcid)
{
	UCHAR idx, wcid_start, wcid_end;
	STA_TR_ENTRY *tr_entry;
	ULONG IrqFlags;
	NDIS_PACKET *pPacket;
	QUEUE_ENTRY *pEntry;
	QUEUE_HEADER *pQueue;
	INT frame_count = 0;
	struct fq_stainfo_type *pfq_sta = NULL;
	INT need_clean = 0;

	if (wcid == WCID_ALL) {
		wcid_start = 0;
		wcid_end = MAX_LEN_OF_TR_TABLE - 1;
	} else {
		if (wcid < MAX_LEN_OF_TR_TABLE)
			wcid_start = wcid_end = wcid;
		else {
			MTWF_LOG(DBG_CAT_TX, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s():Invalid WCID[%d]\n",
					 __func__, wcid));
			return FALSE;
		}
	}

	for (wcid = wcid_start; wcid <= wcid_end; wcid++) {
		tr_entry = &pAd->MacTab.tr_entry[wcid];

		if (IS_ENTRY_NONE(tr_entry))
			continue;

		for (idx = 0; idx < WMM_QUE_NUM; idx++) {
			RTMP_IRQ_LOCK(&tr_entry->txq_lock[idx], IrqFlags);
			pQueue = &tr_entry->tx_queue[idx];

			while (pQueue->Head) {
				pEntry = RemoveHeadQueue(pQueue);
				TR_ENQ_COUNT_DEC(tr_entry);
				frame_count++;
				pPacket = QUEUE_ENTRY_TO_PACKET(pEntry);

				if (pPacket)
					RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
			}
			if (frame_count > 0) {
				pfq_sta = &tr_entry->fq_sta_rec;
				if ((tr_entry->tx_queue[idx].Number == 0) &&
					(pfq_sta->status[idx] == FQ_IN_LIST_STA)) {
					pfq_sta->status[idx] = FQ_UN_CLEAN_STA;
					need_clean = 1;
				}
				RTMP_SPIN_LOCK(&pAd->tx_swq_lock[idx]);
				pAd->fq_ctrl.frm_cnt[idx] -= frame_count;
				frame_count = 0;
				RTMP_SPIN_UNLOCK(&pAd->tx_swq_lock[idx]);
			}
			RTMP_IRQ_UNLOCK(&tr_entry->txq_lock[idx], IrqFlags);
		}
		RTMP_IRQ_LOCK(&tr_entry->ps_queue_lock, IrqFlags);
		pQueue = &tr_entry->ps_queue;

		while (pQueue->Head) {
			pEntry = RemoveHeadQueue(pQueue);
			pPacket = QUEUE_ENTRY_TO_PACKET(pEntry);

			if (pPacket)
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
		}

		RTMP_IRQ_UNLOCK(&tr_entry->ps_queue_lock, IrqFlags);
	}

	if (need_clean == 1)
		fq_clean_list(pAd, WMM_NUM_OF_AC);

	return NDIS_STATUS_SUCCESS;
}

static INT fq_bss_clean_queue(struct _RTMP_ADAPTER *ad, struct wifi_dev *wdev)
{
	INT sta_idx;
	INT qidx;
	struct _STA_TR_ENTRY *tr_entry;
	struct fq_stainfo_type *pfq_sta = NULL;
	INT frame_count = 0;

	/*TODO: add check de-queue task idle*/
	qm_leave_queue_pkt(wdev, &ad->mgmt_que, &ad->mgmt_que_lock);
	/*leave per sta/ac queue*/
	for (sta_idx = 0 ; sta_idx < MAX_LEN_OF_TR_TABLE ; sta_idx++) {

		tr_entry = &ad->MacTab.tr_entry[sta_idx];

		if (tr_entry->wdev != wdev)
			continue;

		for (qidx = 0; qidx < WMM_QUE_NUM ; qidx++) {
			frame_count = tr_entry->tx_queue[qidx].Number;
			qm_leave_queue_pkt(wdev, &tr_entry->tx_queue[qidx], &tr_entry->txq_lock[qidx]);
			pfq_sta = &tr_entry->fq_sta_rec;
			frame_count = frame_count - tr_entry->tx_queue[qidx].Number;
			if (pfq_sta->status[qidx] == FQ_IN_LIST_STA)
				if (tr_entry->tx_queue[qidx].Number == 0)
					pfq_sta->status[qidx] = FQ_UN_CLEAN_STA;
				ad->fq_ctrl.frm_cnt[qidx] -= frame_count;
		}
	}

	fq_clean_list(ad, WMM_NUM_OF_AC);

	return NDIS_STATUS_SUCCESS;
}

static INT fq_enq_dataq_pkt(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, PNDIS_PACKET pkt, UCHAR q_idx)
{
	UCHAR wcid = RTMP_GET_PACKET_WCID(pkt);
	STA_TR_ENTRY *tr_entry = &pAd->MacTab.tr_entry[wcid];
	struct qm_ops *qm_ops = pAd->qm_ops;
	RTMP_ARCH_OP *arch_ops = &pAd->archOps;
	BOOL drop_packet;

	if (wlan_operate_get_state(wdev) != WLAN_OPER_STATE_VALID) {
		RELEASE_NDIS_PACKET(pAd, pkt, NDIS_STATUS_FAILURE);
		return NDIS_STATUS_FAILURE;
	}

	if (!RTMP_GET_PACKET_HIGH_PRIO(pkt)) {
		if (arch_ops->archRedMarkPktDrop == NULL)
			drop_packet = FALSE;
		else
			drop_packet = arch_ops->archRedMarkPktDrop(wcid, q_idx, pAd) &&
					(!(pAd->fq_ctrl.enable & FQ_SKIP_RED));
		if (drop_packet == FALSE) {
			if (pAd->TxSwQueue[q_idx].Number >= pAd->TxSwQMaxLen) {
				RELEASE_NDIS_PACKET(pAd, pkt, NDIS_STATUS_FAILURE);
				if (arch_ops->archRedEnqueueFail)
					arch_ops->archRedEnqueueFail(wcid, q_idx, pAd);
				return NDIS_STATUS_FAILURE;
			} else {
				if (!fq_enq_req(pAd, pkt, q_idx, tr_entry, NULL)) {
					RELEASE_NDIS_PACKET(pAd, pkt, NDIS_STATUS_FAILURE);
					if (arch_ops->archRedEnqueueFail)
						arch_ops->archRedEnqueueFail(wcid, q_idx, pAd);
					return NDIS_STATUS_FAILURE;
				}
			}
		} else {
			RELEASE_NDIS_PACKET(pAd, pkt, NDIS_STATUS_FAILURE);
			return NDIS_STATUS_FAILURE;
		}
	} else {
		RTMP_SEM_LOCK(&pAd->high_prio_que_lock);
		InsertTailQueue(&pAd->high_prio_que, PACKET_TO_QUEUE_ENTRY(pkt));
		RTMP_SEM_UNLOCK(&pAd->high_prio_que_lock);
		if (arch_ops->archRedRecordCP)
			arch_ops->archRedRecordCP(wcid, pAd);
	}

	qm_ops->schedule_tx_que(pAd);

	return NDIS_STATUS_SUCCESS;
}

INT fq_enq_req(RTMP_ADAPTER *pAd, NDIS_PACKET *pkt, UCHAR qidx,
		STA_TR_ENTRY *tr_entry, QUEUE_HEADER *pPktQueue)
{
	BOOLEAN enq_done = FALSE;
	INT enq_idx = 0;
	struct tx_swq_fifo *fifo_swq;
	UCHAR occupied_wcid = 0;
	QUEUE_ENTRY *pEntry;
	struct fq_stainfo_type *pfq_sta = NULL;
	UINT capCount = 0;
	NDIS_PACKET *tmpPkt;
	ULONG IrqFlags = 0;

	ASSERT(qidx < WMM_QUE_NUM);
	ASSERT((tr_entry->wcid != 0));
	fifo_swq = &pAd->tx_swq[qidx];

	RTMP_IRQ_LOCK(&pAd->tx_swq_lock[qidx], IrqFlags);
	if ((tr_entry->enqCount > SQ_ENQ_NORMAL_MAX)
		&& (tr_entry->tx_queue[qidx].Number > SQ_ENQ_RESERVE_PERAC)) {
		enq_done = FALSE;
		goto enq_end;
	}

	enq_idx = fifo_swq->enqIdx;

	if (tr_entry->enq_cap) {
		RTMP_SPIN_LOCK(&tr_entry->txq_lock[qidx]);
		RTMP_SET_PACKET_WCID(pkt, tr_entry->wcid);
		RTMP_SET_PACKET_QUEIDX(pkt, qidx);

		pAd->fq_ctrl.no_packet_chk_map[qidx][tr_entry->wcid>>5] &= ~(1<<(tr_entry->wcid & 0x1F));

		if ((tr_entry->tx_queue[qidx].Number == 0) || (pAd->fq_ctrl.fq[qidx].Number == 0))
			fq_add_list(pAd, qidx, tr_entry);

		pfq_sta = &tr_entry->fq_sta_rec;
		pfq_sta->macQPktLen[qidx] = (pfq_sta->macQPktLen[qidx] <= 0) ? GET_OS_PKT_LEN(pkt)
				: ((((pfq_sta->macQPktLen[qidx]<<6) - pfq_sta->macQPktLen[qidx])>>6)
				+ ((GET_OS_PKT_LEN(pkt))>>6));
		/* tail drop cause OOM quickly -> 32KB pages too spare */
		/* InsertTailQueueAc(pAd, tr_entry, &tr_entry->tx_queue[qidx], PACKET_TO_QUEUE_ENTRY(pkt)); */
		if (pAd->fq_ctrl.frm_cnt[qidx] < ((FQ_PER_AC_LIMIT>>0)-1)) {
			InsertTailQueueAc(pAd, tr_entry, &tr_entry->tx_queue[qidx], PACKET_TO_QUEUE_ENTRY(pkt));
			pAd->fq_ctrl.frm_cnt[qidx]++;
			TR_ENQ_COUNT_INC(tr_entry);
		} else {
			/* pEntry = RemoveHeadQueue(&tr_entry->tx_queue[qidx]); */
			enq_done = FALSE;
			RTMP_SPIN_UNLOCK(&tr_entry->txq_lock[qidx]);
			goto enq_end;
		}
		RTMP_SPIN_UNLOCK(&tr_entry->txq_lock[qidx]);
#ifdef MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL
#if TC_PAGE_BASED_DEMAND
		tr_entry->TotalPageCount[qidx] += (INT16)(MTSDIOTxGetPageCount(GET_OS_PKT_LEN(pkt), FALSE));
#endif /* TC_PAGE_BASED_DEMAND */
#if DEBUG_ADAPTIVE_QUOTA
		MTWF_LOG(DBG_CAT_TX, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("%s: wcid %d q %d, pkt len %d, TotalPageCount %d\n",
				__func__, tr_entry->wcid, qidx, GET_OS_PKT_LEN(pkt),
				tr_entry->TotalPageCount[qidx]));
#endif /* DEBUG_ADAPTIVE_QUOTA */
#endif /* MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL */
		enq_done = TRUE;
	} else {
		enq_done = FALSE;
		goto enq_end;
	}

	capCount = SQ_ENQ_RESERVE_PERAC - tr_entry->tx_queue[qidx].Number;

	if (pPktQueue && pPktQueue->Number <= capCount) {
		while (pPktQueue->Head) {
			pEntry = RemoveHeadQueue(pPktQueue);
			tmpPkt =  QUEUE_ENTRY_TO_PACKET(pEntry);
			enq_idx = fifo_swq->enqIdx;
			if ((pAd->fq_ctrl.enable & FQ_READY) && (tr_entry->enq_cap)) {
				if (tr_entry->enqCount >= SQ_ENQ_NORMAL_MAX) {
					occupied_wcid = fifo_swq->swq[enq_idx];
					enq_done = FALSE;
					goto enq_end;
				}
				RTMP_SPIN_LOCK(&tr_entry->txq_lock[qidx]);
				pAd->fq_ctrl.no_packet_chk_map[qidx][tr_entry->wcid>>5] &= ~(1<<(tr_entry->wcid & 0x1F));
				if ((tr_entry->tx_queue[qidx].Number == 0) || (pAd->fq_ctrl.fq[qidx].Number == 0))
					fq_add_list(pAd, qidx, tr_entry);
				pAd->fq_ctrl.frm_cnt[qidx]++;
				InsertTailQueueAc(pAd, tr_entry, &tr_entry->tx_queue[qidx], tmpPkt);
				TR_ENQ_COUNT_INC(tr_entry);
				RTMP_SPIN_UNLOCK(&tr_entry->txq_lock[qidx]);
				enq_done = TRUE;
#ifdef MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL
#if TC_PAGE_BASED_DEMAND
				tr_entry->TotalPageCount[qidx] +=
					(INT16)(MTSDIOTxGetPageCount(GET_OS_PKT_LEN(tmpPkt), FALSE));
#endif /* TC_PAGE_BASED_DEMAND */
#if DEBUG_ADAPTIVE_QUOTA
				MTWF_LOG(DBG_CAT_TX, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("%s: wcid %d q %d, pkt len %d TotalPageCount %d\n",
					__func__, tr_entry->wcid, qidx, GET_OS_PKT_LEN(tmpPkt),
					tr_entry->TotalPageCount[qidx]));
#endif /* DEBUG_ADAPTIVE_QUOTA */
#endif /* MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL */
			} else {
				enq_done = FALSE;
				goto enq_end;
			}
		}
	}

enq_end:
	RTMP_IRQ_UNLOCK(&pAd->tx_swq_lock[qidx], IrqFlags);
	MTWF_LOG(DBG_CAT_TX, DBG_SUBCAT_ALL, DBG_LVL_INFO,
			 ("%s():EnqPkt(%p) for WCID(%d) to tx_swq[%d].swq[%d] %s\n",
			  __func__, pkt, tr_entry->wcid, qidx, enq_idx,
			  (enq_done ? "success" : "fail")));

	if (enq_done == FALSE) {
#ifdef DBG_DIAGNOSE
#ifdef DBG_TXQ_DEPTH
		if ((pAd->DiagStruct.inited) && (pAd->DiagStruct.wcid == tr_entry->wcid))
			pAd->DiagStruct.diag_info[pAd->DiagStruct.ArrayCurIdx].enq_fall_cnt[qidx]++;
#endif

#endif /* DBG_DIAGNOSE */
	}

#ifdef MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL
	else {
		/* Soumik: may need to move the to _RTMPDeQueuePacket()
		 * for AP mode to help account for the demand due to
		 * delivery of PS buffered frame.
		 */
		MTAdaptiveResourceCheckFastAdjustment(pAd, tr_entry->wcid, qidx);
		MTAdaptiveResourceAllocation(pAd, WCID_ALL, GET_NUM_OF_TX_RING(pAd->chipCap));
	}

#endif
	return enq_done;
}

static INT32 fq_deq_data_pkt(RTMP_ADAPTER *pAd, TX_BLK *tx_blk, INT32 max_cnt, struct dequeue_info *info)
{
	INT ret = NDIS_STATUS_SUCCESS;

	ge_deq_req(pAd, max_cnt, info);

	/* wait for next schedule period to service de-queue pkt */
	if (info->status == NDIS_STATUS_FAILURE)
		return NDIS_STATUS_FAILURE;

	MTWF_LOG(DBG_CAT_TX, DBG_SUBCAT_ALL, DBG_LVL_INFO,
		("%s(): deq_info:cur_wcid=%d,cur_qidx=%d, pkt_cnt=%d, pkt_bytes=%d\n",
		__func__, info->cur_wcid,
		info->cur_q, info->pkt_cnt, info->pkt_bytes));

	ret = deq_packet_gatter(pAd, info, tx_blk);

	if (!ret) {
		if (info->q_max_cnt[info->cur_q] > 0)
			info->q_max_cnt[info->cur_q] -= info->deq_pkt_cnt;

		if (info->target_wcid < MAX_LEN_OF_TR_TABLE)
			info->pkt_cnt -= info->deq_pkt_cnt;
	}


	ret = fq_del_report(pAd, info);

	return ret;
}

/* UserPriority To AccessCategory mapping */
void fq_tx_free_per_packet(RTMP_ADAPTER *pAd, UINT8 ucAC, UINT8 ucWlanIdx, NDIS_PACKET *pkt)
{
	struct fq_stainfo_type *pfq_sta = NULL;
	STA_TR_ENTRY *tr_entry = NULL;
	tr_entry = &pAd->MacTab.tr_entry[ucWlanIdx];

	pfq_sta = &tr_entry->fq_sta_rec;

	RTMP_SEM_LOCK(&pfq_sta->lock[ucAC]);
	if (pfq_sta->macQLen[ucAC] > 0)
		pfq_sta->macQLen[ucAC]--;

	pfq_sta->tx_msdu_cnt++;
	if ((pfq_sta->macQLen[ucAC] == 0) && (pfq_sta->status[ucAC] & FQ_UN_CLEAN_STA))
		fq_reset_list_entry(pAd, ucAC, ucWlanIdx);

	RTMP_SEM_UNLOCK(&pfq_sta->lock[ucAC]);

	return;
}

INT set_fq_enable(PRTMP_ADAPTER pAd, RTMP_STRING *arg)
{
	UINT32 en, rv, factor;
	RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct qm_ops **qm_ops = &pAd->qm_ops;
	int prev_qm = 0;

	if (arg) {
		rv = sscanf(arg, "%d-%d", &en, &factor);
		if ((rv > 0) && (en <= FQ_EN_MASK)) {
			if (((pAd->fq_ctrl.enable & FQ_READY) == 0) && (en & FQ_EN)) {
				tm_exit(pAd);
				qm_exit(pAd);
				pAd->fq_ctrl.enable = en;
				prev_qm = cap->qm;

				if (cap->qm == FAST_PATH_QM) {
					cap->qm = FAST_PATH_FAIR_QM;
					*qm_ops = &fp_fair_qm_ops;
					os_move_mem(*qm_ops, &fp_qm_ops, sizeof(struct qm_ops));
				} else {
					cap->qm = GENERIC_FAIR_QM;
					*qm_ops = &ge_fair_qm_ops;
					os_move_mem(*qm_ops, &ge_qm_ops, sizeof(struct qm_ops));
				}
				qm_init(pAd);
				tm_init(pAd);
				pAd->fq_ctrl.prev_qm = prev_qm;
			} else if ((pAd->fq_ctrl.enable & FQ_READY) && ((en & FQ_EN) == 0)) {
				pAd->fq_ctrl.enable = en;
				prev_qm = pAd->fq_ctrl.prev_qm;
				tm_exit(pAd);
				qm_exit(pAd);
				if (pAd->fq_ctrl.prev_qm == FAST_PATH_QM) {
					cap->qm = FAST_PATH_QM;
					*qm_ops = &fp_qm_ops;
				} else {
					cap->qm = GENERIC_QM;
					*qm_ops = &ge_qm_ops;
				}
				qm_init(pAd);
				tm_init(pAd);
				pAd->fq_ctrl.prev_qm = prev_qm;
			} else
				pAd->fq_ctrl.enable = en | ((pAd->fq_ctrl.enable & FQ_READY) ? FQ_READY : 0);

			if ((factor <= 4) && (factor >= 0))
				pAd->fq_ctrl.factor = factor;
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				("%s: set Host FQ Enable to %x.(factor to %d)\n", __func__,
				pAd->fq_ctrl.enable, pAd->fq_ctrl.factor));
		} else
			return FALSE;
	} else
		return FALSE;

	return TRUE;
}
INT show_fq_info(PRTMP_ADAPTER pAd, RTMP_STRING *arg)
{
	RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
	INT i, nSTA = ((pAd->red_sta_num == 0) ? 32 : pAd->red_sta_num);
	STA_TR_ENTRY *tr_entry = NULL;
	struct fq_stainfo_type *pfq_sta = NULL;

	for (i = 1; i <= nSTA; i++) {
		tr_entry = &pAd->MacTab.tr_entry[i];
		pfq_sta = &tr_entry->fq_sta_rec;
		MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("wcid%d KMAX=%d macQPktLen[1]=%d\n",
			i, pfq_sta->KMAX, pfq_sta->macQPktLen[1]));
		pfq_sta->KMAX = 0;
	}
	for (i = 0; i < WMM_NUM_OF_AC; i++) {
		pAd->fq_ctrl.prev_wcid[i] = -1;
		pAd->fq_ctrl.prev_kick_cnt[i] = 0;
	}
	pAd->fq_ctrl.prev_qidx = -1;

	if (!pAd->fq_ctrl.enable) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("FQ was is Disabled (qm=%d)\n", cap->qm));
		return TRUE;
	}
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("FQ was Enabled [%x] qm=%d (STA=%d,%d)\n",
		pAd->fq_ctrl.enable, cap->qm, pAd->fq_ctrl.nactive, pAd->red_in_use_sta));

	for (i = 0; i < WMM_NUM_OF_AC; i++) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("FQAC%d's frm_cnt=%d.\n", i, pAd->fq_ctrl.frm_cnt[i]));
	}

	return TRUE;
}

INT set_fq_debug_enable(PRTMP_ADAPTER pAd, RTMP_STRING *arg)
{
	UINT32 en, rv;

	if (arg) {
		rv = sscanf(arg, "%d", &en);

		if ((rv > 0) && (en <= FQ_DBG_MASK)) {
			pAd->fq_ctrl.dbg_en = en;
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s: set FQ Debug Message Enable to %d.\n", __func__, pAd->fq_ctrl.dbg_en));
		} else
			return FALSE;
	} else
		return FALSE;

	return TRUE;
}

VOID app_show_fq_dbgmsg(RTMP_ADAPTER *pAd)
{
	UINT_8 wcid, ac_idx, idx;
	INT pos = 0;
	char buf[MAX_LEN_OF_MAC_TABLE*2];
	ULONG IrqFlags = 0;
	STA_TR_ENTRY *tr_entry = NULL;
	struct fq_stainfo_type *pfq_sta = NULL;
	QUEUE_ENTRY *pEntry = NULL;

	/* Show Debug Message by cmd */
	if (pAd->fq_ctrl.dbg_en&FQ_DBG_DUMP_FQLIST) {
		for (ac_idx = WMM_AC_BE; ac_idx <= WMM_AC_BE; ac_idx++) {
			RTMP_IRQ_LOCK(&pAd->tx_swq_lock[ac_idx], IrqFlags);
			os_zero_mem(buf, MAX_LEN_OF_MAC_TABLE*2);
			pEntry = pAd->fq_ctrl.fq[ac_idx].Head;
			pos = 0;
			pos = sprintf(buf+pos, "FQ[%d]={", ac_idx);
			idx = 0;
			while (pAd->fq_ctrl.fq[ac_idx].Number > 0) {
				if (pEntry == NULL) {
					pos += sprintf(buf+pos, "Empty");
					break;
				}
				pfq_sta = container_of(pEntry, struct fq_stainfo_type, Entry[ac_idx]);
				if (idx == 0)
					pos += sprintf(buf+pos, "%d", pfq_sta->wcid);
				else if ((idx % 16) == 0)
					pos += sprintf(buf+pos, ",%d\n", pfq_sta->wcid);
				else
					pos += sprintf(buf+pos, ",%d", pfq_sta->wcid);
				idx++;
				pEntry = pEntry->Next;
				if (pEntry == NULL)
					break;
			}
			if (idx > 0)
				MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("%s},frm:%d\n", buf, pAd->fq_ctrl.frm_cnt[ac_idx]));
			RTMP_IRQ_UNLOCK(&pAd->tx_swq_lock[ac_idx], IrqFlags);
		}
	}

	for (wcid = 1; wcid < MAX_LEN_OF_MAC_TABLE-1; wcid++) {
		tr_entry = &pAd->MacTab.tr_entry[wcid];
		pfq_sta = &tr_entry->fq_sta_rec;
		for (ac_idx = WMM_AC_BK; ac_idx <= WMM_AC_VO; ac_idx++) {
			if ((pAd->fq_ctrl.dbg_en&FQ_DBG_DUMP_STA_LOG) && (pfq_sta->macQPktLen[ac_idx] > 64)) {
				if (pAd->fq_ctrl.enable&FQ_READY) {
					MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF,
						("STA%d[AC%d]thMax:%d macQLen:%d macQPktLen:%d kPkt:%d, KMax:%d,txqnum:%d,mpduTime:%d,S=%d, [0x%08X] msdu_cnt=%d\n",
						wcid, ac_idx, pfq_sta->thMax[ac_idx], pfq_sta->macQLen[ac_idx], pfq_sta->macQPktLen[ac_idx],
						pfq_sta->kickPktCnt[ac_idx], pfq_sta->KMAX, tr_entry->tx_queue[ac_idx].Number,
						pfq_sta->mpduTime, pfq_sta->status[ac_idx], pAd->fq_ctrl.list_map[ac_idx][0], pfq_sta->tx_msdu_cnt));
					RTMP_SEM_LOCK(&pfq_sta->lock[ac_idx]);
					pfq_sta->KMAX = 0;
					RTMP_SEM_UNLOCK(&pfq_sta->lock[ac_idx]);
				}
			}
		}
	}

}

struct qm_ops ge_fair_qm_ops = { 0 };
#else
struct qm_ops ge_fair_qm_ops = {
	.init = NULL,
	.exit = NULL,
};
#endif /* FQ_SCH_SUPPORT */
