/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	hif_usb.c
*/

#ifdef RTMP_MAC_USB

#include	"rt_config.h"

#define MCAST_WCID_TO_REMOVE 0 /* Pat: TODO */

NDIS_STATUS RTUSBFreeDescriptorRelease(RTMP_ADAPTER *pAd, UCHAR BulkOutPipeId)
{
	HT_TX_CONTEXT *pHTTXContext;
	unsigned long IrqFlags;
	pHTTXContext = &pAd->TxContext[BulkOutPipeId];
	RTMP_IRQ_LOCK(&pAd->TxContextQueueLock[BulkOutPipeId], IrqFlags);
	pHTTXContext->bCurWriting = FALSE;
	RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[BulkOutPipeId], IrqFlags);
	return NDIS_STATUS_SUCCESS;
}


/*
	========================================================================

	Routine	Description:
		This subroutine will scan through releative ring descriptor to find
		out avaliable free ring descriptor and compare with request size.

	Arguments:
		pAd	Pointer	to our adapter
		RingType	Selected Ring

	Return Value:
		NDIS_STATUS_FAILURE		Not enough free descriptor
		NDIS_STATUS_SUCCESS		Enough free descriptor

	Note:

	========================================================================
*/
NDIS_STATUS	RTUSBFreeDescRequest(
	IN RTMP_ADAPTER *pAd,
	IN UCHAR BulkOutPipeId,
	IN UINT32 req_cnt)
{
	NDIS_STATUS	 Status = NDIS_STATUS_FAILURE;
	unsigned long IrqFlags;
	HT_TX_CONTEXT *pHTTXContext;
#ifdef MULTI_WMM_SUPPORT

	if (BulkOutPipeId >= EDCA_WMM1_AC0_PIPE) {
		BulkOutPipeId -= EDCA_WMM1_AC0_PIPE;
		pHTTXContext = &pAd->TxContextWmm1[BulkOutPipeId];
		RTMP_IRQ_LOCK(&pAd->TxContextQueueWmm1Lock[BulkOutPipeId], IrqFlags);

		if ((pHTTXContext->CurWritePosition < pHTTXContext->NextBulkOutPosition) && ((pHTTXContext->CurWritePosition + req_cnt + LOCAL_TXBUF_SIZE) > pHTTXContext->NextBulkOutPosition)) {
#ifdef RELEASE_EXCLUDE
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_INFO, ("RTUSBFreeD c1 --> QueIdx=%d, CWPos=%ld, NBOutPos=%ld!\n",
					 BulkOutPipeId, pHTTXContext->CurWritePosition, pHTTXContext->NextBulkOutPosition));
#endif /* RELEASE_EXCLUDE */
			RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_WMM1_NORMAL << BulkOutPipeId));
		} else if ((pHTTXContext->CurWritePosition == 8) && (pHTTXContext->NextBulkOutPosition < (req_cnt + LOCAL_TXBUF_SIZE))) {
#ifdef RELEASE_EXCLUDE
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_INFO, ("RTUSBFreeD c2 --> QueIdx=%d, CWPos=%ld, NBOutPos=%ld!\n",
					 BulkOutPipeId, pHTTXContext->CurWritePosition, pHTTXContext->NextBulkOutPosition));
#endif /* RELEASE_EXCLUDE */
			RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_WMM1_NORMAL << BulkOutPipeId));
		} else if (pHTTXContext->bCurWriting == TRUE) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("RTUSBFreeD c3 --> QueIdx=%d, CWPos=%ld, NBOutPos=%ld!\n", BulkOutPipeId, pHTTXContext->CurWritePosition, pHTTXContext->NextBulkOutPosition));
			RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_WMM1_NORMAL << BulkOutPipeId));
		} else
			Status = NDIS_STATUS_SUCCESS;

		RTMP_IRQ_UNLOCK(&pAd->TxContextQueueWmm1Lock[BulkOutPipeId], IrqFlags);
	} else
#endif /* MULTI_WMM_SUPPORT */
	{
		pHTTXContext = &pAd->TxContext[BulkOutPipeId];
		RTMP_IRQ_LOCK(&pAd->TxContextQueueLock[BulkOutPipeId], IrqFlags);
#ifdef USB_BULK_BUF_ALIGMENT

		if (((pHTTXContext->CurWriteIdx < pHTTXContext->NextBulkIdx) &&   (pHTTXContext->NextBulkIdx - pHTTXContext->CurWriteIdx == 1))
			 || ((pHTTXContext->CurWriteIdx == (BUF_ALIGMENT_RINGSIZE - 1)) &&  (pHTTXContext->NextBulkIdx == 0)))
			RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << BulkOutPipeId));
		else if (pHTTXContext->bCurWriting == TRUE) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("BUF_ALIGMENT RTUSBFreeD c3 --> QueIdx=%d, CWPos=%ld, NBOutPos=%ld!\n", BulkOutPipeId, pHTTXContext->CurWritePosition, pHTTXContext->NextBulkOutPosition));
			RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << BulkOutPipeId));
		}

#else

		if ((pHTTXContext->CurWritePosition < pHTTXContext->NextBulkOutPosition) && ((pHTTXContext->CurWritePosition + req_cnt + LOCAL_TXBUF_SIZE) > pHTTXContext->NextBulkOutPosition)) {
#ifdef RELEASE_EXCLUDE
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_INFO, ("RTUSBFreeD c1 --> QueIdx=%d, CWPos=%ld, NBOutPos=%ld!\n",
					 BulkOutPipeId, pHTTXContext->CurWritePosition, pHTTXContext->NextBulkOutPosition));
#endif /* RELEASE_EXCLUDE */
			RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << BulkOutPipeId));
		} else if ((pHTTXContext->CurWritePosition == 8) && (pHTTXContext->NextBulkOutPosition < (req_cnt + LOCAL_TXBUF_SIZE))) {
#ifdef RELEASE_EXCLUDE
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_INFO, ("RTUSBFreeD c2 --> QueIdx=%d, CWPos=%ld, NBOutPos=%ld!\n",
					 BulkOutPipeId, pHTTXContext->CurWritePosition, pHTTXContext->NextBulkOutPosition));
#endif /* RELEASE_EXCLUDE */
			RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << BulkOutPipeId));
		} else if (pHTTXContext->bCurWriting == TRUE) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("RTUSBFreeD c3 --> QueIdx=%d, CWPos=%ld, NBOutPos=%ld!\n", BulkOutPipeId, pHTTXContext->CurWritePosition, pHTTXContext->NextBulkOutPosition));
			RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << BulkOutPipeId));
		}

#endif /* USB_BULK_BUF_ALIGMENT */
		else
			Status = NDIS_STATUS_SUCCESS;

		RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[BulkOutPipeId], IrqFlags);
	}

	return Status;
}


BOOLEAN	RTUSBNeedQueueBackForAgg(RTMP_ADAPTER *pAd, UCHAR BulkOutPipeId)
{
	HT_TX_CONTEXT *pHTTXContext;
	BOOLEAN needQueBack = FALSE;
	unsigned long   IrqFlags;
	pHTTXContext = &pAd->TxContext[BulkOutPipeId];
	RTMP_IRQ_LOCK(&pAd->TxContextQueueLock[BulkOutPipeId], IrqFlags);

	if ((pHTTXContext->IRPPending == TRUE)  /*&& (pAd->TxSwQueue[BulkOutPipeId].Number == 0) */) {
#if 0

		if ((pHTTXContext->CurWritePosition <= 8) &&
			(pHTTXContext->NextBulkOutPosition > 8 && (pHTTXContext->NextBulkOutPosition + MAX_AGGREGATION_SIZE) < MAX_TXBULK_LIMIT))
			needQueBack = TRUE;
		else if ((pHTTXContext->CurWritePosition < pHTTXContext->NextBulkOutPosition) &&
				 ((pHTTXContext->NextBulkOutPosition + MAX_AGGREGATION_SIZE) < MAX_TXBULK_LIMIT))
			needQueBack = TRUE;

#else

		if ((pHTTXContext->CurWritePosition < pHTTXContext->ENextBulkOutPosition) &&
			(((pHTTXContext->ENextBulkOutPosition + MAX_AGGREGATION_SIZE) < MAX_TXBULK_LIMIT) || (pHTTXContext->CurWritePosition > MAX_AGGREGATION_SIZE)))
			needQueBack = TRUE;

#endif
		else if ((pHTTXContext->CurWritePosition > pHTTXContext->ENextBulkOutPosition) &&
				 ((pHTTXContext->ENextBulkOutPosition + MAX_AGGREGATION_SIZE) < pHTTXContext->CurWritePosition))
			needQueBack = TRUE;
	}

	RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[BulkOutPipeId], IrqFlags);
	return needQueBack;
}


VOID ComposePsPoll(
	IN	RTMP_ADAPTER *pAd,
	IN	PPSPOLL_FRAME pPsPollFrame,
	IN	USHORT	Aid,
	IN	UCHAR *pBssid,
	IN	UCHAR *pTa)
{
#ifdef CONFIG_STA_SUPPORT
	UCHAR *buf;
	USHORT data_len;
	MAC_TX_INFO mac_info;
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
	UINT tx_hw_hdr_len = cap->tx_hw_hdr_len;
	PSTA_ADMIN_CONFIG pStaCfg = NULL;
	struct wifi_dev *wdev = NULL;
#ifdef MT_MAC
	UCHAR *tmac_info;
	TMAC_TXD_L *pTxD = NULL;
#endif /* MT_MAC */
	MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("ComposePsPoll\n"));
	/*
		Wireless client doesn't need to send ps-poll
		if client is not in power saving mode.
	*/
	NdisZeroMemory(pPsPollFrame, sizeof(PSPOLL_FRAME));
	pPsPollFrame->FC.Type = FC_TYPE_CNTL;
	pPsPollFrame->FC.SubType = SUBTYPE_PS_POLL;
	pPsPollFrame->Aid = Aid | 0xC000;
	COPY_MAC_ADDR(pPsPollFrame->Bssid, pBssid);
	COPY_MAC_ADDR(pPsPollFrame->Ta, pTa);
	buf = &pAd->PsPollContext.TransferBuffer->field.WirelessPacket[0];
	RTMPZeroMemory(buf, 100);
	data_len = sizeof(PSPOLL_FRAME);
	NdisZeroMemory((UCHAR *)&mac_info, sizeof(mac_info));
#ifdef MT_MAC
	tmac_info = &buf[0];
	mac_info.hdr_len = data_len;
#endif
	wdev = wdev_search_by_address(pAd, pPsPollFrame->Ta);
	pStaCfg = GetStaCfgByWdev(pAd, wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	if (pAd->CommonCfg.bAPSDForcePowerSave)
		pPsPollFrame->FC.PwrMgmt = PWR_SAVE;
	else
		pPsPollFrame->FC.PwrMgmt = (RtmpPktPmBitCheck(pAd, pStaCfg) == TRUE);

	mac_info.FRAG = FALSE;
	mac_info.CFACK = FALSE;
	mac_info.InsTimestamp = FALSE;
	mac_info.AMPDU = FALSE;
	mac_info.BM = 0;
	mac_info.Ack = TRUE;
	mac_info.NSeq = FALSE;
	mac_info.BASize = 0;
	{
		MAC_TABLE_ENTRY *pEntry = MacTableLookup(pAd, pBssid);
		mac_info.WCID = pEntry->wcid;
	}
	mac_info.Length = data_len;
	mac_info.PID = 0;
	mac_info.TID = 0;
	mac_info.TxRate = (UCHAR) wdev->rate.MlmeTransmit.field.MCS;
	mac_info.Txopmode = IFS_BACKOFF;
	mac_info.Preamble = LONG_PREAMBLE;
	mac_info.IsAutoRate = FALSE;
	mac_info.SpeEn = 1;
#ifdef MT_MAC

	if (IS_HIF_TYPE(pAd, HIF_MT)) {
		mac_info.q_idx = Q_IDX_AC0;
		/* For  MT STA LP control, use H/W control mode for PM bit */
#if defined(CONFIG_STA_SUPPORT) && defined(CONFIG_PM_BIT_HW_MODE)
		mac_info.PsmBySw = 0;
#else
		mac_info.PsmBySw = 1;
#endif /* CONFIG_STA_SUPPORT && CONFIG_PM_BIT_HW_MODE */

		if (!wdev)
			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_INFO, ("%s():Err!! wdev is NULL!!\n", __func__));
		else
			mac_info.OmacIdx = wdev->OmacIdx;
	}

#endif /* MT_MAC */
#ifdef MT_MAC

	if (IS_HIF_TYPE(pAd, HIF_MT)) {
		pAd->archOps.write_tmac_info_fixed_rate(pAd, (UCHAR *)tmac_info, &mac_info, &wdev->rate.MlmeTransmit);
		/*This frame is PS-POLL, duration filed is replace by AID, and duration=1 means H/W won't overwtite this field */
		pTxD = (TMAC_TXD_L *)tmac_info;
		pTxD->TxD2.Duration = 1;
		RTMPMoveMemory((VOID *)&buf[tx_hw_hdr_len], (VOID *)pPsPollFrame, data_len);
		/* Append 4 extra zero bytes. */
		pAd->PsPollContext.BulkOutSize = tx_hw_hdr_len + data_len + 4;
		pAd->PsPollContext.BulkOutSize = (pAd->PsPollContext.BulkOutSize + 3) & (~3);
	}

#endif /* MT_MAC */
	MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("ComposePsPoll, size(%d), OmacIdx(%d)\n", data_len, mac_info.OmacIdx));
#endif /* CONFIG_STA_SUPPORT */
}


#ifdef MULTI_WMM_SUPPORT
static inline NDIS_STATUS RtmpUSBWmm1CanDoWrite(
	IN RTMP_ADAPTER *pAd,
	IN UCHAR QueIdx,
	IN HT_TX_CONTEXT *pHTTXContext)
{
	NDIS_STATUS	canWrite = NDIS_STATUS_RESOURCES;

	if (((pHTTXContext->CurWritePosition) < pHTTXContext->NextBulkOutPosition) && (pHTTXContext->CurWritePosition + LOCAL_TXBUF_SIZE) > pHTTXContext->NextBulkOutPosition) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite c1!\n"));
		RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_WMM1_NORMAL << QueIdx));
	} else if ((pHTTXContext->CurWritePosition == 8) && (pHTTXContext->NextBulkOutPosition < LOCAL_TXBUF_SIZE)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite c2!\n"));
		RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_WMM1_NORMAL << QueIdx));
	} else if (pHTTXContext->bCurWriting == TRUE)
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite c3!\n"));
	else if ((pHTTXContext->ENextBulkOutPosition == 8)  && ((pHTTXContext->CurWritePosition + 7912) > MAX_TXBULK_LIMIT)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite c4!\n"));
		RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_WMM1_NORMAL << QueIdx));
	} else
		canWrite = NDIS_STATUS_SUCCESS;

	return canWrite;
}
#endif /* MULTI_WMM_SUPPORT */

/*
	We can do copy the frame into pTxContext when match following conditions.
		=>
		=>
		=>
*/
static inline NDIS_STATUS RtmpUSBCanDoWrite(
	IN RTMP_ADAPTER *pAd,
	IN UCHAR QueIdx,
	IN HT_TX_CONTEXT *pHTTXContext)
{
	NDIS_STATUS	canWrite = NDIS_STATUS_RESOURCES;
#ifdef USB_BULK_BUF_ALIGMENT

	if (((pHTTXContext->CurWriteIdx < pHTTXContext->NextBulkIdx) &&   (pHTTXContext->NextBulkIdx - pHTTXContext->CurWriteIdx == 1))
		 || ((pHTTXContext->CurWriteIdx == (BUF_ALIGMENT_RINGSIZE - 1)) &&  (pHTTXContext->NextBulkIdx == 0))) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite USB_BULK_BUF_ALIGMENT c1!\n"));
		RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << QueIdx));
	} else if (pHTTXContext->bCurWriting == TRUE)
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite USB_BULK_BUF_ALIGMENT c3!!\n"));

#else

	if (((pHTTXContext->CurWritePosition) < pHTTXContext->NextBulkOutPosition) && (pHTTXContext->CurWritePosition + LOCAL_TXBUF_SIZE) > pHTTXContext->NextBulkOutPosition) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite c1!\n"));
		RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << QueIdx));
	} else if ((pHTTXContext->CurWritePosition == 8) && (pHTTXContext->NextBulkOutPosition < LOCAL_TXBUF_SIZE)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite c2!\n"));
		RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << QueIdx));
	} else if (pHTTXContext->bCurWriting == TRUE)
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite c3!\n"));
	else if ((pHTTXContext->ENextBulkOutPosition == 8)  && ((pHTTXContext->CurWritePosition + 7912) > MAX_TXBULK_LIMIT)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RtmpUSBCanDoWrite c4!\n"));
		RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << QueIdx));
	}

#endif /* USB_BULK_BUF_ALIGMENT */
	else
		canWrite = NDIS_STATUS_SUCCESS;

	return canWrite;
}


USHORT RtmpUSB_WriteSubTxResource(
	IN RTMP_ADAPTER *pAd,
	IN TX_BLK * pTxBlk,
	IN BOOLEAN bIsLast,
	OUT	USHORT *freeCnt)
{
	/* Dummy function. Should be removed in the future.*/
	return 0;
}

UINT32 usb_get_tx_resource_free_num(RTMP_ADAPTER *pAd, UINT8 que_idx)
{
	/* FIXME: need to return URB avaiable numbers */
	return 1;
}

USHORT usb_write_frag_tx_resource(
	RTMP_ADAPTER *pAd,
	TX_BLK *pTxBlk,
	UCHAR fragNum,
	USHORT *freeCnt)
{
	NDIS_STATUS		Status = NDIS_STATUS_SUCCESS;
#ifndef MT_MAC
	HT_TX_CONTEXT	*pHTTXContext;
	USHORT			hwHdrLen;	/* The hwHdrLen consist of 802.11 header length plus the header padding length.*/
	UINT32			fillOffset;
	TXINFO_STRUC	*pTxInfo;
	TXWI_STRUC		*pTxWI;
	PUCHAR			pWirelessPacket = NULL;
	UCHAR			QueIdx;
	unsigned long	IrqFlags;
	UINT32			USBDMApktLen = 0, DMAHdrLen, padding;
#ifdef USB_BULK_BUF_ALIGMENT
	BOOLEAN			bLasAlignmentsectiontRound = FALSE;
#else
	BOOLEAN			TxQLastRound = FALSE;
#endif /* USB_BULK_BUF_ALIGMENT */
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
	UINT8 TXWISize = cap->TXWISize;
	/* get Tx Ring Resource & Dma Buffer address*/
	QueIdx = pTxBlk->QueIdx;
	pHTTXContext  = &pAd->TxContext[QueIdx];
	RTMP_IRQ_LOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
	pHTTXContext  = &pAd->TxContext[QueIdx];
	fillOffset = pHTTXContext->CurWritePosition;

	if (fragNum == 0) {
		/* Check if we have enough space for this bulk-out batch.*/
		Status = RtmpUSBCanDoWrite(pAd, QueIdx, pHTTXContext);

		if (Status == NDIS_STATUS_SUCCESS) {
			pHTTXContext->bCurWriting = TRUE;
#ifndef USB_BULK_BUF_ALIGMENT

			/* Reserve space for 8 bytes padding.*/
			if ((pHTTXContext->ENextBulkOutPosition == pHTTXContext->CurWritePosition)) {
				pHTTXContext->ENextBulkOutPosition += 8;
				pHTTXContext->CurWritePosition += 8;
				fillOffset += 8;
			}

#endif /* USB_BULK_BUF_ALIGMENT */
			pTxBlk->Priv = 0;
			pHTTXContext->CurWriteRealPos = pHTTXContext->CurWritePosition;
		} else {
			RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
			RELEASE_NDIS_PACKET(pAd, pTxBlk->pPacket, NDIS_STATUS_FAILURE);
			return Status;
		}
	} else {
		/* For sub-sequent frames of this bulk-out batch. Just copy it to our bulk-out buffer.*/
		Status = ((pHTTXContext->bCurWriting == TRUE) ? NDIS_STATUS_SUCCESS : NDIS_STATUS_FAILURE);

		if (Status == NDIS_STATUS_SUCCESS)
			fillOffset += pTxBlk->Priv;
		else {
			RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
			RELEASE_NDIS_PACKET(pAd, pTxBlk->pPacket, NDIS_STATUS_FAILURE);
			return Status;
		}
	}

	NdisZeroMemory((PUCHAR)(&pTxBlk->HeaderBuf[0]), TXINFO_SIZE);
	pTxInfo = (TXINFO_STRUC *)(&pTxBlk->HeaderBuf[0]);
	pTxWI = (TXWI_STRUC *)(&pTxBlk->HeaderBuf[TXINFO_SIZE]);
	pWirelessPacket = &pHTTXContext->TransferBuffer->field.WirelessPacket[fillOffset];
	/* copy TXWI + WLAN Header + LLC into DMA Header Buffer*/
	/*hwHdrLen = ROUND_UP(pTxBlk->MpduHeaderLen, 4);*/
	hwHdrLen = pTxBlk->MpduHeaderLen + pTxBlk->HdrPadLen;
	/* Build our URB for USBD*/
	DMAHdrLen = TXWISize + hwHdrLen;
	USBDMApktLen = DMAHdrLen + pTxBlk->SrcBufLen;
	padding = (4 - (USBDMApktLen % 4)) & 0x03;	/* round up to 4 byte alignment*/
	USBDMApktLen += padding;
	pTxBlk->Priv += (TXINFO_SIZE + USBDMApktLen);
	/* For TxInfo, the length of USBDMApktLen = TXWI_SIZE + 802.11 header + payload*/
	rlt_usb_write_txinfo(pAd, pTxInfo, (USHORT)(USBDMApktLen), FALSE, FIFO_EDCA, FALSE /*NextValid*/,  FALSE);

	if (fragNum == pTxBlk->TotalFragNum) {
		pTxInfo->TxInfoUDMATxburst = 0;
#ifdef USB_BULK_BUF_ALIGMENT
		/*
			when CurWritePosition > 0x6000  mean that it is at the max bulk out  size,
			we CurWriteIdx must move to the next alignment section.
			Otherwirse,  CurWriteIdx will be moved to the next section at databulkout.


			(((pHTTXContext->CurWritePosition + 3906)& 0x00007fff) & 0xffff6000) == 0x00006000)
			we must make sure that the last fragNun packet just over the 0x6000
			otherwise it will error because the last frag packet will at the section but will not bulk out.
			ex:   when secoend packet writeresouce and it > 0x6000
				And the last packet writesource and it also > 0x6000  at this time CurWriteIdx++
				but when data bulk out , because at second packet it will > 0x6000 , the last packet will not bulk out.

		*/

		if (((pHTTXContext->CurWritePosition + 3906)  & 0x00006000) == 0x00006000) {
			bLasAlignmentsectiontRound = TRUE;
			pTxInfo->bFragLasAlignmentsectiontRound = 1;
		}

#else

		if ((pHTTXContext->CurWritePosition + pTxBlk->Priv + 3906) > MAX_TXBULK_LIMIT) {
			pTxInfo->TxInfoSwLstRnd = 1;
			TxQLastRound = TRUE;
		}

#endif /* USB_BULK_BUF_ALIGMENT */
	} else
		pTxInfo->TxInfoUDMATxburst = 1;

	NdisMoveMemory(pWirelessPacket, pTxBlk->HeaderBuf, TXINFO_SIZE + TXWISize + hwHdrLen);
#ifdef RT_BIG_ENDIAN
	RTMPFrameEndianChange(pAd, (PUCHAR)(pWirelessPacket + TXINFO_SIZE + TXWISize), DIR_WRITE, FALSE);
#endif /* RT_BIG_ENDIAN */
	pWirelessPacket += (TXINFO_SIZE + TXWISize + hwHdrLen);
	pHTTXContext->CurWriteRealPos += (TXINFO_SIZE + TXWISize + hwHdrLen);
	RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
	NdisMoveMemory(pWirelessPacket, pTxBlk->pSrcBufData, pTxBlk->SrcBufLen);
	/*	Zero the last padding.*/
	pWirelessPacket += pTxBlk->SrcBufLen;
	NdisZeroMemory(pWirelessPacket, padding + 8);

	if (fragNum == pTxBlk->TotalFragNum) {
		RTMP_IRQ_LOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
		/* Update the pHTTXContext->CurWritePosition. 3906 used to prevent the NextBulkOut is a A-RALINK/A-MSDU Frame.*/
		pHTTXContext->CurWritePosition += pTxBlk->Priv;
#ifndef USB_BULK_BUF_ALIGMENT

		if (TxQLastRound == TRUE)
			pHTTXContext->CurWritePosition = 8;

#endif /* USB_BULK_BUF_ALIGMENT */
#ifdef USB_BULK_BUF_ALIGMENT

		if (bLasAlignmentsectiontRound == TRUE)
			pHTTXContext->CurWritePosition = ((CUR_WRITE_IDX_INC(pHTTXContext->CurWriteIdx, BUF_ALIGMENT_RINGSIZE)) * 0x8000);

#endif /* USB_BULK_BUF_ALIGMENT */
		pHTTXContext->CurWriteRealPos = pHTTXContext->CurWritePosition;
#ifdef UAPSD_SUPPORT
#if defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT)
		UAPSD_TagFrame(pAd, pTxBlk->pPacket, pTxBlk->Wcid, pHTTXContext->CurWritePosition);
#else
#ifdef CONFIG_AP_SUPPORT
#ifdef P2P_SUPPORT

		if (P2P_GO_ON(pAd))
#else
#ifdef RT_CFG80211_P2P_SUPPORT
		if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd))
#else /* RT_CFG80211_P2P_SUPPORT */
		IF_DEV_CONFIG_OPMODE_ON_AP(pAd)
#endif /* !RT_CFG80211_P2P_SUPPORT */
#endif /* P2P_SUPPORT */
		{
			UAPSD_TagFrame(pAd, pTxBlk->pPacket, pTxBlk->Wcid, pHTTXContext->CurWritePosition);
		}

#endif /* CONFIG_AP_SUPPORT */
#endif /* defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT) */
#endif /* UAPSD_SUPPORT */
		/* Finally, set bCurWriting as FALSE*/
		pHTTXContext->bCurWriting = FALSE;
		RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
		/* succeed and release the skb buffer*/
		RELEASE_NDIS_PACKET(pAd, pTxBlk->pPacket, NDIS_STATUS_SUCCESS);
	}

#endif
	return Status;
}


USHORT usb_write_tx_resource(
	IN RTMP_ADAPTER *pAd,
	IN TX_BLK *pTxBlk,
	IN BOOLEAN bIsLast,
	OUT	USHORT *freeCnt)
{
	HT_TX_CONTEXT *pHTTXContext;
	UINT32 fillOffset;
	TXINFO_STRUC *pTxInfo;
	TXWI_STRUC *pTxWI;
	UCHAR *pWirelessPacket, *buf;
	UCHAR QueIdx;
	unsigned long	IrqFlags;
	NDIS_STATUS Status;
	UINT32 hdr_copy_len, hdr_len, dma_len = 0, padding;
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
#ifndef USB_BULK_BUF_ALIGMENT
	BOOLEAN bTxQLastRound = FALSE;
#endif /* USB_BULK_BUF_ALIGMENT */
	UINT8 TXWISize;
	/* get Tx Ring Resource & Dma Buffer address*/
	QueIdx = pTxBlk->QueIdx;
	TXWISize = cap->TXWISize;
#ifdef MULTI_WMM_SUPPORT

	if (pTxBlk->QueIdx >= EDCA_WMM1_AC0_PIPE) {
		QueIdx -= EDCA_WMM1_AC0_PIPE;
		RTMP_IRQ_LOCK(&pAd->TxContextQueueWmm1Lock[QueIdx], IrqFlags);
		pHTTXContext  = &pAd->TxContextWmm1[QueIdx];
		fillOffset = pHTTXContext->CurWritePosition;
#ifdef RELEASE_EXCLUDE
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_LOUD, ("WS-B:I=0x%lx, CWPos=%ld, NBPos=%ld, ENBPos=%ld\n",
				 in_interrupt(), pHTTXContext->CurWritePosition,
				 pHTTXContext->NextBulkOutPosition,
				 pHTTXContext->ENextBulkOutPosition));
#endif /* RELEASE_EXCLUDE */
		/* Check ring full */
		Status = RtmpUSBWmm1CanDoWrite(pAd, QueIdx, pHTTXContext);

		if (Status == NDIS_STATUS_SUCCESS) {
			pHTTXContext->bCurWriting = TRUE;
			buf = &pTxBlk->HeaderBuf[0];
			pTxInfo = (TXINFO_STRUC *)buf;
			pTxWI = (TXWI_STRUC *)&buf[TXINFO_SIZE];
#ifndef USB_BULK_BUF_ALIGMENT

			/* Reserve space for 8 bytes padding.*/
			if ((pHTTXContext->ENextBulkOutPosition == pHTTXContext->CurWritePosition)) {
				pHTTXContext->ENextBulkOutPosition += 8;
				pHTTXContext->CurWritePosition += 8;
				fillOffset += 8;
			}

#endif /* USB_BULK_BUF_ALIGMENT */
			pHTTXContext->CurWriteRealPos = pHTTXContext->CurWritePosition;
			pWirelessPacket = &pHTTXContext->TransferBuffer->field.WirelessPacket[fillOffset];
			/* Build our URB for USBD */
#ifdef MT_MAC
			hdr_len = pTxBlk->MpduHeaderLen + pTxBlk->HdrPadLen;

			if (pTxBlk->hw_rsv_len == 0) /* Long */
				hdr_copy_len = sizeof(TMAC_TXD_L) + hdr_len;
			else { /* Short */
				hdr_copy_len = sizeof(TMAC_TXD_S) + hdr_len;
				pTxBlk->HeaderBuf += pTxBlk->hw_rsv_len;
			}

			dma_len = hdr_copy_len + pTxBlk->SrcBufLen;
#else
			hdr_len = TXWISize + TSO_SIZE + pTxBlk->MpduHeaderLen + pTxBlk->HdrPadLen;
			hdr_copy_len = TXINFO_SIZE + hdr_len;
			dma_len = hdr_len + pTxBlk->SrcBufLen;
#endif /* MT_MAC */
			padding = (4 - (dma_len % 4)) & 0x03;	/* round up to 4 byte alignment*/
			dma_len += padding;
#ifdef MT_MAC
			pTxBlk->Priv = (dma_len);
#else
			pTxBlk->Priv = (TXINFO_SIZE + dma_len);
#endif /* MT_MAC */
			/* For TxInfo, the length of USBDMApktLen = TXWI_SIZE + TSO_SIZE + 802.11 header + payload */
#ifndef USB_BULK_BUF_ALIGMENT

			if ((pHTTXContext->CurWritePosition + 3906 + pTxBlk->Priv) > MAX_TXBULK_LIMIT) {
#ifdef MT_MAC
				TMAC_TXD_L *txd_l = (TMAC_TXD_L *)pTxBlk->HeaderBuf;
				TMAC_TXD_S *txd_s = (TMAC_TXD_S *)pTxBlk->HeaderBuf;
				TMAC_TXD_1 *txd_1 = &txd_s->TxD1;
				TMAC_TXD_7 *txd_7;

				if (txd_1->TxDFmt == TMI_FT_SHORT)
					txd_7 = &txd_s->TxD7;
				else
					txd_7 = &txd_l->TxD7;

				txd_7->SwUseSegmentEnd = 1;
#else
				pTxInfo->TxInfoSwLstRnd = 1;
#endif	/* MT_MAC */
				bTxQLastRound = TRUE;
			}

#endif /* USB_BULK_BUF_ALIGMENT */
			NdisMoveMemory(pWirelessPacket, pTxBlk->HeaderBuf, hdr_copy_len);
#ifdef RT_BIG_ENDIAN
			RTMPFrameEndianChange(pAd, (PUCHAR)(pWirelessPacket + TXINFO_SIZE + TXWISize + TSO_SIZE), DIR_WRITE, FALSE);
#endif /* RT_BIG_ENDIAN */
			pWirelessPacket += (hdr_copy_len);
			/* We unlock it here to prevent the first 8 bytes maybe over-writed issue.*/
			/*	1. First we got CurWritePosition but the first 8 bytes still not write to the pTxcontext.*/
			/*	2. An interrupt break our routine and handle bulk-out complete.*/
			/*	3. In the bulk-out compllete, it need to do another bulk-out, */
			/*			if the ENextBulkOutPosition is just the same as CurWritePosition, it will save the first 8 bytes from CurWritePosition,*/
			/*			but the payload still not copyed. the pTxContext->SavedPad[] will save as allzero. and set the bCopyPad = TRUE.*/
			/*	4. Interrupt complete.*/
			/*  5. Our interrupted routine go back and fill the first 8 bytes to pTxContext.*/
			/*	6. Next time when do bulk-out, it found the bCopyPad==TRUE and will copy the SavedPad[] to pTxContext->NextBulkOutPosition.*/
			/*		and the packet will wrong.*/
			pHTTXContext->CurWriteRealPos += hdr_copy_len;
#ifndef USB_BULK_BUF_ALIGMENT
			RTMP_IRQ_UNLOCK(&pAd->TxContextQueueWmm1Lock[QueIdx], IrqFlags);
#endif /* USB_BULK_BUF_ALIGMENT */
			{
				NdisMoveMemory(pWirelessPacket, pTxBlk->pSrcBufData, pTxBlk->SrcBufLen);
				pWirelessPacket += pTxBlk->SrcBufLen;
			}
#ifndef USB_BULK_BUF_ALIGMENT
			NdisZeroMemory(pWirelessPacket, padding + 8);
			RTMP_IRQ_LOCK(&pAd->TxContextQueueWmm1Lock[QueIdx], IrqFlags);
#endif /* USB_BULK_BUF_ALIGMENT */
			pHTTXContext->CurWritePosition += pTxBlk->Priv;
#ifdef UAPSD_SUPPORT
#if defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT)
			UAPSD_TagFrame(pAd, pTxBlk->pPacket, pTxBlk->Wcid, pHTTXContext->CurWritePosition);
#else
#ifdef CONFIG_AP_SUPPORT
#ifdef P2P_SUPPORT

			if (P2P_GO_ON(pAd))
#else
#ifdef RT_CFG80211_P2P_SUPPORT
			if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd))
#else
			IF_DEV_CONFIG_OPMODE_ON_AP(pAd)
#endif /* RT_CFG80211_P2P_SUPPORT */
#endif /* P2P_SUPPORT */
			{
				UAPSD_TagFrame(pAd, pTxBlk->pPacket, pTxBlk->Wcid, pHTTXContext->CurWritePosition);
			}

#endif /* CONFIG_AP_SUPPORT */
#endif /* defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT) */
#endif /* UAPSD_SUPPORT */
#ifdef USB_BULK_BUF_ALIGMENT

			/*
				when CurWritePosition > 0x6000  mean that it is at the max bulk out size,
				we CurWriteIdx must move to the next alignment section.
				Otherwirse,  CurWriteIdx will be moved to the next section at databulkout.

				Writingflag = TRUE ,mean that when we writing resource ,and databulkout happen,
				So we bulk out when this packet finish.
			*/
			if ((pHTTXContext->CurWritePosition  & 0x00006000) == 0x00006000)
				pHTTXContext->CurWritePosition = ((CUR_WRITE_IDX_INC(pHTTXContext->CurWriteIdx, BUF_ALIGMENT_RINGSIZE)) * 0x8000);

#else

			if (bTxQLastRound)
				pHTTXContext->CurWritePosition = 8;

#endif /* USB_BULK_BUF_ALIGMENT */
			pHTTXContext->CurWriteRealPos = pHTTXContext->CurWritePosition;
			pHTTXContext->bCurWriting = FALSE;
		}

		RTMP_IRQ_UNLOCK(&pAd->TxContextQueueWmm1Lock[QueIdx], IrqFlags);
	} else
#endif /* MULTI_WMM_SUPPORT */
	{
		RTMP_IRQ_LOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
		pHTTXContext  = &pAd->TxContext[QueIdx];
		fillOffset = pHTTXContext->CurWritePosition;
#ifdef RELEASE_EXCLUDE
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_LOUD, ("WS-B:I=0x%lx, CWPos=%ld, NBPos=%ld, ENBPos=%ld\n",
				 in_interrupt(), pHTTXContext->CurWritePosition,
				 pHTTXContext->NextBulkOutPosition,
				 pHTTXContext->ENextBulkOutPosition));
#endif /* RELEASE_EXCLUDE */
		/* Check ring full */
		Status = RtmpUSBCanDoWrite(pAd, QueIdx, pHTTXContext);

		if (Status == NDIS_STATUS_SUCCESS) {
			pHTTXContext->bCurWriting = TRUE;
			buf = &pTxBlk->HeaderBuf[0];
			pTxInfo = (TXINFO_STRUC *)buf;
			pTxWI = (TXWI_STRUC *)&buf[TXINFO_SIZE];
#ifndef USB_BULK_BUF_ALIGMENT

			/* Reserve space for 8 bytes padding.*/
			if ((pHTTXContext->ENextBulkOutPosition == pHTTXContext->CurWritePosition)) {
				pHTTXContext->ENextBulkOutPosition += 8;
				pHTTXContext->CurWritePosition += 8;
				fillOffset += 8;
			}

#endif /* USB_BULK_BUF_ALIGMENT */
			pHTTXContext->CurWriteRealPos = pHTTXContext->CurWritePosition;
			pWirelessPacket = &pHTTXContext->TransferBuffer->field.WirelessPacket[fillOffset];
			/* Build our URB for USBD */
#ifdef MT_MAC
			hdr_len = pTxBlk->MpduHeaderLen + pTxBlk->HdrPadLen;

			if (pTxBlk->hw_rsv_len == 0) /* Long */
				hdr_copy_len = sizeof(TMAC_TXD_L) + hdr_len;
			else { /* Short */
				hdr_copy_len = sizeof(TMAC_TXD_S) + hdr_len;
				pTxBlk->HeaderBuf += pTxBlk->hw_rsv_len;
			}

			dma_len = hdr_copy_len + pTxBlk->SrcBufLen;
#else
			hdr_len = TXWISize + TSO_SIZE + pTxBlk->MpduHeaderLen + pTxBlk->HdrPadLen;
			hdr_copy_len = TXINFO_SIZE + hdr_len;
			dma_len = hdr_len + pTxBlk->SrcBufLen;
#endif /* MT_MAC */
			padding = (4 - (dma_len % 4)) & 0x03;	/* round up to 4 byte alignment*/
			dma_len += padding;
#ifdef MT_MAC
			pTxBlk->Priv = (dma_len);
#else
			pTxBlk->Priv = (TXINFO_SIZE + dma_len);
#endif /* MT_MAC */
			/* For TxInfo, the length of USBDMApktLen = TXWI_SIZE + TSO_SIZE + 802.11 header + payload */
#ifndef USB_BULK_BUF_ALIGMENT

			if ((pHTTXContext->CurWritePosition + 3906 + pTxBlk->Priv) > MAX_TXBULK_LIMIT) {
#ifdef MT_MAC
				TMAC_TXD_L *txd_l = (TMAC_TXD_L *)pTxBlk->HeaderBuf;
				TMAC_TXD_S *txd_s = (TMAC_TXD_S *)pTxBlk->HeaderBuf;
				TMAC_TXD_1 *txd_1 = &txd_s->TxD1;
				TMAC_TXD_7 *txd_7;

				if (txd_1->TxDFmt == TMI_FT_SHORT)
					txd_7 = &txd_s->TxD7;
				else
					txd_7 = &txd_l->TxD7;

				txd_7->SwUseSegmentEnd = 1;
#else
				pTxInfo->TxInfoSwLstRnd = 1;
#endif	/* MT_MAC */
				bTxQLastRound = TRUE;
			}

#endif /* USB_BULK_BUF_ALIGMENT */
			NdisMoveMemory(pWirelessPacket, pTxBlk->HeaderBuf, hdr_copy_len);
#ifdef RT_BIG_ENDIAN
			RTMPFrameEndianChange(pAd, (PUCHAR)(pWirelessPacket + TXINFO_SIZE + TXWISize + TSO_SIZE), DIR_WRITE, FALSE);
#endif /* RT_BIG_ENDIAN */
			pWirelessPacket += (hdr_copy_len);
			/* We unlock it here to prevent the first 8 bytes maybe over-writed issue.*/
			/*	1. First we got CurWritePosition but the first 8 bytes still not write to the pTxcontext.*/
			/*	2. An interrupt break our routine and handle bulk-out complete.*/
			/*	3. In the bulk-out compllete, it need to do another bulk-out, */
			/*			if the ENextBulkOutPosition is just the same as CurWritePosition, it will save the first 8 bytes from CurWritePosition,*/
			/*			but the payload still not copyed. the pTxContext->SavedPad[] will save as allzero. and set the bCopyPad = TRUE.*/
			/*	4. Interrupt complete.*/
			/*  5. Our interrupted routine go back and fill the first 8 bytes to pTxContext.*/
			/*	6. Next time when do bulk-out, it found the bCopyPad==TRUE and will copy the SavedPad[] to pTxContext->NextBulkOutPosition.*/
			/*		and the packet will wrong.*/
			pHTTXContext->CurWriteRealPos += hdr_copy_len;
#ifndef USB_BULK_BUF_ALIGMENT
			RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
#endif /* USB_BULK_BUF_ALIGMENT */
			{
				NdisMoveMemory(pWirelessPacket, pTxBlk->pSrcBufData, pTxBlk->SrcBufLen);
				pWirelessPacket += pTxBlk->SrcBufLen;
			}
#ifndef USB_BULK_BUF_ALIGMENT
			NdisZeroMemory(pWirelessPacket, padding + 8);
			RTMP_IRQ_LOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
#endif /* USB_BULK_BUF_ALIGMENT */
			pHTTXContext->CurWritePosition += pTxBlk->Priv;
#ifdef UAPSD_SUPPORT
#if defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT)
			UAPSD_TagFrame(pAd, pTxBlk->pPacket, pTxBlk->Wcid, pHTTXContext->CurWritePosition);
#else
#ifdef CONFIG_AP_SUPPORT
#ifdef P2P_SUPPORT

			if (P2P_GO_ON(pAd))
#else
#ifdef RT_CFG80211_P2P_SUPPORT
			if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd))
#else
			IF_DEV_CONFIG_OPMODE_ON_AP(pAd)
#endif /* RT_CFG80211_P2P_SUPPORT */
#endif /* P2P_SUPPORT */
			{
				UAPSD_TagFrame(pAd, pTxBlk->pPacket, pTxBlk->Wcid, pHTTXContext->CurWritePosition);
			}

#endif /* CONFIG_AP_SUPPORT */
#endif /* defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT) */
#endif /* UAPSD_SUPPORT */
#ifdef USB_BULK_BUF_ALIGMENT

			/*
				when CurWritePosition > 0x6000  mean that it is at the max bulk out size,
				we CurWriteIdx must move to the next alignment section.
				Otherwirse,  CurWriteIdx will be moved to the next section at databulkout.

				Writingflag = TRUE ,mean that when we writing resource ,and databulkout happen,
				So we bulk out when this packet finish.
			*/
			if ((pHTTXContext->CurWritePosition  & 0x00006000) == 0x00006000)
				pHTTXContext->CurWritePosition = ((CUR_WRITE_IDX_INC(pHTTXContext->CurWriteIdx, BUF_ALIGMENT_RINGSIZE)) * 0x8000);

#else

			if (bTxQLastRound)
				pHTTXContext->CurWritePosition = 8;

#endif /* USB_BULK_BUF_ALIGMENT */
			pHTTXContext->CurWriteRealPos = pHTTXContext->CurWritePosition;
			pHTTXContext->bCurWriting = FALSE;
		}

		RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);
	}

#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_LOUD, ("WS-A:Status=%d, Len=%d, CWPos=%ld, NBPos=%ld, ENBPos=%ld\n",
			 Status, TXINFO_SIZE + dma_len, pHTTXContext->CurWritePosition,
			 pHTTXContext->NextBulkOutPosition, pHTTXContext->ENextBulkOutPosition));
#endif /* RELEASE_EXCLUDE */
	/* succeed and release the skb buffer*/
	RELEASE_NDIS_PACKET(pAd, pTxBlk->pPacket, NDIS_STATUS_SUCCESS);
	return Status;
}

USHORT usb_write_multi_tx_resource(
	IN RTMP_ADAPTER *pAd,
	IN TX_BLK *pTxBlk,
	IN UCHAR frmNum,
	OUT USHORT *freeCnt)
{
	NDIS_STATUS Status = NDIS_STATUS_SUCCESS;
#ifndef MT_MAC
	HT_TX_CONTEXT *pHTTXContext;
	USHORT hwHdrLen;	/* The hwHdrLen consist of 802.11 header length plus the header padding length.*/
	UINT32 fillOffset;
	TXINFO_STRUC *pTxInfo;
	TXWI_STRUC *pTxWI;
	UCHAR *pWirelessPacket = NULL;
	UCHAR QueIdx;
	unsigned long IrqFlags;
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
	UINT8 TXWISize = cap->TXWISize;
	/* get Tx Ring Resource & Dma Buffer address*/
	QueIdx = pTxBlk->QueIdx;
	pHTTXContext  = &pAd->TxContext[QueIdx];
	RTMP_IRQ_LOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);

	if (frmNum == 0) {
		/* Check if we have enough space for this bulk-out batch.*/
		Status = RtmpUSBCanDoWrite(pAd, QueIdx, pHTTXContext);

		if (Status == NDIS_STATUS_SUCCESS) {
			pHTTXContext->bCurWriting = TRUE;
			pTxInfo = (TXINFO_STRUC *)(&pTxBlk->HeaderBuf[0]);
			pTxWI = (TXWI_STRUC *)(&pTxBlk->HeaderBuf[TXINFO_SIZE]);
#ifndef USB_BULK_BUF_ALIGMENT

			/* Reserve space for 8 bytes padding.*/
			if ((pHTTXContext->ENextBulkOutPosition == pHTTXContext->CurWritePosition)) {
#ifdef RELEASE_EXCLUDE
				MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_LOUD, ("Colision, CWPos=%ld, ENBPos=%ld!\n", pHTTXContext->CurWritePosition, pHTTXContext->ENextBulkOutPosition));
#endif /* RELEASE_EXCLUDE */
				pHTTXContext->CurWritePosition += 8;
				pHTTXContext->ENextBulkOutPosition += 8;
			}

#endif /* USB_BULK_BUF_ALIGMENT */
			fillOffset = pHTTXContext->CurWritePosition;
			pHTTXContext->CurWriteRealPos = pHTTXContext->CurWritePosition;
			pWirelessPacket = &pHTTXContext->TransferBuffer->field.WirelessPacket[fillOffset];

			/* Copy TXINFO + TXWI + WLAN Header + LLC into DMA Header Buffer*/

			if (pTxBlk->TxFrameType == TX_AMSDU_FRAME)
				/*hwHdrLen = ROUND_UP(pTxBlk->MpduHeaderLen-AMSDU_SUBHEAD_LEN, 4)+AMSDU_SUBHEAD_LEN;*/
				hwHdrLen = pTxBlk->MpduHeaderLen - AMSDU_SUBHEAD_LEN + pTxBlk->HdrPadLen + AMSDU_SUBHEAD_LEN;
			else if (pTxBlk->TxFrameType == TX_RALINK_FRAME)
				/*hwHdrLen = ROUND_UP(pTxBlk->MpduHeaderLen-ARALINK_HEADER_LEN, 4)+ARALINK_HEADER_LEN;*/
				hwHdrLen = pTxBlk->MpduHeaderLen - ARALINK_HEADER_LEN + pTxBlk->HdrPadLen + ARALINK_HEADER_LEN;
			else
				/*hwHdrLen = ROUND_UP(pTxBlk->MpduHeaderLen, 4);*/
				hwHdrLen = pTxBlk->MpduHeaderLen + pTxBlk->HdrPadLen;

			/* Update the pTxBlk->Priv.*/
			pTxBlk->Priv = TXINFO_SIZE + TXWISize + hwHdrLen;
			/*	pTxInfo->USBDMApktLen now just a temp value and will to correct latter.*/
			rlt_usb_write_txinfo(pAd, pTxInfo, (USHORT)(pTxBlk->Priv), FALSE, FIFO_EDCA, FALSE /*NextValid*/,  FALSE);
			/* Copy it.*/
			NdisMoveMemory(pWirelessPacket, pTxBlk->HeaderBuf, pTxBlk->Priv);
#ifdef RT_BIG_ENDIAN
			RTMPFrameEndianChange(pAd, (PUCHAR)(pWirelessPacket + TXINFO_SIZE + TXWISize), DIR_WRITE, FALSE);
#endif /* RT_BIG_ENDIAN */
			pHTTXContext->CurWriteRealPos += pTxBlk->Priv;
			pWirelessPacket += pTxBlk->Priv;
		}
	} else {
		/* For sub-sequent frames of this bulk-out batch. Just copy it to our bulk-out buffer.*/
		Status = ((pHTTXContext->bCurWriting == TRUE) ? NDIS_STATUS_SUCCESS : NDIS_STATUS_FAILURE);

		if (Status == NDIS_STATUS_SUCCESS) {
			fillOffset =  (pHTTXContext->CurWritePosition + pTxBlk->Priv);
			pWirelessPacket = &pHTTXContext->TransferBuffer->field.WirelessPacket[fillOffset];
			/*hwHdrLen = pTxBlk->MpduHeaderLen;*/
			NdisMoveMemory(pWirelessPacket, pTxBlk->HeaderBuf, pTxBlk->MpduHeaderLen);
			pWirelessPacket += (pTxBlk->MpduHeaderLen);
			pTxBlk->Priv += pTxBlk->MpduHeaderLen;
		} else {
			/* It should not happened now unless we are going to shutdown.*/
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("WriteMultiTxResource():bCurWriting is FALSE when handle sub-sequent frames.\n"));
			Status = NDIS_STATUS_FAILURE;
		}
	}

	/*
		We unlock it here to prevent the first 8 bytes maybe over-write issue.
		1. First we got CurWritePosition but the first 8 bytes still not write to the pTxContext.
		2. An interrupt break our routine and handle bulk-out complete.
		3. In the bulk-out compllete, it need to do another bulk-out,
			if the ENextBulkOutPosition is just the same as CurWritePosition, it will save the first 8 bytes from CurWritePosition,
			but the payload still not copyed. the pTxContext->SavedPad[] will save as allzero. and set the bCopyPad = TRUE.
		4. Interrupt complete.
		5. Our interrupted routine go back and fill the first 8 bytes to pTxContext.
		6. Next time when do bulk-out, it found the bCopyPad==TRUE and will copy the SavedPad[] to pTxContext->NextBulkOutPosition.
			and the packet will wrong.
	*/
	RTMP_IRQ_UNLOCK(&pAd->TxContextQueueLock[QueIdx], IrqFlags);

	if (Status != NDIS_STATUS_SUCCESS) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("WriteMultiTxResource: CWPos = %ld, NBOutPos = %ld.\n", pHTTXContext->CurWritePosition, pHTTXContext->NextBulkOutPosition));
		goto done;
	}

	/* Copy the frame content into DMA buffer and update the pTxBlk->Priv*/
	NdisMoveMemory(pWirelessPacket, pTxBlk->pSrcBufData, pTxBlk->SrcBufLen);
	pWirelessPacket += pTxBlk->SrcBufLen;
	pTxBlk->Priv += pTxBlk->SrcBufLen;
done:
	/* Release the skb buffer here*/
	RELEASE_NDIS_PACKET(pAd, pTxBlk->pPacket, NDIS_STATUS_SUCCESS);
#endif
	return Status;
}

#ifdef MT_MAC
VOID mt_usb_write_final_tx_resource(
	RTMP_ADAPTER *pAd,
	TX_BLK *pTxBlk,
	USHORT totalMPDUSize,
	USHORT TxIdx)
{
}
#endif


VOID RtmpUSBDataLastTxIdx(
	IN RTMP_ADAPTER *pAd,
	IN UCHAR QueIdx,
	IN USHORT TxIdx)
{
	/* DO nothing for USB.*/
}


/*
	When can do bulk-out:
		1. TxSwFreeIdx < TX_RING_SIZE;
			It means has at least one Ring entity is ready for bulk-out, kick it out.
		2. If TxSwFreeIdx == TX_RING_SIZE
			Check if the CurWriting flag is FALSE, if it's FALSE, we can do kick out.

*/
VOID usb_kickout_data_tx(
	IN RTMP_ADAPTER *pAd,
	IN TX_BLK *tx_blk,
	IN UCHAR que_idx)
{
	RTUSB_SET_BULK_FLAG(pAd, (fRTUSB_BULK_OUT_DATA_NORMAL << que_idx));
	RTUSBKickBulkOut(pAd);
}


/*
	Must be run in Interrupt context
	This function handle RT2870 specific TxDesc and cpu index update and kick the packet out.
 */
int usb_kickout_mgmt_tx(
	IN RTMP_ADAPTER *pAd,
	IN UCHAR QueIdx,
	IN PNDIS_PACKET pPacket,
	IN UCHAR *pSrcBufVA,
	IN UINT SrcBufLen)
{
	TXINFO_STRUC *pTxInfo;
	ULONG BulkOutSize;
	UCHAR padLen;
	PUCHAR pDest;
	ULONG SwIdx;
	TX_CONTEXT *pMLMEContext = NULL;
	TX_CONTEXT *pBcnContext = NULL;
	ULONG IrqFlags;
#if defined(MT7603) || defined(MT7636) || defined(MT7637)

	if (IS_MT7603(pAd) || IS_MT76x6(pAd) || IS_MT7637(pAd)) {
		if (QueIdx == Q_IDX_BCN) {
			SwIdx = pAd->BcnRing.TxCpuIdx;
			pBcnContext = (PTX_CONTEXT)pAd->BcnRing.Cell[SwIdx].AllocVa;
		} else {
			SwIdx = pAd->MgmtRing.TxCpuIdx;
			pMLMEContext = (PTX_CONTEXT)pAd->MgmtRing.Cell[SwIdx].AllocVa;
		}
	} else
#endif /* MT7603 */
	{
		SwIdx = pAd->MgmtRing.TxCpuIdx;
		pMLMEContext = (PTX_CONTEXT)pAd->MgmtRing.Cell[SwIdx].AllocVa;
	}

	pTxInfo = (TXINFO_STRUC *)(pSrcBufVA);
	/* Build our URB for USBD*/
	BulkOutSize = (SrcBufLen + 3) & (~3);
	BulkOutSize += 4; /* Always add 4 extra bytes at every packet.*/
	/* +++Add by shiang for debug */
#if 0

	if (0) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_OFF, ("-->%s():shiang-6590, QueIdx=%d, SrcBufLen=%d\n", __func__, QueIdx, SrcBufLen));
		dump_txinfo(pAd, pTxInfo);
		dump_tmac_info(pAd, (UCHAR *)(pSrcBufVA + TXINFO_SIZE));
	}

#endif
	/* ---Add by shiang for debug */
	/* WY , it cause Tx hang on Amazon_SE , Max said the padding is useless*/
	/* If BulkOutSize is multiple of BulkOutMaxPacketSize, add extra 4 bytes again.*/
	/*	if ((BulkOutSize % pAd->BulkOutMaxPacketSize) == 0)*/
	/*		BulkOutSize += 4;*/
	padLen = BulkOutSize - SrcBufLen;
	ASSERT((padLen <= RTMP_PKT_TAIL_PADDING));
	/* Now memzero all extra padding bytes.*/
	pDest = (PUCHAR)(pSrcBufVA + SrcBufLen);
#ifdef MT_MAC

	if (QueIdx == Q_IDX_BCN && pBcnContext)
		pBcnContext->ppkt_tail_before_padding = GET_OS_PKT_DATATAIL(pPacket);

#endif
	OS_PKT_TAIL_BUF_EXTEND(pPacket, padLen);
	NdisZeroMemory(pDest, padLen);
	RTMP_IRQ_LOCK(&pAd->MLMEBulkOutLock, IrqFlags);
#ifdef MT_MAC

	if (QueIdx == Q_IDX_BCN)
		pAd->BcnRing.Cell[pAd->BcnRing.TxCpuIdx].pNdisPacket = pPacket;
	else
#endif
		pAd->MgmtRing.Cell[pAd->MgmtRing.TxCpuIdx].pNdisPacket = pPacket;

#ifdef MT_MAC
	/* append four zero bytes padding */
	memset(OS_PKT_TAIL_BUF_EXTEND(pPacket, USB_END_PADDING), 0x00, USB_END_PADDING);
#endif
#ifdef MT_MAC

	if (QueIdx == Q_IDX_BCN && pBcnContext) {
		pBcnContext->TransferBuffer = (PTX_BUFFER)(GET_OS_PKT_DATAPTR(pPacket));
		/* Length in TxInfo should be 8 less than bulkout size.*/
		pBcnContext->BulkOutSize = BulkOutSize;
		pBcnContext->InUse = TRUE;
		pBcnContext->bWaitingBulkOut = TRUE;
#ifdef UAPSD_SUPPORT
		pBcnContext->Wcid = MCAST_WCID_TO_REMOVE;
#endif /* UAPSD_SUPPORT */
	} else if (pMLMEContext)
#endif /* MT_MAC */
	{
		pMLMEContext->TransferBuffer = (PTX_BUFFER)(GET_OS_PKT_DATAPTR(pPacket));
		/* Length in TxInfo should be 8 less than bulkout size.*/
		pMLMEContext->BulkOutSize = BulkOutSize;
		pMLMEContext->InUse = TRUE;
		pMLMEContext->bWaitingBulkOut = TRUE;
#ifdef UAPSD_SUPPORT
		/*
			If the packet is QoS Null frame, we mark the packet with its WCID;
			If not, we mark the packet with bc/mc WCID = 0.

			We will handle it in rtusb_mgmt_dma_done_tasklet().

			Even AP send a QoS Null frame but not EOSP frame in USB mode,
			then we will call UAPSD_SP_Close() and we will check
			pEntry->bAPSDFlagSPStart() so do not worry about it.
		*/
#if defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT)

		if (RTMP_GET_PACKET_QOS_NULL(pPacket) != 0x00)
			pMLMEContext->Wcid = RTMP_GET_PACKET_WCID(pPacket);
		else
			pMLMEContext->Wcid = MCAST_WCID;

#else
#ifdef CONFIG_AP_SUPPORT
#ifdef P2P_SUPPORT

		if (P2P_GO_ON(pAd))
#else
#ifdef RT_CFG80211_P2P_SUPPORT
		if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd))
#else
		IF_DEV_CONFIG_OPMODE_ON_AP(pAd)
#endif /* RT_CFG80211_P2P_SUPPORT */
#endif /* P2P_SUPPORT */
		{
			if (RTMP_GET_PACKET_QOS_NULL(pPacket) != 0x00)
				pMLMEContext->Wcid = RTMP_GET_PACKET_WCID(pPacket);
			else
				pMLMEContext->Wcid = MCAST_WCID_TO_REMOVE;
		}

#endif /* CONFIG_AP_SUPPORT */
#endif /* defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT) */
#endif /* UAPSD_SUPPORT */
	}

	/*hex_dump("RtmpUSBMgmtKickOut", &pMLMEContext->TransferBuffer->field.WirelessPacket[0], (pMLMEContext->BulkOutSize > 16 ? 16 : pMLMEContext->BulkOutSize));*/
	/*
		pAd->RalinkCounters.KickTxCount++;
		pAd->RalinkCounters.OneSecTxDoneCount++;

		if (pAd->MgmtRing.TxSwFreeIdx == MGMT_RING_SIZE)
			needKickOut = TRUE;
	*/
	/* Decrease the TxSwFreeIdx and Increase the TX_CTX_IDX*/
#ifdef MT_MAC

	if (QueIdx == Q_IDX_BCN) {
		pAd->BcnRing.TxSwFreeIdx--;
		INC_RING_INDEX(pAd->BcnRing.TxCpuIdx, BCN_RING_SIZE);
	} else
#endif
	{
		pAd->MgmtRing.TxSwFreeIdx--;
		INC_RING_INDEX(pAd->MgmtRing.TxCpuIdx, MGMT_RING_SIZE);
	}

	RTMP_IRQ_UNLOCK(&pAd->MLMEBulkOutLock, IrqFlags);
#ifdef MT_MAC

	if (QueIdx == Q_IDX_BCN)
		RTUSB_SET_BULK_FLAG(pAd, fRTUSB_BULK_OUT_BCN);
	else
#endif
		RTUSB_SET_BULK_FLAG(pAd, fRTUSB_BULK_OUT_MLME);

	/*if (needKickOut)*/
	RTUSBKickBulkOut(pAd);
	return 0;
}


VOID RtmpUSBNullFrameKickOut(
	IN RTMP_ADAPTER *pAd,
	IN UCHAR QueIdx,
	IN UCHAR *pNullFrame,
	IN UINT32 frameLen)
{
	if (pAd->NullContext.InUse == FALSE) {
		PTX_CONTEXT pNullContext;
		TXINFO_STRUC *pTxInfo;
		TXWI_STRUC *pTxWI;
		UCHAR *pWirelessPkt;
		MAC_TX_INFO mac_info;
		struct wifi_dev *wdev;
		PHEADER_802_11 pHeader_802_11 = (HEADER_802_11 *)(pNullFrame);
#ifdef MT_MAC
		UCHAR *tmac_info;
		struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
		UINT tx_hw_hdr_len = cap->tx_hw_hdr_len;
#endif
#ifdef CONFIG_STA_SUPPORT
		PSTA_ADMIN_CONFIG pStaCfg = NULL;
#endif /* CONFIG_STA_SUPPORT */
		pNullContext = &(pAd->NullContext);
		/* Set the in use bit*/
		pNullContext->InUse = TRUE;
		pWirelessPkt = (PUCHAR)&pNullContext->TransferBuffer->field.WirelessPacket[0];
		RTMPZeroMemory(&pWirelessPkt[0], 100);
		pTxInfo = (TXINFO_STRUC *)&pWirelessPkt[0];
		pTxWI = (TXWI_STRUC *)&pWirelessPkt[TXINFO_SIZE];
		NdisZeroMemory((UCHAR *)&mac_info, sizeof(mac_info));
#ifdef MT_MAC
		tmac_info = &pWirelessPkt[0];

		if (pHeader_802_11->FC.Type == FC_TYPE_DATA) {
			switch (pHeader_802_11->FC.SubType) {
			case SUBTYPE_DATA_NULL:
				mac_info.hdr_len = 24;
				break;

			case SUBTYPE_QOS_NULL:
				mac_info.hdr_len = 26;
				break;

			default:
				break;
			}
		}

#endif

		wdev = wdev_search_by_address(pAd, pHeader_802_11->Addr2);
		if (wdev == NULL)
			return;

		mac_info.FRAG = FALSE;
		mac_info.CFACK = FALSE;
		mac_info.InsTimestamp = FALSE;
		mac_info.AMPDU = FALSE;
		mac_info.BM = 0;
		mac_info.Ack = TRUE;
		mac_info.NSeq = FALSE;
		mac_info.BASize = 0;
		{
			MAC_TABLE_ENTRY *pEntry = MacTableLookup(pAd, pHeader_802_11->Addr1);
			mac_info.WCID = pEntry->wcid;
		}
		mac_info.Length = frameLen;
#ifdef CONFIG_STA_SUPPORT
		pStaCfg = GetStaCfgByWdev(pAd, wdev);
		ASSERT(pStaCfg);

#ifdef STA_LP_PHASE_1_SUPPORT
		if ((!RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS)) && RTMPEnterPsmNullBitStatus(&pStaCfg->PwrMgmt)) {
			mac_info.PID = (pHeader_802_11->FC.PwrMgmt == PWR_ACTIVE) ? PID_NULL_FRAME_PWR_ACTIVE : PID_NULL_FRAME_PWR_SAVE;
			RTMPClearEnterPsmNullBit(&pStaCfg->PwrMgmt);
			TxSTypeCtlPerPkt(pAd, mac_info.PID, TXS_FORMAT0, FALSE, TRUE, FALSE, TXS_DUMP_REPEAT);
		}
#endif /* STA_LP_PHASE_1_SUPPORT */

#endif /* CONFIG_STA_SUPPORT */
		mac_info.TID = 0;
		mac_info.TxRate = (UCHAR)wdev->rate.MlmeTransmit.field.MCS;
		mac_info.Txopmode = IFS_HTTXOP;
		mac_info.Preamble = LONG_PREAMBLE;
		mac_info.IsAutoRate = FALSE;
#ifdef MT_MAC
		/* For  MT STA LP control, use H/W control mode for PM bit */
#if defined(CONFIG_STA_SUPPORT) && defined(CONFIG_PM_BIT_HW_MODE)
		mac_info.PsmBySw = 0;
#else
		mac_info.PsmBySw = 1;
#endif /* CONFIG_STA_SUPPORT && CONFIG_PM_BIT_HW_MODE */
		mac_info.q_idx = Q_IDX_AC0;

		if (!wdev)
			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_INFO, ("%s():Err!! wdev is NULL!!\n", __func__));
		else
			mac_info.OmacIdx = wdev->OmacIdx;

		RTMPMoveMemory(&pWirelessPkt[tx_hw_hdr_len], pNullFrame, frameLen);
		pAd->archOps.write_tmac_info_fixed_rate(pAd, (UCHAR *)tmac_info, &mac_info, &wdev->rate.MlmeTransmit);
		pAd->NullContext.BulkOutSize =  tx_hw_hdr_len + frameLen + 4;
#else
		pAd->archOps.write_tmac_info_fixed_rate(pAd, (UCHAR *)pTxWI, &mac_info, &wdev->rate.MlmeTransmit);
#ifdef RT_BIG_ENDIAN
		RTMPWIEndianChange(pAd, (PUCHAR)pTxWI, TYPE_TXWI);
#endif /* RT_BIG_ENDIAN */
		RTMPMoveMemory(&pWirelessPkt[TXWISize + TXINFO_SIZE + TSO_SIZE], pNullFrame, frameLen);
#ifdef RT_BIG_ENDIAN
		RTMPFrameEndianChange(pAd, (PUCHAR)&pWirelessPkt[TXINFO_SIZE + TXWISize + TSO_SIZE], DIR_WRITE, FALSE);
#endif /* RT_BIG_ENDIAN */
		pAd->NullContext.BulkOutSize =  TXINFO_SIZE + TXWISize + TSO_SIZE + frameLen + 4;
#endif /* MT_MAC */
		pAd->NullContext.BulkOutSize = (pAd->NullContext.BulkOutSize + 3) & (~3);
#ifdef MT_MAC
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("%s - Send NULL Frame @%d Mbps...(PwrMgmt, PID)(%d, %d)\n", __func__, RateIdToMbps[pAd->CommonCfg.TxRate], pHeader_802_11->FC.PwrMgmt, mac_info.PID));
#else
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("%s - Send NULL Frame @%d Mbps...\n", __func__, RateIdToMbps[pAd->CommonCfg.TxRate]));
#endif
		RTUSB_SET_BULK_FLAG(pAd, fRTUSB_BULK_OUT_DATA_NULL);
		pAd->Sequence = (pAd->Sequence + 1) & MAXSEQ;
		/* Kick bulk out */
		RTUSBKickBulkOut(pAd);
	}
}


/*
========================================================================
Routine Description:
    Get a received packet.

Arguments:
	pAd					device control block
	pSaveRxD			receive descriptor information
	*pbReschedule		need reschedule flag
	*pRxPending			pending received packet flag

Return Value:
    the recieved packet

Note:
========================================================================
*/
PNDIS_PACKET usb_get_pkt_from_rx_resource(
	RTMP_ADAPTER *pAd,
	RX_BLK **_pRxBlk,
	BOOLEAN *pbReschedule,
	UINT32 *pRxPending,
	UCHAR RxRingNo)
{
	RX_CONTEXT *pRxContext;
	PNDIS_PACKET pNetPkt = NULL;
	UCHAR *pData;
	ULONG ThisFrameLen, RxBufferLength, valid_len;
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
	UINT8 RXWISize = cap->RXWISize;
	RXINFO_STRUC *pRxInfo = NULL;
	RX_BLK *pRxBlk = *_pRxBlk;
#ifdef MT_MAC
	UINT8 rx_hw_hdr_len = RXWISize;
	UINT32 padding = 0;
#ifdef CONFIG_CSO_SUPPORT
	UINT32 u4len = 0;
	PUCHAR pcBufCso = NULL;
	RX_CSO_STRUCT *prCso = NULL;
#endif
#endif
	pRxContext = &pAd->RxContext[pAd->RxBulkInReadIndex];
	pRxBlk->Flags = 0;
	RxBufferLength = pRxContext->BulkInOffset - pRxContext->ReadPosition;
#ifdef MT_MAC

	if (IS_HIF_TYPE(pAd, HIF_MT))
		valid_len = 8;
	else
#endif /* MT_MAC */
		valid_len = RXDMA_FIELD_SIZE + RXWISize + sizeof(RXINFO_STRUC);

	if (RxBufferLength < valid_len) {
#ifdef RELEASE_EXCLUDE
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_INFO, ("%s(): Remaining RxBufLen(%ld) small than MinSize(%ld)!\n", __func__, RxBufferLength, valid_len));
#endif /* RELEASE_EXCLUDE */
		goto label_null;
	}

	pData = &pRxContext->TransferBuffer[pRxContext->ReadPosition];

	/* +++Add by shiang for debug */
	if (0)
		hex_dump("usb_get_pkt_from_rx_resource", pData, (RxBufferLength > 7000 ? 7000 : RxBufferLength));

	/* ---Add by shiang for debug */
#ifdef RT_BIG_ENDIAN
	RTMPWIEndianChange(pAd, pData, TYPE_RXWI);
#endif /* RT_BIG_ENDIAN */
	/* The RXDMA field is 4 bytes, now just use the first 2 bytes. The Length including the (RXWI + MSDU + Padding) */
	ThisFrameLen = *pData + (*(pData + 1) << 8);
#ifndef MT_MAC

	if (ThisFrameLen == 0) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("RXDMALen is zero.[%ld], BulkInBufLen = %ld)\n",
				 ThisFrameLen, pRxContext->BulkInOffset));
		goto label_null;
	}

	if ((ThisFrameLen & 0x3) != 0) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("RXDMALen not multiple of 4.[%ld], BulkInBufLen = %ld)\n",
				 ThisFrameLen, pRxContext->BulkInOffset));
		goto label_null;
	}

	if ((ThisFrameLen + 8) > RxBufferLength) {	/* 8 for (RXDMA_FIELD_SIZE + sizeof(RXINFO_STRUC))*/
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("FrameLen(0x%lx) outranges. BulkInLen=0x%lx, remaining RxBufLen=0x%lx, ReadPos=0x%lx\n",
				 ThisFrameLen, pRxContext->BulkInOffset, RxBufferLength, pRxContext->ReadPosition));
		/* error frame. finish this loop*/
		goto label_null;
	}

	pData += RXDMA_FIELD_SIZE;
#endif /* MT_MAC */
#ifdef MT_MAC

	if (IS_HIF_TYPE(pAd, HIF_MT)) {
		union _RMAC_RXD_0_UNION *rxd_0;
		rxd_0 = (union _RMAC_RXD_0_UNION *)pData;
		/* allocate a rx packet */
		pNetPkt = RTMP_AllocateFragPacketBuffer(pAd, ThisFrameLen);

		if (pNetPkt == NULL) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("%s():Cannot Allocate sk buffer for this Bulk-In buffer!\n", __func__));
			goto label_null;
		}

		/* copy the rx packet*/
#if 0
		hex_dump("pData rx data:", (char *)pData, ThisFrameLen);
#endif
		RTMP_USB_PKT_COPY(get_netdev_from_bssid(pAd, BSS0), pNetPkt, ThisFrameLen, pData);
		rx_hw_hdr_len = mt_rx_pkt_process(pAd, pRxBlk, pNetPkt);

		if (RX_BLK_TEST_FLAG(pRxBlk, fRX_CMD_RSP)) {
			RELEASE_NDIS_PACKET(pAd, pNetPkt, NDIS_STATUS_SUCCESS);
			/* Only one RX_CMD_RSP exist in one RxContext, update ReadPosition */
			/* to prevent the same RxContext being handled again. */
			pRxContext->ReadPosition += pRxContext->BulkInOffset;
			return NULL;
		}

		ThisFrameLen -= rx_hw_hdr_len;
	}

#endif /* MT_MAC */
#ifdef RT_BIG_ENDIAN
	RTMPWIEndianChange(pAd, pData, TYPE_RXWI);
#endif /* RT_BIG_ENDIAN */

	if (pRxBlk->MPDUtotalByteCnt > ThisFrameLen) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("%s():MPDUtotalByteCount(%d) large than RxDMALen(%ld)\n",
				 __func__, pRxBlk->MPDUtotalByteCnt, ThisFrameLen));
		goto label_null;
	}

#ifdef RT_BIG_ENDIAN
	RTMPWIEndianChange(pAd, pData, TYPE_RXWI);
#endif /* RT_BIG_ENDIAN */

	if (!IS_HIF_TYPE(pAd, HIF_MT)) {
		/* allocate a rx packet*/
		pNetPkt = RTMP_AllocateFragPacketBuffer(pAd, ThisFrameLen);

		if (pNetPkt == NULL) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("%s():Cannot Allocate sk buffer for this Bulk-In buffer!\n", __func__));
			goto label_null;
		}

		/* copy the rx packet*/
		RTMP_USB_PKT_COPY(get_netdev_from_bssid(pAd, BSS0), pNetPkt, ThisFrameLen, pData);
	}

#ifdef RT_BIG_ENDIAN
	RTMPDescriptorEndianChange((PUCHAR)pRxInfo, TYPE_RXINFO);
#endif /* RT_BIG_ENDIAN */
#ifdef MT_MAC

	if (IS_HIF_TYPE(pAd, HIF_MT)) {
		/* update next packet read position.*/
		padding = (4 - ((ThisFrameLen + rx_hw_hdr_len) % 4)) & 0x03;  /* round up to 4 byte alignment*/
		pRxContext->ReadPosition += (ThisFrameLen + rx_hw_hdr_len + padding + 4); /* 4:CSO */
	} else
#endif /* MT_MAC */
	{
		if (pRxInfo != NULL)
			NdisMoveMemory(&pRxBlk->hw_rx_info[RXINFO_OFFSET], pRxInfo, RAL_RXINFO_SIZE);

		pRxBlk->pRxInfo = (RXINFO_STRUC *)&pRxBlk->hw_rx_info[RXINFO_OFFSET];
		/* update next packet read position.*/
		pRxContext->ReadPosition += (ThisFrameLen + RXDMA_FIELD_SIZE + RAL_RXINFO_SIZE);	/* 8 for (RXDMA_FIELD_SIZE + sizeof(RXINFO_STRUC))*/
	}

	pRxBlk->pRxPacket = pNetPkt;
	pRxBlk->pData = (UCHAR *)GET_OS_PKT_DATAPTR(pNetPkt);
#ifdef MT_MAC

	if (IS_HIF_TYPE(pAd, HIF_MT)) {
#ifdef CONFIG_CSO_SUPPORT
		u4len = GET_OS_PKT_LEN(pNetPkt);
		pcBufCso = pRxBlk->pData + ((u4len + 3) & ~3);
		prCso = (RX_CSO_STRUCT *)pcBufCso;
		NdisCopyMemory(&(pRxBlk->rCso), prCso, sizeof(RX_CSO_STRUCT));
#endif
	}

#endif /* MT_MAC */
	pRxBlk->Flags = 0;
	return pNetPkt;
label_null:
	return NULL;
}


#ifdef CONFIG_STA_SUPPORT
VOID RtmpUsbStaAsicForceWakeupTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	RTMP_ADAPTER *pAd = (RTMP_ADAPTER *)FunctionContext;
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_INFO, ("<-- RtmpUsbStaAsicForceWakeupTimeout\n"));
#endif /* RELEASE_EXCLUDE */

	if (pAd && pAd->Mlme.AutoWakeupTimerRunning) {
		{
			RTUSBBulkReceive(pAd);
			AsicSendCommandToMcu(pAd, 0x31, 0xff, 0x00, 0x02, FALSE);
		}
		pAd->StaCfg[0].PwrMgmt.bDoze = FALSE;
		pAd->Mlme.AutoWakeupTimerRunning = FALSE;
	}
}


VOID RT28xxUsbStaAsicWakeup(RTMP_ADAPTER *pAd, BOOLEAN bFromTx, PSTA_ADMIN_CONFIG pStaCfg)
{
#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	ASSERT(pStaCfg);

	if (pStaCfg)
		RTMPOffloadPm(pAd, pStaCfg, PM4, EXIT_PM_STATE);

#else
	BOOLEAN	Canceled;

	if (pAd->Mlme.AutoWakeupTimerRunning) {
		RTMPCancelTimer(&pAd->Mlme.AutoWakeupTimer, &Canceled);
		pAd->Mlme.AutoWakeupTimerRunning = FALSE;
	}

	AsicSendCommandToMcu(pAd, 0x31, 0xff, 0x00, 0x02, FALSE);
	pAd->StaCfg[0].PwrMgmt.bDoze = FALSE;
#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */
}


VOID RT28xxUsbStaAsicSleepAutoWakeup(
	PRTMP_ADAPTER pAd,
	PSTA_ADMIN_CONFIG pStaCfg)
{
#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	ASSERT(pStaCfg);

	if (pStaCfg)
		RTMPOffloadPm(pAd, pStaCfg, PM4, ENTER_PM_STATE);

#else
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_INFO, ("%s(): TbttNumToNextWakeUp=%d 1\n",
			 __func__, pStaCfg->ThisTbttNumToNextWakeUp));
#endif /* RELEASE_EXCLUDE */

	/* Not going to sleep if in the Count Down Time*/
	if (pStaCfg->CountDowntoPsm > 0)
		return;

	/* we have decided to SLEEP, so at least do it for a BEACON period.*/
	if (pStaCfg->ThisTbttNumToNextWakeUp == 0)
		pStaCfg->ThisTbttNumToNextWakeUp = 1;

	RTMPSetTimer(&pAd->Mlme.AutoWakeupTimer, AUTO_WAKEUP_TIMEOUT);
	pAd->Mlme.AutoWakeupTimerRunning = TRUE;
	{
		AsicSendCommandToMcu(pAd, 0x30, 0xff, 0xff, 0x02, FALSE);   /* send POWER-SAVE command to MCU. Timeout 40us.*/

		/* cancel bulk-in IRPs prevent blocking CPU enter C3.*/
		if ((!RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_NIC_NOT_EXIST))) {
			RTUSBCancelPendingBulkInIRP(pAd);
			/* resend bulk-in IRPs to receive beacons after a period of (pAd->CommonCfg.BeaconPeriod - 40) ms*/
		}
	}
	pAd->StaCfg[0].PwrMgmt.bDoze = TRUE;
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_INFO, ("<-- AsicSleepAutoWakeup, TbttNumToNextWakeUp=%d\n", TbttNumToNextWakeUp));
#endif /* RELEASE_EXCLUDE */
#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */
}
#endif /* CONFIG_STA_SUPPORT */


VOID rtmp_hif_data_init(RTMP_ADAPTER *pAd)
{
	UINT index = 0;
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
#ifdef RELEASE_EXCLUDE
	/*
	Recorder: Sample Lin
	Co-worker: Albert Yang, Alex Lin, Albert Liu, Shawn Hsiao
	Date: 2009/12/29

	1. Motivation: Large power consumption problem in RT2870 only.

	2. Problem: When we insert/remove rt2870 station and then insert
		rt2870 ap driver, the current will reach 7xx mA, but the maximum
		legal current is 500mA in USB device.

	3. Phenomenon:
		We found 8051 firmware will update 0x1328 to default value 0x0f50f,
		i.e. enable PA and LNA for 2.4G and 5GHz.

		But if AP is located in 2.4GHz, no need to enable PA/LNA for 5GHz;
		if AP is located in 5GHz, no need to enable PA/LNA for 2.4GHz.

	4. Analysis:
		(1) Our driver will change 0x1328 only when channel switch to
			correct value 0x0f50a (2.4GHz) or 0x0f505 (5GHz);
			But the value will be changed to the wrong value 0x0f50f
			after interface up.
		(2) The we found if we issue the MCU command 0x30 in radio off
			function of station driver, the MAC 0x1328 will be changed
			automatically in AP driver.
		(3) Albert Liu said that 8051 only update MAC 0x1328 when it
			receives 0x31 MCU command.
		(4) If we do not upload 8051 firmware in AP driver after station
			driver is removed, no the problem occur.
			So we think that when 8051 is on work, if we upload 8051
			firmware, any unpredicted result will occur.

	5. Solution:
		(1) From Alex:
			Use new firmware and send 0x31 MCU command before channel
			switch. The new firmware will save 0x1328 value when you issue
			0x30 MCU sleep command and restore 0x1328 value when you issue
			0x31 MCU wake up command.
		(2) From Albert Liu: (final solution, no need to patch firmware)
			Or reset MCU before 8051 firmware upload and 8051 will reset
			anything in AP or STA driver for USB device.
			The solution can not be used in PCI/PCIe device because
			USB device has a ROM kept a simple 8051 firmware but no ROM
			on PCI/PCIe device:

			a. When USB up, it will run the 8051 on ROM;
			b. When we issue a reset MCU command, USB will translate
				to the 8051 on ROM if we have ever run 8051 before;
			c. And we upload firmware;
			d. Issue a vendor request 0x01, 0x8 to run the 8051 on RAM;

			So we must reset 8051 before firmware upload.
			But the side effect is we often receive CRC-ERROR packets.
		(3) Modify EEPROM 0x2e1 = 0x80 to disable 8051 recover 0x1328
			value when 1st beacon is sent.
			Because the code in ROM (not RAM) of USB device will check
			the bit.
			If our customer can not accept to modify EEPROM, we will use
			solution 1.
	*/
#endif /* RELEASE_EXCLUDE */

	if (cap->MCUType == M8051) {
		AsicSendCommandToMcu(pAd, 0x31, 0xff, 0x00, 0x02, FALSE);
		RtmpusecDelay(10000);
	}

	RTMP_CLEAR_FLAG(pAd, fRTMP_ADAPTER_REMOVE_IN_PROGRESS);

	/* Support multiple BulkIn IRP,*/
	/* the value on pAd->CommonCfg.NumOfBulkInIRP may be large than 1.*/
	for (index = 0; index < pAd->CommonCfg.NumOfBulkInIRP; index++) {
		RTUSBBulkReceive(pAd);
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_TRACE, ("RTUSBBulkReceive!\n"));
	}
}


#endif /* RTMP_MAC_USB */


NDIS_STATUS RTMPInitHifAdapterBlock(RTMP_ADAPTER *pAd)
{
#ifdef CONFIG_ATE
	RTMP_OS_ATMOIC_INIT(&pAd->BulkOutRemained, &pAd->RscAtomicMemList);
	RTMP_OS_ATMOIC_INIT(&pAd->BulkInRemained, &pAd->RscAtomicMemList);
#endif /* CONFIG_ATE */
	return NDIS_STATUS_SUCCESS;
}


NDIS_STATUS RTMPFreeHifAdapterBlock(RTMP_ADAPTER *pAd)
{
#ifdef CONFIG_ATE
	RTMP_OS_ATMOIC_DESTROY(&pAd->BulkOutRemained);
	RTMP_OS_ATMOIC_DESTROY(&pAd->BulkInRemained);
#endif /* CONFIG_ATE */
	return NDIS_STATUS_SUCCESS;
}

