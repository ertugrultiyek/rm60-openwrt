/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	hif_sdio.c
*/


#include "rt_config.h"
#include "rtmp.h"

static const TX_RESOURCE_CONTROL_T arTcResourceControl[TC_NUM] = {
	/* dest port index, dest queue index,   HIF TX queue index */
	/* First HW queue */
	{PORT_INDEX_LMAC,   MAC_TXQ_AC0_INDEX,  HIF_TX_AC1_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_AC1_INDEX,  HIF_TX_AC0_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_AC2_INDEX,  HIF_TX_AC2_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_AC3_INDEX,  HIF_TX_AC3_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_BMC_INDEX,  HIF_TX_BMC_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_AC4_INDEX,  HIF_TX_AC4_INDEX},
	{PORT_INDEX_MCU,    MCU_Q1_INDEX,       HIF_TX_CPU_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_BCN_INDEX,  HIF_TX_BCN_INDEX},
#if 0 /* second interface not used currently */
	/* Second HW queue */
	{PORT_INDEX_LMAC,   MAC_TXQ_AC10_INDEX, HIF_TX_AC10_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_AC11_INDEX, HIF_TX_AC11_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_AC12_INDEX, HIF_TX_AC12_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_AC13_INDEX, HIF_TX_AC13_INDEX},
	{PORT_INDEX_LMAC,   MAC_TXQ_AC14_INDEX, HIF_TX_AC14_INDEX},
#endif
};
static INT_EVENT_MAP_T arIntEventMapTable[] = {
	{ABNORMAL_INT,                         INT_EVENT_ABNORMAL},
	{D2H_SW_INT,                           INT_EVENT_SW_INT},
	{TX_DONE_INT,                          INT_EVENT_TX},
	{(RX0_DONE_INT | RX1_DONE_INT),        INT_EVENT_RX}

};

/* --------------- end ----------------------------------> */
static const UINT8 ucIntEventMapSize = (sizeof(arIntEventMapTable) / sizeof(INT_EVENT_MAP_T));

static IST_EVENT_FUNCTION apfnEventFuncTable[] = {
	MTSDIOProcessAbnormalInterrupt,            /*!< INT_EVENT_ABNORMAL */
	MTSDIOProcessSoftwareInterrupt,            /*!< INT_EVENT_SW_INT   */
	MTSDIOProcessTxInterrupt,                  /*!< INT_EVENT_TX       */
	MTSDIOProcessRxInterrupt,                  /*!< INT_EVENT_RX       */
};
#if CFG_SDIO_TX_THREAD
static void RxDoneTasklet(unsigned long data)
{
#ifdef WORKQUEUE_BH
	struct work_struct *work = (struct work_struct *)data;
	POS_COOKIE pObj = container_of(work, struct os_cookie, mt_mac_int_0_task);
	RTMP_ADAPTER *pAd = (RTMP_ADAPTER *)pObj->pAd_va;
#else
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER) data;
	POS_COOKIE pObj;
#endif /* WORKQUEUE_BH */

	_RTMPDeQueuePacket(pAd, FALSE, WMM_NUM_OF_AC, WCID_ALL, 64);
	MtSdioSubmitDataToSDIOWorker(pAd);
}
#endif

VOID
MTSDIORxInitialize(
	IN PRTMP_ADAPTER prAd
)
{
	P_RX_CTRL_T prRxCtrl = NULL;
	P_SW_RFB_T prSwRfb;
	UINT32 i;
	unsigned long flags = 0;
	ASSERT(prAd);
	prRxCtrl = &prAd->rRxCtrl;
	prRxCtrl->pucRxCoalescingBufPtr = prAd->pucCoalescingBufCached;
#if (CFG_SDIO_INTR_ENHANCE == 1)
	os_alloc_mem(prAd, (UCHAR **)&prAd->penhanced_status, sizeof(ENHANCE_MODE_DATA_STRUCT_T));
	InitializeQueueHeader(&prRxCtrl->rFreeSwRfbList);
	InitializeQueueHeader(&prRxCtrl->rReceivedRfbList);
	NdisAllocateSpinLock(prAd, &prRxCtrl->rFreeSwRfbLock);
	NdisAllocateSpinLock(prAd, &prRxCtrl->rReceivedRfbLock);

	for (i = SDIO_RX_RFB_NUM; i != 0; i--) {
		os_alloc_mem(prAd, (UCHAR **)&prSwRfb, sizeof(SW_RFB_T));

		if (!prSwRfb) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: MEM ALLOC ERROR\n", __func__));
			break;
		}

		prSwRfb->prRxPacket = RTMP_AllocateFragPacketBuffer(prAd, MAX_FRAME_SIZE);

		if (prSwRfb->prRxPacket == NULL) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s():Cannot Allocate sk buffer for this Bulk-In buffer!\n", __func__));
			break;
		}

		RTMP_IRQ_LOCK(&prRxCtrl->rFreeSwRfbLock, flags);
		InsertTailQueue(&prRxCtrl->rFreeSwRfbList, &prSwRfb->rQueEntry);
		RTMP_IRQ_UNLOCK(&prRxCtrl->rFreeSwRfbLock, flags);
	}

#if CFG_SDIO_STAT
	prAd->SdioStatistics.RxRceiveMax  = 0;
#endif
#endif
	return;
}


VOID
MTSDIORxUninitialize(
	IN PRTMP_ADAPTER prAd
)
{
	P_RX_CTRL_T prRxCtrl = NULL;
	unsigned long IrqFlags;
	P_SW_RFB_T prSwRfb;
	QUEUE_ENTRY *pEntry;
	ASSERT(prAd);
	prRxCtrl = &prAd->rRxCtrl;
#if (CFG_SDIO_INTR_ENHANCE == 1)
	os_free_mem(prAd->penhanced_status);

	do {
		RTMP_IRQ_LOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags);
		pEntry = RemoveHeadQueue(&prRxCtrl->rFreeSwRfbList);
		prSwRfb = (P_SW_RFB_T)pEntry;
		RTMP_IRQ_UNLOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags);

		if (prSwRfb) {
			if (prSwRfb->prRxPacket)
				RELEASE_NDIS_PACKET(prAd, prSwRfb->prRxPacket, NDIS_STATUS_SUCCESS);

			prSwRfb->prRxPacket = NULL;
			os_free_mem(prSwRfb);
		} else
			break;
	} while (TRUE);

	do {
		RTMP_IRQ_LOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags);
		pEntry = RemoveHeadQueue(&prRxCtrl->rReceivedRfbList);
		prSwRfb = (P_SW_RFB_T)pEntry;
		RTMP_IRQ_UNLOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags);

		if (prSwRfb) {
			if (prSwRfb->prRxPacket)
				RELEASE_NDIS_PACKET(prAd, prSwRfb->prRxPacket, NDIS_STATUS_SUCCESS);

			prSwRfb->prRxPacket = NULL;
			os_free_mem(prSwRfb);
		} else
			break;
	} while (TRUE);

	NdisFreeSpinLock(&prRxCtrl->rFreeSwRfbLock);
	NdisFreeSpinLock(&prRxCtrl->rReceivedRfbLock);
#endif
	prRxCtrl->pucRxCoalescingBufPtr = NULL;
	/*
		free prRxCtrl->pucRxCoalescingBufPtr(prAd->pucCoalescingBufCached)
		in RTMPFreeTxRxRingMemory
	*/
	return;
}


VOID
MTSDIOTxInitialize(
	IN PRTMP_ADAPTER prAd
)
{
	P_TX_CTRL_T prTxCtrl = NULL;
#if CFG_SDIO_TX_THREAD
	P_TX_RFB_T pTxRfb;
	UINT32 i;
	unsigned long flags = 0;
	POS_COOKIE pObj = (POS_COOKIE) prAd->OS_Cookie;
#endif
	ASSERT(prAd);
	prTxCtrl = &prAd->rTxCtrl;
	/* os_alloc_mem(prAd, &prTxCtrl->pucTxCoalescingBufPtr, SDIO_TX_MAX_SIZE_PER_FRAME); */
	prTxCtrl->pucTxCoalescingBufPtr = prAd->pucCoalescingBufCached;
	NdisAllocateSpinLock(prAd, &prAd->TcCountLock);
	/* Reset the TC quota for F/W DL phase */
	MTSDIOTxInitResetResource(prAd);
#if CFG_SDIO_STAT
	prAd->SdioStatistics.TxCount = 0;
	prAd->SdioStatistics.TxR0 = 0;
	prAd->SdioStatistics.TxR1 = 0;
	prAd->SdioStatistics.TxR2 = 0;
	prAd->SdioStatistics.TxR3 = 0;
	prAd->SdioStatistics.TxLenMax = 0;
	prAd->SdioStatistics.TxRdyMax = 0;
#endif
#if CFG_SDIO_TX_THREAD
	InitializeQueueHeader(&prTxCtrl->TxFreeList);
	InitializeQueueHeader(&prTxCtrl->TxReadyList);
	NdisAllocateSpinLock(prAd, &prTxCtrl->TxFreeLock);
	NdisAllocateSpinLock(prAd, &prTxCtrl->TxReadyLock);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: sizeof(TX_RFB_T) is %lu\n", __func__, sizeof(TX_RFB_T)));

	for (i = SDIO_TX_FREE_NUM; i != 0; i--) {
		os_alloc_mem(prAd, (UCHAR **)&pTxRfb, sizeof(TX_RFB_T));

		if (!pTxRfb) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: MEM ALLOC ERROR\n", __func__));
			break;
		}

		RTMP_IRQ_LOCK(&prTxCtrl->TxFreeLock, flags);
		InsertTailQueue(&prTxCtrl->TxFreeList, &pTxRfb->rQueEntry);
		RTMP_IRQ_UNLOCK(&prTxCtrl->TxFreeLock, flags);
	}

	RTMP_OS_TASKLET_INIT(prAd, &pObj->SdioRxdonetask, RxDoneTasklet, (unsigned long)prAd);
#endif
	return;
}

VOID
MTSDIOTxUninitialize(
	IN PRTMP_ADAPTER prAd
)
{
	P_TX_CTRL_T prTxCtrl = NULL;
#if CFG_SDIO_TX_THREAD
	unsigned long IrqFlags;
	QUEUE_ENTRY *pEntry;
	P_TX_RFB_T pTxRfb;
#endif
	ASSERT(prAd);
	prTxCtrl = &prAd->rTxCtrl;
	prTxCtrl->pucTxCoalescingBufPtr = NULL;
#if CFG_SDIO_TX_THREAD

	do {
		RTMP_IRQ_LOCK(&prTxCtrl->TxFreeLock, IrqFlags);
		pEntry = RemoveHeadQueue(&prTxCtrl->TxFreeList);
		pTxRfb = (P_TX_RFB_T)pEntry;
		RTMP_IRQ_UNLOCK(&prTxCtrl->TxFreeLock, IrqFlags);

		if (pTxRfb)
			os_free_mem(pTxRfb);
		else
			break;
	} while (TRUE);

	do {
		RTMP_IRQ_LOCK(&prTxCtrl->TxReadyLock, IrqFlags);
		pEntry = RemoveHeadQueue(&prTxCtrl->TxReadyList);
		pTxRfb = (P_TX_RFB_T)pEntry;
		RTMP_IRQ_UNLOCK(&prTxCtrl->TxReadyLock, IrqFlags);

		if (pTxRfb)
			os_free_mem(pTxRfb);
		else
			break;
	} while (TRUE);

	NdisFreeSpinLock(&prTxCtrl->TxFreeLock);
	NdisFreeSpinLock(&prTxCtrl->TxReadyLock);
#endif
	return;
}


VOID MTSDIOTxInitResetResource(
	IN PRTMP_ADAPTER prAd
)
{
	P_TX_CTRL_T prTxCtrl = NULL;
	unsigned long flags = 0;
	int count = 0;
	ASSERT(prAd);
	prTxCtrl = &prAd->rTxCtrl;
	RTMP_SPIN_LOCK_IRQSAVE(&prAd->TcCountLock, &flags);
	NdisZeroMemory(prTxCtrl->rTc.au2TxDonePageCount, sizeof(prTxCtrl->rTc.au2TxDonePageCount));
	prTxCtrl->rTc.ucNextTcIdx = TC0_INDEX;
	prTxCtrl->rTc.u2AvailiablePageCount = 0;
	prTxCtrl->rTc.au2MaxNumOfPage[TC0_INDEX] = SDIO_TX_PAGE_COUNT_TC0;
	prTxCtrl->rTc.au2FreePageCount[TC0_INDEX] = SDIO_TX_PAGE_COUNT_TC0;
	prTxCtrl->rTc.au2MaxNumOfPage[TC1_INDEX] = SDIO_TX_PAGE_COUNT_TC1;
	prTxCtrl->rTc.au2FreePageCount[TC1_INDEX] = SDIO_TX_PAGE_COUNT_TC1;
	prTxCtrl->rTc.au2MaxNumOfPage[TC2_INDEX] = SDIO_TX_PAGE_COUNT_TC2;
	prTxCtrl->rTc.au2FreePageCount[TC2_INDEX] = SDIO_TX_PAGE_COUNT_TC2;
	prTxCtrl->rTc.au2MaxNumOfPage[TC3_INDEX] = SDIO_TX_PAGE_COUNT_TC3;
	prTxCtrl->rTc.au2FreePageCount[TC3_INDEX] = SDIO_TX_PAGE_COUNT_TC3;
	prTxCtrl->rTc.au2MaxNumOfPage[TC4_INDEX] = SDIO_TX_PAGE_COUNT_TC4;
	prTxCtrl->rTc.au2FreePageCount[TC4_INDEX] = SDIO_TX_PAGE_COUNT_TC4;
	prTxCtrl->rTc.au2MaxNumOfPage[TC5_INDEX] = SDIO_TX_PAGE_COUNT_TC5;
	prTxCtrl->rTc.au2FreePageCount[TC5_INDEX] = SDIO_TX_PAGE_COUNT_TC5;
	prTxCtrl->rTc.au2MaxNumOfPage[TC6_INDEX] = SDIO_TX_PAGE_COUNT_TC6;
	prTxCtrl->rTc.au2FreePageCount[TC6_INDEX] = SDIO_TX_PAGE_COUNT_TC6;
	prTxCtrl->rTc.au2MaxNumOfPage[TC7_INDEX] = SDIO_TX_PAGE_COUNT_TC7;
	prTxCtrl->rTc.au2FreePageCount[TC7_INDEX] = SDIO_TX_PAGE_COUNT_TC7;
#if 0
	prTxCtrl->rTc.au2MinReservedTcResource[TC0_INDEX] = SDIO_MIN_RESERVED_TC0_RESOURCE;
	prTxCtrl->rTc.au2MinReservedTcResource[TC1_INDEX] = SDIO_MIN_RESERVED_TC1_RESOURCE;
	prTxCtrl->rTc.au2MinReservedTcResource[TC2_INDEX] = SDIO_MIN_RESERVED_TC2_RESOURCE;
	prTxCtrl->rTc.au2MinReservedTcResource[TC3_INDEX] = SDIO_MIN_RESERVED_TC3_RESOURCE;
	prTxCtrl->rTc.au2MinReservedTcResource[TC4_INDEX] = SDIO_MIN_RESERVED_TC4_RESOURCE;
	prTxCtrl->rTc.au2MinReservedTcResource[TC5_INDEX] = SDIO_MIN_RESERVED_TC5_RESOURCE;
	prTxCtrl->rTc.au2MinReservedTcResource[TC6_INDEX] = SDIO_MIN_RESERVED_TC6_RESOURCE;
#endif
#ifdef MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL
	prTxCtrl->rTc.au2GuaranteedTcResource[TC0_INDEX] = SDIO_GUARANTEED_TC0_RESOURCE;
	prTxCtrl->rTc.au2GuaranteedTcResource[TC1_INDEX] = SDIO_GUARANTEED_TC1_RESOURCE;
	prTxCtrl->rTc.au2GuaranteedTcResource[TC2_INDEX] = SDIO_GUARANTEED_TC2_RESOURCE;
	prTxCtrl->rTc.au2GuaranteedTcResource[TC3_INDEX] = SDIO_GUARANTEED_TC3_RESOURCE;
	prTxCtrl->rTc.au2GuaranteedTcResource[TC4_INDEX] = SDIO_GUARANTEED_TC4_RESOURCE;
	prTxCtrl->rTc.au2GuaranteedTcResource[TC5_INDEX] = SDIO_GUARANTEED_TC5_RESOURCE;
	prTxCtrl->rTc.au2GuaranteedTcResource[TC6_INDEX] = SDIO_GUARANTEED_TC6_RESOURCE;
	prTxCtrl->rTc.au2GuaranteedTcResource[TC7_INDEX] = SDIO_GUARANTEED_TC7_RESOURCE;

	for (count = 0; count < NUM_ADJUSTABLE_TC; count++) {
		prTxCtrl->rTc.au2AvgDemand[count] = 0;
		prTxCtrl->rTc.au2CurrentTcResource[count] = 0;
	}

	prTxCtrl->rTc.u2TimeToAdjustTcResource = SDIO_INIT_TIME_TO_ADJUST_TC_RSC;
	prTxCtrl->rTc.u2TimeToUpdateQueLen = SDIO_INIT_TIME_TO_UPDATE_QUE_LEN;
	prTxCtrl->rTc.fgTcResourcePostAnnealing = FALSE;
#endif /* !MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL */
	RTMP_SPIN_UNLOCK_IRQRESTORE(&prAd->TcCountLock, &flags);
	return;
}

VOID
MTSDIOTxResetResource(
	IN PRTMP_ADAPTER prAd
)
{
	P_TX_CTRL_T prTxCtrl = NULL;
	unsigned long flags = 0;
	ASSERT(prAd);
	prTxCtrl = &prAd->rTxCtrl;
	RTMP_SPIN_LOCK_IRQSAVE(&prAd->TcCountLock, &flags);
	NdisZeroMemory(prTxCtrl->rTc.au2TxDonePageCount, sizeof(prTxCtrl->rTc.au2TxDonePageCount));
	prTxCtrl->rTc.ucNextTcIdx = TC0_INDEX;
	prTxCtrl->rTc.u2AvailiablePageCount = 0;
	prTxCtrl->rTc.au2MaxNumOfPage[TC0_INDEX] = SDIO_TX_PAGE_COUNT_TC0;
	prTxCtrl->rTc.au2FreePageCount[TC0_INDEX] = SDIO_TX_PAGE_COUNT_TC0;
	prTxCtrl->rTc.au2MaxNumOfPage[TC1_INDEX] = SDIO_TX_PAGE_COUNT_TC1;
	prTxCtrl->rTc.au2FreePageCount[TC1_INDEX] = SDIO_TX_PAGE_COUNT_TC1;
	prTxCtrl->rTc.au2MaxNumOfPage[TC2_INDEX] = SDIO_TX_PAGE_COUNT_TC2;
	prTxCtrl->rTc.au2FreePageCount[TC2_INDEX] = SDIO_TX_PAGE_COUNT_TC2;
	prTxCtrl->rTc.au2MaxNumOfPage[TC3_INDEX] = SDIO_TX_PAGE_COUNT_TC3;
	prTxCtrl->rTc.au2FreePageCount[TC3_INDEX] = SDIO_TX_PAGE_COUNT_TC3;
	prTxCtrl->rTc.au2MaxNumOfPage[TC4_INDEX] = SDIO_TX_PAGE_COUNT_TC4;
	prTxCtrl->rTc.au2FreePageCount[TC4_INDEX] = SDIO_TX_PAGE_COUNT_TC4;
	prTxCtrl->rTc.au2MaxNumOfPage[TC5_INDEX] = SDIO_TX_PAGE_COUNT_TC5;
	prTxCtrl->rTc.au2FreePageCount[TC5_INDEX] = SDIO_TX_PAGE_COUNT_TC5;
	prTxCtrl->rTc.au2MaxNumOfPage[TC6_INDEX] = SDIO_TX_PAGE_COUNT_TC6;
	prTxCtrl->rTc.au2FreePageCount[TC6_INDEX] = SDIO_TX_PAGE_COUNT_TC6;
	prTxCtrl->rTc.au2MaxNumOfPage[TC7_INDEX] = SDIO_TX_PAGE_COUNT_TC7;
	prTxCtrl->rTc.au2FreePageCount[TC7_INDEX] = SDIO_TX_PAGE_COUNT_TC7;
	RTMP_SPIN_UNLOCK_IRQRESTORE(&prAd->TcCountLock, &flags);
	return;
}

UINT8
MTSDIOTxGetCmdResourceType(
	IN PRTMP_ADAPTER prAd
)
{
	return TC6_INDEX;
}

INT32
MTSDIOTxAcquireResource(
	IN PRTMP_ADAPTER prAd,
	IN UINT8       ucTC,
	IN UINT8       ucPageCount
)
{
	P_TX_CTRL_T prTxCtrl = NULL;
	INT32 u4Ret = NDIS_STATUS_FAILURE;
	unsigned long flags = 0;
	prTxCtrl = &prAd->rTxCtrl;
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("b MTSDIOTxAcquireResource ucTC:%x ucPageCount: %x fp:%x\n",
			 ucTC, ucPageCount, prTxCtrl->rTc.au2FreePageCount[ucTC]));
	RTMP_SPIN_LOCK_IRQSAVE(&prAd->TcCountLock, &flags);

	if (prTxCtrl->rTc.au2FreePageCount[ucTC] >= ucPageCount) {
		prTxCtrl->rTc.au2FreePageCount[ucTC] -= ucPageCount;
#ifdef MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL
#if DEBUG_ADAPTIVE_QUOTA
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRAC, ("%s: ucTC:%x ucPageCount: %x fp:%x\n",
				 __func__, ucTC, ucPageCount, prTxCtrl->rTc.au2FreePageCount[ucTC]));
#endif
#endif
		u4Ret = NDIS_STATUS_SUCCESS;
	} else {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: No Tx resource!!! ucTC:%x ucPageCount: %x fp:%x\n",
				 __func__, ucTC, ucPageCount, prTxCtrl->rTc.au2FreePageCount[ucTC]));
	}

	RTMP_SPIN_UNLOCK_IRQRESTORE(&prAd->TcCountLock, &flags);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("a MTSDIOTxAcquireResource ucTC:%x ucPageCount: %x fp:%x\n",
			 ucTC, ucPageCount, prTxCtrl->rTc.au2FreePageCount[ucTC]));
	return u4Ret;
}

UINT32
sdio_get_tx_resource_free_num(
	PRTMP_ADAPTER prAd,
	UINT8 ucTC
)
{
	P_TX_CTRL_T prTxCtrl = NULL;
	/* unsigned long flags = 0; */
	prTxCtrl = &prAd->rTxCtrl;
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("%s: Query TC:%d ,Free Page Count %d\n", __func__, ucTC, prTxCtrl->rTc.au2FreePageCount[ucTC]));
	/* For read, we don't need to acquire spin lock */
	return prTxCtrl->rTc.au2FreePageCount[ucTC];
}

EXPORT_SYMBOL(MTSDIOTxQueryPageResource);


UINT8
MTSDIOTxGetPageCount(
	IN UINT32 u4FrameLength,
	IN BOOLEAN fgIncludeDesc
)
{
	UINT32 u4RequiredBufferSize = 0;
	UINT8  ucPageCount = 0;

	/* Frame Buffer
	 *  |<--Tx Descriptor-->|<--Tx descriptor padding-->|<--802.3/802.11 Header-->|<--Header padding-->|<--Payload-->|
	 */
	if (fgIncludeDesc)
		u4RequiredBufferSize = u4FrameLength;
	else {
		u4RequiredBufferSize =
			SDIO_TX_DESC_LONG_FORMAT_LENGTH +
			SDIO_TX_DESC_PADDING_LENGTH +
			u4FrameLength;
	}

	if (SDIO_TX_PAGE_SIZE_IS_POWER_OF_2)
		ucPageCount = (UINT8)((u4RequiredBufferSize + (SDIO_TX_PAGE_SIZE - 1)) >> SDIO_TX_PAGE_SIZE_IN_POWER_OF_2);
	else
		ucPageCount = (UINT8)((u4RequiredBufferSize + (SDIO_TX_PAGE_SIZE - 1)) / SDIO_TX_PAGE_SIZE);

	return ucPageCount;
}

static BOOLEAN
MTSDIOTxCalculateResource(
	IN PRTMP_ADAPTER prAd,
	IN UINT16 * au2TxRlsCnt,
	OUT UINT16 * au2FreeTcResource
)
{
	P_TX_TCQ_STATUS_T prTcqStatus = NULL;
	UINT16 u2TotalTxDonePageCount = 0;
	UINT8 ucTcIdx = 0;
	BOOLEAN bStatus = FALSE;
	prTcqStatus = &prAd->rTxCtrl.rTc;
	prTcqStatus->u2AvailiablePageCount += au2TxRlsCnt[HIF_TX_FFA_INDEX];

	for (ucTcIdx = TC0_INDEX; ucTcIdx < TC_NUM; ucTcIdx++) {
		prTcqStatus->au2TxDonePageCount[ucTcIdx] += au2TxRlsCnt[arTcResourceControl[ucTcIdx].ucHifTxQIndex];
		u2TotalTxDonePageCount += prTcqStatus->au2TxDonePageCount[ucTcIdx];
	}

	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("Tx Done INT result, FFA[%u] AC[%u:%u:%u:%u:%u] BCN[%u] BMC[%u] CPU[%u]\n",
			 au2TxRlsCnt[HIF_TX_FFA_INDEX],
			 au2TxRlsCnt[HIF_TX_AC0_INDEX],
			 au2TxRlsCnt[HIF_TX_AC1_INDEX],
			 au2TxRlsCnt[HIF_TX_AC2_INDEX],
			 au2TxRlsCnt[HIF_TX_AC3_INDEX],
			 au2TxRlsCnt[HIF_TX_AC4_INDEX],
			 au2TxRlsCnt[HIF_TX_BCN_INDEX],
			 au2TxRlsCnt[HIF_TX_BMC_INDEX],
			 au2TxRlsCnt[HIF_TX_CPU_INDEX]));

	if (prTcqStatus->u2AvailiablePageCount) {
		if (prTcqStatus->u2AvailiablePageCount >= u2TotalTxDonePageCount) {
			NdisCopyMemory(au2FreeTcResource, prTcqStatus->au2TxDonePageCount,
						   sizeof(prTcqStatus->au2TxDonePageCount));
			NdisZeroMemory(prTcqStatus->au2TxDonePageCount,
						   sizeof(prTcqStatus->au2TxDonePageCount));
			prTcqStatus->u2AvailiablePageCount -= u2TotalTxDonePageCount;

			if (prTcqStatus->u2AvailiablePageCount) {
			}
		} else {
			ucTcIdx = prTcqStatus->ucNextTcIdx;

			while (prTcqStatus->u2AvailiablePageCount) {
				if (prTcqStatus->u2AvailiablePageCount >= prTcqStatus->au2TxDonePageCount[ucTcIdx]) {
					au2FreeTcResource[ucTcIdx] = prTcqStatus->au2TxDonePageCount[ucTcIdx];
					prTcqStatus->u2AvailiablePageCount -= prTcqStatus->au2TxDonePageCount[ucTcIdx];
					prTcqStatus->au2TxDonePageCount[ucTcIdx] = 0;
					ucTcIdx++;
					ucTcIdx %= TC_NUM;
				} else {
					au2FreeTcResource[ucTcIdx] = prTcqStatus->u2AvailiablePageCount;
					prTcqStatus->au2TxDonePageCount[ucTcIdx] -= prTcqStatus->u2AvailiablePageCount;
					prTcqStatus->u2AvailiablePageCount = 0;
				}
			}

			prTcqStatus->ucNextTcIdx = ucTcIdx;
		}

		bStatus = TRUE;
	} else
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("No FFA count to release\n"));

	return bStatus;
}

BOOLEAN
MTSDIOTxReleaseResource(
	IN PRTMP_ADAPTER prAd,
	IN UINT16       *au2TxRlsCnt
)
{
	P_TX_TCQ_STATUS_T prTcqStatus = NULL;
	BOOLEAN bStatus = FALSE;
	UINT16 au2FreeTcResource[TC_NUM] = {0};
	/* UINT32 u4BufferCountToBeFeed = 0; */
	UINT8 i = 0;
	unsigned long flags = 0;
	prTcqStatus = &prAd->rTxCtrl.rTc;

	if (MTSDIOTxCalculateResource(prAd, au2TxRlsCnt, au2FreeTcResource)) {
		RTMP_SPIN_LOCK_IRQSAVE(&prAd->TcCountLock, &flags);

		for (i = TC0_INDEX; i < TC_NUM; i++) {
			/* Real page counter */
			prTcqStatus->au2FreePageCount[i] += au2FreeTcResource[i];
#if 0
			/* Buffer counter. For development only */
			/* Convert page count to buffer count */
			u4BufferCountToBeFeed = (prTcqStatus->au2FreePageCount[i] / SDIO_TX_MAX_PAGE_PER_FRAME);
			prTcqStatus->au2FreeBufferCount[i] = u4BufferCountToBeFeed;

			if (au2FreeTcResource[i]) {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("Release: TC%u ReturnPageCnt[%u] FreePageCnt[%u] FreeBufferCnt[%u]\n",
						 i,
						 au2FreeTcResource[i],
						 prTcqStatus->au2FreePageCount[i],
						 prTcqStatus->au2FreeBufferCount[i]));
			}

#endif

			if (au2FreeTcResource[i]) {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("Release: TC%u ReturnPageCnt[%u] FreePageCnt[%u]\n",
						 i,
						 au2FreeTcResource[i],
						 prTcqStatus->au2FreePageCount[i]));
			}
		}

		RTMP_SPIN_UNLOCK_IRQRESTORE(&prAd->TcCountLock, &flags);
		bStatus = TRUE;
	}

	return bStatus;
}

#if CFG_SDIO_INTR_ENHANCE

void  MTSDIOReadIntStatus(IN PRTMP_ADAPTER prAd, OUT PUINT32 pu4IntStatus)
{
	INT32 u4Ret = 0;
	P_ENHANCE_MODE_DATA_STRUCT_T pebancestatus;
	pebancestatus = prAd->penhanced_status;
	u4Ret = MTSDIOMultiRead(prAd, WHISR, (PUCHAR)pebancestatus
							, sizeof(ENHANCE_MODE_DATA_STRUCT_T));

	/* pebancestatus = (P_ENHANCE_MODE_DATA_STRUCT_T)prAd->enhanced_status; */

	/* *pu4IntStatus = pebancestatus->u4WHISR; */

	if ((*pu4IntStatus)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, (" ==>%s hisr:%x num0:%x num1:%x r0len0:%x r0len1:%x r1len0:%x r1len1:%x txqcnt: %x %x %x %x %x %x %x %x\n"
				 , __func__, pebancestatus->u4WHISR
				 , pebancestatus->rRxInfo.u.u2NumValidRx0Len
				 , pebancestatus->rRxInfo.u.u2NumValidRx1Len
				 , pebancestatus->rRxInfo.u.au2Rx0Len[0]
				 , pebancestatus->rRxInfo.u.au2Rx0Len[1]
				 , pebancestatus->rRxInfo.u.au2Rx1Len[0]
				 , pebancestatus->rRxInfo.u.au2Rx1Len[1]
				 , pebancestatus->rTxInfo.au4WTSR[0]
				 , pebancestatus->rTxInfo.au4WTSR[1]
				 , pebancestatus->rTxInfo.au4WTSR[2]
				 , pebancestatus->rTxInfo.au4WTSR[3]
				 , pebancestatus->rTxInfo.au4WTSR[4]
				 , pebancestatus->rTxInfo.au4WTSR[5]
				 , pebancestatus->rTxInfo.au4WTSR[6]
				 , pebancestatus->rTxInfo.au4WTSR[7]
														 ));
	}

	/* Workaround:
	When RX done (without TX done happened), TX INT comes later
	   . We already read the TC and cause TX INT disappear.
	  We need to OR the TX_DONE_INT bit manually to workaound this corner case
	*/
	if ((pebancestatus->u4WHISR & TX_DONE_INT) == 0 &&
		(pebancestatus->rTxInfo.au4WTSR[0] |
		 pebancestatus->rTxInfo.au4WTSR[1] |
		 pebancestatus->rTxInfo.au4WTSR[2] |
		 pebancestatus->rTxInfo.au4WTSR[3] |
		 pebancestatus->rTxInfo.au4WTSR[4] |
		 pebancestatus->rTxInfo.au4WTSR[5] |
		 pebancestatus->rTxInfo.au4WTSR[6] |
		 pebancestatus->rTxInfo.au4WTSR[7]))
		pebancestatus->u4WHISR |= TX_DONE_INT;

	*pu4IntStatus = pebancestatus->u4WHISR;
	/* mtk03034 TODO: add for mailbox case, consider if mailbox INT. is read clear */
	return;
}
#endif

VOID
MTSDIOProcessIST_impl(
	IN PRTMP_ADAPTER prAd,
	IN UINT32 u4IntStatus
)
{
	UINT32 u4IntCount = 0;
	P_INT_EVENT_MAP_T prIntEventMap = NULL;
	ASSERT(prAd);
	prAd->IntStatus = u4IntStatus;
	prIntEventMap = &arIntEventMapTable[0];

	for (u4IntCount = 0; u4IntCount < ucIntEventMapSize; prIntEventMap++, u4IntCount++) {
		if (prIntEventMap->u4Int & prAd->IntStatus) {
			if (apfnEventFuncTable[prIntEventMap->u4Event] != NULL) {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("Process IST !"));
				apfnEventFuncTable[prIntEventMap->u4Event](prAd);
			} else {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("Empty INT handler !"));
				ASSERT(0);
			}

			prAd->IntStatus &= ~prIntEventMap->u4Int;
		}
	}
}


VOID
MTSDIOProcessIST(
	IN PRTMP_ADAPTER prAd
)
{
	UINT32 u4IntStatus = 0;
#if CFG_SDIO_INTR_ENHANCE
	MTSDIOReadIntStatus(prAd, &u4IntStatus);
#else
	MTSDIORead32(prAd, WHISR, &u4IntStatus);
#endif
	/* MTSDIORead32(prAd, WHIER, &u4Val); */

	/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("MTSDIOProcessIST prAd:%p prAd->IntStatus: %x WHIER: %x\n", prAd, u4IntStatus,u4Val)); */

	if (u4IntStatus & ~(WHIER_DEFAULT | FW_OWN_BACK_INT_EN)) {
		u4IntStatus &= WHIER_DEFAULT;
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("(%s): unknown interrupt: %x\n", __func__, u4IntStatus));
	}

	MTSDIOProcessIST_impl(prAd, u4IntStatus);
}

VOID
MTSDIOProcessSoftwareInterrupt(
	IN PRTMP_ADAPTER prAd
)
{
	return;
}

VOID
MTSDIOProcessAbnormalInterrupt(
	IN PRTMP_ADAPTER prAd
)
{
	return;
}

VOID
MTSDIOProcessTxInterrupt(
	IN PRTMP_ADAPTER prAd
)
{
	struct MCU_CTRL *prCtl = NULL;
#if CFG_SDIO_INTR_ENHANCE
	P_ENHANCE_MODE_DATA_STRUCT_T prEnhance = prAd->penhanced_status;
	UINT16 u2CPUCnt = 0;
#else
	INT32 au4TxCount[8];
	UINT8 ucTcIndex = 0;
	UINT32 u4Cnt = 0;
#endif
	struct cmd_msg *prMsg = NULL;
#if CFG_SDIO_TX_THREAD
	POS_COOKIE pObj = (POS_COOKIE) prAd->OS_Cookie;
#endif
	ASSERT(prAd);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("prAd %p\n", prAd));
	prCtl = &prAd->MCUCtrl;
#if CFG_SDIO_INTR_ENHANCE
	MTSDIOTxReleaseResource(prAd, (PUINT16) & (prEnhance->rTxInfo));
#ifdef CONFIG_ATE

	if (ATE_ON(prAd))
		prAd->ATECtrl.txed_pg = prEnhance->rTxInfo.u.u2TQ1Cnt;

#endif /* CONFIG_ATE */
	u2CPUCnt = prEnhance->rTxInfo.u.u2TQ15Cnt;
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("==== TC %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x===\n",
			 prEnhance->rTxInfo.u.u2TQ0Cnt,
			 prEnhance->rTxInfo.u.u2TQ1Cnt,
			 prEnhance->rTxInfo.u.u2TQ2Cnt,
			 prEnhance->rTxInfo.u.u2TQ3Cnt,
			 prEnhance->rTxInfo.u.u2TQ4Cnt,
			 prEnhance->rTxInfo.u.u2TQ5Cnt,
			 prEnhance->rTxInfo.u.u2TQ6Cnt,
			 prEnhance->rTxInfo.u.u2TQ7Cnt,
			 prEnhance->rTxInfo.u.u2TQ8Cnt,
			 prEnhance->rTxInfo.u.u2TQ9Cnt,
			 prEnhance->rTxInfo.u.u2TQ10Cnt,
			 prEnhance->rTxInfo.u.u2TQ11Cnt,
			 prEnhance->rTxInfo.u.u2TQ12Cnt,
			 prEnhance->rTxInfo.u.u2TQ13Cnt,
			 prEnhance->rTxInfo.u.u2TQ14Cnt,
			 prEnhance->rTxInfo.u.u2TQ15Cnt));
	NdisZeroMemory(&(prEnhance->rTxInfo), sizeof(prEnhance->rTxInfo));
#else
	MTSDIORead32(prAd, WTQCR0, &au4TxCount[0]);
	MTSDIORead32(prAd, WTQCR1, &au4TxCount[1]);
	MTSDIORead32(prAd, WTQCR2, &au4TxCount[2]);
	MTSDIORead32(prAd, WTQCR3, &au4TxCount[3]);
	MTSDIORead32(prAd, WTQCR4, &au4TxCount[4]);
	MTSDIORead32(prAd, WTQCR5, &au4TxCount[5]);
	MTSDIORead32(prAd, WTQCR6, &au4TxCount[6]);
	MTSDIORead32(prAd, WTQCR7, &au4TxCount[7]);
	MTSDIORead32(prAd, WHCR, &u4Cnt);
#ifdef CONFIG_ATE

	if (ATE_ON(prAd))
		prAd->ATECtrl.txed_pg = au4TxCount[1];

#endif /* CONFIG_ATE */
	MTSDIOTxReleaseResource(prAd, (PUINT16) au4TxCount);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("==== TC %x %x %x %x %x %x %x %x WHCR: %x===\n",
			 au4TxCount[0],
			 au4TxCount[1],
			 au4TxCount[2],
			 au4TxCount[3],
			 au4TxCount[4],
			 au4TxCount[5],
			 au4TxCount[6],
			 au4TxCount[7], u4Cnt));
#endif
#ifdef MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL
	MTAdjustTcQuotas(prAd);
#endif

	/* TODO: check ackq or kickq */
	if (u2CPUCnt > 0) {
		if (AndesQueueLen(prCtl, &prCtl->ackq) > 0) {
			prMsg = AndesDequeueCmdMsg(prCtl, &prCtl->ackq);

			if (prMsg) {
				AndesQueueHeadCmdMsg(&prCtl->ackq, prMsg, prMsg->state);
				SdioKickOutCmdMsgComplete(prMsg);
			}
		} else if (AndesQueueLen(prCtl, &prCtl->kickq) > 0) {
			prMsg = AndesDequeueCmdMsg(prCtl, &prCtl->kickq);

			if (prMsg) {
				AndesQueueHeadCmdMsg(&prCtl->kickq, prMsg, prMsg->state);
				RTMP_OS_COMPLETE(&prMsg->tx_sdio_done); /* 0627-Leonardo */
			}
		}
	}

	/* pending CMD */
#if 0

	if (AndesQueueLen(prCtl, &prCtl->txq_sdio) > 0)
		MTSDIOWorkerThreadEventNotify(prAd, SDIO_EVENT_CMD_BIT);

#endif

	/* pending Mgmt. frame */
	if ((MGMT_RING_SIZE - prAd->MgmtRing.TxSwFreeIdx) > 0)
		MTSDIOWorkerThreadEventNotify(prAd, SDIO_EVENT_TXREQ_BIT);

	/* TODO: mtk03034 pending Tx frame (need to review)*/
	{
		ULONG u4IrqFlags = 0;
		INT i4deq_id = 0, i4enq_id = 0;
		UINT32 u4i = 0;
		struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(prAd->hdev_ctrl);
		UINT8 num_of_tx_ring = GET_NUM_OF_TX_RING(cap);

		RTMP_IRQ_LOCK(&prAd->irq_lock, u4IrqFlags);

		for (u4i = 0; u4i < num_of_tx_ring; u4i++) {
			i4deq_id = prAd->tx_swq[u4i].deqIdx;
			i4enq_id = prAd->tx_swq[u4i].enqIdx;

			if (prAd->tx_swq[u4i].swq[i4deq_id] != 0) {
#if CFG_SDIO_TX_THREAD
				RTMP_OS_TASKLET_SCHE(&pObj->SdioRxdonetask);
#else
				MTSDIOWorkerThreadEventNotify(prAd, SDIO_EVENT_TX_DATA_REQ_BIT);
#endif
				break;
			}
		}

		RTMP_IRQ_UNLOCK(&prAd->irq_lock, u4IrqFlags);
	}
#ifdef CONFIG_ATE

	if ((ATE_ON(prAd))) {
		struct _ATE_CTRL *ATECtrl = &prAd->ATECtrl;
		BOOLEAN transmitted = FALSE;

		if (ATECtrl->Mode & ATE_TXFRAME) {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ATECtrl.Mode:%x,TxCount=%u, DoneCount=%u, Txed_pg:0x%x, tx_pg:0x%x\n", __func__,
					 ATECtrl->Mode, ATECtrl->TxCount, ATECtrl->TxDoneCount, ATECtrl->txed_pg, ATECtrl->tx_pg));

			if (ATECtrl->txed_pg >= ATECtrl->tx_pg) {
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, receive all the tx page\n", __func__));
				ATECtrl->TxDoneCount += ATECtrl->agg_num;
				ATECtrl->tx_pg = 0;
				transmitted = TRUE;
			} else {
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, NOT receive all the tx page yet\n", __func__));
				ATECtrl->tx_pg -= ATECtrl->txed_pg;
			}

			if ((ATECtrl->Mode & ATE_TXFRAME)
				&& ((ATECtrl->TxDoneCount < ATECtrl->TxCount) || (ATECtrl->TxCount == 0))
				&& transmitted) {
				struct _ATE_IF_OPERATION *if_ops = ATECtrl->ATEIfOps;

				if (if_ops->test_frame_tx)
					if_ops->test_frame_tx(prAd);

				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Tx another, PgCnt:0x%x\n", ATECtrl->tx_pg));
			} else if ((ATECtrl->TxStatus == 1)
					   && (ATECtrl->TxDoneCount >= ATECtrl->TxCount)) {
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("All Tx is done\n"));
				/* Tx status enters idle mode.*/
				ATECtrl->TxStatus = 0;
			} else
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Not ATE Packet Test TxQ Event, tc:0x%x\n", prEnhance->rTxInfo.u.u2TQ0Cnt));
		}
	}

#endif /* CONFIG_ATE */
	return;
}

VOID
MTSDIOProcessRxInterrupt(
	IN PRTMP_ADAPTER prAd
)
{
	ASSERT(prAd);
#if (CFG_SDIO_RX_AGG == 0) && (CFG_SDIO_INTR_ENHANCE == 0)
	MTSDIORxReadBuffer(prAd);
#elif(CFG_SDIO_RX_AGG == 0) && (CFG_SDIO_INTR_ENHANCE == 1)
	MTSDIORxEnhancedReadBuffer(prAd);
#elif(CFG_SDIO_RX_AGG == 1) && (CFG_SDIO_INTR_ENHANCE == 1)
	MTSDIORxEnhancedAggReadBuffer(prAd);
#endif
}


INT32
MTSDIOCmdTx(
	IN PRTMP_ADAPTER prAd,
	IN UCHAR *prBuf,
	IN UINT32 u4Length
)
{
	/* printk("(%s) enter\n", __func__); */
	INT32 u4Ret = 0;
	u4Ret = MTSDIOMultiWrite(prAd, WTDR1, prBuf, u4Length);
	return u4Ret;
}


INT32
MTSDIODataTx(
	IN PRTMP_ADAPTER prAd,
	IN UCHAR *prBuf,
	IN UINT32 u4Length
)
{
	INT32 u4Ret = 0;
	u4Ret = MTSDIOMultiWrite(prAd, WTDR1, prBuf, u4Length);
	return u4Ret;
}


INT32
MTSDIODataRx0(
	IN PRTMP_ADAPTER prAd,
	OUT UCHAR *prBuf,
	IN UINT32 u4Length
)
{
	INT32 u4Ret = 0;
	u4Ret = MTSDIOMultiRead(prAd, WRDR0, prBuf, u4Length);
	return u4Ret;
}


INT32
MTSDIODataRx1(
	IN PRTMP_ADAPTER prAd,
	OUT UCHAR *prBuf,
	IN UINT32 u4Length
)
{
	INT32 u4Ret = 0;
	u4Ret = MTSDIOMultiRead(prAd, WRDR1, prBuf, u4Length);
	return u4Ret;
}


#if (CFG_SDIO_RX_AGG == 0) && (CFG_SDIO_INTR_ENHANCE == 0)

INT32 MTSDIORxReadBuffer(
	IN PRTMP_ADAPTER prAd
)
{
	UINT32 u4i = 0;
	PUCHAR prBuf = NULL;
	UINT32 u4Value = 0;
	UINT32 u4RX0PacketLen = 0, u4RX1PacketLen = 0;
	UINT32 u4Length = 0;
	UINT32 u4ReadLength = 0;
	UINT8  ucRxNum = 0;
	RTMP_ARCH_OP *op = &prAd->archOps;
	ASSERT(prAd);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("%s: =============>\n", __func__));

	if ((RTMP_TEST_FLAG(prAd, (
							fRTMP_ADAPTER_HALT_IN_PROGRESS |
							fRTMP_ADAPTER_NIC_NOT_EXIST)) ||
		 (!RTMP_TEST_FLAG(prAd, fRTMP_ADAPTER_START_UP)))
		&& (!RTMP_TEST_FLAG(prAd, fRTMP_ADAPTER_POLL_IDLE)))
		break;

	MTSDIORead32(prAd, WRPLR, &u4Value);
	u4RX0PacketLen = GET_RX0_PACKET_LENGTH(u4Value);
	u4RX1PacketLen = GET_RX1_PACKET_LENGTH(u4Value);

	if (u4RX0PacketLen > 0) {
		ucRxNum = 0;
		u4Length = u4RX0PacketLen;
	} else {
		ucRxNum = 1;
		u4Length = u4RX1PacketLen;
	}

	if (u4Length == 0) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("(%s): RX done, but No RX pkt\n", __func__));
		return -1;
	}

#if 0

	if (u4Length >= prAd->BlockSize)
		u4Length = (u4Length + ((-u4Length) & (prAd->BlockSize - 1)));

#endif
	prAd->SDIORxPacket = RTMP_AllocateFragPacketBuffer(prAd, SDIO_TX_MAX_SIZE_PER_FRAME);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("%s: =============>\n", __func__));

	if (!prAd->SDIORxPacket) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: allocate net packet fail\n",
				 __func__));
		return -1;
	}

#if 0
	/* Read Entire RFB and packet, include HW appended DW (Checksum Status) */
	u4ReadLength = (((u4Length) + 3) & ~3u) + 4;
#else
	u4ReadLength = (((u4Length) + 3) & ~3u);
#endif

	if (ucRxNum == 0)
		MTSDIODataRx0(prAd, GET_OS_PKT_DATAPTR(prAd->SDIORxPacket), u4ReadLength);
	else
		MTSDIODataRx1(prAd, GET_OS_PKT_DATAPTR(prAd->SDIORxPacket), u4ReadLength);

	/* SET_OS_PKT_LEN(prAd->SDIORxPacket, u4ReadLength); */
	SET_OS_PKT_LEN(prAd->SDIORxPacket, u4Length);
	prBuf = GET_OS_PKT_DATAPTR(prAd->SDIORxPacket);
	prAd->fgSDIORxPacKetInUsed = TRUE;
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("%s: ================len = %x ===\n", __func__, u4Length));
#if 0

	for (u4i = 0; u4i < u4Length; u4i++)
		printk("%x,", *(prBuf + u4i));

	printk("\n");
#endif

	if (RTMP_TEST_FLAG(prAd, fRTMP_ADAPTER_HALT_IN_PROGRESS |
					   fRTMP_ADAPTER_NIC_NOT_EXIST)) {
		RTMPFreeNdisPacket(prAd, prAd->SDIORxPacket);
		return -1;
	}

#if CFG_SDIO_RX_THREAD
	MTSDIORxThreadEventNotify(prAd, SDIO_RXEVENT_BIT);
#else
	op->rx_done_handle(prAd);
#endif
	return 0;
}
#elif(CFG_SDIO_RX_AGG == 0) && (CFG_SDIO_INTR_ENHANCE == 1)

INT32 MTSDIORxEnhancedReadBuffer(IN PRTMP_ADAPTER prAd)
{
	UINT32 u4i = 0;
	UINT32 u4k = 0;
	PUCHAR prBuf = NULL;
	UINT32 u4Value = 0;
	UINT32 u4RX0PacketLen = 0, u4RX1PacketLen = 0;
	UINT32 u4Length = 0;
	UINT32 u4ReadLength = 0;
	UINT8  ucRxNum = 0;
	UINT32 rxNum;
	UINT16 u2RxPktNum;
	P_ENHANCE_MODE_DATA_STRUCT_T prSDIOCtrl;
	P_SW_RFB_T prSwRfb;
	P_RX_CTRL_T prRxCtrl = NULL;
	unsigned long IrqFlags;
	QUEUE_HEADER *pEntry;
	RTMP_ARCH_OP *op = &prAd->archOps;
	ASSERT(prAd);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("%s: =============>\n", __func__));
	prSDIOCtrl = prAd->penhanced_status;
	prRxCtrl = &prAd->rRxCtrl;

	if ((RTMP_TEST_FLAG(prAd, (
							fRTMP_ADAPTER_HALT_IN_PROGRESS |
							fRTMP_ADAPTER_NIC_NOT_EXIST)) ||
		 (!RTMP_TEST_FLAG(prAd, fRTMP_ADAPTER_START_UP)))
		&& (!RTMP_TEST_FLAG(prAd, fRTMP_ADAPTER_POLL_IDLE)))
		break;

	for (rxNum = 0; rxNum < 2; rxNum++) {
		u2RxPktNum = (rxNum == 0 ? prSDIOCtrl->rRxInfo.u.u2NumValidRx0Len : prSDIOCtrl->rRxInfo.u.u2NumValidRx1Len);
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("%s: ====rxNum: %x u2RxPktNum: %x\n", __func__, rxNum, u2RxPktNum));

		if (u2RxPktNum == 0)
			continue;

		for (u4i = 0; u4i < u2RxPktNum; u4i++) {
#if 0
			MTSDIORead32(prAd, WRPLR, &u4Value);
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: WRPLR u4Value: %x\n", __func__, u4Value));
#endif
#if 0

			if (rxNum == 0) {
				u4RX0PacketLen = GET_RX0_PACKET_LENGTH(u4Value);
				u4Length = u4RX0PacketLen;
			} else {
				/* u4RX1PacketLen = GET_RX1_PACKET_LENGTH(u4Value); */
				u4RX1PacketLen = u4Value >> 16;
				u4Length = u4RX1PacketLen;
			}

#else

			if (rxNum == 0)
				u4Length = prSDIOCtrl->rRxInfo.u.au2Rx0Len[0];
			else
				u4Length = prSDIOCtrl->rRxInfo.u.au2Rx1Len[0];

#endif

			/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: WRPLR u4RX0PacketLen: %x u4RX1PacketLen: %x u4Length: %x\n", __func__,u4RX0PacketLen,u4RX1PacketLen,u4Length)); */

			if (u4Length == 0) {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("(%s): RX done, but No RX pkt\n", __func__));
				break;
			}

			u4ReadLength = (((u4Length) + 3) & ~3);
			/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: ====u4Length: %x u4ReadLength: %x num: %x\n",__func__,u4Length, u4ReadLength ,prRxCtrl->rFreeSwRfbList.Number)); */
			RTMP_IRQ_LOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags);
			pEntry = RemoveHeadQueue(&prRxCtrl->rFreeSwRfbList);
			prSwRfb = (P_SW_RFB_T)pEntry;
			RTMP_IRQ_UNLOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags);

			if (!prSwRfb) {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: No More RFB\n", __func__));
				break;
			}

			/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: ====prSwRfb != NULL\n",__func__)); */

			if (rxNum == 0) {
				if (MTSDIODataRx0(prAd, GET_OS_PKT_DATAPTR(prSwRfb->prRxPacket), u4ReadLength)) {
					MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: MTSDIORxEnhancedReadBuffer rx0 failed\n", __func__));
					RTMP_IRQ_LOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags)
					InsertTailQueue(&prRxCtrl->rFreeSwRfbList, &prSwRfb->rQueEntry);
					RTMP_IRQ_UNLOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags);
					break;
				}
			} else {
				if (MTSDIODataRx1(prAd, GET_OS_PKT_DATAPTR(prSwRfb->prRxPacket), u4ReadLength)) {
					MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: MTSDIORxEnhancedReadBuffer rx1 failed\n", __func__));
					RTMP_IRQ_LOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags)
					InsertTailQueue(&prRxCtrl->rFreeSwRfbList, &prSwRfb->rQueEntry);
					RTMP_IRQ_UNLOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags);
					break;
				}
			}

			SET_OS_PKT_LEN(prSwRfb->prRxPacket, u4Length);
			/* prSDIOCtrl->au4RxLength[i] = 0; */
			RTMP_IRQ_LOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags);
			InsertTailQueue(&prRxCtrl->rReceivedRfbList, &prSwRfb->rQueEntry);
			RTMP_IRQ_UNLOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags);
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("%s: InsertTailQueue rReceivedRfbList\n", __func__));
		}
	}

#if CFG_SDIO_RX_THREAD
	MTSDIORxThreadEventNotify(prAd, SDIO_RXEVENT_BIT);
#else
	op->rx_done_handle(prAd);
#endif
	return 0;
}

#elif(CFG_SDIO_RX_AGG == 1) && (CFG_SDIO_INTR_ENHANCE == 1)

INT32 MTSDIORxEnhancedAggReadBuffer(IN PRTMP_ADAPTER prAd)
{
	UINT32 u4i = 0;
	UINT32 u4j = 0;
	UINT32 u4RxLength;
	UINT32 rxNum;
	UINT16 u2RxPktNum;
	P_ENHANCE_MODE_DATA_STRUCT_T prSDIOCtrl;
	P_SW_RFB_T prSwRfb;
	P_RX_CTRL_T prRxCtrl = NULL;
	unsigned long IrqFlags;
	QUEUE_ENTRY *pEntry;
	UINT32 u4RxLengthAlign;
	UINT32 u4RxAvailAggLen;
	UINT32 u4CurrAvailFreeRfbCnt;
	UINT32 u4RxAggCount;
	UINT32 u4RxAggLength;
	PUINT8 pucSrcAddr;
	UINT32 u4RxPktLen;
	UINT16 u2Rxbyte;
	BOOLEAN fReadFail = FALSE;
	BOOLEAN fgIsRxEnhanceMode = FALSE;
#if CFG_SDIO_RX_ENHANCE
	UINT32 u4MaxLoopCount = CFG_MAX_RX_ENHANCE_LOOP_COUNT;
#endif
	RTMP_ARCH_OP *op = &prAd->archOps;
	ASSERT(prAd);
	/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: =============>\n", __func__)); */
	prSDIOCtrl = prAd->penhanced_status;
	prRxCtrl = &prAd->rRxCtrl;
#if CFG_SDIO_RX_ENHANCE
	fgIsRxEnhanceMode = TRUE;
#else
	fgIsRxEnhanceMode = FALSE;
#endif

	do {
#if CFG_SDIO_RX_ENHANCE
		/* to limit maximum loop for RX */
		u4MaxLoopCount--;

		if (u4MaxLoopCount == 0)
			break;

#endif

		if ((RTMP_TEST_FLAG(prAd, (
								fRTMP_ADAPTER_HALT_IN_PROGRESS |
								fRTMP_ADAPTER_NIC_NOT_EXIST)) ||
			 (!RTMP_TEST_FLAG(prAd, fRTMP_ADAPTER_START_UP)))
			&& (!RTMP_TEST_FLAG(prAd, fRTMP_ADAPTER_POLL_IDLE)))
			break;

		if (prSDIOCtrl->rRxInfo.u.u2NumValidRx0Len == 0 &&
			prSDIOCtrl->rRxInfo.u.u2NumValidRx1Len == 0)
			break;

		for (rxNum = 0; rxNum < 2; rxNum++) {
			u2RxPktNum = (rxNum == 0 ? prSDIOCtrl->rRxInfo.u.u2NumValidRx0Len : prSDIOCtrl->rRxInfo.u.u2NumValidRx1Len);

			/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: ====rxNum: %x u2RxPktNum: %x\n", __func__,rxNum,u2RxPktNum)); */

			if (u2RxPktNum > 16)
				continue;

			if (u2RxPktNum == 0)
				continue;

#if CFG_SDIO_RX_ENHANCE
			u4RxAvailAggLen = CFG_RX_COALESCING_BUFFER_SIZE - sizeof(ENHANCE_MODE_DATA_STRUCT_T) - HIF_RX_ZERO_APPENDED_LEN;
#else
			u4RxAvailAggLen = CFG_RX_COALESCING_BUFFER_SIZE;
#endif
			/*why to add 4 */
			u4CurrAvailFreeRfbCnt = prRxCtrl->rFreeSwRfbList.Number;
			u4RxAggCount = 0;
			u4RxAggLength = 0;

			if (u4CurrAvailFreeRfbCnt < u2RxPktNum) {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: u4CurrAvailFreeRfbCnt < u2RxPktNum\n", __func__));
				continue;
			}

			for (u4i = 0; u4i < u2RxPktNum; u4i++) {
				u4RxLength = (rxNum == 0 ?
							  (UINT32)prSDIOCtrl->rRxInfo.u.au2Rx0Len[u4i] :
							  (UINT32)prSDIOCtrl->rRxInfo.u.au2Rx1Len[u4i]);

				if (!u4RxLength) {
					ASSERT(0);
					break;
				}

				u4RxLengthAlign = ROUND_UP(u4RxLength + HIF_RX_CSO_APPENDED_LEN, 4);

				if (u4RxLengthAlign < u4RxAvailAggLen) {
					if (u4RxAggCount < u4CurrAvailFreeRfbCnt) {
						u4RxAvailAggLen -= u4RxLengthAlign;
						u4RxAggLength += u4RxLengthAlign;
						u4RxAggCount++;
					} else {
						/* no FreeSwRfb for rx packet */
						ASSERT(0);
						break;
					}
				} else {
					/* CFG_RX_COALESCING_BUFFER_SIZE is not large enough */
					ASSERT(0);
					break;
				}
			}

			if (u4RxAggCount > 1)
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("%s: u4RxAggLength: %x u4RxAggCount: %x\n", __func__, u4RxAggLength, u4RxAggCount));

#if CFG_SDIO_RX_ENHANCE
			u4RxAggLength =  u4RxAggLength + HIF_RX_ZERO_APPENDED_LEN + sizeof(ENHANCE_MODE_DATA_STRUCT_T);
#else
			u4RxAggLength = u4RxAggLength;
#endif

			if (rxNum == 0) {
				u4j = MTSDIODataRx0(prAd, prRxCtrl->pucRxCoalescingBufPtr, u4RxAggLength);

				if (u4j) {
					MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: u4RxAggLength: %x u4RxAggCount: %x\n", __func__, u4RxAggLength, u4RxAggCount));
					MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: MTSDIORxEnhancedReadBuffer rx0 failed: err = %x\n", __func__, u4j));
					fReadFail = TRUE;
					break;
				}
			} else {
				u4j = MTSDIODataRx1(prAd, prRxCtrl->pucRxCoalescingBufPtr, u4RxAggLength);

				if (u4j) {
					MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: u4RxAggLength: %x u4RxAggCount: %x\n", __func__, u4RxAggLength, u4RxAggCount));
					MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s: MTSDIORxEnhancedReadBuffer rx1 failed: err = %x\n", __func__, u4j));
					fReadFail = TRUE;
					break;
				}
			}

			pucSrcAddr = prRxCtrl->pucRxCoalescingBufPtr;

			for (u4j = 0; u4j < u4RxAggCount; u4j++) {
				u4RxPktLen = (rxNum == 0 ?
							  (UINT32)prSDIOCtrl->rRxInfo.u.au2Rx0Len[u4j] :
							  (UINT32)prSDIOCtrl->rRxInfo.u.au2Rx1Len[u4j]);
				RTMP_IRQ_LOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags);
				pEntry = RemoveHeadQueue(&prRxCtrl->rFreeSwRfbList);
				prSwRfb = (P_SW_RFB_T)pEntry;
				RTMP_IRQ_UNLOCK(&prRxCtrl->rFreeSwRfbLock, IrqFlags);
				u2Rxbyte = *(PUINT16)pucSrcAddr;
				/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: u4j: %x u4RxPktLen: %x u4RxAggLength: %x\n", __func__,u4j,u4RxPktLen,u4RxAggLength)); */
				NdisCopyMemory(GET_OS_PKT_DATAPTR(prSwRfb->prRxPacket), pucSrcAddr, ROUND_UP(u4RxPktLen + HIF_RX_CSO_APPENDED_LEN, 4));
				pucSrcAddr = pucSrcAddr + ROUND_UP(u4RxPktLen + HIF_RX_CSO_APPENDED_LEN, 4);
				SET_OS_PKT_LEN(prSwRfb->prRxPacket, u4RxPktLen);
				/* prSDIOCtrl->au4RxLength[i] = 0; */
				RTMP_IRQ_LOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags);
				InsertTailQueue(&prRxCtrl->rReceivedRfbList, &prSwRfb->rQueEntry);
				RTMP_IRQ_UNLOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags);
				/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: InsertTailQueue rReceivedRfbList\n",__func__)); */
			}

#if CFG_SDIO_RX_ENHANCE
			NdisCopyMemory(prSDIOCtrl, (pucSrcAddr + 4), sizeof(ENHANCE_MODE_DATA_STRUCT_T));

			/* do the same thing what nicSDIOReadIntStatus() does */
			if ((prSDIOCtrl->u4WHISR & TX_DONE_INT) == 0 &&
				(prSDIOCtrl->rTxInfo.au4WTSR[0] | prSDIOCtrl->rTxInfo.au4WTSR[1]
				 | prSDIOCtrl->rTxInfo.au4WTSR[2] | prSDIOCtrl->rTxInfo.au4WTSR[3]
				 | prSDIOCtrl->rTxInfo.au4WTSR[4] | prSDIOCtrl->rTxInfo.au4WTSR[5]
				 | prSDIOCtrl->rTxInfo.au4WTSR[6] | prSDIOCtrl->rTxInfo.au4WTSR[7]))
				prSDIOCtrl->u4WHISR |= TX_DONE_INT;

			/* FIXME: TODO: mtk3034: handle mailbox */
#if 0

			if ((prSDIOCtrl->u4WHISR & BIT(31)) == 0 &&
				HAL_GET_MAILBOX_READ_CLEAR(prAdapter) == TRUE &&
				(prSDIOCtrl->u4RcvMailbox0 != 0 || prSDIOCtrl->u4RcvMailbox1 != 0))
				prSDIOCtrl->u4WHISR |= BIT(31);

#endif
			/* dispatch to interrupt handler with RX bits masked */
			MTSDIOProcessIST_impl(prAd, prSDIOCtrl->u4WHISR &  (~(RX0_DONE_INT | RX1_DONE_INT)));
#endif
		}

#if !CFG_SDIO_RX_ENHANCE
		prSDIOCtrl->rRxInfo.u.u2NumValidRx0Len = 0;
		prSDIOCtrl->rRxInfo.u.u2NumValidRx1Len = 0;
#endif
	} while ((prSDIOCtrl->rRxInfo.u.u2NumValidRx0Len
			  || prSDIOCtrl->rRxInfo.u.u2NumValidRx1Len) && fgIsRxEnhanceMode  && !fReadFail);

#if CFG_SDIO_RX_THREAD
	MTSDIORxThreadEventNotify(prAd, SDIO_RXEVENT_BIT);
#else
	op->rx_done_handle(prAd);
#endif
	return 0;
}

#endif

/*
 * ========================================================================
 * Routine Description:
 *     SDIO thread for handling TX request (DATA/CMD) and interrupt
 *
 * Arguments:
 *     ulContext            Pointer to RTMP_ADAPTER
 *
 * Return Value:
 *
 * Note:
 * ========================================================================
 */
#if CFG_SDIO_RX_THREAD
VOID
MTSDIORxThreadEventNotify(
	IN PRTMP_ADAPTER prAd,
	IN UINT32 u4EventBit
)
{
	set_bit(u4EventBit, &prAd->u4TaskRxEvent);
	RtmpOsTaskWakeUp(&prAd->rSDIORxTask);
}
#endif

VOID
MTSDIOWorkerThreadEventNotify(
	IN PRTMP_ADAPTER prAd,
	IN UINT32 u4EventBit
)
{
	/* TODO: Replaced with RtmpOSxx */
	set_bit(u4EventBit, &prAd->u4TaskEvent);
	RtmpOsTaskWakeUp(&prAd->rSDIOTask);
}

/*
 * ========================================================================
 * Routine Description:
 *     SDIO thread for handling TX request (DATA/CMD) and interrupt
 *
 * Arguments:
 *     ulContext            Pointer to RTMP_ADAPTER
 *
 * Return Value:
 *
 * Note:
 * ========================================================================
 */
#if CFG_SDIO_RX_THREAD
INT
MTSDIORxThread(
	IN ULONG ulContext
)
{
	RTMP_OS_TASK *prTask = (RTMP_OS_TASK *) ulContext;
	PRTMP_ADAPTER prAd = (PRTMP_ADAPTER) RTMP_OS_TASK_DATA_GET(prTask);
	UINT32 u4Status = 0;
	RTMP_ARCH_OP *op = &prAd->archOps;
	ASSERT(prAd);
	RtmpOSTaskCustomize(prTask);

	while (!RTMP_OS_TASK_IS_KILLED(prTask)) {
		if (!RtmpOSTaskWaitCond(prAd, prTask, (prAd->u4TaskRxEvent != 0), &u4Status)) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s(): leave SDIO Rxthread\n", __func__));
			break;
		}

		if (test_and_clear_bit(SDIO_RXEVENT_BIT, &prAd->u4TaskRxEvent)) {
			RTMP_SEM_LOCK(&prAd->RxThreadLock);
			op->rx_done_handle(prAd);
			RTMP_SEM_UNLOCK(&prAd->RxThreadLock);
		}
	}

	RtmpOSTaskNotifyToExit(prTask);
	return 0;
}
#endif
INT
MTSDIOWorkerThread(
	IN ULONG ulContext
)
{
	RTMP_OS_TASK *prTask = (RTMP_OS_TASK *) ulContext;
	PRTMP_ADAPTER prAd = (PRTMP_ADAPTER) RTMP_OS_TASK_DATA_GET(prTask);
	UINT32 u4Status = 0;
	ASSERT(prAd);
	RtmpOSTaskCustomize(prTask);

	while (!RTMP_OS_TASK_IS_KILLED(prTask)) {
		if (!RtmpOSTaskWaitCond(prAd, prTask, (prAd->u4TaskEvent != 0), &u4Status)) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s(): leave SDIO worker thread\n", __func__));
			break;
		}

		/* Handle interrupt */
		/* TODO: replaced with RtmpOSxxx */
		if (test_and_clear_bit(SDIO_EVENT_INT_BIT, &prAd->u4TaskEvent)) {
			MTSDIOProcessIST(prAd);
			/* Enable Interrupt */
			RTMP_SDIO_WRITE32(prAd, WHLPCR, W_INT_EN_SET);
		}

		/* Handle CMD request */
		if (test_and_clear_bit(SDIO_EVENT_CMD_BIT, &prAd->u4TaskEvent))
			AndesMTSendCmdMsgToSdio(prAd);

		if (test_and_clear_bit(SDIO_EVENT_TX_DATA_REQ_BIT, &prAd->u4TaskEvent)) {
#if CFG_SDIO_TX_THREAD
			MtSDIOAggTXInit(prAd);
			MtSDIOAggTXKickout(prAd);
#else
#if CFG_SDIO_TX_AGG
			MtSDIOAggTXInit(prAd);
#endif
			_RTMPDeQueuePacket(prAd, FALSE, WMM_NUM_OF_AC, WCID_ALL, 64);
#if CFG_SDIO_TX_AGG
			MtSDIOAggTXKickout(prAd);
#endif
#endif
		}

		if (test_and_clear_bit(SDIO_EVENT_TXREQ_BIT, &prAd->u4TaskEvent)) {
			UINT32 u4i = 0;
			UINT32 u4j = 0;
			ULONG ulFlags = 0;
			u4j = prAd->MgmtRing.TxDmaIdx;

			for (u4i = 0; u4i < (MGMT_RING_SIZE - prAd->MgmtRing.TxSwFreeIdx); u4i++) {
				/* hex_dump("mgmt packet", GET_OS_PKT_DATAPTR(prAd->MgmtRing.Cell[u4j].pNdisPacket), prAd->MgmtRing.Cell[u4j].u4TxLength); */
				if (!MTSDIOTxAcquireResource(prAd, TC5_INDEX, MTSDIOTxGetPageCount(prAd->MgmtRing.Cell[u4j].u4TxLength, TRUE))) {
					MtSDIOMgmtKickOut(
						prAd,
						GET_OS_PKT_DATAPTR(prAd->MgmtRing.Cell[u4j].pNdisPacket),
						prAd->MgmtRing.Cell[u4j].u4TxLength
					);
#if 0 /* Use TXS */
#ifdef RT_CFG80211_SUPPORT

					/* YF: no good mechanism for new chip , need cheeck */
					if (prAd->MgmtRing.Cell[u4j].pNdisPacket) {
						HEADER_802_11  *pHeader;
						struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(prAd->hdev_ctrl);

						pHeader = (HEADER_802_11 *)(
							GET_OS_PKT_DATAPTR(prAd->MgmtRing.Cell[u4j].pNdisPacket)
							+ TXINFO_SIZE + cap->TXWISize);
						CFG80211_SendMgmtFrameDone(prAd, pHeader->Sequence);
					}

#endif /* RT_CFG80211_SUPPORT */
#endif
					RELEASE_NDIS_PACKET(prAd, prAd->MgmtRing.Cell[u4j].pNdisPacket, NDIS_STATUS_SUCCESS);
					RTMP_IRQ_LOCK(&prAd->MgmtRingLock, ulFlags);
					INC_RING_INDEX(u4j, MGMT_RING_SIZE);
					prAd->MgmtRing.TxSwFreeIdx++;
					INC_RING_INDEX(prAd->MgmtRing.TxDmaIdx, MGMT_RING_SIZE);
					RTMP_IRQ_UNLOCK(&prAd->MgmtRingLock, ulFlags);
				}
			}
		}

		if (test_and_clear_bit(SDIO_EVENT_TX_BCN_BIT, &prAd->u4TaskEvent)) {
			UINT32 u4j = 0;
			ULONG ulFlags = 0;
			u4j = prAd->BcnRing.TxDmaIdx;
			/* for (u4i = 0; u4i < (BCN_RING_SIZE - prAd->BcnRing.TxSwFreeIdx); u4i++) { */

			/* hex_dump("bcn packet", GET_OS_PKT_DATAPTR(prAd->BcnRing.Cell[u4j].pNdisPacket), prAd->BcnRing.Cell[u4j].u4TxLength); */

			if (!MTSDIOTxAcquireResource(prAd, TC7_INDEX, MTSDIOTxGetPageCount(prAd->BcnRing.Cell[u4j].u4TxLength, TRUE))) {
				MtSDIOMgmtKickOut(
					prAd,
					GET_OS_PKT_DATAPTR(prAd->BcnRing.Cell[u4j].pNdisPacket),
					prAd->BcnRing.Cell[u4j].u4TxLength
				);
				RTMP_IRQ_LOCK(&prAd->BcnRingLock, ulFlags);
				INC_RING_INDEX(u4j, BCN_RING_SIZE);
				prAd->BcnRing.TxSwFreeIdx++;
				INC_RING_INDEX(prAd->BcnRing.TxDmaIdx, BCN_RING_SIZE);
				RTMP_IRQ_UNLOCK(&prAd->BcnRingLock, ulFlags);
			}

			/* } */
		}
	}

	RtmpOSTaskNotifyToExit(prTask);
	return 0;
}

/*
========================================================================
Routine Description:
    SDIO command kernel thread.

Arguments:
	*Context			the pAd, driver control block pointer

Return Value:
    0					close the thread

Note:
========================================================================
*/
INT
MTSDIOCmdThread(
	IN ULONG Context)
{
	RTMP_ADAPTER *pAd;
	RTMP_OS_TASK *pTask;
	int status;
	status = 0;
	pTask = (RTMP_OS_TASK *)Context;
	pAd = (PRTMP_ADAPTER)RTMP_OS_TASK_DATA_GET(pTask);
#if 0
	/*
		If we don't check here, coverity will complain.
	*/
#endif

	if (pAd == NULL)
		return 0;

	RtmpOSTaskCustomize(pTask);
	NdisAcquireSpinLock(&pAd->CmdQLock);
	pAd->CmdQ.CmdQState = RTMP_TASK_STAT_RUNNING;
	NdisReleaseSpinLock(&pAd->CmdQLock);

	while (pAd->CmdQ.CmdQState == RTMP_TASK_STAT_RUNNING) {
		if (RtmpOSTaskWait(pAd, pTask, &status) == FALSE) {
			RTMP_SET_FLAG(pAd, fRTMP_ADAPTER_HALT_IN_PROGRESS);
			break;
		}

		if (pAd->CmdQ.CmdQState == RTMP_TASK_STAT_STOPED)
			break;

		if (!pAd->PM_FlgSuspend)
			CMDHandler(pAd);
	}

	if (!pAd->PM_FlgSuspend) {
		/* Clear the CmdQElements. */
		CmdQElmt	*pCmdQElmt = NULL;
		NdisAcquireSpinLock(&pAd->CmdQLock);
		pAd->CmdQ.CmdQState = RTMP_TASK_STAT_STOPED;

		while (pAd->CmdQ.size) {
			RTThreadDequeueCmd(&pAd->CmdQ, &pCmdQElmt);

			if (pCmdQElmt) {
				if (pCmdQElmt->CmdFromNdis == TRUE) {
					if (pCmdQElmt->buffer != NULL)
						os_free_mem(pCmdQElmt->buffer);

					os_free_mem((PUCHAR)pCmdQElmt);
				} else {
					if ((pCmdQElmt->buffer != NULL) && (pCmdQElmt->bufferlength != 0))
						os_free_mem(pCmdQElmt->buffer);

					os_free_mem((PUCHAR)pCmdQElmt);
				}
			}
		}

		NdisReleaseSpinLock(&pAd->CmdQLock);
	}

	/* notify the exit routine that we're actually exiting now
	 *
	 * complete()/wait_for_completion() is similar to up()/down(),
	 * except that complete() is safe in the case where the structure
	 * is getting deleted in a parallel mode of execution (i.e. just
	 * after the down() -- that's necessary for the thread-shutdown
	 * case.
	 *
	 * complete_and_exit() goes even further than this -- it is safe in
	 * the case that the thread of the caller is going away (not just
	 * the structure) -- this is necessary for the module-remove case.
	 * This is important in preemption kernels, which transfer the flow
	 * of execution immediately upon a complete().
	 */
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("<---MTSDIOCmdThread\n"));
	RtmpOSTaskNotifyToExit(pTask);
	return 0;
}


/*
 * ========================================================================
 * Routine Description:
 *     SDIO thread for handling TX request (DATA/CMD) and interrupt
 *
 * Arguments:
 *     *prAd            Pointer to RTMP_ADAPTER
 *
 * Return Value:
 *
 * Note:
 * ========================================================================
 */

VOID
MTSDIODataIsr(
	IN PRTMP_ADAPTER prAd)
{
	ASSERT(prAd);
	/* Disable Interrupt */
	RTMP_SDIO_WRITE32(prAd, WHLPCR, W_INT_EN_CLR);
	/* Notify the sdio worker thread */
	MTSDIOWorkerThreadEventNotify(prAd, SDIO_EVENT_INT_BIT);
}
#ifdef MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL
VOID MTAdaptiveResourceCheckFastAdjustment(IN RTMP_ADAPTER *pAd, IN INT wcid, IN UCHAR queue)
{
	P_TX_CTRL_T prTxCtrl = NULL;
	STA_TR_ENTRY	*tr_entry = NULL;
	UCHAR	ucTc;
	tr_entry = &pAd->MacTab.tr_entry[wcid];

	if (tr_entry->EntryType == ENTRY_CAT_MCAST) {
		if (pAd->MacTab.fAnyStationInPsm)
			ucTc = TC4_INDEX;
		else
			ucTc = TC0_INDEX;
	} else
		ucTc = queue;

	prTxCtrl = &pAd->rTxCtrl;

	/* In MtSDIOTxResourceRequest() an additional page is made
		mandatory for transmission of a frame to PSE.
		We need to incorporate the same margin here.
		TODO: Do we actually need the extra page? */

	if (prTxCtrl->rTc.au2MaxNumOfPage[ucTc] < (SDIO_TX_MAX_PAGE_PER_FRAME + 1)) {
		prTxCtrl->rTc.fQuotaAdjustFast = TRUE;
		prTxCtrl->rTc.u2TimeToUpdateQueLen = 1;
		prTxCtrl->rTc.u2TimeToAdjustTcResource = 1;
#if DEBUG_ADAPTIVE_QUOTA
		{
			UINT16 *p;
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: ucTc %d :set fast = 1\n", __func__, ucTc));
			p = &prTxCtrl->rTc.au2MaxNumOfPage[0];
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: Max Page %d %d %d %d %d\n", __func__, p[0], p[1], p[2], p[3], p[4]));
			p = &prTxCtrl->rTc.au2FreePageCount[0];
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: FreePage %d %d %d %d %d\n", __func__, p[0], p[1], p[2], p[3], p[4]));
		}
#endif /* DEBUG_ADAPTIVE_QUOTA */
	}

	return;
}


VOID MTAdaptiveResourceAllocation(IN RTMP_ADAPTER *pAd, IN INT wcid, IN UCHAR queue)
{
	UINT16 demand[NUM_ADJUSTABLE_TC];
	STA_TR_ENTRY *tr_entry;
	UINT16 total_demand;
	int qid;
	int wcid_id;
	P_TX_CTRL_T prTxCtrl = NULL;
	/* unsigned long IrqFlags = 0; */
	ASSERT(pAd);
	prTxCtrl = &pAd->rTxCtrl;

	/* check if time to update average demand */
	if (--(prTxCtrl->rTc.u2TimeToUpdateQueLen))
		return;

	prTxCtrl->rTc.u2TimeToUpdateQueLen = SDIO_INIT_TIME_TO_UPDATE_QUE_LEN;

	for (qid = 0; qid < NUM_ADJUSTABLE_TC; qid++)
		demand[qid] = 0;

	/* calculate current demand for all queueus */
	for (wcid_id = 0; wcid_id < MAX_LEN_OF_TR_TABLE; wcid_id++) {
		tr_entry = &pAd->MacTab.tr_entry[wcid_id];

		if (IS_VALID_ENTRY(tr_entry)) {
			if (tr_entry->EntryType == ENTRY_CAT_MCAST) {
				if (pAd->MacTab.fAnyStationInPsm == 0) {
#if TC_PAGE_BASED_DEMAND
					demand[TC0_INDEX] += tr_entry->TotalPageCount[TC0_INDEX];
#else
					demand[TC0_INDEX] += tr_entry->tx_queue[TC0_INDEX].Number;
#endif
				} else {
#if TC_PAGE_BASED_DEMAND
					demand[TC4_INDEX] += tr_entry->TotalPageCount[TC0_INDEX];
#else
					demand[TC4_INDEX] += tr_entry->tx_queue[TC0_INDEX].Number;
#endif
				}
			} else {
				/* TODO Soumik: may need to check other conditions ps_state for PSM STA
				 * for AP mode operation */
				if ((tr_entry->PsMode != PWR_SAVE) || (tr_entry->wcid == wcid_id)) {
					for (qid = 0; qid <= TC3_INDEX; qid++) {
#if TC_PAGE_BASED_DEMAND
						demand[qid] += tr_entry->TotalPageCount[qid];
#else
						demand[qid] += tr_entry->tx_queue[qid].Number;
#endif
					}
				}
			}
		}
	}

#if !TC_PAGE_BASED_DEMAND

	/* converting demand into the page demand */
	for (qid = 0; qid < NUM_ADJUSTABLE_TC; qid++)
		demand[qid] *= SDIO_TX_MAX_PAGE_PER_FRAME;

#endif /* !TC_PAGE_BASED_DEMAND */
#if DEBUG_ADAPTIVE_QUOTA
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("%s: demand %d %d %d %d %d\n", __func__, demand[0], demand[1],
			 demand[2], demand[3], demand[4]));
#endif /* DEBUG_ADAPTIVE_QUOTA */
#if DEBUG_ADAPTIVE_QUOTA
	{
		UINT16 *p = &prTxCtrl->rTc.au2AvgDemand[0];
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: AvgDemand %d %d %d %d %d\n", __func__, p[0], p[1],
				 p[2], p[3], p[4]));
	}
#endif

	/* evaluating the moving avg */
	for (qid = 0; qid < NUM_ADJUSTABLE_TC; qid++) {
		/* TODO: soumik - replace the divison with bit shift operation */
		if (demand[qid] && (prTxCtrl->rTc.au2AvgDemand[qid] == 0))
			prTxCtrl->rTc.au2AvgDemand[qid] = demand[qid];
		else
			prTxCtrl->rTc.au2AvgDemand[qid] = (((prTxCtrl->rTc.au2AvgDemand[qid] * (MOVING_AVARAGE_WINDOW_SIZE - 1)) + demand[qid]) / MOVING_AVARAGE_WINDOW_SIZE);

		demand[qid] = prTxCtrl->rTc.au2AvgDemand[qid];
	}

#if DEBUG_ADAPTIVE_QUOTA
	{
		UINT16 *p = &prTxCtrl->rTc.au2AvgDemand[0];
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: AvgDemand %d %d %d %d %d\n",
				 __func__, p[0], p[1], p[2], p[3], p[4]));
	}
#endif /* DEBUG_ADAPTIVE_QUOTA */

	/* Check if it is time for resource re-assignment */
	if (--prTxCtrl->rTc.u2TimeToAdjustTcResource)
		return;

	/* Check if last quota re-adjustement is complete */
	if (prTxCtrl->rTc.fgTcResourcePostAnnealing) {
		prTxCtrl->rTc.u2TimeToAdjustTcResource = 1;
		return;
	}

	prTxCtrl->rTc.u2TimeToAdjustTcResource = SDIO_INIT_TIME_TO_ADJUST_TC_RSC;
	/* Calculate the total demand */
	total_demand = 0;

	for (qid = 0; qid < NUM_ADJUSTABLE_TC; qid++)
		total_demand += demand[qid];

#if DEBUG_ADAPTIVE_QUOTA
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: total_demand %d total adjustable %d\n",
			 __func__, total_demand, NIC_TOTAL_ADJUSTABLE_RESOURCES));
#endif

	/* Allocating resources for each queue */
	if ((total_demand > 0) && (total_demand <= NIC_TOTAL_ADJUSTABLE_RESOURCES)) {
		int total_resources = NIC_TOTAL_ADJUSTABLE_RESOURCES;
		int shareCount = 0;
		int shareResourcesPerQueue = 0;

		for (qid = 0; qid < NUM_ADJUSTABLE_TC; qid++) {
			prTxCtrl->rTc.au2CurrentTcResource[qid] = demand[qid];

			if (demand[qid] > 0) {
				total_resources -= demand[qid];
				shareCount++;
			}
		}

		if (shareCount)
			shareResourcesPerQueue = (total_resources / shareCount);

		if (shareResourcesPerQueue) {
			for (qid = 0; qid < NUM_ADJUSTABLE_TC; qid++) {
				if (demand[qid]) {
					prTxCtrl->rTc.au2CurrentTcResource[qid] += shareResourcesPerQueue;
					total_resources -= shareResourcesPerQueue;
				}
			}
		}

		/* allocating the remaining resources to VO */
		prTxCtrl->rTc.au2CurrentTcResource[TC3_INDEX] += total_resources;
	} else if (total_demand > NIC_TOTAL_ADJUSTABLE_RESOURCES) {
		int total_resources = NIC_TOTAL_ADJUSTABLE_RESOURCES;
		int totalDeficit = 0;
		int totalUnallocatedResources;
		int shareResourcesPerQueue;

		for (qid = 0; qid < NUM_ADJUSTABLE_TC; qid++) {
			if (demand[qid] > 0) {
				prTxCtrl->rTc.au2CurrentTcResource[qid] = prTxCtrl->rTc.au2GuaranteedTcResource[qid];
				total_resources -= prTxCtrl->rTc.au2GuaranteedTcResource[qid];

				if (demand[qid] <= prTxCtrl->rTc.au2GuaranteedTcResource[qid])
					demand[qid] = 0;
				else
					demand[qid] -= prTxCtrl->rTc.au2GuaranteedTcResource[qid];
			} else
				prTxCtrl->rTc.au2CurrentTcResource[qid] = 0;

			totalDeficit += demand[qid];
		}

		totalUnallocatedResources = total_resources;

		for (qid = NUM_ADJUSTABLE_TC - 1; qid  >= 0; qid--) {
			if (demand[qid] == 0)
				continue;

			shareResourcesPerQueue = ((demand[qid] * totalUnallocatedResources) / totalDeficit);

			if (shareResourcesPerQueue == 0)
				continue;

			if (shareResourcesPerQueue > demand[qid])
				shareResourcesPerQueue = demand[qid];

			prTxCtrl->rTc.au2CurrentTcResource[qid] += shareResourcesPerQueue;
			total_resources -= shareResourcesPerQueue;
			demand[qid] -= shareResourcesPerQueue;
		}

		if (total_resources > 0) {
			/* Excluding BMC queue from residual allocation */
			for (qid = TC3_INDEX; qid >= 0; qid--) {
				if (demand[qid] == 0)
					continue;

				if (demand[qid] >=	 total_resources) {
					prTxCtrl->rTc.au2CurrentTcResource[qid] += total_resources;
					demand[qid] -= total_resources;
					total_resources = 0;
					break;
				} else {
					prTxCtrl->rTc.au2CurrentTcResource[qid] += demand[qid];
					demand[qid] = 0;
					total_resources  = -demand[qid];
				}
			}
		}
	}

	prTxCtrl->rTc.fgTcResourcePostAnnealing = TRUE;
#if DEBUG_ADAPTIVE_QUOTA
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: CurrentTcResources  %d %d %d %d %d %d %d %d\n", __func__,
			 pAd->rTxCtrl.rTc.au2CurrentTcResource[0],
			 pAd->rTxCtrl.rTc.au2CurrentTcResource[1],
			 pAd->rTxCtrl.rTc.au2CurrentTcResource[2],
			 pAd->rTxCtrl.rTc.au2CurrentTcResource[3],
			 pAd->rTxCtrl.rTc.au2CurrentTcResource[4],
			 pAd->rTxCtrl.rTc.au2CurrentTcResource[5],
			 pAd->rTxCtrl.rTc.au2CurrentTcResource[6],
			 pAd->rTxCtrl.rTc.au2CurrentTcResource[7]));
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: FreeResources %d %d %d %d %d %d %d %d\n", __func__,
			 pAd->rTxCtrl.rTc.au2FreePageCount[0],
			 pAd->rTxCtrl.rTc.au2FreePageCount[1],
			 pAd->rTxCtrl.rTc.au2FreePageCount[2],
			 pAd->rTxCtrl.rTc.au2FreePageCount[3],
			 pAd->rTxCtrl.rTc.au2FreePageCount[4],
			 pAd->rTxCtrl.rTc.au2FreePageCount[5],
			 pAd->rTxCtrl.rTc.au2FreePageCount[6],
			 pAd->rTxCtrl.rTc.au2FreePageCount[7]));
#endif

	if (prTxCtrl->rTc.fQuotaAdjustFast) {
#if DEBUG_ADAPTIVE_QUOTA
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: fQuotaAdjustFast == TRUE call MTAdjustTcQuotas\n", __func__));
#endif
		prTxCtrl->rTc.fQuotaAdjustFast = FALSE;
		MTAdjustTcQuotas(pAd);
	}

	return;
}

VOID MTAdjustTcQuotas(IN RTMP_ADAPTER *pAd)
{
	INT16 i2TotalExtraQuota = 0;
	INT16 ai2ExtraQuota[NUM_ADJUSTABLE_TC];
	BOOLEAN fgResourceRedistributed = TRUE;
	P_TX_CTRL_T prTxCtrl = NULL;
	int qid;
	unsigned long flags = 0;
	ASSERT(pAd);
	prTxCtrl = &pAd->rTxCtrl;

	if (!prTxCtrl->rTc.fgTcResourcePostAnnealing)
		return;

#if DEBUG_ADAPTIVE_QUOTA
	{
		UINT16 *p;
		p = &prTxCtrl->rTc.au2MaxNumOfPage[0];
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: MaxNumPage = %d %d %d %d %d %d %d %d\n", __func__,
				 p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]));
		p = &prTxCtrl->rTc.au2CurrentTcResource[0];
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: CurTcResource = %d %d %d %d %d %d %d %d\n", __func__,
				 p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]));
		p = &prTxCtrl->rTc.au2FreePageCount[0];
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: FreePageCount = %d %d %d %d %d %d %d %d\n", __func__,
				 p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]));
	}
#endif

	/* Obtain the free-to-distribute resources */
	for (qid = 0; qid < NUM_ADJUSTABLE_TC; qid++) {
		ai2ExtraQuota[qid] = (INT16)((UINT16)prTxCtrl->rTc.au2MaxNumOfPage[qid] - (UINT16)prTxCtrl->rTc.au2CurrentTcResource[qid]);

		if (ai2ExtraQuota[qid] > 0) {
			/* The resource shall be reallocated to other TCs */
			if (ai2ExtraQuota[qid] > prTxCtrl->rTc.au2FreePageCount[qid]) {
				ai2ExtraQuota[qid] = prTxCtrl->rTc.au2FreePageCount[qid];
				fgResourceRedistributed = FALSE;
#if DEBUG_ADAPTIVE_QUOTA
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: qid %d fgResourceRedistributed = %d ExtraQuota %d FreePage %d\n",
						 __func__, qid, fgResourceRedistributed, ai2ExtraQuota[qid], prTxCtrl->rTc.au2FreePageCount[qid]));
#endif /* DEBUG_ADAPTIVE_QUOTA */
			}

			i2TotalExtraQuota += ai2ExtraQuota[qid];
		}
	}

#if DEBUG_ADAPTIVE_QUOTA
	{
		INT16 *p = &ai2ExtraQuota[0];
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: ExtraQuota = %d %d %d %d %d TotalExtraQuota = %d\n", __func__,
				 p[0], p[1], p[2], p[3], p[4], i2TotalExtraQuota));
	}
#endif /* DEBUG_ADAPTIVE_QUOTA */
	RTMP_SPIN_LOCK_IRQSAVE(&pAd->TcCountLock, &flags);

	for (qid = TC3_INDEX; qid >= 0; qid--) {
		if (ai2ExtraQuota[qid] < 0) {
			if ((-ai2ExtraQuota[qid]) <= i2TotalExtraQuota) {
				prTxCtrl->rTc.au2MaxNumOfPage[qid] += -ai2ExtraQuota[qid];
				prTxCtrl->rTc.au2FreePageCount[qid] += -ai2ExtraQuota[qid];
				i2TotalExtraQuota += ai2ExtraQuota[qid];
			} else {
				prTxCtrl->rTc.au2MaxNumOfPage[qid] += i2TotalExtraQuota;
				prTxCtrl->rTc.au2FreePageCount[qid] += i2TotalExtraQuota;
				i2TotalExtraQuota = 0;
				fgResourceRedistributed = FALSE;
			}
		} else {
			prTxCtrl->rTc.au2MaxNumOfPage[qid] -= ai2ExtraQuota[qid];
			prTxCtrl->rTc.au2FreePageCount[qid] -= ai2ExtraQuota[qid];
		}
	}

	if ((i2TotalExtraQuota > 0) && ai2ExtraQuota[TC4_INDEX] < 0) {
		if ((-ai2ExtraQuota[TC4_INDEX]) >= i2TotalExtraQuota) {
			fgResourceRedistributed = FALSE;
			prTxCtrl->rTc.au2MaxNumOfPage[TC4_INDEX] += i2TotalExtraQuota;
			prTxCtrl->rTc.au2FreePageCount[TC4_INDEX] += i2TotalExtraQuota;
			i2TotalExtraQuota = 0;
		} else {
			prTxCtrl->rTc.au2MaxNumOfPage[TC4_INDEX] += -ai2ExtraQuota[TC4_INDEX];
			prTxCtrl->rTc.au2FreePageCount[TC4_INDEX] += -ai2ExtraQuota[TC4_INDEX];
			i2TotalExtraQuota += ai2ExtraQuota[TC4_INDEX];
		}
	} else if (ai2ExtraQuota[TC4_INDEX] > 0) {
		prTxCtrl->rTc.au2MaxNumOfPage[TC4_INDEX] -= ai2ExtraQuota[TC4_INDEX];
		prTxCtrl->rTc.au2FreePageCount[TC4_INDEX] -= ai2ExtraQuota[TC4_INDEX];
		i2TotalExtraQuota += ai2ExtraQuota[TC4_INDEX];
	}

	if (i2TotalExtraQuota > 0) {
		prTxCtrl->rTc.au2MaxNumOfPage[TC3_INDEX] += i2TotalExtraQuota;
		prTxCtrl->rTc.au2FreePageCount[TC3_INDEX] += i2TotalExtraQuota;
	}

#if DEBUG_ADAPTIVE_QUOTA
	{
		UINT16 *p;
		p = &prTxCtrl->rTc.au2MaxNumOfPage[0];
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: MaxNumPage = %d %d %d %d %d\n", __func__,
				 p[0], p[1], p[2], p[3], p[4]));
		p = &prTxCtrl->rTc.au2CurrentTcResource[0];
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: CurTcResource = %d %d %d %d %d\n", __func__,
				 p[0], p[1], p[2], p[3], p[4]));
		p = &prTxCtrl->rTc.au2FreePageCount[0];
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: FreePage = %d %d %d %d %d\n", __func__,
				 p[0], p[1], p[2], p[3], p[4]));
	}
#endif /* DEBUG_ADAPTIVE_QUOTA */
	RTMP_SPIN_UNLOCK_IRQRESTORE(&pAd->TcCountLock, &flags);
	prTxCtrl->rTc.fgTcResourcePostAnnealing = (!fgResourceRedistributed);
#if DEBUG_ADAPTIVE_QUOTA
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s: fgTcResourcePostAnnealing = %d\n", __func__, prTxCtrl->rTc.fgTcResourcePostAnnealing));
#endif /* DEBUG_ADAPTIVE_QUOTA */
	return;
}
#endif /* MT_SDIO_ADAPTIVE_TC_RESOURCE_CTRL */

VOID ComposePsPoll(
	IN	RTMP_ADAPTER *pAd,
	IN	PPSPOLL_FRAME pPsPollFrame,
	IN	USHORT	Aid,
	IN	UCHAR *pBssid,
	IN	UCHAR *pTa)
{
}

USHORT MtSDIO_WriteSubTxResource(struct _RTMP_ADAPTER *pAd, struct _TX_BLK *pTxBlk, BOOLEAN bIsLast, USHORT *freeCnt)
{
	return 0;
}

USHORT sdio_write_frag_tx_resource(
	RTMP_ADAPTER *pAd,
	struct _TX_BLK *pTxBlk,
	UCHAR fragNum,
	USHORT *freeCnt)
{
	return 0;
}


USHORT
sdio_write_tx_resource(
	IN PRTMP_ADAPTER prAd,
	IN TX_BLK * prTxBlk,
	IN BOOLEAN fgIsLast,
	OUT USHORT *u2freeCnt)
{
	TXINFO_STRUC *prTxInfo = NULL;
	UCHAR *pucOutputBuf = NULL;
	UCHAR *prBuf = NULL;
	UCHAR ucQueIdx = 0;
	/* NDIS_STATUS rStatus = NDIS_STATUS_SUCCESS; */
	UINT32 hdr_copy_len, hdr_len, dma_len = 0;
	P_TX_CTRL_T prTxCtrl = &prAd->rTxCtrl;
	NDIS_STATUS Status = 0;
#if CFG_SDIO_TX_THREAD
	unsigned long IrqFlags;
	QUEUE_ENTRY *pEntry;
	P_TX_RFB_T pTxRfb;
	UINT32 Ret;
	UINT16 u2PgCnt = 0;
#else
	UINT16 u2PgCnt = 0;
#endif
	pucOutputBuf = prTxCtrl->pucTxCoalescingBufPtr;
	/* get Tx Ring Resource & Dma Buffer address*/
	ucQueIdx = prTxBlk->QueIdx;
	{
		do {
			prBuf = &prTxBlk->HeaderBuf[0];
			prTxInfo = (TXINFO_STRUC *) prBuf;
			/* Build our URB for USBD */
#ifdef MT_MAC
			hdr_len = prTxBlk->MpduHeaderLen + prTxBlk->HdrPadLen;

			if (prTxBlk->hw_rsv_len == 0) /* Long */
				hdr_copy_len = sizeof(TMAC_TXD_L) + hdr_len;
			else { /* Short */
				hdr_copy_len = sizeof(TMAC_TXD_S) + hdr_len;
				prTxBlk->HeaderBuf += prTxBlk->hw_rsv_len;
			}

			dma_len = hdr_copy_len + prTxBlk->SrcBufLen;
#endif /* MT_MAC */
			dma_len = ROUND_UP(dma_len, 4);
#ifdef MT_MAC
			prTxBlk->Priv = (dma_len);
#endif /* MT_MAC */
#if CFG_SDIO_TX_AGG
			/*
				To check MTSDIOTxAcquireResource(IN PRTMP_ADAPTER prAd,IN UINT8	ucTC,IN UINT8 ucPageCount)
				*/
			/*
			   prTxCtrl->pucAggIdx lock/unlock is neccessary or not?
			   */
#if CFG_SDIO_TX_THREAD

			if (prTxCtrl->TxFreeList.Number == 0) {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("(%s) prTxCtrl->TxFreeList.Number is not enough!!!\n", __func__));
				/* assert(TRUE); */
			}

			RTMP_IRQ_LOCK(&prTxCtrl->TxFreeLock, IrqFlags);
			pEntry = RemoveHeadQueue(&prTxCtrl->TxFreeList);
			pTxRfb = (P_TX_RFB_T)pEntry;
			RTMP_IRQ_UNLOCK(&prTxCtrl->TxFreeLock, IrqFlags);

			/* u2Rxbyte = *(PUINT16)pucSrcAddr; */
			if (pTxRfb) {
#if 1
				u2PgCnt = MTSDIOTxGetPageCount(dma_len, TRUE);
				Ret = MTSDIOTxAcquireResource(prAd, prTxBlk->QueIdx, u2PgCnt);

				if (Ret) {
					MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("(%s): Tx data no resource ?\n", __func__));
					break;
				}

#endif
				NdisCopyMemory(&pTxRfb->HeaderBuf[0], &prTxBlk->HeaderBuf[0], hdr_copy_len);
				pTxRfb->hdr_copy_len = hdr_copy_len;
				pTxRfb->pbuf = prTxBlk->pSrcBufData;
				pTxRfb->SrcBufLen = prTxBlk->SrcBufLen;
				pTxRfb->QueIdx = prTxBlk->QueIdx;
				pTxRfb->prTxPacket = prTxBlk->pPacket;
				RTMP_IRQ_LOCK(&prTxCtrl->TxReadyLock, IrqFlags);
				InsertTailQueue(&prTxCtrl->TxReadyList, &pTxRfb->rQueEntry);
				RTMP_IRQ_UNLOCK(&prTxCtrl->TxReadyLock, IrqFlags);
			} else
				break;

#else
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("(%s) buf(%p) offset:%p len = %d\n", __func__, prTxBlk->HeaderBuf, prTxCtrl->pucAggOffset, hdr_copy_len));
			NdisCopyMemory(prTxCtrl->pucAggOffset, prTxBlk->HeaderBuf, hdr_copy_len);
			prTxCtrl->pucAggOffset += (hdr_copy_len);
			{
				NdisCopyMemory(prTxCtrl->pucAggOffset, prTxBlk->pSrcBufData, ((prTxBlk->SrcBufLen)));
				prTxCtrl->pucAggOffset += ((prTxBlk->SrcBufLen + 0x3) & ~0x3);
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("(%s) buf(%p) offset:%p len = %d\n", __func__, prTxBlk->pSrcBufData, prTxCtrl->pucAggOffset, ((prTxBlk->SrcBufLen + 0x3) & ~0x3)));
			}
			prTxCtrl->u4AggLen  += dma_len;
			/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("(%s) each agg len %d\n", __func__, dma_len)); */
			u2PgCnt = MTSDIOTxGetPageCount((hdr_copy_len + prTxBlk->SrcBufLen), TRUE);
			MTSDIOTxAcquireResource(prAd, prTxBlk->QueIdx, u2PgCnt);
#endif
#else
			NdisCopyMemory(pucOutputBuf, prTxBlk->HeaderBuf, hdr_copy_len);
			pucOutputBuf += (hdr_copy_len);
			{
				NdisCopyMemory(pucOutputBuf, prTxBlk->pSrcBufData, prTxBlk->SrcBufLen);
				pucOutputBuf += prTxBlk->SrcBufLen;
			}
#endif
		} while (FALSE);
	}
#if CFG_SDIO_TX_THREAD
#else
	/* succeed and release the skb buffer*/
	RELEASE_NDIS_PACKET(prAd, prTxBlk->pPacket, NDIS_STATUS_SUCCESS);
#endif
	return Status;
}

USHORT sdio_write_multi_tx_resource(
	RTMP_ADAPTER *pAd,
	struct _TX_BLK *pTxBlk,
	UCHAR frmNum,
	USHORT *freeCnt)
{
	NDIS_STATUS Status = 0;
	return Status;
}


VOID sdio_write_final_tx_resource(
	RTMP_ADAPTER	*pAd,
	struct _TX_BLK *pTxBlk,
	USHORT totalMPDUSize,
	USHORT TxIdx)
{
}


VOID MtSDIODataLastTxIdx(
	RTMP_ADAPTER *pAd,
	UCHAR QueIdx,
	USHORT TxIdx)
{
	/* DO nothing for USB.*/
}

UINT32	MtSDIOTxResourceRequest(
	IN RTMP_ADAPTER *pAd,
	IN UCHAR QueIdx,
	IN UINT16 u2FreePgCnt,
	IN UINT32 req_cnt)
{
#if CFG_SDIO_TX_AGG
	UINT32	result = NDIS_STATUS_FAILURE;

	/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("(%s) each real len %d\n", __func__, req_cnt)); */

	/* margin: 1 page */
	/* TODO: mtk03034 calculate exactly size */

	if (u2FreePgCnt >= (MTSDIOTxGetPageCount(req_cnt, FALSE) + 1))
		result = NDIS_STATUS_SUCCESS;

	return result;
#else
	return NDIS_STATUS_SUCCESS;
#endif
}

VOID
sdio_kickout_data_tx(
	IN PRTMP_ADAPTER prAd,
	IN TX_BLK * prTxBlk,
	IN UCHAR QueIdx)
{
#if !CFG_SDIO_TX_AGG
	P_TX_CTRL_T prTxCtrl = &prAd->rTxCtrl;
	UCHAR *pucOutputBuf = NULL;
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("(%s)\n", __func__));
	pucOutputBuf = prTxCtrl->pucTxCoalescingBufPtr;
	MTSDIOMultiWrite(prAd, WTDR1, pucOutputBuf, prTxBlk->Priv);
	hex_dump("xxx", pucOutputBuf, prTxBlk->Priv);
#endif
}

VOID
MtSdioSubmitDataToSDIOWorker(
	IN PRTMP_ADAPTER prAd
)
{
	MTSDIOWorkerThreadEventNotify(prAd, SDIO_EVENT_TX_DATA_REQ_BIT);
	return;
}


VOID
MtSdioSubmitMgmtToSDIOWorker(
	IN PRTMP_ADAPTER prAd,
	IN UCHAR ucQueIdx,
	IN PNDIS_PACKET prPacket,
	IN UCHAR *prSrcBufVA,
	IN UINT u4SrcBufLen
)
{
	/* caller will help to hold MgmtRing lock */
	/* `P_MSDU_INTO_T prMsduInfo = NULL; */
	/* Decrease the TxSwFreeIdx and Increase the TX_CTX_IDX*/
#ifdef MT_MAC
	if (ucQueIdx == Q_IDX_BCN) {
		prAd->BcnRing.Cell[prAd->BcnRing.TxCpuIdx].pNdisPacket
			= prPacket;
		prAd->BcnRing.Cell[prAd->BcnRing.TxCpuIdx].u4TxLength
			= u4SrcBufLen;
		prAd->BcnRing.TxSwFreeIdx--;
		INC_RING_INDEX(prAd->BcnRing.TxCpuIdx, BCN_RING_SIZE);
		MTSDIOWorkerThreadEventNotify(prAd, SDIO_EVENT_TX_BCN_BIT);
	} else
#endif
	{
		prAd->MgmtRing.Cell[prAd->MgmtRing.TxCpuIdx].pNdisPacket = prPacket;
		prAd->MgmtRing.Cell[prAd->MgmtRing.TxCpuIdx].u4TxLength = u4SrcBufLen;
		prAd->MgmtRing.TxSwFreeIdx--;
		INC_RING_INDEX(prAd->MgmtRing.TxCpuIdx, MGMT_RING_SIZE);
		MTSDIOWorkerThreadEventNotify(prAd, SDIO_EVENT_TXREQ_BIT);
	}

	return;
}

VOID MtSDIONullFrameKickOut(struct _RTMP_ADAPTER *pAd, UCHAR QIdx, UCHAR *pNullFrm, UINT32 frmLen)
{
	/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("(%s) enter\n", __func__)); */
	/* RTMP_IRQ_LOCK(&pAd->MgmtRingLock, Flags); ?? lock is need or not */
	/* if (pAd->pNULLPacketInUse == FALSE) */
	{
		/* PTX_CONTEXT pNullContext; */
		PNDIS_PACKET pPacket;
		TXINFO_STRUC *pTxInfo;
		TXWI_STRUC *pTxWI;
		UCHAR *pWirelessPkt;
		struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
		UINT8 tx_hw_hdr_len = cap->tx_hw_hdr_len;
		MAC_TX_INFO mac_info;
		/* ULONG FreeNum; */
		PACKET_INFO PacketInfo;
		UCHAR *pSrcBufVA;
		UCHAR *pBuf;
		UINT SrcBufLen;
		NDIS_STATUS Status = NDIS_STATUS_SUCCESS;
		UINT32 uLen;
		UINT32 hw_len;
		UCHAR rtmpHwHdr[40];
		ULONG Flags = 0;
		UCHAR *tmac_info;
		struct wifi_dev *wdev;
		PHEADER_802_11 pHeader_802_11;
#ifdef CONFIG_STA_SUPPORT
		PSTA_ADMIN_CONFIG pStaCfg = NULL;
#endif /* CONFIG_STA_SUPPORT */
		RTMP_IRQ_LOCK(&pAd->MgmtRingLock, Flags);
		pHeader_802_11 = (HEADER_802_11 *)(pNullFrm);
		hw_len = tx_hw_hdr_len;
		ASSERT((sizeof(rtmpHwHdr) > hw_len));
		/* We need to reserve space for rtmp hardware header. i.e., TxWI for RT2860 and TxInfo+TxWI for RT2870*/
		NdisZeroMemory(&rtmpHwHdr, hw_len);
		/* Status = RTMPAllocateNdisPacket(pAd, &pPacket, (UCHAR *)&rtmpHwHdr[0], hw_len, pData, Length); //where to release it? */
		Status = RTMPAllocateNdisPacket(pAd, &pPacket, (UCHAR *)&rtmpHwHdr[0], hw_len, pNullFrm, frmLen); /* where to release it? */

		if (Status != NDIS_STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("MiniportMMRequest (error:: can't allocate NDIS PACKET)\n"));
			RTMP_IRQ_UNLOCK(&pAd->MgmtRingLock, Flags);
			return;
		}

		RTMP_QueryPacketInfo(pPacket, &PacketInfo, &pSrcBufVA, &SrcBufLen);
		/* pNullContext = &(pAd->NullContext); */
		/* Set the in use bit*/
		/* pWirelessPkt = (PUCHAR)&pNullContext->TransferBuffer->field.WirelessPacket[0]; */
		pWirelessPkt = pSrcBufVA;
		RTMPZeroMemory(&pWirelessPkt[0], SrcBufLen);
		pTxInfo = (TXINFO_STRUC *)&pWirelessPkt[0];
		/* rlt_usb_write_txinfo(pAd, pTxInfo, (USHORT)(frameLen + TXWISize + TSO_SIZE), TRUE, EpToQueue[MGMTPIPEIDX], FALSE,  FALSE); */
		pTxWI = (TXWI_STRUC *)&pWirelessPkt[TXINFO_SIZE]; /* ? */
		NdisZeroMemory((UCHAR *)&mac_info, sizeof(mac_info));
#ifdef MT_MAC
		tmac_info = &pWirelessPkt[0];

		if (pHeader_802_11->FC.Type == FC_TYPE_DATA) {
			switch (pHeader_802_11->FC.SubType) {
			case SUBTYPE_DATA_NULL:
				mac_info.hdr_len = 24;
				break;

			case SUBTYPE_QOS_NULL:
				mac_info.hdr_len = 26;
				break;

			default:
				break;
			}
		}

#endif
		wdev = wdev_search_by_address(pAd, pHeader_802_11->Addr2);

		if (!wdev) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("MiniportMMRequest (error:: can't search wdev by address)\n"));
			RTMP_IRQ_UNLOCK(&pAd->MgmtRingLock, Flags);
			return;
		}

		mac_info.FRAG = FALSE;
		mac_info.CFACK = FALSE;
		mac_info.InsTimestamp = FALSE;
		mac_info.AMPDU = FALSE;
		mac_info.BM = 0;
		mac_info.Ack = TRUE;
		mac_info.NSeq = FALSE;
		mac_info.BASize = 0;
		{
			MAC_TABLE_ENTRY *pEntry = MacTableLookup(pAd, pHeader_802_11->Addr1);
			mac_info.WCID = pEntry->wcid;
		}
		/* mac_info.Length = frameLen; */
		mac_info.Length = frmLen;
#ifdef CONFIG_STA_SUPPORT
		pStaCfg = GetStaCfgByWdev(pAd, wdev);
		ASSERT(pStaCfg);

#ifdef STA_LP_PHASE_1_SUPPORT
		if (pHeader_802_11->FC.PwrMgmt == PWR_ACTIVE)
			mac_info.PID = PID_NULL_FRAME_PWR_ACTIVE;
		else
			mac_info.PID = PID_NULL_FRAME_PWR_SAVE;

		if ((!RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS)) && RTMPEnterPsmNullBitStatus(&pStaCfg->PwrMgmt)) {
			RTMPClearEnterPsmNullBit(&pStaCfg->PwrMgmt);
			TxSTypeCtlPerPkt(pAd, mac_info.PID, TXS_FORMAT0, FALSE, TRUE, FALSE, TXS_DUMP_REPEAT);
		} else {
			/* In scan initial phase, driver needs not handle PID_NULL_FRAME_PWR_SAVE
			since driver will wakeup H/W later at ScanNextChannel() to do scan */
			TxSTypeCtlPerPkt(pAd, mac_info.PID, TXS_FORMAT0, FALSE, FALSE, FALSE, TXS_DUMP_REPEAT);
		}
#endif /* STA_LP_PHASE_1_SUPPORT */

#endif /* CONFIG_STA_SUPPORT */
		mac_info.TID = 0;
		mac_info.TxRate = (UCHAR)wdev->rate.MlmeTransmit.field.MCS;
		mac_info.Txopmode = IFS_HTTXOP;
		mac_info.Preamble = LONG_PREAMBLE;
		mac_info.IsAutoRate = FALSE;
#ifdef MT_MAC
		/* For  MT STA LP control, use H/W control mode for PM bit */
#if defined(CONFIG_STA_SUPPORT) && defined(CONFIG_PM_BIT_HW_MODE)
		mac_info.PsmBySw = 0;
#else
		mac_info.PsmBySw = 1;
#endif /* CONFIG_STA_SUPPORT && CONFIG_PM_BIT_HW_MODE */
		mac_info.q_idx = Q_IDX_AC4;

		if (!wdev)
			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_INFO, ("%s():Err!! wdev is NULL!!\n", __func__));
		else
			mac_info.OmacIdx = wdev->OmacIdx;

		RTMPMoveMemory(&pWirelessPkt[tx_hw_hdr_len], pNullFrm, frmLen);
		pAd->archOps.write_tmac_info_fixed_rate(pAd, (UCHAR *)tmac_info, &mac_info, &wdev->rate.MlmeTransmit);
#endif /* MT_MAC */
		/* pAd->NullContext.BulkOutSize = ( pAd->NullContext.BulkOutSize + 3) & (~3); */
#ifdef MT_MAC
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("%s - Send NULL Frame @%d Mbps...(PwrMgmt, PID)(%d, %d)\n", __func__, RateIdToMbps[pAd->CommonCfg.TxRate], pHeader_802_11->FC.PwrMgmt, mac_info.PID));
#else
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("%s - Send NULL Frame @%d Mbps...\n", __func__, RateIdToMbps[pAd->CommonCfg.TxRate]));
#endif
		/* RTUSB_SET_BULK_FLAG(pAd, fRTUSB_BULK_OUT_DATA_NULL); */
		pAd->Sequence = (pAd->Sequence + 1) & MAXSEQ;
		uLen = frmLen + tx_hw_hdr_len;
		SET_OS_PKT_LEN(pPacket, uLen);
		pBuf =  GET_OS_PKT_DATAPTR(pPacket);
		uLen =  GET_OS_PKT_LEN(pPacket);
		/* hex_dump("MtSDIONullFrameKickOut",pBuf,uLen); */
		MtSdioSubmitMgmtToSDIOWorker(pAd, mac_info.q_idx, pPacket, pSrcBufVA, uLen); /* SrcBufLen --> uLen */
		RTMP_IRQ_UNLOCK(&pAd->MgmtRingLock, Flags);
		/* Kick bulk out */
		/* RTUSBKickBulkOut(pAd); */
	}
}

PNDIS_PACKET
sdio_get_pkt_from_rx_resource(
	IN PRTMP_ADAPTER prAd,
	IN RX_BLK * *_prRxBlk,
	OUT BOOLEAN  *pbReschedule,
	OUT UINT32 *pRxPending,
	IN UCHAR RxRingNo
)
{
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(prAd->hdev_ctrl);
	UINT8 rx_hw_hdr_len = cap->RXWISize;
	PNDIS_PACKET prRxPacket;
	unsigned long flags;
	RX_BLK *prRxBlk = *_prRxBlk;
#if (CFG_SDIO_RX_AGG == 0) && (CFG_SDIO_INTR_ENHANCE == 0)
	prRxPacket = prAd->SDIORxPacket;
	PUCHAR prBuf = GET_OS_PKT_DATAPTR(prRxPacket);
	UINT32 u4len = GET_OS_PKT_LEN(prRxPacket);
	UINT32 u4i = 0;
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("%s===========start\n", __func__));
	prRxBlk->Flags = 0;

	if (!prRxPacket) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%s=====return NULL !!!!!\n", __func__));
		return NULL;
	}

	if (!prAd->fgSDIORxPacKetInUsed)
		return NULL;

	mt_rx_pkt_process(prAd, prRxBlk, prRxPacket);

	if (RX_BLK_TEST_FLAG(prRxBlk, fRX_CMD_RSP)) {
		RELEASE_NDIS_PACKET(prAd, prRxPacket, NDIS_STATUS_SUCCESS);
		return NULL;
	}

	prAd->fgSDIORxPacKetInUsed = FALSE;
	/* #elif(CFG_SDIO_RX_AGG == 0) && (CFG_SDIO_INTR_ENHANCE == 1) */
#else
	P_RX_CTRL_T prRxCtrl = NULL;
	unsigned long IrqFlags;
	QUEUE_ENTRY *pEntry;
	P_SW_RFB_T prSwRfb;
	PUCHAR prBuf;
	UINT32 u4len;
	/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("enter %s=====!!!!\n",__func__)); */
#ifdef CONFIG_CSO_SUPPORT
	UINT32 u4i;
	PUCHAR pcBufCso;
	RX_CSO_STRUCT *prCso;
#endif
	prRxCtrl = &prAd->rRxCtrl;
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("enter %s=====num: %x!!!!\n", __func__, prRxCtrl->rReceivedRfbList.Number));

	if (prRxCtrl->rReceivedRfbList.Number == 0)
		return NULL;

	RTMP_IRQ_LOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags);
	pEntry = RemoveHeadQueue(&prRxCtrl->rReceivedRfbList);
	RTMP_IRQ_UNLOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags)

	if (!pEntry) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("enter ==>%s NULL!!!!\n", __func__));
		return NULL;
	}

	prSwRfb = (P_SW_RFB_T)pEntry;
#if CFG_SDIO_STAT
	prAd->SdioStatistics.RxRceiveMax = (prAd->SdioStatistics.RxRceiveMax < prRxCtrl->rReceivedRfbList.Number) ? prRxCtrl->rReceivedRfbList.Number : prAd->SdioStatistics.RxRceiveMax;
#endif
	prRxPacket = prSwRfb->prRxPacket;/* prAd->SDIORxPacket; */

	if (!prRxPacket) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("%s=====return NULL !!!!!\n", __func__));
		return NULL;
	}

	prBuf = GET_OS_PKT_DATAPTR(prRxPacket);
	u4len = GET_OS_PKT_LEN(prRxPacket);
	prRxBlk->Flags = 0;
#ifdef CONFIG_CSO_SUPPORT
	pcBufCso = prBuf + ((u4len + 3) &  ~3);
	prCso = (RX_CSO_STRUCT *) pcBufCso;
	/* printk("=================>pcBufCso:\n"); */
	/* for(u4i = 0; u4i < 4; u4i++){ */
	/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%x ", *(pcBufCso + u4i))); */
	/* } */
	/* MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("cs_status: %x cs_type: %x", prCso->ChksumStatus,prCso->ChksumType)); */
	/* printk("\n"); */
	NdisCopyMemory(&(prRxBlk->rCso), prCso, sizeof(RX_CSO_STRUCT));
#endif
	/*
		printk("rx_packet_content:\n");
		for(u4i = 0; u4i < u4len; u4i++){
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_OFF, ("%x", *(prBuf + u4i)));
		}
	*/
	rx_hw_hdr_len = mt_rx_pkt_process(prAd, prRxBlk, prRxPacket);
	/*reallocate Packet buffer to rFreeSwRfbList*/
	prSwRfb->prRxPacket = RTMP_AllocateFragPacketBuffer(prAd, MAX_FRAME_SIZE);

	if (prSwRfb->prRxPacket == NULL) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("%s():Cannot Allocate sk buffer for this rx buffer!\n", __func__));
		return NULL;
	}

	RTMP_IRQ_LOCK(&prRxCtrl->rFreeSwRfbLock, flags);
	InsertTailQueue(&prRxCtrl->rFreeSwRfbList, &prSwRfb->rQueEntry);
	RTMP_IRQ_UNLOCK(&prRxCtrl->rFreeSwRfbLock, flags);

	if (rx_hw_hdr_len == 0)
		prRxBlk->DataSize = 0;

	if (RX_BLK_TEST_FLAG(prRxBlk, fRX_CMD_RSP)) {
		RELEASE_NDIS_PACKET(prAd, prRxPacket, NDIS_STATUS_SUCCESS);
		return NULL;
	}

	prRxBlk->pRxPacket = prRxPacket;
	prRxBlk->pData = (UCHAR *) GET_OS_PKT_DATAPTR(prRxPacket);
	/*
		RTMP_IRQ_LOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags);
		pEntry = RemoveHeadQueue(&prRxCtrl->rReceivedRfbList);
		prSwRfb = (P_SW_RFB_T)pEntry;
		RTMP_IRQ_UNLOCK(&prRxCtrl->rReceivedRfbLock, IrqFlags);
	*/
	/*when to release packet and return to rFreeSwRfbList*/
	/* #elif(CFG_SDIO_RX_AGG == 1) && (CFG_SDIO_INTR_ENHANCE == 1) */
#endif
#ifdef CFG_RX_AGG
#else
#endif
	return prRxPacket;
}

#if CFG_SDIO_TX_AGG

VOID MtSDIOAggTXInit(RTMP_ADAPTER *pAd)
{
	P_TX_CTRL_T prTxCtrl = &pAd->rTxCtrl;
#if CFG_SDIO_TX_THREAD
	prTxCtrl->pucAggOffset = prTxCtrl->pucTxCoalescingBufPtr;
	prTxCtrl->u4AggLen  = 0;
#else
	prTxCtrl->pucAggOffset = prTxCtrl->pucTxCoalescingBufPtr;
	prTxCtrl->u4AggLen  = 0;
#endif
}

VOID MtSDIOAggTXKickout(RTMP_ADAPTER *pAd)
{
	P_TX_CTRL_T prTxCtrl = &pAd->rTxCtrl;
	UCHAR *pucOutputBuf = NULL;
#if CFG_SDIO_TX_THREAD
	P_TX_RFB_T	pTxRfb;
	UINT32	dma_len = 0;
	unsigned long	IrqFlags = 0;
	QUEUE_ENTRY	*pEntry;
	ULONG	hwd_cnt;
	UINT8	u2PgCnt;
	INT32 Ret = 0;
#endif
#if CFG_SDIO_TX_THREAD
#if CFG_SDIO_STAT
	pAd->SdioStatistics.TxRdyMax = (prTxCtrl->TxReadyList.Number > pAd->SdioStatistics.TxRdyMax) ? prTxCtrl->TxReadyList.Number :  pAd->SdioStatistics.TxRdyMax;
#endif

	while (1) {
		if (prTxCtrl->TxReadyList.Number == 0) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_TRACE, ("(%s) TxReadyList is empty\n", __func__));
			break;
		}

		RTMP_IRQ_LOCK(&prTxCtrl->TxReadyLock, IrqFlags);
		pEntry = RemoveHeadQueue(&prTxCtrl->TxReadyList);
		RTMP_IRQ_UNLOCK(&prTxCtrl->TxReadyLock, IrqFlags)
		pTxRfb = (P_TX_RFB_T)pEntry;

		if (pTxRfb) {
			dma_len = pTxRfb->hdr_copy_len + pTxRfb->SrcBufLen;
			dma_len = ROUND_UP(dma_len, 4);
			/* CHECK RESOURCE IS ENOUGTH OR NOT IF not break */
#if 0
			hwd_cnt = MTSDIOTxQueryPageResource(pAd, pTxRfb->QueIdx);

			if (MtSDIOTxResourceRequest(pAd, pTxRfb->QueIdx, hwd_cnt, dma_len) != NDIS_STATUS_SUCCESS) {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("(%s) MtSDIOTxResourceRequest failuire\n", __func__));
				RTMP_IRQ_LOCK(&prTxCtrl->TxReadyLock, IrqFlags);
				InsertHeadQueue(&prTxCtrl->TxReadyList,  &pTxRfb->rQueEntry);
				RTMP_IRQ_UNLOCK(&prTxCtrl->TxReadyLock, IrqFlags)
				break;
			}

			u2PgCnt = MTSDIOTxGetPageCount(dma_len, TRUE);
			Ret = MTSDIOTxAcquireResource(pAd, pTxRfb->QueIdx, u2PgCnt);

			if (Ret) {
				MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("(%s): Tx data no resource ?\n", __func__));
				break;
			}

			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("*"));
#endif
			NdisCopyMemory(prTxCtrl->pucAggOffset, pTxRfb->HeaderBuf, pTxRfb->hdr_copy_len);
			prTxCtrl->pucAggOffset += (pTxRfb->hdr_copy_len);
			NdisCopyMemory(prTxCtrl->pucAggOffset, pTxRfb->pbuf, pTxRfb->SrcBufLen);
			prTxCtrl->pucAggOffset += ROUND_UP(pTxRfb->SrcBufLen, 4);
			prTxCtrl->u4AggLen  += dma_len;
			RELEASE_NDIS_PACKET(pAd, pTxRfb->prTxPacket, NDIS_STATUS_SUCCESS);
			RTMP_IRQ_LOCK(&prTxCtrl->TxFreeLock, IrqFlags);
			InsertTailQueue(&prTxCtrl->TxFreeList, &pTxRfb->rQueEntry);
			RTMP_IRQ_UNLOCK(&prTxCtrl->TxFreeLock, IrqFlags);
		} else {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_ERROR, ("(%s) pTxRfb is NULL\n", __func__));
			break;
		}
	}

#endif
#if CFG_SDIO_STAT

	if (pAd->SdioStatistics.TxCount  == 0) {
		pAd->SdioStatistics.TxR0  = 0;
		pAd->SdioStatistics.TxR1  = 0;
		pAd->SdioStatistics.TxR2  = 0;
		pAd->SdioStatistics.TxR3  = 0;
	}

	pAd->SdioStatistics.TxCount++;
	pAd->SdioStatistics.TxLenMax = (prTxCtrl->u4AggLen > pAd->SdioStatistics.TxLenMax) ? prTxCtrl->u4AggLen : pAd->SdioStatistics.TxLenMax;

	if (prTxCtrl->u4AggLen == 0)
		pAd->SdioStatistics.TxR0++;
	else if (prTxCtrl->u4AggLen < 1500)
		pAd->SdioStatistics.TxR1++;
	else if (prTxCtrl->u4AggLen < 15000)
		pAd->SdioStatistics.TxR2++;
	else if (prTxCtrl->u4AggLen < 30000)
		pAd->SdioStatistics.TxR3++;
	else
		pAd->SdioStatistics.TxR4++;

#endif
	pucOutputBuf = prTxCtrl->pucTxCoalescingBufPtr;

	if (prTxCtrl->u4AggLen  != 0)
		MTSDIOMultiWrite(pAd, WTDR1, pucOutputBuf, prTxCtrl->u4AggLen);

	/* hex_dump("xxx", pucOutputBuf, prTxBlk->Priv); */
}

#endif

#ifdef CONFIG_STA_SUPPORT
VOID MtSDIOStaAsicForceWakeupTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("<-- RtmpUsbStaAsicForceWakeupTimeout\n"));
#endif /* RELEASE_EXCLUDE */
}


VOID MtSDIOStaAsicWakeup(RTMP_ADAPTER *pAd, BOOLEAN bFromTx, PSTA_ADMIN_CONFIG pStaCfg)
{
#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	ASSERT(pStaCfg);

	if (pStaCfg)
		RTMPOffloadPm(pAd, pStaCfg, PM4, EXIT_PM_STATE);

#else
	BOOLEAN	Canceled;

	if (pAd->Mlme.AutoWakeupTimerRunning) {
		RTMPCancelTimer(&pAd->Mlme.AutoWakeupTimer, &Canceled);
		pAd->Mlme.AutoWakeupTimerRunning = FALSE;
	}

	AsicSendCommandToMcu(pAd, 0x31, 0xff, 0x00, 0x02, FALSE);
	pAd->StaCfg[0].PwrMgmt.bDoze = FALSE;
#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */
}


VOID MtSDIOStaAsicSleepAutoWakeup(
	PRTMP_ADAPTER pAd,
	PSTA_ADMIN_CONFIG pStaCfg)
{
#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	ASSERT(pStaCfg);

	if (pStaCfg)
		RTMPOffloadPm(pAd, pStaCfg, PM4, ENTER_PM_STATE);

#else
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("%s(): TbttNumToNextWakeUp=%d 1\n",
			 __func__, pStaCfg->ThisTbttNumToNextWakeUp));
#endif /* RELEASE_EXCLUDE */

	/* Not going to sleep if in the Count Down Time*/
	if (pStaCfg->CountDowntoPsm > 0)
		return;

	/* we have decided to SLEEP, so at least do it for a BEACON period.*/
	if (pStaCfg->ThisTbttNumToNextWakeUp == 0)
		pStaCfg->ThisTbttNumToNextWakeUp = 1;

	RTMPSetTimer(&pAd->Mlme.AutoWakeupTimer, AUTO_WAKEUP_TIMEOUT);
	pAd->Mlme.AutoWakeupTimerRunning = TRUE;
	{
		AsicSendCommandToMcu(pAd, 0x30, 0xff, 0xff, 0x02, FALSE);   /* send POWER-SAVE command to MCU. Timeout 40us.*/

		/* cancel bulk-in IRPs prevent blocking CPU enter C3.*/
		if ((pAd->PendingRx > 0) && (!RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_NIC_NOT_EXIST))) {
			RTUSBCancelPendingBulkInIRP(pAd);
			/* resend bulk-in IRPs to receive beacons after a period of (pAd->CommonCfg.BeaconPeriod - 40) ms*/
			pAd->PendingRx = 0;
		}
	}
	pAd->StaCfg[0].PwrMgmt.bDoze = TRUE;
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_HIF, CATHIF_SDIO, DBG_LVL_INFO, ("<-- AsicSleepAutoWakeup, TbttNumToNextWakeUp=%d\n", pStaCfg->ThisTbttNumToNextWakeUp));
#endif /* RELEASE_EXCLUDE */
#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */
}
#endif /* CONFIG_STA_SUPPORT */

VOID rtmp_hif_data_init(RTMP_ADAPTER *pAd)
{
	/* We reset TC quota here, because PSE re-init is done */
	MTSDIOTxResetResource(pAd);
	return;
}

NDIS_STATUS RTMPInitHifAdapterBlock(RTMP_ADAPTER *pAd)
{
	RTMP_SEM_EVENT_INIT(&(pAd->PowerLock), NULL);
	pAd->bDrvOwn = 0;
	pAd->bCRAccessing = 0;
	pAd->bSetFWOwnRunning = 0;
	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS RTMPFreeHifAdapterBlock(RTMP_ADAPTER *pAd)
{
	return NDIS_STATUS_SUCCESS;
}

