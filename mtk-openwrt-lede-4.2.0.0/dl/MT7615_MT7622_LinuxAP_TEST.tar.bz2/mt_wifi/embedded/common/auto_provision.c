/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 5F., No.36, Taiyuan St., Jhubei City,
 * Hsinchu County 302,
 * Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2009, Ralink Technology, Inc.
 *
 * All rights reserved. Ralink's source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of Ralink Tech. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	auto_provision

	Abstract:
*/

#include "rt_config.h"

#ifdef EASY_CONFIG_SETUP
#ifdef CONFIG_AP_SUPPORT
VOID AutoProvisionBuildAssocRespIE(
	IN	PRTMP_ADAPTER	pAd,
	IN  UCHAR			ApIdx,
	IN  UCHAR			Reason,
	OUT	PUCHAR			pOutBuf,
	OUT	PUCHAR			pIeLen)
{
	WSC_IE_HEADER	ieHdr;
	UCHAR			Data[512] = {0};
	PUCHAR			pData;
	INT				Len = 0, templen = 0;
	UINT8			tempVal = 0;
#ifdef EASY_CONFIG_SETUP
	UCHAR			ExtData[4] = {0};
#endif /* EASY_CONFIG_SETUP */
	UCHAR			Version = 0x10;
	USHORT			Tag = 0, TlvLen = 0;
	MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("-----> WscBuildAssocRespIE\n"));
	/* WSC IE Header */
	ieHdr.elemId = 221;
	ieHdr.length = 4;
	ieHdr.oui[0] = 0x00;
	ieHdr.oui[1] = 0x50;
	ieHdr.oui[2] = 0xF2;
	ieHdr.oui[3] = 0x04;
	pData = (PUCHAR) &Data[0];
	Len = 0;
	/* Version, 1 byte */
	Tag = cpu2be16(0x104A);
	TlvLen = cpu2be16(1);
	NdisMoveMemory(pData, &Tag, 2);
	NdisMoveMemory(pData + 2, &TlvLen, 2);
	NdisMoveMemory(pData + 4, &Version, 1);
	templen = 5;
	pData += templen;
	Len   += templen;
	/* Request Type */
	tempVal = 0x03;
	Tag = cpu2be16(0x103B);
	TlvLen = cpu2be16(1);
	NdisMoveMemory(pData, &Tag, 2);
	NdisMoveMemory(pData + 2, &TlvLen, 2);
	NdisMoveMemory(pData + 4, &tempVal, 1);
	templen = 5;
	pData += templen;
	Len   += templen;

	/*
		Only main bssid supports auto provision.
	*/
	if ((pAd->ApCfg.MBSSID[MAIN_MBSSID].EasyConfigInfo.bEnable == TRUE) &&
		(ApIdx == MAIN_MBSSID)) {
		/* WPS Vendor Extension */
		NdisMoveMemory(ExtData, RALINK_OUI, 3);
		ExtData[3] = Reason;
		Tag = cpu2be16(0x1049);
		TlvLen = cpu2be16(4);
		NdisMoveMemory(pData, &Tag, 2);
		NdisMoveMemory(pData + 2, &TlvLen, 2);
		NdisMoveMemory(pData + 4, &ExtData[0], 4);
		templen = 8;
		pData += templen;
		Len   += templen;
	}

	ieHdr.length = ieHdr.length + Len;
	NdisMoveMemory(pOutBuf, &ieHdr, sizeof(WSC_IE_HEADER));
	NdisMoveMemory(pOutBuf + sizeof(WSC_IE_HEADER), Data, Len);
	*pIeLen = sizeof(WSC_IE_HEADER) + Len;
	MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("<----- WscBuildAssocRespIE\n"));
}


VOID	AutoProvisionBuildAssocRspIE(
	IN  PRTMP_ADAPTER		pAd,
	IN  PMLME_QUEUE_ELEM	Elem,
	IN  PMAC_TABLE_ENTRY	pEntry,
	OUT PUCHAR				pOutBuffer,
	OUT PULONG				pFrameLen)
{
	if (pEntry && pEntry->bRaAutoWpsCapable) {
		UCHAR		*pWscBuf = NULL, WscIeLen = 0;
		ULONG		WscTmpLen = 0;
		PEASY_CONFIG_INFO	pEasyConfig = &pAd->ApCfg.MBSSID[pEntry->func_tb_idx].EasyConfigInfo;
		os_alloc_mem(NULL, (UCHAR **)&pWscBuf, 512);

		if (pWscBuf != NULL) {
			CHAR	Rssi = -80;
			Rssi = RTMPMaxRssi(pAd,
							   ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_0),
							   ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_1),
							   ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_2));
			NdisZeroMemory(pWscBuf, 512);
#ifdef WSC_AP_SUPPORT

			if ((pAd->ApCfg.MBSSID[pEntry->func_tb_idx].WscControl.WscConfMode != WSC_DISABLE) &&
				(MAC_ADDR_EQUAL(pAd->ApCfg.MBSSID[pEntry->func_tb_idx].WscControl.EntryAddr, pEntry->Addr))) {
				if (Rssi > pEasyConfig->RssiThreshold)
					WscBuildAssocRespIE(pAd, pEntry->func_tb_idx, 0, pWscBuf, &WscIeLen);
				else {
					pEntry->bRaAutoWpsCapable = FALSE;
					WscBuildAssocRespIE(pAd, pEntry->func_tb_idx, 1, pWscBuf, &WscIeLen);
				}
			} else
#endif /* WSC_AP_SUPPORT */
				if (pEasyConfig->bEnable == TRUE) {
					if (Rssi > pEasyConfig->RssiThreshold)
						AutoProvisionBuildAssocRespIE(pAd, pEntry->func_tb_idx, 0, pWscBuf, &WscIeLen);
					else {
						pEntry->bRaAutoWpsCapable = FALSE;
						AutoProvisionBuildAssocRespIE(pAd, pEntry->func_tb_idx, 1, pWscBuf, &WscIeLen);
					}
				}

			MakeOutgoingFrame(pOutBuffer + (*pFrameLen), &WscTmpLen,
							  WscIeLen,					 pWscBuf,
							  END_OF_ARGS);
			(*pFrameLen) += WscTmpLen;
			os_free_mem(pWscBuf);
		} else
			MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s:: WscBuf Allocate failed!\n", __FUNCTION__));
	}
}

VOID AutoProvisionCheckEntry(
	IN RTMP_ADAPTER * pAd,
	IN PMAC_TABLE_ENTRY pEntry,
	IN PEID_STRUCT eid_ptr)
{

	if (pAd->ApCfg.MBSSID[MAIN_MBSSID].EasyConfigInfo.bEnable == TRUE) {
		if (pEntry && eid_ptr) {
			pEntry->bRaAutoWpsCapable = FALSE;

			if (pEntry->func_tb_idx == MAIN_MBSSID) {
				if (WpsMICIntegrity(pAd, eid_ptr->Octet, (INT)eid_ptr->Len, pEntry->Addr, pEntry->func_tb_idx))
					pEntry->bRaAutoWpsCapable = TRUE;
			}
		}
	}
}

VOID	AutoProvisionAssignSSID(
	IN  PRTMP_ADAPTER		pAd,
	IN  PUCHAR				eid_data,
	IN  INT					eid_len,
	IN  PUCHAR				pAddr2,
	IN  UCHAR				apidx,
	OUT PUCHAR				SsidLen,
	OUT PUCHAR				Ssid)
{
	if (pAd->ApCfg.MBSSID[apidx].EasyConfigInfo.bEnable == FALSE) {
		MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("MBSSID[%d] do not support Easy Config, skip the checking EC OUI\n", apidx));
		return;
	}

	if (WpsMICIntegrity(pAd, eid_data, eid_len, pAddr2, apidx)) {
		*SsidLen = pAd->ApCfg.MBSSID[apidx].SsidLen;
		NdisMoveMemory(Ssid, pAd->ApCfg.MBSSID[apidx].Ssid, *SsidLen);
	}
}

BOOLEAN AutoProvisionCheckWscMsg(
	IN		PRTMP_ADAPTER	pAd,
	IN		PFRAME_802_11	pFrame,
	INOUT	PUSHORT			pDataSize)
{
	/*int                 HeaderLen = LENGTH_802_1_H + sizeof(IEEE8021X_FRAME) + sizeof(EAP_FRAME);*/
	RTMP_STRING *pData;
	PEAP_FRAME 		pEapFrame;
	/* Skip the EAP LLC header */
	pData = (RTMP_STRING *) (pFrame + LENGTH_802_1_H);

	if (pData)
		pEapFrame = (PEAP_FRAME)(pData + sizeof(IEEE8021X_FRAME));

	pData += sizeof(IEEE8021X_FRAME) + sizeof(EAP_FRAME);

	if ((pData != NULL) &&
		(pEapFrame->Code == EAP_CODE_RSP) &&
		(pEapFrame->Type == EAP_TYPE_WSC)) {
		if (WscCheckWSCHeader((PUCHAR) pData)) {
			/* EAP-Rsp (Messages) */
			pData += sizeof(WSC_FRAME);

			if (pData && (pData + 9)) {
				UCHAR MsgType = *(pData + 9);

				if (MsgType == 0x04) /* M1 */
					*pDataSize -= 19;
			}
		}
	}

	return FALSE;
}

#endif /* CONFIG_AP_SUPPORT */

VOID	AutoProvisionGenWpsPTK(
	IN  PRTMP_ADAPTER		pAd,
	IN  UCHAR			ApIdx)
{
	UCHAR	temp1[64];
	CHAR	temp2[6] = {'r', 'a', 'l', 'i', 'n', 'k'};
	PEASY_CONFIG_INFO	pEasyConfigInfo;
#ifdef CONFIG_AP_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
		pEasyConfigInfo = &pAd->ApCfg.MBSSID[ApIdx].EasyConfigInfo;
	}
#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		pEasyConfigInfo = &pAd->StaCfg[0].EasyConfigInfo;
	}
#endif /* CONFIG_STA_SUPPORT */
	/* use proprietary WPS PTK */
	NdisZeroMemory(temp1, 64);
	NdisMoveMemory(temp1, "ralink_auto_provision", strlen("ralink_auto_provision"));
	NdisZeroMemory(pEasyConfigInfo->WpsPTK, 64);
	/* use proprietary PTK */
	WpaDerivePTK(pAd, temp1, temp1, temp2, temp1, temp2, pEasyConfigInfo->WpsPTK, LEN_PTK);
}

VOID	AutoProvisionDecodeExtData(
	IN  PRTMP_ADAPTER	pAd,
	IN  UCHAR			ApIdx,
	IN  PUCHAR			pEntryAddr,
	IN  PUCHAR			pData)
{
#ifdef WSC_INCLUDED
	PWSC_CTRL			pWpsCtrl = NULL;
#endif /* WSC_INCLUDED */
	PMAC_TABLE_ENTRY	pEntry = NULL;
	PEASY_CONFIG_INFO	pEasyConfigInfo = NULL;
#ifdef CONFIG_AP_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
		pEasyConfigInfo = &pAd->ApCfg.MBSSID[ApIdx].EasyConfigInfo;
#ifdef WSC_INCLUDED
		pWpsCtrl = &pAd->ApCfg.MBSSID[ApIdx].WscControl;
#endif /* WSC_INCLUDED */
	}
#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		pEasyConfigInfo = &pAd->StaCfg[0].EasyConfigInfo;
#ifdef WSC_INCLUDED
		pWpsCtrl = &pAd->StaCfg[0].WscControl;
#endif /* WSC_INCLUDED */
	}
#endif /* CONFIG_STA_SUPPORT */
	pEntry = MacTableLookup(pAd, pEntryAddr);

	if (pEntry && (pEntry->bRaAutoWpsCapable && !pEntry->bSamsungAutoWpsCapable)) {
		CIPHER_KEY	CipherKey;
		CHAR		EncryptedPIN[16] = {0}, PinStr[9] = {0};
		UINT16		PinLen = 12;
		UCHAR		iv_hdr[4];
		NdisZeroMemory(&CipherKey, sizeof(CIPHER_KEY));
		NdisMoveMemory(&CipherKey, pEasyConfigInfo->WpsPTK, 64);
		CipherKey.CipherAlg = CIPHER_WEP128;
		CipherKey.KeyLen = 13;
		NdisMoveMemory(&EncryptedPIN[4], pData + 3, 12);
		/* Construct the 4-bytes WEP IV header */
		RTMPConstructWEPIVHdr(1,
							  CipherKey.TxTsc,
							  iv_hdr);
		NdisMoveMemory(&EncryptedPIN[0], &iv_hdr, 4);
		PinLen = 16;

		if (RTMPSoftDecryptWEP(pAd, &CipherKey, EncryptedPIN, &PinLen)) {
			NdisMoveMemory(PinStr, &EncryptedPIN[0], 8);
			NdisMoveMemory(&(pEasyConfigInfo->WpsPinCode[0]), &EncryptedPIN[0], 8);
#ifdef WSC_INCLUDED

			if ((pWpsCtrl->WscConfMode != WSC_DISABLE) &&
				(pEasyConfigInfo->bEnable)) {
				pWpsCtrl->WscPinCode = os_str_tol(PinStr, 0, 10);
				pWpsCtrl->WscPinCodeLen = 8;
				/*
					To make sure of doing WPS process with WPS Client by PIN method
				*/
				pWpsCtrl->WscMode = WSC_PIN_MODE;
				WscGetRegDataPIN(pAd, pWpsCtrl->WscPinCode, pWpsCtrl);
			}

#endif /* WSC_INCLUDED */
		}
	}
}

BOOLEAN WpsMICIntegrity(
	IN  PRTMP_ADAPTER	pAd,
	IN  PUCHAR			pData,
	IN  INT			DataLen,
	IN	PUCHAR			pMacAddr,
	IN	UCHAR			ApIdx)
{
	BOOLEAN		bStatus = FALSE;
	PUCHAR		pBuf = NULL;
	INT			BufLen = 0, Length = DataLen;
	UCHAR		*Ptr = pData + 4, *pWpsMIC = NULL, *pPeerWpsMIC = NULL;
	WSC_IE		*pWscIE;
	EASY_CONFIG_INFO	*pEasyConfigInfo = NULL;

	if (DataLen > 255) {
		MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s: DataLen > 255\n", __FUNCTION__));
		return FALSE;
	}

	os_alloc_mem(NULL, (UCHAR **)&pBuf, 256);

	if (pBuf == NULL) {
		MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s: pBuf alloc fail !!\n", __FUNCTION__));
		return FALSE;
	}

	pWpsMIC = pBuf + 200;
	pPeerWpsMIC = pBuf + 216;
#ifdef CONFIG_AP_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
		pEasyConfigInfo = &pAd->ApCfg.MBSSID[ApIdx].EasyConfigInfo;
	}
#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		pEasyConfigInfo = &pAd->StaCfg[0].EasyConfigInfo;
	}
#endif /* CONFIG_STA_SUPPORT */
	NdisZeroMemory(pBuf, 256);

	while (Length > 0) {
		WSC_IE	WscIE;
		NdisMoveMemory(&WscIE, Ptr, sizeof(WSC_IE));
		/* Check for WSC IEs */
		pWscIE = &WscIE;

		/* Check for device password ID, PBC = 0x0004 */
		if (be2cpu16(pWscIE->Type) == 0x1049) {
			/*
				4: 0x00 0x50 0xF2 0x04
				4: 0x10 0x49 0x00 0x0x
			*/
			BufLen = DataLen - 4 - 4 - (INT)be2cpu16(pWscIE->Length);
			NdisMoveMemory(pBuf, pData + 4, BufLen);
			/*
				7: 0x10 0x49 0x00 0x0x 0x00 0x0c 0x43
			*/
			NdisMoveMemory(pPeerWpsMIC, Ptr + 7, LEN_KEY_DESC_MIC);
			WpsCalculateMIC(pAd, pBuf, BufLen, pEasyConfigInfo, pMacAddr, pWpsMIC);

			if (NdisEqualMemory(pPeerWpsMIC, pWpsMIC, LEN_KEY_DESC_MIC))
				bStatus = TRUE;

			break;
		}

		/* Set the offset and look for PBC information */
		/* Since Type and Length are both short type, we need to offset 4, not 2 */
		Ptr		+= (be2cpu16(pWscIE->Length) + 4);
		Length	-= (be2cpu16(pWscIE->Length) + 4);
	}

	os_free_mem(pBuf);
	return bStatus;
}

VOID	WpsCalculateMIC(
	IN  PRTMP_ADAPTER		pAd,
	IN  PUCHAR				pBuf,
	IN	INT					BufLen,
	IN	PEASY_CONFIG_INFO	pEasyConfig,
	IN  PUCHAR				pMacAddr,
	OUT	PUCHAR				pMIC)
{
	PUCHAR			pDigest = NULL, pTemp = NULL;
	os_alloc_mem(NULL, &pTemp, 256);

	if (pTemp == NULL) {
		MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s: pTemp alloc fail !!\n", __FUNCTION__));
		return;
	}

	os_alloc_mem(NULL, &pDigest, 80);

	if (pDigest == NULL) {
		os_free_mem(pTemp);
		MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s: pDigest alloc fail !!\n", __FUNCTION__));
		return;
	}

	NdisZeroMemory(pTemp, 256);
	NdisMoveMemory(pTemp, pBuf, BufLen);
	NdisMoveMemory(pTemp + BufLen, pMacAddr, MAC_ADDR_LEN);
	RT_HMAC_SHA1(pEasyConfig->WpsPTK, LEN_PTK_KCK, pTemp, BufLen + MAC_ADDR_LEN, pDigest, SHA1_DIGEST_SIZE);
	NdisMoveMemory(pMIC, pDigest, LEN_KEY_DESC_MIC);
	os_free_mem(pTemp);
	os_free_mem(pDigest);
}
#endif /* EASY_CONFIG_SETUP */
