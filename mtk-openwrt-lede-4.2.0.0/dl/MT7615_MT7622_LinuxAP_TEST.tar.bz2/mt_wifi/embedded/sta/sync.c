/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 * (c) Copyright 2002, Ralink Technology, Inc.
 *
 * All rights reserved. Ralink's source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of Ralink Tech. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	sync.c

	Abstract:

	Revision History:
	Who			When			What
	--------	----------		----------------------------------------------

*/
#include "rt_config.h"
#ifdef MESH_SUPPORT
#include "mesh_sanity.h"
#endif /* MESH_SUPPORT */

#ifdef DOT11R_FT_SUPPORT
#include "ft.h"
#endif /* DOT11R_FT_SUPPORT */

#define ADHOC_ENTRY_BEACON_LOST_TIME	(2*OS_HZ)	/* 2 sec */


#ifdef DBG
VOID dump_bcn_ie_list(RTMP_ADAPTER *pAd, BCN_IE_LIST *ie_list)
{
	ASSERT(ie_list);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Dump BCN_IE_LIST\n"));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\tAddr2=%02x:%02x:%02x:%02x:%02x:%02x\n",
			 PRINT_MAC(ie_list->Addr2)));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\tBssid=%02x:%02x:%02x:%02x:%02x:%02x\n",
			 PRINT_MAC(ie_list->Bssid)));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\tSSID[len=%d]=%s\n",
			 ie_list->SsidLen, ie_list->Ssid));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\tBssType=%d\n", ie_list->BssType));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\tBeaconPeriod=%d\n", ie_list->BeaconPeriod));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\tChannel=%d\n", ie_list->Channel));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\tNewChannel=%d\n", ie_list->NewChannel));
}
#endif /* DBG */


/*
 *	==========================================================================
 *	Description:
 *		The sync state machine,
 *	Parameters:
 *		Sm - pointer to the state machine
 *	Note:
 *		the state machine looks like the following
 *
 *	==========================================================================
 */
VOID SyncStateMachineInit(
	IN PRTMP_ADAPTER pAd,
	IN struct wifi_dev *wdev,
	IN STATE_MACHINE * Sm,
	OUT STATE_MACHINE_FUNC Trans[])
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	StateMachineInit(Sm, Trans, MAX_SYNC_STATE, MAX_SYNC_MSG, (STATE_MACHINE_FUNC)Drop, SYNC_IDLE, SYNC_MACHINE_BASE);
	/* column 1 */
	StateMachineSetAction(Sm, SYNC_IDLE, MT2_MLME_SCAN_REQ, (STATE_MACHINE_FUNC)MlmeScanReqAction);
	StateMachineSetAction(Sm, SYNC_IDLE, MT2_MLME_FORCE_SCAN_REQ, (STATE_MACHINE_FUNC)MlmeForceScanReqAction);
	StateMachineSetAction(Sm, SYNC_IDLE, MT2_MLME_JOIN_REQ, (STATE_MACHINE_FUNC)MlmeJoinReqAction);
	StateMachineSetAction(Sm, SYNC_IDLE, MT2_MLME_FORCE_JOIN_REQ, (STATE_MACHINE_FUNC)MlmeForceJoinReqAction);
	StateMachineSetAction(Sm, SYNC_IDLE, MT2_MLME_START_REQ, (STATE_MACHINE_FUNC)MlmeStartReqAction);
	StateMachineSetAction(Sm, SYNC_IDLE, MT2_PEER_BEACON, (STATE_MACHINE_FUNC)PeerBeacon);
	StateMachineSetAction(Sm, SYNC_IDLE, MT2_PEER_PROBE_REQ, (STATE_MACHINE_FUNC)PeerProbeReqAction);
#ifdef P2P_SUPPORT
	StateMachineSetAction(Sm, SYNC_IDLE, MT2_PEER_PROBE_RSP, (STATE_MACHINE_FUNC)PeerBeaconAtScanAction);
#endif /* P2P_SUPPORT */
	/* column 2 */
	StateMachineSetAction(Sm, JOIN_WAIT_BEACON, MT2_MLME_JOIN_REQ, (STATE_MACHINE_FUNC)MlmeJoinReqAction);
	StateMachineSetAction(Sm, JOIN_WAIT_BEACON, MT2_MLME_START_REQ, (STATE_MACHINE_FUNC)InvalidStateWhenStart);
	StateMachineSetAction(Sm, JOIN_WAIT_BEACON, MT2_PEER_BEACON, (STATE_MACHINE_FUNC)PeerBeaconAtJoinAction);
	StateMachineSetAction(Sm, JOIN_WAIT_BEACON, MT2_BEACON_TIMEOUT, (STATE_MACHINE_FUNC)BeaconTimeoutAtJoinAction);
#if defined(MT7636_FPGA) /*|| defined(MT7637_FPGA)*/
	StateMachineSetAction(Sm, JOIN_WAIT_BEACON, MT2_PEER_PROBE_RSP,
						  (STATE_MACHINE_FUNC)/*PeerBeaconAtScanAction*/PeerBeaconAtJoinAction);
#else
	StateMachineSetAction(Sm, JOIN_WAIT_BEACON, MT2_PEER_PROBE_RSP, (STATE_MACHINE_FUNC)PeerBeaconAtScanAction);
#endif /* MT7636_FPGA || MT7637_FPGA */
	/* column 3 */
	StateMachineSetAction(Sm, SCAN_LISTEN, MT2_MLME_JOIN_REQ, (STATE_MACHINE_FUNC)MlmeJoinReqAction);
	StateMachineSetAction(Sm, SCAN_LISTEN, MT2_MLME_START_REQ, (STATE_MACHINE_FUNC)InvalidStateWhenStart);
	StateMachineSetAction(Sm, SCAN_LISTEN, MT2_PEER_BEACON, (STATE_MACHINE_FUNC)PeerBeaconAtScanAction);
	StateMachineSetAction(Sm, SCAN_LISTEN, MT2_PEER_PROBE_RSP, (STATE_MACHINE_FUNC)PeerBeaconAtScanAction);
	StateMachineSetAction(Sm, SCAN_LISTEN, MT2_SCAN_TIMEOUT, (STATE_MACHINE_FUNC)ScanTimeoutAction);
	/* StateMachineSetAction(Sm, SCAN_LISTEN, MT2_MLME_SCAN_CNCL, (STATE_MACHINE_FUNC)ScanCnclAction); */
	/* resume scanning for fast-roaming */
	StateMachineSetAction(Sm, SCAN_PENDING, MT2_MLME_SCAN_REQ, (STATE_MACHINE_FUNC)MlmeScanReqAction);
	StateMachineSetAction(Sm, SCAN_PENDING, MT2_PEER_BEACON, (STATE_MACHINE_FUNC)PeerBeacon);
	/* timer init */
	pStaCfg->MlmeAux.BeaconTimerFuncContext.pAd = pAd;
	pStaCfg->MlmeAux.BeaconTimerFuncContext.wdev = wdev;
	RTMPInitTimer(pAd, &pStaCfg->MlmeAux.BeaconTimer, GET_TIMER_FUNCTION(BeaconTimeout),
				  &pStaCfg->MlmeAux.BeaconTimerFuncContext, FALSE);
	pStaCfg->MlmeAux.ScanTimerFuncContext.pAd = pAd;
	pStaCfg->MlmeAux.ScanTimerFuncContext.wdev = wdev;
	RTMPInitTimer(pAd, &pStaCfg->MlmeAux.ScanTimer, GET_TIMER_FUNCTION(ScanTimeout), &pStaCfg->MlmeAux.ScanTimerFuncContext,
				  FALSE);
}

/*
 *	==========================================================================
 *	Description:
 *		Beacon timeout handler, executed in timer thread
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID BeaconTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	PTIMER_FUNC_CONTEXT pContext = (PTIMER_FUNC_CONTEXT)FunctionContext;
	RTMP_ADAPTER *pAd = pContext->pAd;
	struct wifi_dev *wdev = pContext->wdev;
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - BeaconTimeout\n"));

	/*
	 *    Do nothing if the driver is starting halt state.
	 *    This might happen when timer already been fired before cancel timer with mlmehalt
	 */
	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_HALT_IN_PROGRESS))
		return;

	MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_BEACON_TIMEOUT, 0, NULL, 0, wdev);
	RTMP_MLME_HANDLER(pAd);
}

/*
 *	==========================================================================
 *	Description:
 *		Scan timeout handler, executed in timer thread
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID ScanTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	PTIMER_FUNC_CONTEXT pContext = (PTIMER_FUNC_CONTEXT)FunctionContext;
	RTMP_ADAPTER *pAd = pContext->pAd;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, pContext->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("SYNC - Scan Timeout\n"));
#endif /* RELEASE_EXCLUDE */

	/*
	 *    Do nothing if the driver is starting halt state.
	 *    This might happen when timer already been fired before cancel timer with mlmehalt
	 */
	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_HALT_IN_PROGRESS))
		return;

	if (MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_SCAN_TIMEOUT, 0, NULL, 0, pContext->wdev))
		RTMP_MLME_HANDLER(pAd);
	else {
		/* To prevent SyncMachine.CurrState is SCAN_LISTEN forever. */
		pStaCfg->MlmeAux.Channel = 0;
		pAd->ScanCtrl.Channel = 0;
		ScanNextChannel(pAd, OPMODE_STA, pContext->wdev);
		RTMPSendWirelessEvent(pAd, IW_SCAN_ENQUEUE_FAIL_EVENT_FLAG, NULL, BSS0, 0);
	}
}


VOID MlmeForceJoinReqAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	BOOLEAN        TimerCancelled;
	HEADER_802_11 Hdr80211;
	NDIS_STATUS   NStatus;
	ULONG         FrameLen = 0;
	PUCHAR        pOutBuffer = NULL;
	PUCHAR        pSupRate = NULL;
	UCHAR         SupRateLen;
	PUCHAR        pExtRate = NULL;
	UCHAR         ExtRateLen;
	UCHAR         ASupRate[] = {0x8C, 0x12, 0x98, 0x24, 0xb0, 0x48, 0x60, 0x6C};
	UCHAR         ASupRateLen = sizeof(ASupRate) / sizeof(UCHAR);
	MLME_JOIN_REQ_STRUCT *pInfo = (MLME_JOIN_REQ_STRUCT *)(Elem->Msg);
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - MlmeForeJoinReqAction(BSS #%ld)\n", pInfo->BssIdx));
	/* reset all the timers */
	RTMPCancelTimer(&pStaCfg->MlmeAux.ScanTimer, &TimerCancelled);
	RTMPCancelTimer(&pStaCfg->MlmeAux.BeaconTimer, &TimerCancelled);
	{
		RTMPZeroMemory(pStaCfg->MlmeAux.Ssid, MAX_LEN_OF_SSID);
		NdisMoveMemory(pStaCfg->MlmeAux.Ssid, pStaCfg->ConnectinfoSsid, pStaCfg->ConnectinfoSsidLen);
		pStaCfg->MlmeAux.SsidLen = pStaCfg->ConnectinfoSsidLen;
	}
	pStaCfg->MlmeAux.BssType = pStaCfg->ConnectinfoBssType;
	pStaCfg->MlmeAux.Channel = pStaCfg->ConnectinfoChannel;
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - BBP R4 to 20MHz.l\n"));
	RTMPSetTimer(&pStaCfg->MlmeAux.BeaconTimer, JOIN_TIMEOUT);

	do {
		/*
		 *send probe request
		 */
		NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);

		if (NStatus == NDIS_STATUS_SUCCESS) {
			if (pStaCfg->MlmeAux.Channel <= 14) {
				pSupRate = pStaCfg->wdev.rate.SupRate;
				SupRateLen = pStaCfg->wdev.rate.SupRateLen;
				pExtRate = pStaCfg->wdev.rate.ExtRate;
				ExtRateLen = pStaCfg->wdev.rate.ExtRateLen;
			} else {
				/*
				 *       Overwrite Support Rate, CCK rate are not allowed
				 */
				pSupRate = ASupRate;
				SupRateLen = ASupRateLen;
				ExtRateLen = 0;
			}

			if ((pStaCfg->MlmeAux.BssType == BSS_INFRA)  && (!MAC_ADDR_EQUAL(ZERO_MAC_ADDR, pStaCfg->ConnectinfoBssid))) {
				COPY_MAC_ADDR(pStaCfg->MlmeAux.Bssid, pStaCfg->ConnectinfoBssid);
				MgtMacHeaderInit(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, pStaCfg->MlmeAux.Bssid,
								 pStaCfg->wdev.if_addr,
								 pStaCfg->MlmeAux.Bssid);
			} else
				MgtMacHeaderInit(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, BROADCAST_ADDR,
								 pStaCfg->wdev.if_addr,
								 BROADCAST_ADDR);

			MakeOutgoingFrame(pOutBuffer,               &FrameLen,
							  sizeof(HEADER_802_11),    &Hdr80211,
							  1,                        &SsidIe,
							  1,                        &pStaCfg->MlmeAux.SsidLen,
							  pStaCfg->MlmeAux.SsidLen,	    pStaCfg->MlmeAux.Ssid,
							  1,                        &SupRateIe,
							  1,                        &SupRateLen,
							  SupRateLen,               pSupRate,
							  END_OF_ARGS);

			if (ExtRateLen) {
				ULONG Tmp;
				MakeOutgoingFrame(pOutBuffer + FrameLen,            &Tmp,
								  1,                                &ExtRateIe,
								  1,                                &ExtRateLen,
								  ExtRateLen,                       pExtRate,
								  END_OF_ARGS);
				FrameLen += Tmp;
			}

#ifdef WPA_SUPPLICANT_SUPPORT

			if ((pAd->OpMode == OPMODE_STA) &&
				(pStaCfg->wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) &&
				(pStaCfg->wpa_supplicant_info.WpsProbeReqIeLen != 0)) {
				ULONG		WpsTmpLen = 0;
				MakeOutgoingFrame(pOutBuffer + FrameLen,              &WpsTmpLen,
								  pStaCfg->wpa_supplicant_info.WpsProbeReqIeLen,
								  pStaCfg->wpa_supplicant_info.pWpsProbeReqIe,
								  END_OF_ARGS);
				FrameLen += WpsTmpLen;
			}

#ifdef RT_CFG80211_SUPPORT

			if ((pAd->OpMode == OPMODE_STA) &&
				(pStaCfg->wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) &&
				(pAd->cfg80211_ctrl.ExtraIeLen != 0)) {
				ULONG ExtraIeTmpLen = 0;
				MakeOutgoingFrame(pOutBuffer + FrameLen,              &ExtraIeTmpLen,
								  pAd->cfg80211_ctrl.ExtraIeLen,   pAd->cfg80211_ctrl.pExtraIe,
								  END_OF_ARGS);
				FrameLen += ExtraIeTmpLen;
			}

#endif /* RT_CFG80211_SUPPORT */
#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef WFD_SUPPORT
#ifdef RT_CFG80211_SUPPORT

			if (pStaCfg->WfdCfg.bSuppInsertWfdIe) {
				ULONG	WfdIeLen, WfdIeBitmap;
				PUCHAR	ptr;
				ptr = pOutBuffer + FrameLen;
				WfdIeBitmap = (0x1 << SUBID_WFD_DEVICE_INFO) | (0x1 << SUBID_WFD_ASSOCIATED_BSSID) |
							  (0x1 << SUBID_WFD_COUPLED_SINK_INFO);
				WfdMakeWfdIE(pAd, WfdIeBitmap, ptr, &WfdIeLen);
				FrameLen += WfdIeLen;
			}

#endif /* RT_CFG80211_SUPPORT */
#endif /* WFD_SUPPORT */
			MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
			MlmeFreeMemory(pOutBuffer);
		}
	} while (FALSE);

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, 0,
			 ("FORCE JOIN SYNC - Switch to ch %d, Wait BEACON from %02x:%02x:%02x:%02x:%02x:%02x\n",
			  pStaCfg->ConnectinfoChannel, PRINT_MAC(pStaCfg->ConnectinfoBssid)));
	pStaCfg->SyncMachine.CurrState = JOIN_WAIT_BEACON;
}


VOID MlmeForceScanReqAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	UCHAR          Ssid[MAX_LEN_OF_SSID], SsidLen, ScanType, BssType;
	BOOLEAN        TimerCancelled;
	ULONG		   Now;
	USHORT         Status;
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef RTMP_MAC_USB

	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_IDLE_RADIO_OFF))
		ASIC_RADIO_ON(pAd, MLME_RADIO_ON);

#endif /* RTMP_MAC_USB */

	/*
	 * Check the total scan tries for one single OID command
	 * If this is the CCX 2.0 Case, skip that!
	 */
	if (!RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_START_UP)) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - MlmeForceScanReqAction before Startup\n"));
		return;
	}

	/* first check the parameter sanity */
	if (MlmeScanReqSanity(pAd,
						  Elem->Msg,
						  Elem->MsgLen,
						  &BssType,
						  (PCHAR)Ssid,
						  &SsidLen,
						  &ScanType)) {
#ifdef RT_CFG80211_P2P_CONCURRENT_DEVICE

		if (pAd->ApCfg.ApCliTab[MAIN_MBSSID].Valid && RTMP_CFG80211_VIF_P2P_CLI_ON(pAd)) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CFG80211_NULL: PWR_SAVE IN ForceScanStart\n"));
			RT_CFG80211_P2P_CLI_SEND_NULL_FRAME(pAd, PWR_SAVE);
		}

#endif /* RT_CFG80211_P2P_CONCURRENT_DEVICE */
#ifdef CONFIG_MULTI_CHANNEL
#ifdef RT_CFG80211_SUPPORT

		if ((RTMP_CFG80211_VIF_P2P_GO_ON(pAd))) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("delay 380 for noa !!!!\n"));
			OS_WAIT(380);
		}

#endif /* RT_CFG80211_SUPPORT */
#endif /* CONFIG_MULTI_CHANNEL */

		/*
		 *    To prevent data lost.
		 *    Send an NULL data with turned PSM bit on to current associated AP before SCAN progress.
		 *    And should send an NULL data with turned PSM bit off to AP, when scan progress done
		 */
		if (STA_STATUS_TEST_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED) && (INFRA_ON(pStaCfg))) {
			RTMPSendNullFrame(pAd,
							  pStaCfg,
							  pAd->CommonCfg.TxRate,
							  (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_WMM_INUSED) ? TRUE : FALSE),
							  PWR_SAVE);
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("MlmeForceScanReqAction -- Send PSM Data frame for off channel RM, SCAN_IN_PROGRESS=%d!\n",
					  RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS)));
			OS_WAIT(20);
		}

		RTMPSendWirelessEvent(pAd, IW_SCANNING_EVENT_FLAG, NULL, BSS0, 0);
		NdisGetSystemUpTime(&Now);
		pStaCfg->LastScanTime = Now;
		/* reset all the timers */
		RTMPCancelTimer(&pStaCfg->MlmeAux.BeaconTimer, &TimerCancelled);
		RTMPCancelTimer(&pStaCfg->MlmeAux.ScanTimer, &TimerCancelled);
		/* record desired BSS parameters */
		pStaCfg->MlmeAux.BssType = BssType;
		pStaCfg->MlmeAux.ScanType = ScanType;
		pStaCfg->MlmeAux.SsidLen = SsidLen;
		NdisZeroMemory(pStaCfg->MlmeAux.Ssid, MAX_LEN_OF_SSID);
		NdisMoveMemory(pStaCfg->MlmeAux.Ssid, Ssid, SsidLen);
		pAd->ScanCtrl.BssType = BssType;
		pAd->ScanCtrl.ScanType = ScanType;
		pAd->ScanCtrl.SsidLen = SsidLen;
		NdisZeroMemory(pAd->ScanCtrl.Ssid, MAX_LEN_OF_SSID);
		NdisMoveMemory(pAd->ScanCtrl.Ssid, Ssid, SsidLen);

		/*
		 *	Scanning was pending (for fast scanning)
		 */
		if ((pStaCfg->bImprovedScan) && (pStaCfg->SyncMachine.CurrState == SCAN_PENDING)) {
			pStaCfg->MlmeAux.Channel = pStaCfg->LastScanChannel;
			pAd->ScanCtrl.Channel = pStaCfg->LastScanChannel;
		} else {
			if (pStaCfg->bFastConnect && (wdev->channel != 0) && !pStaCfg->bNotFirstScan) {
				pStaCfg->MlmeAux.Channel = wdev->channel;
				pAd->ScanCtrl.Channel = wdev->channel;
			} else {
				/* start from the first channel */
				pStaCfg->MlmeAux.Channel = FirstChannel(pAd);
				pAd->ScanCtrl.Channel = FirstChannel(pAd);
			}
		}

#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
		/* Before scan, reset trigger event table. */
		TriEventInit(pAd);
#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
		ScanNextChannel(pAd, OPMODE_STA, wdev);

		if (pStaCfg->ConnectinfoChannel != 0) {
			pStaCfg->MlmeAux.Channel = 0;
			pAd->ScanCtrl.Channel = 0;
		}

		pStaCfg->CntlMachine.CurrState = CNTL_WAIT_SCAN_FOR_CONNECT;
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("SYNC - MlmeForceScanReqAction() sanity check fail\n"));
		pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
		Status = MLME_INVALID_FORMAT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_SCAN_CONF, 2, &Status, 0, Elem->wdev);
	}
}



/*
 *	==========================================================================
 *	Description:
 *		MLME SCAN req state machine procedure
 *	==========================================================================
 */
VOID MlmeScanReqAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	UCHAR          Ssid[MAX_LEN_OF_SSID], SsidLen, ScanType, BssType;
	BOOLEAN        TimerCancelled;
	ULONG		   Now;
	USHORT         Status;
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef RTMP_MAC_USB

	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_IDLE_RADIO_OFF))
		ASIC_RADIO_ON(pAd, MLME_RADIO_ON);

#endif /* RTMP_MAC_USB */

	/*
	 * Check the total scan tries for one single OID command
	 * If this is the CCX 2.0 Case, skip that!
	 */
	if (!RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_START_UP)) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - MlmeScanReqAction before Startup\n"));
		return;
	}

#ifdef RTMP_SDIO_SUPPORT

	if (pAd->MCUCtrl.fwdl_ctrl.stage != FWDL_STAGE_FW_RUNNING) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("MlmeScanReqAction SDIO Ctl->fwdl_ctrl.stage != FWDL_STAGE_FW_RUNNING\n"));
		return;
	}

#endif

	/* first check the parameter sanity */
	if (MlmeScanReqSanity(pAd,
						  Elem->Msg,
						  Elem->MsgLen,
						  &BssType,
						  (PCHAR)Ssid,
						  &SsidLen,
						  &ScanType)) {
#ifdef RT_CFG80211_P2P_CONCURRENT_DEVICE

		if (pAd->ApCfg.ApCliTab[MAIN_MBSSID].Valid && RTMP_CFG80211_VIF_P2P_CLI_ON(pAd)) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CFG80211_NULL: PWR_SAVE IN ScanStart\n"));
			RT_CFG80211_P2P_CLI_SEND_NULL_FRAME(pAd, PWR_SAVE);
		}

#endif /* RT_CFG80211_P2P_CONCURRENT_DEVICE */
#ifdef CONFIG_MULTI_CHANNEL
#ifdef RT_CFG80211_SUPPORT

		if ((RTMP_CFG80211_VIF_P2P_GO_ON(pAd))) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("delay 380 for noa !!!!\n"));
			OS_WAIT(400);
		}

#endif /* RT_CFG80211_SUPPORT */
#endif /* CONFIG_MULTI_CHANNEL */

		/*
		 *    To prevent data lost.
		 *    Send an NULL data with turned PSM bit on to current associated AP before SCAN progress.
		 *    And should send an NULL data with turned PSM bit off to AP, when scan progress done
		 */
		if (STA_STATUS_TEST_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED) && (INFRA_ON(pStaCfg))) {
			if (pStaCfg->PwrMgmt.bDoze) {
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:: H/W is in DOZE, wake up H/W before scanning\n",
						 __func__));
				RTMP_FORCE_WAKEUP(pAd, pStaCfg);
			}

			RTMPSendNullFrame(pAd,
							  pStaCfg,
							  pAd->CommonCfg.TxRate,
							  (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_WMM_INUSED) ? TRUE : FALSE),
							  PWR_SAVE);
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("MlmeScanReqAction -- Send PSM Data frame for off channel RM, SCAN_IN_PROGRESS=%d!\n",
					  RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS)));
			OS_WAIT(20);
		}

		RTMPSendWirelessEvent(pAd, IW_SCANNING_EVENT_FLAG, NULL, BSS0, 0);
		NdisGetSystemUpTime(&Now);
		pStaCfg->LastScanTime = Now;
		/* reset all the timers */
		RTMPCancelTimer(&pStaCfg->MlmeAux.BeaconTimer, &TimerCancelled);
		RTMPCancelTimer(&pStaCfg->MlmeAux.ScanTimer, &TimerCancelled);
		/* record desired BSS parameters */
		pStaCfg->MlmeAux.BssType = BssType;
		pStaCfg->MlmeAux.ScanType = ScanType;
		pStaCfg->MlmeAux.SsidLen = SsidLen;
		NdisZeroMemory(pStaCfg->MlmeAux.Ssid, MAX_LEN_OF_SSID);
		NdisMoveMemory(pStaCfg->MlmeAux.Ssid, Ssid, SsidLen);
		/* YF */
		/* record desired BSS parameters */
		pAd->ScanCtrl.BssType = BssType;
		pAd->ScanCtrl.ScanType = ScanType;
		pAd->ScanCtrl.SsidLen = SsidLen;
		NdisMoveMemory(pAd->ScanCtrl.Ssid, Ssid, SsidLen);

		/* CFG_TODO */
		/* start from the first channel */
		/* pAd->ScanCtrl.Channel = FirstChannel(pAd); */

		/*
		 *	Scanning was pending (for fast scanning)
		 */
		if ((pStaCfg->bImprovedScan) && (pStaCfg->SyncMachine.CurrState == SCAN_PENDING))
			pStaCfg->MlmeAux.Channel = pStaCfg->LastScanChannel;

#ifdef P2P_SUPPORT
		else if (pAd->P2pCfg.CtrlCurrentState == P2P_CTRL_DISCOVERY)
			pStaCfg->MlmeAux.Channel = 1;

#endif /* P2P_SUPPORT */
		else {
			if (pStaCfg->bFastConnect && (wdev->channel != 0) && !pStaCfg->bNotFirstScan)
				pStaCfg->MlmeAux.Channel = wdev->channel;
			else {
#ifdef WIDI_SUPPORT
#ifdef P2P_SUPPORT

				/*
				 *	We need to set P2P DISC SM to be IDEL for following P2P Spec.
				 */
				if (pAd->P2pCfg.bWIDI) {
					MlmeEnqueueWithWdev(pAd, P2P_DISC_STATE_MACHINE, P2P_DISC_CANL_CMD_EVT, 0, NULL, 0, Elem->wdev);
					RTMP_MLME_HANDLER(pAd);
				}

				if (pAd->P2pCfg.bWIDI) {
					if (pStaCfg->MlmeAux.OldChannel > 0 && (pStaCfg->MlmeAux.ScanType == SCAN_PASSIVE)) {
						pStaCfg->MlmeAux.Channel = pStaCfg->MlmeAux.OldChannel;
						pAd->ScanCtrl.Channel = pStaCfg->MlmeAux.OldChannel;
					}
				} else
#endif /* P2P_SUPPORT */
#endif /* WIDI_SUPPORT */
				{
					/* start from the first channel */
					pStaCfg->MlmeAux.Channel = FirstChannel(pAd);
					pAd->ScanCtrl.Channel = FirstChannel(pAd);
				}
			}
		}

#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
		/* Before scan, reset trigger event table. */
		TriEventInit(pAd);
#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
#ifdef MT76XX_BTCOEX_SUPPORT
		MLMEHook(pAd, WLAN_SCANREQEST, WLAN_NO_BSSID);
#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef COEX_SUPPORT

		if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd)) {
			if (pAd->ScanCtrl.Channel <= 14)
				MT76xxMLMEHook(pAd, MT76xx_WLAN_SCANREQEST_2G, 0);
			else
				MT76xxMLMEHook(pAd, MT76xx_WLAN_SCANREQEST_5G, 0);
		}

#endif /* COEX_SUPPORT */
		ScanNextChannel(pAd, OPMODE_STA, wdev);
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("SYNC - MlmeScanReqAction() sanity check fail\n"));
		pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
		Status = MLME_INVALID_FORMAT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_SCAN_CONF, 2, &Status, 0, Elem->wdev);
	}
}


/*
 *	==========================================================================
 *	Description:
 *		MLME JOIN req state machine procedure
 *	==========================================================================
 */
VOID MlmeJoinReqAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	BSS_ENTRY    *pBss;
	BOOLEAN       TimerCancelled;
	HEADER_802_11 Hdr80211;
	NDIS_STATUS   NStatus;
	ULONG         FrameLen = 0;
	PUCHAR        pOutBuffer = NULL;
	PUCHAR        pSupRate = NULL;
	UCHAR         SupRateLen;
	PUCHAR        pExtRate = NULL;
	UCHAR         ExtRateLen;
	UCHAR         ASupRate[] = {0x8C, 0x12, 0x98, 0x24, 0xb0, 0x48, 0x60, 0x6C};
	UCHAR         ASupRateLen = sizeof(ASupRate) / sizeof(UCHAR);
	MLME_JOIN_REQ_STRUCT *pInfo = (MLME_JOIN_REQ_STRUCT *)(Elem->Msg);
	BOOLEAN       bChangeInitBW = FALSE;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
#ifdef P2P_SUPPORT
	PAPCLI_STRUCT pApCliEntry = NULL;
#endif /* P2P_SUPPORT */
	struct wifi_dev *wdev = Elem->wdev;
	struct _build_ie_info ie_info = {0};
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	ie_info.frame_subtype = SUBTYPE_PROBE_REQ;
	ie_info.channel = wdev->channel;
	ie_info.phy_mode = wdev->PhyMode;
	ie_info.wdev = wdev;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - MlmeJoinReqAction(BSS #%ld)\n", pInfo->BssIdx));
#ifdef MT76XX_BTCOEX_SUPPORT
	MLMEHook(pAd, WLAN_CONNECTION_START, QueryHashID(pAd, pStaCfg->MlmeAux.Bssid, FALSE));
#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef COEX_SUPPORT
	if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd)) {
		if ((pAd->BtWlanStatus & COEX_STATUS_LINK_UP) != 0)
			MT76xxMLMEHook(pAd, MT76xx_WLAN_LINK_DONE, 0);

		MT76xxMLMEHook(pAd, MT76xx_WLAN_LINK_START, 0);
	}

#endif /*COEX_SUPPORT */
	/* reset all the timers */
	RTMPCancelTimer(&pStaCfg->MlmeAux.ScanTimer, &TimerCancelled);
	RTMPCancelTimer(&pStaCfg->MlmeAux.BeaconTimer, &TimerCancelled);
	pBss = &pStaCfg->MlmeAux.SsidBssTab.BssEntry[pInfo->BssIdx];
	/* record the desired SSID & BSSID we're waiting for */
	COPY_MAC_ADDR(pStaCfg->MlmeAux.Bssid, pBss->Bssid);

	/* If AP's SSID is not hidden, it is OK for updating ssid to MlmeAux again. */
	if (pBss->Hidden == 0) {
		RTMPZeroMemory(pStaCfg->MlmeAux.Ssid, MAX_LEN_OF_SSID);
		NdisMoveMemory(pStaCfg->MlmeAux.Ssid, pBss->Ssid, pBss->SsidLen);
		pStaCfg->MlmeAux.SsidLen = pBss->SsidLen;
	}

#ifdef CONFIG_MULTI_CHANNEL
	/* pAd->Mlme.channel_1st_channel = pStaCfg->MlmeAux.Channel; */
	/* pAd->MCC_Connect_Protect = TRUE; */
	/* pAd->MCC_Connect_Count = 0; */
#endif /* CONFIG_MULTI_CHANNEL */
	pStaCfg->MlmeAux.BssType = pBss->BssType;
	pStaCfg->MlmeAux.Channel = pBss->Channel;
	pStaCfg->MlmeAux.CentralChannel = pBss->CentralChannel;
#ifdef EXT_BUILD_CHANNEL_LIST

	/* Country IE of the AP will be evaluated and will be used. */
	if ((pStaCfg->IEEE80211dClientMode != Rt802_11_D_None) &&
		(pBss->bHasCountryIE == TRUE)) {
		NdisMoveMemory(&pAd->CommonCfg.CountryCode[0], &pBss->CountryString[0], 2);

		if (pBss->CountryString[2] == 'I')
			pAd->CommonCfg.Geography = IDOR;
		else if (pBss->CountryString[2] == 'O')
			pAd->CommonCfg.Geography = ODOR;
		else
			pAd->CommonCfg.Geography = BOTH;

		BuildChannelListEx(pAd);
	}

#endif /* EXT_BUILD_CHANNEL_LIST */
#ifdef P2P_SUPPORT
	pApCliEntry = &pAd->ApCfg.ApCliTab[BSS0];

	if (!P2P_GO_ON(pAd) && (pApCliEntry->Valid == FALSE))
#endif /* P2P_SUPPORT */
	{
		bChangeInitBW = TRUE;
	}

#ifdef P2P_SUPPORT

	if ((P2P_GO_ON(pAd) || (pApCliEntry->Valid == TRUE)) && (wdev->channel != pStaCfg->MlmeAux.Channel))
		bChangeInitBW = TRUE;

#endif /* P2P_SUPPORT */

	if (bChangeInitBW == TRUE) {
		HcCrossChannelCheck(pAd, wdev, pStaCfg->MlmeAux.Channel);
		/* switch channel and waiting for beacon timer */
		wdev->channel  = pStaCfg->MlmeAux.Channel;
		wlan_operate_scan(wdev, pStaCfg->MlmeAux.Channel);
	}

#ifdef WSC_STA_SUPPORT
#ifdef WSC_LED_SUPPORT

	/* LED indication. */
	if (pStaCfg->MlmeAux.BssType == BSS_INFRA) {
		LEDConnectionStart(pAd);
		LEDConnectionCompletion(pAd, TRUE);
	}

#endif /* WSC_LED_SUPPORT */
#endif /* WSC_STA_SUPPORT */
	RTMPSetTimer(&pStaCfg->MlmeAux.BeaconTimer, JOIN_TIMEOUT);

	do {
		if (((pAd->CommonCfg.bIEEE80211H == 1) &&
			 (pStaCfg->MlmeAux.Channel > 14) &&
			 RadarChannelCheck(pAd, pStaCfg->MlmeAux.Channel))
#ifdef CARRIER_DETECTION_SUPPORT /* Roger sync Carrier */
			|| (pAd->CommonCfg.CarrierDetect.Enable == TRUE)
#endif /* CARRIER_DETECTION_SUPPORT */
		   ) {
			/* We can't send any Probe request frame to meet 802.11h. */
			if (pBss->Hidden == 0)
				break;
		}

		/*
		 *    send probe request
		 */
		NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);

		if (NStatus == NDIS_STATUS_SUCCESS) {
			if (pStaCfg->MlmeAux.Channel <= 14) {
				pSupRate = wdev->rate.SupRate;
				SupRateLen = wdev->rate.SupRateLen;
				pExtRate = wdev->rate.ExtRate;
				ExtRateLen = wdev->rate.ExtRateLen;
			} else {
				/* Overwrite Support Rate, CCK rate are not allowed */
				pSupRate = ASupRate;
				SupRateLen = ASupRateLen;
				ExtRateLen = 0;
			}

			if (pStaCfg->MlmeAux.BssType == BSS_INFRA)
				MgtMacHeaderInit(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, pStaCfg->MlmeAux.Bssid,
								 wdev->if_addr,/* pAd->CurrentAddress, */
								 pStaCfg->MlmeAux.Bssid);
			else
				MgtMacHeaderInit(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, BROADCAST_ADDR,
								 wdev->if_addr,/* pAd->CurrentAddress, */
								 BROADCAST_ADDR);

			MakeOutgoingFrame(pOutBuffer, &FrameLen,
							  sizeof(HEADER_802_11), &Hdr80211,
							  1,                        &SsidIe,
							  1,                        &pStaCfg->MlmeAux.SsidLen,
							  pStaCfg->MlmeAux.SsidLen, pStaCfg->MlmeAux.Ssid,
							  1,                        &SupRateIe,
							  1,                        &SupRateLen,
							  SupRateLen,               pSupRate,
							  END_OF_ARGS);

			if (ExtRateLen) {
				ULONG Tmp;
				MakeOutgoingFrame(pOutBuffer + FrameLen, &Tmp,
								  1,                                &ExtRateIe,
								  1,                                &ExtRateLen,
								  ExtRateLen,                       pExtRate,
								  END_OF_ARGS);
				FrameLen += Tmp;
			}

#ifdef WSC_INCLUDED
			ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
			FrameLen += build_wsc_ie(pAd, &ie_info);
#endif /* WSC_INCLUDED */

#ifdef WPA_SUPPLICANT_SUPPORT

			if ((pAd->OpMode == OPMODE_STA) &&
				(pStaCfg->wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) &&
				(pStaCfg->wpa_supplicant_info.WpsProbeReqIeLen != 0)) {
				ULONG		WpsTmpLen = 0;
				MakeOutgoingFrame(pOutBuffer + FrameLen,              &WpsTmpLen,
								  pStaCfg->wpa_supplicant_info.WpsProbeReqIeLen,
								  pStaCfg->wpa_supplicant_info.pWpsProbeReqIe,
								  END_OF_ARGS);
				FrameLen += WpsTmpLen;
			}

#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef RT_CFG80211_SUPPORT

			if ((pAd->OpMode == OPMODE_STA) &&
				(pStaCfg->wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) &&
				(pAd->cfg80211_ctrl.ExtraIeLen != 0)) {
				ULONG ExtraIeTmpLen = 0;
				MakeOutgoingFrame(pOutBuffer + FrameLen,              &ExtraIeTmpLen,
								  pAd->cfg80211_ctrl.ExtraIeLen,   pAd->cfg80211_ctrl.pExtraIe,
								  END_OF_ARGS);
				FrameLen += ExtraIeTmpLen;
			}

#endif /* RT_CFG80211_SUPPORT */
#ifdef WFD_SUPPORT
#ifdef RT_CFG80211_SUPPORT

			if (pStaCfg->WfdCfg.bSuppInsertWfdIe) {
				ULONG	WfdIeLen, WfdIeBitmap;
				PUCHAR	ptr;
				ptr = pOutBuffer + FrameLen;
				WfdIeBitmap = (0x1 << SUBID_WFD_DEVICE_INFO) | (0x1 << SUBID_WFD_ASSOCIATED_BSSID) |
							  (0x1 << SUBID_WFD_COUPLED_SINK_INFO);
				WfdMakeWfdIE(pAd, WfdIeBitmap, ptr, &WfdIeLen);
				FrameLen += WfdIeLen;
			}

#endif /* RT_CFG80211_SUPPORT */
#endif /* WFD_SUPPORT */
			MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
			MlmeFreeMemory(pOutBuffer);
#ifdef RELEASE_EXCLUDE
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("SYNC - send ProbeReq @ channel=%d, Len=%ld\n",
					 pStaCfg->MlmeAux.Channel, FrameLen));
#endif /* RELEASE_EXCLUDE */
		}
	} while (FALSE);

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("SYNC - Switch to ch %d, Wait BEACON from %02x:%02x:%02x:%02x:%02x:%02x\n",
			  pBss->Channel, PRINT_MAC(pBss->Bssid)));
	pStaCfg->SyncMachine.CurrState = JOIN_WAIT_BEACON;
}

/*
 *	==========================================================================
 *	Description:
 *		MLME START Request state machine procedure, starting an IBSS
 *	==========================================================================
 */
VOID MlmeStartReqAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	UCHAR Ssid[MAX_LEN_OF_SSID], SsidLen;
	BOOLEAN TimerCancelled;
	UCHAR *VarIE = NULL;		/* New for WPA security suites */
	NDIS_802_11_VARIABLE_IEs *pVIE = NULL;
	LARGE_INTEGER TimeStamp;
	BOOLEAN Privacy;
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	/* allocate memory */
	os_alloc_mem(NULL, (UCHAR **)&VarIE, MAX_VIE_LEN);

	if (VarIE == NULL) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: Allocate memory fail!!!\n", __func__));
		return;
	}

	/* Init Variable IE structure */
	pVIE = (PNDIS_802_11_VARIABLE_IEs) VarIE;
	pVIE->Length = 0;
	TimeStamp.u.LowPart  = 0;
	TimeStamp.u.HighPart = 0;

	if ((MlmeStartReqSanity(pAd, Elem->Msg, Elem->MsgLen, (PCHAR)Ssid, &SsidLen)) &&
		(CHAN_PropertyCheck(pAd, pStaCfg->MlmeAux.Channel, CHANNEL_NO_IBSS) == FALSE)) {
		struct wifi_dev *wdev = &pStaCfg->wdev;
		/* reset all the timers */
		RTMPCancelTimer(&pStaCfg->MlmeAux.ScanTimer, &TimerCancelled);
		RTMPCancelTimer(&pStaCfg->MlmeAux.BeaconTimer, &TimerCancelled);
		/* Start a new IBSS. All IBSS parameters are decided now */
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("MlmeStartReqAction - Start a new IBSS. All IBSS parameters are decided now....\n"));
		pStaCfg->MlmeAux.BssType = BSS_ADHOC;
		NdisMoveMemory(pStaCfg->MlmeAux.Ssid, Ssid, SsidLen);
		pStaCfg->MlmeAux.SsidLen = SsidLen;
#ifdef IWSC_SUPPORT

		if (pStaCfg->IWscInfo.bDoNotChangeBSSID)
			pStaCfg->IWscInfo.bDoNotChangeBSSID = FALSE;
		else
#endif /* IWSC_SUPPORT */
		{
			/* generate a radom number as BSSID */
			MacAddrRandomBssid(pAd, pStaCfg->MlmeAux.Bssid);
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("MlmeStartReqAction - generate a radom number as BSSID\n"));
		}

		Privacy = IS_SECURITY(&wdev->SecConfig);
		pStaCfg->MlmeAux.CapabilityInfo = CAP_GENERATE(0, 1, Privacy, (pAd->CommonCfg.TxPreamble == Rt802_11PreambleShort),
										  pAd->CommonCfg.bUseShortSlotTime, 0);
		pStaCfg->MlmeAux.BeaconPeriod = pAd->CommonCfg.BeaconPeriod;
		pStaCfg->MlmeAux.AtimWin = pStaCfg->AtimWin;
		pStaCfg->MlmeAux.Channel = wdev->channel;
		pStaCfg->MlmeAux.CentralChannel = wdev->channel;
		pStaCfg->MlmeAux.SupRateLen = pStaCfg->wdev.rate.SupRateLen;
		NdisMoveMemory(pStaCfg->MlmeAux.SupRate, pStaCfg->wdev.rate.SupRate, MAX_LEN_OF_SUPPORTED_RATES);
		RTMPCheckRates(pAd, pStaCfg->MlmeAux.SupRate, &pStaCfg->MlmeAux.SupRateLen, wdev->PhyMode);
		pStaCfg->MlmeAux.ExtRateLen = pStaCfg->wdev.rate.ExtRateLen;
		NdisMoveMemory(pStaCfg->MlmeAux.ExtRate, pStaCfg->wdev.rate.ExtRate, MAX_LEN_OF_SUPPORTED_RATES);
		RTMPCheckRates(pAd, pStaCfg->MlmeAux.ExtRate, &pStaCfg->MlmeAux.ExtRateLen, wdev->PhyMode);
#ifdef DOT11_N_SUPPORT

		if (WMODE_CAP_N(wdev->PhyMode) && (pStaCfg->bAdhocN == TRUE)) {
			RTMPUpdateHTIE(&wdev->DesiredHtPhyInfo.MCSSet[0], wdev, &pStaCfg->MlmeAux.HtCapability,
						   &pStaCfg->MlmeAux.AddHtInfo);
			pStaCfg->MlmeAux.HtCapabilityLen = sizeof(HT_CAPABILITY_IE);
			/* Not turn pStaCfg->StaActive.SupportedHtPhy.bHtEnable = TRUE here. */
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC -pStaCfg->StaActive.SupportedHtPhy.bHtEnable = TRUE\n"));
#ifdef DOT11_VHT_AC

			if (WMODE_CAP_AC(wdev->PhyMode) &&
				(pStaCfg->MlmeAux.Channel > 14)) {
				build_vht_cap_ie(pAd, wdev, (UCHAR *)&pStaCfg->MlmeAux.vht_cap);
				pStaCfg->MlmeAux.vht_cap_len = sizeof(VHT_CAP_IE);
			}

#endif /* DOT11_VHT_AC */
		} else
#endif /* DOT11_N_SUPPORT */
		{
			pStaCfg->MlmeAux.HtCapabilityLen = 0;
			pStaCfg->StaActive.SupportedPhyInfo.bHtEnable = FALSE;
			NdisZeroMemory(&pStaCfg->StaActive.SupportedPhyInfo.MCSSet[0], 16);
		}

		/* temporarily not support QOS in IBSS */
		NdisZeroMemory(&pStaCfg->MlmeAux.APEdcaParm, sizeof(EDCA_PARM));
		NdisZeroMemory(&pStaCfg->MlmeAux.APQbssLoad, sizeof(QBSS_LOAD_PARM));
		NdisZeroMemory(&pStaCfg->MlmeAux.APQosCapability, sizeof(QOS_CAPABILITY_PARM));
		wdev->channel  = pStaCfg->MlmeAux.Channel;
		wlan_operate_set_prim_ch(wdev, pStaCfg->MlmeAux.Channel);
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("SYNC - MlmeStartReqAction(ch= %d,sup rates= %d, ext rates=%d)\n",
				  pStaCfg->MlmeAux.Channel, pStaCfg->MlmeAux.SupRateLen, pStaCfg->MlmeAux.ExtRateLen));
		pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
		Status = MLME_SUCCESS;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_START_CONF, 2, &Status, 0, Elem->wdev);
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("SYNC - MlmeStartReqAction() sanity check fail.\n"));
		pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
		Status = MLME_INVALID_FORMAT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_START_CONF, 2, &Status, 0, Elem->wdev);
	}

	if (VarIE != NULL)
		os_free_mem(VarIE);
}

#if 0
/* +++Add by shiang to check correctness of new sanity function */
VOID rtmp_dbg_sanity_diff(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	/* Parameters used for old sanity function */
	UCHAR Bssid[MAC_ADDR_LEN], Addr2[MAC_ADDR_LEN];
	UCHAR *Ssid = NULL;
	UCHAR SsidLen = 0, DtimCount, DtimPeriod, BcastFlag, MessageToMe, NewChannel, Channel = 0, BssType;
	CF_PARM CfParm = {0};
	USHORT BeaconPeriod, AtimWin, CapabilityInfo;
	LARGE_INTEGER TimeStamp;
	UCHAR SupRate[MAX_LEN_OF_SUPPORTED_RATES], ExtRate[MAX_LEN_OF_SUPPORTED_RATES];
	UCHAR CkipFlag;
	EDCA_PARM EdcaParm = {0};
	UCHAR AironetCellPowerLimit;
	UCHAR SupRateLen, ExtRateLen;
	QBSS_LOAD_PARM QbssLoad;
	QOS_CAPABILITY_PARM QosCapability = {0};
	ULONG RalinkIe;
	UCHAR			AddHtInfoLen;
	EXT_CAP_INFO_ELEMENT	ExtCapInfo;
	HT_CAPABILITY_IE		*pHtCapability = NULL;
	ADD_HT_INFO_IE		*pAddHtInfo = NULL;	/* AP might use this additional ht info IE */
	UCHAR			HtCapabilityLen = 0, PreNHtCapabilityLen = 0;
	UCHAR Erp;
	UCHAR			NewExtChannelOffset = 0xff;
	USHORT LenVIE;
	UCHAR *VarIE = NULL;
	NDIS_802_11_VARIABLE_IEs *pVIE = NULL;
#ifdef CONFIG_STA_SUPPORT
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT
	UCHAR SelReg;
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif /* CONFIG_STA_SUPPORT */
	BCN_IE_LIST *ie_list = NULL;
	BOOLEAN sanity_new, sanity_old;
	/* allocate memory */
	os_alloc_mem(NULL, (UCHAR **)&Ssid, MAX_LEN_OF_SSID);

	if (Ssid == NULL)
		goto LabelErr;

	os_alloc_mem(NULL, (UCHAR **)&pHtCapability, sizeof(HT_CAPABILITY_IE));

	if (pHtCapability == NULL)
		goto LabelErr;

	os_alloc_mem(NULL, (UCHAR **)&pAddHtInfo, sizeof(ADD_HT_INFO_IE));

	if (pAddHtInfo == NULL)
		goto LabelErr;

	NdisZeroMemory(&QbssLoad, sizeof(QBSS_LOAD_PARM)); /* woody */
#ifdef DOT11_N_SUPPORT
	RTMPZeroMemory(pHtCapability, sizeof(HT_CAPABILITY_IE));
	RTMPZeroMemory(pAddHtInfo, sizeof(ADD_HT_INFO_IE));
#endif /* DOT11_N_SUPPORT */
	NdisZeroMemory(Ssid, MAX_LEN_OF_SSID);
	os_alloc_mem(NULL, (UCHAR **)&ie_list, sizeof(BCN_IE_LIST));

	if (ie_list == NULL)
		goto LabelErr;

	NdisZeroMemory(ie_list, sizeof(BCN_IE_LIST));
	sanity_new = PeerBeaconAndProbeRspSanity(pAd,
				 Elem->wdev,
				 &Elem->Msg[0], Elem->MsgLen,
				 Elem->Channel,
				 ie_list, &LenVIE, pVIE, FALSE);
	sanity_old = PeerBeaconAndProbeRspSanity_Old(pAd,
				 Elem->Msg,
				 Elem->MsgLen,
				 Elem->Channel,
				 Addr2,
				 Bssid,
				 (PCHAR)Ssid,
				 &SsidLen,
				 &BssType,
				 &BeaconPeriod,
				 &Channel,
				 &NewChannel,
				 &TimeStamp,
				 &CfParm,
				 &AtimWin,
				 &CapabilityInfo,
				 &Erp,
				 &DtimCount,
				 &DtimPeriod,
				 &BcastFlag,
				 &MessageToMe,
				 SupRate,
				 &SupRateLen,
				 ExtRate,
				 &ExtRateLen,
				 &CkipFlag,
				 &AironetCellPowerLimit,
				 &EdcaParm,
				 &QbssLoad,
				 &QosCapability,
				 &RalinkIe,
				 &HtCapabilityLen,
#ifdef CONFIG_STA_SUPPORT
				 &PreNHtCapabilityLen,
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT
				 &SelReg,
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif /* CONFIG_STA_SUPPORT */
				 pHtCapability,
				 &ExtCapInfo,
				 &AddHtInfoLen,
				 pAddHtInfo,
				 &NewExtChannelOffset,
				 &LenVIE,
				 pVIE);

	if (sanity_old != sanity_new)
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("sanity mismatch, old=%d, new=%d\n", sanity_old, sanity_new));
	else {
		if (NdisCmpMemory(&ie_list->Addr2[0], &Addr2[0], MAC_ADDR_LEN) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("Add2 mismatch!Old=%02x:%02x:%02x:%02x:%02x:%02x!New=%02x:%02x:%02x:%02x:%02x:%02x!\n",
					  PRINT_MAC(Addr2), PRINT_MAC(ie_list->Addr2)));
		}

		if (NdisCmpMemory(&ie_list->Bssid[0], &Bssid[0], MAC_ADDR_LEN) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("Bssid mismatch!Old=%02x:%02x:%02x:%02x:%02x:%02x!New=%02x:%02x:%02x:%02x:%02x:%02x!\n",
					  PRINT_MAC(Bssid), PRINT_MAC(ie_list->Bssid)));
		}

		if (SsidLen != ie_list->SsidLen)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("SsidLen mismatch!Old=%d, New=%d\n", SsidLen,
					 ie_list->SsidLen));

		if (NdisCmpMemory(&ie_list->Ssid[0], &Ssid[0], SsidLen) != 0)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Ssid mismatch!Old=%s, New=%s\n", Ssid, ie_list->Ssid));

		if (BssType != ie_list->BssType)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("BssType mismatch!Old=%d, New=%d\n", BssType,
					 ie_list->BssType));

		if (BeaconPeriod != ie_list->BeaconPeriod)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("BeaconPeriod mismatch!Old=%d, New=%d\n", BeaconPeriod,
					 ie_list->BeaconPeriod));

		if (Channel != ie_list->Channel)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Channel mismatch!Old=%d, New=%d\n", Channel,
					 ie_list->Channel));

		if (NewChannel != ie_list->NewChannel)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("NewChannel mismatch!Old=%d, New=%d\n", NewChannel,
					 ie_list->NewChannel));

		if (NdisCmpMemory(&ie_list->TimeStamp, &TimeStamp, sizeof(LARGE_INTEGER)) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("TimeStamp mismatch!Old=%d - %d, New=%d - %d\n",
					 TimeStamp.u.LowPart, TimeStamp.u.HighPart,
					 ie_list->TimeStamp.u.LowPart, ie_list->TimeStamp.u.HighPart));
		}

		if (NdisCmpMemory(&ie_list->CfParm, &CfParm, sizeof(CF_PARM)) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("CFParam mismatch!\n"));
			hex_dump("Old CFParam", (UCHAR *)&CfParm, sizeof(CF_PARM));
			hex_dump("New CFParam", (UCHAR *)&ie_list->CfParm, sizeof(CF_PARM));
		}

		if (AtimWin != ie_list->AtimWin)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("AtimWin mismatch!Old=%d, New=%d\n", AtimWin,
					 ie_list->AtimWin));

		if (CapabilityInfo != ie_list->CapabilityInfo)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("CapabilityInfo mismatch!Old=%d, New=%d\n", CapabilityInfo,
					 ie_list->CapabilityInfo));

		if (Erp != ie_list->Erp)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Erp mismatch!Old=%d, New=%d\n", Erp, ie_list->Erp));

		if (DtimCount != ie_list->DtimCount)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("DtimCount mismatch!Old=%d, New=%d\n", DtimCount,
					 ie_list->DtimCount));

		if (DtimPeriod != ie_list->DtimPeriod)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("DtimPeriod mismatch!Old=%d, New=%d\n", DtimPeriod,
					 ie_list->DtimPeriod));

		if (BcastFlag != ie_list->BcastFlag)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("BcastFlag mismatch!Old=%d, New=%d\n", BcastFlag,
					 ie_list->BcastFlag));

		if (MessageToMe != ie_list->MessageToMe)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("MessageToMe mismatch!Old=%d, New=%d\n", MessageToMe,
					 ie_list->MessageToMe));

		if (SupRateLen != ie_list->SupRateLen)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("SupRateLen mismatch!Old=%d, New=%d\n", SupRateLen,
					 ie_list->SupRateLen));

		if (NdisCmpMemory(&ie_list->SupRate[0], &SupRate, ie_list->SupRateLen) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("SupRate mismatch!\n"));
			hex_dump("Old SupRate", (UCHAR *)&SupRate, ie_list->SupRateLen);
			hex_dump("New SupRate", (UCHAR *)&ie_list->SupRate, ie_list->SupRateLen);
		}

		if (ExtRateLen != ie_list->ExtRateLen)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("ExtRateLen mismatch!Old=%d, New=%d\n", ExtRateLen,
					 ie_list->ExtRateLen));

		if (NdisCmpMemory(&ie_list->ExtRate[0], &ExtRate, ie_list->ExtRateLen) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("ExtRate mismatch!\n"));
			hex_dump("Old ExtRate", (UCHAR *)&ExtRate, ie_list->ExtRateLen);
			hex_dump("New ExtRate", (UCHAR *)&ie_list->ExtRate, ie_list->ExtRateLen);
		}

		if (CkipFlag != ie_list->CkipFlag)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("CkipFlag mismatch!Old=%d, New=%d\n", CkipFlag,
					 ie_list->CkipFlag));

		if (AironetCellPowerLimit != ie_list->AironetCellPowerLimit)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("AironetCellPowerLimit mismatch!Old=%d, New=%d\n",
					 AironetCellPowerLimit, ie_list->AironetCellPowerLimit));

		if (NdisCmpMemory(&ie_list->EdcaParm, &EdcaParm, sizeof(EDCA_PARM)) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("EdcaParm mismatch!\n"));
			hex_dump("Old EdcaParm", (UCHAR *)&EdcaParm, sizeof(EDCA_PARM));
			hex_dump("New EdcaParm", (UCHAR *)&ie_list->EdcaParm, sizeof(EDCA_PARM));
		}

		if (NdisCmpMemory(&ie_list->QbssLoad, &QbssLoad, sizeof(QBSS_LOAD_PARM)) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("QbssLoad mismatch!\n"));
			hex_dump("Old QbssLoad", (UCHAR *)&QbssLoad, sizeof(QBSS_LOAD_PARM));
			hex_dump("New QbssLoad", (UCHAR *)&ie_list->QbssLoad, sizeof(QBSS_LOAD_PARM));
		}

		if (NdisCmpMemory(&ie_list->QosCapability, &QosCapability, sizeof(QOS_CAPABILITY_PARM)) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("QosCapability mismatch!\n"));
			hex_dump("Old QosCapability", (UCHAR *)&QosCapability, sizeof(QOS_CAPABILITY_PARM));
			hex_dump("New QosCapability", (UCHAR *)&ie_list->QosCapability, sizeof(QOS_CAPABILITY_PARM));
		}

		if (RalinkIe != ie_list->vendor_ie.ra_cap)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("RalinkIe mismatch!Old=%lx, New=%lx\n", RalinkIe,
					 ie_list->vendor_ie.ra_cap));

		if (HtCapabilityLen != ie_list->HtCapabilityLen)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("HtCapabilityLen mismatch!Old=%d, New=%d\n", HtCapabilityLen,
					 ie_list->HtCapabilityLen));

#ifdef CONFIG_STA_SUPPORT

		if (PreNHtCapabilityLen != ie_list->PreNHtCapabilityLen)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("PreNHtCapabilityLen mismatch!Old=%d, New=%d\n",
					 PreNHtCapabilityLen, ie_list->PreNHtCapabilityLen));

#endif /* CONFIG_STA_SUPPORT */

		if (NdisCmpMemory(&ie_list->HtCapability, pHtCapability, sizeof(HT_CAPABILITY_IE)) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("pHtCapability mismatch!\n"));
			hex_dump("Old HtCapability", (UCHAR *)pHtCapability, sizeof(HT_CAPABILITY_IE));
			hex_dump("New HtCapability", (UCHAR *)&ie_list->HtCapability, sizeof(HT_CAPABILITY_IE));
		}

		if (NdisCmpMemory(&ie_list->ExtCapInfo, &ExtCapInfo, sizeof(EXT_CAP_INFO_ELEMENT)) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("ExtCapInfo mismatch!\n"));
			hex_dump("Old ExtCapInfo", (UCHAR *)&ExtCapInfo, sizeof(EXT_CAP_INFO_ELEMENT));
			hex_dump("New ExtCapInfo", (UCHAR *)&ie_list->ExtCapInfo, sizeof(EXT_CAP_INFO_ELEMENT));
		}

		if (AddHtInfoLen != ie_list->AddHtInfoLen)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("AddHtInfoLen mismatch!Old=%d, New=%d\n", AddHtInfoLen,
					 ie_list->AddHtInfoLen));

		if (NdisCmpMemory(&ie_list->AddHtInfo, pAddHtInfo, sizeof(ADD_HT_INFO_IE)) != 0) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("AddHtInfo mismatch!\n"));
			hex_dump("Old AddHtInfo", (UCHAR *)pAddHtInfo, sizeof(ADD_HT_INFO_IE));
			hex_dump("New AddHtInfo", (UCHAR *)&ie_list->AddHtInfo, sizeof(ADD_HT_INFO_IE));
		}

		if (NewExtChannelOffset != ie_list->NewExtChannelOffset)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("AddHtInfoLen mismatch!Old=%d, New=%d\n", NewExtChannelOffset,
					 ie_list->NewExtChannelOffset));
	}

	goto LabelOK;
LabelErr:
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: Allocate memory fail!!!\n", __func__));
LabelOK:

	if (Ssid != NULL)
		os_free_mem(Ssid);

	if (VarIE != NULL)
		os_free_mem(VarIE);

	if (pHtCapability != NULL)
		os_free_mem(pHtCapability);

	if (pAddHtInfo != NULL)
		os_free_mem(pAddHtInfo);

	if (ie_list != NULL)
		os_free_mem(ie_list);
}
/* ---Add by shiang to check correctness of new sanity function */
#endif

/*
 *	==========================================================================
 *	Description:
 *		peer sends beacon back when scanning
 *	==========================================================================
 */
VOID PeerBeaconAtScanAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	PFRAME_802_11 pFrame;
	USHORT LenVIE;
	UCHAR *VarIE = NULL;
	NDIS_802_11_VARIABLE_IEs *pVIE = NULL;
	BCN_IE_LIST *ie_list = NULL;
#ifdef MESH_SUPPORT
	UCHAR HostName[MAX_HOST_NAME_LEN] = {0};
	UCHAR HostNameLen = 0;
	UCHAR MeshId[MAX_MESH_ID_LEN] = {0};
	UCHAR MeshIdLen = 0;
	MESH_CONFIGURAION_IE MeshConfig = {0};
#endif /* MESH_SUPPORT */
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	os_alloc_mem(NULL, (UCHAR **)&ie_list, sizeof(BCN_IE_LIST));

	if (!ie_list) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s():Alloc ie_list failed!\n", __func__));
		return;
	}

	NdisZeroMemory((UCHAR *)ie_list, sizeof(BCN_IE_LIST));
	/* Init Variable IE structure */
	os_alloc_mem(NULL, (UCHAR **)&VarIE, MAX_VIE_LEN);

	if (VarIE == NULL)
		goto LabelErr;

	pVIE = (PNDIS_802_11_VARIABLE_IEs) VarIE;
	pVIE->Length = 0;
	pFrame = (PFRAME_802_11) Elem->Msg;

	if (PeerBeaconAndProbeRspSanity(pAd,
									Elem->wdev,
									&Elem->Msg[0], Elem->MsgLen,
									Elem->Channel,
									ie_list, &LenVIE, pVIE, FALSE, FALSE) == TRUE) {
		ULONG Idx = 0;
		CHAR Rssi = 0;
#ifdef WIFI_REGION32_HIDDEN_SSID_SUPPORT
		CHAR SsidAllZero = 0;
		CHAR k = 0;

		/* check ssid values, assume it's all zero first */
		if (ie_list->SsidLen != 0)
			SsidAllZero = 1;

		for (k = 0 ; k < ie_list->SsidLen ; k++) {
			if (ie_list->Ssid[k] != 0) {
				SsidAllZero = 0;
				break;
			}
		}

#endif /* WIFI_REGION32_HIDDEN_SSID_SUPPORT */
		Idx = BssTableSearch(&pAd->ScanTab, &ie_list->Bssid[0], ie_list->Channel);
#ifdef WIFI_REGION32_HIDDEN_SSID_SUPPORT

		if (Idx != BSS_NOT_FOUND && ie_list->SsidLen != 0 && SsidAllZero == 0)
#else
		if (Idx != BSS_NOT_FOUND)
#endif /* WIFI_REGION32_HIDDEN_SSID_SUPPORT */
			Rssi = pAd->ScanTab.BssEntry[Idx].Rssi;

#ifdef WIFI_REGION32_HIDDEN_SSID_SUPPORT
		else
			do {
				UCHAR SsidLen = 0;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s::CountryRegion %d\n", __func__,
						 pAd->CommonCfg.CountryRegion));
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s::Channel %d\n", __func__, ie_list->Channel));
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s::ssid length %d\n", __func__, ie_list->SsidLen));

				if (((pAd->CommonCfg.CountryRegion & 0x7f) == REGION_32_BG_BAND)
					&& ((ie_list->Channel == 12) || (ie_list->Channel == 13))
					&& ((ie_list->SsidLen == 0) || (SsidAllZero == 1))) {
					HEADER_802_11   Hdr80211;
					PUCHAR          pOutBuffer = NULL;
					NDIS_STATUS     NStatus;
					ULONG           FrameLen = 0;
					NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);  /* Get an unused nonpaged memory */

					if (NStatus != NDIS_STATUS_SUCCESS) {
						MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("PeerBeaconAtScanAction() allocate memory fail\n"));
						break;
					}

					SsidLen = pStaCfg->MlmeAux.SsidLen;
#ifdef CONFIG_STA_SUPPORT
					IF_DEV_CONFIG_OPMODE_ON_STA(pAd)
					MgtMacHeaderInit(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, &ie_list->Bssid[0],
									 pStaCfg->wdev.if_addr,
									 &ie_list->Bssid[0]);
#endif /* CONFIG_STA_SUPPORT // */
					MakeOutgoingFrame(pOutBuffer,               &FrameLen,
									  sizeof(HEADER_802_11),    &Hdr80211,
									  1,                        &SsidIe,
									  1,                        &SsidLen,
									  SsidLen,			        pStaCfg->MlmeAux.Ssid,
									  1,                        &SupRateIe,
									  1,                        &pStaCfg->wdev.rate.SupRateLen,
									  pStaCfg->wdev.rate.SupRateLen,  pStaCfg->wdev.rate.SupRate,
									  END_OF_ARGS);

					if (pStaCfg->wdev.rate.ExtRateLen) {
						ULONG Tmp;
						MakeOutgoingFrame(pOutBuffer + FrameLen,            &Tmp,
										  1,                                &ExtRateIe,
										  1,                                &pStaCfg->wdev.rate.ExtRateLen,
										  pStaCfg->wdev.rate.ExtRateLen,          pStaCfg->wdev.rate.ExtRate,
										  END_OF_ARGS);
						FrameLen += Tmp;
					}

					MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
					MlmeFreeMemory(pOutBuffer);
				}
			} while (0);

#endif  /* WIFI_REGION32_HIDDEN_SSID_SUPPORT */
		Rssi = RTMPMaxRssi(pAd, ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_0),
						   ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_1),
						   ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_2));
#ifdef MESH_SUPPORT
		MeshPeerBeaconAndProbeSanity(pAd, Elem->Msg, Elem->MsgLen,
									 HostName, &HostNameLen, MeshId,
									 &MeshIdLen, &MeshConfig);

		if (MESH_ON(pAd) && (MeshIdLen != 0)) {
			ULONG LinkIdx;
			InsertNeighborMP(pAd, Rssi, &ie_list->Bssid[0], ie_list->Channel,
							 (UINT8)ie_list->AddHtInfo.AddHtInfo.RecomWidth,
							 (UINT8)ie_list->AddHtInfo.AddHtInfo.ExtChanOffset,
							 HostName, MeshId, MeshIdLen, ie_list->CapabilityInfo,
							 (PUCHAR)pVIE, LenVIE, &MeshConfig);
			LinkIdx = GetMeshLinkId(pAd, (CHAR *)&ie_list->Addr2[0]);

			if (VALID_MESH_LINK_ID(LinkIdx)) {
				ULONG Now;
				NdisGetSystemUpTime(&Now);
				pAd->MeshTab.MeshLink[LinkIdx].Entry.LastBeaconTime = Now;
			}
		}

#endif /* MESH_SUPPORT */
#ifdef P2P_SUPPORT
		MlmeEnqueueWithWdev(pAd, P2P_DISC_STATE_MACHINE, P2P_DISC_PEER_PROB_RSP, Elem->MsgLen, Elem->Msg, ie_list->Channel,
							Elem->wdev);
#endif /* P2P_SUPPORT */
#ifdef DOT11_N_SUPPORT

		if ((ie_list->HtCapabilityLen > 0) || (ie_list->PreNHtCapabilityLen > 0))
			ie_list->HtCapabilityLen = SIZE_HT_CAP_IE;

#endif /* DOT11_N_SUPPORT */
		Idx = BssTableSetEntry(pAd, pStaCfg, &pAd->ScanTab, ie_list, Rssi, LenVIE, pVIE);
#ifdef DOT11_N_SUPPORT
		/* TODO: Check for things need to do when enable "DOT11V_WNM_SUPPORT" */
#ifdef DOT11N_DRAFT3

		/* Check if this scan channel is the effeced channel */
		if (INFRA_ON(pStaCfg)
			&& (pAd->CommonCfg.bBssCoexEnable == TRUE)
			&& ((ie_list->Channel > 0) && (ie_list->Channel <= 14))) {
			int chListIdx;

			/* find the channel list idx by the channel number */
			for (chListIdx = 0; chListIdx < pAd->ChannelListNum; chListIdx++) {
				if (ie_list->Channel == pAd->ChannelList[chListIdx].Channel)
					break;
			}

			if (chListIdx < pAd->ChannelListNum) {
#ifdef RELEASE_EXCLUDE
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO,
						 ("%s():Check Channel(%d) with ChList[Idx=%d, Ch=%d, bEffected=%d]",
						  __func__, ie_list->Channel, chListIdx, pAd->ChannelList[chListIdx].Channel,
						  pAd->ChannelList[chListIdx].bEffectedChannel));
#endif /* RELEASE_EXCLUDE */

				/*
				 *	If this channel is effected channel for the 20/40 coex operation. Check the related IEs.
				 */
				if (pAd->ChannelList[chListIdx].bEffectedChannel == TRUE) {
					UCHAR RegClass;
					OVERLAP_BSS_SCAN_IE	BssScan;
					/* Read Beacon's Reg Class IE if any. */
					PeerBeaconAndProbeRspSanity2(pAd, Elem->Msg, Elem->MsgLen, &BssScan, &RegClass);
					TriEventTableSetEntry(pAd, &pAd->CommonCfg.TriggerEventTab, &ie_list->Bssid[0],
										  &ie_list->HtCapability, ie_list->HtCapabilityLen,
										  RegClass, ie_list->Channel);
				}
			}
		}

#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */

		if (Idx != BSS_NOT_FOUND) {
			BSS_ENTRY *pBssEntry = &pAd->ScanTab.BssEntry[Idx];
			NdisMoveMemory(pBssEntry->PTSF, &Elem->Msg[24], 4);
			NdisMoveMemory(&pBssEntry->TTSF[0], &Elem->TimeStamp.u.LowPart, 4);
			NdisMoveMemory(&pBssEntry->TTSF[4], &Elem->TimeStamp.u.LowPart, 4);
			pBssEntry->MinSNR = Elem->Signal % 10;

			if (pBssEntry->MinSNR == 0)
				pBssEntry->MinSNR = -5;

			NdisMoveMemory(pBssEntry->MacAddr, &ie_list->Addr2[0], MAC_ADDR_LEN);

			if ((pFrame->Hdr.FC.SubType == SUBTYPE_PROBE_RSP) && (LenVIE != 0)) {
				pBssEntry->VarIeFromProbeRspLen = 0;

				if (pBssEntry->pVarIeFromProbRsp) {
					pBssEntry->VarIeFromProbeRspLen = LenVIE;
					RTMPZeroMemory(pBssEntry->pVarIeFromProbRsp, MAX_VIE_LEN);
					RTMPMoveMemory(pBssEntry->pVarIeFromProbRsp, pVIE, LenVIE);
				}
			}
		}

#ifdef LINUX
#ifdef RT_CFG80211_SUPPORT

		/* Determine primary channel by IE's DSPS rather than channel of received frame */
		if (ie_list->Channel != 0)
			Elem->Channel = ie_list->Channel;

		RT_CFG80211_SCANNING_INFORM(pAd, Idx, Elem->Channel, (UCHAR *)pFrame,
									Elem->MsgLen, Rssi);
#endif /* RT_CFG80211_SUPPORT */
#endif /* LINUX */
	}

	/* sanity check fail, ignored */
	goto LabelOK;
LabelErr:
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: Allocate memory fail!!!\n", __func__));
LabelOK:

	if (VarIE != NULL)
		os_free_mem(VarIE);

	if (ie_list != NULL)
		os_free_mem(ie_list);
}


/*
 *	==========================================================================
 *	Description:
 *		When waiting joining the (I)BSS, beacon received from external
 *	==========================================================================
 */
VOID PeerBeaconAtJoinAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	BOOLEAN TimerCancelled;
	USHORT LenVIE;
	USHORT Status;
	UCHAR *VarIE = NULL;
	NDIS_802_11_VARIABLE_IEs *pVIE = NULL;
	ULONG Idx = 0;
	CHAR Rssi = 0;
#ifdef DOT11_N_SUPPORT
	UCHAR CentralChannel;
	BOOLEAN bAllowNrate = FALSE;
#endif /* DOT11_N_SUPPORT */
	BCN_IE_LIST *ie_list = NULL;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	MAC_TABLE_ENTRY *pEntry = NULL;
	struct wifi_dev *wdev = Elem->wdev;
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	pEntry = GetAssociatedAPByWdev(pAd, Elem->wdev);
	/* allocate memory */
	os_alloc_mem(NULL, (UCHAR **)&ie_list, sizeof(BCN_IE_LIST));

	if (ie_list == NULL)
		goto LabelErr;

	NdisZeroMemory(ie_list, sizeof(BCN_IE_LIST));
	os_alloc_mem(NULL, (UCHAR **)&VarIE, MAX_VIE_LEN);

	if (VarIE == NULL)
		goto LabelErr;

	/* Init Variable IE structure */
	pVIE = (PNDIS_802_11_VARIABLE_IEs) VarIE;
	pVIE->Length = 0;

	if (PeerBeaconAndProbeRspSanity(pAd,
									Elem->wdev,
									Elem->Msg,
									Elem->MsgLen,
									Elem->Channel,
									ie_list,
									&LenVIE,
									pVIE,
									TRUE,
									FALSE)) {
		/* Disqualify 11b only adhoc when we are in 11g only adhoc mode */
		if ((ie_list->BssType == BSS_ADHOC) &&
			WMODE_EQUAL(wdev->PhyMode, WMODE_G) &&
			((ie_list->SupRateLen + ie_list->ExtRateLen) < 12))
			goto LabelOK;

#ifdef P2P_SUPPORT

		if (P2P_INF_ON(pAd))
			P2pPeerBeaconAtJoinAction(pAd, Elem, &ie_list->Bssid[0]);

#endif /* P2P_SUPPORT */

		/*
		 *    BEACON from desired BSS/IBSS found. We should be able to decide most
		 *    BSS parameters here.
		 *    Q. But what happen if this JOIN doesn't conclude a successful ASSOCIATEION?
		 *	Do we need to receover back all parameters belonging to previous BSS?
		 *    A. Should be not. There's no back-door recover to previous AP. It still need
		 *	a new JOIN-AUTH-ASSOC sequence.
		 */
		if (MAC_ADDR_EQUAL(pStaCfg->MlmeAux.Bssid, &ie_list->Bssid[0])) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():receive desired BEACON,Channel=%d, (%d, %d)\n",
					 __func__, ie_list->Channel, ie_list->BeaconPeriod, ie_list->DtimPeriod));
			RTMPCancelTimer(&pStaCfg->MlmeAux.BeaconTimer, &TimerCancelled);
#ifdef P2P_SUPPORT

			if (IS_P2P_ENROLLEE(pAd)) {
				int p2pIdx;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Recv desired Beacon, update SSID[%d][%s]\n",
						 ie_list->SsidLen, &ie_list->Ssid[0]));
				pStaCfg->MlmeAux.SsidLen = ie_list->SsidLen;
				NdisMoveMemory(pStaCfg->MlmeAux.Ssid, ie_list->Ssid, pStaCfg->MlmeAux.SsidLen);
				p2pIdx = P2pGroupTabSearch(pAd, ie_list->Addr2);

				if (p2pIdx < MAX_P2P_GROUP_SIZE) {
					pAd->P2pTable.Client[p2pIdx].SsidLen = ie_list->SsidLen;
					NdisMoveMemory(pAd->P2pTable.Client[p2pIdx].Ssid, ie_list->Ssid, pAd->P2pTable.Client[p2pIdx].SsidLen);
				}
			}

#endif /* P2P_SUPPORT */
			/* Update RSSI to prevent No signal display when cards first initialized */
			pStaCfg->RssiSample.LastRssi[0] = ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_0);
			pStaCfg->RssiSample.LastRssi[1] = ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_1);
			pStaCfg->RssiSample.LastRssi[2] = ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_2);
			pStaCfg->RssiSample.AvgRssi[0] = pStaCfg->RssiSample.LastRssi[0];
			pStaCfg->RssiSample.AvgRssiX8[0] = pStaCfg->RssiSample.AvgRssi[0] << 3;
			pStaCfg->RssiSample.AvgRssi[1] = pStaCfg->RssiSample.LastRssi[1];
			pStaCfg->RssiSample.AvgRssiX8[1] = pStaCfg->RssiSample.AvgRssi[1] << 3;
			pStaCfg->RssiSample.AvgRssi[2] = pStaCfg->RssiSample.LastRssi[2];
			pStaCfg->RssiSample.AvgRssiX8[2] = pStaCfg->RssiSample.AvgRssi[2] << 3;

			/*
			 *  We need to check if SSID only set to any, then we can record the current SSID.
			 *  Otherwise will cause hidden SSID association failed.
			 */
			if (pStaCfg->MlmeAux.SsidLen == 0) {
				NdisMoveMemory(pStaCfg->MlmeAux.Ssid, ie_list->Ssid, ie_list->SsidLen);
				pStaCfg->MlmeAux.SsidLen = ie_list->SsidLen;
			} else {
				Idx = BssSsidTableSearch(&pAd->ScanTab, ie_list->Bssid,
										 pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen,
										 ie_list->Channel);

				if (Idx == BSS_NOT_FOUND) {
					Rssi = RTMPMaxRssi(pAd, ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_0),
									   ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_1),
									   ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_2));
					Idx = BssTableSetEntry(pAd, pStaCfg, &pAd->ScanTab, ie_list, Rssi, LenVIE, pVIE);

					if (Idx != BSS_NOT_FOUND) {
						NdisMoveMemory(pAd->ScanTab.BssEntry[Idx].PTSF, &Elem->Msg[24], 4);
						NdisMoveMemory(&pAd->ScanTab.BssEntry[Idx].TTSF[0], &Elem->TimeStamp.u.LowPart, 4);
						NdisMoveMemory(&pAd->ScanTab.BssEntry[Idx].TTSF[4], &Elem->TimeStamp.u.LowPart, 4);
						ie_list->CapabilityInfo = pAd->ScanTab.BssEntry[Idx].CapabilityInfo;
						pAd->ScanTab.BssEntry[Idx].MinSNR = Elem->Signal % 10;

						if (pAd->ScanTab.BssEntry[Idx].MinSNR == 0)
							pAd->ScanTab.BssEntry[Idx].MinSNR = -5;

						NdisMoveMemory(pAd->ScanTab.BssEntry[Idx].MacAddr, ie_list->Addr2, MAC_ADDR_LEN);
					}
				} else {
#ifdef WPA_SUPPLICANT_SUPPORT

					if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP & WPA_SUPPLICANT_ENABLE_WPS)
						;
					else
#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef WSC_STA_SUPPORT
						if (wdev->WscControl.WscState != WSC_STATE_OFF)
							;
						else
#endif /* WSC_STA_SUPPORT */
						{
							/*
							 *    Check if AP privacy is different Staion, if yes,
							 *    start a new scan and ignore the frame
							 *    (often happen during AP change privacy at short time)
							 */
							if ((((IS_SECURITY_Entry(wdev)) << 4) ^ ie_list->CapabilityInfo) & 0x0010) {
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT

								/* When using -Dwext and trigger WPS, do not check security. */
								if (ie_list->selReg == 0)
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
								{
									MLME_SCAN_REQ_STRUCT ScanReq;
									MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:AP privacy %d is differenct from STA privacy%d\n",
											 __func__, (ie_list->CapabilityInfo & 0x0010) >> 4,
											 IS_SECURITY_Entry(wdev)));
									ScanParmFill(pAd, &ScanReq, (RTMP_STRING *) pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen, BSS_ANY, SCAN_ACTIVE);
									MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_SCAN_REQ, sizeof(MLME_SCAN_REQ_STRUCT), &ScanReq, 0, wdev);
									pStaCfg->CntlMachine.CurrState = CNTL_WAIT_OID_LIST_SCAN;
									NdisGetSystemUpTime(&pStaCfg->LastScanTime);
									pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
									RTMP_MLME_HANDLER(pAd);
									goto LabelOK;
								}
							}
						}

					/* Multiple SSID case, used correct CapabilityInfo */
					ie_list->CapabilityInfo = pAd->ScanTab.BssEntry[Idx].CapabilityInfo;
				}
			}

			pStaCfg->MlmeAux.CapabilityInfo = ie_list->CapabilityInfo & SUPPORTED_CAPABILITY_INFO;
			pStaCfg->MlmeAux.BssType = ie_list->BssType;
			pStaCfg->MlmeAux.BeaconPeriod = ie_list->BeaconPeriod;
			pStaCfg->MlmeAux.DtimPeriod = ie_list->DtimPeriod;

			/*
			 *	Some AP may carrys wrong beacon interval (ex. 0) in Beacon IE.
			 *	We need to check here for preventing divided by 0 error.
			 */
			if (pStaCfg->MlmeAux.BeaconPeriod == 0)
				pStaCfg->MlmeAux.BeaconPeriod = 100;

			pStaCfg->MlmeAux.Channel = ie_list->Channel;
			pStaCfg->MlmeAux.AtimWin = ie_list->AtimWin;
			pStaCfg->MlmeAux.CfpPeriod = ie_list->CfParm.CfpPeriod;
			pStaCfg->MlmeAux.CfpMaxDuration = ie_list->CfParm.CfpMaxDuration;
			NdisMoveMemory(&pStaCfg->MlmeAux.vendor_ie,
						   &ie_list->vendor_ie, sizeof(struct _vendor_ie_cap));
			/*
			 *    Copy AP's supported rate to MlmeAux for creating assoication request
			 *    Also filter out not supported rate
			 */
			pStaCfg->MlmeAux.SupRateLen = ie_list->SupRateLen;
			NdisMoveMemory(pStaCfg->MlmeAux.SupRate, ie_list->SupRate, ie_list->SupRateLen);
			RTMPCheckRates(pAd, pStaCfg->MlmeAux.SupRate, &pStaCfg->MlmeAux.SupRateLen, wdev->PhyMode);
			pStaCfg->MlmeAux.ExtRateLen = ie_list->ExtRateLen;
			NdisMoveMemory(pStaCfg->MlmeAux.ExtRate, ie_list->ExtRate, ie_list->ExtRateLen);
			RTMPCheckRates(pAd, pStaCfg->MlmeAux.ExtRate, &pStaCfg->MlmeAux.ExtRateLen, wdev->PhyMode);
			NdisZeroMemory(pStaCfg->StaActive.SupportedPhyInfo.MCSSet, 16);
#ifdef DOT11R_FT_SUPPORT

			if (pStaCfg->Dot11RCommInfo.bFtSupport &&
				FT_GetMDIE(pVIE, LenVIE, &pStaCfg->MlmeAux.MdIeInfo)) {
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("PeerBeaconAtJoinAction! (MdId=%x%x, FtOverDs=%d, RsrReqCap=%d)\n",
						  pStaCfg->MlmeAux.MdIeInfo.MdId[0],
						  pStaCfg->MlmeAux.MdIeInfo.MdId[1],
						  pStaCfg->MlmeAux.MdIeInfo.FtCapPlc.field.FtOverDs,
						  pStaCfg->MlmeAux.MdIeInfo.FtCapPlc.field.RsrReqCap));
			}

#endif /* DOT11R_FT_SUPPORT */
			/*  Get the ext capability info element */
			NdisMoveMemory(&pStaCfg->MlmeAux.ExtCapInfo, &ie_list->ExtCapInfo, sizeof(ie_list->ExtCapInfo));
#ifdef DOT11_VHT_AC
			pStaCfg->StaActive.SupportedPhyInfo.bVhtEnable = FALSE;
			pStaCfg->StaActive.SupportedPhyInfo.vht_bw = VHT_BW_2040;
#endif /* DOT11_VHT_AC */
#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("MlmeAux.ExtCapInfo=%d\n",
					 pStaCfg->MlmeAux.ExtCapInfo.BssCoexistMgmtSupport));

			if (pAd->CommonCfg.bBssCoexEnable == TRUE)
				pAd->CommonCfg.ExtCapIE.BssCoexistMgmtSupport = 1;

#endif /* DOT11N_DRAFT3 */
			pStaCfg->MlmeAux.NewExtChannelOffset = ie_list->NewExtChannelOffset;
			pStaCfg->MlmeAux.HtCapabilityLen = ie_list->HtCapabilityLen;
			CentralChannel = ie_list->Channel;
			RTMPZeroMemory(&pStaCfg->MlmeAux.HtCapability, SIZE_HT_CAP_IE);

			if (!pEntry) {
				/* The first time MacEntry is go to be used. We have to create the MacEntry. */
				pEntry = MacTableInsertEntry(pAd, ie_list->Bssid, &pStaCfg->wdev, ENTRY_INFRA, OPMODE_STA, TRUE);
				ASSERT(pEntry);
			}

			/* Decide Pairwise and group cipher with AP */
			if (pEntry) {
				struct _SECURITY_CONFIG *pProfile_SecConfig = &wdev->SecConfig;
				struct _SECURITY_CONFIG *pEntry_SecConfig = &pEntry->SecConfig;
				USHORT RsnCapability = 0;
				USHORT IsSHA256 = FALSE;
				PaserSecurityIE(ie_list,
								&LenVIE,
								(PNDIS_802_11_VARIABLE_IEs) VarIE,
								&pEntry_SecConfig->AKMMap,
								&pEntry_SecConfig->PairwiseCipher,
								&pEntry_SecConfig->GroupCipher,
								&RsnCapability,
								&IsSHA256);
				/* Check the Authmode first*/
				pEntry_SecConfig->Handshake.WpaState = SS_NOTUSE;
				pEntry_SecConfig->Handshake.GTKState = REKEY_NEGOTIATING;
				os_zero_mem(pEntry_SecConfig->Handshake.ReplayCounter, LEN_KEY_DESC_REPLAY);
				pEntry_SecConfig->AKMMap &=  pProfile_SecConfig->AKMMap;
				pEntry_SecConfig->PairwiseCipher &=  pProfile_SecConfig->PairwiseCipher;

				if (IS_AKM_WPA1(pEntry_SecConfig->AKMMap) && IS_AKM_WPA2(pEntry_SecConfig->AKMMap)) {
					CLEAR_SEC_AKM(pEntry_SecConfig->AKMMap);
					SET_AKM_WPA2(pEntry_SecConfig->AKMMap);
				} else if (IS_AKM_WPA1PSK(pEntry_SecConfig->AKMMap) && IS_AKM_WPA2PSK(pEntry_SecConfig->AKMMap)) {
					CLEAR_SEC_AKM(pEntry_SecConfig->AKMMap);
					SET_AKM_WPA2PSK(pEntry_SecConfig->AKMMap);
				}

				if ((IS_CIPHER_TKIP(pEntry_SecConfig->PairwiseCipher)) && (IS_CIPHER_CCMP128(pEntry_SecConfig->PairwiseCipher))) {
					CLEAR_CIPHER(pEntry_SecConfig->PairwiseCipher);
					SET_CIPHER_CCMP128(pEntry_SecConfig->PairwiseCipher);
				}

				/*WPS: WPS Connection need to set HT Capablities and channel, so dont skip, if WPS is triggered*/
				if (
					((pEntry_SecConfig->AKMMap == 0) || (pEntry_SecConfig->PairwiseCipher == 0))
#ifdef WSC_STA_SUPPORT
					&& (wdev->WscControl.bWscTrigger == FALSE)
#endif
#ifdef WPA_SUPPLICANT_SUPPORT
					&& (!(pStaCfg->wpa_supplicant_info.WpaSupplicantUP & WPA_SUPPLICANT_ENABLE_WPS))
#endif
				) {
					goto LabelOK; /* None matched*/
				}

#ifdef DOT11W_PMF_SUPPORT
				{
					RSN_CAPABILITIES RsnCap;
					NdisMoveMemory(&RsnCap, &RsnCapability, sizeof(RSN_CAPABILITIES));
					RsnCap.word = cpu2le16(RsnCap.word);

					if (((pProfile_SecConfig->PmfCfg.MFPR) && (RsnCap.field.MFPC == FALSE))
						|| ((pProfile_SecConfig->PmfCfg.MFPC == FALSE) && (RsnCap.field.MFPR)))
						goto LabelOK; /* None matched*/

					if ((pProfile_SecConfig->PmfCfg.MFPC) && (RsnCap.field.MFPC)) {
						pEntry_SecConfig->PmfCfg.UsePMFConnect = TRUE;

						if ((IsSHA256) || (RsnCap.field.MFPR))
							pEntry_SecConfig->PmfCfg.UseSHA256Connect = TRUE;

						pEntry_SecConfig->PmfCfg.MFPC = RsnCap.field.MFPC;
						pEntry_SecConfig->PmfCfg.MFPR = 0;
					}

					if ((pProfile_SecConfig->PmfCfg.MFPR) && (RsnCap.field.MFPR))
						pEntry_SecConfig->PmfCfg.MFPR = RsnCap.field.MFPR;
				}
#endif /* DOT11W_PMF_SUPPORT */

				if ((IS_NO_SECURITY(pEntry_SecConfig)
					 || ((!IS_CIPHER_WEP(pEntry_SecConfig->PairwiseCipher)) && (!IS_CIPHER_TKIP(pEntry_SecConfig->PairwiseCipher))))
					|| (pAd->CommonCfg.HT_DisallowTKIP == FALSE)) {
					if ((pStaCfg->BssType == BSS_INFRA) ||
						((pStaCfg->BssType == BSS_ADHOC) && (pStaCfg->bAdhocN == TRUE)))
						bAllowNrate = TRUE;
				}

				if (IS_CIPHER_WEP(pEntry_SecConfig->PairwiseCipher)) {
					os_move_mem(pEntry_SecConfig->WepKey, pProfile_SecConfig->WepKey,  sizeof(SEC_KEY_INFO)*SEC_KEY_NUM);
					pProfile_SecConfig->GroupKeyId = pProfile_SecConfig->PairwiseKeyId;
					pEntry_SecConfig->PairwiseKeyId = pProfile_SecConfig->PairwiseKeyId;
				} else {
					/* Calculate PMK */
					SetWPAPSKKey(pAd, pProfile_SecConfig->PSK, strlen(pProfile_SecConfig->PSK), pStaCfg->MlmeAux.Ssid,
								 pStaCfg->MlmeAux.SsidLen, pEntry_SecConfig->PMK);
					os_move_mem(pEntry_SecConfig->Handshake.AAddr, pEntry->Addr, MAC_ADDR_LEN);
					os_move_mem(pEntry_SecConfig->Handshake.SAddr, wdev->if_addr, MAC_ADDR_LEN);
				}

				pEntry_SecConfig->GroupKeyId = pProfile_SecConfig->GroupKeyId;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("%s(): Final Security AKM = 0x%x, PairwiseCipher = 0x%x, GroupCipher = 0x%x, bAllowNrate=%d\n",
						  __func__, pEntry_SecConfig->AKMMap, pEntry_SecConfig->PairwiseCipher, pEntry_SecConfig->GroupCipher, bAllowNrate));
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("%s(): pEntry_SecConfig->PairwiseKeyId=%d, pEntry_SecConfig->GroupKeyId=%d\n",
						  __func__, pEntry_SecConfig->PairwiseKeyId, pEntry_SecConfig->GroupKeyId));
#ifdef DOT11W_PMF_SUPPORT

				if (pEntry_SecConfig->PmfCfg.UsePMFConnect)
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("[PMF] Use PMF Connect\n"));

				if (pEntry_SecConfig->PmfCfg.UseSHA256Connect)
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("[PMF] Use SHA256\n"));

#endif /* DOT11W_PMF_SUPPORT */
			}

			/* filter out un-supported ht rates */
			if (((ie_list->HtCapabilityLen > 0) || (ie_list->PreNHtCapabilityLen > 0)) &&
				(wdev->DesiredHtPhyInfo.bHtEnable) &&
				(WMODE_CAP_N(wdev->PhyMode) && bAllowNrate)) {
				RTMPMoveMemory(&pStaCfg->MlmeAux.AddHtInfo, &ie_list->AddHtInfo, SIZE_ADD_HT_INFO_IE);
				/* StaActive.SupportedHtPhy.MCSSet stores Peer AP's 11n Rx capability */
				NdisMoveMemory(pStaCfg->StaActive.SupportedPhyInfo.MCSSet, ie_list->HtCapability.MCSSet, 16);
				pStaCfg->MlmeAux.NewExtChannelOffset = ie_list->NewExtChannelOffset;
				pStaCfg->MlmeAux.HtCapabilityLen = SIZE_HT_CAP_IE;
				pStaCfg->StaActive.SupportedPhyInfo.bHtEnable = TRUE;

				if (ie_list->PreNHtCapabilityLen > 0)
					pStaCfg->StaActive.SupportedPhyInfo.bPreNHt = TRUE;

				if (pEntry)
					RTMPCheckHt(pAd, pEntry->wcid, &ie_list->HtCapability, &ie_list->AddHtInfo);

				/* Copy AP Parameter to StaActive.  This is also in LinkUp. */
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():(MpduDensity=%d, MaxRAmpduFactor=%d, BW=%d)\n",
						 __func__, pStaCfg->StaActive.SupportedHtPhy.MpduDensity,
						 pStaCfg->StaActive.SupportedHtPhy.MaxRAmpduFactor,
						 ie_list->HtCapability.HtCapInfo.ChannelWidth));

				if (ie_list->AddHtInfoLen > 0) {
					/* Check again the Bandwidth capability of this AP. */
					CentralChannel = get_cent_ch_by_htinfo(pAd,
														   &ie_list->AddHtInfo,
														   &ie_list->HtCapability);
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): HT-CtrlChannel=%d, CentralChannel=>%d\n",
							 __func__, ie_list->AddHtInfo.ControlChan, CentralChannel));
				}

#ifdef DOT11_VHT_AC

				if (WMODE_CAP_AC(wdev->PhyMode) &&
					(pStaCfg->MlmeAux.Channel > 14) &&
					(ie_list->vht_cap_len)) {
					VHT_OP_INFO *vht_op = &ie_list->vht_op_ie.vht_op_info;
					UCHAR cap_vht_bw = wlan_operate_get_vht_bw(wdev);
					struct _op_info op_info = {0};
					NdisMoveMemory(&pStaCfg->MlmeAux.vht_cap, &ie_list->vht_cap_ie, ie_list->vht_cap_len);
					pStaCfg->MlmeAux.vht_cap_len = ie_list->vht_cap_len;
					pStaCfg->StaActive.SupportedPhyInfo.bVhtEnable = TRUE;
#if 1
					update_vht_op_info(cap_vht_bw, vht_op, &op_info);

					if (op_info.bw != VHT_BW_2040)
						CentralChannel = op_info.cent_ch;

					pStaCfg->StaActive.SupportedPhyInfo.vht_bw = op_info.bw;
#else

					if (vht_op->ch_width == 0)
						pStaCfg->StaActive.SupportedPhyInfo.vht_bw = VHT_BW_2040;

					if ((vht_op->ch_width >= 1) && (cap_vht_bw >= VHT_BW_80)) {
						CentralChannel = vht_op->center_freq_1;
						pStaCfg->StaActive.SupportedPhyInfo.vht_bw = VHT_BW_80;
					}

					if (vht_op->ch_width == 2 && (cap_vht_bw == VHT_BW_160)) {
						CentralChannel = vht_op->center_freq_1;
						pStaCfg->StaActive.SupportedPhyInfo.vht_bw = VHT_BW_160;
					}

					if (vht_op->ch_width == 3 && (cap_vht_bw == VHT_BW_8080)) {
						CentralChannel = vht_op->center_freq_1;
						pStaCfg->StaActive.SupportedPhyInfo.vht_bw = VHT_BW_8080;
						wlan_operate_set_cen_ch_2(wdev, vht_op->center_freq_2);
					}

#endif
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): CentralChannel=>%d\n",
							 __func__, CentralChannel));
				}

#endif /* DOT11_VHT_AC */
			} else
#endif /* DOT11_N_SUPPORT */
			{
				/* To prevent error, let legacy AP must have same CentralChannel and Channel. */
				if ((ie_list->HtCapabilityLen == 0) && (ie_list->PreNHtCapabilityLen == 0))
					pStaCfg->MlmeAux.CentralChannel = pStaCfg->MlmeAux.Channel;

				pStaCfg->StaActive.SupportedPhyInfo.bHtEnable = FALSE;
#ifdef DOT11_VHT_AC
				pStaCfg->StaActive.SupportedPhyInfo.bVhtEnable = FALSE;
				pStaCfg->StaActive.SupportedPhyInfo.vht_bw = VHT_BW_2040;
#endif /* DOT11_VHT_AC */
				pStaCfg->MlmeAux.NewExtChannelOffset = 0xff;
				RTMPZeroMemory(&pStaCfg->MlmeAux.HtCapability, SIZE_HT_CAP_IE);
				pStaCfg->MlmeAux.HtCapabilityLen = 0;
				RTMPZeroMemory(&pStaCfg->MlmeAux.AddHtInfo, SIZE_ADD_HT_INFO_IE);
			}

			pStaCfg->MlmeAux.CentralChannel = CentralChannel;
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): Set CentralChannel=%d\n", __func__,
					 pStaCfg->MlmeAux.CentralChannel));
			RTMPUpdateMlmeRate(pAd);

			/* copy QOS related information */
			if ((wdev->bWmmCapable)
#ifdef DOT11_N_SUPPORT
				|| WMODE_CAP_N(wdev->PhyMode)
#endif /* DOT11_N_SUPPORT */
			   ) {
				NdisMoveMemory(&pStaCfg->MlmeAux.APEdcaParm, &ie_list->EdcaParm, sizeof(EDCA_PARM));
				NdisMoveMemory(&pStaCfg->MlmeAux.APQbssLoad, &ie_list->QbssLoad, sizeof(QBSS_LOAD_PARM));
				NdisMoveMemory(&pStaCfg->MlmeAux.APQosCapability, &ie_list->QosCapability, sizeof(QOS_CAPABILITY_PARM));
			} else {
				NdisZeroMemory(&pStaCfg->MlmeAux.APEdcaParm, sizeof(EDCA_PARM));
				NdisZeroMemory(&pStaCfg->MlmeAux.APQbssLoad, sizeof(QBSS_LOAD_PARM));
				NdisZeroMemory(&pStaCfg->MlmeAux.APQosCapability, sizeof(QOS_CAPABILITY_PARM));
			}

			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): - after JOIN, SupRateLen=%d, ExtRateLen=%d\n",
					 __func__, pStaCfg->MlmeAux.SupRateLen,
					 pStaCfg->MlmeAux.ExtRateLen));

			if (ie_list->AironetCellPowerLimit != 0xFF) {
				/* We need to change our TxPower for CCX 2.0 AP Control of Client Transmit Power */
				ChangeToCellPowerLimit(pAd, ie_list->AironetCellPowerLimit);
			} else {
				/* Used the default TX Power Percentage. */
				pAd->CommonCfg.ucTxPowerPercentage[BAND0] = pAd->CommonCfg.ucTxPowerDefault[BAND0];
#ifdef DBDC_MODE
				pAd->CommonCfg.ucTxPowerPercentage[BAND1] = pAd->CommonCfg.ucTxPowerDefault[BAND1];
#endif /* DBDC_MODE */
			}

			if (pStaCfg->BssType == BSS_INFRA) {
				BOOLEAN InfraAP_BW;
				UCHAR BwFallBack = 0;
#if 0
				InitChannelRelatedValue(pAd, wdev);
#endif

				if (pStaCfg->MlmeAux.HtCapability.HtCapInfo.ChannelWidth == BW_40)
					InfraAP_BW = TRUE;
				else
					InfraAP_BW = FALSE;

				AdjustChannelRelatedValue(pAd,
										  &BwFallBack,
										  BSS0,
										  InfraAP_BW,
										  pStaCfg->MlmeAux.Channel,
										  pStaCfg->MlmeAux.CentralChannel,
										  wdev);
#ifdef P2P_SUPPORT

				if (BwFallBack == 1) {
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("P2P STA connection to 40MHz GO, but Infra extra and P2P Group extra is different!!!\n"));
					pStaCfg->MlmeAux.HtCapability.HtCapInfo.ChannelWidth = BW_20;
					pStaCfg->MlmeAux.CentralChannel = pStaCfg->MlmeAux.Channel;
					pStaCfg->MlmeAux.bBwFallBack = TRUE;
				} else
					pStaCfg->MlmeAux.bBwFallBack = FALSE;

				pStaCfg->MlmeAux.ConCurrentCentralChannel = CentralChannel;
#endif /* P2P_SUPPORT */
			}

			pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
			Status = MLME_SUCCESS;
			MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_JOIN_CONF, 2, &Status, 0, wdev);
#ifdef LINUX
#ifdef RT_CFG80211_SUPPORT

			/* Determine primary channel by IE's DSPS rather than channel of received frame */
			if (ie_list->Channel != 0)
				Elem->Channel = ie_list->Channel;

			RT_CFG80211_SCANNING_INFORM(pAd, Idx, Elem->Channel, Elem->Msg,
										Elem->MsgLen, Rssi);
#endif /* RT_CFG80211_SUPPORT */
#endif /* LINUX */
		}

		/* not to me BEACON, ignored */
	}

	/* sanity check fail, ignore this frame */
	goto LabelOK;
LabelErr:
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: Allocate memory fail!!!\n", __func__));
LabelOK:

	if (ie_list != NULL)
		os_free_mem(ie_list);

	if (VarIE != NULL)
		os_free_mem(VarIE);
}

/*
 *	==========================================================================
 *	Description:
 *		receive BEACON from peer
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID PeerBeacon(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	UCHAR index = 0;
	USHORT TbttNumToNextWakeUp;
	USHORT LenVIE;
	UCHAR *VarIE = NULL;		/* Total VIE length = MAX_VIE_LEN - -5 */
	NDIS_802_11_VARIABLE_IEs *pVIE = NULL;
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	MAC_TABLE_ENTRY *pEntry = NULL;
#ifdef MESH_SUPPORT
	UCHAR HostName[MAX_HOST_NAME_LEN] = {0};
	UCHAR HostNameLen = 0;
	UCHAR MeshId[MAX_MESH_ID_LEN] = {0};
	UCHAR MeshIdLen = 0;
	MESH_CONFIGURAION_IE MeshConfig = {0};
#endif /* MESH_SUPPORT */
	BCN_IE_LIST *bcn_ie_list = NULL;
	/* Phase 1 STA LP: Beacon with my UC will be indicated to driver */
#ifdef STA_LP_PHASE_1_SUPPORT
	PFRAME_802_11 pFrame = NULL;
#endif /* STA_LP_PHASE_1_SUPPORT */
	pEntry = GetAssociatedAPByWdev(pAd, wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#if 0
	/* +++Add by shiang for debug */
	{
		ULONG now_time;
		NdisGetSystemUpTime(&now_time);
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("-->%s():INFRA_ON=%d, jiffies=0x%x, OS_HZ=%d\n", __func__,
				 INFRA_ON(pAd), now_time, OS_HZ));
	}
	/* ---Add by shiang for debug */
#endif
#ifdef CONFIG_ATE

	if (ATE_ON(pAd))
		return;

#endif /* CONFIG_ATE */

	if (!(INFRA_ON(pStaCfg) || ADHOC_ON(pAd)
#ifdef MESH_SUPPORT
		  || MESH_ON(pAd)
#endif /* MESH_SUPPORT */
#ifdef P2P_SUPPORT
		  || P2P_GO_ON(pAd) || P2P_CLI_ON(pAd)
#endif /* P2P_SUPPORT */
		 ))
		return;

	TbttNumToNextWakeUp = 0;
	/* allocate memory */
	os_alloc_mem(NULL, (UCHAR **)&bcn_ie_list, sizeof(BCN_IE_LIST));

	if (bcn_ie_list == NULL)
		goto LabelErr;

	NdisZeroMemory(bcn_ie_list, sizeof(BCN_IE_LIST));
	os_alloc_mem(NULL, (UCHAR **)&VarIE, MAX_VIE_LEN);

	if (VarIE == NULL)
		goto LabelErr;

	/* Init Variable IE structure */
	pVIE = (PNDIS_802_11_VARIABLE_IEs) VarIE;
	pVIE->Length = 0;
#ifdef STA_LP_PHASE_1_SUPPORT
	pFrame = (PFRAME_802_11)(Elem->Msg);
#endif /* STA_LP_PHASE_1_SUPPORT */

	if (PeerBeaconAndProbeRspSanity(pAd,
									Elem->wdev,
									Elem->Msg,
									Elem->MsgLen,
									Elem->Channel,
									bcn_ie_list,
									&LenVIE,
									pVIE,
									FALSE,
									FALSE)) {
		BOOLEAN is_my_bssid, is_my_ssid;
		ULONG Bssidx, Now;
		BSS_ENTRY *pBss;
		CHAR RealRssi = RTMPMaxRssi(pAd, ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_0),
									ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_1),
									ConvertToRssi(pAd, &Elem->rssi_info, RSSI_IDX_2));
		is_my_bssid = MAC_ADDR_EQUAL(bcn_ie_list->Bssid, pStaCfg->Bssid) ? TRUE : FALSE;
		is_my_ssid = SSID_EQUAL(bcn_ie_list->Ssid, bcn_ie_list->SsidLen, pStaCfg->Ssid, pStaCfg->SsidLen) ? TRUE : FALSE;
#ifdef P2P_SUPPORT

		if (bcn_ie_list->AddHtInfoLen != 0)
			bcn_ie_list->Channel = bcn_ie_list->AddHtInfo.ControlChan;

		if (bcn_ie_list->Channel == pAd->ApCfg.AutoChannel_Channel) {
			if (AutoChBssSearchWithSSID(pAd, bcn_ie_list->Bssid, (PUCHAR)bcn_ie_list->Ssid, bcn_ie_list->SsidLen,
										bcn_ie_list->Channel) == BSS_NOT_FOUND)
				pAd->pChannelInfo->ApCnt[pAd->ApCfg.current_channel_index]++;

			AutoChBssInsertEntry(pAd, bcn_ie_list->Bssid, bcn_ie_list->Ssid, bcn_ie_list->SsidLen, bcn_ie_list->Channel,
								 bcn_ie_list->NewExtChannelOffset, RealRssi);
		}

#endif /* P2P_SUPPORT */
#ifdef MESH_SUPPORT
		MeshPeerBeaconAndProbeSanity(pAd, Elem->Msg, Elem->MsgLen, HostName, &HostNameLen, MeshId, &MeshIdLen, &MeshConfig);

		if (MESH_ON(pAd) && (MeshIdLen != 0)) {
			ULONG LinkIdx;
			InsertNeighborMP(pAd, RealRssi, bcn_ie_list->Bssid, bcn_ie_list->Channel,
							 (UINT8)bcn_ie_list->AddHtInfo.AddHtInfo.RecomWidth,
							 (UINT8)bcn_ie_list->AddHtInfo.AddHtInfo.ExtChanOffset,
							 HostName, MeshId, MeshIdLen, bcn_ie_list->CapabilityInfo,
							 (PUCHAR)pVIE, LenVIE, &MeshConfig);
			LinkIdx = GetMeshLinkId(pAd, (PCHAR)bcn_ie_list->Addr2);

			if (VALID_MESH_LINK_ID(LinkIdx)) {
				ULONG Mesh_Now;
				NdisGetSystemUpTime(&Mesh_Now);
				pAd->MeshTab.MeshLink[LinkIdx].Entry.LastBeaconTime = Mesh_Now;
			}
		}

#endif /* MESH_SUPPORT */

		/* ignore BEACON not for my SSID */
		if ((!is_my_ssid) && (!is_my_bssid))
			goto LabelOK;

		/* It means STA waits disassoc completely from this AP, ignores this beacon. */
		if (pStaCfg->CntlMachine.CurrState == CNTL_WAIT_DISASSOC)
			goto LabelOK;

#ifdef DOT11_N_SUPPORT

		/* Copy Control channel for this BSSID. */
		if (bcn_ie_list->AddHtInfoLen != 0)
			bcn_ie_list->Channel = bcn_ie_list->AddHtInfo.ControlChan;

		if ((bcn_ie_list->HtCapabilityLen > 0) || (bcn_ie_list->PreNHtCapabilityLen > 0))
			bcn_ie_list->HtCapabilityLen = SIZE_HT_CAP_IE;

#endif /* DOT11_N_SUPPORT */
		/* Housekeeping "SsidBssTab" table for later-on ROAMing usage. */
		Bssidx = BssTableSearchWithSSID(&pStaCfg->MlmeAux.SsidBssTab, bcn_ie_list->Bssid, bcn_ie_list->Ssid,
										bcn_ie_list->SsidLen, bcn_ie_list->Channel);

		if (Bssidx == BSS_NOT_FOUND) {
			/* discover new AP of this network, create BSS entry */
			Bssidx = BssTableSetEntry(pAd, pStaCfg, &pStaCfg->MlmeAux.SsidBssTab, bcn_ie_list, RealRssi, LenVIE, pVIE);

			if (Bssidx == BSS_NOT_FOUND)
				;
			else {
				BSS_ENTRY *pBssEntry = &pStaCfg->MlmeAux.SsidBssTab.BssEntry[Bssidx];
				NdisMoveMemory(&pBssEntry->PTSF[0], &Elem->Msg[24], 4);
				NdisMoveMemory(&pBssEntry->TTSF[0], &Elem->TimeStamp.u.LowPart, 4);
				NdisMoveMemory(&pBssEntry->TTSF[4], &Elem->TimeStamp.u.LowPart, 4);
				pBssEntry->Rssi = RealRssi;
				NdisMoveMemory(pBssEntry->MacAddr, bcn_ie_list->Addr2, MAC_ADDR_LEN);
#ifdef RELEASE_EXCLUDE
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO,
						 ("SYNC - New AP added to SsidBssTab[%ld], RSSI=%d, MAC=%02x:%02x:%02x:%02x:%02x:%02x\n",
						  Bssidx, RealRssi, PRINT_MAC(bcn_ie_list->Bssid)));
#endif /* RELEASE_EXCLUDE */
#ifdef LINUX
#ifdef RT_CFG80211_SUPPORT
				/* if (RTMPEqualMemory(ie_list->Ssid, "DIRECT-", 7)) */
				/* MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s PASSIVE SCANNING: %s [%d]\n", __FUNCTION__, bcn_ie_list->Ssid, Bssidx)); */

				/* Determine primary channel by IE's DSPS rather than channel of received frame */
				if (bcn_ie_list->Channel != 0)
					Elem->Channel = bcn_ie_list->Channel;

				RT_CFG80211_SCANNING_INFORM(pAd, Bssidx, Elem->Channel, Elem->Msg,
											Elem->MsgLen, RealRssi);
#endif /* RT_CFG80211_SUPPORT */
#endif /* LINUX */
			}
		}

		/* Update ScanTab */
		Bssidx = BssTableSearch(&pAd->ScanTab, bcn_ie_list->Bssid, bcn_ie_list->Channel);

		if (Bssidx == BSS_NOT_FOUND) {
			/* discover new AP of this network, create BSS entry */
			Bssidx = BssTableSetEntry(pAd, pStaCfg, &pAd->ScanTab, bcn_ie_list, RealRssi, LenVIE, pVIE);

			if (Bssidx == BSS_NOT_FOUND) /* return if BSS table full */
				goto LabelOK;

			NdisMoveMemory(pAd->ScanTab.BssEntry[Bssidx].PTSF, &Elem->Msg[24], 4);
			NdisMoveMemory(&pAd->ScanTab.BssEntry[Bssidx].TTSF[0], &Elem->TimeStamp.u.LowPart, 4);
			NdisMoveMemory(&pAd->ScanTab.BssEntry[Bssidx].TTSF[4], &Elem->TimeStamp.u.LowPart, 4);
			pAd->ScanTab.BssEntry[Bssidx].MinSNR = Elem->Signal % 10;

			if (pAd->ScanTab.BssEntry[Bssidx].MinSNR == 0)
				pAd->ScanTab.BssEntry[Bssidx].MinSNR = -5;

			NdisMoveMemory(pAd->ScanTab.BssEntry[Bssidx].MacAddr, bcn_ie_list->Addr2, MAC_ADDR_LEN);
#ifdef RELEASE_EXCLUDE
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO,
					 ("SYNC - New AP added to SsidBssTab[%ld], RSSI=%d, MAC=%02x:%02x:%02x:%02x:%02x:%02x\n",
					  Bssidx, RealRssi, PRINT_MAC(bcn_ie_list->Bssid)));
#endif /* RELEASE_EXCLUDE */
		}

		/*
		 *    if the ssid matched & bssid unmatched, we should select the bssid with large value.
		 *    This might happened when two STA start at the same time
		 */
		if ((!is_my_bssid) && ADHOC_ON(pAd)) {
			INT	i;
#if 0
			BOOLEAN	bMerge = FALSE;
#endif
#ifdef IWSC_SUPPORT

			if ((pStaCfg->WscControl.WscConfMode != WSC_DISABLE) &&
				(pStaCfg->WscControl.bWscTrigger == TRUE))
				;
			else
#endif /* IWSC_SUPPORT */

				/* Add the safeguard against the mismatch of adhoc wep status */
				if ((wdev->SecConfig.PairwiseCipher != pAd->ScanTab.BssEntry[Bssidx].PairwiseCipher) ||
					(wdev->SecConfig.AKMMap != pAd->ScanTab.BssEntry[Bssidx].AKMMap)) {
#ifdef RELEASE_EXCLUDE
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO,
							 ("SYNC - Not matched wep status 0x%x 0x%x or auth mode 0x%x 0x%x\n",
							  wdev->SecConfig.PairwiseCipher, pAd->ScanTab.BssEntry[Bssidx].PairwiseCipher,
							  wdev->SecConfig.AKMMap, pAd->ScanTab.BssEntry[Bssidx].AKMMap));
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("bssid=%s\n", pAd->ScanTab.BssEntry[Bssidx].Bssid));
#endif /* RELEASE_EXCLUDE */
					goto LabelOK;
				}

			/* collapse into the ADHOC network which has bigger BSSID value. */
			for (i = 0; i < 6; i++) {
				if (bcn_ie_list->Bssid[i] > pStaCfg->Bssid[i]) {
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("SYNC - merge to the IBSS with bigger BSSID=%02x:%02x:%02x:%02x:%02x:%02x\n",
							  PRINT_MAC(bcn_ie_list->Bssid)));
					AsicDisableSync(pAd, HW_BSSID_0);
					COPY_MAC_ADDR(pStaCfg->Bssid, bcn_ie_list->Bssid);

					if (wdev_do_linkdown(wdev) != TRUE)
						MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): linkdown fail!!\n", __func__));

					if (wdev_do_linkup(wdev, pEntry) != TRUE)
						MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): linkup fail!!\n", __func__));

					if (wdev_do_conn_act(wdev, pEntry) != TRUE)
						MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): connect fail!!\n", __func__));

					is_my_bssid = TRUE;
					break;
				} else if (bcn_ie_list->Bssid[i] < pStaCfg->Bssid[i])
					break;
			}
		}

#ifdef RELEASE_EXCLUDE
#ifdef STA_LP_PHASE_1_SUPPORT
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO,
				 ("SYNC - PeerBeacon from %02x:%02x:%02x:%02x:%02x:%02x - Dtim=%d/%d, Rssi=%02x, SN(%d)\n",
				  PRINT_MAC(bcn_ie_list->Bssid), bcn_ie_list->DtimCount, bcn_ie_list->DtimPeriod, RealRssi, pFrame->Hdr.Sequence));
#endif /* STA_LP_PHASE_1_SUPPORT */
#endif /* RELEASE_EXCLUDE */
		NdisGetSystemUpTime(&Now);
		pBss = &pAd->ScanTab.BssEntry[Bssidx];
		pBss->Rssi = RealRssi;       /* lastest RSSI */
		pBss->LastBeaconRxTime = Now;   /* last RX timestamp */

		/*
		 *   BEACON from my BSSID - either IBSS or INFRA network
		 */
		if (is_my_bssid) {
			struct rx_signal_info signal;
#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
			OVERLAP_BSS_SCAN_IE	BssScan;
			UCHAR					RegClass;
			BOOLEAN					brc;
			/* Read Beacon's Reg Class IE if any. */
			brc = PeerBeaconAndProbeRspSanity2(pAd, Elem->Msg, Elem->MsgLen, &BssScan, &RegClass);

			if (brc == TRUE) {
				UpdateBssScanParm(pAd, BssScan);
				pStaCfg->RegClass = RegClass;
			}

#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
			pStaCfg->DtimCount = bcn_ie_list->DtimCount;
			pStaCfg->DtimPeriod = bcn_ie_list->DtimPeriod;
			pStaCfg->LastBeaconRxTime = Now;
			signal.raw_rssi[0] = Elem->rssi_info.raw_rssi[0];
			signal.raw_rssi[1] = Elem->rssi_info.raw_rssi[1];
			signal.raw_rssi[2] = Elem->rssi_info.raw_rssi[2];
			signal.raw_rssi[3] = Elem->rssi_info.raw_rssi[3];

			if (INFRA_ON(pStaCfg)) {
				MAC_TABLE_ENTRY *pEntry = GetAssociatedAPByWdev(pAd, wdev);

				if (pEntry) {
					Update_Rssi_Sample(pAd, &pEntry->RssiSample, &signal, 0 /* Prevent SNR calculate error. */, BW_20);
#ifdef RT_CFG80211_P2P_SINGLE_DEVICE

					if (CFG_P2PCLI_ON(pAd))
						CFG80211_PeerP2pBeacon(pAd, bcn_ie_list->Addr2, Elem, bcn_ie_list->TimeStamp);

#endif /* RT_CFG80211_P2P_SINGLE_DEVICE */
				}
			}

			Update_Rssi_Sample(pAd, &pStaCfg->RssiSample, &signal, 0, BW_20);

			if ((pAd->CommonCfg.bIEEE80211H == 1) &&
				(bcn_ie_list->NewChannel != 0) &&
				(bcn_ie_list->Channel != bcn_ie_list->NewChannel)) {
				/* Switching to channel 1 can prevent from rescanning the current channel immediately (by auto reconnection). */
				/* In addition, clear the MLME queue and the scan table to discard the RX packets and previous scanning results. */
				wdev->channel  = 1;
				wlan_operate_set_prim_ch(wdev, 1);
				LinkDown(pAd, FALSE, &pStaCfg->wdev);
				MlmeQueueInit(pAd, &pAd->Mlme.Queue);
				BssTableInit(&pAd->ScanTab);
				RtmpusecDelay(1000000);		/* use delay to prevent STA do reassoc */

				/* channel sanity check */
				for (index = 0 ; index < pAd->ChannelListNum; index++) {
					if (pAd->ChannelList[index].Channel == bcn_ie_list->NewChannel) {
						pAd->ScanTab.BssEntry[Bssidx].Channel = bcn_ie_list->NewChannel;
						wdev->channel = bcn_ie_list->NewChannel;
						wlan_operate_set_prim_ch(wdev, wdev->channel);
						MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
								 ("PeerBeacon - STA receive channel switch announcement IE (New Channel =%d)\n",
								  bcn_ie_list->NewChannel));
						break;
					}
				}

				if (index >= pAd->ChannelListNum)
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
							 ("PeerBeacon(can not find New Channel=%d in ChannelList[%d]\n",
							  pStaCfg->wdev.channel,
							  pAd->ChannelListNum));
			}

#ifdef WPA_SUPPLICANT_SUPPORT

			if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP & WPA_SUPPLICANT_ENABLE_WPS)
				;
			else
#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef WSC_STA_SUPPORT
				if (wdev->WscControl.WscState == WSC_STATE_OFF)
#endif /* WSC_STA_SUPPORT */
				{
					if ((((IS_SECURITY_Entry(wdev)) << 4) ^ bcn_ie_list->CapabilityInfo) & 0x0010) {
#ifdef RELEASE_EXCLUDE
						/* This issue was reported by Toshiba. */
#endif /* RELEASE_EXCLUDE */
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT

						/* When using -Dwext and trigger WPS, do not check security. */
						if (bcn_ie_list->selReg == 0)
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
						{
							/*
							 *	To prevent STA connect to OPEN/WEP AP when STA is OPEN/NONE or
							 *	STA connect to OPEN/NONE AP when STA is OPEN/WEP AP.
							 */
							MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:AP privacy:%x is differenct from STA privacy:%x\n",
									 __func__, (bcn_ie_list->CapabilityInfo & 0x0010) >> 4,
									 IS_SECURITY_Entry(wdev)));

							if (INFRA_ON(pStaCfg)) {
								LinkDown(pAd, FALSE, &pStaCfg->wdev);
								BssTableInit(&pAd->ScanTab);
							}

							goto LabelOK;
						}
					}
				}

#ifdef LINUX
#ifdef RT_CFG80211_SUPPORT
			/* CFG80211_BeaconCountryRegionParse(pAd, pVIE, LenVIE); */
#endif /* RT_CFG80211_SUPPORT */
#endif /* LINUX */
#ifdef RELEASE_EXCLUDE
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO,
					 ("SYNC - my beacon from %02x:%02x:%02x:%02x:%02x:%02x - Dtim=%d/%d, Rssi=%d, Rssi2=%d, Rssi3=%d\n",
					  PRINT_MAC(bcn_ie_list->Bssid), bcn_ie_list->DtimCount, bcn_ie_list->DtimPeriod,
					  pStaCfg->RssiSample.LastRssi[0], pStaCfg->RssiSample.LastRssi[1],
					  pStaCfg->RssiSample.LastRssi[2]));
#endif /* RELEASE_EXCLUDE */

			if (bcn_ie_list->AironetCellPowerLimit != 0xFF) {
				/*
				 *   We get the Cisco (ccx) "TxPower Limit" required
				 *   Changed to appropriate TxPower Limit for Ciso Compatible Extensions
				 */
				ChangeToCellPowerLimit(pAd, bcn_ie_list->AironetCellPowerLimit);
			} else {
				/*
				 *   AironetCellPowerLimit equal to 0xFF means the Cisco (ccx) "TxPower Limit" not exist.
				 *   Used the default TX Power Percentage, that set from UI.
				 */
				pAd->CommonCfg.ucTxPowerPercentage[BAND0] = pAd->CommonCfg.ucTxPowerDefault[BAND0];
#ifdef DBDC_MODE
				pAd->CommonCfg.ucTxPowerPercentage[BAND1] = pAd->CommonCfg.ucTxPowerDefault[BAND1];
#endif /* DBDC_MODE */
			}

			if (ADHOC_ON(pAd) && (CAP_IS_IBSS_ON(bcn_ie_list->CapabilityInfo))) {
				UCHAR			MaxSupportedRateIn500Kbps = 0;
				MAC_TABLE_ENTRY *pEntry;
#ifdef IWSC_SUPPORT
				PWSC_CTRL pWpsCtrl = &pStaCfg->WscControl;
#endif /* IWSC_SUPPORT */
				MaxSupportedRateIn500Kbps = dot11_max_sup_rate(bcn_ie_list->SupRateLen, &bcn_ie_list->SupRate[0],
											bcn_ie_list->ExtRateLen, &bcn_ie_list->ExtRate[0]);
				/* look up the existing table */
				pEntry = MacTableLookup2(pAd, bcn_ie_list->Addr2, wdev);

				/*
				 *   Ad-hoc mode is using MAC address as BA session. So we need to continuously find newly joined adhoc station by receiving beacon.
				 *   To prevent always check this, we use wcid == RESERVED_WCID to recognize it as newly joined adhoc station.
				 */
				if ((ADHOC_ON(pAd) && ((!pEntry) || (pEntry && IS_ENTRY_NONE(pEntry)))) ||
					(pEntry && RTMP_TIME_AFTER(Now, pEntry->LastBeaconRxTime + ADHOC_ENTRY_BEACON_LOST_TIME))) {
					/* Another adhoc joining, add to our MAC table. */
					if (pEntry == NULL) {
						pEntry = MacTableInsertEntry(pAd, bcn_ie_list->Addr2, wdev, ENTRY_ADHOC, OPMODE_STA, FALSE);
#ifdef RT_CFG80211_SUPPORT
						MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
								 ("Another adhoc joining, add to our MAC table ==> %02x:%02x:%02x:%02x:%02x:%02x\n",
								  PRINT_MAC(bcn_ie_list->Addr2)));
						RT_CFG80211_JOIN_IBSS(pAd, pStaCfg->MlmeAux.Bssid);
						CFG80211OS_NewSta(pAd->net_dev, bcn_ie_list->Addr2, NULL, 0);
#endif /* RT_CFG80211_SUPPORT */
					}

					if (pEntry == NULL)
						goto LabelOK;

					SET_ENTRY_CLIENT(pEntry);
#ifdef IWSC_SUPPORT
					hex_dump("Another adhoc joining - Addr2", bcn_ie_list->Addr2, 6);
					hex_dump("Another adhoc joining - WscPeerMAC", pStaCfg->WscControl.WscPeerMAC, 6);

					if ((NdisEqualMemory(bcn_ie_list->Addr2, pStaCfg->WscControl.WscPeerMAC, MAC_ADDR_LEN)) &&
						(pStaCfg->IWscInfo.bSendEapolStart == FALSE) &&
						(pWpsCtrl->bWscTrigger == TRUE))
						pStaCfg->IWscInfo.bSendEapolStart = TRUE;

#endif /* IWSC_SUPPORT */
#ifdef DOT11_VHT_AC
					{
						BOOLEAN result;
						IE_LISTS *ielist;
						os_alloc_mem(NULL, (UCHAR **)&ielist, sizeof(IE_LISTS));

						if (!ielist)
							goto LabelOK;

						NdisZeroMemory((UCHAR *)ielist, sizeof(IE_LISTS));

						if (bcn_ie_list->vht_cap_len && bcn_ie_list->vht_op_len) {
							NdisMoveMemory(&ielist->vht_cap, &bcn_ie_list->vht_cap_ie, sizeof(VHT_CAP_IE));
							NdisMoveMemory(&ielist->vht_op, &bcn_ie_list->vht_op_ie, sizeof(VHT_OP_IE));
							ielist->vht_cap_len = bcn_ie_list->vht_cap_len;
							ielist->vht_op_len = bcn_ie_list->vht_op_len;
						}

						result = StaUpdateMacTableEntry(pAd,
														pEntry,
														MaxSupportedRateIn500Kbps,
														&bcn_ie_list->HtCapability,
														bcn_ie_list->HtCapabilityLen,
														&bcn_ie_list->AddHtInfo,
														bcn_ie_list->AddHtInfoLen,
														ielist,
														bcn_ie_list->CapabilityInfo);
						os_free_mem(ielist);

						if (result == FALSE) {
							MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ADHOC - Add Entry failed.\n"));
							goto LabelOK;
						}

#ifdef IWSC_SUPPORT
						else
							pEntry->bUpdateInfoFromPeerBeacon = TRUE;

#endif /* IWSC_SUPPORT */
					}
#else

					if (StaUpdateMacTableEntry(pAd,
											   pEntry,
											   MaxSupportedRateIn500Kbps,
											   &bcn_ie_list->HtCapability,
											   bcn_ie_list->HtCapabilityLen,
											   &bcn_ie_list->AddHtInfo,
											   bcn_ie_list->AddHtInfoLen,
											   NULL,
											   bcn_ie_list->CapabilityInfo) == FALSE) {
						MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ADHOC - Add Entry failed.\n"));
						goto LabelOK;
					}

#ifdef IWSC_SUPPORT
					else
						pEntry->bUpdateInfoFromPeerBeacon = TRUE;

#endif /* IWSC_SUPPORT */
#endif /* DOT11_VHT_AC */

					if (ADHOC_ON(pAd) && pEntry) {
						RTMPSetSupportMCS(pAd,
										  OPMODE_STA,
										  pEntry,
										  bcn_ie_list->SupRate,
										  bcn_ie_list->SupRateLen,
										  bcn_ie_list->ExtRate,
										  bcn_ie_list->ExtRateLen,
#ifdef DOT11_VHT_AC
										  bcn_ie_list->vht_cap_len,
										  &bcn_ie_list->vht_cap_ie,
#endif /* DOT11_VHT_AC */
										  &bcn_ie_list->HtCapability,
										  bcn_ie_list->HtCapabilityLen);
					}

					pEntry->LastBeaconRxTime = 0;
#ifdef ADHOC_WPA2PSK_SUPPORT

					/* Adhoc support WPA2PSK by Eddy */
					if (IS_AKM_WPA2PSK(wdev->SecConfig.AKMMap)
						&& (pEntry->WPA_Authenticator.WpaState < AS_INITPSK)
#ifdef IWSC_SUPPORT
						&& ((pStaCfg->WscControl.WscConfMode == WSC_DISABLE) ||
							(pStaCfg->WscControl.bWscTrigger == FALSE) ||
							(NdisEqualMemory(pEntry->Addr, pStaCfg->WscControl.WscPeerMAC, MAC_ADDR_LEN) == FALSE))
#ifdef IWSC_TEST_SUPPORT
						&& (pStaCfg->IWscInfo.bBlockConnection == FALSE)
#endif /* IWSC_TEST_SUPPORT */
#endif /* IWSC_SUPPORT // */
					   ) {
						INT len, i;
						PEID_STRUCT         pEid;
						NDIS_802_11_VARIABLE_IEs    *pVIE2 = NULL;
						BOOLEAN bHigherMAC = FALSE;
						pVIE2 = pVIE;
						len	 = LenVIE;

						while (len > 0) {
							pEid = (PEID_STRUCT) pVIE;

							if ((pEid->Eid == IE_RSN) && (NdisEqualMemory(pEid->Octet + 2, RSN_OUI, 3))) {
								NdisMoveMemory(pEntry->RSN_IE, pVIE, (pEid->Len + 2));
								pEntry->RSNIE_Len = (pEid->Len + 2);
							}

							pVIE2 += (pEid->Len + 2);
							len  -= (pEid->Len + 2);
						}

						/* pEntry->PortSecured = WPA_802_1X_PORT_NOT_SECURED; */
						/* TODO: shiang-usw, need to replace upper setting with tr_entry */
						pAd->MacTab.tr_entry[pEntry->wcid].PortSecured = WPA_802_1X_PORT_NOT_SECURED;
						NdisZeroMemory(&pEntry->WPA_Supplicant.ReplayCounter, LEN_KEY_DESC_REPLAY);
						NdisZeroMemory(&pEntry->WPA_Authenticator.ReplayCounter, LEN_KEY_DESC_REPLAY);
						pEntry->WPA_Authenticator.WpaState = AS_INITPSK;
						pEntry->WPA_Supplicant.WpaState = AS_INITPSK;
						pEntry->EnqueueEapolStartTimerRunning = EAPOL_START_PSK;

						for (i = 0; i < 6; i++) {
							if (bcn_ie_list->Addr2[i] > wdev->if_addr[i]) {
								bHigherMAC = TRUE;
								break;
							} else if (bcn_ie_list->Addr2[i] < wdev->if_addr[i])
								break;
						}

						hex_dump("PeerBeacon:: Addr2", bcn_ie_list->Addr2, MAC_ADDR_LEN);
						hex_dump("PeerBeacon:: CurrentAddress", wdev->if_addr, MAC_ADDR_LEN);
						pEntry->bPeerHigherMAC = bHigherMAC;

						if (pEntry->bPeerHigherMAC == FALSE) {
							/*
							 *	My MAC address is higher than peer's MAC address.
							 */
							/* MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ADHOC - EnqueueStartForPSKTimer.\n")); */
							/* RTMPSetTimer(&pEntry->EnqueueStartForPSKTimer, ENQUEUE_EAPOL_START_TIMER); */
						}
					} else {
						/* pEntry->PortSecured = WPA_802_1X_PORT_SECURED; */
						/* TODO: shiang-usw, need to replace upper setting with tr_entry */
						pAd->MacTab.tr_entry[pEntry->wcid].PortSecured = WPA_802_1X_PORT_SECURED;
					}

#endif /* ADHOC_WPA2PSK_SUPPORT */

					if (pEntry /*&& (Elem->Wcid == RESERVED_WCID)*/) {
						ASIC_SEC_INFO Info = {0};
						/* Set key material to Asic */
						os_zero_mem(&Info, sizeof(ASIC_SEC_INFO));
						Info.Operation = SEC_ASIC_ADD_GROUP_KEY;
						Info.Direction = SEC_ASIC_KEY_BOTH;
						Info.Wcid = pEntry->wcid;
						Info.BssIndex = wdev->func_idx;
						Info.Cipher = wdev->SecConfig.GroupCipher;
						Info.KeyIdx = wdev->SecConfig.GroupKeyId;
						os_move_mem(&Info.PeerAddr[0], pEntry->Addr, MAC_ADDR_LEN);
						HW_ADDREMOVE_KEYTABLE(pAd, &Info);
					}
				}

				if (pEntry && IS_ENTRY_CLIENT(pEntry)) {
					pEntry->LastBeaconRxTime = Now;
#ifdef IWSC_SUPPORT

					if (pEntry->bUpdateInfoFromPeerBeacon == FALSE) {
						if (StaUpdateMacTableEntry(pAd,
												   pEntry,
												   MaxSupportedRateIn500Kbps,
												   &bcn_ie_list->HtCapability,
												   bcn_ie_list->HtCapabilityLen,
												   &bcn_ie_list->AddHtInfo,
												   bcn_ie_list->AddHtInfoLen,
												   NULL,
												   bcn_ie_list->CapabilityInfo) == FALSE) {
							MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ADHOC 2 - Add Entry failed.\n"));
							return;
						}

						if (ADHOC_ON(pAd) && pEntry) {
							RTMPSetSupportMCS(pAd,
											  OPMODE_STA,
											  pEntry,
											  bcn_ie_list->SupRate,
											  bcn_ie_list->SupRateLen,
											  bcn_ie_list->ExtRate,
											  bcn_ie_list->ExtRateLen,
#ifdef DOT11_VHT_AC
											  bcn_ie_list->vht_cap_len,
											  &bcn_ie_list->vht_cap_ie,
#endif /* DOT11_VHT_AC */
											  &bcn_ie_list->HtCapability,
											  bcn_ie_list->HtCapabilityLen);
						}

						pEntry->bUpdateInfoFromPeerBeacon = TRUE;
					}

#endif /* IWSC_SUPPORT */
				}

				/* At least another peer in this IBSS, declare MediaState as CONNECTED */
				if (!STA_STATUS_TEST_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED)) {
					STA_STATUS_SET_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED);
					RTMP_IndicateMediaState(pAd, NdisMediaStateConnected);
#ifdef MT76XX_BTCOEX_SUPPORT
					MLMEHook(pAd, WLAN_CONNECTION_COMPLETION, QueryHashID(pAd, pAd->CommonCfg.Bssid, FALSE));
#endif /*MT76XX_BTCOEX_SUPPORT*/
					pAd->ExtraInfo = GENERAL_LINK_UP;
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ADHOC  fSTA_STATUS_MEDIA_STATE_CONNECTED.\n"));
				}

#ifdef IWSC_SUPPORT

				if (pStaCfg->IWscInfo.bSendEapolStart &&
					(pAd->Mlme.IWscMachine.CurrState != IWSC_WAIT_PIN) &&
					(pStaCfg->WscControl.WscConfMode == WSC_ENROLLEE)) {
					pStaCfg->IWscInfo.bSendEapolStart = FALSE;
					pWpsCtrl->WscState = WSC_STATE_LINK_UP;
					pWpsCtrl->WscStatus = STATUS_WSC_LINK_UP;
					NdisMoveMemory(pWpsCtrl->EntryAddr, pWpsCtrl->WscPeerMAC, MAC_ADDR_LEN);
					WscSendEapolStart(pAd, pWpsCtrl->WscPeerMAC, STA_MODE, wdev);
				}

#endif /* IWSC_SUPPORT */
			}

			if (INFRA_ON(pStaCfg)) {
				BOOLEAN bUseShortSlot;
				BOOLEAN bUseBGProtection;
				BOOLEAN bNonGFExist =
					(pStaCfg->MlmeAux.AddHtInfo.AddHtInfo2.NonGfPresent) ? TRUE : FALSE;
				UINT16 OperationMode =
					pStaCfg->MlmeAux.AddHtInfo.AddHtInfo2.OperaionMode;
				/*
				 *   decide to use/change to -
				 *      1. long slot (20 us) or short slot (9 us) time
				 *      2. turn on/off RTS/CTS and/or CTS-to-self protection
				 *      3. short preamble
				 */
#ifdef WMM_ACM_SUPPORT
				ACMP_BandwidthInfoSet(pAd, bcn_ie_list->QbssLoad.StaNum,
									  bcn_ie_list->QbssLoad.ChannelUtilization,
									  bcn_ie_list->QbssLoad.RemainingAdmissionControl);
#endif /* WMM_ACM_SUPPORT */
				/* bUseShortSlot = pAd->CommonCfg.bUseShortSlotTime && CAP_IS_SHORT_SLOT(CapabilityInfo); */
				bUseShortSlot = CAP_IS_SHORT_SLOT(bcn_ie_list->CapabilityInfo);

				if (bUseShortSlot != STA_STATUS_TEST_FLAG(pStaCfg, fSTA_STATUS_SHORT_SLOT_INUSED))
					HW_SET_SLOTTIME(pAd, bUseShortSlot, wdev->channel, wdev);

				bUseBGProtection = (pAd->CommonCfg.UseBGProtection == 1) ||    /* always use */
								   ((pAd->CommonCfg.UseBGProtection == 0) && ERP_IS_USE_PROTECTION(bcn_ie_list->Erp));

				if (wdev->channel > 14) {
					/* always no BG protection in A-band.
					 * falsely happened when switching A/G band to a dual-band AP
					 */
					bUseBGProtection = FALSE;
				}

				if (bUseBGProtection != OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_BG_PROTECTION_INUSED)) {
					if (bUseBGProtection) {
						OPSTATUS_SET_FLAG(pAd, fOP_STATUS_BG_PROTECTION_INUSED);
						wdev->protection |= SET_PROTECT(ERP);
					} else {
						OPSTATUS_CLEAR_FLAG(pAd, fOP_STATUS_BG_PROTECTION_INUSED);
						wdev->protection &= ~(SET_PROTECT(ERP));
					}

					AsicUpdateProtect(pAd);
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_WARN,
							 ("SYNC - AP changed B/G protection to %d\n", bUseBGProtection));
				}

#ifdef DOT11_N_SUPPORT

				/* check Ht protection mode. and adhere to the Non-GF device indication by AP. */
				if (bcn_ie_list->AddHtInfoLen != 0) {
					if ((bcn_ie_list->AddHtInfo.AddHtInfo2.OperaionMode != OperationMode)
						|| (bcn_ie_list->AddHtInfo.AddHtInfo2.NonGfPresent != bNonGFExist)) {
						pStaCfg->MlmeAux.AddHtInfo.AddHtInfo2.OperaionMode
							= bcn_ie_list->AddHtInfo.AddHtInfo2.OperaionMode;
						pStaCfg->MlmeAux.AddHtInfo.AddHtInfo2.NonGfPresent
							= bcn_ie_list->AddHtInfo.AddHtInfo2.NonGfPresent;
						OperationMode = pStaCfg->MlmeAux.AddHtInfo.AddHtInfo2.OperaionMode;
						bNonGFExist =
							(pStaCfg->MlmeAux.AddHtInfo.AddHtInfo2.NonGfPresent) ? TRUE : FALSE;

						if (bNonGFExist)
							wdev->protection |= SET_PROTECT(GREEN_FIELD_PROTECT);
						else
							wdev->protection &= ~(SET_PROTECT(GREEN_FIELD_PROTECT));

						AsicUpdateProtect(pAd);
						MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
								 ("SYNC - AP changed N OperaionMode to %d\n",
								  OperationMode));
					}
				}

#endif /* DOT11_N_SUPPORT */

				if (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_SHORT_PREAMBLE_INUSED) &&
					ERP_IS_USE_BARKER_PREAMBLE(bcn_ie_list->Erp)) {
					MlmeSetTxPreamble(pAd, Rt802_11PreambleLong);
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - AP forced to use LONG preamble\n"));
				}

				if (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_WMM_INUSED)    &&
					(bcn_ie_list->EdcaParm.bValid == TRUE) &&
					(bcn_ie_list->EdcaParm.EdcaUpdateCount !=
						pStaCfg->MlmeAux.APEdcaParm.EdcaUpdateCount)) {
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - AP change EDCA parameters(from %d to %d)\n",
							 pAd->CommonCfg.APEdcaParm[0].EdcaUpdateCount,
							 bcn_ie_list->EdcaParm.EdcaUpdateCount));
					HcAcquiredEdca(pAd, wdev, &bcn_ie_list->EdcaParm);
					HcSetEdca(wdev);
				}

				/* copy QOS related information */
				NdisMoveMemory(&pAd->CommonCfg.APQbssLoad, &bcn_ie_list->QbssLoad, sizeof(QBSS_LOAD_PARM));
				NdisMoveMemory(&pAd->CommonCfg.APQosCapability, &bcn_ie_list->QosCapability, sizeof(QOS_CAPABILITY_PARM));
#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3

				/*
				 *   2009: PF#1: 20/40 Coexistence in 2.4 GHz Band
				 *   When AP changes "STA Channel Width" and "Secondary Channel Offset" fields of HT Operation Element in the Beacon to 0
				 */

				if (INFRA_ON(pStaCfg)) {
					BOOLEAN bChangeBW = FALSE;
					bChangeBW = AdjustBwToSyncAp(pAd, bcn_ie_list, pEntry->wcid, 0);

					if (bChangeBW) {
						pAd->CommonCfg.BSSCoexist2040.word = 0;
						TriEventInit(pAd);
						BuildEffectedChannelList(pAd, wdev);
					}
				}

#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
#ifdef DOT11_VHT_AC

				if ((pEntry) && ((pEntry->force_op_mode != pStaCfg->MlmeAux.force_op_mode) ||
								 (NdisCmpMemory(&pEntry->operating_mode, &pStaCfg->MlmeAux.op_mode, 1) != 0))) {
					CMD_STAREC_AUTO_RATE_UPDATE_T rRaParam;
					pStaCfg->MlmeAux.force_op_mode = pEntry->force_op_mode;
					NdisMoveMemory(&pStaCfg->MlmeAux.op_mode, &pEntry->operating_mode, 1);
					NdisZeroMemory(&rRaParam, sizeof(CMD_STAREC_AUTO_RATE_UPDATE_T));
					rRaParam.u4Field = RA_PARAM_VHT_OPERATING_MODE;
					RAParamUpdate(pAd, pEntry, &rRaParam);
				}

#endif
			}

			/* only INFRASTRUCTURE mode support power-saving feature */
#ifdef STA_LP_PHASE_2_SUPPORT
			/* MT7636 STA Legacy PS (PS-POLL) and WMM PS is offload to FW */
#else

			if ((INFRA_ON(pStaCfg) && (RtmpPktPmBitCheck(pAd, pStaCfg) == TRUE)) || (pAd->CommonCfg.bAPSDForcePowerSave)) {
#if !defined(MT7615) && !defined(MT7622) && !defined(P18) && !defined(MT7663)
				UCHAR FreeNumber;
#endif

				/*
				 *     1. AP has backlogged unicast-to-me frame, stay AWAKE, send PSPOLL
				 *     2. AP has backlogged broadcast/multicast frame and we want those frames, stay AWAKE
				 *     3. we have outgoing frames in TxRing or MgmtRing, better stay AWAKE
				 *     4. Psm change to PWR_SAVE, but AP not been informed yet, we better stay AWAKE
				 *     5. otherwise, put PHY back to sleep to save battery.
				 */
				if (bcn_ie_list->MessageToMe) {
#ifdef STA_LP_PHASE_1_SUPPORT
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("SYNC - AP backlog unicast-to-me, stay AWAKE, send PSPOLL, SN(%d)\n", pFrame->Hdr.Sequence));
#endif /* STA_LP_PHASE_1_SUPPORT */
#ifdef UAPSD_SUPPORT

					if (pStaCfg->wdev.UapsdInfo.bAPSDCapable &&
						pAd->CommonCfg.APEdcaParm[0].bAPSDCapable &&
						pAd->CommonCfg.bAPSDAC_BE &&
						pAd->CommonCfg.bAPSDAC_BK &&
						pAd->CommonCfg.bAPSDAC_VI &&
						pAd->CommonCfg.bAPSDAC_VO) {
						pAd->CommonCfg.bNeedSendTriggerFrame = TRUE;
#if defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT)
						RTMPSendNullFrame(pAd,
										  pStaCfg,
										  pAd->CommonCfg.TxRate,
										  TRUE,
										  pAd->CommonCfg.bAPSDForcePowerSave ? PWR_SAVE : pStaCfg->PwrMgmt.Psm);
#endif /* defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT) */
					} else
#endif /* UAPSD_SUPPORT */
					{
#ifdef STA_LP_PHASE_1_SUPPORT

						if (pStaCfg->CountDowntoPsm == 0)
							pStaCfg->CountDowntoPsm = STAY_2_SECONDS_AWAKE;
						else
							MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:: pAd->CountDowntoPsm(%d)\n", __func__,
									 pStaCfg->CountDowntoPsm));

#endif /* STA_LP_PHASE_1_SUPPORT */

						if (pStaCfg->WindowsBatteryPowerMode == Ndis802_11PowerModeFast_PSP) {
#ifdef STA_LP_PHASE_1_SUPPORT
							MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
									 ("%s::Fast_PSP::Wake up both H/W and Protocol PS to retrieve buffered data\n",
									  __func__));

							if (pStaCfg->PwrMgmt.bDoze)
								AsicWakeup(pAd, TRUE, pStaCfg);

#endif /* STA_LP_PHASE_1_SUPPORT */
							/* wake up and send a NULL frame with PM = 0 to the AP */
							RTMP_SET_PSM_BIT(pAd, pStaCfg, PWR_ACTIVE);
							RTMPSendNullFrame(pAd,
											  pStaCfg,
											  pAd->CommonCfg.TxRate,
											  (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_WMM_INUSED) ? TRUE : FALSE),
											  PWR_ACTIVE);
						} else {
#ifdef STA_LP_PHASE_1_SUPPORT
							MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
									 ("%s::Legacy_PSP::Keep PS-POLL service period and avoid H/W enter PS mode\n",
									  __func__));

							if (pStaCfg->PwrMgmt.bDoze)
								AsicWakeup(pAd, TRUE, pStaCfg);

#endif /* STA_LP_PHASE_1_SUPPORT */
							/* use PS-Poll to get any buffered packet */
							MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:: Send PS-POLL to retrieve buffered data\n", __func__));
							ComposePsPoll(pAd, &(pAd->PsPollFrame), pStaCfg->StaActive.Aid,
										  pStaCfg->Bssid, pStaCfg->wdev.if_addr);
							RTMP_PS_POLL_ENQUEUE(pAd, pStaCfg);
						}
					}
				} else if (bcn_ie_list->BcastFlag && (bcn_ie_list->DtimCount == 0) &&
						   OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_RECEIVE_DTIM)) {
#ifdef RELEASE_EXCLUDE
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("SYNC - AP backlog broadcast/multicast, stay AWAKE\n"));
#endif /* RELEASE_EXCLUDE */
				}

#if !defined(MT7615) && !defined(MT7622) && !defined(P18) && !defined(MT7663)
				else if ((pAd->TxSwQueue[QID_AC_BK].Number != 0) ||
						 (pAd->TxSwQueue[QID_AC_BE].Number != 0) ||
						 (pAd->TxSwQueue[QID_AC_VI].Number != 0) ||
						 (pAd->TxSwQueue[QID_AC_VO].Number != 0) ||
						 (RTMPFreeTXDRequest(pAd, QID_AC_BK, TX_RING_SIZE - 1, &FreeNumber) != NDIS_STATUS_SUCCESS) ||
						 (RTMPFreeTXDRequest(pAd, QID_AC_BE, TX_RING_SIZE - 1, &FreeNumber) != NDIS_STATUS_SUCCESS) ||
						 (RTMPFreeTXDRequest(pAd, QID_AC_VI, TX_RING_SIZE - 1, &FreeNumber) != NDIS_STATUS_SUCCESS) ||
						 (RTMPFreeTXDRequest(pAd, QID_AC_VO, TX_RING_SIZE - 1, &FreeNumber) != NDIS_STATUS_SUCCESS) ||
						 (RTMPFreeTXDRequest(pAd, QID_MGMT, MGMT_RING_SIZE - 1, &FreeNumber) != NDIS_STATUS_SUCCESS)) {
					/* TODO: consider scheduled HCCA. might not be proper to use traditional DTIM-based power-saving scheme */
					/* can we cheat here (i.e. just check MGMT & AC_BE) for better performance? */
#ifdef RELEASE_EXCLUDE
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("SYNC - outgoing frame in TxRing/MgmtRing, stay AWAKE\n"));
#endif /* RELEASE_EXCLUDE */
				}

#endif /* !defined(MT7615) && !defined(MT7622) && !defined(P18) && !defined(MT7663) */
				else {
					if ((pAd->CommonCfg.bACMAPSDTr[QID_AC_VO]) ||
						(pAd->CommonCfg.bACMAPSDTr[QID_AC_VI]) ||
						(pAd->CommonCfg.bACMAPSDTr[QID_AC_BK]) ||
						(pAd->CommonCfg.bACMAPSDTr[QID_AC_BE])
#if defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT)
						|| (pStaCfg->FlgPsmCanNotSleep == TRUE)
						|| (RtmpPktPmBitCheck(pAd, pStaCfg) == FALSE)
#endif /* defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT) */
					   ) {
#ifdef RELEASE_EXCLUDE
						/*
						 *	WMM Spec v1.0 3.6.2.4,
						 *	The WMM STA shall remain awake until it receives a
						 *	QoS Data or Null frame addressed to it, with the
						 *	EOSP subfield in QoS Control field set to 1.
						 *
						 *	So we can not sleep here or we will suffer a case:
						 *
						 *	PS Management Frame -->
						 *	Trigger frame -->
						 *	Beacon (TIM=0) (Beacon is closer to Trig frame) -->
						 *	Station goes to sleep -->
						 *	AP delivery queued UAPSD packets -->
						 *	Station can NOT receive the reply
						 *
						 *	Maybe we need a timeout timer to avoid that we do
						 *	NOT receive the EOSP frame.
						 *
						 *	We can not use More Data to check if SP is ended
						 *	due to MaxSPLength.
						 */
#endif /* RELEASE_EXCLUDE */
					} else {
#ifdef STA_LP_PHASE_1_SUPPORT
#else
						USHORT NextDtim = bcn_ie_list->DtimCount;
#ifdef RELEASE_EXCLUDE
						/*
						 *   The value of DefaultListenCount depends on power-saving mode:
						 *Max_PSP               5
						 *   Legacy_PSP		3
						 *   FAST_PSP		3
						 *   The value of TbttNumToNextWakeUp is the smaller value between DefaultListenCount and NextDtim (is retrieved from beacon)
						 */
#endif /* RELEASE_EXCLUDE */

						if (NextDtim == 0)
							NextDtim = bcn_ie_list->DtimPeriod;

						TbttNumToNextWakeUp = pStaCfg->DefaultListenCount;

						if (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_RECEIVE_DTIM) && (TbttNumToNextWakeUp > NextDtim))
							TbttNumToNextWakeUp = NextDtim;

#ifdef RELEASE_EXCLUDE
						MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("SYNC - PHY sleeps for %d TBTT, Dtim=%d/%d\n",
								 TbttNumToNextWakeUp,
								 bcn_ie_list->DtimCount,
								 bcn_ie_list->DtimPeriod));
#endif /* RELEASE_EXCLUDE */

						if (!pStaCfg->PwrMgmt.bDoze) {
							/* Set a flag to go to sleep . Then after parse this RxDoneInterrupt, will go to sleep mode. */
							pStaCfg->ThisTbttNumToNextWakeUp = TbttNumToNextWakeUp;
							AsicSleepAutoWakeup(pAd, pStaCfg);
						}

#endif /* STA_LP_PHASE_1_SUPPORT */
					}
				}
			}

#endif /* STA_LP_PHASE_2_SUPPORT */
#ifdef CFG_TDLS_SUPPORT

			if (INFRA_ON(pAd) && (bcn_ie_list->DtimCount == 0) &&
				pStaCfg->wpa_supplicant_info.CFG_Tdls_info.bDoingPeriodChannelSwitch &&
				pStaCfg->wpa_supplicant_info.CFG_Tdls_info.bChannelSwitchInitiator) {
				BOOLEAN TimerCancelled;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("101. CFG TDLS DTIM %ld !!!\n", (jiffies * 1000) / OS_HZ));
				RTMPCancelTimer(&pStaCfg->wpa_supplicant_info.CFG_Tdls_info.BaseChannelSwitchTimer, &TimerCancelled);
				RTMPSetTimer(&pStaCfg->wpa_supplicant_info.CFG_Tdls_info.BaseChannelSwitchTimer,
							 pStaCfg->wpa_supplicant_info.CFG_Tdls_info.BaseChannelStayTime);

				if (bcn_ie_list->MessageToMe)
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("301. %ld DTIM MessageToMe !!!\n", (jiffies * 1000) / OS_HZ));

				if (pStaCfg->wpa_supplicant_info.CFG_Tdls_info.IamInOffChannel == TRUE) {
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
							 ("%ld Recieve Orig AP Beacon but FW didn't inform Back to Base, force back to base !!!\n",
							  (jiffies * 1000) / OS_HZ));
					pStaCfg->wpa_supplicant_info.CFG_Tdls_info.IamInOffChannel = FALSE;
				}
			}

#endif /* CFG_TDLS_SUPPORT // */
		}

		/* not my BSSID, ignore it */
	}

	/* sanity check fail, ignore this frame */
	goto LabelOK;
LabelErr:
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: Allocate memory fail!!!\n", __func__));
LabelOK:

	if (VarIE != NULL)
		os_free_mem(VarIE);

	if (bcn_ie_list != NULL)
		os_free_mem(bcn_ie_list);

#if 0
	/* +++Add by shiang for debug */
	{
		ULONG now_time;
		NdisGetSystemUpTime(&now_time);
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("<--%s(), jiffies=0x%x\n", __func__, now_time));
	}
	/* ---Add by shiang for debug */
#endif
}

/*
 *	==========================================================================
 *	Description:
 *		Receive PROBE REQ from remote peer when operating in IBSS mode
 *	==========================================================================
 */
VOID PeerProbeReqAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	PEER_PROBE_REQ_PARAM ProbeReqParam = { {0} };
#ifdef DOT11_N_SUPPORT
	struct _build_ie_info ie_info = {0};
#endif /* DOT11_N_SUPPORT */
	HEADER_802_11 ProbeRspHdr;
	NDIS_STATUS   NStatus;
	PUCHAR        pOutBuffer = NULL;
	ULONG         FrameLen = 0;
	LARGE_INTEGER FakeTimestamp;
	UCHAR         DsLen = 1, IbssLen = 2;
	UCHAR         LocalErpIe[3] = {IE_ERP, 1, 0};
	BOOLEAN       Privacy;
	USHORT        CapabilityInfo;
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef DOT11_N_SUPPORT
	ie_info.frame_subtype = SUBTYPE_PROBE_RSP;
	ie_info.channel = wdev->channel;
	ie_info.phy_mode = wdev->PhyMode;
	ie_info.wdev = wdev;
#endif /* DOT11_N_SUPPORT */

#ifdef P2P_SUPPORT

	/* P2P device and Listen State could response Probe Req. */
	/*	if ((pAd->P2pCfg.DiscCurrentState == P2P_DISC_LISTEN) && !(P2P_CLI_ON(pAd)))*/
	if (P2P_INF_ON(pAd))
		MlmeEnqueueWithWdev(pAd, P2P_DISC_STATE_MACHINE, P2P_DISC_PEER_PROB_REQ, Elem->MsgLen, Elem->Msg, Elem->Channel,
							Elem->wdev);

#endif /* P2P_SUPPORT */

	if (!ADHOC_ON(pAd))
		return;

	if (PeerProbeReqSanity(pAd, Elem->Msg, Elem->MsgLen, &ProbeReqParam)) {
		if ((ProbeReqParam.SsidLen == 0) ||
			SSID_EQUAL(ProbeReqParam.Ssid, ProbeReqParam.SsidLen, pStaCfg->Ssid, pStaCfg->SsidLen)) {
			/* allocate and send out ProbeRsp frame */
			NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);  /* Get an unused nonpaged memory */

			if (NStatus != NDIS_STATUS_SUCCESS)
				return;

#if 0
			pStaCfg->AtimWin = 0;  /* ?????? */
#endif
#ifdef RELEASE_EXCLUDE
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("SYNC - Send PROBE_RSP to %02x:%02x:%02x:%02x:%02x:%02x...\n",
					 PRINT_MAC(ProbeReqParam.Addr2)));
#endif /* RELEASE_EXCLUDE */
			MgtMacHeaderInit(pAd, &ProbeRspHdr, SUBTYPE_PROBE_RSP,
							 0, ProbeReqParam.Addr2,
							 pStaCfg->wdev.if_addr,
							 pStaCfg->Bssid);
			Privacy = IS_SECURITY(&wdev->SecConfig);
			CapabilityInfo = CAP_GENERATE(0, 1, Privacy, (pAd->CommonCfg.TxPreamble == Rt802_11PreambleShort), 0, 0);
			MakeOutgoingFrame(pOutBuffer,                   &FrameLen,
							  sizeof(HEADER_802_11),        &ProbeRspHdr,
							  TIMESTAMP_LEN,                &FakeTimestamp,
							  2,                            &pAd->CommonCfg.BeaconPeriod,
							  2,                            &CapabilityInfo,
							  1,                            &SsidIe,
							  1,                            &pStaCfg->SsidLen,
							  pStaCfg->SsidLen,             pStaCfg->Ssid,
							  1,                            &SupRateIe,
							  1,                            &pStaCfg->StaActive.SupRateLen,
							  pStaCfg->StaActive.SupRateLen, pStaCfg->StaActive.SupRate,
							  1,                            &DsIe,
							  1,                            &DsLen,
							  1,                            &wdev->channel,
							  1,                            &IbssIe,
							  1,                            &IbssLen,
							  2,                            &pStaCfg->StaActive.AtimWin,
							  END_OF_ARGS);

			if (pStaCfg->StaActive.ExtRateLen) {
				ULONG tmp;
				MakeOutgoingFrame(pOutBuffer + FrameLen,        &tmp,
								  3,                            LocalErpIe,
								  1,                            &ExtRateIe,
								  1,                            &pStaCfg->StaActive.ExtRateLen,
								  pStaCfg->StaActive.ExtRateLen, &pStaCfg->StaActive.ExtRate,
								  END_OF_ARGS);
				FrameLen += tmp;
			}

			/* Modify by Eddy, support WPA2PSK in Adhoc mode */
			if (IS_AKM_WPANONE(wdev->SecConfig.AKMMap)
#ifdef ADHOC_WPA2PSK_SUPPORT
				|| IS_AKM_WPA2PSK(wdev->SecConfig.AKMMap)
#endif /* ADHOC_WPA2PSK_SUPPORT */
			   ) {
				ULONG   tmp;
				UCHAR   RSNIe = IE_WPA;
#ifdef ADHOC_WPA2PSK_SUPPORT
				RTMPMakeRSNIE(pAd, wdev->AuthMode, wdev->WepStatus, BSS0);

				if (IS_AKM_WPA2PSK(wdev->SecConfig.AKMMap))
					RSNIe = IE_RSN;

#endif /* ADHOC_WPA2PSK_SUPPORT */
				MakeOutgoingFrame(pOutBuffer + FrameLen,		&tmp,
								  1,				&RSNIe,
								  1,				&pStaCfg->RSNIE_Len,
								  pStaCfg->RSNIE_Len,		pStaCfg->RSN_IE,
								  END_OF_ARGS);
				FrameLen += tmp;
			}

#ifdef DOT11_N_SUPPORT

			if (WMODE_CAP_N(wdev->PhyMode)) {
				ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
				ie_info.is_draft_n_type = FALSE;
				FrameLen += build_ht_ies(pAd, &ie_info);

				if (pAd->bBroadComHT == TRUE) {
					ie_info.is_draft_n_type = TRUE;
					ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
					FrameLen += build_ht_ies(pAd, &ie_info);
				}
			}

#endif /* DOT11_N_SUPPORT */
#ifdef WSC_STA_SUPPORT

			/* add Simple Config Information Element */
			if (wdev->WscIEProbeResp.ValueLen != 0) {
				ULONG WscTmpLen = 0;
				MakeOutgoingFrame(pOutBuffer + FrameLen,					&WscTmpLen,
								  wdev->WscIEProbeResp.ValueLen,		wdev->WscIEProbeResp.Value,
								  END_OF_ARGS);
				FrameLen += WscTmpLen;
			}

#endif /* WSC_STA_SUPPORT */
			MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
			MlmeFreeMemory(pOutBuffer);
		}
	}
}

VOID BeaconTimeoutAtJoinAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - BeaconTimeoutAtJoinAction\n"));
	pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
	Status = MLME_REJ_TIMEOUT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_JOIN_CONF, 2, &Status, 0, Elem->wdev);
}

/*
 *	==========================================================================
 *	Description:
 *		Scan timeout procedure. basically add channel index by 1 and rescan
 *	==========================================================================
 */
VOID ScanTimeoutAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
#ifdef WIDI_SUPPORT
#ifdef P2P_SUPPORT
	/* This counter is for L2SD + Wifi Direct Listen Channel Interop */
	static int count_scan;

	/* Reset the counter, if widi is disable by cmd*/
	if (!(pStaCfg->bWIDI || pAd->P2pCfg.bWIDI))
		count_scan = 0;

#endif /* P2P_SUPPORT */
#endif /* WIDI_SUPPORT */
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef RTMP_MAC_USB

	/*
	 *    To prevent data lost.
	 *    Send an NULL data with turned PSM bit on to current associated AP when SCAN in the channel where
	 *    associated AP located.
	 */
	if ((wdev->channel == pStaCfg->MlmeAux.Channel) &&
		(pStaCfg->MlmeAux.ScanType == SCAN_ACTIVE) &&
		(INFRA_ON(pStaCfg)) &&
		STA_STATUS_TEST_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED)
	   ) {
#if 1
		RTMPSendNullFrame(pAd,
						  pStaCfg,
						  pAd->CommonCfg.TxRate,
						  (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_WMM_INUSED) ? TRUE : FALSE),
						  PWR_SAVE);
#else
		PUCHAR pOutBuffer;
		NDIS_STATUS NStatus;
		PHEADER_802_11 pHdr80211;
		NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);  /*Get an unused nonpaged memory */

		if (NStatus == NDIS_STATUS_SUCCESS) {
			NdisZeroMemory(pOutBuffer, MGMT_DMA_BUFFER_SIZE);
			pHdr80211 = (PHEADER_802_11) pOutBuffer;
			MgtMacHeaderInit(pAd, pHdr80211, SUBTYPE_DATA_NULL, 1, pAd->CommonCfg.Bssid, pAd->CommonCfg.Bssid);
			pHdr80211->Duration = 0;
			pHdr80211->FC.Type = FC_TYPE_DATA;
			pHdr80211->FC.PwrMgmt = PWR_SAVE;
			/* Send using priority queue */
			MiniportMMRequest(pAd, 0, pOutBuffer, sizeof(HEADER_802_11));
			MlmeFreeMemory(pOutBuffer);
			OS_WAIT(20);
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("ScanTimeoutAction():Send PWS NullData frame to notify the associated AP!\n"));
		} else
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): Cannot get memory to send NullFrame out!\n", __func__));

#endif
	}

#endif /* RTMP_MAC_USB */

	if (pStaCfg->bFastConnect && !pStaCfg->bNotFirstScan) {
		pStaCfg->MlmeAux.Channel = 0;
		pAd->ScanCtrl.Channel = 0;
		pStaCfg->bNotFirstScan = TRUE;
#ifdef WIDI_SUPPORT
#ifdef P2P_SUPPORT
		count_scan = 0;
#endif /* P2P_SUPPORT */
#endif /* WIDI_SUPPORT */
	} else {
#ifdef P2P_SUPPORT
#ifdef WIDI_SUPPORT
#ifdef INTEL_L2SD_TOGGLE_SCAN_SUPPORT

		if (pStaCfg->bWIDI && pAd->P2pCfg.bWIDI) {
			count_scan++;

			if (count_scan > pAd->p2p_l2sd_scan_toggle) {
				count_scan = 0;
				pStaCfg->MlmeAux.Channel = 0;
				pAd->ScanCtrl.Channel = 0;

				/*
				 *	Go back to listen channel, set P2P DISC SM to be LISTEN for receiving Probe Req from Peer.
				 *
				 *	1.	After ra0 connects to AP, we cannot change Channel here.
				 *		If we change this value, STA will lost connection with AP after scanning.
				 *	2.	After P2P negociation is done, we cannot change Channel here.
				 *		If we change this value, P2P Client will lost connection with P2P Owner because of zero ApCliRcvBeaconTime.
				 */
				if (((!INFRA_ON(pStaCfg)) && (!P2P_CLI_ON(pAd)) && (!P2P_GO_ON(pAd))) || (pAd->OpMode == OPMODE_AP))
					wdev->channel = pAd->P2pCfg.ListenChannel;

				MlmeEnqueueWithWdev(pAd, P2P_DISC_STATE_MACHINE, P2P_DISC_LISTEN_CMD_EVT, 0, NULL, TRUE, Elem->wdev);
				RTMP_MLME_HANDLER(pAd);
			} else {
				if (pStaCfg->MlmeAux.OldChannel) {
					pStaCfg->MlmeAux.Channel = NextChannel(pAd, pStaCfg->MlmeAux.OldChannel);
					pAd->ScanCtrl.Channel = NextChannel(pAd, pStaCfg->MlmeAux.OldChannel);
				} else {
					pStaCfg->MlmeAux.Channel = NextChannel(pAd, pStaCfg->MlmeAux.Channel);
					pAd->ScanCtrl.Channel = NextChannel(pAd, pStaCfg->MlmeAux.Channel);
				}

				if (pStaCfg->MlmeAux.Channel == 0) { /* reach the last channel */
					if (count_scan <= pAd->p2p_l2sd_scan_toggle) {
						pStaCfg->MlmeAux.Channel = FirstChannel(pAd);
						pAd->ScanCtrl.Channel = FirstChannel(pAd);
					}
				}

				pStaCfg->MlmeAux.OldChannel = pStaCfg->MlmeAux.Channel;
			}
		} else
#endif /* INTEL_L2SD_TOGGLE_SCAN_SUPPORT */
#endif /* WIDI_SUPPORT */
#endif /* P2P_SUPPORT */
		{
			pStaCfg->MlmeAux.OldChannel = pStaCfg->MlmeAux.Channel;
			pStaCfg->MlmeAux.Channel = NextChannel(pAd, pStaCfg->MlmeAux.Channel);
			pAd->ScanCtrl.Channel = NextChannel(pAd, pAd->ScanCtrl.Channel);
#ifdef COEX_SUPPORT

			if (pStaCfg->MlmeAux.OldChannel <= 14 && pStaCfg->MlmeAux.Channel > 14) {
				if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd)) {
					MT76xxMLMEHook(pAd, MT76xx_WLAN_SCANDONE_2G, 0);
					MT76xxMLMEHook(pAd, MT76xx_WLAN_SCANREQEST_5G, 0);
				}
			}

#endif /* COEX_SUPPORT */
		}
	}

	/* Only one channel scanned for CISCO beacon request */
	if ((pStaCfg->MlmeAux.ScanType == SCAN_CISCO_ACTIVE) ||
		(pStaCfg->MlmeAux.ScanType == SCAN_CISCO_PASSIVE) ||
		(pStaCfg->MlmeAux.ScanType == SCAN_CISCO_NOISE) ||
		(pStaCfg->MlmeAux.ScanType == SCAN_CISCO_CHANNEL_LOAD)) {
		pStaCfg->MlmeAux.Channel = 0;
		pAd->ScanCtrl.Channel = 0;
	}

	/* this routine will stop if pStaCfg->MlmeAux.Channel == 0 */
	ScanNextChannel(pAd, OPMODE_STA, wdev);
}

/*
 *	==========================================================================
 *	Description:
 *	==========================================================================
 */
VOID InvalidStateWhenScan(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
#ifdef P2P_SUPPORT
	UCHAR          Ssid[MAX_LEN_OF_SSID], SsidLen, ScanType, BssType;
#endif /* P2P_SUPPORT */
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	if (Elem->MsgType != MT2_MLME_SCAN_REQ)
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("AYNC - InvalidStateWhenScan(state=%ld). Reset SYNC machine\n",
				 pStaCfg->SyncMachine.CurrState));
	else
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("AYNC - Already in scanning, do nothing here.(state=%ld).\n",
				 pStaCfg->SyncMachine.CurrState));

#ifdef P2P_SUPPORT

	if (MlmeScanReqSanity(pAd,
						  Elem->Msg,
						  Elem->MsgLen,
						  &BssType,
						  (PCHAR)Ssid,
						  &SsidLen,
						  &ScanType)) {
#if 0

		if ((ScanType == SCAN_P2P) || (ScanType == SCAN_P2P_SEARCH)) {
			MlmeEnqueue(pAd, SYNC_STATE_MACHINE, MT2_MLME_SCAN_REQ, Elem->MsgLen, Elem->Msg, 0);
			return;
		}

#endif
		/* reset Device Discovery State Machine. */
		MlmeEnqueueWithWdev(pAd, P2P_CTRL_STATE_MACHINE, P2P_CTRL_DISC_CANL_EVT, 0, NULL, 0, Elem->wdev);
		P2PSetNextScanTimer(pAd, 10);
		return;
	}

#endif /* P2P_SUPPORT */

	if (Elem->MsgType != MT2_MLME_SCAN_REQ) {
		pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
		Status = MLME_STATE_MACHINE_REJECT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_SCAN_CONF, 2, &Status, 0, Elem->wdev);
	}
}

/*
 *	==========================================================================
 *	Description:
 *	==========================================================================
 */
VOID InvalidStateWhenJoin(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("InvalidStateWhenJoin(state=%ld, msg=%ld). Reset SYNC machine\n",
			  pStaCfg->SyncMachine.CurrState,
			  Elem->MsgType));
	pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
	Status = MLME_STATE_MACHINE_REJECT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_JOIN_CONF, 2, &Status, 0, Elem->wdev);
}

/*
 *	==========================================================================
 *	Description:
 *	==========================================================================
 */
VOID InvalidStateWhenStart(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("InvalidStateWhenStart(state=%ld). Reset SYNC machine\n",
			 pStaCfg->SyncMachine.CurrState));
	pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
	Status = MLME_STATE_MACHINE_REJECT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_START_CONF, 2, &Status, 0, Elem->wdev);
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID EnqueuePsPoll(RTMP_ADAPTER *pAd, PSTA_ADMIN_CONFIG pStaCfg)
{
#ifdef CONFIG_ATE

	if (ATE_ON(pAd))
		return;

#endif /* CONFIG_ATE */
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("SYNC - send PsPoll ...\n"));
#endif /* RELEASE_EXCLUDE */

	if (pStaCfg->WindowsPowerMode == Ndis802_11PowerModeLegacy_PSP)
		pAd->PsPollFrame.FC.PwrMgmt = PWR_SAVE;

	MiniportMMRequest(pAd, 0, (PUCHAR)&pAd->PsPollFrame, sizeof(PSPOLL_FRAME));
#ifdef STA_LP_PHASE_1_SUPPORT

	/* Keep Waking up */
	if (pStaCfg->CountDowntoPsm == 0)
		pStaCfg->CountDowntoPsm = STAY_2_SECONDS_AWAKE;

#else
#ifdef RTMP_MAC_USB

	/* Keep Waking up */
	if (pStaCfg->CountDowntoPsm == 0)
		pStaCfg->CountDowntoPsm = STAY_2_SECONDS_AWAKE;

#endif /* RTMP_MAC_USB */
#endif /* STA_LP_PHASE_1_SUPPORT */
}

#if 0
/*
 *	==========================================================================
 *	Description:
 *	==========================================================================
 */
VOID EnqueueProbeRequest(RTMP_ADAPTER *pAd)
{
	NDIS_STATUS     NState;
	PUCHAR          pOutBuffer;
	ULONG           FrameLen = 0;
	HEADER_802_11   Hdr80211;
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("force out a ProbeRequest ...\n"));
	NState = MlmeAllocateMemory(pAd, &pOutBuffer);  /* Get an unused nonpaged memory */

	if (NState == NDIS_STATUS_SUCCESS) {
		MgtMacHeaderInit(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, BROADCAST_ADDR,
						 pAd->CurrentAddress,
						 BROADCAST_ADDR);
		/* this ProbeRequest explicitly specify SSID to reduce unwanted ProbeResponse */
		MakeOutgoingFrame(pOutBuffer,                     &FrameLen,
						  sizeof(HEADER_802_11),          &Hdr80211,
						  1,                              &SsidIe,
						  1,                              &pAd->CommonCfg.SsidLen,
						  pAd->CommonCfg.SsidLen,		  pAd->CommonCfg.Ssid,
						  1,                              &SupRateIe,
						  1,                              &pStaCfg->StaActive.SupRateLen,
						  pAd->StaActive.SupRateLen,      pAd->StaActive.SupRate,
						  END_OF_ARGS);
		MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
		MlmeFreeMemory(pOutBuffer);
	}
}
#endif

#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
/*
 *	========================================================================
 *
 *	Routine Description:
 *		Control Primary&Central Channel, ChannelWidth and Second Channel Offset
 *
 *	Arguments:
 *		pAd						Pointer to our adapter
 *		PrimaryChannel			Primary Channel
 *		CentralChannel			Central Channel
 *		ChannelWidth				BW_20 or BW_40
 *		SecondaryChannelOffset	EXTCHA_NONE, EXTCHA_ABOVE and EXTCHA_BELOW
 *
 *	Return Value:
 *		None
 *
 *	Note:
 *
 *	========================================================================
 */
VOID CntlChannelWidth(
	IN PRTMP_ADAPTER pAd,
	IN UCHAR prim_ch,
	IN UCHAR cent_ch,
	IN UCHAR ch_bw,
	IN UCHAR sec_ch_offset)
{
	UINT8 rf_bw = BW_20, ext_ch = EXTCHA_NONE;
	struct wifi_dev *wdev = get_default_wdev(pAd);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s: PrimaryChannel[%d]\n", __func__, prim_ch));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s: CentralChannel[%d]\n", __func__, cent_ch));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s: ChannelWidth[%d]\n", __func__, ch_bw));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s: SecondaryChannelOffset[%d]\n", __func__, sec_ch_offset));
#ifdef DOT11_N_SUPPORT

	/*Change to AP channel */
	if (ch_bw == BW_40) {
		if (sec_ch_offset == EXTCHA_ABOVE) {
			rf_bw = BW_40;
			ext_ch = EXTCHA_ABOVE;
		} else if (sec_ch_offset == EXTCHA_BELOW) {
			rf_bw = BW_40;
			ext_ch = EXTCHA_BELOW;
		}
	} else
#endif /* DOT11_N_SUPPORT */
	{
		rf_bw = BW_20;
		ext_ch = EXTCHA_NONE;
	}

	wlan_operate_set_prim_ch(wdev, prim_ch);
	wlan_operate_set_ht_bw(wdev, rf_bw, ext_ch);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("!!!40MHz Lower !!! Control Channel at Below. Central = %d\n",
			 wlan_operate_get_cen_ch_1(wdev)));
	bbp_get_agc(pAd, &pAd->BbpTuning.R66CurrentValue, RX_CHAIN_0);
}
#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */

/*
 *    ==========================================================================
 *    Description:
 *	MLME Cancel the SCAN req state machine procedure
 *    ==========================================================================
 */
VOID ScanCnclAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	BOOLEAN Cancelled;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	RTMPCancelTimer(&pStaCfg->MlmeAux.ScanTimer, &Cancelled);
	pStaCfg->MlmeAux.Channel = 0;
	pAd->ScanCtrl.Channel = 0;
	ScanNextChannel(pAd, OPMODE_STA, Elem->wdev);
}

