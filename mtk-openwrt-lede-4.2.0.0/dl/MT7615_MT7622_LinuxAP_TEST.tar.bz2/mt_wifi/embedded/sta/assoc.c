/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology	5th	Rd.
 * Science-based Industrial	Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2004, Ralink Technology, Inc.
 *
 * All rights reserved.	Ralink's source	code is	an unpublished work	and	the
 * use of a	copyright notice does not imply	otherwise. This	source code
 * contains	confidential trade secret material of Ralink Tech. Any attemp
 * or participation	in deciphering,	decoding, reverse engineering or in	any
 * way altering	the	source code	is stricitly prohibited, unless	the	prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	assoc.c

	Abstract:

	Revision History:
	Who			When			What
	--------	----------		----------------------------------------------
	John		2004-9-3		porting from RT2500
*/
#include "rt_config.h"
#ifdef DOT11R_FT_SUPPORT
#include "ft.h"
#endif /* DOT11R_FT_SUPPORT */

UCHAR CipherWpaTemplate[] = {
	0xdd,			/* WPA IE */
	0x16,			/* Length */
	0x00, 0x50, 0xf2, 0x01,	/* oui */
	0x01, 0x00,		/* Version */
	0x00, 0x50, 0xf2, 0x02,	/* Multicast */
	0x01, 0x00,		/* Number of unicast */
	0x00, 0x50, 0xf2, 0x02,	/* unicast */
	0x01, 0x00,		/* number of authentication method */
	0x00, 0x50, 0xf2, 0x01	/* authentication */
};

UCHAR CipherWpa2Template[] = {
	0x30,			/* RSN IE */
	0x14,			/* Length */
	0x01, 0x00,		/* Version */
	0x00, 0x0f, 0xac, 0x02,	/* group cipher, TKIP */
	0x01, 0x00,		/* number of pairwise */
	0x00, 0x0f, 0xac, 0x02,	/* unicast */
	0x01, 0x00,		/* number of authentication method */
	0x00, 0x0f, 0xac, 0x02,	/* authentication */
	0x00, 0x00,		/* RSN capability */
};


/*
 *==========================================================================
 * Description:
 *      Association timeout procedure. After association timeout, this function
 *	will be called and it will put a message into the MLME queue
 *Parameters:
 *	Standard timer parameters
 *
 *IRQL = DISPATCH_LEVEL
 *
 *==========================================================================
 */
VOID AssocTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	PTIMER_FUNC_CONTEXT pContext = (PTIMER_FUNC_CONTEXT)FunctionContext;
	RTMP_ADAPTER *pAd = pContext->pAd;
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("ASSOC - enqueue MT2_ASSOC_TIMEOUT\n"));
#endif /* RELEASE_EXCLUDE */

	/* Do nothing if the driver is starting halt state. */
	/* This might happen when timer already been fired before cancel timer with mlmehalt */
	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_HALT_IN_PROGRESS | fRTMP_ADAPTER_NIC_NOT_EXIST))
		return;

	MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE, MT2_ASSOC_TIMEOUT, 0, NULL, 0, pContext->wdev);
	RTMP_MLME_HANDLER(pAd);
}

/*
 *	==========================================================================
 *	Description:
 *		Reassociation timeout procedure. After reassociation timeout, this
 *		function will be called and put a message into the MLME queue
 *	Parameters:
 *		Standard timer parameters
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID ReassocTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	PTIMER_FUNC_CONTEXT pContext = (PTIMER_FUNC_CONTEXT)FunctionContext;
	RTMP_ADAPTER *pAd = pContext->pAd;
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("ASSOC - enqueue MT2_REASSOC_TIMEOUT\n"));
#endif /* RELEASE_EXCLUDE */

	/* Do nothing if the driver is starting halt state. */
	/* This might happen when timer already been fired before cancel timer with mlmehalt */
	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_HALT_IN_PROGRESS | fRTMP_ADAPTER_NIC_NOT_EXIST))
		return;

	MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE, MT2_REASSOC_TIMEOUT, 0, NULL, 0, pContext->wdev);
	RTMP_MLME_HANDLER(pAd);
}

/*
 *	==========================================================================
 *	Description:
 *		Disassociation timeout procedure. After disassociation timeout, this
 *		function will be called and put a message into the MLME queue
 *	Parameters:
 *		Standard timer parameters
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID DisassocTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	PTIMER_FUNC_CONTEXT pContext = (PTIMER_FUNC_CONTEXT)FunctionContext;
	RTMP_ADAPTER *pAd = pContext->pAd;
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("ASSOC - enqueue MT2_DISASSOC_TIMEOUT\n"));
#endif /* RELEASE_EXCLUDE */

	/* Do nothing if the driver is starting halt state. */
	/* This might happen when timer already been fired before cancel timer with mlmehalt */
	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_HALT_IN_PROGRESS | fRTMP_ADAPTER_NIC_NOT_EXIST))
		return;

	MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE, MT2_DISASSOC_TIMEOUT, 0, NULL, 0, pContext->wdev);
	RTMP_MLME_HANDLER(pAd);
}

/*
 *	==========================================================================
 *	Description:
 *		mlme assoc req handling procedure
 *	Parameters:
 *		Adapter - Adapter pointer
 *		Elem - MLME Queue Element
 *	Pre:
 *		the station has been authenticated and the following information is stored in the config
 *			-# SSID
 *			-# supported rates and their length
 *			-# listen interval (Adapter->StaCfg[0].default_listen_count)
 *			-# Transmit power  (Adapter->StaCfg[0].tx_power)
 *	Post  :
 *		-# An association request frame is generated and sent to the air
 *		-# Association timer starts
 *		-# Association state -> ASSOC_WAIT_RSP
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID MlmeAssocReqAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	UCHAR ApAddr[6];
	HEADER_802_11 AssocHdr;
	USHORT ListenIntv;
	ULONG Timeout;
	USHORT CapabilityInfo;
	BOOLEAN TimerCancelled;
	PUCHAR pOutBuffer = NULL;
	NDIS_STATUS NStatus;
	ULONG FrameLen = 0;
	ULONG tmp;
	USHORT VarIesOffset = 0;
	USHORT Status;
#if defined(TXBF_SUPPORT) && defined(VHT_TXBF_SUPPORT)
	UCHAR ucETxBfCap;
#endif /* TXBF_SUPPORT && VHT_TXBF_SUPPORT */
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	MAC_TABLE_ENTRY *pAPEntry = GetAssociatedAPByWdev(pAd, Elem->wdev);
	struct _build_ie_info ie_info = {0};

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	/* Block all authentication request durning WPA block period */
	if (pStaCfg->bBlockAssoc == TRUE) {
		MTWF_LOG	(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("ASSOC - Block Assoc request durning WPA block period!\n"));
		pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
		Status = MLME_STATE_MACHINE_REJECT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_ASSOC_CONF, 2,
							&Status, 0, wdev);
	}
	/* check sanity first */
	else if (MlmeAssocReqSanity(pAd, Elem->Msg, Elem->MsgLen, ApAddr, &CapabilityInfo, &Timeout, &ListenIntv)) {
		/*for dhcp,issue ,wpa_supplicant ioctl too fast , at link_up, it will add key before driver remove key  */
		RTMPWPARemoveAllKeys(pAd, wdev);
		RTMPCancelTimer(&pStaCfg->MlmeAux.AssocTimer, &TimerCancelled);
		COPY_MAC_ADDR(pStaCfg->MlmeAux.Bssid, ApAddr);
		/* Get an unused nonpaged memory */
		NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);

		if (NStatus != NDIS_STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("ASSOC - MlmeAssocReqAction() allocate memory failed\n"));
			pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
			Status = MLME_FAIL_NO_RESOURCE;
			MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE,
								MT2_ASSOC_CONF, 2, &Status, 0, wdev);
			return;
		}

		/* Add by James 03/06/27 */
		pStaCfg->AssocInfo.Length =
			sizeof(NDIS_802_11_ASSOCIATION_INFORMATION);
		/* Association don't need to report MAC address */
		pStaCfg->AssocInfo.AvailableRequestFixedIEs =
			NDIS_802_11_AI_REQFI_CAPABILITIES | NDIS_802_11_AI_REQFI_LISTENINTERVAL;
		pStaCfg->AssocInfo.RequestFixedIEs.Capabilities = CapabilityInfo;
		pStaCfg->AssocInfo.RequestFixedIEs.ListenInterval = ListenIntv;
		/* Only reassociate need this */
		/*COPY_MAC_ADDR(pStaCfg->AssocInfo.RequestFixedIEs.CurrentAPAddress, ApAddr); */
		pStaCfg->AssocInfo.OffsetRequestIEs = sizeof(NDIS_802_11_ASSOCIATION_INFORMATION);
		NdisZeroMemory(pStaCfg->ReqVarIEs, MAX_VIE_LEN);
		/* First add SSID */
		VarIesOffset = 0;
		NdisMoveMemory(pStaCfg->ReqVarIEs + VarIesOffset, &SsidIe, 1);
		VarIesOffset += 1;
		NdisMoveMemory(pStaCfg->ReqVarIEs + VarIesOffset, &pStaCfg->MlmeAux.SsidLen, 1);
		VarIesOffset += 1;
		NdisMoveMemory(pStaCfg->ReqVarIEs + VarIesOffset, pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen);
		VarIesOffset += pStaCfg->MlmeAux.SsidLen;
		/* Second add Supported rates */
		NdisMoveMemory(pStaCfg->ReqVarIEs + VarIesOffset, &SupRateIe, 1);
		VarIesOffset += 1;
		NdisMoveMemory(pStaCfg->ReqVarIEs + VarIesOffset, &pStaCfg->MlmeAux.SupRateLen, 1);
		VarIesOffset += 1;
		NdisMoveMemory(pStaCfg->ReqVarIEs + VarIesOffset, pStaCfg->MlmeAux.SupRate, pStaCfg->MlmeAux.SupRateLen);
		VarIesOffset += pStaCfg->MlmeAux.SupRateLen;
		/* End Add by James */
#if 0

		/*
		 *  CapabilityInfo already sync value with AP in PeerBeaconAtJoinAction.
		 *  We don't need to do below action here.
		 */
		if ((wdev->channel > 14) &&
			(pAd->CommonCfg.bIEEE80211H == TRUE))
			CapabilityInfo |= 0x0100;

#endif

		/*
		 *  CapabilityInfo already sync value with AP in PeerBeaconAtJoinAction.
		 *  But we need to clean Spectrum Management bit here, if we disable bIEEE80211H in infra sta
		 */
		if (!((wdev->channel > 14) &&
			  (pAd->CommonCfg.bIEEE80211H == TRUE)))
			CapabilityInfo &= (~0x0100);

		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ASSOC - Send ASSOC request...\n"));
		MgtMacHeaderInit(pAd, &AssocHdr, SUBTYPE_ASSOC_REQ, 0, ApAddr,
						 pStaCfg->wdev.if_addr,
						 ApAddr);
		/* Build basic frame first */
		MakeOutgoingFrame(pOutBuffer, &FrameLen,
						  sizeof(HEADER_802_11), &AssocHdr,
						  2, &CapabilityInfo,
						  2, &ListenIntv,
						  1, &SsidIe,
						  1, &pStaCfg->MlmeAux.SsidLen,
						  pStaCfg->MlmeAux.SsidLen, pStaCfg->MlmeAux.Ssid,
						  1, &SupRateIe,
						  1, &pStaCfg->MlmeAux.SupRateLen,
						  pStaCfg->MlmeAux.SupRateLen, pStaCfg->MlmeAux.SupRate,
						  END_OF_ARGS);

		if (pStaCfg->MlmeAux.ExtRateLen != 0) {
			MakeOutgoingFrame(pOutBuffer + FrameLen, &tmp,
							  1, &ExtRateIe,
							  1, &pStaCfg->MlmeAux.ExtRateLen,
							  pStaCfg->MlmeAux.ExtRateLen,
							  pStaCfg->MlmeAux.ExtRate, END_OF_ARGS);
			FrameLen += tmp;
		}

#ifdef DOT11R_FT_SUPPORT

		/* Add MDIE if we are connection to DOT11R AP */
		if (pStaCfg->Dot11RCommInfo.bFtSupport &&
			pStaCfg->MlmeAux.MdIeInfo.Len) {
			/* MDIE */
			FT_InsertMdIE(pAd, pOutBuffer + FrameLen, &FrameLen,
						  pStaCfg->MlmeAux.MdIeInfo.MdId,
						  pStaCfg->MlmeAux.MdIeInfo.FtCapPlc);
		}

#endif /* DOT11R_FT_SUPPORT */
#ifdef DOT11_N_SUPPORT

		/* HT */
		if ((pStaCfg->MlmeAux.HtCapabilityLen > 0)
			&& WMODE_CAP_N(wdev->PhyMode)) {
			ULONG TmpLen;
			UCHAR HtLen, BROADCOM[4] = { 0x0, 0x90, 0x4c, 0x33 };
			PHT_CAPABILITY_IE pHtCapability;
#ifdef DOT11_VHT_AC
			struct _build_ie_info vht_ie_info;
#endif /* DOT11_VHT_AC */
#ifdef RT_BIG_ENDIAN
			HT_CAPABILITY_IE HtCapabilityTmp;

			NdisZeroMemory(&HtCapabilityTmp, sizeof(HT_CAPABILITY_IE));
			NdisMoveMemory(&HtCapabilityTmp, &pStaCfg->MlmeAux.HtCapability, pStaCfg->MlmeAux.HtCapabilityLen);
			*(USHORT *) (&HtCapabilityTmp.HtCapInfo) = SWAP16(*(USHORT *) (&HtCapabilityTmp.HtCapInfo));
			*(USHORT *) (&HtCapabilityTmp.ExtHtCapInfo) = SWAP16(*(USHORT *) (&HtCapabilityTmp.ExtHtCapInfo));
			pHtCapability = &HtCapabilityTmp;
#else
			pHtCapability = &pStaCfg->MlmeAux.HtCapability;
#endif

			if (pStaCfg->StaActive.SupportedPhyInfo.bPreNHt == TRUE) {
				HtLen = SIZE_HT_CAP_IE + 4;
				MakeOutgoingFrame(pOutBuffer + FrameLen,
								  &TmpLen, 1, &WpaIe, 1, &HtLen,
								  4, &BROADCOM[0],
								  pStaCfg->MlmeAux.HtCapabilityLen,
								  pHtCapability, END_OF_ARGS);
			} else {
				MakeOutgoingFrame(pOutBuffer + FrameLen,
								  &TmpLen, 1, &HtCapIe, 1,
								  &pStaCfg->MlmeAux.HtCapabilityLen,
								  pStaCfg->MlmeAux.HtCapabilityLen,
								  pHtCapability, END_OF_ARGS);
			}

			FrameLen += TmpLen;
#ifdef DOT11_VHT_AC
			vht_ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
			vht_ie_info.frame_subtype = SUBTYPE_ASSOC_REQ;
			vht_ie_info.channel = pStaCfg->MlmeAux.Channel;
			vht_ie_info.phy_mode = wdev->PhyMode;
			vht_ie_info.wdev = wdev;
#if defined(TXBF_SUPPORT) && defined(VHT_TXBF_SUPPORT)
			ucETxBfCap = pAd->CommonCfg.ETxBfEnCond;

			if (HcIsBfCapSupport(wdev) == FALSE)
				pAd->CommonCfg.ETxBfEnCond = 0;

#endif /* TXBF_SUPPORT && VHT_TXBF_SUPPORT */
			FrameLen += build_vht_ies(pAd, &vht_ie_info);
#if defined(TXBF_SUPPORT) && defined(VHT_TXBF_SUPPORT)
			pAd->CommonCfg.ETxBfEnCond = ucETxBfCap;
#endif /* TXBF_SUPPORT && VHT_TXBF_SUPPORT */
#endif /* DOT11_VHT_AC */
		}

#endif /* DOT11_N_SUPPORT */

		ie_info.frame_subtype = SUBTYPE_ASSOC_REQ;
		ie_info.channel = pStaCfg->MlmeAux.Channel;
		ie_info.phy_mode = wdev->PhyMode;
		ie_info.wdev = wdev;
		ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
		FrameLen += build_extended_cap_ie(pAd, &ie_info);

		/* add Ralink proprietary IE to inform AP this STA is going to use AGGREGATION or PIGGY-BACK+AGGREGATION */
		/* Case I: (Aggregation + Piggy-Back) */
		/* 1. user enable aggregation, AND */
		/* 2. Mac support piggy-back */
		/* 3. AP annouces it's PIGGY-BACK+AGGREGATION-capable in BEACON */
		/* Case II: (Aggregation) */
		/* 1. user enable aggregation, AND */
		/* 2. AP annouces it's AGGREGATION-capable in BEACON */
		FrameLen += build_vendor_ie(pAd, wdev, (pOutBuffer + FrameLen));

		ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
		FrameLen += build_wmm_cap_ie(pAd, &ie_info);

		/*
		 *	Let WPA(#221) Element ID on the end of this association frame.
		 *	Otherwise some AP will fail on parsing Element ID and set status fail on Assoc Rsp.
		 *	For example: Put Vendor Specific IE on the front of WPA IE.
		 *	This happens on AP (Model No:Linksys WRK54G)
		 */
		if ((pAPEntry)
			&& (IS_AKM_WPA_CAPABILITY(pAPEntry->SecConfig.AKMMap)
#ifdef WAPI_SUPPORT
				|| IS_AKM_WAICERT(pAPEntry->SecConfig.AKMMap)
				|| IS_AKM_WPIPSK(pAPEntry->SecConfig.AKMMap)
#endif /* WAPI_SUPPORT */
			   )
#ifdef WSC_STA_SUPPORT
			&& ((wdev->WscControl.WscConfMode == WSC_DISABLE) ||
				((wdev->WscControl.WscConfMode != WSC_DISABLE) &&
				 !(wdev->WscControl.bWscTrigger
#ifdef STA_EASY_CONFIG_SETUP
				   || wdev->EasyConfigInfo.bDoAutoWps
#endif /* STA_EASY_CONFIG_SETUP */
				  )))
#endif /* WSC_STA_SUPPORT */
		   ) {
#ifdef WPA_SUPPLICANT_SUPPORT

			if (pStaCfg->wpa_supplicant_info.bRSN_IE_FromWpaSupplicant == FALSE)
#endif /* WPA_SUPPLICANT_SUPPORT */
			{
#ifdef WPA_SUPPLICANT_SUPPORT

				if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) {
					return; /*do nothing, RSNE content should be from wpa_supplicant */
				} else
#endif /* WPA_SUPPLICANT_SUPPORT */
					WPAMakeRSNIE(wdev->wdev_type, &pAPEntry->SecConfig);

				/* Check for WPA PMK cache list */
				if (IS_AKM_WPA2(pAPEntry->SecConfig.AKMMap)) {
					INT idx;
					BOOLEAN FoundPMK = FALSE;

					/*	Search chched PMKID, append it if existed */
					for (idx = 0; idx < PMKID_NO; idx++) {
						if (NdisEqualMemory(ApAddr, &pStaCfg->SavedPMK[idx].BSSID, 6)) {
							FoundPMK = TRUE;
							break;
						}
					}

#ifdef WPA_SUPPLICANT_SUPPORT

					/*
					 *  When AuthMode is WPA2-Enterprise and AP reboot or STA lost AP,
					 *  AP would not do PMK cache with STA after STA re-connect to AP again.
					 *  In this case, driver doesn't need to send PMKID to AP and WpaSupplicant.
					 */
					if (NdisEqualMemory(pStaCfg->MlmeAux.Bssid, pStaCfg->LastBssid, MAC_ADDR_LEN))
						FoundPMK = FALSE;

#endif /* WPA_SUPPLICANT_SUPPORT */

					if (FoundPMK) {
						/* Set PMK number */
						UCHAR *ptr = pStaCfg->RSN_IE;
						*(PUSHORT) & pStaCfg->RSN_IE[pStaCfg->RSNIE_Len] = 1;
						ptr = ptr + pStaCfg->RSNIE_Len + 2;
						NdisMoveMemory(ptr, &pStaCfg->SavedPMK[idx].PMKID, 16);
						pStaCfg->RSNIE_Len += 18;
					}
				}
			}

#ifdef WPA_SUPPLICANT_SUPPORT

			/*
			 *	Can not use SIOCSIWGENIE definition, it is used in wireless.h
			 *	We will not see the definition in MODULE.
			 *	The definition can be saw in UTIL and NETIF.
			 */
			if ((pStaCfg->wpa_supplicant_info.WpaSupplicantUP & WPA_SUPPLICANT_ENABLE)
				&& (pStaCfg->wpa_supplicant_info.bRSN_IE_FromWpaSupplicant == TRUE))
				;
			else
#endif /* WPA_SUPPLICANT_SUPPORT */
			{
				ULONG TempLen = 0;
				CHAR rsne_idx = 0;

				for (rsne_idx = 0; rsne_idx < SEC_RSNIE_NUM; rsne_idx++) {
					if (pAPEntry->SecConfig.RSNE_Type[rsne_idx] == SEC_RSNIE_NONE)
						continue;

					MakeOutgoingFrame(pOutBuffer + FrameLen, &TempLen,
									  1, &pAPEntry->SecConfig.RSNE_EID[rsne_idx][0],
									  1, &pAPEntry->SecConfig.RSNE_Len[rsne_idx],
									  pAPEntry->SecConfig.RSNE_Len[rsne_idx], &pAPEntry->SecConfig.RSNE_Content[rsne_idx][0],
									  END_OF_ARGS);
					FrameLen += TempLen;
				}
			}

#ifdef WPA_SUPPLICANT_SUPPORT

			/*
			 *	Can not use SIOCSIWGENIE definition, it is used in wireless.h
			 *	We will not see the definition in MODULE.
			 *	The definition can be saw in UTIL and NETIF.
			 */
			if (((pStaCfg->wpa_supplicant_info.WpaSupplicantUP & 0x7F) !=
				 WPA_SUPPLICANT_ENABLE)
				|| (pStaCfg->wpa_supplicant_info.bRSN_IE_FromWpaSupplicant == FALSE))
#endif /* WPA_SUPPLICANT_SUPPORT */
			{
				CHAR rsne_idx = 0;

				for (rsne_idx = 0; rsne_idx < SEC_RSNIE_NUM; rsne_idx++) {
					if (pAPEntry->SecConfig.RSNE_Type[rsne_idx] == SEC_RSNIE_NONE)
						continue;

					/* Append Variable IE */
					NdisMoveMemory(pStaCfg->ReqVarIEs + VarIesOffset, &pAPEntry->SecConfig.RSNE_EID[rsne_idx][0], 1);
					VarIesOffset += 1;
					NdisMoveMemory(pStaCfg->ReqVarIEs + VarIesOffset, &pAPEntry->SecConfig.RSNE_Len[rsne_idx], 1);
					VarIesOffset += 1;
					NdisMoveMemory(pStaCfg->ReqVarIEs + VarIesOffset, &pAPEntry->SecConfig.RSNE_Content[rsne_idx][0], pAPEntry->SecConfig.RSNE_Len[rsne_idx]);
					VarIesOffset += pStaCfg->RSNIE_Len;
					/* Set Variable IEs Length */
					pStaCfg->ReqVarIELen = VarIesOffset;
					break;
				}
			}
		}

		ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
		FrameLen +=  build_extra_ie(pAd, &ie_info);

#ifdef P2P_SUPPORT
		if (P2P_INF_ON(pAd)) {
			/* Check the total P2P Attribue IE in this AP.s */
			if (pAd->P2pCfg.P2pManagedParm.TotalNumOfP2pAttribute > 0) {
				PUCHAR	ptr;

				ptr = pOutBuffer + FrameLen;
				P2pMakeP2pIE(pAd, SUBTYPE_ASSOC_REQ, ptr, &tmp);
				FrameLen += tmp;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("ASSOCREQ - Insert P2P IE in case for managed AP to recognize me\n"));
			}
		}

#endif /* P2P_SUPPORT */
#ifdef WSC_INCLUDED
		ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
		FrameLen += build_wsc_ie(pAd, &ie_info);
#endif /* WSC_INCLUDED */
#ifdef WFD_SUPPORT
#ifdef RT_CFG80211_SUPPORT

		if (pStaCfg->WfdCfg.bSuppInsertWfdIe) {
			ULONG	WfdIeLen, WfdIeBitmap;
			PUCHAR	ptr;

			ptr = pOutBuffer + FrameLen;
			WfdIeBitmap = (0x1 << SUBID_WFD_DEVICE_INFO) | (0x1 << SUBID_WFD_ASSOCIATED_BSSID) |
						  (0x1 << SUBID_WFD_COUPLED_SINK_INFO);
			WfdMakeWfdIE(pAd, WfdIeBitmap, ptr, &WfdIeLen);
			FrameLen += WfdIeLen;
		}

#endif /* RT_CFG80211_SUPPORT */
#endif /* WFD_SUPPORT */
		MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
		MlmeFreeMemory(pOutBuffer);
		RTMPSetTimer(&pStaCfg->MlmeAux.AssocTimer, Timeout);
		pStaCfg->AssocMachine.CurrState = ASSOC_WAIT_RSP;
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("ASSOC - MlmeAssocReqAction() sanity check failed. BUG!!!!!!\n"));
		pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
		Status = MLME_INVALID_FORMAT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_ASSOC_CONF, 2,
							&Status, 0, wdev);
	}
}

/*
 *	==========================================================================
 *	Description:
 *		mlme reassoc req handling procedure
 *	Parameters:
 *		Elem -
 *	Pre:
 *		-# SSID  (Adapter->StaCfg[0].ssid[])
 *		-# BSSID (AP address, Adapter->StaCfg[0].bssid)
 *		-# Supported rates (Adapter->StaCfg[0].supported_rates[])
 *		-# Supported rates length (Adapter->StaCfg[0].supported_rates_len)
 *		-# Tx power (Adapter->StaCfg[0].tx_power)
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID MlmeReassocReqAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	UCHAR ApAddr[6];
	HEADER_802_11 ReassocHdr;
	UCHAR WmeIe[9] = {IE_VENDOR_SPECIFIC, 0x07, 0x00, 0x50, 0xf2, 0x02, 0x00, 0x01, 0x00};
	USHORT CapabilityInfo, ListenIntv;
	ULONG Timeout;
	ULONG FrameLen = 0;
	BOOLEAN TimerCancelled;
	NDIS_STATUS NStatus;
	ULONG tmp;
	PUCHAR pOutBuffer = NULL;
	USHORT Status;
#if defined(TXBF_SUPPORT) && defined(VHT_TXBF_SUPPORT)
	UCHAR ucETxBfCap;
#endif /* TXBF_SUPPORT && VHT_TXBF_SUPPORT */
	struct wifi_dev *Wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	struct _build_ie_info ie_info = {0};

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	/* Block all authentication request durning WPA block period */
	if (pStaCfg->bBlockAssoc == TRUE) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("ASSOC - Block ReAssoc request durning WPA block period!\n"));
		pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
		Status = MLME_STATE_MACHINE_REJECT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_REASSOC_CONF, 2, &Status, 0, Wdev);
	}
	/* the parameters are the same as the association */
	else if (MlmeAssocReqSanity(pAd, Elem->Msg, Elem->MsgLen, ApAddr, &CapabilityInfo, &Timeout, &ListenIntv)) {
		/*for dhcp,issue ,wpa_supplicant ioctl too fast , at link_up, it will add key before driver remove key  */
		RTMPWPARemoveAllKeys(pAd, Wdev);
		RTMPCancelTimer(&pStaCfg->MlmeAux.ReassocTimer, &TimerCancelled);
		NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);	/*Get an unused nonpaged memory */

		if (NStatus != NDIS_STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("ASSOC - MlmeReassocReqAction() allocate memory failed\n"));
			pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
			Status = MLME_FAIL_NO_RESOURCE;
			MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE,
								MT2_REASSOC_CONF, 2, &Status, 0, Wdev);
			return;
		}

		COPY_MAC_ADDR(pStaCfg->MlmeAux.Bssid, ApAddr);
		/* make frame, use bssid as the AP address?? */
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("ASSOC - Send RE-ASSOC request...\n"));
		MgtMacHeaderInit(pAd, &ReassocHdr, SUBTYPE_REASSOC_REQ, 0, ApAddr,
						 pStaCfg->wdev.if_addr,
						 ApAddr);
		MakeOutgoingFrame(pOutBuffer, &FrameLen, sizeof(HEADER_802_11),
						  &ReassocHdr, 2, &CapabilityInfo, 2,
						  &ListenIntv, MAC_ADDR_LEN, ApAddr, 1, &SsidIe,
						  1, &pStaCfg->MlmeAux.SsidLen,
						  pStaCfg->MlmeAux.SsidLen, pStaCfg->MlmeAux.Ssid, 1,
						  &SupRateIe, 1, &pStaCfg->MlmeAux.SupRateLen,
						  pStaCfg->MlmeAux.SupRateLen, pStaCfg->MlmeAux.SupRate,
						  END_OF_ARGS);

		if (pStaCfg->MlmeAux.ExtRateLen != 0) {
			MakeOutgoingFrame(pOutBuffer + FrameLen, &tmp,
							  1, &ExtRateIe,
							  1, &pStaCfg->MlmeAux.ExtRateLen,
							  pStaCfg->MlmeAux.ExtRateLen,
							  pStaCfg->MlmeAux.ExtRate, END_OF_ARGS);
			FrameLen += tmp;
		}

#ifdef DOT11R_FT_SUPPORT

		/* Add MDIE if we are connection to DOT11R AP */
		if (pStaCfg->Dot11RCommInfo.bFtSupport &&
			pStaCfg->MlmeAux.MdIeInfo.Len) {
			PUINT8 mdie_ptr;
			UINT mdie_len = 0;
			/* MDIE */
			mdie_ptr = pOutBuffer + FrameLen;
			mdie_len = 5;
			FT_InsertMdIE(pAd, pOutBuffer + FrameLen, &FrameLen,
						  pStaCfg->MlmeAux.MdIeInfo.MdId,
						  pStaCfg->MlmeAux.MdIeInfo.FtCapPlc);

			/* Indicate the FT procedure */
			if (pStaCfg->Dot11RCommInfo.bInMobilityDomain &&
				pStaCfg->WepStatus != Ndis802_11WEPDisabled) {
				UINT8 FtIeLen = 0;
				PMAC_TABLE_ENTRY pEntry;
				FT_MIC_CTR_FIELD mic_ctr;
				PUINT8 rsnie_ptr;
				UINT rsnie_len = 0;
				PUINT8 ftie_ptr;
				UINT ftie_len = 0;
				UINT8 ft_mic[16];

				pEntry = &pAd->MacTab.Content[MCAST_WCID];
				/* Insert RSNIE[PMK-R1-NAME] */
				rsnie_ptr = pOutBuffer + FrameLen;
				rsnie_len = 2 + pStaCfg->RSNIE_Len + 2 + LEN_PMK_NAME;
				RTMPInsertRSNIE(pOutBuffer + FrameLen,
								&FrameLen,
								pStaCfg->RSN_IE,
								pStaCfg->RSNIE_Len,
								pEntry->FT_PMK_R1_NAME,
								LEN_PMK_NAME);
				/* Insert FTIE[MIC, ANONCE, SNONCE, R1KH-ID, R0KH-ID] */
				FtIeLen = sizeof(FT_FTIE) +
						  (2 + MAC_ADDR_LEN) +
						  (2 + pStaCfg->Dot11RCommInfo.R0khIdLen);
				ftie_ptr = pOutBuffer + FrameLen;
				ftie_len = (2 + FtIeLen);
				mic_ctr.field.IECnt = 3;
				NdisZeroMemory(ft_mic, 16);
				FT_InsertFTIE(pAd,
							  pOutBuffer + FrameLen,
							  &FrameLen,
							  FtIeLen,
							  mic_ctr,
							  ft_mic,
							  pEntry->ANonce, pEntry->SNonce);
				FT_FTIE_InsertKhIdSubIE(pAd,
										pOutBuffer + FrameLen,
										&FrameLen,
										FT_R1KH_ID,
										pStaCfg->MlmeAux.Bssid,
										MAC_ADDR_LEN);
				FT_FTIE_InsertKhIdSubIE(pAd,
										pOutBuffer + FrameLen,
										&FrameLen,
										FT_R0KH_ID,
										&pStaCfg->Dot11RCommInfo.R0khId[0],
										pStaCfg->Dot11RCommInfo.R0khIdLen);

				/* RIC-Request */
				if (pStaCfg->MlmeAux.MdIeInfo.FtCapPlc.field.RsrReqCap
					&& pStaCfg->Dot11RCommInfo.bSupportResource) {
				}

				/* Calculate MIC */
				if (mic_ctr.field.IECnt) {
					UINT8 ft_mic[16];
					PFT_FTIE pFtIe;

					FT_CalculateMIC(pAd->CurrentAddress,
									pStaCfg->MlmeAux.Bssid,
									pEntry->PTK,
									5,
									rsnie_ptr,
									rsnie_len,
									mdie_ptr,
									mdie_len,
									ftie_ptr,
									ftie_len,
									NULL, 0, ft_mic);
					/* Update the MIC field of FTIE */
					pFtIe = (PFT_FTIE) (ftie_ptr + 2);
					NdisMoveMemory(pFtIe->MIC, ft_mic, 16);
				}
			}
		}

#endif /* DOT11R_FT_SUPPORT */

		if (pStaCfg->MlmeAux.APEdcaParm.bValid) {
			if (pStaCfg->wdev.UapsdInfo.bAPSDCapable
				&& pStaCfg->MlmeAux.APEdcaParm.bAPSDCapable) {
				QBSS_STA_INFO_PARM QosInfo;

				NdisZeroMemory(&QosInfo, sizeof(QBSS_STA_INFO_PARM));
				QosInfo.UAPSD_AC_BE = pAd->CommonCfg.bAPSDAC_BE;
				QosInfo.UAPSD_AC_BK = pAd->CommonCfg.bAPSDAC_BK;
				QosInfo.UAPSD_AC_VI = pAd->CommonCfg.bAPSDAC_VI;
				QosInfo.UAPSD_AC_VO = pAd->CommonCfg.bAPSDAC_VO;
				QosInfo.MaxSPLength = pAd->CommonCfg.MaxSPLength;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("uapsd> MaxSPLength = %d!\n", QosInfo.MaxSPLength));
				WmeIe[8] |= *(PUCHAR)&QosInfo;
			}

			MakeOutgoingFrame(pOutBuffer + FrameLen, &tmp,
							  9, &WmeIe[0], END_OF_ARGS);
			FrameLen += tmp;
		}

#ifdef DOT11_N_SUPPORT

		/* HT */
		if ((pStaCfg->MlmeAux.HtCapabilityLen > 0)
			&& WMODE_CAP_N(Wdev->PhyMode)) {
			ULONG TmpLen;
			UCHAR HtLen;
			UCHAR BROADCOM[4] = {0x0, 0x90, 0x4c, 0x33};
			PHT_CAPABILITY_IE pHtCapability;
#ifdef DOT11_VHT_AC
			struct _build_ie_info vht_ie_info;
#endif /* DOT11_VHT_AC */
#ifdef RT_BIG_ENDIAN
			HT_CAPABILITY_IE HtCapabilityTmp;

			NdisZeroMemory(&HtCapabilityTmp, sizeof(HT_CAPABILITY_IE));
			NdisMoveMemory(&HtCapabilityTmp, &pStaCfg->MlmeAux.HtCapability, pStaCfg->MlmeAux.HtCapabilityLen);
			*(USHORT *) (&HtCapabilityTmp.HtCapInfo) = SWAP16(*(USHORT *) (&HtCapabilityTmp.HtCapInfo));
			*(USHORT *) (&HtCapabilityTmp.ExtHtCapInfo) = SWAP16(*(USHORT *) (&HtCapabilityTmp.ExtHtCapInfo));
			pHtCapability = &HtCapabilityTmp;
#else
			pHtCapability = &pStaCfg->MlmeAux.HtCapability;
#endif

			if (pStaCfg->StaActive.SupportedPhyInfo.bPreNHt == TRUE) {
				HtLen = SIZE_HT_CAP_IE + 4;
				MakeOutgoingFrame(pOutBuffer + FrameLen,
								  &TmpLen, 1, &WpaIe, 1, &HtLen,
								  4, &BROADCOM[0],
								  pStaCfg->MlmeAux.HtCapabilityLen,
								  pHtCapability, END_OF_ARGS);
			} else {
				MakeOutgoingFrame(pOutBuffer + FrameLen,
								  &TmpLen, 1, &HtCapIe, 1,
								  &pStaCfg->MlmeAux.HtCapabilityLen,
								  pStaCfg->MlmeAux.HtCapabilityLen,
								  pHtCapability, END_OF_ARGS);
			}

			FrameLen += TmpLen;
#ifdef DOT11_VHT_AC
			vht_ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
			vht_ie_info.frame_subtype = SUBTYPE_ASSOC_REQ;
			vht_ie_info.channel = pStaCfg->MlmeAux.Channel;
			vht_ie_info.phy_mode = Wdev->PhyMode;
			vht_ie_info.wdev = Wdev;
#if defined(TXBF_SUPPORT) && defined(VHT_TXBF_SUPPORT)
			ucETxBfCap = pAd->CommonCfg.ETxBfEnCond;

			if (HcIsBfCapSupport(Wdev) == FALSE)
				pAd->CommonCfg.ETxBfEnCond = 0;

#endif /* TXBF_SUPPORT && VHT_TXBF_SUPPORT */
			FrameLen += build_vht_ies(pAd, &vht_ie_info);
#if defined(TXBF_SUPPORT) && defined(VHT_TXBF_SUPPORT)
			pAd->CommonCfg.ETxBfEnCond = ucETxBfCap;
#endif /* TXBF_SUPPORT && VHT_TXBF_SUPPORT */
#endif /* DOT11_VHT_AC */
		}

#endif /* DOT11_N_SUPPORT */

		ie_info.frame_subtype = SUBTYPE_ASSOC_REQ;
		ie_info.channel = pStaCfg->MlmeAux.Channel;
		ie_info.phy_mode = Wdev->PhyMode;
		ie_info.wdev = Wdev;
		ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
		FrameLen += build_extended_cap_ie(pAd, &ie_info);

		/* add Ralink proprietary IE to inform AP this STA is going to use AGGREGATION or PIGGY-BACK+AGGREGATION */
		/* Case I: (Aggregation + Piggy-Back) */
		/* 1. user enable aggregation, AND */
		/* 2. Mac support piggy-back */
		/* 3. AP annouces it's PIGGY-BACK+AGGREGATION-capable in BEACON */
		/* Case II: (Aggregation) */
		/* 1. user enable aggregation, AND */
		/* 2. AP annouces it's AGGREGATION-capable in BEACON */
		FrameLen += build_vendor_ie(pAd, Wdev, (pOutBuffer + FrameLen));

		ie_info.frame_buf = (UCHAR *)(pOutBuffer + FrameLen);
		FrameLen += build_wmm_cap_ie(pAd, &ie_info);

#ifdef WFD_SUPPORT
#ifdef RT_CFG80211_SUPPORT

		if (pStaCfg->WfdCfg.bSuppInsertWfdIe) {
			ULONG	WfdIeLen, WfdIeBitmap;
			PUCHAR	ptr;

			ptr = pOutBuffer + FrameLen;
			WfdIeBitmap = (0x1 << SUBID_WFD_DEVICE_INFO) | (0x1 << SUBID_WFD_ASSOCIATED_BSSID) |
						  (0x1 << SUBID_WFD_COUPLED_SINK_INFO);
			WfdMakeWfdIE(pAd, WfdIeBitmap, ptr, &WfdIeLen);
			FrameLen += WfdIeLen;
		}

#endif /* RT_CFG80211_SUPPORT */
#endif /* WFD_SUPPORT */
		MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
		MlmeFreeMemory(pOutBuffer);
		RTMPSetTimer(&pStaCfg->MlmeAux.ReassocTimer, Timeout * 2);	/* in mSec */
		pStaCfg->AssocMachine.CurrState = REASSOC_WAIT_RSP;
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("ASSOC - MlmeReassocReqAction() sanity check failed. BUG!!!!\n"));
		pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
		Status = MLME_INVALID_FORMAT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_REASSOC_CONF, 2,
							&Status, 0, Wdev);
	}
}

/*
 *	==========================================================================
 *	Description:
 *		Upper layer issues disassoc request
 *	Parameters:
 *		Elem -
 *
 *	IRQL = PASSIVE_LEVEL
 *
 *	==========================================================================
 */
VOID MlmeDisassocReqAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	PMLME_DISASSOC_REQ_STRUCT pDisassocReq;
	HEADER_802_11 DisassocHdr;
	PHEADER_802_11 pDisassocHdr;
	PUCHAR pOutBuffer = NULL;
	ULONG FrameLen = 0;
	NDIS_STATUS NStatus;
	BOOLEAN TimerCancelled;
	ULONG Timeout = 500;
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef MT76XX_BTCOEX_SUPPORT
	/* coex hook disconnect */
	MLMEHook(pAd, WLAN_DISCONNECT, QueryHashID(pAd, pAd->CommonCfg.Bssid, FALSE));
#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef DOT11Z_TDLS_SUPPORT

	if (IS_TDLS_SUPPORT(pAd)) {
		if (pStaCfg->bRadio == TRUE)
			TDLS_LinkTearDown(pAd, TRUE);
		else {
			UCHAR		idx;
			BOOLEAN		TimerCancelled;
			PRT_802_11_TDLS	pTDLS = NULL;

			/* tear down tdls table entry */
			for (idx = 0; idx < MAX_NUM_OF_TDLS_ENTRY; idx++) {
				pTDLS = &pStaCfg->TdlsInfo.TDLSEntry[idx];

				if (pTDLS->Valid && (pTDLS->Status >= TDLS_MODE_CONNECTED)) {
					pTDLS->Status = TDLS_MODE_NONE;
					pTDLS->Valid	= FALSE;
					pTDLS->Token = 0;
					RTMPCancelTimer(&pTDLS->Timer, &TimerCancelled);

					if (!VALID_WCID(pTDLS->MacTabMatchWCID))
						return;

					MacTableDeleteEntry(pAd, pTDLS->MacTabMatchWCID, pTDLS->MacAddr);
				} else if (pTDLS->Valid) {
					pTDLS->Status = TDLS_MODE_NONE;
					pTDLS->Valid	= FALSE;
					pTDLS->Token = 0;
					RTMPCancelTimer(&pTDLS->Timer, &TimerCancelled);
				}
			}
		}
	}

#endif /* DOT11Z_TDLS_SUPPORT */
	/* skip sanity check */
	pDisassocReq = (PMLME_DISASSOC_REQ_STRUCT) (Elem->Msg);
	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);	/*Get an unused nonpaged memory */

	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("ASSOC - MlmeDisassocReqAction() allocate memory failed\n"));
		pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
		Status = MLME_FAIL_NO_RESOURCE;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_DISASSOC_CONF, 2,
							&Status, 0, Elem->wdev);
		return;
	}

#ifdef WMM_ACM_SUPPORT
	ACMP_StationDelete(pAd, ACMR_STA_ENTRY_GET(pAd, pAd->CommonCfg.Bssid));
#endif /* WMM_ACM_SUPPORT */
#ifdef WAPI_SUPPORT
	WAPI_InternalCmdAction(pAd,
						   pStaCfg->wdev.SecConfig.AKMMap,
						   BSS0, pDisassocReq->Addr, WAI_MLME_DISCONNECT);
#endif /* WAPI_SUPPORT */
	RTMPCancelTimer(&pStaCfg->MlmeAux.DisassocTimer, &TimerCancelled);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("ASSOC - Send DISASSOC request[BSSID::%02x:%02x:%02x:%02x:%02x:%02x (Reason=%d)\n",
			  PRINT_MAC(pDisassocReq->Addr), pDisassocReq->Reason));
	MgtMacHeaderInit(pAd, &DisassocHdr, SUBTYPE_DISASSOC, 0, pDisassocReq->Addr,
					 pStaCfg->wdev.if_addr,
					 pDisassocReq->Addr);	/* patch peap ttls switching issue */
	MakeOutgoingFrame(pOutBuffer, &FrameLen,
					  sizeof(HEADER_802_11), &DisassocHdr,
					  2, &pDisassocReq->Reason, END_OF_ARGS);
	MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
	/* To patch Instance and Buffalo(N) AP */
	/* Driver has to send deauth to Instance AP, but Buffalo(N) needs to send disassoc to reset Authenticator's state machine */
	/* Therefore, we send both of them. */
	pDisassocHdr = (PHEADER_802_11) pOutBuffer;
	pDisassocHdr->FC.SubType = SUBTYPE_DEAUTH;
	MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
	MlmeFreeMemory(pOutBuffer);
	pStaCfg->DisassocReason = REASON_DISASSOC_STA_LEAVING;
	COPY_MAC_ADDR(pStaCfg->DisassocSta, pDisassocReq->Addr);
	RTMPSetTimer(&pStaCfg->MlmeAux.DisassocTimer, Timeout);	/* in mSec */
	pStaCfg->AssocMachine.CurrState = DISASSOC_WAIT_RSP;
#ifdef WPA_SUPPLICANT_SUPPORT
#ifndef NATIVE_WPA_SUPPLICANT_SUPPORT

	if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) {
		/*send disassociate event to wpa_supplicant */
		RtmpOSWrielessEventSend(pAd->net_dev, RT_WLAN_EVENT_CUSTOM,
								RT_DISASSOC_EVENT_FLAG, NULL, NULL, 0);
	}

#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif /* WPA_SUPPLICANT_SUPPORT */
	/* mark here because linkdown also call this function */
#if 0
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT
	RtmpOSWrielessEventSend(pAd->net_dev, RT_WLAN_EVENT_CGIWAP, -1, NULL, NULL, 0);
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif
	RTMPSendWirelessEvent(pAd, IW_DISASSOC_EVENT_FLAG, NULL, BSS0, 0);
}

/*
 *	==========================================================================
 *	Description:
 *		peer sends assoc rsp back
 *	Parameters:
 *		Elme - MLME message containing the received frame
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID PeerAssocRspAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	USHORT CapabilityInfo, Status, Aid;
	UCHAR SupRate[MAX_LEN_OF_SUPPORTED_RATES], SupRateLen;
	UCHAR ExtRate[MAX_LEN_OF_SUPPORTED_RATES], ExtRateLen;
	UCHAR Addr2[MAC_ADDR_LEN];
	BOOLEAN TimerCancelled;
	UCHAR CkipFlag;
	EDCA_PARM EdcaParm;
	HT_CAPABILITY_IE HtCapability;
	ADD_HT_INFO_IE AddHtInfo;	/* AP might use this additional ht info IE */
	UCHAR HtCapabilityLen = 0;
	UCHAR AddHtInfoLen;
	UCHAR NewExtChannelOffset = 0xff;
	EXT_CAP_INFO_ELEMENT ExtCapInfo;
	MAC_TABLE_ENTRY *pEntry;
	IE_LISTS *ie_list = NULL;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	os_alloc_mem(pAd, (UCHAR **)&ie_list, sizeof(IE_LISTS));

	if (ie_list == NULL) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s():mem alloc failed!\n", __func__));
		return;
	}

	NdisZeroMemory((UCHAR *)ie_list, sizeof(IE_LISTS));
	os_zero_mem(&EdcaParm, sizeof(EDCA_PARM));

	if (PeerAssocRspSanity(&pStaCfg->wdev, Elem->Msg, Elem->MsgLen,
						   Addr2, &CapabilityInfo, &Status, &Aid, SupRate,
						   &SupRateLen, ExtRate, &ExtRateLen, &HtCapability,
						   &AddHtInfo, &HtCapabilityLen, &AddHtInfoLen,
						   &NewExtChannelOffset, &EdcaParm, &ExtCapInfo,
						   &CkipFlag, ie_list)) {
		/* The frame is for me ? */
		if (MAC_ADDR_EQUAL(Addr2, pStaCfg->MlmeAux.Bssid)) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("%s():ASSOC - receive ASSOC_RSP to me (status=%d)\n", __func__, Status));
			RTMPCancelTimer(&pStaCfg->MlmeAux.AssocTimer, &TimerCancelled);
#ifdef DOT11R_FT_SUPPORT

			if (pStaCfg->Dot11RCommInfo.bFtSupport && pStaCfg->MlmeAux.FtIeInfo.Len) {
				FT_FTIE_INFO *pFtInfo = &pStaCfg->MlmeAux.FtIeInfo;

				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():ASSOC - FTIE\n", __func__));
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("MIC Countrol IECnt: %x\n", pFtInfo->MICCtr.field.IECnt));
				hex_dump("ANonce", pFtInfo->ANonce, 32);
				hex_dump("SNonce", pFtInfo->SNonce, 32);

				if (pFtInfo->R1khIdLen)
					hex_dump("R1KH-ID", pFtInfo->R1khId, pFtInfo->R1khIdLen);

				if (pFtInfo->R0khIdLen)
					hex_dump("R0KH-ID", pFtInfo->R0khId, pFtInfo->R0khIdLen);

				if ((pStaCfg->Dot11RCommInfo.R0khIdLen != pFtInfo->R0khIdLen)
					|| (!NdisEqualMemory(pFtInfo->R0khId, pFtInfo->R0khId,
										 pStaCfg->Dot11RCommInfo.R0khIdLen))) {
					if (pStaCfg->Dot11RCommInfo.bInMobilityDomain)
						Status = MLME_INVALID_FORMAT;
				}
			}

#endif /* DOT11R_FT_SUPPORT */
#ifdef DOT11V_WNM_SUPPORT

			if (ExtCapInfo.BssTransitionManmt == 1)
				pStaCfg->bBSSMantAPSupport = TRUE;

			if (ExtCapInfo.DMSSupport == 1)
				pStaCfg->bDMSAPSupport = TRUE;

#endif /* DOT11V_WNM_SUPPORT */

			if (Status == MLME_SUCCESS) {
				UCHAR MaxSupportedRateIn500Kbps = 0;
				/*
				 *	In roaming case, LinkDown wouldn't be invoked.
				 *	For preventing finding MacTable Hash index malfunction,
				 *	we need to do MacTableDeleteEntry here.
				 */
				pEntry = MacTableLookup2(pAd, Addr2, &pStaCfg->wdev);
				ASSERT(pEntry);

				if (!pEntry)
					goto end;

				MaxSupportedRateIn500Kbps = dot11_max_sup_rate(SupRateLen, &SupRate[0],
											ExtRateLen, &ExtRate[0]);
				/* go to procedure listed on page 376 */
				AssocPostProc(pAd, Addr2, CapabilityInfo, Aid,
							  SupRate, SupRateLen, ExtRate,
							  ExtRateLen, &EdcaParm,
							  ie_list,
							  &HtCapability, HtCapabilityLen,
							  &AddHtInfo,
							  pEntry);
				StaUpdateMacTableEntry(pAd,
									   pEntry,
									   MaxSupportedRateIn500Kbps,
									   &HtCapability,
									   HtCapabilityLen, &AddHtInfo,
									   AddHtInfoLen,
									   ie_list,
									   CapabilityInfo);
				/* +++Add by shiang for debug */
				/* TODO: shiang-usw, we need more solid way to do this! */
				{
					/* struct wifi_dev *wdev = &pStaCfg->wdev; */
					/*
					 *	re-copy the MAC to virtual interface to avoid these MAC = all zero,
					 *	when re-open the ra0,
					 *	i.e. ifconfig ra0 down, ifconfig ra0 up, ifconfig ra0 down, ifconfig up...
					 */
					/* wdev->func_idx = 0; */
					/* wdev->tr_tb_idx = pEntry->wcid; */
					TRTableInsertEntry(pAd, pEntry->wcid, pEntry);
				}
				/* TRTableEntryDump(pAd, pEntry->wcid, __FUNCTION__, __LINE__); */
				/* ---Add by shiang for debug */
				RTMPSetSupportMCS(pAd,
								  OPMODE_STA,
								  pEntry,
								  SupRate,
								  SupRateLen,
								  ExtRate,
								  ExtRateLen,
#ifdef DOT11_VHT_AC
								  ie_list->vht_cap_len,
								  &ie_list->vht_cap,
#endif /* DOT11_VHT_AC */
								  &HtCapability,
								  HtCapabilityLen);
			}

			pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
			MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_ASSOC_CONF, 2, &Status, 0, Elem->wdev);
#ifdef LINUX
#ifdef RT_CFG80211_SUPPORT

			if (Status == MLME_SUCCESS) {
				PFRAME_802_11 pFrame =  (PFRAME_802_11) (Elem->Msg);

				RTEnqueueInternalCmd(pAd, CMDTHREAD_CONNECT_RESULT_INFORM,
									 &pFrame->Octet[6], Elem->MsgLen - 6 - sizeof(HEADER_802_11));
			}

#endif /* RT_CFG80211_SUPPORT */
#endif /* LINUX */
		}
	} else
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ASSOC - %s() sanity check fail\n", __func__));

end:
	if (ie_list != NULL)
		os_free_mem(ie_list);
}


/*
 *	==========================================================================
 *	Description:
 *		peer sends reassoc rsp
 *	Parametrs:
 *		Elem - MLME message cntaining the received frame
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID PeerReassocRspAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	USHORT CapabilityInfo;
	USHORT Status;
	USHORT Aid;
	UCHAR SupRate[MAX_LEN_OF_SUPPORTED_RATES], SupRateLen;
	UCHAR ExtRate[MAX_LEN_OF_SUPPORTED_RATES], ExtRateLen;
	UCHAR Addr2[MAC_ADDR_LEN];
	UCHAR CkipFlag;
	BOOLEAN TimerCancelled;
	EDCA_PARM EdcaParm;
	HT_CAPABILITY_IE HtCapability;
	ADD_HT_INFO_IE AddHtInfo;	/* AP might use this additional ht info IE */
	UCHAR HtCapabilityLen;
	UCHAR AddHtInfoLen;
	UCHAR NewExtChannelOffset = 0xff;
	EXT_CAP_INFO_ELEMENT ExtCapInfo;
	IE_LISTS *ie_list = NULL;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	os_alloc_mem(pAd, (UCHAR **)&ie_list, sizeof(IE_LISTS));

	if (ie_list == NULL) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s():mem alloc failed!\n", __func__));
		return;
	}

	NdisZeroMemory((UCHAR *)ie_list, sizeof(IE_LISTS));

	if (PeerAssocRspSanity(&pStaCfg->wdev, Elem->Msg, Elem->MsgLen, Addr2,
						   &CapabilityInfo, &Status, &Aid, SupRate,
						   &SupRateLen, ExtRate, &ExtRateLen, &HtCapability,
						   &AddHtInfo, &HtCapabilityLen, &AddHtInfoLen,
						   &NewExtChannelOffset, &EdcaParm, &ExtCapInfo,
						   &CkipFlag, ie_list)) {
		if (MAC_ADDR_EQUAL(Addr2, pStaCfg->MlmeAux.Bssid)) {	/* The frame is for me ? */
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("REASSOC - receive REASSOC_RSP to me (status=%d)\n", Status));
			RTMPCancelTimer(&pStaCfg->MlmeAux.ReassocTimer,
							&TimerCancelled);

			if (Status == MLME_SUCCESS) {
				UCHAR MaxSupportedRateIn500Kbps = 0;
				PMAC_TABLE_ENTRY pEntry = NULL;
				/*
				 *	In roaming case, LinkDown wouldn't be invoked.
				 *	For preventing finding MacTable Hash index malfunction,
				 *	we need to do MacTableDeleteEntry here.
				 */
				pEntry = MacTableLookup2(pAd, pStaCfg->Bssid, &pStaCfg->wdev);

				if (pEntry) {
					MacTableDeleteEntry(pAd, pEntry->wcid, pEntry->Addr);
					pEntry = NULL;
				}

				pEntry = MacTableLookup2(pAd, Addr2, &pStaCfg->wdev);

				if (pEntry) {
					MacTableDeleteEntry(pAd, pEntry->wcid, pEntry->Addr);
					pEntry = NULL;
				}

				pEntry = MacTableInsertEntry(pAd, Addr2, &pStaCfg->wdev, ENTRY_INFRA, OPMODE_STA, TRUE);
				ASSERT(pEntry);
				MaxSupportedRateIn500Kbps = dot11_max_sup_rate(SupRateLen, &SupRate[0], ExtRateLen, &ExtRate[0]);
				/* go to procedure listed on page 376 */
				AssocPostProc(pAd, Addr2, CapabilityInfo, Aid,
							  SupRate, SupRateLen, ExtRate,
							  ExtRateLen, &EdcaParm,
							  ie_list,
							  &HtCapability, HtCapabilityLen,
							  &AddHtInfo,
							  pEntry);
				StaUpdateMacTableEntry(pAd,
									   pEntry,
									   MaxSupportedRateIn500Kbps,
									   &HtCapability,
									   HtCapabilityLen, &AddHtInfo,
									   AddHtInfoLen,
									   ie_list,
									   CapabilityInfo);
				RTMPSetSupportMCS(pAd,
								  OPMODE_STA,
								  pEntry,
								  SupRate,
								  SupRateLen,
								  ExtRate,
								  ExtRateLen,
#ifdef DOT11_VHT_AC
								  ie_list->vht_cap_len,
								  &ie_list->vht_cap,
#endif /* DOT11_VHT_AC */
								  &HtCapability,
								  HtCapabilityLen);
#ifdef WPA_SUPPLICANT_SUPPORT
#ifndef NATIVE_WPA_SUPPLICANT_SUPPORT

				if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) {
					SendAssocIEsToWpaSupplicant(pAd->net_dev,
												pStaCfg->ReqVarIEs,
												pStaCfg->ReqVarIELen);
					RtmpOSWrielessEventSend(pAd->net_dev,
											RT_WLAN_EVENT_CUSTOM,
											RT_ASSOC_EVENT_FLAG,
											NULL, NULL, 0);
				}

#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT
				{
					wext_notify_event_assoc(pAd->net_dev,
											pStaCfg->ReqVarIEs,
											pStaCfg->ReqVarIELen);
					RtmpOSWrielessEventSend(pAd->net_dev,
											RT_WLAN_EVENT_CGIWAP,
											-1,
											&pStaCfg->MlmeAux.Bssid[0], NULL,
											0);
				}
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
			}

#ifdef DOT11V_WNM_SUPPORT

			if (ExtCapInfo.BssTransitionManmt == 1)
				pStaCfg->bBSSMantAPSupport = TRUE;

			if (ExtCapInfo.DMSSupport == 1)
				pStaCfg->bDMSAPSupport = TRUE;

#endif /* DOT11V_WNM_SUPPORT */
			/* CkipFlag is no use for reassociate */
			pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
			MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_REASSOC_CONF, 2, &Status, 0, Elem->wdev);
		}
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("REASSOC - %s() sanity check fail\n", __func__));
	}

	if (ie_list)
		os_free_mem(ie_list);
}

/*
 *	==========================================================================
 *	Description:
 *		procedures on IEEE 802.11/1999 p.376
 *	Parametrs:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID AssocPostProc(
	IN PRTMP_ADAPTER pAd,
	IN PUCHAR pAddr2,
	IN USHORT CapabilityInfo,
	IN USHORT Aid,
	IN UCHAR SupRate[],
	IN UCHAR SupRateLen,
	IN UCHAR ExtRate[],
	IN UCHAR ExtRateLen,
	IN PEDCA_PARM pEdcaParm,
	IN IE_LISTS *ie_list,
	IN HT_CAPABILITY_IE *pHtCapability,
	IN UCHAR HtCapabilityLen,
	IN ADD_HT_INFO_IE *pAddHtInfo,
	IN MAC_TABLE_ENTRY *pEntry)
{
	/* AP might use this additional ht info IE */
	ULONG Idx;
	struct wifi_dev *wdev = pEntry->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, pEntry->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	pStaCfg->MlmeAux.BssType = BSS_INFRA;
	COPY_MAC_ADDR(pStaCfg->MlmeAux.Bssid, pAddr2);
	pStaCfg->MlmeAux.Aid = Aid;
	pStaCfg->MlmeAux.CapabilityInfo = CapabilityInfo & SUPPORTED_CAPABILITY_INFO;
#if defined(MT_MAC) && defined(TXBF_SUPPORT)
	if (pAd->chipOps.archSetAid)
		pAd->chipOps.archSetAid(pAd, Aid);
#endif
#ifdef DOT11_N_SUPPORT

	/* Some HT AP might lost WMM IE. We add WMM ourselves. beacuase HT requires QoS on. */
	if ((HtCapabilityLen > 0) && (pEdcaParm->bValid == FALSE)) {
		pEdcaParm->bValid = TRUE;
		pEdcaParm->Aifsn[0] = 3;
		pEdcaParm->Aifsn[1] = 7;
		pEdcaParm->Aifsn[2] = 2;
		pEdcaParm->Aifsn[3] = 2;
		pEdcaParm->Cwmin[0] = 4;
		pEdcaParm->Cwmin[1] = 4;
		pEdcaParm->Cwmin[2] = 3;
		pEdcaParm->Cwmin[3] = 2;
		pEdcaParm->Cwmax[0] = 10;
		pEdcaParm->Cwmax[1] = 10;
		pEdcaParm->Cwmax[2] = 4;
		pEdcaParm->Cwmax[3] = 3;
		pEdcaParm->Txop[0] = 0;
		pEdcaParm->Txop[1] = 0;
		pEdcaParm->Txop[2] = 94;
		pEdcaParm->Txop[3] = 47;
	}

#endif /* DOT11_N_SUPPORT */

	if (pEdcaParm->bValid == TRUE)
		CLIENT_STATUS_SET_FLAG(pEntry, fCLIENT_STATUS_WMM_CAPABLE);

	NdisMoveMemory(&pStaCfg->MlmeAux.APEdcaParm, pEdcaParm, sizeof(EDCA_PARM));
	/* filter out un-supported rates */
	pStaCfg->MlmeAux.SupRateLen = SupRateLen;
	NdisMoveMemory(pStaCfg->MlmeAux.SupRate, SupRate, SupRateLen);
	RTMPCheckRates(pAd, pStaCfg->MlmeAux.SupRate, &pStaCfg->MlmeAux.SupRateLen, wdev->PhyMode);
	/* filter out un-supported rates */
	pStaCfg->MlmeAux.ExtRateLen = ExtRateLen;
	NdisMoveMemory(pStaCfg->MlmeAux.ExtRate, ExtRate, ExtRateLen);
	RTMPCheckRates(pAd, pStaCfg->MlmeAux.ExtRate, &pStaCfg->MlmeAux.ExtRateLen, wdev->PhyMode);
#ifdef DOT11_N_SUPPORT

	if (HtCapabilityLen > 0) {
		if (pEntry)
			RTMPCheckHt(pAd, pEntry->wcid, pHtCapability, pAddHtInfo);
	}

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("%s():=>AP.AMsduSize = %d. ClientStatusFlags = 0x%lx\n",
			  __func__, pEntry->AMsduSize, pEntry->ClientStatusFlags));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("%s():=>(Mmps=%d, AmsduSize=%d, )\n",
			  __func__, pEntry->MmpsMode, pEntry->AMsduSize));
#ifdef DOT11_VHT_AC

	if (ie_list->vht_cap_len > 0 && ie_list->vht_op_len > 0)
		RTMPCheckVht(pAd, pEntry->wcid, &ie_list->vht_cap, &ie_list->vht_op);

#endif /* DOT11_VHT_AC */
#endif /* DOT11_N_SUPPORT */
	/* Set New WPA information */
	Idx = BssTableSearch(&pAd->ScanTab, pAddr2, pStaCfg->MlmeAux.Channel);

	if (Idx == BSS_NOT_FOUND)
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("ASSOC - Can't find BSS after receiving Assoc response\n"));
	else {
		/* Init variable */
		pEntry->RSNIE_Len = 0;
		NdisZeroMemory(pEntry->RSN_IE, MAX_LEN_OF_RSNIE);

		/* Store appropriate RSN_IE for WPA SM negotiation later */
		if (IS_AKM_WPA_CAPABILITY(wdev->SecConfig.AKMMap)
			&& (Idx < MAX_LEN_OF_BSS_TABLE)
			&& (pAd->ScanTab.BssEntry[Idx].VarIELen != 0)) {
			PUCHAR pVIE;
			USHORT len;
			PEID_STRUCT pEid;

			pVIE = pAd->ScanTab.BssEntry[Idx].VarIEs;
			len = pAd->ScanTab.BssEntry[Idx].VarIELen;

			while (len > 0) {
				pEid = (PEID_STRUCT) pVIE;

				/* For WPA/WPAPSK */
				if ((pEid->Eid == IE_WPA)
					&& (NdisEqualMemory(pEid->Octet, WPA_OUI, 4))
					&& (IS_AKM_WPA1(wdev->SecConfig.AKMMap)
						|| IS_AKM_WPA1PSK(wdev->SecConfig.AKMMap))) {
					NdisMoveMemory(pEntry->RSN_IE, pVIE, (pEid->Len + 2));
					pEntry->RSNIE_Len = (pEid->Len + 2);
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("%s():=> Store RSN_IE for WPA SM negotiation\n", __func__));
				}
				/* For WPA2/WPA2PSK */
				else if ((pEid->Eid == IE_RSN)
						 && (NdisEqualMemory(pEid->Octet + 2, RSN_OUI, 3))
						 && (IS_AKM_WPA2(wdev->SecConfig.AKMMap)
							 || IS_AKM_WPA2PSK(wdev->SecConfig.AKMMap))) {
					NdisMoveMemory(pEntry->RSN_IE, pVIE, (pEid->Len + 2));
					pEntry->RSNIE_Len = (pEid->Len + 2);
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("%s():=> Store RSN_IE for WPA2 SM negotiation\n", __func__));
				}

#ifdef WAPI_SUPPORT
				/* For WAPI */
				else if ((pEid->Eid == IE_WAPI)
						 && (NdisEqualMemory(pEid->Octet + 4, WAPI_OUI, 3))
						 && (IS_AKM_WAICERT(wdev->SecConfig.AKMMap)
							 || IS_AKM_WPIPSK(wdev->SecConfig.AKMMap))) {
					NdisMoveMemory(pEntry->RSN_IE, pVIE, (pEid->Len + 2));
					pEntry->RSNIE_Len = (pEid->Len + 2);
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("%s():=> Store RSN_IE for WAPI SM negotiation\n", __func__));
				}

#endif /* WAPI_SUPPORT */
				pVIE += (pEid->Len + 2);
				len -= (pEid->Len + 2);
			}

#ifdef DOT11R_FT_SUPPORT

			if (pStaCfg->Dot11RCommInfo.bFtSupport &&
				pStaCfg->Dot11RCommInfo.bInMobilityDomain &&
				(pStaCfg->MlmeAux.FtIeInfo.GtkLen != 0)) {
				/* extract GTK related information */
				FT_ExtractGTKSubIe(pAd,
								   &pAd->MacTab.Content[MCAST_WCID],
								   &pStaCfg->MlmeAux.FtIeInfo);
			}

#endif /* DOT11R_FT_SUPPORT */
		}

		if (pEntry->RSNIE_Len == 0)
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():=> no RSN_IE\n", __func__));
		else
			hex_dump("RSN_IE", pEntry->RSN_IE, pEntry->RSNIE_Len);
	}
}

/*
 *	==========================================================================
 *	Description:
 *		left part of IEEE 802.11/1999 p.374
 *	Parameters:
 *		Elem - MLME message containing the received frame
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID PeerDisassocAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	UCHAR Addr2[MAC_ADDR_LEN];
	USHORT Reason;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ASSOC - PeerDisassocAction()\n"));

	if (PeerDisassocSanity(pAd, Elem->Msg, Elem->MsgLen, Addr2, &Reason)) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("ASSOC - PeerDisassocAction() Reason = %d\n",
				  Reason));

		if (INFRA_ON(pStaCfg)
			&& MAC_ADDR_EQUAL(pStaCfg->Bssid, Addr2)) {
#ifdef WMM_ACM_SUPPORT
			ACMP_StationDelete(pAd,
							   ACMR_STA_ENTRY_GET(pAd,
												  pAd->CommonCfg.Bssid));
#endif /* WMM_ACM_SUPPORT */
			RTMPSendWirelessEvent(pAd, IW_DISASSOC_EVENT_FLAG, NULL,
								  BSS0, 0);
#ifdef WAPI_SUPPORT
			WAPI_InternalCmdAction(pAd,
								   pStaCfg->wdev.SecConfig.AKMMap,
								   BSS0,
								   Addr2, WAI_MLME_DISCONNECT);
#endif /* WAPI_SUPPORT */

			/*
			 *  It is possible that AP sends dis-assoc frame(PeerDisassocAction) to STA
			 *  after driver enqueue MT2_MLME_DISASSOC_REQ (MlmeDisassocReqAction)
			 *  and set CntlMachine.CurrState = CNTL_WAIT_DISASSOC.
			 *  DisassocTimer is useless because AssocMachine.CurrState will set to ASSOC_IDLE here.
			 *  Therefore, we need to check CntlMachine.CurrState here and enqueue MT2_DISASSOC_CONF to
			 *  reset CntlMachine.CurrState to CNTL_IDLE state again.
			 */
			if (pStaCfg->CntlMachine.CurrState ==
				CNTL_WAIT_DISASSOC) {
				USHORT Status;

				Status = MLME_SUCCESS;
				MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE,
									MT2_DISASSOC_CONF, 2, &Status, 0, Elem->wdev);
			} else
				LinkDown(pAd, TRUE, Elem->wdev);

			pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
#ifdef WPA_SUPPLICANT_SUPPORT
#ifndef NATIVE_WPA_SUPPLICANT_SUPPORT

			if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) {
				/*send disassociate event to wpa_supplicant */
				RtmpOSWrielessEventSend(pAd->net_dev,
										RT_WLAN_EVENT_CUSTOM,
										RT_DISASSOC_EVENT_FLAG,
										NULL, NULL, 0);
			}

#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif /* WPA_SUPPLICANT_SUPPORT */
			/* mark here because linkdown also call this function */
#if 0
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT
			RtmpOSWrielessEventSend(pAd->net_dev,
									RT_WLAN_EVENT_CGIWAP, -1, NULL,
									NULL, 0);
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif
		}
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("ASSOC - PeerDisassocAction() sanity check fail\n"));
	}
}

/*
 *	==========================================================================
 *	Description:
 *		what the state machine will do after assoc timeout
 *	Parameters:
 *		Elme -
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID AssocTimeoutAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ASSOC - AssocTimeoutAction\n"));
	pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
	Status = MLME_REJ_TIMEOUT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_ASSOC_CONF, 2, &Status,
						0, Elem->wdev);
}

/*
 *	==========================================================================
 *	Description:
 *		what the state machine will do after reassoc timeout
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID ReassocTimeoutAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ASSOC - ReassocTimeoutAction\n"));
	pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
	Status = MLME_REJ_TIMEOUT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_REASSOC_CONF, 2, &Status,
						0, Elem->wdev);
}

/*
 *	==========================================================================
 *	Description:
 *		what the state machine will do after disassoc timeout
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID DisassocTimeoutAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ASSOC - DisassocTimeoutAction\n"));
	pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
	Status = MLME_SUCCESS;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_DISASSOC_CONF, 2, &Status,
						0, Elem->wdev);
}

VOID InvalidStateWhenAssoc(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("ASSOC - InvalidStateWhenAssoc(state=%ld), reset ASSOC state machine\n",
			  pStaCfg->AssocMachine.CurrState));
	pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
	Status = MLME_STATE_MACHINE_REJECT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_ASSOC_CONF, 2, &Status,
						0, Elem->wdev);
}

VOID InvalidStateWhenReassoc(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("ASSOC - InvalidStateWhenReassoc(state=%ld), reset ASSOC state machine\n",
			  pStaCfg->AssocMachine.CurrState));
	pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
	Status = MLME_STATE_MACHINE_REJECT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_REASSOC_CONF, 2, &Status,
						0, Elem->wdev);
}

VOID InvalidStateWhenDisassociate(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("ASSOC - InvalidStateWhenDisassoc(state=%ld), reset ASSOC state machine\n",
			  pStaCfg->AssocMachine.CurrState));
	pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
	Status = MLME_STATE_MACHINE_REJECT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_DISASSOC_CONF, 2, &Status,
						0, Elem->wdev);
}
#if 0
/* Not used */
/*
 *	==========================================================================
 *	Description:
 *		right part of IEEE 802.11/1999 page 374
 *	Note:
 *		This event should never cause ASSOC state machine perform state
 *		transition, and has no relationship with CNTL machine. So we separate
 *		this routine as a service outside of ASSOC state transition table.
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID Cls3errAction(RTMP_ADAPTER *pAd, UCHAR *pAddr)
{
	HEADER_802_11 DisassocHdr;
	PHEADER_802_11 pDisassocHdr;
	PUCHAR pOutBuffer = NULL;
	ULONG FrameLen = 0;
	NDIS_STATUS NStatus;
	USHORT Reason = REASON_CLS3ERR;

	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);	/*Get an unused nonpaged memory */

	if (NStatus != NDIS_STATUS_SUCCESS)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("ASSOC - Class 3 Error, Send DISASSOC frame\n"));
	MgtMacHeaderInit(pAd, &DisassocHdr, SUBTYPE_DISASSOC, 0, pAddr,
					 pStaCfg->wdev.if_addr,
					 pAd->CommonCfg.Bssid);	/* patch peap ttls switching issue */
	MakeOutgoingFrame(pOutBuffer, &FrameLen,
					  sizeof(HEADER_802_11), &DisassocHdr,
					  2, &Reason, END_OF_ARGS);
	MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
	/* To patch Instance and Buffalo(N) AP */
	/* Driver has to send deauth to Instance AP, but Buffalo(N) needs to send disassoc to reset Authenticator's state machine */
	/* Therefore, we send both of them. */
	pDisassocHdr = (PHEADER_802_11) pOutBuffer;
	pDisassocHdr->FC.SubType = SUBTYPE_DEAUTH;
	MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
	MlmeFreeMemory(pOutBuffer);
	pAd->StaCfg[0].DisassocReason = REASON_CLS3ERR;
	COPY_MAC_ADDR(pAd->StaCfg[0].DisassocSta, pAddr);
}
#endif

/*
 *	==========================================================================
 *	Description:
 *		association state machine init, including state transition and timer init
 *	Parameters:
 *		S - pointer to the association state machine
 *
 *	IRQL = PASSIVE_LEVEL
 *
 *	==========================================================================
 */
VOID AssocStateMachineInit(
	IN PRTMP_ADAPTER pAd,
	IN struct wifi_dev *wdev,
	IN STATE_MACHINE * S,
	OUT STATE_MACHINE_FUNC Trans[])
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	StateMachineInit(S, Trans, MAX_ASSOC_STATE, MAX_ASSOC_MSG,
					 (STATE_MACHINE_FUNC) Drop, ASSOC_IDLE,
					 ASSOC_MACHINE_BASE);
	/* first column */
	StateMachineSetAction(S, ASSOC_IDLE, MT2_MLME_ASSOC_REQ,
						  (STATE_MACHINE_FUNC) MlmeAssocReqAction);
	StateMachineSetAction(S, ASSOC_IDLE, MT2_MLME_REASSOC_REQ,
						  (STATE_MACHINE_FUNC) MlmeReassocReqAction);
	StateMachineSetAction(S, ASSOC_IDLE, MT2_MLME_DISASSOC_REQ,
						  (STATE_MACHINE_FUNC) MlmeDisassocReqAction);
	StateMachineSetAction(S, ASSOC_IDLE, MT2_PEER_DISASSOC_REQ,
						  (STATE_MACHINE_FUNC) PeerDisassocAction);
	/* second column */
	StateMachineSetAction(S, ASSOC_WAIT_RSP, MT2_MLME_ASSOC_REQ,
						  (STATE_MACHINE_FUNC) InvalidStateWhenAssoc);
	StateMachineSetAction(S, ASSOC_WAIT_RSP, MT2_MLME_REASSOC_REQ,
						  (STATE_MACHINE_FUNC) InvalidStateWhenReassoc);
	StateMachineSetAction(S, ASSOC_WAIT_RSP, MT2_MLME_DISASSOC_REQ,
						  (STATE_MACHINE_FUNC)
						  InvalidStateWhenDisassociate);
	StateMachineSetAction(S, ASSOC_WAIT_RSP, MT2_PEER_DISASSOC_REQ,
						  (STATE_MACHINE_FUNC) PeerDisassocAction);
	StateMachineSetAction(S, ASSOC_WAIT_RSP, MT2_PEER_ASSOC_RSP,
						  (STATE_MACHINE_FUNC) PeerAssocRspAction);
	/* */
	/* Patch 3Com AP MOde:3CRWE454G72 */
	/* We send Assoc request frame to this AP, it always send Reassoc Rsp not Associate Rsp. */
	/* */
	StateMachineSetAction(S, ASSOC_WAIT_RSP, MT2_PEER_REASSOC_RSP,
						  (STATE_MACHINE_FUNC) PeerAssocRspAction);
	StateMachineSetAction(S, ASSOC_WAIT_RSP, MT2_ASSOC_TIMEOUT,
						  (STATE_MACHINE_FUNC) AssocTimeoutAction);
	/* third column */
	StateMachineSetAction(S, REASSOC_WAIT_RSP, MT2_MLME_ASSOC_REQ,
						  (STATE_MACHINE_FUNC) InvalidStateWhenAssoc);
	StateMachineSetAction(S, REASSOC_WAIT_RSP, MT2_MLME_REASSOC_REQ,
						  (STATE_MACHINE_FUNC) InvalidStateWhenReassoc);
	StateMachineSetAction(S, REASSOC_WAIT_RSP, MT2_MLME_DISASSOC_REQ,
						  (STATE_MACHINE_FUNC)
						  InvalidStateWhenDisassociate);
	StateMachineSetAction(S, REASSOC_WAIT_RSP, MT2_PEER_DISASSOC_REQ,
						  (STATE_MACHINE_FUNC) PeerDisassocAction);
	StateMachineSetAction(S, REASSOC_WAIT_RSP, MT2_PEER_REASSOC_RSP,
						  (STATE_MACHINE_FUNC) PeerReassocRspAction);
	/* */
	/* Patch, AP doesn't send Reassociate Rsp frame to Station. */
	/* */
	StateMachineSetAction(S, REASSOC_WAIT_RSP, MT2_PEER_ASSOC_RSP,
						  (STATE_MACHINE_FUNC) PeerReassocRspAction);
	StateMachineSetAction(S, REASSOC_WAIT_RSP, MT2_REASSOC_TIMEOUT,
						  (STATE_MACHINE_FUNC) ReassocTimeoutAction);
	/* fourth column */
	StateMachineSetAction(S, DISASSOC_WAIT_RSP, MT2_MLME_ASSOC_REQ,
						  (STATE_MACHINE_FUNC) InvalidStateWhenAssoc);
	StateMachineSetAction(S, DISASSOC_WAIT_RSP, MT2_MLME_REASSOC_REQ,
						  (STATE_MACHINE_FUNC) InvalidStateWhenReassoc);
	StateMachineSetAction(S, DISASSOC_WAIT_RSP, MT2_MLME_DISASSOC_REQ,
						  (STATE_MACHINE_FUNC)
						  InvalidStateWhenDisassociate);
	StateMachineSetAction(S, DISASSOC_WAIT_RSP, MT2_PEER_DISASSOC_REQ,
						  (STATE_MACHINE_FUNC) PeerDisassocAction);
	StateMachineSetAction(S, DISASSOC_WAIT_RSP, MT2_DISASSOC_TIMEOUT,
						  (STATE_MACHINE_FUNC) DisassocTimeoutAction);
	/* initialize the timer */
	pStaCfg->MlmeAux.AssocTimerFuncContext.pAd = pAd;
	pStaCfg->MlmeAux.AssocTimerFuncContext.wdev = wdev;
	RTMPInitTimer(pAd, &pStaCfg->MlmeAux.AssocTimer,
				  GET_TIMER_FUNCTION(AssocTimeout), &pStaCfg->MlmeAux.AssocTimerFuncContext, FALSE);
	pStaCfg->MlmeAux.ReassocTimerFuncContext.pAd = pAd;
	pStaCfg->MlmeAux.ReassocTimerFuncContext.wdev = wdev;
	RTMPInitTimer(pAd, &pStaCfg->MlmeAux.ReassocTimer,
				  GET_TIMER_FUNCTION(ReassocTimeout), &pStaCfg->MlmeAux.ReassocTimerFuncContext, FALSE);
	pStaCfg->MlmeAux.DisassocTimerFuncContext.pAd = pAd;
	pStaCfg->MlmeAux.DisassocTimerFuncContext.wdev = wdev;
	RTMPInitTimer(pAd, &pStaCfg->MlmeAux.DisassocTimer,
				  GET_TIMER_FUNCTION(DisassocTimeout), &pStaCfg->MlmeAux.DisassocTimerFuncContext, FALSE);
}
