/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology	5th	Rd.
 * Science-based Industrial	Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2004, Ralink Technology, Inc.
 *
 * All rights reserved.	Ralink's source	code is	an unpublished work	and	the
 * use of a	copyright notice does not imply	otherwise. This	source code
 * contains	confidential trade secret material of Ralink Tech. Any attemp
 * or participation	in deciphering,	decoding, reverse engineering or in	any
 * way altering	the	source code	is stricitly prohibited, unless	the	prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	connect.c

	Abstract:

	Revision History:
	Who			When			What
	--------	----------		----------------------------------------------
	John			2004-08-08			Major modification from RT2560
*/
#include "rt_config.h"
#ifdef DOT11R_FT_SUPPORT
#include "ft.h"
#endif /* DOT11R_FT_SUPPORT */

UCHAR CipherSuiteWpaNoneTkip[] = {
	0x00, 0x50, 0xf2, 0x01,	/* oui */
	0x01, 0x00,		/* Version */
	0x00, 0x50, 0xf2, 0x02,	/* Multicast */
	0x01, 0x00,		/* Number of unicast */
	0x00, 0x50, 0xf2, 0x02,	/* unicast */
	0x01, 0x00,		/* number of authentication method */
	0x00, 0x50, 0xf2, 0x00	/* authentication */
};
UCHAR CipherSuiteWpaNoneTkipLen =
	(sizeof(CipherSuiteWpaNoneTkip) / sizeof(UCHAR));

UCHAR CipherSuiteWpaNoneAes[] = {
	0x00, 0x50, 0xf2, 0x01,	/* oui */
	0x01, 0x00,		/* Version */
	0x00, 0x50, 0xf2, 0x04,	/* Multicast */
	0x01, 0x00,		/* Number of unicast */
	0x00, 0x50, 0xf2, 0x04,	/* unicast */
	0x01, 0x00,		/* number of authentication method */
	0x00, 0x50, 0xf2, 0x00	/* authentication */
};
UCHAR CipherSuiteWpaNoneAesLen =
	(sizeof(CipherSuiteWpaNoneAes) / sizeof(UCHAR));

/* The following MACRO is called after 1. starting an new IBSS, 2. succesfully JOIN an IBSS, */
/* or 3. succesfully ASSOCIATE to a BSS, 4. successfully RE_ASSOCIATE to a BSS */
/* All settings successfuly negotiated furing MLME state machines become final settings */
/* and are copied to pStaCfg->StaActive */
#define COPY_SETTINGS_FROM_MLME_AUX_TO_ACTIVE_CFG(_pAd, _pStaCfg, _pEntry)                                 \
	{                                                                                       \
		NdisZeroMemory((_pStaCfg)->Ssid, MAX_LEN_OF_SSID);							\
		(_pStaCfg)->SsidLen = (_pStaCfg)->MlmeAux.SsidLen;                                \
		NdisMoveMemory((_pStaCfg)->Ssid, (_pStaCfg)->MlmeAux.Ssid, (_pStaCfg)->MlmeAux.SsidLen); \
		COPY_MAC_ADDR((_pStaCfg)->Bssid, (_pStaCfg)->MlmeAux.Bssid);                      \
		(_pStaCfg)->wdev.channel = (_pStaCfg)->MlmeAux.Channel;                                \
		(_pStaCfg)->StaActive.Aid = (_pStaCfg)->MlmeAux.Aid;                                        \
		(_pStaCfg)->StaActive.AtimWin = (_pStaCfg)->MlmeAux.AtimWin;                                \
		(_pStaCfg)->StaActive.CapabilityInfo = (_pStaCfg)->MlmeAux.CapabilityInfo;                  \
		(_pStaCfg)->StaActive.ExtCapInfo = (_pStaCfg)->MlmeAux.ExtCapInfo;                  \
		(_pAd)->CommonCfg.BeaconPeriod = (_pStaCfg)->MlmeAux.BeaconPeriod;                      \
		(_pStaCfg)->StaActive.CfpMaxDuration = (_pStaCfg)->MlmeAux.CfpMaxDuration;                  \
		(_pStaCfg)->StaActive.CfpPeriod = (_pStaCfg)->MlmeAux.CfpPeriod;                            \
		(_pStaCfg)->StaActive.SupRateLen = (_pStaCfg)->MlmeAux.SupRateLen;                          \
		NdisMoveMemory((_pStaCfg)->StaActive.SupRate, (_pStaCfg)->MlmeAux.SupRate, (_pStaCfg)->MlmeAux.SupRateLen);\
		(_pStaCfg)->StaActive.ExtRateLen = (_pStaCfg)->MlmeAux.ExtRateLen;                          \
		NdisMoveMemory((_pStaCfg)->StaActive.ExtRate, (_pStaCfg)->MlmeAux.ExtRate, (_pStaCfg)->MlmeAux.ExtRateLen);\
		NdisMoveMemory(&(_pAd)->CommonCfg.APEdcaParm, &(_pStaCfg)->MlmeAux.APEdcaParm, sizeof(EDCA_PARM));\
		NdisMoveMemory(&(_pAd)->CommonCfg.APQosCapability, &(_pStaCfg)->MlmeAux.APQosCapability, sizeof(QOS_CAPABILITY_PARM));\
		NdisMoveMemory(&(_pAd)->CommonCfg.APQbssLoad, &(_pStaCfg)->MlmeAux.APQbssLoad, sizeof(QBSS_LOAD_PARM));\
		COPY_MAC_ADDR((_pEntry)->Addr, (_pStaCfg)->MlmeAux.Bssid);      \
		(_pEntry)->SecConfig.AKMMap = (_pStaCfg)->AKMMap;\
		(_pEntry)->SecConfig.PairwiseCipher = (_pStaCfg)->PairwiseCipher;\
		COPY_MAC_ADDR((_pEntry)->bssid, (_pStaCfg)->MlmeAux.Bssid);\
		(_pEntry)->RateLen = (_pStaCfg)->StaActive.SupRateLen + (_pStaCfg)->StaActive.ExtRateLen;\
	}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = PASSIVE_LEVEL
 *
 *	==========================================================================
 */
VOID MlmeCntlInit(
	IN PRTMP_ADAPTER pAd,
	IN struct wifi_dev *wdev)
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	/* Control state machine differs from other state machines, the interface */
	/* follows the standard interface */
	pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID MlmeCntlMachinePerformAction(
	IN PRTMP_ADAPTER pAd,
	IN STATE_MACHINE * S,
	IN MLME_QUEUE_ELEM * Elem)
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	MAC_TABLE_ENTRY *pEntry = NULL;

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	pEntry = GetAssociatedAPByWdev(pAd, Elem->wdev);

	switch (pStaCfg->CntlMachine.CurrState) {
	case CNTL_IDLE:
		CntlIdleProc(pAd, Elem);
		break;

	case CNTL_WAIT_DISASSOC:
		CntlWaitDisassocProc(pAd, Elem);
		break;

	case CNTL_WAIT_JOIN:
		CntlWaitJoinProc(pAd, Elem);
		break;

	/* CNTL_WAIT_REASSOC is the only state in CNTL machine that does */
	/* not triggered directly or indirectly by "RTMPSetInformation(OID_xxx)". */
	/* Therefore not protected by NDIS's "only one outstanding OID request" */
	/* rule. Which means NDIS may SET OID in the middle of ROAMing attempts. */
	/* Current approach is to block new SET request at RTMPSetInformation() */
	/* when CntlMachine.CurrState is not CNTL_IDLE */
	case CNTL_WAIT_REASSOC:
		CntlWaitReassocProc(pAd, Elem);
		break;

	case CNTL_WAIT_START:
		CntlWaitStartProc(pAd, Elem);
		break;

	case CNTL_WAIT_AUTH:
		CntlWaitAuthProc(pAd, Elem);
		break;

	case CNTL_WAIT_AUTH2:
		CntlWaitAuthProc2(pAd, Elem);
		break;

	case CNTL_WAIT_ASSOC:
		CntlWaitAssocProc(pAd, Elem);
		break;

	case CNTL_WAIT_OID_LIST_SCAN:
		if (Elem->MsgType == MT2_SCAN_CONF) {
			USHORT	Status = MLME_SUCCESS;

			NdisMoveMemory(&Status, Elem->Msg, sizeof(USHORT));
#ifdef MT76XX_BTCOEX_SUPPORT
			MLMEHook(pAd, WLAN_SCANDONE, WLAN_NO_BSSID);
#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef COEX_SUPPORT
			if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd)) {
				if (pStaCfg->MlmeAux.OldChannel <= 14)
					MT76xxMLMEHook(pAd, MT76xx_WLAN_SCANDONE_2G, 0);
				else
					MT76xxMLMEHook(pAd, MT76xx_WLAN_SCANDONE_5G, 0);
			}

#endif /* COEX_SUPPORT */

			pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
			/* scan completed, init to not FastScan */
			pStaCfg->bImprovedScan = FALSE;
#ifdef RT_CFG80211_SUPPORT
			RTEnqueueInternalCmd(pAd, CMDTHREAD_SCAN_END, NULL, 0);
#endif /* RT_CFG80211_SUPPORT */
#ifdef LED_CONTROL_SUPPORT

			/* */
			/* Set LED status to previous status. */
			/* */
			if (pAd->LedCntl.bLedOnScanning) {
				pAd->LedCntl.bLedOnScanning = FALSE;
				RTMPSetLED(pAd, pAd->LedCntl.LedStatus);
			}

#endif /* LED_CONTROL_SUPPORT */
#ifdef DOT11N_DRAFT3

			/* AP sent a 2040Coexistence mgmt frame, then station perform a scan, and then send back the respone. */
			if ((pAd->CommonCfg.BSSCoexist2040.field.InfoReq == 1)
				&& INFRA_ON(pStaCfg)
				&& OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_SCAN_2040)) {
				ASSERT(pEntry);
				Update2040CoexistFrameAndNotify(pAd, pEntry->wcid,
												TRUE);
			}

#endif /* DOT11N_DRAFT3 */
#ifdef WPA_SUPPLICANT_SUPPORT

			if (pStaCfg->bAutoReconnect == TRUE &&
				pAd->IndicateMediaState != NdisMediaStateConnected &&
				(pStaCfg->wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_ENABLE_WITH_WEB_UI)) {
				BssTableSsidSort(pAd, &pStaCfg->wdev, &pStaCfg->MlmeAux.SsidBssTab, (PCHAR)pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen);
				pStaCfg->MlmeAux.BssIdx = 0;
				IterateOnBssTab(pAd, Elem->wdev);
			}

#endif /* WPA_SUPPLICANT_SUPPORT */

			if (Status == MLME_SUCCESS) {
#ifdef WIDI_SUPPORT

				if (pStaCfg->MlmeAux.OldChannel == 0)
#endif /* WIDI_SUPPORT */
				{
					/*
					 *	Maintain Scan Table
					 *	MaxBeaconRxTimeDiff: 120 seconds
					 *	MaxSameBeaconRxTimeCount: 1
					 */
#ifdef CONFIG_MULTI_CHANNEL
					bss_table_maintenance(pAd, &pStaCfg->wdev, &pAd->ScanTab, 120, 4);
#else
					bss_table_maintenance(pAd, &pStaCfg->wdev, &pAd->ScanTab, 120, 2);
#endif /* !CONFIG_MULTI_CHANNEL */
				}

#ifdef P2P_SUPPORT

				if (!((pStaCfg->MlmeAux.ScanType == SCAN_P2P_SEARCH) || (pStaCfg->MlmeAux.ScanType == SCAN_P2P)))
#endif /* P2P_SUPPORT */
				{
					RTMPSendWirelessEvent(pAd, IW_SCAN_COMPLETED_EVENT_FLAG, NULL, BSS0, 0);
#ifdef WPA_SUPPLICANT_SUPPORT
					RtmpOSWrielessEventSend(pAd->net_dev, RT_WLAN_EVENT_SCAN, -1, NULL, NULL, 0);
#endif /* WPA_SUPPLICANT_SUPPORT */
				}

#ifdef P2P_SUPPORT

				if (pAd->P2pCfg.P2pCounter.bStartScan &&
					((pStaCfg->MlmeAux.ScanType == SCAN_P2P) || (pStaCfg->MlmeAux.ScanType == SCAN_P2P_SEARCH))) {
#ifdef DPA_S

					if (pStaCfg->MlmeAux.ScanType == SCAN_P2P)
						RtmpOSWrielessEventSend(pAd->p2p_dev, RT_WLAN_EVENT_CUSTOM, P2P_NOTIF_DISCOVER_START_SEARCH_LISTEN, NULL, NULL, 0);

					if (pStaCfg->MlmeAux.ScanType == SCAN_P2P_SEARCH)
						RtmpOSWrielessEventSend(pAd->p2p_dev, RT_WLAN_EVENT_CUSTOM, P2P_NOTIF_DISCOVER_SEARCH_LISTEN_ITERATION, NULL, NULL, 0);

#endif /* DPA_S */

					if (P2P_GO_ON(pAd))
						P2PSetNextScanTimer(pAd, 10);
					else
						P2PSetListenTimer(pAd, 0);
				}

				pAd->P2pCfg.bPeriodicListen = TRUE;
#endif /* P2P_SUPPORT */
			}

#ifdef IWSC_SUPPORT

			if (pStaCfg->BssType == BSS_ADHOC) {
				MlmeEnqueueWithWdev(pAd, IWSC_STATE_MACHINE, IWSC_MT2_MLME_SCAN_DONE, 0, NULL, 0, Elem->wdev);
				RTMP_MLME_HANDLER(pAd);
			}

#endif /* IWSC_SUPPORT */
		}

		break;

	case CNTL_WAIT_OID_DISASSOC:
		if (Elem->MsgType == MT2_DISASSOC_CONF) {
			LinkDown(pAd, FALSE, Elem->wdev);
			/*
			 * for android system , if connect ap1 and want to change to ap2 ,
			 * when disassoc from ap1 ,and send even_scan will direct connect to ap2 , not need to wait ui to scan and connect
			 */
#if 0
#ifdef ANDROID_SUPPORT
			RtmpOSWrielessEventSend(pAd->net_dev, RT_WLAN_EVENT_SCAN, -1, NULL, NULL, 0);
#endif /* ANDROID_SUPPORT */
#endif

			if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS)) {
				pStaCfg->CntlMachine.CurrState = CNTL_WAIT_OID_LIST_SCAN;
				CFG80211DBG(DBG_LVL_ERROR, ("[%s] BSS_SCAN_IN_PROGRESS, Set CntlMachine to CNTL_WAIT_OID_LIST_SCAN state\n", __func__));
			} else
				pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
		}

		break;

	case CNTL_WAIT_SCAN_FOR_CONNECT:
		if (Elem->MsgType == MT2_SCAN_CONF) {
			USHORT	Status = MLME_SUCCESS;

			NdisMoveMemory(&Status, Elem->Msg, sizeof(USHORT));
			pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
			BssTableSsidSort(pAd, &pStaCfg->wdev, &pStaCfg->MlmeAux.SsidBssTab, (PCHAR)pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen);
			pStaCfg->MlmeAux.BssIdx = 0;
			IterateOnBssTab(pAd, Elem->wdev);
		}

		break;
#if 0
#ifdef RTMP_MAC_USB

	/* */
	/* This state is for that we want to connect to an AP but */
	/* it didn't find on BSS List table. So we need to scan the air first, */
	/* after that we can try to connect to the desired AP if available. */
	/* */
	case CNTL_WAIT_SCAN_FOR_CONNECT:
		if (Elem->MsgType == MT2_SCAN_CONF) {
			/* Resume TxRing after SCANING complete. We hope the out-of-service time */
			/* won't be too long to let upper layer time-out the waiting frames */
			RTMPResumeMsduTransmission(pAd);
#ifdef CCX_SUPPORT

			if (pStaCfg->CCXReqType != MSRN_TYPE_UNUSED) {
				/* Cisco scan request is finished, prepare beacon report */
				MlmeEnqueue(pAd, AIRONET_STATE_MACHINE,
							MT2_AIRONET_SCAN_DONE, 0, NULL, 0);
			}

#endif /* CCX_SUPPORT */
			pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
			/* */
			/* Check if we can connect to. */
			/* */
			BssTableSsidSort(pAd, &pStaCfg->MlmeAux.SsidBssTab,
							 (CHAR *) pStaCfg->MlmeAux.
							 AutoReconnectSsid,
							 pStaCfg->MlmeAux.AutoReconnectSsidLen);
#ifdef WSC_STA_SUPPORT
#ifdef WSC_LED_SUPPORT

			if ((pStaCfg->MlmeAux.SsidBssTab.BssNr == 0)
				&& (pStaCfg->BssType == BSS_INFRA)) {
				LEDConnectionStart(pAd);
				LEDConnectionCompletion(pAd, FALSE);
			}

#endif /* WSC_LED_SUPPORT */
#endif /* WSC_STA_SUPPORT */

			if (pStaCfg->MlmeAux.SsidBssTab.BssNr > 0)
				MlmeAutoReconnectLastSSID(pAd);
		}

		break;
#endif /* RTMP_MAC_USB */
#endif

	default:
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("!ERROR! CNTL - Illegal message type(=%ld)",
				 Elem->MsgType));
		break;
	}
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlIdleProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	MLME_DISASSOC_REQ_STRUCT DisassocReq;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	if (IsHcRadioCurStatOffByWdev(Elem->wdev))
		return;

	switch (Elem->MsgType) {
	case OID_802_11_SSID:
		CntlOidSsidProc(pAd, Elem);
		break;

	case OID_802_11_BSSID:
		CntlOidRTBssidProc(pAd, Elem);
		break;

	case OID_802_11_BSSID_LIST_SCAN:
		CntlOidScanProc(pAd, Elem);
		break;

	case OID_802_11_DISASSOCIATE:
		DisassocParmFill(pAd, &DisassocReq, pStaCfg->Bssid,
						 REASON_DISASSOC_STA_LEAVING);
		MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE, MT2_MLME_DISASSOC_REQ,
							sizeof(MLME_DISASSOC_REQ_STRUCT), &DisassocReq, 0, Elem->wdev);
		pStaCfg->CntlMachine.CurrState = CNTL_WAIT_OID_DISASSOC;
#ifdef WPA_SUPPLICANT_SUPPORT

		if ((pStaCfg->wpa_supplicant_info.WpaSupplicantUP & 0x7F) !=
			WPA_SUPPLICANT_ENABLE_WITH_WEB_UI)
#endif /* WPA_SUPPLICANT_SUPPORT */
		{
			/* Set the AutoReconnectSsid to prevent it reconnect to old SSID */
			/* Since calling this indicate user don't want to connect to that SSID anymore. */
			pStaCfg->MlmeAux.AutoReconnectSsidLen = 32;
			NdisZeroMemory(pStaCfg->MlmeAux.AutoReconnectSsid,
						   pStaCfg->MlmeAux.AutoReconnectSsidLen);
		}

		break;

	case MT2_MLME_ROAMING_REQ:
		CntlMlmeRoamingProc(pAd, Elem);
		break;

	case OID_802_11_MIC_FAILURE_REPORT_FRAME:
		WpaMicFailureReportFrame(pAd, Elem);
		break;
#ifdef DOT11Z_TDLS_SUPPORT

	case RT_OID_802_11_SET_TDLS_PARAM:
		TDLS_CntlOidTDLSRequestProc(pAd, Elem);
		break;
#endif /* DOT11Z_TDLS_SUPPORT */

	default:
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("CNTL - Illegal message in CntlIdleProc(MsgType=%ld)\n",
				  Elem->MsgType));
		break;
	}
}

VOID CntlOidScanProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	MLME_SCAN_REQ_STRUCT ScanReq;
	ULONG BssIdx = BSS_NOT_FOUND;
	/*	BSS_ENTRY                  CurrBss; */
	BSS_ENTRY *pCurrBss = NULL;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef CONFIG_ATE

	/* Disable scanning when ATE is running. */
	if (ATE_ON(pAd))
		return;

#endif /* CONFIG_ATE */
#ifdef P2P_SUPPORT

	if (pAd->P2pCfg.P2pCounter.bStartScan == TRUE)
		return;

#endif /* P2P_SUPPORT */
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("CNTL - SCAN starts\n"));
#endif /* RELEASE_EXCLUDE */
	/* allocate memory */
	os_alloc_mem(NULL, (UCHAR **)&pCurrBss, sizeof(BSS_ENTRY));

	if (pCurrBss == NULL) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s: Allocate memory fail!!!\n", __func__));
		return;
	}

	/* record current BSS if network is connected. */
	/* 2003-2-13 do not include current IBSS if this is the only STA in this IBSS. */
	if (STA_STATUS_TEST_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED)) {
		BssIdx = BssSsidTableSearch(&pAd->ScanTab, pStaCfg->Bssid,
									(PUCHAR) pStaCfg->Ssid,
									pStaCfg->SsidLen,
									pStaCfg->wdev.channel);

		if (BssIdx != BSS_NOT_FOUND) {
			NdisMoveMemory(pCurrBss, &pAd->ScanTab.BssEntry[BssIdx],
						   sizeof(BSS_ENTRY));
		}
	}

#if 0
	/* clean up previous SCAN result, add current BSS back to table if any */
	BssTableInit(&pAd->ScanTab);

	if (BssIdx != BSS_NOT_FOUND) {
		/* DDK Note: If the NIC is associated with a particular BSSID and SSID */
		/*    that are not contained in the list of BSSIDs generated by this scan, the */
		/*    BSSID description of the currently associated BSSID and SSID should be */
		/*    appended to the list of BSSIDs in the NIC's database. */
		/* To ensure this, we append this BSS as the first entry in SCAN result */
		NdisMoveMemory(&pAd->ScanTab.BssEntry[0], pCurrBss,
					   sizeof(BSS_ENTRY));
		pAd->ScanTab.BssNr = 1;
	}

#endif
#ifdef WIDI_SUPPORT

	if (pStaCfg->bWIDI)
		ScanParmFill(pAd, &ScanReq, (RTMP_STRING *)Elem->Msg, Elem->MsgLen, BSS_ANY, SCAN_PASSIVE);
	else
#endif /* WIDI_SUPPORT */
		ScanParmFill(pAd, &ScanReq, (RTMP_STRING *) Elem->Msg, Elem->MsgLen, BSS_ANY, Elem->Priv);

	MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_SCAN_REQ,
						sizeof(MLME_SCAN_REQ_STRUCT), &ScanReq, 0, Elem->wdev);
	pStaCfg->CntlMachine.CurrState = CNTL_WAIT_OID_LIST_SCAN;

	if (pCurrBss != NULL)
		os_free_mem(pCurrBss);
}


/*
 *	==========================================================================
 *	Description:
 *		Before calling this routine, user desired SSID should already been
 *		recorded in CommonCfg.Ssid[]
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlOidSsidProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	PNDIS_802_11_SSID pOidSsid = (NDIS_802_11_SSID *) Elem->Msg;
	MLME_DISASSOC_REQ_STRUCT DisassocReq;
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef DOT11R_FT_SUPPORT
	pStaCfg->Dot11RCommInfo.bInMobilityDomain = FALSE;
	pStaCfg->Dot11RCommInfo.FtRspSuccess = 0;
#endif /* DOT11R_FT_SUPPORT */
	/* Step 1. record the desired user settings to MlmeAux */
	NdisZeroMemory(pStaCfg->MlmeAux.Ssid, MAX_LEN_OF_SSID);
	NdisMoveMemory(pStaCfg->MlmeAux.Ssid, pOidSsid->Ssid, pOidSsid->SsidLength);
	pStaCfg->MlmeAux.SsidLen = (UCHAR) pOidSsid->SsidLength;

	if (pStaCfg->BssType == BSS_INFRA)
		NdisZeroMemory(pStaCfg->MlmeAux.Bssid, MAC_ADDR_LEN);

	pStaCfg->MlmeAux.BssType = pStaCfg->BssType;
	pStaCfg->bAutoConnectByBssid = FALSE;
	/*save connect info*/
	NdisZeroMemory(pStaCfg->ConnectinfoSsid, MAX_LEN_OF_SSID);
	NdisMoveMemory(pStaCfg->ConnectinfoSsid, pOidSsid->Ssid, pOidSsid->SsidLength);
	pStaCfg->ConnectinfoSsidLen = pOidSsid->SsidLength;
	pStaCfg->ConnectinfoBssType = pStaCfg->BssType;
#ifdef WSC_STA_SUPPORT
	/* for M8 */
	NdisZeroMemory(pStaCfg->Ssid, MAX_LEN_OF_SSID);
	NdisMoveMemory(pStaCfg->Ssid, pOidSsid->Ssid, pOidSsid->SsidLength);
	pStaCfg->SsidLen = (UCHAR) pOidSsid->SsidLength;
#endif /* WSC_STA_SUPPORT */
	/* Update Reconnect Ssid, that user desired to connect. */
	NdisZeroMemory(pStaCfg->MlmeAux.AutoReconnectSsid, MAX_LEN_OF_SSID);
	NdisMoveMemory(pStaCfg->MlmeAux.AutoReconnectSsid, pStaCfg->MlmeAux.Ssid,
				   pStaCfg->MlmeAux.SsidLen);
	pStaCfg->MlmeAux.AutoReconnectSsidLen = pStaCfg->MlmeAux.SsidLen;
	/*
	 *	step 2.
	 *	find all matching BSS in the lastest SCAN result (inBssTab)
	 *	and log them into MlmeAux.SsidBssTab for later-on iteration. Sort by RSSI order
	 */
	BssTableSsidSort(pAd, &pStaCfg->wdev, &pStaCfg->MlmeAux.SsidBssTab,
					 (PCHAR) pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("CntlOidSsidProc():CNTL - %d BSS of %d BSS match the desire ",
			  pStaCfg->MlmeAux.SsidBssTab.BssNr, pAd->ScanTab.BssNr));

	if (pStaCfg->MlmeAux.SsidLen == MAX_LEN_OF_SSID)
		hex_dump("\nSSID", pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen);
	else
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("(%d)SSID - %s\n", pStaCfg->MlmeAux.SsidLen,
				  pStaCfg->MlmeAux.Ssid));

	if (INFRA_ON(pStaCfg) &&
		STA_STATUS_TEST_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED) &&
		(pStaCfg->SsidLen == pStaCfg->MlmeAux.SsidBssTab.BssEntry[0].SsidLen)
		&& NdisEqualMemory(pStaCfg->Ssid, pStaCfg->MlmeAux.SsidBssTab.BssEntry[0].Ssid, pStaCfg->SsidLen)
		&& MAC_ADDR_EQUAL(pStaCfg->Bssid, pStaCfg->MlmeAux.SsidBssTab.BssEntry[0].Bssid)) {
		/*
		 *	Case 1. already connected with an AP who has the desired SSID
		 *			with highest RSSI
		 */

		/* Add checking Mode "LEAP" for CCX 1.0 */
		if ((IS_AKM_WPA_CAPABILITY_Entry(wdev)
#ifdef WAPI_SUPPORT
			 || IS_AKM_WAICERT(wdev->SecConfig.AKMMap)
			 || IS_AKM_WPIPSK(wdev->SecConfig.AKMMap)
#endif /* WAPI_SUPPORT */
			) &&
			(wdev->PortSecured == WPA_802_1X_PORT_NOT_SECURED)) {
			/*
			 *	case 1.1 For WPA, WPA-PSK,
			 *	if port is not secured, we have to redo connection process
			 */
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CntlOidSsidProc():CNTL - disassociate with current AP...\n"));
			DisassocParmFill(pAd, &DisassocReq,
							 pStaCfg->Bssid,
							 REASON_DISASSOC_STA_LEAVING);
			MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE,
								MT2_MLME_DISASSOC_REQ,
								sizeof(MLME_DISASSOC_REQ_STRUCT),
								&DisassocReq, 0, wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_WAIT_DISASSOC;
		} else if (pStaCfg->bConfigChanged == TRUE) {
			/* case 1.2 Important Config has changed, we have to reconnect to the same AP */
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CntlOidSsidProc():CNTL - disassociate with current AP Because config changed...\n"));
			DisassocParmFill(pAd, &DisassocReq,
							 pStaCfg->Bssid,
							 REASON_DISASSOC_STA_LEAVING);
			MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE,
								MT2_MLME_DISASSOC_REQ,
								sizeof(MLME_DISASSOC_REQ_STRUCT),
								&DisassocReq, 0, wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_WAIT_DISASSOC;
		} else {
			/* case 1.3. already connected to the SSID with highest RSSI. */
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CntlOidSsidProc():CNTL - already with this BSSID. ignore this SET_SSID request\n"));

			/*
			 *	(HCT 12.1) 1c_wlan_mediaevents required
			 *	media connect events are indicated when associating with the same AP
			 */
			if (INFRA_ON(pStaCfg)) {
				/*
				 *	Since MediaState already is NdisMediaStateConnected
				 *	We just indicate the connect event again to meet the WHQL required.
				 */
				RTMP_IndicateMediaState(pAd, NdisMediaStateConnected);
				pAd->ExtraInfo = GENERAL_LINK_UP;	/* Update extra information to link is up */
			}

			pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT
			RtmpOSWrielessEventSend(pAd->net_dev,
									RT_WLAN_EVENT_CGIWAP, -1,
									&pStaCfg->MlmeAux.Bssid[0], NULL,
									0);
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
		}
	} else if (INFRA_ON(pStaCfg)) {
		/*
		 *	For RT61
		 *	[88888] OID_802_11_SSID should have returned NDTEST_WEP_AP2(Returned: )
		 *	RT61 may lost SSID, and not connect to NDTEST_WEP_AP2 and will connect to NDTEST_WEP_AP2 by Autoreconnect
		 *	But media status is connected, so the SSID not report correctly.
		 */
		if (!SSID_EQUAL(pStaCfg->Ssid, pStaCfg->SsidLen, pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen)) {
			/* Different SSID means not Roaming case, so we let LinkDown() to Indicate a disconnect event. */
			pStaCfg->MlmeAux.CurrReqIsFromNdis = TRUE;
		}

		/*
		 *	case 2. active INFRA association existent
		 *	Roaming is done within miniport driver, nothing to do with configuration
		 *	utility. so upon a new SET(OID_802_11_SSID) is received, we just
		 *	disassociate with the current associated AP,
		 *	then perform a new association with this new SSID, no matter the
		 *	new/old SSID are the same or not.
		 */
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("CntlOidSsidProc():CNTL - disassociate with current AP...\n"));
		DisassocParmFill(pAd, &DisassocReq, pStaCfg->Bssid,
						 REASON_DISASSOC_STA_LEAVING);
		MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE, MT2_MLME_DISASSOC_REQ,
							sizeof(MLME_DISASSOC_REQ_STRUCT), &DisassocReq, 0, wdev);
		pStaCfg->CntlMachine.CurrState = CNTL_WAIT_DISASSOC;
	} else {
		if (ADHOC_ON(pAd)) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CntlOidSsidProc():CNTL - drop current ADHOC\n"));
			LinkDown(pAd, FALSE, Elem->wdev);
			STA_STATUS_CLEAR_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED);
			RTMP_IndicateMediaState(pAd, NdisMediaStateDisconnected);
			pAd->ExtraInfo = GENERAL_LINK_DOWN;
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CntlOidSsidProc():NDIS_STATUS_MEDIA_DISCONNECT Event C!\n"));
		}

		if ((pStaCfg->MlmeAux.SsidBssTab.BssNr == 0) &&
			(pStaCfg->bAutoReconnect == TRUE) &&
			(((pStaCfg->MlmeAux.BssType == BSS_INFRA) && (!RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS)))
			 || ((pStaCfg->MlmeAux.BssType == BSS_ADHOC) && !pStaCfg->bNotFirstScan))
			&& (MlmeValidateSSID(pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen) == TRUE)
		   ) {
			MLME_SCAN_REQ_STRUCT ScanReq;

			if (pStaCfg->MlmeAux.BssType == BSS_ADHOC)
				pStaCfg->bNotFirstScan = TRUE;

			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CntlOidSsidProc():CNTL - No matching BSS, start a new scan\n"));
#if 0
			BssTableInit(&pAd->ScanTab);
#endif

			if ((pStaCfg->ConnectinfoChannel != 0) && (pStaCfg->Connectinfoflag == TRUE)) {
				ScanParmFill(pAd, &ScanReq, (RTMP_STRING *) pStaCfg->MlmeAux.Ssid,
							 pStaCfg->MlmeAux.SsidLen, BSS_ANY, SCAN_ACTIVE);
				MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_FORCE_SCAN_REQ,
									sizeof(MLME_SCAN_REQ_STRUCT), &ScanReq, 0, wdev);
				pStaCfg->CntlMachine.CurrState =	CNTL_WAIT_SCAN_FOR_CONNECT;
			} else {
#ifdef WIDI_SUPPORT

				if (pStaCfg->bWIDI) {
					if (pStaCfg->MlmeAux.OldChannel > 0)
						pStaCfg->MlmeAux.Channel = pStaCfg->MlmeAux.OldChannel;

					ScanParmFill(pAd, &ScanReq, (RTMP_STRING *) pStaCfg->MlmeAux.Ssid,
								 pStaCfg->MlmeAux.SsidLen, BSS_ANY, SCAN_PASSIVE);
				} else
#endif /* WIDI_SUPPORT */
					ScanParmFill(pAd, &ScanReq, (RTMP_STRING *) pStaCfg->MlmeAux.Ssid,
								 pStaCfg->MlmeAux.SsidLen, BSS_ANY, SCAN_ACTIVE);

				MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_SCAN_REQ,
									sizeof(MLME_SCAN_REQ_STRUCT), &ScanReq, 0, wdev);
				pStaCfg->CntlMachine.CurrState = CNTL_WAIT_OID_LIST_SCAN;
			}

			/* Reset Missed scan number */
			NdisGetSystemUpTime(&pStaCfg->LastScanTime);
		} else {
#ifdef WSC_STA_SUPPORT
#ifdef WSC_LED_SUPPORT

			/* LED indication. */
			if (pStaCfg->MlmeAux.BssType == BSS_INFRA)
				LEDConnectionStart(pAd);

#endif /* WSC_LED_SUPPORT */
#endif /* WSC_STA_SUPPORT */

			if ((pAd->CommonCfg.CountryRegion & 0x7f) == REGION_33_BG_BAND) {
				BSS_ENTRY *entry;
				/* TODO: shiang-6590, check this "SavedPhyMode"! */
				entry = &pStaCfg->MlmeAux.SsidBssTab.BssEntry[pStaCfg->MlmeAux.BssIdx];

				if ((entry->Channel == 14) && (pAd->CommonCfg.SavedPhyMode == 0xff)) {
					pAd->CommonCfg.SavedPhyMode = wdev->PhyMode;
					RTMPSetPhyMode(pAd, wdev, WMODE_B);
				} else if (pAd->CommonCfg.SavedPhyMode != 0xff) {
					RTMPSetPhyMode(pAd, wdev, pAd->CommonCfg.SavedPhyMode);
					pAd->CommonCfg.SavedPhyMode = 0xFF;
				} else {
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s():SavedPhyMode=0x%x! Channel=%d\n",
							 __func__, pAd->CommonCfg.SavedPhyMode, entry->Channel));
				}
			}

			pStaCfg->MlmeAux.BssIdx = 0;
			IterateOnBssTab(pAd, Elem->wdev);
		}

#ifdef RT_CFG80211_SUPPORT

		if ((pStaCfg->MlmeAux.SsidBssTab.BssNr == 0) && (pStaCfg->MlmeAux.BssType == BSS_INFRA)
			&& (pAd->cfg80211_ctrl.FlgCfg80211Connecting == TRUE)) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CFG80211_MLME: No matching BSS, Report cfg80211_layer SM to Idle --> %ld\n",
					 pStaCfg->CntlMachine.CurrState));
			pAd->cfg80211_ctrl.Cfg_pending_SsidLen = pStaCfg->MlmeAux.SsidLen;
			NdisZeroMemory(pAd->cfg80211_ctrl.Cfg_pending_Ssid, MAX_LEN_OF_SSID + 1);
			NdisMoveMemory(pAd->cfg80211_ctrl.Cfg_pending_Ssid, pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen);
			RT_CFG80211_CONN_RESULT_INFORM(pAd, pStaCfg->MlmeAux.Bssid, NULL, 0, NULL, 0, 0);
		}

#endif /* RT_CFG80211_SUPPORT */
	}
}

#ifdef WSC_STA_SUPPORT
/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlWscIterate(RTMP_ADAPTER *pAd, PSTA_ADMIN_CONFIG sta_cfg)
{
#ifdef WSC_LED_SUPPORT
	UCHAR WPSLEDStatus;
#endif /* WSC_LED_SUPPORT */
	struct wifi_dev *wdev;

	wdev = &sta_cfg->wdev;

	/* Connect to the WPS-enabled AP by its BSSID directly. */
	/* Note: When WscState is equal to WSC_STATE_START, */
	/*       pStaCfg->WscControl.WscAPBssid has been filled with valid BSSID. */
	if ((wdev->WscControl.WscState >= WSC_STATE_START) &&
		(wdev->WscControl.WscStatus != STATUS_WSC_SCAN_AP)) {
		/* Set WSC state to WSC_STATE_START */
		wdev->WscControl.WscState = WSC_STATE_START;
		wdev->WscControl.WscStatus = STATUS_WSC_START_ASSOC;

		if (sta_cfg->BssType == BSS_INFRA) {
			MlmeEnqueueWithWdev(pAd,
								MLME_CNTL_STATE_MACHINE,
								OID_802_11_BSSID,
								MAC_ADDR_LEN,
								wdev->WscControl.WscBssid, 0, wdev);
		} else {
			MlmeEnqueueWithWdev(pAd,
								MLME_CNTL_STATE_MACHINE,
								OID_802_11_SSID,
								sizeof(NDIS_802_11_SSID),
								(VOID *)&wdev->WscControl.WscSsid,
								0, wdev);
		}

		sta_cfg->CntlMachine.CurrState = CNTL_IDLE;
		RTMP_MLME_HANDLER(pAd);
	}

#ifdef WSC_LED_SUPPORT
	/* The protocol is connecting to a partner. */
	WPSLEDStatus = LED_WPS_IN_PROCESS;
	RTMPSetLED(pAd, WPSLEDStatus);
#endif /* WSC_LED_SUPPORT */
}
#endif /* WSC_STA_SUPPORT */

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlOidRTBssidProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	ULONG BssIdx;
	PUCHAR pOidBssid = (PUCHAR) Elem->Msg;
	MLME_DISASSOC_REQ_STRUCT DisassocReq;
	MLME_JOIN_REQ_STRUCT JoinReq;
	BSS_ENTRY *pInBss = NULL;
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
#ifdef WSC_STA_SUPPORT
	PWSC_CTRL pWpsCtrl;
#endif /* WSC_STA_SUPPORT */
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef WSC_STA_SUPPORT
	pWpsCtrl = &pStaCfg->wdev.WscControl;
#endif /* WSC_STA_SUPPORT */
#ifdef CONFIG_ATE

	/* No need to perform this routine when ATE is running. */
	if (ATE_ON(pAd))
		return;

#endif /* CONFIG_ATE */
	/* record user desired settings */
	COPY_MAC_ADDR(pStaCfg->MlmeAux.Bssid, pOidBssid);
	pStaCfg->MlmeAux.BssType = pStaCfg->BssType;
	/*save connect info*/
	NdisZeroMemory(pStaCfg->ConnectinfoBssid, MAC_ADDR_LEN);
	NdisMoveMemory(pStaCfg->ConnectinfoBssid, pOidBssid, MAC_ADDR_LEN);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("ANDROID IOCTL::SIOCSIWAP %02x:%02x:%02x:%02x:%02x:%02x\n",
			 PRINT_MAC(pStaCfg->ConnectinfoBssid)));
	/* find the desired BSS in the latest SCAN result table */
	BssIdx = BssTableSearch(&pAd->ScanTab, pOidBssid, pStaCfg->MlmeAux.Channel);
#ifdef WPA_SUPPLICANT_SUPPORT

	if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP & WPA_SUPPLICANT_ENABLE_WPS)
		;
	else
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT
		if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP & WPA_SUPPLICANT_ENABLE)
			;
		else
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif /* WPA_SUPPLICANT_SUPPORT */
			if (
#ifdef WSC_STA_SUPPORT
				(pWpsCtrl->WscConfMode == WSC_DISABLE) &&
#endif /* WSC_STA_SUPPORT */
				(BssIdx != BSS_NOT_FOUND)) {
				pInBss = &pAd->ScanTab.BssEntry[BssIdx];

				/*
				 *	If AP's SSID has been changed, STA cannot connect to this AP.
				 */
				if (SSID_EQUAL(pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen, pInBss->Ssid, pInBss->SsidLen) == FALSE)
					BssIdx = BSS_NOT_FOUND;

				if (IS_AKM_OPEN(wdev->SecConfig.AKMMap)
					|| IS_AKM_SHARED(wdev->SecConfig.AKMMap)
					|| IS_AKM_AUTOSWITCH(wdev->SecConfig.AKMMap)) {
					if (wdev->SecConfig.PairwiseCipher != pInBss->PairwiseCipher)
						BssIdx = BSS_NOT_FOUND;
				} else {
					/* Check AuthMode and AuthModeAux for matching, in case AP support dual-mode */
					if (wdev->SecConfig.AKMMap != pInBss->AKMMap)
						BssIdx = BSS_NOT_FOUND;
				}
			}

#ifdef WSC_STA_SUPPORT

	if ((pWpsCtrl->WscConfMode != WSC_DISABLE) &&
		((pWpsCtrl->WscStatus == STATUS_WSC_START_ASSOC) || (pWpsCtrl->WscStatus == STATUS_WSC_LINK_UP)) &&
		(pStaCfg->bSkipAutoScanConn == TRUE))
		pStaCfg->bSkipAutoScanConn = FALSE;

#endif /* WSC_STA_SUPPORT */

	if (BssIdx == BSS_NOT_FOUND) {
		if (((pStaCfg->BssType == BSS_INFRA) && (!RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS))) ||
			(pStaCfg->bNotFirstScan == FALSE)) {
			MLME_SCAN_REQ_STRUCT ScanReq;

			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - BSSID not found. reply NDIS_STATUS_NOT_ACCEPTED\n"));

			if (pStaCfg->BssType == BSS_ADHOC)
				pStaCfg->bNotFirstScan = TRUE;

			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - BSSID not found. start a new scan\n"));
#if 0
			BssTableInit(&pAd->ScanTab);
#endif

			if ((pStaCfg->ConnectinfoChannel  != 0) && (pStaCfg->Connectinfoflag == TRUE)) {
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("CntlOidRTBssidProc BSSID %02x:%02x:%02x:%02x:%02x:%02x\n",
						 PRINT_MAC(pStaCfg->ConnectinfoBssid)));
				wdev->channel = pStaCfg->ConnectinfoChannel;
				MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_FORCE_JOIN_REQ,
									sizeof(MLME_JOIN_REQ_STRUCT), &JoinReq, 0, wdev);
				pStaCfg->CntlMachine.CurrState = CNTL_WAIT_JOIN;
			} else	{
				ScanParmFill(pAd, &ScanReq, (RTMP_STRING *) pStaCfg->MlmeAux.Ssid,
							 pStaCfg->MlmeAux.SsidLen, BSS_ANY, SCAN_ACTIVE);
				MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_SCAN_REQ,
									sizeof(MLME_SCAN_REQ_STRUCT), &ScanReq, 0, wdev);
				pStaCfg->CntlMachine.CurrState = CNTL_WAIT_OID_LIST_SCAN;
			}

			/* Reset Missed scan number */
			NdisGetSystemUpTime(&pStaCfg->LastScanTime);
		} else {
			MLME_START_REQ_STRUCT StartReq;

			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - BSSID not found. start a new ADHOC (Ssid=%s)...\n",
					  pStaCfg->MlmeAux.Ssid));
			StartParmFill(pAd, &StartReq, (PCHAR)pStaCfg->MlmeAux.Ssid,
						  pStaCfg->MlmeAux.SsidLen);
			MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_START_REQ,
								sizeof(MLME_START_REQ_STRUCT), &StartReq, 0, wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_WAIT_START;
		}

		return;
	}

	pInBss = &pAd->ScanTab.BssEntry[BssIdx];
	/* Update Reconnect Ssid, that user desired to connect. */
	NdisZeroMemory(pStaCfg->MlmeAux.AutoReconnectSsid, MAX_LEN_OF_SSID);
	pStaCfg->MlmeAux.AutoReconnectSsidLen = pInBss->SsidLen;
	NdisMoveMemory(pStaCfg->MlmeAux.AutoReconnectSsid, pInBss->Ssid, pInBss->SsidLen);
	/* copy the matched BSS entry from ScanTab to MlmeAux.SsidBssTab. Why? */
	/* Because we need this entry to become the JOIN target in later on SYNC state machine */
	pStaCfg->MlmeAux.BssIdx = 0;
	pStaCfg->MlmeAux.SsidBssTab.BssNr = 1;
	NdisMoveMemory(&pStaCfg->MlmeAux.SsidBssTab.BssEntry[0], pInBss,
				   sizeof(BSS_ENTRY));
	{
		if (INFRA_ON(pStaCfg)) {
			/* disassoc from current AP first */
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - disassociate with current AP ...\n"));
			DisassocParmFill(pAd, &DisassocReq,
							 pStaCfg->Bssid,
							 REASON_DISASSOC_STA_LEAVING);
			MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE,
								MT2_MLME_DISASSOC_REQ,
								sizeof(MLME_DISASSOC_REQ_STRUCT),
								&DisassocReq, 0, wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_WAIT_DISASSOC;
		} else {
			if (ADHOC_ON(pAd)) {
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("CNTL - drop current ADHOC\n"));
				LinkDown(pAd, FALSE, wdev);
				STA_STATUS_CLEAR_FLAG(pStaCfg,
									  fSTA_STATUS_MEDIA_STATE_CONNECTED);
				RTMP_IndicateMediaState(pAd,
										NdisMediaStateDisconnected);
				pAd->ExtraInfo = GENERAL_LINK_DOWN;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("NDIS_STATUS_MEDIA_DISCONNECT Event C!\n"));
			}

			pInBss = &pStaCfg->MlmeAux.SsidBssTab.BssEntry[0];
			pStaCfg->PairwiseCipher = wdev->SecConfig.PairwiseCipher;
#ifdef WPA_SUPPLICANT_SUPPORT

			if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP == WPA_SUPPLICANT_DISABLE)
#endif /* WPA_SUPPLICANT_SUPPORT */
				pStaCfg->GroupCipher = wdev->SecConfig.GroupCipher;

			/*Check AuthMode of AP, may have more AuthMode Supported,eg WPA/WPA2*/
			/*Set the AKMMap according to sta/AP capablities */
			if (IS_AKM_WPA1(wdev->SecConfig.AKMMap) && IS_AKM_WPA2(wdev->SecConfig.AKMMap)) {
				CLEAR_SEC_AKM(pStaCfg->AKMMap);
				SET_AKM_WPA2(pStaCfg->AKMMap);
			} else if (IS_AKM_WPA1PSK(wdev->SecConfig.AKMMap) && IS_AKM_WPA2PSK(wdev->SecConfig.AKMMap)) {
				CLEAR_SEC_AKM(pStaCfg->AKMMap);
				SET_AKM_WPA2PSK(pStaCfg->AKMMap);
			} else
				pStaCfg->AKMMap = wdev->SecConfig.AKMMap;

			/* Check cipher suite, AP must have more secured cipher than station setting */
			/* Set the Pairwise and Group cipher to match the intended AP setting */
			/* We can only connect to AP with less secured cipher setting */
			if (IS_AKM_WPA1(wdev->SecConfig.AKMMap)
				|| IS_AKM_WPA1PSK(wdev->SecConfig.AKMMap)) {
				pStaCfg->GroupCipher = pInBss->GroupCipher;
				CLEAR_CIPHER(pStaCfg->PairwiseCipher);

				if (IS_CIPHER_CCMP128(wdev->SecConfig.PairwiseCipher) && IS_CIPHER_CCMP128(pInBss->PairwiseCipher))
					SET_CIPHER_CCMP128(pStaCfg->PairwiseCipher);
				else	/* There is no PairCipher Aux, downgrade our capability to TKIP */
					SET_CIPHER_TKIP(pStaCfg->PairwiseCipher);
			}

			if (IS_AKM_WPA2(wdev->SecConfig.AKMMap)
				|| IS_AKM_WPA2PSK(wdev->SecConfig.AKMMap)) {
				pStaCfg->GroupCipher = pInBss->GroupCipher;
				CLEAR_CIPHER(pStaCfg->PairwiseCipher);

				if (IS_CIPHER_CCMP128(wdev->SecConfig.PairwiseCipher)
					&& IS_CIPHER_CCMP128(pInBss->PairwiseCipher))
					SET_CIPHER_CCMP128(pStaCfg->PairwiseCipher);
				else if (IS_CIPHER_CCMP256(wdev->SecConfig.PairwiseCipher)
						 && IS_CIPHER_CCMP256(pInBss->PairwiseCipher))
					SET_CIPHER_CCMP256(pStaCfg->PairwiseCipher);
				else if (IS_CIPHER_GCMP128(wdev->SecConfig.PairwiseCipher)
						 && IS_CIPHER_GCMP128(pInBss->PairwiseCipher))
					SET_CIPHER_GCMP128(pStaCfg->PairwiseCipher);
				else if (IS_CIPHER_GCMP256(wdev->SecConfig.PairwiseCipher)
						 && IS_CIPHER_GCMP256(pInBss->PairwiseCipher))
					SET_CIPHER_GCMP256(pStaCfg->PairwiseCipher);
				else	/* There is no PairCipher Aux, downgrade our capability to TKIP */
					SET_CIPHER_TKIP(pStaCfg->PairwiseCipher);

				/* RSN capability */
				pStaCfg->RsnCapability = pInBss->RsnCapability;
			}

#ifdef WAPI_SUPPORT
			else if (IS_AKM_WAICERT(wdev->SecConfig.AKMMap)
					 || IS_AKM_WPIPSK(wdev->SecConfig.AKMMap)) {
				pStaCfg->GroupCipher = pInBss->GroupCipher;
				pStaCfg->PairwiseCipher = pInBss->PairwiseCipher;
			}

#endif /* WAPI_SUPPORT */
			/* No active association, join the BSS immediately */
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - joining %02x:%02x:%02x:%02x:%02x:%02x ...\n",
					  PRINT_MAC(pOidBssid)));
			JoinParmFill(pAd, &JoinReq, pStaCfg->MlmeAux.BssIdx);
			MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_JOIN_REQ,
								sizeof(MLME_JOIN_REQ_STRUCT), &JoinReq, 0, wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_WAIT_JOIN;
		}
	}
}

/* Roaming is the only external request triggering CNTL state machine */
/* despite of other "SET OID" operation. All "SET OID" related oerations */
/* happen in sequence, because no other SET OID will be sent to this device */
/* until the the previous SET operation is complete (successful o failed). */
/* So, how do we quarantee this ROAMING request won't corrupt other "SET OID"? */
/* or been corrupted by other "SET OID"? */
/* */
/* IRQL = DISPATCH_LEVEL */
VOID CntlMlmeRoamingProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
#ifdef DOT11R_FT_SUPPORT
	MAC_TABLE_ENTRY *pEntry = GetAssociatedAPByWdev(pAd, Elem->wdev);
	BSS_ENTRY *pTargetAP = &pStaCfg->MlmeAux.RoamTab.BssEntry[0];
#endif /* DOT11R_FT_SUPPORT */
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef DOT11R_FT_SUPPORT
	ASSERT(pEntry);

	if (!pEntry)
		return;

#endif
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CNTL - Roaming in MlmeAux.RoamTab...\n"));
#ifdef DOT11R_FT_SUPPORT

	if (pStaCfg->Dot11RCommInfo.bFtSupport &&
		pStaCfg->Dot11RCommInfo.bInMobilityDomain &&
		(wdev->channel != pTargetAP->Channel)) {
		if (pEntry->MdIeInfo.FtCapPlc.field.FtOverDs) {
			MLME_FT_REQ_STRUCT FtReq;

			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("Dot11r: pBss->Channel = %d. Use OTD.\n",
					  pTargetAP->Channel));
			FT_OTD_ActParmFill(pAd, &FtReq, pTargetAP->Bssid,
							   pTargetAP->AuthMode,
							   &pStaCfg->Dot11RCommInfo.MdIeInfo,
							   &pStaCfg->Dot11RCommInfo.FtIeInfo,
							   pStaCfg->RSNIE_Len,
							   pStaCfg->RSN_IE);
			MlmeEnqueueWithWdev(pAd, FT_OTD_ACT_STATE_MACHINE,
								FT_OTD_MT2_MLME_REQ,
								sizeof(MLME_FT_REQ_STRUCT), &FtReq, 0, wdev);
		} else
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("CNTL - Shall not haapen!!\n"));
	} else
#endif /* DOT11R_FT_SUPPORT */
	{
#ifdef MT76XX_BTCOEX_SUPPORT

		if (IS_MT76XXBTCOMBO(pAd)) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("COEX: ROAMING_START, Remove old protection frame and AFH information\n"));
			pStaCfg->MlmeAux.bStaCanRoam = TRUE;
			COEXLinkDown(pAd, wdev, pAd->CommonCfg.Bssid, wdev->channel);
		}

#endif /*MT76XX_BTCOEX_SUPPORT*/
		/*Let BBP register at 20MHz to do (fast) roaming. */
		wlan_operate_set_ht_bw(wdev, HT_BW_20, EXTCHA_NONE);
		NdisMoveMemory(&pStaCfg->MlmeAux.SsidBssTab, &pStaCfg->MlmeAux.RoamTab,
					   sizeof(pStaCfg->MlmeAux.RoamTab));
		pStaCfg->MlmeAux.SsidBssTab.BssNr = pStaCfg->MlmeAux.RoamTab.BssNr;
		BssTableSortByRssi(&pStaCfg->MlmeAux.SsidBssTab, FALSE);
		pStaCfg->MlmeAux.BssIdx = 0;
		IterateOnBssTab(pAd, Elem->wdev);
	}
}


/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlWaitDisassocProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	MLME_START_REQ_STRUCT StartReq;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	struct wifi_dev *wdev;

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	wdev = Elem->wdev;

	if (Elem->MsgType == MT2_DISASSOC_CONF) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CNTL - Dis-associate successful\n"));
		RTMPSendWirelessEvent(pAd, IW_DISASSOC_EVENT_FLAG, NULL, BSS0,
							  0);
		LinkDown(pAd, FALSE, wdev);

		/* case 1. no matching BSS, and user wants ADHOC, so we just start a new one */
		if ((pStaCfg->MlmeAux.SsidBssTab.BssNr == 0)
			&& (pStaCfg->BssType == BSS_ADHOC)) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - No matching BSS, start a new ADHOC (Ssid=%s)...\n",
					  pStaCfg->MlmeAux.Ssid));
			StartParmFill(pAd, &StartReq, (PCHAR) pStaCfg->MlmeAux.Ssid,
						  pStaCfg->MlmeAux.SsidLen);
			MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_START_REQ,
								sizeof(MLME_START_REQ_STRUCT), &StartReq,
								0, Elem->wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_WAIT_START;
		}
		/* case 2. try each matched BSS */
		else {
			/*
			 *   Some customer would set AP1 & AP2 same SSID, AuthMode & EncrypType but different WPAPSK,
			 *   therefore we need to try next AP here.
			 */
			/*pStaCfg->MlmeAux.BssIdx = 0;*/
			pStaCfg->MlmeAux.BssIdx++;
#ifdef WSC_STA_SUPPORT

			if (wdev->WscControl.WscState >= WSC_STATE_START)
				CntlWscIterate(pAd, pStaCfg);
			else if (((wdev->WscControl.bWscTrigger == FALSE)
#ifdef STA_EASY_CONFIG_SETUP
					  || (wdev->EasyConfigInfo.bDoAutoWps == FALSE)
#endif /* STA_EASY_CONFIG_SETUP */
					 )
					 && (wdev->WscControl.WscState != WSC_STATE_INIT))
#endif /* WSC_STA_SUPPORT */
				IterateOnBssTab(pAd, wdev);

#ifdef WSC_STA_SUPPORT
			else
				pStaCfg->CntlMachine.CurrState = CNTL_IDLE;

#endif /* WSC_STA_SUPPORT */
		}
	}
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlWaitJoinProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	USHORT Reason;
	MLME_AUTH_REQ_STRUCT AuthReq;
	struct wifi_dev *wdev = Elem->wdev;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	if (Elem->MsgType == MT2_JOIN_CONF) {
		NdisMoveMemory(&Reason, Elem->Msg, sizeof(USHORT));

		if (Reason == MLME_SUCCESS) {
			/* 1. joined an IBSS, we are pretty much done here */
			if (pStaCfg->MlmeAux.BssType == BSS_ADHOC) {
				/* */
				/* 5G bands rules of Japan: */
				/* Ad hoc must be disabled in W53(ch52,56,60,64) channels. */
				/* */
				if ((pAd->CommonCfg.bIEEE80211H == 1) &&
					RadarChannelCheck(pAd, wdev->channel)) {
					pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("CNTL - Channel=%d, Join adhoc on W53(52,56,60,64) Channels are not accepted\n",
							  wdev->channel));
					return;
				}

				LinkUp(pAd, BSS_ADHOC, wdev);
				pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("CNTL - join the IBSS = %02x:%02x:%02x:%02x:%02x:%02x ...\n",
						  PRINT_MAC(pStaCfg->Bssid)));
				RTMP_IndicateMediaState(pAd, NdisMediaStateConnected);
				pAd->ExtraInfo = GENERAL_LINK_UP;
				RTMPSendWirelessEvent(pAd, IW_JOIN_IBSS_FLAG, NULL, BSS0, 0);
			}
			/* 2. joined a new INFRA network, start from authentication */
			else {
#ifdef DOT11R_FT_SUPPORT

				if (pStaCfg->Dot11RCommInfo.bFtSupport &&
					pStaCfg->Dot11RCommInfo.bInMobilityDomain) {
					MLME_FT_OTA_AUTH_REQ_STRUCT FtOtaAuthReq;

					FT_OTA_AuthParmFill(pAd,
										&FtOtaAuthReq,
										pStaCfg->MlmeAux.Bssid,
										AUTH_MODE_FT,
										&pStaCfg->Dot11RCommInfo);
					MlmeEnqueueWithWdev(pAd,
										FT_OTA_AUTH_STATE_MACHINE,
										FT_OTA_MT2_MLME_AUTH_REQ,
										sizeof(MLME_FT_OTA_AUTH_REQ_STRUCT),
										&FtOtaAuthReq, 0, Elem->wdev);
				} else
#endif /* DOT11R_FT_SUPPORT */
#ifdef DOT11_SAE_SUPPORT
				if ((IS_AKM_SAE_SHA256(pStaCfg->wdev.SecConfig.AKMMap)
					|| IS_AKM_FT_SAE_SHA256(pStaCfg->wdev.SecConfig.AKMMap))) {
					AuthParmFill(pAd, &AuthReq,
							     pStaCfg->MlmeAux.Bssid,
							     AUTH_MODE_SAE);
					MlmeEnqueueWithWdev(pAd, AUTH_STATE_MACHINE,
						    MT2_MLME_SAE_AUTH_REQ,
						    sizeof(MLME_AUTH_REQ_STRUCT),
						    &AuthReq, 0, Elem->wdev);
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,
							("CNTL(%s) - use SAE\n", __func__));
				} else
#endif /* DOT11_SAE_SUPPORT */
				{
#ifdef WEPAUTO_OPEN_FIRST

					/* Only Ndis802_11AuthModeShared try shared key first, Ndis802_11AuthModeAutoSwitch use open first */
					if (IS_SECURITY_SHARED_WEP_Entry(&pStaCfg->wdev))
#else

					/* either Ndis802_11AuthModeShared or Ndis802_11AuthModeAutoSwitch, try shared key first */
					if (IS_SECURITY_SHARED_WEP_Entry(&pStaCfg->wdev)
						|| IS_SECURITY_AUTOSWITCH_Entry(&pStaCfg->wdev))
#endif
					{
						AuthParmFill(pAd, &AuthReq,
									 pStaCfg->MlmeAux.Bssid,
									 AUTH_MODE_KEY);
					} else {
						AuthParmFill(pAd, &AuthReq,
									 pStaCfg->MlmeAux.Bssid,
									 AUTH_MODE_OPEN);
					}

					MlmeEnqueueWithWdev(pAd, AUTH_STATE_MACHINE,
										MT2_MLME_AUTH_REQ,
										sizeof(MLME_AUTH_REQ_STRUCT),
										&AuthReq, 0, Elem->wdev);
				}

				pStaCfg->CntlMachine.CurrState = CNTL_WAIT_AUTH;
			}
		} else {
#ifdef STA_EASY_CONFIG_SETUP

			if (pStaCfg->EasyConfigInfo.bDoAutoWps) {
				pAd->Mlme.AutoProvisionMachine.CurrState = INFRA_AUTO_PROVISION;
				MlmeEnqueueWithWdev(pAd, AUTO_PROVISION_STATE_MACHINE,
									MT2_CONN_AP, 0, NULL, 0, Elem->wdev);
				RTMP_MLME_HANDLER(pAd);
				return;
			}

#endif /* STA_EASY_CONFIG_SETUP */
			/* 3. failed, try next BSS */
			pStaCfg->MlmeAux.BssIdx++;
#ifdef MT76XX_BTCOEX_SUPPORT
			MLMEHook(pAd, WLAN_CONNECTION_JOIN_FAIL, QueryHashID(pAd, pStaCfg->MlmeAux.Bssid, TRUE));
#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef COEX_SUPPORT
			if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd)) {
				if ((pAd->BtWlanStatus & COEX_STATUS_LINK_UP) != 0)
					MT76xxMLMEHook(pAd, MT76xx_WLAN_LINK_DONE, 0);
			}

#endif /* COEX_SUPPORT */

			IterateOnBssTab(pAd, Elem->wdev);
		}
	}
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlWaitStartProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	USHORT Result;
	RT_PHY_INFO *rt_phy_info;
	struct wifi_dev *wdev = Elem->wdev;
	ADD_HT_INFO_IE *addht;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	MAC_TABLE_ENTRY *pEntry = GetAssociatedAPByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	addht = wlan_operate_get_addht(wdev);

	if (Elem->MsgType == MT2_START_CONF) {
		NdisMoveMemory(&Result, Elem->Msg, sizeof(USHORT));

		if (Result == MLME_SUCCESS) {
			/* */
			/* 5G bands rules of Japan: */
			/* Ad hoc must be disabled in W53(ch52,56,60,64) channels. */
			/* */
			if ((pAd->CommonCfg.bIEEE80211H == 1) &&
				RadarChannelCheck(pAd, wdev->channel)
			   ) {
				pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("CNTL - Channel=%d, Start adhoc on W53(52,56,60,64) Channels are not accepted\n",
						  wdev->channel));
				return;
			}

#ifdef DOT11_N_SUPPORT
			rt_phy_info = &pStaCfg->StaActive.SupportedPhyInfo;
			NdisZeroMemory(&rt_phy_info->MCSSet[0], 16);

			if (WMODE_CAP_N(wdev->PhyMode)
				&& (pStaCfg->bAdhocN == TRUE)
				&& (!pAd->CommonCfg.HT_DisallowTKIP
					|| !IS_INVALID_HT_SECURITY(pStaCfg->wdev.SecConfig.PairwiseCipher))) {
				SetCommonHtVht(pAd, wdev);
				pStaCfg->MlmeAux.CentralChannel = get_cent_ch_by_htinfo(pAd,
												  addht,
												  &pAd->CommonCfg.HtCapability);
				NdisMoveMemory(&pStaCfg->MlmeAux.AddHtInfo,
							   addht,
							   sizeof(ADD_HT_INFO_IE));

				if (pEntry)
					RTMPCheckHt(pAd, pEntry->wcid,
								&pAd->CommonCfg.HtCapability,
								addht);

				rt_phy_info->bHtEnable = TRUE;
				NdisMoveMemory(&rt_phy_info->MCSSet[0],
							   &pAd->CommonCfg.HtCapability.MCSSet[0], 16);
				ASSERT(pEntry);

				if (pEntry)
					COPY_HTSETTINGS_FROM_MLME_AUX_TO_ACTIVE_CFG(pAd, pEntry, pStaCfg);

#ifdef DOT11_VHT_AC

				if (WMODE_CAP_AC(wdev->PhyMode) &&
					pStaCfg->MlmeAux.vht_cap_len) {
					RT_VHT_CAP *rt_vht_cap = &pStaCfg->StaActive.SupVhtCap;

					COPY_VHT_FROM_MLME_AUX_TO_ACTIVE_CFG(pAd);
					rt_vht_cap->vht_bw = BW_80;
					rt_vht_cap->sgi_80m = pStaCfg->MlmeAux.vht_cap.vht_cap.sgi_80M;
					rt_vht_cap->vht_txstbc = pStaCfg->MlmeAux.vht_cap.vht_cap.tx_stbc;
					rt_vht_cap->vht_rxstbc = pStaCfg->MlmeAux.vht_cap.vht_cap.rx_stbc;
					rt_vht_cap->vht_htc = pStaCfg->MlmeAux.vht_cap.vht_cap.htc_vht_cap;
				}

#endif /* DOT11_VHT_AC */
			} else
#endif /* DOT11_N_SUPPORT */
			{
				pStaCfg->StaActive.SupportedPhyInfo.bHtEnable = FALSE;
			}

			pStaCfg->bAdhocCreator = TRUE;
			LinkUp(pAd, BSS_ADHOC, wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
			/* Before send beacon, driver need do radar detection */

			if ((wdev->channel > 14)
				&& (pAd->CommonCfg.bIEEE80211H == 1)
				&& RadarChannelCheck(pAd, wdev->channel)) {
				pAd->Dot11_H.RDMode = RD_SILENCE_MODE;
				pAd->Dot11_H.RDCount = 0;
			}

			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - start a new IBSS = %02x:%02x:%02x:%02x:%02x:%02x ...\n",
					  PRINT_MAC(pStaCfg->Bssid)));
			RTMPSendWirelessEvent(pAd, IW_START_IBSS_FLAG, NULL, BSS0, 0);
		} else {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CNTL - Start IBSS fail. BUG!!!!!\n"));
			pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
		}
	}
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlWaitAuthProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	USHORT Reason;
	MLME_ASSOC_REQ_STRUCT AssocReq;
	MLME_AUTH_REQ_STRUCT AuthReq;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef DOT11R_FT_SUPPORT

	if (pStaCfg->Dot11RCommInfo.bFtSupport &&
		Elem->MsgType == MT2_FT_OTD_CONF) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("FT_TEMP - CntlWaitFtProc\n"));
		NdisMoveMemory(&Reason, Elem->Msg, sizeof(USHORT));

		if (Reason == MLME_SUCCESS) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CNTL - FT OTD AUTH OK\n"));
			AssocParmFill(pAd, &AssocReq, pStaCfg->MlmeAux.Bssid,
						  pStaCfg->MlmeAux.CapabilityInfo,
						  ASSOC_TIMEOUT,
						  pStaCfg->DefaultListenCount);
			MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE,
								MT2_MLME_REASSOC_REQ,
								sizeof(MLME_ASSOC_REQ_STRUCT), &AssocReq,
								0, Elem->wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_WAIT_REASSOC;
		}
	} else
#endif /* DOT11R_FT_SUPPORT */
		if (Elem->MsgType == MT2_AUTH_CONF) {
			NdisMoveMemory(&Reason, Elem->Msg, sizeof(USHORT));

			if (Reason == MLME_SUCCESS) {
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CNTL - AUTH OK\n"));
				AssocParmFill(pAd, &AssocReq, pStaCfg->MlmeAux.Bssid,
							  pStaCfg->MlmeAux.CapabilityInfo,
							  ASSOC_TIMEOUT,
							  pStaCfg->DefaultListenCount);
#ifdef DOT11R_FT_SUPPORT

				if (pStaCfg->Dot11RCommInfo.bFtSupport &&
					(pStaCfg->Dot11RCommInfo.FtRspSuccess != 0)) {
					MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE,
										MT2_MLME_REASSOC_REQ,
										sizeof(MLME_ASSOC_REQ_STRUCT),
										&AssocReq, 0, Elem->wdev);
					pStaCfg->CntlMachine.CurrState = CNTL_WAIT_REASSOC;
				} else
#endif /* DOT11R_FT_SUPPORT */
				{
#ifdef DOT11_SAE_SUPPORT
					MAC_TABLE_ENTRY *pEntry = (MAC_TABLE_ENTRY *)pStaCfg->pAssociatedAPEntry;

					if (IS_AKM_SAE_SHA256(pEntry->SecConfig.AKMMap)
						|| IS_AKM_FT_SAE_SHA256(pEntry->SecConfig.AKMMap)) {
						pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
						MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("CNTL - SAE reassoc\n"));
						AssocParmFill(pAd, &AssocReq, pStaCfg->MlmeAux.Bssid,
						      pStaCfg->MlmeAux.CapabilityInfo,
						      5000,
						      pStaCfg->DefaultListenCount);
					}

#endif /* DOT11_SAE_SUPPORT */
					MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE,
										MT2_MLME_ASSOC_REQ,
										sizeof(MLME_ASSOC_REQ_STRUCT),
										&AssocReq, 0, Elem->wdev);
					pStaCfg->CntlMachine.CurrState = CNTL_WAIT_ASSOC;
				}
			} else {
				/* This fail may because of the AP already keep us in its MAC table without */
				/* ageing-out. The previous authentication attempt must have let it remove us. */
				/* so try Authentication again may help. For D-Link DWL-900AP+ compatibility. */
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("CNTL - AUTH FAIL, try again...\n"));
#ifdef DOT11R_FT_SUPPORT

				if (pStaCfg->Dot11RCommInfo.bFtSupport &&
					(pStaCfg->Dot11RCommInfo.FtRspSuccess ==
					 FT_OTA_RESPONSE)) {
					MLME_FT_OTA_AUTH_REQ_STRUCT FtOtaAuthReq;

					FT_OTA_AuthParmFill(pAd,
										&FtOtaAuthReq,
										pStaCfg->MlmeAux.Bssid,
										AUTH_MODE_FT,
										&pStaCfg->Dot11RCommInfo);
					MlmeEnqueueWithWdev(pAd, FT_OTA_AUTH_STATE_MACHINE,
										FT_OTA_MT2_MLME_AUTH_REQ,
										sizeof(MLME_FT_OTA_AUTH_REQ_STRUCT),
										&FtOtaAuthReq, 0, Elem->wdev);
				} else
#endif /* DOT11R_FT_SUPPORT */
#ifdef DOT11_SAE_SUPPORT
				if ((IS_AKM_SAE_SHA256(pStaCfg->wdev.SecConfig.AKMMap)
					|| IS_AKM_FT_SAE_SHA256(pStaCfg->wdev.SecConfig.AKMMap))) {
					AuthParmFill(pAd, &AuthReq,
							     pStaCfg->MlmeAux.Bssid,
							     AUTH_MODE_SAE);
					MlmeEnqueueWithWdev(pAd, AUTH_STATE_MACHINE,
						    MT2_MLME_SAE_AUTH_REQ,
						    sizeof(MLME_AUTH_REQ_STRUCT),
						    &AuthReq, 0, Elem->wdev);
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,
							("CNTL(%s) - use SAE\n", __func__));
				} else
#endif /* DOT11_SAE_SUPPORT */
				{
#ifdef WEPAUTO_OPEN_FIRST

					/* Only Ndis802_11AuthModeShared try shared key first, Ndis802_11AuthModeAutoSwitch use open first */
					if (IS_SECURITY_SHARED_WEP_Entry(&pStaCfg->wdev))
#else
					if (IS_SECURITY_SHARED_WEP_Entry(&pStaCfg->wdev)
						|| IS_SECURITY_AUTOSWITCH_Entry(&pStaCfg->wdev))
#endif
					{
						/* either Ndis802_11AuthModeShared or Ndis802_11AuthModeAutoSwitch, try shared key first */
						AuthParmFill(pAd, &AuthReq,
									 pStaCfg->MlmeAux.Bssid,
									 AUTH_MODE_KEY);
					} else {
						AuthParmFill(pAd, &AuthReq,
									 pStaCfg->MlmeAux.Bssid,
									 AUTH_MODE_OPEN);
					}

					MlmeEnqueueWithWdev(pAd, AUTH_STATE_MACHINE,
										MT2_MLME_AUTH_REQ,
										sizeof(MLME_AUTH_REQ_STRUCT),
										&AuthReq, 0, Elem->wdev);
				}

				pStaCfg->CntlMachine.CurrState = CNTL_WAIT_AUTH2;
			}
		}
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlWaitAuthProc2(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	USHORT Reason;
	MLME_ASSOC_REQ_STRUCT AssocReq;
	MLME_AUTH_REQ_STRUCT AuthReq;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	MAC_TABLE_ENTRY *pEntry = GetAssociatedAPByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	if (Elem->MsgType == MT2_AUTH_CONF) {
		NdisMoveMemory(&Reason, Elem->Msg, sizeof(USHORT));

		if (Reason == MLME_SUCCESS) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CNTL - AUTH OK\n"));
			AssocParmFill(pAd, &AssocReq, pStaCfg->MlmeAux.Bssid,
						  pStaCfg->MlmeAux.CapabilityInfo,
						  ASSOC_TIMEOUT,
						  pStaCfg->DefaultListenCount);
#ifdef DOT11R_FT_SUPPORT

			if (pStaCfg->Dot11RCommInfo.bFtSupport &&
				(pStaCfg->Dot11RCommInfo.FtRspSuccess != 0)) {
				MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE,
									MT2_MLME_REASSOC_REQ,
									sizeof(MLME_ASSOC_REQ_STRUCT),
									&AssocReq, 0, Elem->wdev);
				pStaCfg->CntlMachine.CurrState = CNTL_WAIT_REASSOC;
			} else
#endif /* DOT11R_FT_SUPPORT */
			{
#ifdef DOT11_SAE_SUPPORT
				MAC_TABLE_ENTRY *pEntry = (MAC_TABLE_ENTRY *)pStaCfg->pAssociatedAPEntry;

				if (IS_AKM_SAE_SHA256(pEntry->SecConfig.AKMMap)
					|| IS_AKM_FT_SAE_SHA256(pEntry->SecConfig.AKMMap)) {
					pStaCfg->AssocMachine.CurrState = ASSOC_IDLE;
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("CNTL2 - SAE reassoc\n"));
				}

#endif /* DOT11_SAE_SUPPORT */
				MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE,
									MT2_MLME_ASSOC_REQ,
									sizeof(MLME_ASSOC_REQ_STRUCT),
									&AssocReq, 0, Elem->wdev);
				pStaCfg->CntlMachine.CurrState = CNTL_WAIT_ASSOC;
			}
		} else {
#ifdef DOT11R_FT_SUPPORT

			if (pStaCfg->Dot11RCommInfo.bFtSupport &&
				(pStaCfg->Dot11RCommInfo.FtRspSuccess == FT_OTA_RESPONSE)) {
				/* failed, try next BSS */
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("CNTL - FT_OTA_AUTH FAIL, give up; try next BSS\n"));
				ASSERT(pEntry);
				pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
				pStaCfg->MlmeAux.BssIdx++;
				IterateOnBssTab(pAd, Elem->wdev);
			} else
#endif /* DOT11R_FT_SUPPORT */
#ifdef WEPAUTO_OPEN_FIRST
				if (IS_AKM_AUTOSWITCH(pStaCfg->wdev.SecConfig.AKMMap)
					&& IS_AKM_OPEN(pStaCfg->wdev.SecConfig.AKMMap)) {
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("CNTL - AUTH OPEN FAIL, try SHARE system...\n"));
					AuthParmFill(pAd, &AuthReq, pStaCfg->MlmeAux.Bssid,
								 Ndis802_11AuthModeShared);
#else

				if (IS_AKM_AUTOSWITCH(pStaCfg->wdev.SecConfig.AKMMap)
					&& IS_AKM_SHARED(pStaCfg->wdev.SecConfig.AKMMap)) {
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("CNTL - AUTH FAIL, try OPEN system...\n"));
					AuthParmFill(pAd, &AuthReq, pStaCfg->MlmeAux.Bssid,
								 Ndis802_11AuthModeOpen);
#endif
					MlmeEnqueueWithWdev(pAd, AUTH_STATE_MACHINE,
										MT2_MLME_AUTH_REQ,
										sizeof(MLME_AUTH_REQ_STRUCT),
										&AuthReq, 0, Elem->wdev);
					pStaCfg->CntlMachine.CurrState = CNTL_WAIT_AUTH2;
				} else {
					/* not success, try next BSS */
					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("CNTL - AUTH FAIL, give up; try next BSS\n"));
#ifdef RT_CFG80211_SUPPORT
					RT_CFG80211_CONN_RESULT_INFORM(pAd, pStaCfg->MlmeAux.Bssid, NULL, 0,
												   NULL, 0, 0);
#endif /* RT_CFG80211_SUPPORT */
					ASSERT(pEntry);
					pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
					pStaCfg->MlmeAux.BssIdx++;
#ifdef MT76XX_BTCOEX_SUPPORT
					MLMEHook(pAd, WLAN_CONNECTION_AUTH_FAIL, QueryHashID(pAd, pStaCfg->MlmeAux.Bssid, TRUE));
#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef COEX_SUPPORT

					if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd)) {
						if ((pAd->BtWlanStatus & COEX_STATUS_LINK_UP) != 0)
							MT76xxMLMEHook(pAd, MT76xx_WLAN_LINK_DONE, 0);
					}

#endif /* COEX_SUPPORT */

#ifndef RT_CFG80211_SUPPORT
					/*let wpa_supplicant take action on auth fail, instead of driver*/
					IterateOnBssTab(pAd, Elem->wdev);
#endif /*RT_CFG80211_SUPPORT*/
				}
		}
	}
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlWaitAssocProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	USHORT Reason;
	MAC_TABLE_ENTRY *pEntry = GetAssociatedAPByWdev(pAd, Elem->wdev);
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	if (Elem->MsgType == MT2_ASSOC_CONF) {
		NdisMoveMemory(&Reason, Elem->Msg, sizeof(USHORT));

		if (Reason == MLME_SUCCESS) {
			RTMPSendWirelessEvent(pAd, IW_ASSOC_EVENT_FLAG, NULL, BSS0, 0);
			LinkUp(pAd, BSS_INFRA, Elem->wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - Association successful on BSS #%ld\n", pStaCfg->MlmeAux.BssIdx));
		} else {
			/* not success, try next BSS */
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - Association fails on BSS #%ld\n", pStaCfg->MlmeAux.BssIdx));
#ifdef RT_CFG80211_SUPPORT
			RT_CFG80211_CONN_RESULT_INFORM(pAd, pStaCfg->MlmeAux.Bssid, NULL, 0,
										   NULL, 0, 0);
#endif /* RT_CFG80211_SUPPORT */
			ASSERT(pEntry);
			pStaCfg->MlmeAux.BssIdx++;
#ifdef MT76XX_BTCOEX_SUPPORT
			MLMEHook(pAd, WLAN_CONNECTION_ASSOC_FAIL, QueryHashID(pAd, pStaCfg->MlmeAux.Bssid, TRUE));
#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef COEX_SUPPORT

			if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd)) {
				if ((pAd->BtWlanStatus & COEX_STATUS_LINK_UP) != 0)
					MT76xxMLMEHook(pAd, MT76xx_WLAN_LINK_DONE, 0);
			}

#endif /* COEX_SUPPORT */
			IterateOnBssTab(pAd, Elem->wdev);
		}
	}
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID CntlWaitReassocProc(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem)
{
	USHORT Result;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	if (Elem->MsgType == MT2_REASSOC_CONF) {
		NdisMoveMemory(&Result, Elem->Msg, sizeof(USHORT));

		if (Result == MLME_SUCCESS) {
			/* send wireless event - for association */
			RTMPSendWirelessEvent(pAd, IW_ASSOC_EVENT_FLAG, NULL,
								  BSS0, 0);
#ifdef DOT11R_FT_SUPPORT

			if (pStaCfg->Dot11RCommInfo.bFtSupport &&
				pStaCfg->Dot11RCommInfo.bInMobilityDomain &&
				(pStaCfg->Dot11RCommInfo.FtRspSuccess ==
				 FT_OTD_RESPONSE))
				InitChannelRelatedValue(pAd, &pStaCfg->wdev);

#endif /* DOT11R_FT_SUPPORT */
			/* NDIS requires a new Link UP indication but no Link Down for RE-ASSOC */
			LinkUp(pAd, BSS_INFRA, Elem->wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - Re-assocition successful on BSS #%ld\n",
					  pStaCfg->MlmeAux.RoamIdx));
		} else {
			/* reassoc failed, try to pick next BSS in the BSS Table */
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - Re-assocition fails on BSS #%ld\n",
					  pStaCfg->MlmeAux.RoamIdx));
#ifdef DOT11R_FT_SUPPORT

			if (pStaCfg->Dot11RCommInfo.bFtSupport &&
				pStaCfg->Dot11RCommInfo.bInMobilityDomain &&
				(pStaCfg->Dot11RCommInfo.FtRspSuccess == FT_OTD_RESPONSE)
			   ) {
				NDIS_802_11_SSID ApSsid;

				NdisZeroMemory(&ApSsid, sizeof(NDIS_802_11_SSID));
				ApSsid.SsidLength = pStaCfg->MlmeAux.SsidLen;
				NdisMoveMemory(ApSsid.Ssid, pStaCfg->MlmeAux.Ssid, ApSsid.SsidLength);
				MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE,
									OID_802_11_SSID,
									sizeof(NDIS_802_11_SSID),
									(VOID *)&ApSsid, 0, Elem->wdev);
				pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
			} else
#endif /* DOT11R_FT_SUPPORT */
			{
				pStaCfg->MlmeAux.RoamIdx++;
				IterateOnBssTab2(pAd, Elem->wdev);
			}
		}
	}
}

VOID AdhocTurnOnQos(RTMP_ADAPTER *pAd, PSTA_ADMIN_CONFIG pStaCfg)
{
	if (pAd->CommonCfg.APEdcaParm[0].bValid == FALSE) {
		pAd->CommonCfg.APEdcaParm[0].bValid = TRUE;
		pAd->CommonCfg.APEdcaParm[0].Aifsn[0] = 3;
		pAd->CommonCfg.APEdcaParm[0].Aifsn[1] = 7;
		pAd->CommonCfg.APEdcaParm[0].Aifsn[2] = 1;
		pAd->CommonCfg.APEdcaParm[0].Aifsn[3] = 1;
		pAd->CommonCfg.APEdcaParm[0].Cwmin[0] = 4;
		pAd->CommonCfg.APEdcaParm[0].Cwmin[1] = 4;
		pAd->CommonCfg.APEdcaParm[0].Cwmin[2] = 3;
		pAd->CommonCfg.APEdcaParm[0].Cwmin[3] = 2;
		pAd->CommonCfg.APEdcaParm[0].Cwmax[0] = 10;
		pAd->CommonCfg.APEdcaParm[0].Cwmax[1] = 6;
		pAd->CommonCfg.APEdcaParm[0].Cwmax[2] = 4;
		pAd->CommonCfg.APEdcaParm[0].Cwmax[3] = 3;
		pAd->CommonCfg.APEdcaParm[0].Txop[0] = 0;
		pAd->CommonCfg.APEdcaParm[0].Txop[1] = 0;
		pAd->CommonCfg.APEdcaParm[0].Txop[2] = 94;
		pAd->CommonCfg.APEdcaParm[0].Txop[3] = 47;
	}

	HcAcquiredEdca(pAd, &pStaCfg->wdev, &pAd->CommonCfg.APEdcaParm[0]);
}


VOID LinkUp_Adhoc(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, MAC_TABLE_ENTRY *pEntry)
{
	/* INT idx; */
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	/* If WEP is enabled, add key material and cipherAlg into Asic */
	/* Fill in Shared Key Table(offset: 0x6c00) and Shared Key Mode(offset: 0x7000) */
#if 0 /* Todo:Adhoc Need re-write by Eddy*/

	if (wdev->WepStatus == Ndis802_11WEPEnabled) {
		UCHAR CipherAlg;

		for (idx = 0; idx < SHARE_KEY_NUM; idx++) {
			CipherAlg = pAd->SharedKey[BSS0][idx].CipherAlg;

			if (pAd->SharedKey[BSS0][idx].KeyLen > 0) {
				/* Set key material and cipherAlg to Asic */
				AsicAddSharedKeyEntry(pAd, BSS0, idx,
									  &pAd->SharedKey[BSS0][idx]);

				if (idx == wdev->DefaultKeyId) {
					INT cnt;

					/* Generate 3-bytes IV randomly for software encryption using */
					for (cnt = 0; cnt < LEN_WEP_TSC; cnt++)
						pAd->SharedKey[BSS0][idx].TxTsc[cnt] = RandomByte(pAd);

#ifdef MT_MAC

					if (IS_HIF_TYPE(pAd, HIF_MT)) {
						INT groupWcid = pStaCfg->wdev.tr_tb_idx;

						RTMP_ADDREMOVE_KEY(pAd, 0, BSS0, wdev->DefaultKeyId, groupWcid, SHAREDKEYTABLE,
										   &pAd->SharedKey[BSS0][wdev->DefaultKeyId], BROADCAST_ADDR);
					}

#endif /* MT_MAC */
				}
			}
		}
	}
	/* If WPANone is enabled, add key material and cipherAlg into Asic */
	/* Fill in Shared Key Table(offset: 0x6c00) and Shared Key Mode(offset: 0x7000) */
	else if (IS_AKM_WPANONE(wdev->SecConfig.AKMMap)) {
		wdev->SecConfig.PairwiseKeyId = 0;	/* always be zero */
		NdisZeroMemory(&pAd->SharedKey[BSS0][0], sizeof(CIPHER_KEY));
		pAd->SharedKey[BSS0][0].KeyLen = LEN_TK;
		NdisMoveMemory(pAd->SharedKey[BSS0][0].Key, pStaCfg->PMK, LEN_TK);

		if (pStaCfg->PairCipher == Ndis802_11TKIPEnable) {
			NdisMoveMemory(pAd->SharedKey[BSS0][0].RxMic,
						   &pStaCfg->PMK[16], LEN_TKIP_MIC);
			NdisMoveMemory(pAd->SharedKey[BSS0][0].TxMic,
						   &pStaCfg->PMK[16], LEN_TKIP_MIC);
		}

		/* Decide its ChiperAlg */
		if (pStaCfg->PairCipher == Ndis802_11TKIPEnable)
			pAd->SharedKey[BSS0][0].CipherAlg = CIPHER_TKIP;
		else if (pStaCfg->PairCipher == Ndis802_11AESEnable)
			pAd->SharedKey[BSS0][0].CipherAlg = CIPHER_AES;
		else {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("Unknow Cipher (=%d), set Cipher to AES\n",
					  pStaCfg->PairCipher));
			pAd->SharedKey[BSS0][0].CipherAlg = CIPHER_AES;
		}

		/* Set key material and cipherAlg to Asic */
		AsicAddSharedKeyEntry(pAd,
							  BSS0, 0, &pAd->SharedKey[BSS0][0]);
#ifdef MT_MAC

		if (IS_HIF_TYPE(pAd, HIF_MT)) {
			INT groupWcid = pStaCfg->wdev.tr_tb_idx;

			RTMP_ADDREMOVE_KEY(pAd, 0, BSS0, wdev->DefaultKeyId, groupWcid, SHAREDKEYTABLE,
							   &pAd->SharedKey[BSS0][wdev->DefaultKeyId], BROADCAST_ADDR);
		}

#endif /* MT_MAC */
	}

#endif /*0 */
#ifdef ADHOC_WPA2PSK_SUPPORT
	else if ((wdev->AuthMode == Ndis802_11AuthModeWPA2PSK)
#ifdef WPA_SUPPLICANT_SUPPORT
			 && (pStaCfg->wpa_supplicant_info.WpaSupplicantUP == WPA_SUPPLICANT_DISABLE)
#endif /* WPA_SUPPLICANT_SUPPORT */
			) {
		USHORT Wcid = 0;

		wdev->DefaultKeyId = 0;	/* always be zero */
		NdisZeroMemory(&pAd->SharedKey[BSS0][0], sizeof(CIPHER_KEY));
		pAd->SharedKey[BSS0][0].KeyLen = LEN_TK;
		NdisMoveMemory(pAd->SharedKey[BSS0][0].Key, pStaCfg->PMK, LEN_TK);
		pAd->SharedKey[BSS0][0].CipherAlg = CIPHER_AES;
		/* Generate GMK and GNonce randomly */
		GenRandom(pAd, pStaCfg->Bssid, pStaCfg->GMK);
		GenRandom(pAd, pStaCfg->Bssid, pStaCfg->GNonce);
		/* Derive GTK per BSSID */
		WpaDeriveGTK(pStaCfg->GMK,
					 pStaCfg->GNonce,
					 wdev->if_addr,
					 pStaCfg->GTK, LEN_TKIP_GTK);

		if (pStaCfg->GroupCipher == Ndis802_11AESEnable) {
			NdisZeroMemory(&pStaCfg->TxGTK, sizeof(CIPHER_KEY));
			NdisMoveMemory(pStaCfg->TxGTK.Key, pStaCfg->GTK, LEN_TK);
			pStaCfg->TxGTK.CipherAlg = CIPHER_AES;
			pStaCfg->TxGTK.KeyLen = LEN_TK;
			/* Add Pair-wise key to Asic */
			/* GET_GroupKey_WCID(pAd, Wcid, BSS0); */
			Wcid = pStaCfg->wdev.bss_info_argument.ucBcMcWlanIdx;
			AsicAddPairwiseKeyEntry(pAd,
									(UCHAR) Wcid,
									&pStaCfg->TxGTK);
		}
	}

#endif /* ADHOC_WPA2PSK_SUPPORT */
#ifdef LINUX
#ifdef RT_CFG80211_SUPPORT
	RT_CFG80211_JOIN_IBSS(pAd, pStaCfg->MlmeAux.Bssid);
#endif /* RT_CFG80211_SUPPORT */
#endif /* LINUX */

	if (wdev_do_linkup(wdev, pEntry) != TRUE)
		MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): linkup fail!!\n", __func__));

	if (wdev_do_conn_act(wdev, pEntry) != TRUE)
		MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): connect fail!!\n", __func__));
}


VOID LinkUp_Infra(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, MAC_TABLE_ENTRY *pEntry, UCHAR *tmpWscSsid, UCHAR tmpWscSsidLen)
{
	BOOLEAN Cancelled;
	UCHAR	BROADCAST_ADDR[MAC_ADDR_LEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	STA_TR_ENTRY *tr_entry;
#ifdef RELEASE_EXCLUDE
	/*
	 *	Fix compile unused variable issue when DOT11R_FT_SUPPORT/WSC_STA_SUPPORT compile flags are OFF.
	 *	@20150625
	 */
#endif /* RELEASE_EXCLUDE */
	Cancelled = TRUE;
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	/* Reset Beaconlost */
	pStaCfg->PwrMgmt.bBeaconLost = FALSE;
	/* Copy DtimPeriod/BeaconPeriod to wdev */
	pStaCfg->PwrMgmt.ucBeaconPeriod = pStaCfg->MlmeAux.BeaconPeriod;
	pStaCfg->PwrMgmt.ucDtimPeriod = pStaCfg->MlmeAux.DtimPeriod;
	pStaCfg->PwrMgmt.bTriggerRoaming = FALSE;
	pStaCfg->PwrMgmt.ucWcid = pEntry->wcid;
#ifdef STA_LP_PHASE_1_SUPPORT
	RTMPClearEnterPsmNullBit(&pStaCfg->PwrMgmt);
#endif /* STA_LP_PHASE_1_SUPPORT */
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s::uBeaconPeriod(%d), uDtimPeriod(%d)\n", __func__, pStaCfg->PwrMgmt.ucBeaconPeriod, pStaCfg->PwrMgmt.ucDtimPeriod));
#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */

	COPY_MAC_ADDR(wdev->bssid, pStaCfg->Bssid);
	tr_entry = &pAd->MacTab.tr_entry[pEntry->wcid];

	if (IS_CIPHER_NONE_OR_WEP_Entry(wdev)) {
#ifdef WPA_SUPPLICANT_SUPPORT

		if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP &&
			(IS_CIPHER_WEP_Entry(wdev)) &&
			(wdev->SecConfig.IEEE8021X == TRUE))
			;
		else
#endif /* WPA_SUPPLICANT_SUPPORT */
		{
			wdev->PortSecured = WPA_802_1X_PORT_SECURED;
			pStaCfg->PrivacyFilter = Ndis802_11PrivFilterAcceptAll;
		}
	}

	/*
	 *	On WPA mode, Remove All Keys if not connect to the last BSSID
	 *	Key will be set after 4-way handshake
	 */
	if (IS_AKM_WPA_CAPABILITY(wdev->SecConfig.AKMMap)
#ifdef WAPI_SUPPORT
		|| IS_CIPHER_WPI_SMS4(wdev->SecConfig.PairwiseCipher)
#endif
	   ) {
		/* Remove all WPA keys */
		/*
		 *		 for dhcp,issue ,wpa_supplicant ioctl too fast , at link_up, it will add key before driver remove key
		 *	 move to assoc.c
		 */
		/*			RTMPWPARemoveAllKeys(pAd, wdev);*/
		wdev->PortSecured = WPA_802_1X_PORT_NOT_SECURED;
		pStaCfg->PrivacyFilter = Ndis802_11PrivFilter8021xWEP;
#if 0				/* Remove by AlbertY, this routine shall be processed in WPA handshaking */
		/* Fixed connection failed with Range Maximizer - 515 AP (Marvell Chip) when security is WPAPSK/TKIP */
		/* If IV related values are too large in GroupMsg2, AP would ignore this message. */
		IV = 1;
		IV |= (pStaCfg->DefaultKeyId << 30);
		AsicUpdateWCIDIVEIV(pAd, pEntry->wcid, IV, 0);
#endif
#ifdef SOFT_ENCRYPT
		/* There are some situation to need to encryption by software
		 *   1. The Client support PMF. It shall ony support AES cipher.
		 *   2. The Client support WAPI.
		 *   If use RT3883 or later, HW can handle the above.
		 */
#ifdef WAPI_SUPPORT

		if (!(IS_HW_WAPI_SUPPORT(pAd))
			&& (IS_CIPHER_WPI_SMS4(wdev->SecConfig.PairwiseCipher)))
			CLIENT_STATUS_SET_FLAG(pEntry, fCLIENT_STATUS_SOFTWARE_ENCRYPT);

#endif /* WAPI_SUPPORT */
#ifdef DOT11W_PMF_SUPPORT
		{
			struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);

			if ((cap->FlgPMFEncrtptMode == PMF_ENCRYPT_MODE_0)
				&& (pEntry->SecConfig.PmfCfg.UsePMFConnect == TRUE))
				CLIENT_STATUS_SET_FLAG(pEntry, fCLIENT_STATUS_SOFTWARE_ENCRYPT);
		}
#endif /* DOT11W_PMF_SUPPORT */
#endif /* SOFT_ENCRYPT */
	}

	NdisAcquireSpinLock(&pAd->MacTabLock);
	tr_entry->PortSecured = wdev->PortSecured;
	NdisReleaseSpinLock(&pAd->MacTabLock);
#ifndef WMM_ACM_SUPPORT
#ifdef MT7615
#ifdef MT_MAC

	if (IS_HIF_TYPE(pAd, HIF_MT)) {
		if (pStaCfg->MlmeAux.APEdcaParm.bValid) {
			pEntry->bACMBit[WMM_AC_BK] = pStaCfg->MlmeAux.APEdcaParm.bACM[WMM_AC_BK];
			pEntry->bACMBit[WMM_AC_BE] = pStaCfg->MlmeAux.APEdcaParm.bACM[WMM_AC_BE];
			pEntry->bACMBit[WMM_AC_VI] = pStaCfg->MlmeAux.APEdcaParm.bACM[WMM_AC_VI];
			pEntry->bACMBit[WMM_AC_VO] = pStaCfg->MlmeAux.APEdcaParm.bACM[WMM_AC_VO];
		}
	}

#endif /* MT_MAC */
#endif /* MT7615 */
#endif /* WMM_ACM_SUPPORT */

	if (wdev_do_linkup(wdev, pEntry) != TRUE)
		MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): linkup fail!!\n", __func__));

	if (wdev_do_conn_act(wdev, pEntry) != TRUE)
		MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): connect fail!!\n", __func__));

	/* Check the new SSID with last SSID */
	while (TRUE) {
		if (pStaCfg->LastSsidLen == pStaCfg->SsidLen) {
			if (RTMPCompareMemory(pStaCfg->LastSsid, pStaCfg->Ssid, pStaCfg->LastSsidLen) == 0) {
				/* Link to the old one no linkdown is required. */
				break;
			}
		}

#ifndef DPA_S
		/* Send link down event before set to link up */
		RTMP_IndicateMediaState(pAd, NdisMediaStateDisconnected);
		pAd->ExtraInfo = GENERAL_LINK_DOWN;
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("NDIS_STATUS_MEDIA_DISCONNECT Event AA!\n"));
#endif /* !DPA_S */
		break;
	}

#ifdef DOT11R_FT_SUPPORT
	else {
		/*
		 *   11R only supports OPEN/NONE and WPA2PSK/TKIPAES now.
		 */
		if (pStaCfg->Dot11RCommInfo.bFtSupport &&
			pStaCfg->MlmeAux.MdIeInfo.Len &&
			IS_SECURITY_OPEN_NONE_Entry(wdev))
			pStaCfg->Dot11RCommInfo.bInMobilityDomain = TRUE;
	}

#endif /* DOT11R_FT_SUPPORT */
	/* NOTE: */
	/* the decision of using "short slot time" or not may change dynamically due to */
	/* new STA association to the AP. so we have to decide that upon parsing BEACON, not here */
	/* NOTE: */
	/* the decision to use "RTC/CTS" or "CTS-to-self" protection or not may change dynamically */
	/* due to new STA association to the AP. so we have to decide that upon parsing BEACON, not here */
	ComposePsPoll(pAd, &(pAd->PsPollFrame), pStaCfg->StaActive.Aid,
				  pStaCfg->Bssid, pStaCfg->wdev.if_addr);
	ComposeNullFrame(pAd, &(pAd->NullFrame), pStaCfg->Bssid,
					 pStaCfg->wdev.if_addr, pStaCfg->Bssid);
#ifdef MESH_SUPPORT

	if (MESH_ON(pAd)) {
		UCHAR ext_cha = wlan_operate_get_ext_cha(wdev);

		AsicEnableMESHSync(pAd);

		if ((wdev->channel != pAd->MeshTab.MeshChannel)
#ifdef DOT11_N_SUPPORT
			|| (ext_cha != pAd->MeshTab.ExtChOffset)
#endif /* DOT11_N_SUPPORT */
		   ) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("Channel change , old channel:%d new channel:%d !!\n",
					  wdev->channel,
					  pAd->MeshTab.MeshChannel));
#ifdef DOT11_N_SUPPORT
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("Old ExtCh:%d new ExtCh:%d !!\n",
					  ext_cha,
					  pAd->MeshTab.ExtChOffset));
#endif /* DOT11_N_SUPPORT */

			if (pAd->MeshTab.UCGEnable == TRUE) {
				wlan_operate_set_prim_ch(wdev, pAd->MeshTab.MeshChannel);
				pAd->MeshTab.MeshChannel = wdev->channel;
#ifdef DOT11_N_SUPPORT
				pAd->MeshTab.ExtChOffset = ext_cha;
#endif /* DOT11_N_SUPPORT */
				MlmeEnqueueWithWdev(pAd,
									MESH_CTRL_STATE_MACHINE,
									MESH_CTRL_UCG_EVT, 0, NULL,
									0, wdev);
			} else {
				pAd->MeshTab.MeshChannel = wdev->channel;
#ifdef DOT11_N_SUPPORT
				pAd->MeshTab.ExtChOffset = ext_cha;
#endif /* DOT11_N_SUPPORT */
				MeshMakeBeacon(pAd, MESH_BEACON_IDX(pAd));
				MeshUpdateBeaconFrame(pAd, MESH_BEACON_IDX(pAd));
			}

			TearDownAllMeshLink(pAd);
		}
	} else
#endif /* MESH_SUPPORT */
#ifdef P2P_SUPPORT
		pAd->P2pCfg.GroupChannel = wdev->channel;

	if (P2P_GO_ON(pAd)) {
		UCHAR ext_cha = wlan_operate_get_ext_cha(wdev);

		AsicEnableP2PGoSync(pAd);

		if (wdev->channel != pAd->P2PChannel) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Channel change , old channel:%d new channel:%d !!\n"
					 , pAd->P2PChannel, wdev->channel));
#ifdef DOT11_N_SUPPORT
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Old ExtCh:%d new ExtCh:%d !!\n"
					 , pAd->P2PExtChOffset, ext_cha));
#endif /* DOT11_N_SUPPORT */
			P2P_GoStop(pAd);
			P2P_GoStartUp(pAd, MAIN_MBSSID);
		}
	} else if (P2P_CLI_ON(pAd)) {
		AsicSetSyncModeAndEnable(pAd, pAd->CommonCfg.BeaconPeriod, HW_BSSID_0, OPMODE_STA);

		if (wdev->channel != pAd->P2PChannel) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Channel change , old channel:%d new channel:%d !!\n"
					 , pAd->P2PChannel, wdev->channel));
#ifdef DOT11_N_SUPPORT
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Old ExtCh:%d new ExtCh:%d !!\n"
					 , pAd->P2PExtChOffset, ext_cha));
#endif /* DOT11_N_SUPPORT */
			MlmeEnqueueWithWdev(pAd, APCLI_CTRL_STATE_MACHINE, APCLI_CTRL_DISCONNECT_REQ, 0, NULL, 0, wdev);
		}
	} else
#endif /* P2P_SUPPORT */
#ifdef RT_CFG80211_P2P_CONCURRENT_DEVICE
		if (CFG_P2PGO_ON(pAd))
			AsicEnableApBssSync(pAd, pAd->CommonCfg.BeaconPeriod);
		else
#endif /* RT_CFG80211_P2P_CONCURRENT_DEVICE */
			AsicSetSyncModeAndEnable(pAd, pAd->CommonCfg.BeaconPeriod, HW_BSSID_0, OPMODE_STA);

	MacTableSetEntryRaCap(pAd, pEntry, &pStaCfg->MlmeAux.vendor_ie);
	/* +++Add by shiang for debug */
	{
		STA_TR_ENTRY *tr_entry = &pAd->MacTab.tr_entry[pEntry->wcid];
		/* TODO: shiang-usw, revise this! */
		COPY_MAC_ADDR(tr_entry->bssid, wdev->bssid);
	}
	/* ---Add by shiang */
	/* If WEP is enabled, add paiewise and shared key */
#ifdef WPA_SUPPLICANT_SUPPORT

	if (((pStaCfg->wpa_supplicant_info.WpaSupplicantUP) &&
		 (IS_CIPHER_WEP_Entry(wdev)) &&
		 (wdev->PortSecured == WPA_802_1X_PORT_SECURED)) ||
		((pStaCfg->wpa_supplicant_info.WpaSupplicantUP == WPA_SUPPLICANT_DISABLE) &&
		 (IS_CIPHER_WEP_Entry(wdev))))
#else
	if (IS_CIPHER_WEP_Entry(wdev))
#endif /* WPA_SUPPLICANT_SUPPORT */
	{
		ASIC_SEC_INFO Info = {0};
		struct _SECURITY_CONFIG *pSecConfig = &pEntry->SecConfig;
		/* Set Group key material to Asic */
		os_zero_mem(&Info, sizeof(ASIC_SEC_INFO));
		Info.Operation = SEC_ASIC_ADD_GROUP_KEY;
		Info.Direction = SEC_ASIC_KEY_RX;
		Info.Wcid = wdev->bss_info_argument.ucBcMcWlanIdx;
		Info.BssIndex = wdev->wdev_idx;
		Info.Cipher = pSecConfig->GroupCipher;
		Info.KeyIdx = pSecConfig->GroupKeyId;
		os_move_mem(&Info.PeerAddr[0], BROADCAST_ADDR, MAC_ADDR_LEN);
		os_move_mem(&Info.Key, &pSecConfig->WepKey[Info.KeyIdx], sizeof(SEC_KEY_INFO));
		HW_ADDREMOVE_KEYTABLE(pAd, &Info);
		/* Set Pairwise key material to Asic */
		os_zero_mem(&Info, sizeof(ASIC_SEC_INFO));
		Info.Operation = SEC_ASIC_ADD_PAIRWISE_KEY;
		Info.Direction = SEC_ASIC_KEY_BOTH;
		Info.Wcid = pEntry->wcid;
		Info.BssIndex = wdev->wdev_idx;
		Info.Cipher = pSecConfig->PairwiseCipher;
		Info.KeyIdx = pSecConfig->PairwiseKeyId;
		os_move_mem(&Info.PeerAddr[0], pEntry->Addr, MAC_ADDR_LEN);
		os_move_mem(&Info.Key, &pSecConfig->WepKey[Info.KeyIdx], sizeof(SEC_KEY_INFO));
		HW_ADDREMOVE_KEYTABLE(pAd, &Info);
	}

#if 0 /* Move to OPSTATUS_SET_FLAG(pAd, fOP_STATUS_INFRA_ON) code segment */
	/* only INFRASTRUCTURE mode need to indicate connectivity immediately; ADHOC mode */
	/* should wait until at least 2 active nodes in this BSSID. */
	STA_STATUS_SET_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED);
#endif

	/* For GUI ++ */
	if (IS_AKM_OPEN(wdev->SecConfig.AKMMap) || IS_AKM_SHARED(wdev->SecConfig.AKMMap) || IS_AKM_AUTOSWITCH(wdev->SecConfig.AKMMap)) {
#ifdef WPA_SUPPLICANT_SUPPORT

		if (((pStaCfg->wpa_supplicant_info.WpaSupplicantUP) && (IS_CIPHER_WEP_Entry(wdev)) && (wdev->PortSecured == WPA_802_1X_PORT_SECURED))
			|| ((pStaCfg->wpa_supplicant_info.WpaSupplicantUP == WPA_SUPPLICANT_DISABLE) && (IS_CIPHER_WEP_Entry(wdev)))
			|| (IS_CIPHER_NONE(wdev->SecConfig.PairwiseCipher)))
#endif /* WPA_SUPPLICANT_SUPPORT */
		{
			pAd->ExtraInfo = GENERAL_LINK_UP;
			RTMP_IndicateMediaState(pAd, NdisMediaStateConnected);
		}
	} else if (IS_AKM_WPA1PSK(wdev->SecConfig.AKMMap) ||
			   IS_AKM_WPA2PSK(wdev->SecConfig.AKMMap)) {
#ifdef WPA_SUPPLICANT_SUPPORT

		if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP == WPA_SUPPLICANT_DISABLE)
#endif /* WPA_SUPPLICANT_SUPPORT */
			RTMPSetTimer(&pStaCfg->LinkDownTimer, LINK_DOWN_TIMEOUT);

#ifdef WSC_STA_SUPPORT

		if (wdev->WscControl.WscProfileRetryTimerRunning) {
			RTMPSetTimer(&wdev->WscControl.WscProfileRetryTimer,
						 WSC_PROFILE_RETRY_TIME_OUT);
		}

#endif /* WSC_STA_SUPPORT */
	}

#if 0 /* Move to StaUpdateMacTableEntry */
	/* Add BSSID in my MAC Table. */
	NdisAcquireSpinLock(&pAd->MacTabLock);

	/* add this MAC entry into HASH table */
	if (pEntry) {
		HashIdx = MAC_ADDR_HASH_INDEX(pAd->CommonCfg.Bssid);

		if (pAd->MacTab.Hash[HashIdx] == NULL)
			pAd->MacTab.Hash[HashIdx] = pEntry;
		else {
			pCurrEntry = pAd->MacTab.Hash[HashIdx];

			while (pCurrEntry->pNext != NULL)
				pCurrEntry = pCurrEntry->pNext;

			pCurrEntry->pNext = pEntry;
		}
	}

	RTMPMoveMemory(pEntry->Addr, pAd->CommonCfg.Bssid, MAC_ADDR_LEN);
	pEntry->Aid = BSSID_WCID;
	pEntry->wcid = BSSID_WCID;
	pEntry->pAd = pAd;
	SET_ENTRY_CLIENT(pEntry);
#ifdef P2P_SUPPORT

	if (!(P2P_GO_ON(pAd) || P2P_CLI_ON(pAd)))
#endif /* P2P_SUPPORT */
		pAd->MacTab.Size = 1;	/* infra mode always set MACtab size =1. */

	pEntry->Sst = SST_ASSOC;
	pEntry->AuthState = SST_ASSOC;
	pEntry->AuthMode = pStaCfg->AuthMode;
	pEntry->WepStatus = pStaCfg->WepStatus;

	if (pEntry->AuthMode < Ndis802_11AuthModeWPA) {
		pEntry->WpaState = AS_NOTUSE;
		pEntry->PrivacyFilter = Ndis802_11PrivFilterAcceptAll;
	} else {
		pEntry->WpaState = AS_PTKSTART;
		pEntry->PrivacyFilter = Ndis802_11PrivFilter8021xWEP;
	}

#endif
#ifdef DOT11R_FT_SUPPORT
	NdisAcquireSpinLock(&pAd->MacTabLock);
	pEntry->MdIeInfo.Len = 0;

	if (pStaCfg->Dot11RCommInfo.bFtSupport &&
		pStaCfg->MlmeAux.MdIeInfo.Len &&
		(wdev->WepStatus == Ndis802_11WEPDisabled
		 || wdev->AuthMode == Ndis802_11AuthModeWPA2PSK)) {
		pEntry->MdIeInfo.Len = pStaCfg->MlmeAux.MdIeInfo.Len;
		FT_SET_MDID(pEntry->MdIeInfo.MdId,
					pStaCfg->MlmeAux.MdIeInfo.MdId);
		pEntry->MdIeInfo.FtCapPlc.word =
			pStaCfg->MlmeAux.MdIeInfo.FtCapPlc.word;

		if (pStaCfg->Dot11RCommInfo.bInMobilityDomain == TRUE) {
			RTMPCancelTimer(&pStaCfg->LinkDownTimer, &Cancelled);

			if (pEntry->WepStatus != Ndis802_11WEPDisabled) {
				NdisMoveMemory(pEntry->PTK,
							   pAd->MacTab.Content[wdev->bss_info_argument.ucBcMcWlanIdx].PTK,
							   64);
				NdisReleaseSpinLock(&pAd->MacTabLock);
				WpaStaGroupKeySetting(pAd, wdev);
				WpaStaPairwiseKeySetting(pAd, wdev);
			} else
				NdisReleaseSpinLock(&pAd->MacTabLock);
		} else
			NdisReleaseSpinLock(&pAd->MacTabLock);
	}

#endif /* DOT11R_FT_SUPPORT */
#if 0
	else
		NdisReleaseSpinLock(&pAd->MacTabLock);

#endif
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("!!! LINK UP !!!  ClientStatusFlags=%lx)\n",
			 pEntry->ClientStatusFlags));
#ifdef WIDI_SUPPORT

	/*
	 *	Send L2SDTA Association status here
	 */
	if (wdev->WscControl.bWscTrigger)
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("WPS is in Prgress; Not sending this LINK UP\n"));
	else {
		if ((wdev->AuthMode != Ndis802_11AuthModeWPA2PSK)
			&& (wdev->AuthMode != Ndis802_11AuthModeWPAPSK)) {
			WidiUpdateStateToDaemon(pAd, MIN_NET_DEVICE_FOR_MBSSID,
									WIDI_MSG_TYPE_ASSOC_STATUS,
									pEntry->Addr, NULL, 0,
									WIDI_ASSOCIATED);
		} else
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Auth Mode is WPA2PSK or WPAPSK; Not sending this LINK UP\n"));
	}

#endif /* WIDI_SUPPORT */
#ifdef WSC_STA_SUPPORT

	/*
	 *   1. WSC initial connect to AP, set the correct parameters
	 *   2. When security of Marvell WPS AP is OPEN/NONE, Marvell AP will send EAP-Req(ID) to STA immediately.
	 *   STA needs to receive this EAP-Req(ID) on time, because Marvell AP will not send again after STA sends EAPOL-Start.
	 */
	if ((wdev->WscControl.WscConfMode != WSC_DISABLE) &&
		(wdev->WscControl.bWscTrigger
#ifdef STA_EASY_CONFIG_SETUP
		 || wdev->EasyConfigInfo.bDoAutoWps
#endif /* STA_EASY_CONFIG_SETUP */
		)) {
#ifdef DOT11R_FT_SUPPORT
		pStaCfg->Dot11RCommInfo.bInMobilityDomain = FALSE;
		pStaCfg->Dot11RCommInfo.FtRspSuccess = 0;
#endif /* DOT11R_FT_SUPPORT */
		RTMPCancelTimer(&pStaCfg->LinkDownTimer, &Cancelled);
		wdev->WscControl.WscState = WSC_STATE_LINK_UP;
		wdev->WscControl.WscStatus = WSC_STATE_LINK_UP;
		NdisZeroMemory(pStaCfg->Ssid, MAX_LEN_OF_SSID);
		NdisMoveMemory(pStaCfg->Ssid, tmpWscSsid,
					   tmpWscSsidLen);
		pStaCfg->SsidLen = tmpWscSsidLen;
	} else
		WscStop(pAd,
#ifdef CONFIG_AP_SUPPORT
				FALSE,
#endif /* CONFIG_AP_SUPPORT */
				&wdev->WscControl);

#endif /* WSC_STA_SUPPORT */
	MlmeUpdateTxRates(pAd, TRUE, wdev->wdev_idx);
#ifdef DOT11_N_SUPPORT
	MlmeUpdateHtTxRates(pAd, wdev->wdev_idx);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("!!! LINK UP !! (StaActive.bHtEnable =%d)\n",
			 pStaCfg->StaActive.SupportedPhyInfo.bHtEnable));
#endif /* DOT11_N_SUPPORT */
#ifdef DOT11_VHT_AC
	MlmeUpdateVhtTxRates(pAd, pEntry, wdev->wdev_idx);
#endif /* DOT11_VHT_AC */
#ifdef WAPI_SUPPORT

	if (IS_CIPHER_WPI_SMS4(pEntry->SecConfig.PairwiseCipher))
		RTMPInitWapiRekeyTimerByMacEntry(pAd, pEntry);

#endif /* WAPI_SUPPORT */

	/* TODO: shiang-usw, revise this! */
	if (CLIENT_STATUS_TEST_FLAG(pEntry, fCLIENT_STATUS_PIGGYBACK_CAPABLE)) {
		AsicSetPiggyBack(pAd, TRUE);
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Turn on Piggy-Back\n"));
	}

#ifdef DOT11_N_SUPPORT

	if (CLIENT_STATUS_TEST_FLAG(pEntry, fCLIENT_STATUS_RDG_CAPABLE)
		&& CLIENT_STATUS_TEST_FLAG(pEntry, fCLIENT_STATUS_RALINK_CHIPSET)) {
		/* AsicSetRDG(pAd, pEntry->wcid, HcGetBandByWdev(pEntry->wdev), 1, 1); */
	}

#endif /* DOT11_N_SUPPORT */

#ifdef STA_LP_PHASE_1_SUPPORT
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Add TxSType(PID_NULL_FRAME_PWR_SAVE)\n"));
	AddTxSTypePerPkt(pAd, PID_NULL_FRAME_PWR_SAVE, TXS_FORMAT0, NullFramePM1TxSHandler);
#endif /* STA_LP_PHASE_1_SUPPORT */
}


/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID LinkUp(RTMP_ADAPTER *pAd, UCHAR BssType, struct wifi_dev *wdev)
{
	ULONG Now;
	BOOLEAN Cancelled, bDoTxRateSwitch = FALSE;
	/* UCHAR idx = 0; */
	MAC_TABLE_ENTRY *pEntry = NULL;
	STA_TR_ENTRY *tr_entry;
#if 1 /* def WSC_STA_SUPPORT */
	UCHAR tmpWscSsid[MAX_LEN_OF_SSID] = { 0 };
	UCHAR tmpWscSsidLen = 0;
#endif /* WSC_STA_SUPPORT */
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	UCHAR BandIdx;
	ADD_HT_INFO_IE *addht;

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef CONFIG_MULTI_CHANNEL
#if defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT)
	BSS_STRUCT *pMbss = &pAd->ApCfg.MBSSID[CFG_GO_BSSID_IDX];
	PAPCLI_STRUCT pApCliEntry = &pAd->ApCfg.ApCliTab[MAIN_MBSSID];
	MAC_TABLE_ENTRY *pMacEntry = NULL;
	struct wifi_dev *p2p_wdev = NULL;
#endif /* defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT) */
#endif /* CONFIG_MULTI_CHANNEL */
	/* Init ChannelQuality to prevent DEAD_CQI at initial LinkUp */
	pStaCfg->ChannelQuality = 50;
	/* init to not doing improved scan */
	pStaCfg->bImprovedScan = FALSE;
	pStaCfg->bNotFirstScan = TRUE;
	pStaCfg->bAutoConnectByBssid = FALSE;
#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	pStaCfg->CountDowntoPsm = STAY_10_SECONDS_AWAKE;
#else
#ifdef RTMP_MAC_USB
	/* Within 10 seconds after link up, don't allow to go to sleep. */
	pStaCfg->CountDowntoPsm = STAY_10_SECONDS_AWAKE;
#endif /* RTMP_MAC_USB */
#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */
#ifdef DOT11R_FT_SUPPORT
	pStaCfg->Dot11RCommInfo.FtRspSuccess = 0;

	if ((BssType == BSS_INFRA) && (pStaCfg->Dot11RCommInfo.bFtSupport)) {
		if (pStaCfg->Dot11RCommInfo.bInMobilityDomain == FALSE) {
			FT_SET_MDID(pStaCfg->Dot11RCommInfo.MdIeInfo.MdId,
						pStaCfg->MlmeAux.MdIeInfo.MdId);
			NdisZeroMemory(pStaCfg->Dot11RCommInfo.R0khId,
						   FT_ROKH_ID_LEN);
			NdisMoveMemory(pStaCfg->Dot11RCommInfo.R0khId,
						   pStaCfg->MlmeAux.FtIeInfo.R0khId,
						   pStaCfg->MlmeAux.FtIeInfo.R0khIdLen);
			pStaCfg->Dot11RCommInfo.R0khIdLen = pStaCfg->MlmeAux.FtIeInfo.R0khIdLen;

			if (pStaCfg->AuthMode == Ndis802_11AuthModeWPA2PSK) {
				/* Update PMK. */
				if (pStaCfg->WpaPassPhraseLen == 64)
					AtoH(pStaCfg->WpaPassPhrase, pStaCfg->PMK, 32);
				else {
					UCHAR keyMaterial[40] = { 0 };

					RtmpPasswordHash(pStaCfg->WpaPassPhrase,
									 pStaCfg->MlmeAux.Ssid,
									 pStaCfg->MlmeAux.SsidLen,
									 keyMaterial);
					NdisMoveMemory(pStaCfg->PMK, keyMaterial, 32);
				}
			}
		} else {
			/* Update Reconnect Ssid, that user desired to connect. */
			NdisZeroMemory(pStaCfg->MlmeAux.AutoReconnectSsid, MAX_LEN_OF_SSID);
			NdisMoveMemory(pStaCfg->MlmeAux.AutoReconnectSsid,
						   pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen);
			pStaCfg->MlmeAux.AutoReconnectSsidLen = pStaCfg->MlmeAux.SsidLen;
		}
	}

#endif /* DOT11R_FT_SUPPORT */
	pEntry = GetAssociatedAPByWdev(pAd, wdev);

	if (pEntry == NULL) {
		ASSERT(pEntry)
		return;
	}

	addht = wlan_operate_get_addht(wdev);
	tr_entry = &pAd->MacTab.tr_entry[pEntry->wcid];
	/*for rate adapter can refer wdev to get phy mode & channel*/
	pEntry->wdev = wdev;
	/*
	 *	ASSOC - DisassocTimeoutAction
	 *	CNTL - Dis-associate successful
	 *	!!! LINK DOWN !!!
	 *	[88888] OID_802_11_SSID should have returned NDTEST_WEP_AP2(Returned: )
	 */
	/*
	 *	To prevent DisassocTimeoutAction to call Link down after we link up,
	 *	cancel the DisassocTimer no matter what it start or not.
	 */
	RTMPCancelTimer(&pStaCfg->MlmeAux.DisassocTimer, &Cancelled);
#ifdef WSC_STA_SUPPORT
	tmpWscSsidLen = pStaCfg->SsidLen;
	NdisMoveMemory(tmpWscSsid, pStaCfg->Ssid, tmpWscSsidLen);
#endif /* WSC_STA_SUPPORT */
	COPY_SETTINGS_FROM_MLME_AUX_TO_ACTIVE_CFG(pAd, pStaCfg, pEntry);
#ifdef DOT11_N_SUPPORT
	COPY_HTSETTINGS_FROM_MLME_AUX_TO_ACTIVE_CFG(pAd, pEntry, pStaCfg);
#ifdef MESH_SUPPORT
	NdisMoveMemory(&pAd->CommonCfg.HtCapability, &pStaCfg->MlmeAux.HtCapability, sizeof(HT_CAPABILITY_IE));
	NdisMoveMemory(addht, &pStaCfg->MlmeAux.AddHtInfo, sizeof(ADD_HT_INFO_IE));
#endif /* MESH_SUPPORT */
#endif /* DOT11_N_SUPPORT */
#ifdef P2P_SUPPORT
	{
		PAPCLI_STRUCT pApCliEntry = NULL;

		pApCliEntry = &pAd->ApCfg.ApCliTab[BSS0];

		if (P2P_GO_ON(pAd) || (pApCliEntry->Valid == TRUE)) {
#ifdef DOT11_N_SUPPORT

			if (pStaCfg->MlmeAux.bBwFallBack == TRUE)
				wlan_operate_set_ht_bw(wdev, HT_BW_20, EXTCHA_NONE);

#endif /* DOT11_N_SUPPORT */
		}
	}
#endif /* P2P_SUPPORT */

	if (BssType == BSS_ADHOC) {
		OPSTATUS_SET_FLAG(pAd, fOP_STATUS_ADHOC_ON);
		STA_STATUS_CLEAR_FLAG(pStaCfg, fSTA_STATUS_INFRA_ON);
#ifdef CARRIER_DETECTION_SUPPORT	/* Roger sync Carrier */
		/* No carrier detection when adhoc */
		/* CarrierDetectionStop(pAd); */
		pAd->CommonCfg.CarrierDetect.CD_State = CD_NORMAL;
#endif /* CARRIER_DETECTION_SUPPORT */
#ifdef DOT11_N_SUPPORT

		if (WMODE_CAP_N(wdev->PhyMode)
			&& (pStaCfg->bAdhocN == TRUE))
			AdhocTurnOnQos(pAd, pStaCfg);

#endif /* DOT11_N_SUPPORT */
		InitChannelRelatedValue(pAd, wdev);
	} else {
		STA_STATUS_SET_FLAG(pStaCfg, fSTA_STATUS_INFRA_ON);
		OPSTATUS_CLEAR_FLAG(pAd, fOP_STATUS_ADHOC_ON);
		STA_STATUS_SET_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED);
#ifdef MT76XX_BTCOEX_SUPPORT

		if (pStaCfg->MlmeAux.bStaCanRoam) {
			MLMEHook(pAd, WLAN_ROAMING_COMPLETE, QueryHashID(pAd, pStaCfg->Bssid, FALSE));
			pStaCfg->MlmeAux.bStaCanRoam = FALSE;
		} else
			MLMEHook(pAd, WLAN_CONNECTION_COMPLETION, QueryHashID(pAd, pStaCfg->Bssid, FALSE));

#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef COEX_SUPPORT
		if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd)) {
			if ((pAd->BtWlanStatus & COEX_STATUS_LINK_UP) != 0)
				MT76xxMLMEHook(pAd, MT76xx_WLAN_LINK_DONE, 0);
		}
#endif /* COEX_SUPPORT */

	}

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("!!!%s LINK UP !!!\n", (BssType == BSS_ADHOC ? "ADHOC" : "Infra")));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("!!! LINK UP !!! wdev %d, (BssType=%d, AID=%d, ssid=%s, Channel=%d, CentralChannel = %d)\n",
			  wdev->func_idx, BssType, pStaCfg->StaActive.Aid, pStaCfg->Ssid,
			  wdev->channel, wlan_operate_get_cen_ch_1(wdev)));
	NdisGetSystemUpTime(&Now);
	pStaCfg->LastBeaconRxTime = Now;	/* last RX timestamp */
#ifdef DOT11_N_SUPPORT
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("!!! LINK UP !!! (Density =%d, )\n", pEntry->MpduDensity));
#endif /* DOT11_N_SUPPORT */
#ifdef STREAM_MODE_SUPPORT
	/*  Enable stream mode for BSSID MAC Address */
	pEntry->StreamModeMACReg = TX_CHAIN_ADDR1_L;
	AsicSetStreamMode(pAd, &pStaCfg->Bssid[0], 1, TRUE);
#endif /* STREAM_MODE_SUPPORT */
	HW_SET_SLOTTIME(pAd, TRUE, wdev->channel, wdev);
#ifdef WMM_ACM_SUPPORT
	/* reset the ACM flag after association ok;
	 * different ACM configuration for different APs
	 */
	ACMP_EnableFlagReset(pAd,
						 pAd->CommonCfg.APEdcaParm[0].bACM[0],
						 pAd->CommonCfg.APEdcaParm[0].bACM[1],
						 pAd->CommonCfg.APEdcaParm[0].bACM[2],
						 pAd->CommonCfg.APEdcaParm[0].bACM[3]);
#endif /* WMM_ACM_SUPPORT */
	/*
	 *	Call this for RTS protectionfor legacy rate, we will always enable RTS threshold,
	 *	but normally it will not hit
	 */
#ifdef DOT11_N_SUPPORT

	if (pStaCfg->StaActive.SupportedPhyInfo.bHtEnable == TRUE) {
		ADD_HTINFO2 *ht_info2 = &pStaCfg->MlmeAux.AddHtInfo.AddHtInfo2;

		wdev->protection &= ~(SET_PROTECT(ERP));

		if (ht_info2->OperaionMode < _NOT_DEFINE_HT_PROTECT)
			wdev->protection |= SET_PROTECT(ht_info2->OperaionMode);
		else
			wdev->protection |= SET_PROTECT(_NOT_DEFINE_HT_PROTECT);

		if (ht_info2->NonGfPresent == 1)
			wdev->protection |= SET_PROTECT(GREEN_FIELD_PROTECT);
		else
			wdev->protection &= ~(SET_PROTECT(GREEN_FIELD_PROTECT));

		AsicUpdateProtect(pAd);
	}

#endif /* DOT11_N_SUPPORT */

	if ((pAd->CommonCfg.TxPreamble != Rt802_11PreambleLong) &&
		CAP_IS_SHORT_PREAMBLE_ON(pStaCfg->StaActive.CapabilityInfo)) {
#ifdef RELEASE_EXCLUDE
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("CNTL - !!! Set to short preamble!!!\n"));
#endif /* RELEASE_EXCLUDE */
		MlmeSetTxPreamble(pAd, Rt802_11PreambleShort);
	}

	pAd->Dot11_H.RDMode = RD_NORMAL_MODE;

	if (BssType == BSS_ADHOC)
		LinkUp_Adhoc(pAd, wdev, pEntry);
	else
		LinkUp_Infra(pAd, wdev, pEntry, tmpWscSsid, tmpWscSsidLen);

#ifdef WSC_STA_SUPPORT
#ifdef WSC_LED_SUPPORT

	/*
	 *	LED indication.
	 *
	 *
	 *	LEDConnectionCompletion(pAd, TRUE);
	 *
	 *	If we call LEDConnectionCompletion, it will enqueue cmdthread to send asic mcu
	 *	command, this may be happen that sending the mcu command with
	 *	LED_NORMAL_CONNECTION_WITH_SECURITY will be later than sending the mcu
	 *	command with LED_LINK_UP.
	 *
	 *	It will cause Tx power LED be unusual after scanning, since firmware
	 *	only do Tx power LED in link up state.
	 */
	/*if (pStaCfg->WscControl.bWPSSession == FALSE) */
	if (wdev->WscControl.WscConfMode == WSC_DISABLE) {
		if (LED_MODE(pAd) == WPS_LED_MODE_9) {	/* LED mode 9. */
			UCHAR led_status;

			if (IS_NO_SECURITY_Entry(wdev))
				led_status = LED_NORMAL_CONNECTION_WITHOUT_SECURITY;
			else
				led_status = LED_NORMAL_CONNECTION_WITH_SECURITY;

			RTMPSetLED(pAd, led_status);
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s: LedConnSecurityStatus(%d)\n",
					 __func__, led_status));
		}
	}

#endif /* WSC_LED_SUPPORT */
#endif /* WSC_STA_SUPPORT */
#ifdef DOT11_N_SUPPORT
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("NDIS_STATUS_MEDIA_CONNECT Event B!.BACapability = %x. ClientStatusFlags = %lx\n",
			  pAd->CommonCfg.BACapability.word,
			  pEntry->ClientStatusFlags));
#endif /* DOT11_N_SUPPORT */
#ifdef LED_CONTROL_SUPPORT
	RTMPSetLED(pAd, LED_LINK_UP);
#endif /* LED_CONTROL_SUPPORT */
	pAd->Mlme.PeriodicRound = 0;
	pAd->Mlme.OneSecPeriodicRound = 0;
	pStaCfg->bConfigChanged = FALSE;	/* Reset config flag */
	pAd->ExtraInfo = GENERAL_LINK_UP;	/* Update extra information to link is up */
	NdisAcquireSpinLock(&pAd->MacTabLock);
	pEntry->HTPhyMode.word = wdev->HTPhyMode.word;
	pEntry->MaxHTPhyMode.word = wdev->MaxHTPhyMode.word;

	if (wdev->bAutoTxRateSwitch == FALSE) {
		bDoTxRateSwitch = FALSE;
#ifdef DOT11_N_SUPPORT

		if (pEntry->HTPhyMode.field.MCS == 32)
			pEntry->HTPhyMode.field.ShortGI = GI_800;

		if ((pEntry->HTPhyMode.field.MCS > MCS_7)
			|| (pEntry->HTPhyMode.field.MCS == 32))
			pEntry->HTPhyMode.field.STBC = STBC_NONE;

#endif /* DOT11_N_SUPPORT */

		/* If the legacy mode is set, overwrite the transmit setting of this entry. */
		if (pEntry->HTPhyMode.field.MODE <= MODE_OFDM)
			RTMPUpdateLegacyTxSetting((UCHAR) wdev->DesiredTransmitSetting.field.FixedTxMode, pEntry);
	} else
		bDoTxRateSwitch = TRUE;

	MSDU_FORBID_CLEAR(wdev, MSDU_FORBID_CONNECTION_NOT_READY);
	NdisReleaseSpinLock(&pAd->MacTabLock);
#ifdef MT_MAC

	if (IS_HIF_TYPE(pAd, HIF_MT)) {
		if (bDoTxRateSwitch == TRUE)
			pEntry->bAutoTxRateSwitch = TRUE;
		else {
			pEntry->bAutoTxRateSwitch = FALSE;

			if (pEntry->HTPhyMode.field.MODE == MODE_VHT) {
				pEntry->HTPhyMode.field.MCS = wdev->DesiredTransmitSetting.field.MCS +
											  ((wlan_operate_get_tx_stream(wdev) - 1) << 4);
			}
		}

		RAInit(pAd, pEntry);
#ifdef TXBF_SUPPORT
		/* Check whether disable/enable BF souding timer for STA mode only */
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():Send HW_STA_BF_SOUNDING_ADJUST Cmd\n", __func__));
		IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
			HW_STA_BF_SOUNDING_ADJUST(pAd, STATE_CONNECTED, wdev);
		}
#endif /* TXBF_SUPPORT */
	}

#endif /* MT_MAC */
	/*  Let Link Status Page display first initial rate. */
	pAd->LastTxRate = (USHORT) (pEntry->HTPhyMode.word);
	BandIdx = HcGetBandByWdev(wdev);
	AsicSetTxStream(pAd, pAd->Antenna.field.TxPath, OPMODE_STA, TRUE, BandIdx);
	pAd->CommonCfg.IOTestParm.bLastAtheros = FALSE;
#ifdef WPA_SUPPLICANT_SUPPORT

	/*
	 *   If STA connects to different AP, STA couldn't send EAPOL_Start for WpaSupplicant.
	 */
	if ((pStaCfg->BssType == BSS_INFRA) &&
		(IS_AKM_WPA2_Entry(wdev)) &&
		(NdisEqualMemory(pStaCfg->Bssid, pStaCfg->LastBssid, MAC_ADDR_LEN) == FALSE) &&
		(pStaCfg->wpa_supplicant_info.bLostAp == TRUE))
		pStaCfg->wpa_supplicant_info.bLostAp = FALSE;

#endif /* WPA_SUPPLICANT_SUPPORT */
	/*
	 *   Need to check this COPY. This COPY is from Windows Driver.
	 */
#ifdef DOT11V_WNM_SUPPORT
	WNM_Init(pAd);
#endif /* DOT11V_WNM_SUPPORT */
	COPY_MAC_ADDR(pStaCfg->LastBssid, pStaCfg->Bssid);
	/* BSSID add in one MAC entry too.  Because in Tx, ASIC need to check Cipher and IV/EIV, BAbitmap */
	/* Pther information in MACTab.Content[BSSID_WCID] is not necessary for driver. */
	/* Note: As STA, The MACTab.Content[BSSID_WCID]. PairwiseKey and Shared Key for BSS0 are the same. */
	RTMP_CLEAR_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS);
	/*RTMP_CLEAR_PSFLAG(pAd, fRTMP_PS_GO_TO_SLEEP_NOW); */
#ifdef WSC_STA_SUPPORT

	/* WSC initial connect to AP, jump to Wsc start action and set the correct parameters */
	if ((wdev->WscControl.WscConfMode != WSC_DISABLE) &&
		(wdev->WscControl.bWscTrigger
#ifdef STA_EASY_CONFIG_SETUP
		 || (wdev->EasyConfigInfo.bDoAutoWps
			 && (wdev->WscControl.WscConfMode == WSC_ENROLLEE))
#endif /* STA_EASY_CONFIG_SETUP */
		)) {
		RtmpusecDelay(100000);	/* 100 ms */

		if (pStaCfg->BssType == BSS_INFRA) {
			NdisMoveMemory(wdev->WscControl.WscPeerMAC,
						   pStaCfg->Bssid, MAC_ADDR_LEN);
			NdisMoveMemory(wdev->WscControl.EntryAddr,
						   pStaCfg->Bssid, MAC_ADDR_LEN);
			WscSendEapolStart(pAd,
							  wdev->WscControl.WscPeerMAC,
							  STA_MODE,
							  wdev);
		}

#ifdef STA_EASY_CONFIG_SETUP

		if (pStaCfg->EasyConfigInfo.bDoAutoWps) {
			RTMPCancelTimer(&pStaCfg->EasyConfigInfo.InfraConnTimer, &Cancelled);
			RTMPSetTimer(&pStaCfg->EasyConfigInfo.InfraConnTimer, WSC_TWO_MINS_TIME_OUT);
		}

#endif /* STA_EASY_CONFIG_SETUP */
	}

#endif /* WSC_STA_SUPPORT */
#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3

	if (INFRA_ON(pStaCfg)) {
		if ((pAd->CommonCfg.bBssCoexEnable == TRUE)
			&& (wdev->channel <= 14)
			&& (pStaCfg->StaActive.SupportedPhyInfo.bHtEnable == TRUE)
			&& (pStaCfg->MlmeAux.ExtCapInfo.BssCoexistMgmtSupport == 1)) {
			OPSTATUS_SET_FLAG(pAd, fOP_STATUS_SCAN_2040);
			BuildEffectedChannelList(pAd, wdev);
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("LinkUP AP supports 20/40 BSS COEX, Dot11BssWidthTriggerScanInt[%d]\n",
					  pAd->CommonCfg.Dot11BssWidthTriggerScanInt));
		} else {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("not supports 20/40 BSS COEX !!!\n"));
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("pAd->CommonCfg Info: bBssCoexEnable=%d, Channel=%d, CentralChannel=%d, PhyMode=%d\n",
					  pAd->CommonCfg.bBssCoexEnable, wdev->channel,
					  wlan_operate_get_cen_ch_1(wdev), wdev->PhyMode));
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("pStaCfg->StaActive.SupportedHtPhy.bHtEnable=%d\n",
					  pStaCfg->StaActive.SupportedPhyInfo.bHtEnable));
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("pStaCfg->MlmeAux.ExtCapInfo.BssCoexstSup=%d\n",
					  pStaCfg->MlmeAux.ExtCapInfo.BssCoexistMgmtSupport));
		}
	}

#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
#ifdef WPA_SUPPLICANT_SUPPORT

	/*
	 *   When AuthMode is WPA2-Enterprise and AP reboot or STA lost AP,
	 *   WpaSupplicant would not send EapolStart to AP after STA re-connect to AP again.
	 *   In this case, driver would send EapolStart to AP.
	 */
	if ((pStaCfg->BssType == BSS_INFRA) &&
		(IS_AKM_WPA2_Entry(wdev)) &&
		(NdisEqualMemory
		 (pStaCfg->Bssid, pStaCfg->LastBssid, MAC_ADDR_LEN))
		&& (pStaCfg->wpa_supplicant_info.bLostAp == TRUE)) {
		WpaSendEapolStart(pAd, pStaCfg->Bssid, &pStaCfg->wdev);
		pStaCfg->wpa_supplicant_info.bLostAp = FALSE;
	}

#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef CONFIG_MULTI_CHANNEL
	/*if INFRA connect and GO not ready , make pAd->Mlme.BeaconSyncafterAP = TRUE for */
#ifdef RT_CFG80211_SUPPORT
#ifdef CONFIG_AP_SUPPORT

	if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd))
		p2p_wdev = &pMbss->wdev;
	else if (RTMP_CFG80211_VIF_P2P_CLI_ON(pAd))
		p2p_wdev = &pApCliEntry->wdev;

	/* start MCC when Infra connect */
	if (p2p_wdev
		&& ((wdev->AuthMode == Ndis802_11AuthModeOpen) && !(pStaCfg->wpa_supplicant_info.WpaSupplicantUP & WPA_SUPPLICANT_ENABLE_WPS)) /* WPS not under goining! */
	   ) {
		UCHAR op_ht_bw1 = wlan_operate_get_ht_bw(wdev);
		UCHAR op_ht_bw2 = wlan_operate_get_ht_bw(p2p_wdev);

		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("p2p_wdev->channel %d wdev->channel %d\n", p2p_wdev->channel, wdev->channel));

		if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd)) {
			if ((op_ht_bw1 != op_ht_bw2) && ((wdev->channel == p2p_wdev->channel))) {
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("start bw !=  && P2P GO SCC\n"));
				pAd->Mlme.bStartScc = TRUE;
			} else if ((((op_ht_bw1 == op_ht_bw2) && (wdev->channel != p2p_wdev->channel))
						|| !((op_ht_bw1 == op_ht_bw2) && ((wdev->channel == p2p_wdev->channel))))) {
				LONG timeDiff;
				INT starttime = pAd->Mlme.channel_1st_staytime;

				NdisGetSystemUpTime(&pAd->Mlme.BeaconNow32);
				timeDiff = (pAd->Mlme.BeaconNow32 - pStaCfg->LastBeaconRxTime) % (pAd->CommonCfg.BeaconPeriod);
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("#####pAd->Mlme.Now32 %lu pStaCfg->LastBeaconRxTime %lu\n", pAd->Mlme.BeaconNow32, pStaCfg->LastBeaconRxTime));
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("####    timeDiff %ld\n", timeDiff));
				AsicDisableSync(pAd, HW_BSSID_0);

				if (starttime > timeDiff)
					OS_WAIT((starttime - timeDiff));
				else
					OS_WAIT((starttime + (pAd->CommonCfg.BeaconPeriod - timeDiff)));

				AsicEnableApBssSync(pAd, pAd->CommonCfg.BeaconPeriod);
				Start_MCC(pAd);
				/* pAd->MCC_DHCP_Protect = TRUE; */
			}
		} else if (RTMP_CFG80211_VIF_P2P_CLI_ON(pAd)) {
			pMacEntry = &pAd->MacTab.Content[pApCliEntry->MacTabWCID];

			if (pMacEntry) {
				if (IS_ENTRY_APCLI(pMacEntry) && (pMacEntry->PairwiseKey.KeyLen == LEN_TK)) { /* P2P GC will have security */
					if ((op_ht_bw1 != op_ht_bw2) && ((wdev->channel == p2p_wdev->channel))) {
						MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("start bw !=  && P2P GC SCC\n"));
						pAd->Mlme.bStartScc = TRUE;
					}

					if ((((op_ht_bw1 == op_ht_bw2) && (wdev->channel != p2p_wdev->channel))
						 || !((op_ht_bw1 == op_ht_bw2) && ((wdev->channel == p2p_wdev->channel))))) {
						Start_MCC(pAd);
						/* pAd->MCC_DHCP_Protect = TRUE; */
					}
				}
			}
		}
	}

#endif /* CONFIG_AP_SUPPORT */
#endif /*RT_CFG80211_SUPPORT */
#endif /* CONFIG_MULTI_CHANNEL */
#ifdef THREADX
#ifdef EBS_RTIP
	dc_log_printf("IFACEID=%d", RtmpIfaceId);
	net_ipsource_signal(DC_NET_DRV_LINK_STATUS_UP, RtmpIfaceId);
	/*ipsource_signal(DC_NET_DRV_LINK_STATUS_UP, ifaceId); */
#endif /* EBS_RTIP */
#endif /* THREADX */
	pAd->MacTab.MsduLifeTime = 5; /* default 5 seconds */
#ifdef MICROWAVE_OVEN_SUPPORT
	pAd->CommonCfg.MO_Cfg.bEnable = TRUE;
#endif /* MICROWAVE_OVEN_SUPPORT */
#ifdef MT76XX_BTCOEX_SUPPORT

	if (IS_MT76XXBTCOMBO(pAd)) {
		UCHAR ht_bw = wlan_operate_get_ht_bw(wdev);
		UCHAR cen_ch = wlan_operate_get_cen_ch_1(wdev);

		BtAFHCtl(pAd, ht_bw, wdev->channel, cen_ch, FALSE);
		SendAndesAFH(pAd, ht_bw, wdev->channel, cen_ch, FALSE, QueryHashID(pAd, pStaCfg->Bssid, FALSE));
		TDDFDDExclusiveRequest(pAd,  COEX_MODE_RESET);
		EstablishFrameBundle(pAd, pStaCfg->Bssid, COEX_OPMODE_STA, pEntry);
		UpdateAndesNullFrameSpace(pAd);
	}

#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef COEX_SUPPORT
	if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd)) {
		AndesCoexProtectionFrameOP(pAd, COEX_Legacy_CCK, LONG_PREAMBLE_1M);

		if (CLIENT_STATUS_TEST_FLAG(pEntry, fCLIENT_STATUS_WMM_CAPABLE))
			AndesCoexBSSInfo(pAd, 1, 1);
		else
			AndesCoexBSSInfo(pAd, 1, 0);
	}

#endif /* COEX_SUPPORT */

	pStaCfg->wdev.bLinkUpDone = TRUE;
#ifdef RT_CFG80211_SUPPORT

	if (pStaCfg->wdev.bGotEapolPkt && pStaCfg->wdev.pEapolPktFromAP) {
		indicate_802_11_pkt(pAd, pStaCfg->wdev.pEapolPktFromAP, pStaCfg->wdev.wdev_idx);
		pStaCfg->wdev.bGotEapolPkt = FALSE;
	}

#endif /* RT_CFG80211_SUPPORT */
}


INT LinkDown_Adhoc(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
#ifdef ADHOC_WPA2PSK_SUPPORT
	INT i;
#endif /* ADHOC_WPA2PSK_SUPPORT */
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("!!! LINK DOWN 1!!!\n"));
#ifdef ADHOC_WPA2PSK_SUPPORT

	/* In an IBSS, a STA's SME responds to Deauthenticate frames from a STA by */
	/* deleting the PTKSA associated with that STA. (Spec. P802.11i/D10 P.19) */
	if (wdev->AuthMode == Ndis802_11AuthModeWPA2PSK) {
		for (i = 1; VALID_UCAST_ENTRY_WCID(pAd, i); i++) {
			if (IS_ENTRY_CLIENT(&pAd->MacTab.Content[i]))
				MlmeDeAuthAction(pAd,
								 &pAd->MacTab.Content[i],
								 REASON_DEAUTH_STA_LEAVING,
								 FALSE);
		}
	}

#endif /* ADHOC_WPA2PSK_SUPPORT */
	OPSTATUS_CLEAR_FLAG(pAd, fOP_STATUS_ADHOC_ON);
	STA_STATUS_CLEAR_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED);
	RTMP_IndicateMediaState(pAd, NdisMediaStateDisconnected);
	pAd->ExtraInfo = GENERAL_LINK_DOWN;
	BssTableDeleteEntry(&pAd->ScanTab, pStaCfg->Bssid,
						wdev->channel);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("MacTab.Size=%d\n", pAd->MacTab.Size));

	if (wdev_do_linkdown(wdev) != TRUE)
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: linkdown fail!", __func__));

#ifdef RT_CFG80211_SUPPORT
	CFG80211OS_DelSta(pAd->net_dev, pStaCfg->Bssid);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: del this ad-hoc %02x:%02x:%02x:%02x:%02x:%02x\n",
			 __func__, PRINT_MAC(pStaCfg->Bssid)));
#endif /* RT_CFG80211_SUPPORT */
	return TRUE;
}


INT LinkDown_Infra(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, BOOLEAN ReqByAP)
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
#ifdef RACTRL_FW_OFFLOAD_SUPPORT
	MAC_TABLE_ENTRY *pEntry = GetAssociatedAPByWdev(pAd, wdev);
#endif
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return FALSE;

	/* Infra structure mode */
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("!!! LINK DOWN INFRA!!!\n"));
#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	pStaCfg->PwrMgmt.bBeaconLost = FALSE;
	pStaCfg->PwrMgmt.bTriggerRoaming = FALSE;
#ifdef STA_LP_PHASE_1_SUPPORT
	RTMPClearEnterPsmNullBit(&pStaCfg->PwrMgmt);
#endif /* STA_LP_PHASE_1_SUPPORT */
#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */

#ifdef DOT11Z_TDLS_SUPPORT

	if (IS_TDLS_SUPPORT(pAd))
		TDLS_LinkTearDown(pAd, TRUE);

#endif /* DOT11Z_TDLS_SUPPORT */
#ifdef STA_EASY_CONFIG_SETUP

	if (ReqByAP) {
		/*
		 *   STA cannot know WEP key is valid or invalid in TX path(AP may change WEP key).
		 *   Change WepStatus to NONE for forcing STA to do auto provision again.
		 */
		if (wdev->WepStatus == Ndis802_11WEPEnabled)
			wdev->WepStatus = Ndis802_11WEPDisabled;

		pAd->Mlme.AutoProvisionMachine.CurrState = INFRA_AUTO_PROVISION;
		MlmeEnqueueWithWdev(pAd, AUTO_PROVISION_STATE_MACHINE,
							MT2_CONN_AP, 0, NULL, 0, wdev);
		RTMP_MLME_HANDLER(pAd);
	}

	pStaCfg->EasyConfigInfo.bDoAutoWps = FALSE;
#endif /* STA_EASY_CONFIG_SETUP */
	STA_STATUS_CLEAR_FLAG(pStaCfg, fSTA_STATUS_INFRA_ON);
	STA_STATUS_CLEAR_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED);
#ifdef DOT11V_WNM_SUPPORT
	WNM_Init(pAd);
#endif /* DOT11V_WNM_SUPPORT */
	/* Saved last SSID for linkup comparison */
	pStaCfg->LastSsidLen = pStaCfg->SsidLen;
	NdisMoveMemory(pStaCfg->LastSsid,
				   pStaCfg->Ssid,
				   pStaCfg->LastSsidLen);
	COPY_MAC_ADDR(pStaCfg->LastBssid,
				  pStaCfg->Bssid);

	if (pStaCfg->MlmeAux.CurrReqIsFromNdis == TRUE) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("NDIS_STATUS_MEDIA_DISCONNECT Event A!\n"));
		pStaCfg->MlmeAux.CurrReqIsFromNdis = FALSE;
	} else {
		if ((wdev->PortSecured == WPA_802_1X_PORT_SECURED)
			|| IS_AKM_OPEN(wdev->SecConfig.AKMMap)
			|| IS_AKM_SHARED(wdev->SecConfig.AKMMap)
			|| IS_AKM_AUTOSWITCH(wdev->SecConfig.AKMMap)) {
			/*
			 *	If disassociation request is from NDIS, then we don't need
			 *	to delete BSSID from entry. Otherwise lost beacon or receive
			 *	De-Authentication from AP, then we should delete BSSID
			 *	from BssTable.
			 *
			 *	If we don't delete from entry, roaming will fail.
			 */
			BssTableDeleteEntry(&pAd->ScanTab,
								pStaCfg->Bssid,
								wdev->channel);
		}
	}

	/*
	 *	restore back to -
	 *	1. long slot (20 us) or short slot (9 us) time
	 *	2. turn on/off RTS/CTS and/or CTS-to-self protection
	 *	3. short preamble
	 */
	OPSTATUS_CLEAR_FLAG(pAd, fOP_STATUS_BG_PROTECTION_INUSED);
#ifdef EXT_BUILD_CHANNEL_LIST

	/* Country IE of the AP will be evaluated and will be used. */
	if (pStaCfg->IEEE80211dClientMode != Rt802_11_D_None) {
		NdisMoveMemory(&pAd->CommonCfg.CountryCode[0],
					   &pStaCfg->StaOriCountryCode[0], 2);
		pAd->CommonCfg.Geography = pStaCfg->StaOriGeography;
		BuildChannelListEx(pAd);
	}

#endif /* EXT_BUILD_CHANNEL_LIST */
#ifdef MT76XX_BTCOEX_SUPPORT

	if (IS_MT76XXBTCOMBO(pAd)) {
		UCHAR ht_bw = wlan_operate_get_ht_bw(wdev);
		UCHAR cen_ch = wlan_operate_get_cen_ch_1(wdev);

		BtAFHCtl(pAd, ht_bw, wdev->channel, cen_ch, TRUE);
		SendAndesAFH(pAd, ht_bw,  wdev->channel, cen_ch, TRUE, QueryHashID(pAd, pAd->CommonCfg.Bssid, FALSE));
		/* Coex release protection frame */
		InvalidProtectionFrameSpace(pAd, pAd->CommonCfg.Bssid);
		UpdateAndesNullFrameSpace(pAd);
		RemoveProtectionFrameSpace(pAd, pAd->CommonCfg.Bssid);
		TDDFDDExclusiveRequest(pAd, COEX_MODE_RESET);
		MLMEHook(pAd, WLAN_CONNECTION_CANCEL_IND, QueryHashID(pAd, pAd->CommonCfg.Bssid, TRUE));
	}

#endif /*MT76XX_BTCOEX_SUPPORT*/
#ifdef COEX_SUPPORT
	if (IS_MT76x6(pAd) || IS_MT7637(pAd) || IS_MT7622(pAd))
		AndesCoexBSSInfo(pAd, 0, 0);

#endif /* COEX_SUPPORT */
#ifdef CONFIG_MULTI_CHANNEL
#if defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT)
	MAC_TABLE_ENTRY	*pMacEntry = (MAC_TABLE_ENTRY *)NULL;
	BSS_STRUCT *pMbss = &pAd->ApCfg.MBSSID[CFG_GO_BSSID_IDX];
	struct wifi_dev *pWdev = &pMbss->wdev;
	PAPCLI_STRUCT pApCliEntry = &pAd->ApCfg.ApCliTab[MAIN_MBSSID];

	pMacEntry = &pAd->MacTab.Content[pApCliEntry->MacTabWCID];
	/* pStaCfg->MlmeAux.InfraChannel = 0; */
	pStaCfg->wdev.channel = 0;
	wlan_operate_set_ht_bw(pStaCfg, HT_BW_20, EXTCHA_NONE);

	if (pAd->Mlme.bStartMcc == TRUE) {
		struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);

		cap->tssi_enable = TRUE; /* let host do tssi */
		pAd->Mlme.bStartMcc = FALSE;

		if (((pMacEntry->PairwiseKey.KeyLen == LEN_TK) && IS_ENTRY_APCLI(pMacEntry)) || RTMP_CFG80211_VIF_P2P_GO_ON(pAd)) { /* yiwei : PairwiseKey seems not clear in MacTableDeleteEntry() */
			/* need to park at GC channel */
			Stop_MCC(pAd, 1);
		} else {
			/* TODO :  need to care the wps case. */
			/* tmply don't care */
			Stop_MCC(pAd, 0);
		}
	}

	if (pAd->Mlme.bStartScc == TRUE) {
		pAd->Mlme.bStartScc = FALSE;

		if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd)) {
			UCHAR cfg_ht_bw = wlan_config_get_ht_bw(pWdev);
			UCHAR ext_cha = wlan_config_get_ext_cha(pWdev);

			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("link down and switch to GO bw %d   pWdev->CentralChanne  %d\n", op_ht_bw, pWdev->CentralChannel));
			wlan_operate_set_ht_bw(pWdev, cfg_ht_bw, ext_cha);
		}

		/*if p2p_cli*/
	}

#endif /* defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT) */
#endif /* CONFIG_MULTI_CHANNEL */
#ifdef RACTRL_FW_OFFLOAD_SUPPORT

	if (IS_HIF_TYPE(pAd, HIF_MT))
		pEntry->RaEntry.fgRaValid = FALSE;

#endif
#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Remove TxSType(PID_NULL_FRAME_PWR_SAVE)\n"));
	RemoveTxSTypePerPkt(pAd, PID_NULL_FRAME_PWR_SAVE, TXS_FORMAT0);
#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */
	return TRUE;
}


/*
 *	==========================================================================
 *
 *	Routine	Description:
 *		Disconnect current BSSID
 *
 *	Arguments:
 *		pAd				- Pointer to our adapter
 *		IsReqFromAP		- Request from AP
 *
 *	Return Value:
 *		None
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	Note:
 *		We need more information to know it's this requst from AP.
 *		If yes! we need to do extra handling, for example, remove the WPA key.
 *		Otherwise on 4-way handshaking will faied, since the WPA key didn't be
 *		remove while auto reconnect.
 *		Disconnect request from AP, it means we will start afresh 4-way handshaking
 *		on WPA mode.
 *
 *	==========================================================================
 */
VOID LinkDown(RTMP_ADAPTER *pAd, BOOLEAN IsReqFromAP, struct wifi_dev *wdev)
{
	UCHAR i;
#ifdef RTMP_USB_SUPPORT
	UCHAR acidx;
#endif /* RTMP_USB_SUPPORT */
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	MAC_TABLE_ENTRY *pEntry = GetAssociatedAPByWdev(pAd, wdev);
	UCHAR BandIdx;

	ASSERT(pStaCfg);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("[%s] wdev %d pEntry=%p\n", __func__, wdev->func_idx, (PVOID)pEntry));

	if (!pStaCfg)
		return;

	if (!pEntry) /* Nothig to linkdown */
		return;

	/* Do nothing if monitor mode is on */
	if (MONITOR_ON(pAd))
		return;

#ifdef MT_WOW_SUPPORT

	if (pAd->WOW_Cfg.bWoWRunning) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("[%s] WoW is running, skip!\n", __func__));
		return;
	}

#endif
#ifdef CONFIG_ATE

	/* Nothing to do in ATE mode. */
	if (ATE_ON(pAd))
		return;

#endif /* CONFIG_ATE */
	STA_STATUS_CLEAR_FLAG(pStaCfg, fSTA_STATUS_INFRA_ON);
	STA_STATUS_CLEAR_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED);
	pStaCfg->wdev.bLinkUpDone = FALSE;
#ifdef WMM_ACM_SUPPORT
	ACMP_StationDelete(pAd, ACMR_STA_ENTRY_GET(pAd, pAd->CommonCfg.Bssid));
#endif /* WMM_ACM_SUPPORT */
	RTMPSendWirelessEvent(pAd, IW_STA_LINKDOWN_EVENT_FLAG, NULL, BSS0, 0);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("!!! LINK DOWN !!!\n"));
	/* reset to not doing improved scan */
	pStaCfg->bImprovedScan = FALSE;
#ifdef RT_CFG80211_SUPPORT

	if (CFG80211DRV_OpsScanRunning(pAd))
		CFG80211DRV_OpsScanInLinkDownAction(pAd);

#endif /* RT_CFG80211_SUPPORT */
#ifdef RELEASE_EXCLUDE
	/*
	 *	The variable, fRTMP_PS_SET_PCI_CLK_OFF_COMMAND, comes form Windows source codes.
	 *	They use it to indicate whether or not the PCIe device is going power-saving.
	 *	In Window's codes, RTMPPCIeLinkCtrlSetting will turn on this flag and turn off in RTMPPCIeLinkCtrlRestore.
	 */
#endif /* RELEASE_EXCLUDE */

	if (pStaCfg->PwrMgmt.bDoze
		|| RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_IDLE_RADIO_OFF))
		RTMP_FORCE_WAKEUP(pAd, pStaCfg);

	if (ADHOC_ON(pAd))
		LinkDown_Adhoc(pAd, wdev);
	else
		LinkDown_Infra(pAd, wdev, IsReqFromAP);

#ifdef WAPI_SUPPORT

	if (IS_CIPHER_WPI_SMS4(wdev->SecConfig.PairwiseCipher)) {
		/* Cancel rekey timer */
		RTMPCancelWapiRekeyTimerByMacEntry(pAd, pEntry);
	}

#endif /* WAPI_SUPPORT */

	/*
	 *	if link down come from AP, we need to remove all WPA keys on WPA mode.
	 *	otherwise will cause 4-way handshaking failed, since the WPA key not empty.
	 */
	if ((IsReqFromAP) && (IS_AKM_WPA_CAPABILITY_Entry(wdev))) {
		/* Remove all WPA keys */
		RTMPWPARemoveAllKeys(pAd, wdev);
	}

#ifdef MT_MAC
#ifdef TXBF_SUPPORT
	/* Shihwei @20160509 */
	/* Check whether disable/enable BF souding timer for STA mode only */
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():Send HW_STA_BF_SOUNDING_ADJUST Cmd\n", __func__));
		HW_STA_BF_SOUNDING_ADJUST(pAd, STATE_DISCONNECT, wdev);
	}
#endif /* TXBF_SUPPORT */
#endif /* MT_MAC */
	/* reset tr_entry for B/M txQ */
	TRTableResetEntry(pAd, wdev->bss_info_argument.ucBcMcWlanIdx);
	MacTableDeleteEntry(pAd, pEntry->wcid, pEntry->Addr);
#ifdef MT_MAC

	if (ADHOC_ON(pAd)) {
		/* TODO: Need to add. */
	} else {
		if (wdev_do_linkdown(wdev) != TRUE)
			MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): link down fail!!\n", __func__));
	}

#endif /* MT_MAC */
	HW_SET_SLOTTIME(pAd, TRUE, wdev->channel, wdev);	/*FALSE); */
#ifdef RT_CFG80211_P2P_CONCURRENT_DEVICE

	if ((!RTMP_CFG80211_VIF_P2P_GO_ON(pAd)) && (!RTMP_CFG80211_VIF_P2P_CLI_ON(pAd)))
#else
#ifdef P2P_SUPPORT
	if ((!P2P_GO_ON(pAd)) && (!P2P_CLI_ON(pAd)))
#endif /* P2P_SUPPORT */
#endif /* RT_CFG80211_P2P_SUPPORT */
#ifdef LED_CONTROL_SUPPORT
		/* Set LED */
		RTMPSetLED(pAd, LED_LINK_DOWN);

	pAd->LedCntl.LedIndicatorStrength = 0xF0;
	RTMPSetSignalLED(pAd, -100);	/* Force signal strength Led to be turned off, firmware is not done it. */
#endif /* LED_CONTROL_SUPPORT */
#ifdef MESH_SUPPORT

	if (MESH_ON(pAd) && !ADHOC_ON(pAd))
		AsicEnableMESHSync(pAd);
	else
#endif /* MESH_SUPPORT */
#ifdef P2P_SUPPORT
		if (!P2P_GO_ON(pAd))
#endif /* P2P_SUPPORT */
			AsicDisableSync(pAd, HW_BSSID_0);

	pAd->Mlme.PeriodicRound = 0;
	pAd->Mlme.OneSecPeriodicRound = 0;
#ifdef DOT11_N_SUPPORT
	NdisZeroMemory(&pStaCfg->MlmeAux.HtCapability, sizeof(HT_CAPABILITY_IE));
	NdisZeroMemory(&pStaCfg->MlmeAux.AddHtInfo, sizeof(ADD_HT_INFO_IE));
	pStaCfg->MlmeAux.HtCapabilityLen = 0;
	pStaCfg->MlmeAux.NewExtChannelOffset = 0xff;
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("LinkDownCleanMlmeAux.ExtCapInfo!\n"));
	NdisZeroMemory((PUCHAR) (&pStaCfg->MlmeAux.ExtCapInfo),
				   sizeof(EXT_CAP_INFO_ELEMENT));
#endif /* DOT11_N_SUPPORT */

	/* Reset WPA-PSK state. Only reset when supplicant enabled */
	if (pStaCfg->WpaState != SS_NOTUSE) {
		pStaCfg->WpaState = SS_START;
		/* Clear Replay counter */
		NdisZeroMemory(pStaCfg->ReplayCounter, 8);
	}

	/* 802.1x port control */
#ifdef WPA_SUPPLICANT_SUPPORT

	/* Prevent clear PortSecured here with static WEP */
	/* NetworkManger set security policy first then set SSID to connect AP. */
	if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP &&
		(IS_CIPHER_WEP_Entry(wdev)) &&
		(wdev->SecConfig.IEEE8021X == FALSE))
		wdev->PortSecured = WPA_802_1X_PORT_SECURED;
	else
#endif /* WPA_SUPPLICANT_SUPPORT */
	{
		wdev->PortSecured = WPA_802_1X_PORT_NOT_SECURED;
		pStaCfg->PrivacyFilter = Ndis802_11PrivFilter8021xWEP;
	}

	NdisAcquireSpinLock(&pAd->MacTabLock);
	/* Pat: we cannot zero MacEntry, because we just enqueue a STAREC update job to execute later and it will refer to pEntry */
	/* It is not a good way, need to refine the STARec update flow */
	/* Rmove this. TODO: refine flow. NdisZeroMemory(pEntry, sizeof(MAC_TABLE_ENTRY)); */
	pAd->MacTab.tr_entry[pEntry->wcid].PortSecured = wdev->PortSecured;
	NdisReleaseSpinLock(&pAd->MacTabLock);
	pStaCfg->MicErrCnt = 0;
	RTMP_IndicateMediaState(pAd, NdisMediaStateDisconnected);
	/* Update extra information to link is up */
	pAd->ExtraInfo = GENERAL_LINK_DOWN;
	pStaCfg->StaActive.SupportedPhyInfo.bHtEnable = FALSE;
#ifdef RTMP_MAC_USB
	pAd->bUsbTxBulkAggre = FALSE;
#endif /* RTMP_MAC_USB */
	/* Clean association information */
	NdisZeroMemory(&pStaCfg->AssocInfo,
				   sizeof(NDIS_802_11_ASSOCIATION_INFORMATION));
	pStaCfg->AssocInfo.Length = sizeof(NDIS_802_11_ASSOCIATION_INFORMATION);
	pStaCfg->ReqVarIELen = 0;
	pStaCfg->ResVarIELen = 0;
	/* Reset RSSI value after link down */
	NdisZeroMemory((PUCHAR) (&pStaCfg->RssiSample),
				   sizeof(pStaCfg->RssiSample));
	/* Restore MlmeRate */
	pAd->CommonCfg.MlmeRate = pAd->CommonCfg.BasicMlmeRate;
	pAd->CommonCfg.RtsRate = pAd->CommonCfg.BasicMlmeRate;
#ifdef DOT11_N_SUPPORT

	/* TODO: shiang-6590, why we need to fallback to BW_20 here? How about the BW_10? */
	if (wlan_operate_get_ht_bw(wdev) != BW_20) {
#ifdef P2P_SUPPORT
		PAPCLI_STRUCT pApCliEntry = NULL;

		pApCliEntry = &pAd->ApCfg.ApCliTab[BSS0];

		if (!P2P_GO_ON(pAd) && (pApCliEntry->Valid == FALSE))
#endif /* P2P_SUPPORT */
		{
			wlan_operate_set_ht_bw(wdev, HT_BW_20, EXTCHA_NONE);
		}
	}

#endif /* DOT11_N_SUPPORT */
	BandIdx  = HcGetBandByWdev(wdev);
	AsicSetTxStream(pAd, pAd->Antenna.field.TxPath, OPMODE_STA, FALSE, BandIdx);
	/* After Link down, reset piggy-back setting in ASIC. Disable RDG. */
	AsicSetPiggyBack(pAd, FALSE);
#ifdef DOT11_N_SUPPORT
	pAd->CommonCfg.BACapability.word = pAd->CommonCfg.REGBACapability.word;
#endif /* DOT11_N_SUPPORT */
	/* Restore all settings in the following. */
	wdev->protection = 0; /* link down set to default */
	AsicUpdateProtect(pAd);
#ifdef DOT11_N_SUPPORT
	/* AsicSetRDG(pAd, pEntry->wcid, BandIdx, 0, 0); */
#endif /* DOT11_N_SUPPORT */
#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
	OPSTATUS_CLEAR_FLAG(pAd, fOP_STATUS_SCAN_2040);
	pAd->CommonCfg.BSSCoexist2040.word = 0;
	TriEventInit(pAd);

	for (i = 0; i < (pAd->ChannelListNum - 1); i++)
		pAd->ChannelList[i].bEffectedChannel = FALSE;

#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
	RTMP_CLEAR_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS);
#ifdef WIDI_SUPPORT

	/*
	 *	Send L2SDTA Disassociation status here
	 */
	if (pStaCfg->WscControl.bWscTrigger)
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("WPS is in Prgress; Not sending this LINK DOWN\n"));
	else {
		/* LastBssid is zero; Not sending this LINK DOWN */
		if (!MAC_ADDR_EQUAL(pAd->CommonCfg.LastBssid, ZERO_MAC_ADDR)) {
			WidiUpdateStateToDaemon(pAd, MIN_NET_DEVICE_FOR_MBSSID, WIDI_MSG_TYPE_ASSOC_STATUS,
									pAd->CommonCfg.LastBssid, NULL, 0, WIDI_DISASSOCIATED);
		} else
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("LastBssid is zero; Not sending this LINK DOWN\n"));
	}

#endif /* WIDI_SUPPORT */
#ifdef WPA_SUPPLICANT_SUPPORT
#ifndef NATIVE_WPA_SUPPLICANT_SUPPORT

	if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP) {
		/*send disassociate event to wpa_supplicant */
		RtmpOSWrielessEventSend(pAd->net_dev, RT_WLAN_EVENT_CUSTOM,
								RT_DISASSOC_EVENT_FLAG, NULL, NULL, 0);
	}

#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef NATIVE_WPA_SUPPLICANT_SUPPORT
	RtmpOSWrielessEventSend(pAd->net_dev, RT_WLAN_EVENT_CGIWAP, -1, NULL,
							NULL, 0);
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#ifdef RT_CFG80211_SUPPORT
	RT_CFG80211_LOST_AP_INFORM(pAd);
#endif /* RT_CFG80211_SUPPORT */

	if (pStaCfg->BssType != BSS_ADHOC)
		pStaCfg->bNotFirstScan = FALSE;
	else
		pStaCfg->bAdhocCreator = FALSE;

	/*After change from one ap to another , we need to re-init rssi for AdjustTxPower  */
	pStaCfg->RssiSample.AvgRssi[0] = -127;
	pStaCfg->RssiSample.AvgRssi[1] = -127;
	pStaCfg->RssiSample.AvgRssi[2] = -127;
	NdisZeroMemory(pStaCfg->ConnectinfoSsid, MAX_LEN_OF_SSID);
	NdisZeroMemory(pStaCfg->ConnectinfoBssid, MAC_ADDR_LEN);
	pStaCfg->ConnectinfoSsidLen  = 0;
	pStaCfg->ConnectinfoBssType  = 1;
	pStaCfg->ConnectinfoChannel = 0;
#ifdef RTMP_USB_SUPPORT
	/* RTUSBRejectPendingPackets(pAd); */
{
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
	UINT8 num_of_tx_ring = GET_NUM_OF_TX_RING(cap);

	for (acidx = 0; acidx < num_of_tx_ring; acidx++) {
		PHT_TX_CONTEXT  pHTTXContext = &(pAd->TxContext[acidx]);

		pHTTXContext->IRPPending = FALSE;
		pHTTXContext->NextBulkOutPosition = 0;
		pHTTXContext->ENextBulkOutPosition = 0;
		pHTTXContext->CurWritePosition = 0;
		pHTTXContext->CurWriteRealPos = 0;
		pHTTXContext->BulkOutSize = 0;
		pHTTXContext->bRingEmpty = TRUE;
		pHTTXContext->bCopySavePad = FALSE;
		pAd->BulkOutPending[acidx] = FALSE;
	}
}
#endif /* RTMP_USB_SUPPORT */
#ifdef DOT11_VHT_AC
	pStaCfg->MlmeAux.force_op_mode = 0;
	NdisZeroMemory(&pStaCfg->MlmeAux.op_mode, sizeof(OPERATING_MODE));
#endif
}


/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID IterateOnBssTab(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	MLME_START_REQ_STRUCT StartReq;
	MLME_JOIN_REQ_STRUCT JoinReq;
	ULONG BssIdx;
	BSS_ENTRY *pInBss = NULL;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	/* Change the wepstatus to original wepstatus */
	pStaCfg->PairwiseCipher = wdev->SecConfig.PairwiseCipher;
#ifdef WPA_SUPPLICANT_SUPPORT

	if (pStaCfg->wpa_supplicant_info.WpaSupplicantUP == WPA_SUPPLICANT_DISABLE)
#endif /* WPA_SUPPLICANT_SUPPORT */
		pStaCfg->GroupCipher = wdev->SecConfig.GroupCipher;

	BssIdx = pStaCfg->MlmeAux.BssIdx;

	if (pStaCfg->BssType == BSS_ADHOC) {
		if (BssIdx < pStaCfg->MlmeAux.SsidBssTab.BssNr) {
			pInBss = &pStaCfg->MlmeAux.SsidBssTab.BssEntry[BssIdx];
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("CNTL - iterate BSS %ld of %d\n", BssIdx,
					  pStaCfg->MlmeAux.SsidBssTab.BssNr));
			JoinParmFill(pAd, &JoinReq, BssIdx);
			MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_JOIN_REQ,
								sizeof(MLME_JOIN_REQ_STRUCT), &JoinReq, 0, wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_WAIT_JOIN;
#ifdef WSC_STA_SUPPORT

			if (wdev->WscControl.WscState >= WSC_STATE_START) {
				NdisMoveMemory(wdev->WscControl.WscPeerMAC, pInBss->MacAddr,
							   MAC_ADDR_LEN);
				NdisMoveMemory(wdev->WscControl.EntryAddr,
							   pInBss->MacAddr, MAC_ADDR_LEN);
			}

#endif /* WSC_STA_SUPPORT */
			return;
		}

#ifdef IWSC_SUPPORT

		if (wdev->WscControl.bWscTrigger == TRUE) {
			pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
			MlmeEnqueueWithWdev(pAd, IWSC_STATE_MACHINE, IWSC_MT2_MLME_RECONNECT, 0, NULL, 0, wdev);
			RTMP_MLME_HANDLER(pAd);
		} else
#endif /* IWSC_SUPPORT */
		{
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CNTL - All BSS fail; start a new ADHOC (Ssid=%s)...\n", pStaCfg->MlmeAux.Ssid));
			StartParmFill(pAd, &StartReq, (PCHAR) pStaCfg->MlmeAux.Ssid, pStaCfg->MlmeAux.SsidLen);
			MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_START_REQ, sizeof(MLME_START_REQ_STRUCT), &StartReq, 0, wdev);
			pStaCfg->CntlMachine.CurrState = CNTL_WAIT_START;
		}
	} else if ((BssIdx < pStaCfg->MlmeAux.SsidBssTab.BssNr) &&
			   (pStaCfg->BssType == BSS_INFRA)) {
		pInBss = &pStaCfg->MlmeAux.SsidBssTab.BssEntry[BssIdx];
		/*Check AuthMode of AP, may have more AuthMode Supported,eg WPA/WPA2*/
		/*Set the AKMMap according to sta/AP capablities */
		pStaCfg->AKMMap = wdev->SecConfig.AKMMap &  pInBss->AKMMap;

		if (IS_AKM_WPA1(pStaCfg->AKMMap) && IS_AKM_WPA2(pStaCfg->AKMMap)) {
			CLEAR_SEC_AKM(pStaCfg->AKMMap);
			SET_AKM_WPA2(pStaCfg->AKMMap);
		} else if (IS_AKM_WPA1PSK(pStaCfg->AKMMap) && IS_AKM_WPA2PSK(pStaCfg->AKMMap)) {
			CLEAR_SEC_AKM(pStaCfg->AKMMap);
			SET_AKM_WPA2PSK(pStaCfg->AKMMap);
		}

		/* Check cipher suite, AP must have more secured cipher than station setting */
		/* Set the Pairwise and Group cipher to match the intended AP setting */
		/* We can only connect to AP with less secured cipher setting */
		if (IS_AKM_WPA1(wdev->SecConfig.AKMMap)
			|| IS_AKM_WPA1PSK(wdev->SecConfig.AKMMap)) {
			pStaCfg->GroupCipher = pInBss->GroupCipher;
			CLEAR_CIPHER(pStaCfg->PairwiseCipher);

			if (IS_CIPHER_CCMP128(wdev->SecConfig.PairwiseCipher) && IS_CIPHER_CCMP128(pInBss->PairwiseCipher))
				SET_CIPHER_CCMP128(pStaCfg->PairwiseCipher);
			else	/* There is no PairCipher Aux, downgrade our capability to TKIP */
				SET_CIPHER_TKIP(pStaCfg->PairwiseCipher);
		}

		if (IS_AKM_WPA2(wdev->SecConfig.AKMMap)
			|| IS_AKM_WPA2PSK(wdev->SecConfig.AKMMap)) {
			pStaCfg->GroupCipher = pInBss->GroupCipher;
			CLEAR_CIPHER(pStaCfg->PairwiseCipher);

			if (IS_CIPHER_CCMP128(wdev->SecConfig.PairwiseCipher)
				&& IS_CIPHER_CCMP128(pInBss->PairwiseCipher))
				SET_CIPHER_CCMP128(pStaCfg->PairwiseCipher);
			else if (IS_CIPHER_CCMP256(wdev->SecConfig.PairwiseCipher)
					 && IS_CIPHER_CCMP256(pInBss->PairwiseCipher))
				SET_CIPHER_CCMP256(pStaCfg->PairwiseCipher);
			else if (IS_CIPHER_GCMP128(wdev->SecConfig.PairwiseCipher)
					 && IS_CIPHER_GCMP128(pInBss->PairwiseCipher))
				SET_CIPHER_GCMP128(pStaCfg->PairwiseCipher);
			else if (IS_CIPHER_GCMP256(wdev->SecConfig.PairwiseCipher)
					 && IS_CIPHER_GCMP256(pInBss->PairwiseCipher))
				SET_CIPHER_GCMP256(pStaCfg->PairwiseCipher);
			else	/* There is no PairCipher Aux, downgrade our capability to TKIP */
				SET_CIPHER_TKIP(pStaCfg->PairwiseCipher);

			/* RSN capability */
			pStaCfg->RsnCapability = pInBss->RsnCapability;
		}

#ifdef WAPI_SUPPORT
		else if (IS_AKM_WAICERT(wdev->SecConfig.AKMMap)
				 || IS_AKM_WPIPSK(wdev->SecConfig.AKMMap)) {
			pStaCfg->GroupCipher = pInBss->GroupCipher;
			pStaCfg->PairwiseCipher  = pInBss->PairwiseCipher;
		}

#endif /* WAPI_SUPPORT */
#if 0

		if (pStaCfg->bMixCipher == TRUE) {
			/* If mix cipher, re-build RSNIE */
			RTMPMakeRSNIE(pAd, pStaCfg->AuthMode,
						  pStaCfg->WepStatus, 0);
		}

#endif
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("CNTL - iterate BSS %ld of %d\n", BssIdx,
				  pStaCfg->MlmeAux.SsidBssTab.BssNr));
		JoinParmFill(pAd, &JoinReq, BssIdx);
		MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_JOIN_REQ,
							sizeof(MLME_JOIN_REQ_STRUCT), &JoinReq, 0, wdev);
		pStaCfg->CntlMachine.CurrState = CNTL_WAIT_JOIN;
	} else {
		/* no more BSS */
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("CNTL - All roaming failed, restore to channel %d, Total BSS[%02d]\n",
				  wdev->channel, pAd->ScanTab.BssNr));
#ifdef P2P_SUPPORT

		if (P2P_GO_ON(pAd) || P2P_CLI_ON(pAd))
			; /* Do NOT delete this entry here because ra interface cannot do all channel scan in this case. */
		else
#endif /* P2P_SUPPORT */
		{
			pStaCfg->MlmeAux.SsidBssTab.BssNr = 0;
			BssTableDeleteEntry(&pAd->ScanTab,
								pStaCfg->MlmeAux.SsidBssTab.BssEntry[0].Bssid,
								pStaCfg->MlmeAux.SsidBssTab.BssEntry[0].Channel);
		}

		pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
#ifdef WSC_STA_SUPPORT
#ifdef WSC_LED_SUPPORT
		/* LED indication. */
		LEDConnectionCompletion(pAd, FALSE);
#endif /* WSC_LED_SUPPORT */
#endif /* WSC_STA_SUPPORT */
	}
}


/* for re-association only */
/* IRQL = DISPATCH_LEVEL */
VOID IterateOnBssTab2(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	MLME_REASSOC_REQ_STRUCT ReassocReq;
	ULONG BssIdx;
	BSS_ENTRY *pBss;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	BssIdx = pStaCfg->MlmeAux.RoamIdx;
	pBss = &pStaCfg->MlmeAux.RoamTab.BssEntry[BssIdx];

	if (BssIdx < pStaCfg->MlmeAux.RoamTab.BssNr) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("CNTL - iterate BSS %ld of %d\n", BssIdx,
				  pStaCfg->MlmeAux.RoamTab.BssNr));
		wdev->channel = pBss->Channel;
		wlan_operate_set_prim_ch(wdev, wdev->channel);
		/* reassociate message has the same structure as associate message */
		AssocParmFill(pAd, &ReassocReq, pBss->Bssid,
					  pBss->CapabilityInfo, ASSOC_TIMEOUT,
					  pStaCfg->DefaultListenCount);
		MlmeEnqueueWithWdev(pAd, ASSOC_STATE_MACHINE, MT2_MLME_REASSOC_REQ,
							sizeof(MLME_REASSOC_REQ_STRUCT), &ReassocReq, 0, wdev);
		pStaCfg->CntlMachine.CurrState = CNTL_WAIT_REASSOC;
	} else {
		/* no more BSS */
		struct freq_cfg freq;

		os_zero_mem(&freq, sizeof(freq));
		freq.prim_ch = wdev->channel;
		freq.ext_cha = EXTCHA_NONE;
		freq.ht_bw = HT_BW_20;
		wlan_operate_set_phy(wdev, &freq);
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("%s():CNTL - All roaming failed, restore to Channel(Ctrl=%d, Central = %d)\n",
				  __func__, wdev->channel,
				  wlan_operate_get_cen_ch_1(wdev)));
	}

	pStaCfg->CntlMachine.CurrState = CNTL_IDLE;
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID JoinParmFill(
	IN PRTMP_ADAPTER pAd,
	IN OUT MLME_JOIN_REQ_STRUCT *JoinReq,
	IN ULONG BssIdx)
{
	JoinReq->BssIdx = BssIdx;
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID StartParmFill(
	IN PRTMP_ADAPTER pAd,
	IN OUT MLME_START_REQ_STRUCT *StartReq,
	IN CHAR Ssid[],
	IN UCHAR SsidLen)
{
	ASSERT(SsidLen <= MAX_LEN_OF_SSID);

	if (SsidLen > MAX_LEN_OF_SSID)
		SsidLen = MAX_LEN_OF_SSID;

	NdisMoveMemory(StartReq->Ssid, Ssid, SsidLen);
	StartReq->SsidLen = SsidLen;
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
VOID AuthParmFill(
	IN PRTMP_ADAPTER pAd,
	IN OUT MLME_AUTH_REQ_STRUCT *AuthReq,
	IN PUCHAR pAddr,
	IN USHORT Alg)
{
	COPY_MAC_ADDR(AuthReq->Addr, pAddr);
	AuthReq->Alg = Alg;
	AuthReq->Timeout = AUTH_TIMEOUT;
}

/*
 *	==========================================================================
 *	Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *	==========================================================================
 */
#ifdef RTMP_MAC_USB

VOID MlmeCntlConfirm(
	IN struct wifi_dev *wdev,
	IN ULONG MsgType,
	IN USHORT Msg)
{
	RTMP_ADAPTER *pAd = (RTMP_ADAPTER *)wdev->sys_handle;

	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MsgType, sizeof(USHORT),
						&Msg, 0, wdev);
}
#endif /* RTMP_MAC_USB */

VOID InitChannelRelatedValue(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	UINT8 ht_bw, ext_ch;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	UCHAR cen_ch = pStaCfg->MlmeAux.CentralChannel;

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#ifdef RTMP_MAC_PCI
	/* In power save , We will force use 1R. */
	/* So after link up, check Rx antenna # again. */
	bbp_set_rxpath(pAd, pAd->Antenna.field.RxPath);
#endif /* RTMP_MAC_PCI */
	wdev->channel = pStaCfg->MlmeAux.Channel;
#ifdef DOT11_N_SUPPORT

	/* Change to AP channel */
	if ((cen_ch > wdev->channel)
		&& (pStaCfg->MlmeAux.HtCapability.HtCapInfo.ChannelWidth == BW_40)) {
		ht_bw = BW_40;
		ext_ch = EXTCHA_ABOVE;
	} else if ((cen_ch < wdev->channel)
			   && (pStaCfg->MlmeAux.HtCapability.HtCapInfo.ChannelWidth == BW_40)) {
		ht_bw = BW_40;
		ext_ch = EXTCHA_BELOW;
	} else
#endif /* DOT11_N_SUPPORT */
	{
		ht_bw = BW_20;
		ext_ch = EXTCHA_NONE;
	}

	{
		struct freq_cfg freq;

		os_zero_mem(&freq, sizeof(freq));
		freq.prim_ch = wdev->channel;
		freq.ht_bw = ht_bw;
		freq.ext_cha = ext_ch;
		wlan_operate_set_phy(wdev, &freq);
	}

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("%s():BW_%s, CtrlChannel=%d, CentralChannel=%d\n",
			  __func__, (ht_bw == HT_BW_40 ? "40" : "20"),
			  wdev->channel,
			  cen_ch));
	/* Save BBP_R66 value, it will be used in RTUSBResumeMsduTransmission */
	bbp_get_agc(pAd, &pAd->BbpTuning.R66CurrentValue, RX_CHAIN_0);
}

VOID AdjustChannelRelatedValue(
	IN PRTMP_ADAPTER pAd,
	OUT UCHAR *pBwFallBack,
	IN USHORT ifIndex,
	IN BOOLEAN ht_bw,
	IN UCHAR PriCh,
	IN UCHAR cen_ch_1,
	IN struct wifi_dev *wdev)
{
	struct freq_cfg cfg;
	UCHAR ext_cha;
#ifdef DOT11_VHT_AC
	UCHAR vht_bw = VHT_BW_2040;
#endif /* DOT11_VHT_AC */
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	*pBwFallBack = 0;

	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_BSS_SCAN_IN_PROGRESS))
		return;

	wdev->channel = PriCh;
#ifdef DOT11_N_SUPPORT

	/* Change to AP channel */
	if ((cen_ch_1 > wdev->channel) && (ht_bw == HT_BW_40))
		ext_cha = EXTCHA_ABOVE;
	else if ((cen_ch_1 < wdev->channel) && (ht_bw == HT_BW_40))
		ext_cha = EXTCHA_BELOW;
	else
#endif /* DOT11_N_SUPPORT */
	{
		ht_bw = HT_BW_20;
		ext_cha = EXTCHA_NONE;
	}

#ifdef DOT11_VHT_AC

	if (ht_bw == HT_BW_40 &&
		pStaCfg->StaActive.SupportedPhyInfo.bVhtEnable == TRUE &&
		pStaCfg->StaActive.SupportedPhyInfo.vht_bw >= VHT_BW_80)
		vht_bw = pStaCfg->StaActive.SupportedPhyInfo.vht_bw;

#endif /* DOT11_VHT_AC */
	/*for STA connection usage*/
	os_zero_mem(&cfg, sizeof(cfg));
	cfg.prim_ch = wdev->channel;
	cfg.ht_bw = ht_bw;
	cfg.ext_cha = ext_cha;
	cfg.vht_bw = vht_bw;
	cfg.cen_ch_2 = wlan_operate_get_cen_ch_2(wdev);
	wlan_operate_set_phy(wdev, &cfg);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("%s(): RF-Ch=%d, CtrlCh=%d, CentralCh=%d, CentralCh2=%d, BW=%d\n",
			  __func__,
			  pAd->LatchRfRegs.Channel,
			  wdev->channel,
			  wlan_operate_get_cen_ch_1(wdev),
			  wlan_operate_get_cen_ch_2(wdev),
			  wlan_operate_get_bw(wdev)));
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("AdjustChannelRelatedValue ==> not any connection !!!\n"));
}

