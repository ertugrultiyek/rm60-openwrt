/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2004, Ralink Technology, Inc.
 *
 * All rights reserved. Ralink's source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of Ralink Tech. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	sta.c

	Abstract:
	initialization for STA module

	Revision History:
	Who		When			What
	--------	----------		----------------------------------------------
*/

#include "rt_config.h"

NET_DEV_STATS *RT28xx_get_ether_stats(PNET_DEV net_dev);

VOID STARxErrorHandle(RTMP_ADAPTER *pAd, RX_BLK *pRxBlk)
{
}

INT StaAllowToSendPacket_new(
	IN RTMP_ADAPTER *pAd,
	IN struct wifi_dev *wdev,
	IN PNDIS_PACKET pPacket,
	IN UCHAR * pWcid)
{
	MAC_TABLE_ENTRY *pEntry;
	PACKET_INFO PacketInfo;
	UCHAR *pSrcBufVA;
	UINT SrcBufLen;

	/* Drop send request since we are in monitor mode */
	/* TODO: shiang-usw, integrate this check to wdev->allow_data_tx = FALSE! */
	if (MONITOR_ON(pAd))
		return FALSE;

	RTMP_QueryPacketInfo(pPacket, &PacketInfo, &pSrcBufVA, &SrcBufLen);

	if (MAC_ADDR_IS_GROUP(pSrcBufVA)) {
		*pWcid = wdev->tr_tb_idx;
#ifdef CONFIG_FPGA_MODE
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s():Group Packet, wdev->tr_tb_idx=%d\n", __func__, wdev->tr_tb_idx));

		/* TODO: shiang-MT7603 work around! */
		if (IS_MT7603(pAd) || IS_MT7628(pAd) || IS_MT76x6(pAd) || IS_MT7637(pAd))
			*pWcid = wdev->bss_info_argument.ucBcMcWlanIdx;

#endif /* CONFIG_FPGA_MODE */
		return TRUE;
	}

	pEntry = MacTableLookup2(pAd, pSrcBufVA, wdev);

	if (pEntry)
		ASSERT((pEntry->wdev == wdev));

	if (pEntry && (pEntry->Sst == SST_ASSOC)) {
		*pWcid = (UCHAR)pEntry->wcid;
		return TRUE;
	}

	return FALSE;
}


INT sta_func_init(RTMP_ADAPTER *pAd)
{
#ifdef DOT11Z_TDLS_SUPPORT
	TDLS_Table_Init(pAd);
#endif /* DOT11Z_TDLS_SUPPORT */
#ifdef WPA_SUPPLICANT_SUPPORT
#ifndef NATIVE_WPA_SUPPLICANT_SUPPORT
	/* send wireless event to wpa_supplicant for infroming interface up.*/
	RtmpOSWrielessEventSend(pAd->net_dev, RT_WLAN_EVENT_CUSTOM, RT_INTERFACE_UP, NULL, NULL, 0);
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT */
#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef ETH_CONVERT_SUPPORT
	MATEngineInit(pAd);
#endif /* ETH_CONVERT_SUPPORT */
	return TRUE;
}

/* Initialize STA and the MAIN STA interface. */
INT STAInitialize(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
#ifdef ETH_CONVERT_SUPPORT
	extern UCHAR ZERO_MAC_ADDR[MAC_ADDR_LEN];
#endif
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return 0;

#ifdef ETH_CONVERT_SUPPORT

	if (NdisEqualMemory(&pAd->EthConvert.EthCloneMac[0], &ZERO_MAC_ADDR[0], MAC_ADDR_LEN)) {
		NdisMoveMemory(&pAd->EthConvert.EthCloneMac[0], &pAd->CurrentAddress[0], MAC_ADDR_LEN);
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Read EEPROM, EthCloneMac is %02x:%02x:%02x:%02x:%02x:%02x!\n",
				 PRINT_MAC(pAd->EthConvert.EthCloneMac)));
	}

#endif /* ETH_CONVERT_SUPPORT */
	pStaCfg->OriDevType = RTMP_OS_NETDEV_GET_TYPE(pAd->net_dev);
#ifdef CREDENTIAL_STORE
	NdisAllocateSpinLock(pAd, &pAd->StaCtIf.Lock);
#endif /* CREDENTIAL_STORE */
	pAd->MSTANum = 1;

	if (pAd->MaxMSTANum == 0) /* This mean profile has no setting for MaxMSTANum */
		pAd->MaxMSTANum = 1;

	return 0;
}



VOID rtmp_sta_init(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	STAInitialize(pAd, wdev);
#ifdef CREDENTIAL_STORE
	RecoverConnectInfo(pAd);
#endif /* CREDENTIAL_STORE */
#ifdef WMM_ACM_SUPPORT
	ACMP_Init(pAd, 0, 0, 0, 0, 0);
#endif /* WMM_ACM_SUPPORT */
	/* Set up the Mac address*//* Here is to set MAIN_MSTA_ID STA, Extend MSTA is set in MSTA_Open */
	NdisMoveMemory(&pStaCfg->wdev.if_addr[0], &pAd->CurrentAddress[0], MAC_ADDR_LEN);
	RtmpOSNetDevAddrSet(pAd->OpMode, pAd->net_dev, &pStaCfg->wdev.if_addr[0], (PUCHAR)(pStaCfg->dev_name));

	if (wdev_do_open(wdev) != TRUE)
		MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s() open fail!!!\n", __func__));

	RTMPSetPhyMode(pAd, &pStaCfg->wdev, pStaCfg->wdev.PhyMode);

	sta_func_init(pAd);
}


VOID RTMPStaCfgRadioCtrlFromEEPROM(RTMP_ADAPTER *pAd, EEPROM_NIC_CONFIG2_STRUC NicConfig2)
{
#ifdef RTMP_MAC_PCI

	/* Read Hardware controlled Radio state enable bit*/
	if (NicConfig2.field.HardwareRadioControl == 1) {
#if 0
		UINT32 data = 0;
		BOOLEAN radioOff = FALSE;
		{
			/* Read GPIO pin2 as Hardware controlled radio state*/
			RTMP_IO_READ32(pAd, GPIO_CTRL_CFG, &data);

			if ((data & 0x04) == 0)
				radioOff = TRUE;
		}

		if (radioOff) {
			pStaCfg->bHwRadio = FALSE;
			pStaCfg->bRadio = FALSE;
			/* RTMP_IO_WRITE32(pAd, PWR_PIN_CFG, 0x00001818); */
			RTMP_SET_FLAG(pAd, fRTMP_ADAPTER_RADIO_OFF);
		}

#endif
	} else
#endif /* RTMP_MAC_PCI */
	{
#if 0
		pStaCfg->bHardwareRadio = FALSE;
#endif
	}

#if 0
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Use Hw Radio Control Pin=%d\n",
			 pStaCfg->bHardwareRadio));
#ifdef LED_CONTROL_SUPPORT
	RTMPSetLED(pAd, pStaCfg->bRadio == FALSE ? LED_RADIO_OFF : LED_RADIO_ON);
#endif /* LED_CONTROL_SUPPORT */
#endif
#ifdef RTMP_MAC_PCI
#if 0

	if (pStaCfg->bRadio == TRUE) {
		AsicSendCmdToMcuAndWait(pAd, 0x30, PowerRadioOffCID, 0xff, 0x02, FALSE);
		/*AsicSendCommandToMcu(pAd, 0x30, 0xff, 0xff, 0x02, FALSE);*/
		AsicSendCmdToMcuAndWait(pAd, 0x31, PowerWakeCID, 0x00, 0x00, FALSE);
	}

#endif
#endif /* RTMP_MAC_PCI */
}

VOID RT28xx_MSTA_Init(VOID *pAd, PNET_DEV main_dev_p)
{
	RTMP_OS_NETDEV_OP_HOOK netDevHook;

	NdisZeroMemory(&netDevHook, sizeof(netDevHook));
	netDevHook.open = MSTA_VirtualIF_Open;  /* device opem hook point */
	netDevHook.stop = MSTA_VirtualIF_Close; /* device close hook point */
	netDevHook.xmit = rt28xx_send_packets;  /* hard transmit hook point */
	netDevHook.ioctl = rt28xx_ioctl;    /* ioctl hook point */
	netDevHook.get_stats = RT28xx_get_ether_stats;
	RTMP_STA_IoctlHandle(pAd, NULL, CMD_RTPRIV_IOCTL_MSTA_INIT,
						 0, &netDevHook, 0, 0);
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s <---\n", __func__));
#endif /* RELEASE_EXCLUDE */
}

VOID RT28xx_MSTA_Remove(VOID *pAd)
{
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s --->\n", __func__));
#endif /* RELEASE_EXCLUDE */
	RTMP_STA_IoctlHandle(pAd, NULL, CMD_RTPRIV_IOCTL_MSTA_REMOVE, 0, NULL, 0, 0);
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s <---\n", __func__));
#endif /* RELEASE_EXCLUDE */
}

INT MSTA_VirtualIF_Open(PNET_DEV pDev)
{
	VOID *pAd;

	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s: ===> %s\n", RTMP_OS_NETDEV_GET_DEVNAME(pDev), __func__));
	pAd = RTMP_OS_NETDEV_GET_PRIV(pDev);
	RTMP_STA_IoctlHandle(pAd, NULL, CMD_RTPRIV_IOCTL_MSTA_OPEN, 0, pDev, 0, 0);

	if (VIRTUAL_IF_UP(pAd, pDev) != 0)
		return -1;

	/* increase MODULE use count */
	RT_MOD_INC_USE_COUNT();
	RT_MOD_HNAT_REG(pDev);
	RTMP_OS_NETDEV_START_QUEUE(pDev);
	return 0;
}

INT MSTA_VirtualIF_Close(PNET_DEV pDev)
{
	VOID *pAd;

	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s: ===> %s\n", RTMP_OS_NETDEV_GET_DEVNAME(pDev), __func__));
	pAd = RTMP_OS_NETDEV_GET_PRIV(pDev);
	RTMP_OS_NETDEV_STOP_QUEUE(pDev);
	RTMP_STA_IoctlHandle(pAd, NULL, CMD_RTPRIV_IOCTL_MSTA_CLOSE, 0, pDev, 0, 0);
	VIRTUAL_IF_DOWN(pAd, pDev);
	RT_MOD_HNAT_DEREG(pDev);
	RT_MOD_DEC_USE_COUNT();
	return 0;
}

INT32 MSTA_IdxGet(RTMP_ADAPTER *pAd, PNET_DEV pDev)
{
	INT32 ret = -1;
	INT32 i;

	if (!pAd || !pDev)
		return -1;

	for (i = 0; i < pAd->MSTANum; i++) {
		if (pAd->StaCfg[i].wdev.if_dev == pDev) {
			ret = i;
			break;
		}
	}

	return ret;
}

extern struct wifi_dev_ops sta_wdev_ops;

VOID MSTA_Init(RTMP_ADAPTER *pAd, RTMP_OS_NETDEV_OP_HOOK *pNetDevOps)
{
	INT32 IdSta, MaxNumSta = pAd->MaxMSTANum;
	PNET_DEV pDevNew;
	RTMP_OS_NETDEV_OP_HOOK netDevHook;
	INT status;
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s (%d) --->\n", __func__, pAd->MaxMSTANum));
#endif /* RELEASE_EXCLUDE */

	/* create virtual network interface */
	for (IdSta = (MAIN_MSTA_ID + 1); IdSta < MaxNumSta; IdSta++) {
		struct wifi_dev *wdev;
		UINT32 MC_RowID = 0, IoctlIF = 0;
		char *dev_name;
		INT32 Ret;
#ifdef MULTIPLE_CARD_SUPPORT
		MC_RowID = pAd->MC_RowID;
#endif /* MULTIPLE_CARD_SUPPORT */
		PSTA_ADMIN_CONFIG pStaCfg = NULL;
		struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);

		dev_name = get_dev_name_prefix(pAd, INT_MSTA);
		pDevNew = RtmpOSNetDevCreate(MC_RowID, &IoctlIF, INT_MSTA, IdSta, sizeof(struct mt_dev_priv), dev_name);

		if (pDevNew == NULL)
			break;
		else {
			pAd->MSTANum = IdSta + 1; /* re-assign new actual number of total MSTA, including MAIN STA*/
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Register MSTA IF (%s)\n", RTMP_OS_NETDEV_GET_DEVNAME(pDevNew)));
		}

		pStaCfg = &pAd->StaCfg[IdSta];
		wdev = &pAd->StaCfg[IdSta].wdev;
		Ret = wdev_init(pAd, wdev, WDEV_TYPE_STA, pDevNew, IdSta,
						(VOID *)&pAd->StaCfg[IdSta], (void *)pAd);

		if (!Ret) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Assign wdev idx for %s failed, free net device!\n",
					 RTMP_OS_NETDEV_GET_DEVNAME(pDevNew)));
			RtmpOSNetDevFree(pDevNew);
			break;
		}

		Ret = wdev_ops_register(wdev, WDEV_TYPE_STA, &sta_wdev_ops,
								cap->wmm_detect_method);

		if (!Ret) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("register wdev_ops %s failed, free net device!\n", RTMP_OS_NETDEV_GET_DEVNAME(pDevNew)));
			RtmpOSNetDevFree(pDevNew);
			break;
		}

		RTMP_OS_NETDEV_SET_PRIV(pDevNew, pAd);
		RTMP_OS_NETDEV_SET_WDEV(pDevNew, wdev);
		/* init operation functions and flags */
		NdisCopyMemory(&netDevHook, pNetDevOps, sizeof(netDevHook));
		netDevHook.priv_flags = INT_MSTA;
		netDevHook.needProtcted = TRUE;
		netDevHook.wdev = wdev;
		/* Set the interface address of this extend MSTA, TODO Pat: temparary to decide 2nd MSTA address */
		COPY_MAC_ADDR(&pStaCfg->wdev.if_addr[0], pAd->CurrentAddress);
		pStaCfg->wdev.if_addr[0] |= 0x2;
		/* default choose bit[31:28], if there is no assigned mac from profile. */
		pStaCfg->wdev.if_addr[3] = pStaCfg->wdev.if_addr[3] & 0xef;
		pStaCfg->wdev.if_addr[3] = (pStaCfg->wdev.if_addr[3] | (IdSta << 4));
		NdisMoveMemory(&netDevHook.devAddr[0], pStaCfg->wdev.if_addr, MAC_ADDR_LEN);
		/* register this device to OS */
		status = RtmpOSNetDevAttach(pAd->OpMode, pDevNew, &netDevHook);
	}

#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s <---\n", __func__));
#endif /* RELEASE_EXCLUDE */
}

VOID MSTAStop(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	/* Clear PMKID cache.*/
	pStaCfg->SavedPMKNum = 0;
	RTMPZeroMemory(pStaCfg->SavedPMK, (PMKID_NO * sizeof(BSSID_INFO)));

	/* Link down first if any association exists*/
	if (!RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_NIC_NOT_EXIST)) {
		if (INFRA_ON(pStaCfg) || ADHOC_ON(pAd)) {
			MLME_DISASSOC_REQ_STRUCT DisReq;
			MLME_QUEUE_ELEM *pMsgElem;

			os_alloc_mem(pAd, (UCHAR **)&pMsgElem, sizeof(MLME_QUEUE_ELEM));

			if (pMsgElem) {
				COPY_MAC_ADDR(&DisReq.Addr, pStaCfg->Bssid);
				DisReq.Reason =  REASON_DISASSOC_STA_LEAVING;
				pMsgElem->Machine = ASSOC_STATE_MACHINE;
				pMsgElem->MsgType = MT2_MLME_DISASSOC_REQ;
				pMsgElem->MsgLen = sizeof(MLME_DISASSOC_REQ_STRUCT);
				IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
					pMsgElem->wdev = wdev;
				}
				os_move_mem(pMsgElem->Msg, &DisReq, sizeof(MLME_DISASSOC_REQ_STRUCT));
				MlmeDisassocReqAction(pAd, pMsgElem);
				os_free_mem(pMsgElem);
				RtmpusecDelay(1000);
			}
		}
	}

	/* Link down first if any association exists*/
	if (INFRA_ON(pStaCfg) || ADHOC_ON(pAd))
		LinkDown(pAd, FALSE, &pStaCfg->wdev);

	RtmpusecDelay(10000);
	/*==========================================*/
	/* Clean up old bss table*/
#ifndef ANDROID_SUPPORT
	/* because abdroid will get scan table when interface down, so we not clean scan table */
	BssTableInit(&pAd->ScanTab);
#endif /* ANDROID_SUPPORT */
}

VOID MSTA_Remove(RTMP_ADAPTER *pAd)
{
	UINT MaxNumSta = pAd->MaxMSTANum;
	struct wifi_dev *wdev = NULL;
	UINT IdSta = 0;
	PSTA_ADMIN_CONFIG pStaCfg = NULL;

	if (!pAd)
		return;

#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s --->\n", __func__));
#endif /* RELEASE_EXCLUDE */

	/* Basically, it is the same, but for gcc 4.9, only below is acceptable. */
	/* for(IdSta = (MAIN_MSTA_ID + 1); IdSta < pAd->MSTANum; IdSta++) */
	for (IdSta = (MAIN_MSTA_ID + 1); IdSta < MaxNumSta; IdSta++) {
		wdev = &pAd->StaCfg[IdSta].wdev;
		pStaCfg = &pAd->StaCfg[IdSta];

		if (pStaCfg)
			return;

		if (wdev->if_dev) {
			RtmpOSNetDevProtect(1);
			RtmpOSNetDevDetach(wdev->if_dev);
			RtmpOSNetDevProtect(0);
			wdev_deinit(pAd, wdev);
			RtmpOSNetDevFree(wdev->if_dev);
			wdev->if_dev = NULL;
		}
	}

#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s <---\n", __func__));
#endif /* RELEASE_EXCLUDE */
}

INT32 MSTA_Open(PNET_DEV pDev)
{
	PRTMP_ADAPTER pAd;
	INT StaId;
	/* struct wifi_dev *wdev = NULL; */
	PSTA_ADMIN_CONFIG pStaCfg = NULL;
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s --->\n", __func__));
#endif /* RELEASE_EXCLUDE */
	pAd = RTMP_OS_NETDEV_GET_PRIV(pDev);
	StaId = MSTA_IdxGet(pAd, pDev);

	if (StaId < 0)
		return -1;

	pStaCfg = &pAd->StaCfg[StaId];

	if (wdev_do_open(&pStaCfg->wdev) != TRUE)
		MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s() open fail!!!\n", __func__));

	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("MSTA interface up for ra_%x func_idx=%d OmacIdx=%d\n", StaId, pStaCfg->wdev.func_idx, pStaCfg->wdev.OmacIdx));
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s <---\n", __func__));
#endif /* RELEASE_EXCLUDE */
	return 0;
}

INT MSTA_Close(PNET_DEV pDev)
{
	PRTMP_ADAPTER pAd;
	INT StaId;
	struct wifi_dev *wdev = NULL;
#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s --->\n", __func__));
#endif /* RELEASE_EXCLUDE */
	pAd = RTMP_OS_NETDEV_GET_PRIV(pDev);
	StaId = MSTA_IdxGet(pAd, pDev);

	if (StaId < 0)
		return -1;

	RTMP_OS_NETDEV_STOP_QUEUE(pDev);
	/* Disconnet from AP of this interface */
	/* Pat: TODO: */
	wdev = &pAd->StaCfg[StaId].wdev;
	MSTAStop(pAd, wdev);

	if (wdev_do_close(wdev) != TRUE)
		MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s() close fail!!!\n", __func__));

#ifdef RELEASE_EXCLUDE
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s <---\n", __func__));
#endif /* RELEASE_EXCLUDE */
	return 0;
}


/*
 * wifi system layer api for ADHOC
 */
INT adhoc_link_up(struct wifi_dev *wdev, struct _MAC_TABLE_ENTRY *entry)
{
	struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *) wdev->sys_handle;

	UpdateBeaconHandler(
		ad,
		wdev,
		BCN_UPDATE_IF_STATE_CHG);

	if ((wdev->channel > 14)
		&& (ad->CommonCfg.bIEEE80211H == 1)
		&& RadarChannelCheck(ad, wdev->channel)) {
		;	/*Do nothing */
	} else {
		AsicEnableIbssSync(
			ad,
			ad->CommonCfg.BeaconPeriod,
			HW_BSSID_0,
			OPMODE_ADHOC);
	}

	if (wifi_sys_linkup(wdev, entry) != TRUE) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s(): linkup fail!\n", __func__));
	}

	return TRUE;
}

UINT32 bssinfo_sta_feature_decision(struct wifi_dev *wdev, UCHAR wcid, UINT32 *feature)
{
	UINT32 features = 0;

	features |= BSS_INFO_PM_FEATURE;
#ifdef UAPSD_SUPPORT
	features |= BSS_INFO_UAPSD_FEATURE;
#endif /* UAPSD_SUPPORT */
	*feature |= features;
	return TRUE;
}

VOID sta_deauth_act(struct wifi_dev *wdev)
{
	RTEnqueueInternalCmd(wdev->sys_handle, CMDTHRED_STA_DEAUTH_ACT, (VOID *) wdev, sizeof(struct wifi_dev));
}
