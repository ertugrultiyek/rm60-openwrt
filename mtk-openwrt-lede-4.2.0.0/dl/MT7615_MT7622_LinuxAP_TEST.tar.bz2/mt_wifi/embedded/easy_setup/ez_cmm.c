/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology	5th	Rd.
 * Science-based Industrial	Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2004, Ralink Technology, Inc.
 *
 * All rights reserved.	Ralink's source	code is	an unpublished work	and	the
 * use of a	copyright notice does not imply	otherwise. This	source code
 * contains	confidential trade secret material of Ralink Tech. Any attemp
 * or participation	in deciphering,	decoding, reverse engineering or in	any
 * way altering	the	source code	is stricitly prohibited, unless	the	prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	cmm_ez.c

	Abstract:
	Easy Setup APIs

	Revision History:
	Who			When			What
	--------	----------		----------------------------------------------
*/
#ifdef WH_EZ_SETUP
#include "rt_config.h"
#ifdef DUAL_CHIP
void *pAd_5 = NULL;
void *pAd_2 = NULL;
unsigned int first_init = 0;
NDIS_SPIN_LOCK ez_conn_perm_lock;
NDIS_SPIN_LOCK ez_handle_disconnect_lock;
NDIS_SPIN_LOCK ez_mlme_sync_lock;
#endif
#ifdef DBG
unsigned long ez_memory_alloc_num;
unsigned long ez_memory_free_num;
#endif /* DBG */

#define EZ_DEFAULT_RSSI_THRESHOLD (-70)

static unsigned char __DH_G_VALUE[1] = {0x02};
static unsigned char __DH_P_VALUE[192] =
{
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xC9, 0x0F, 0xDA, 0xA2, 0x21, 0x68, 0xC2, 0x34,
    0xC4, 0xC6, 0x62, 0x8B, 0x80, 0xDC, 0x1C, 0xD1,
    0x29, 0x02, 0x4E, 0x08, 0x8A, 0x67, 0xCC, 0x74,
    0x02, 0x0B, 0xBE, 0xA6, 0x3B, 0x13, 0x9B, 0x22,
    0x51, 0x4A, 0x08, 0x79, 0x8E, 0x34, 0x04, 0xDD,
    0xEF, 0x95, 0x19, 0xB3, 0xCD, 0x3A, 0x43, 0x1B,
    0x30, 0x2B, 0x0A, 0x6D, 0xF2, 0x5F, 0x14, 0x37,
    0x4F, 0xE1, 0x35, 0x6D, 0x6D, 0x51, 0xC2, 0x45,
    0xE4, 0x85, 0xB5, 0x76, 0x62, 0x5E, 0x7E, 0xC6,
    0xF4, 0x4C, 0x42, 0xE9, 0xA6, 0x37, 0xED, 0x6B,
    0x0B, 0xFF, 0x5C, 0xB6, 0xF4, 0x06, 0xB7, 0xED,
    0xEE, 0x38, 0x6B, 0xFB, 0x5A, 0x89, 0x9F, 0xA5,
    0xAE, 0x9F, 0x24, 0x11, 0x7C, 0x4B, 0x1F, 0xE6,
    0x49, 0x28, 0x66, 0x51, 0xEC, 0xE4, 0x5B, 0x3D,
    0xC2, 0x00, 0x7C, 0xB8, 0xA1, 0x63, 0xBF, 0x05,
    0x98, 0xDA, 0x48, 0x36, 0x1C, 0x55, 0xD3, 0x9A,
    0x69, 0x16, 0x3F, 0xA8, 0xFD, 0x24, 0xCF, 0x5F,
    0x83, 0x65, 0x5D, 0x23, 0xDC, 0xA3, 0xAD, 0x96,
    0x1C, 0x62, 0xF3, 0x56, 0x20, 0x85, 0x52, 0xBB,
    0x9E, 0xD5, 0x29, 0x07, 0x70, 0x96, 0x96, 0x6D,
    0x67, 0x0C, 0x35, 0x4E, 0x4A, 0xBC, 0x98, 0x04,
    0xF1, 0x74, 0x6C, 0x08, 0xCA, 0x23, 0x73, 0x27,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
};
unsigned char mtk_oui[MTK_OUI_LEN] = {0x00, 0x0C, 0xE7};
unsigned char ralink_oui[RALINK_OUI_LEN] = {0x00, 0x0C, 0x43};
int EzDebugLevel = DBG_LVL_ERROR;

#define EZ_TIMER_INIT(__ad, __data, __time_var, __time_flg, __time_fn) \
	do{ \
	        RTMPInitTimer((__ad), (__time_var), GET_TIMER_FUNCTION(__time_fn), (__data), FALSE); \
	    	(__time_flg) = FALSE; \
	}while(0)

#define EZ_CANCEL_TIMER(__time_var, __time_flg) \
	do{ \
			unsigned char __cancelled; \
	        RTMPCancelTimer(__time_var, &__cancelled); \
	    	(__time_flg) = FALSE; \
	}while(0)

#define EZ_RELEASE_TIMER(__time_var, __time_flg) \
	do{ \
			unsigned char __cancelled; \
	        RTMPReleaseTimer(__time_var, &__cancelled); \
	    	(__time_flg) = FALSE; \
	}while(0)
#ifdef EZ_NETWORK_MERGE_SUPPORT	
void EzStartGroupMergeTimer(struct _ez_security *ez_sec_info);

enum_group_merge_action_t is_group_merge_candidate(void *bss_entry,void *temp_bss_entry ,struct _ez_security *ez_security);
enum_config_update_action_t push_and_update_config(void *ad_obj , struct wifi_dev *wdev,
	struct _ez_peer_security_info *ez_peer, 
	BOOLEAN check_for_weight, 
	BOOLEAN from_port_secured,
	BOOLEAN surely_a_group_merge
	);
BOOLEAN send_action_update_config(void *ad_obj, 
					struct _ez_peer_security_info *ez_peer,
					struct wifi_dev *wdev, 
					updated_configs_t *updated_configs,
					BOOL same_band,
					BOOL group_id_update);
void ez_send_unicast_deauth(void *ad_obj, UCHAR *peer_addr);
void ez_send_broadcast_deauth(void *ad_obj, struct wifi_dev *wdev);
#endif

static BOOLEAN ez_is_ap_apcli(struct wifi_dev *wdev)
{
	if(wdev->wdev_type == WDEV_TYPE_AP || wdev->wdev_type == WDEV_TYPE_APCLI)
		return TRUE;
	else
		return FALSE;
}

#ifdef NEW_CONNECTION_ALGO
void ez_allocate_node_number(void *ad_obj,	EZ_NODE_NUMBER *node_number,UCHAR if_index);
void ez_apcli_allocate_self_node_number(EZ_NODE_NUMBER *node_number, void * entry_obj);
void ez_apcli_adopt_new_node_number(void *ad_obj, EZ_NODE_NUMBER *new_node_number, unsigned char if_index);
BOOLEAN ez_apcli_search_best_ap_configured(void *ad_obj,	void *out_table_obj,void *apcli_entry_obj);
void ez_ap_send_new_node_number(void *ad_obj,	struct wifi_dev *wdev,	struct _ez_peer_security_info *ez_peer);
BOOLEAN ez_update_new_node_number_sta(	void *ad_obj, unsigned char if_index, void * entry_obj);

#ifdef EZ_DUAL_BAND_SUPPORT
void ez_init_updated_configs(updated_configs_t *updated_config, struct _ez_peer_security_info *ez_peer, struct wifi_dev* wdev);
BOOLEAN ez_send_action_update_config_for_this_band(void *ad_obj, void *wdev_obj, updated_configs_t *updated_configs, BOOLEAN group_id_diff, BOOLEAN band_switched, BOOLEAN deauth_non_ez_sta);
struct _ez_peer_security_info *ez_get_other_band_ez_peer(void * wdev_obj, struct _ez_peer_security_info *ez_peer);
void ez_inform_other_band(void * ad_obj, void * wdev_obj, inform_other_band_action_t action);
BOOLEAN ez_update_other_band_ap(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOLEAN group_id_diff);
BOOLEAN ez_update_this_band_ap(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOLEAN group_id_diff);
BOOLEAN ez_update_ap(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOLEAN group_id_diff, BOOLEAN band_switched);
BOOLEAN ez_update_other_band_cli(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOLEAN group_id_diff);
BOOLEAN ez_update_this_band_cli(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOLEAN group_id_diff);
BOOLEAN ez_update_cli(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOLEAN group_id_diff, BOOLEAN band_switched);
void ez_update_other_band_ap_peer_record(void * ad_obj, void * wdev_obj);
void ez_update_this_band_ap_peer_record(void * ad_obj, void * wdev_obj);
void ez_update_ap_peer_record(void * ad_obj, void * wdev_obj, BOOLEAN band_switched);
void ez_update_other_band_cli_peer_record(void * ad_obj, void * wdev_obj);
void ez_update_this_band_cli_peer_record(void * ad_obj, void * wdev_obj);
void ez_update_cli_peer_record(void * ad_obj, void * wdev_obj, BOOLEAN band_switched);
BOOLEAN ez_get_other_band_info(void * ad_obj, void * wdev_obj, void *other_band_config);
void ez_init_updated_configs_for_push(updated_configs_t *updated_config, struct wifi_dev* wdev);
void ez_inform_all_interfaces(void * ad_obj, void * wdev_obj, inform_other_band_action_t action);
void ez_hex_dump(char *str, UCHAR *pSrcBufVA, UINT SrcBufLen);
BOOLEAN ez_get_band( void * wdev_obj);

ULONG BssTableSearchWithBssId(
    IN BSS_TABLE *Tab,
    IN PUCHAR     Bssid,
    IN UCHAR      Channel);
void ez_set_other_band_cli_loop_chk_info(void * ad_obj, void * wdev_obj, BOOLEAN test_start);
void ez_cancel_loop_chk(struct wifi_dev* wdev);
void ez_initiate_new_scan(void *ad_obj);
void ez_notify_roam(PRTMP_ADAPTER pAd, struct _ez_peer_security_info *ez_peer);
void send_action_notify_roam(void *ad_obj, 
					struct wifi_dev *wdev, 
					struct _ez_peer_security_info *ez_peer
					);


#endif

#ifdef OLD_PRJ
static void ez_install_pairwise_key(
	void *ad_obj,
	void *entry_obj,
	unsigned char *pmk,
	unsigned char *ptk,
	unsigned char authenticator)
{
	RTMP_ADAPTER *pAd;
	MAC_TABLE_ENTRY *entry;

	pAd = (RTMP_ADAPTER *)ad_obj;
	entry = (MAC_TABLE_ENTRY *)entry_obj;
	entry->WepStatus = Ndis802_11AESEnable;
	NdisCopyMemory(&entry->PTK[0], ptk, LEN_PTK);
#ifdef APCLI_SUPPORT	
	if (IS_ENTRY_APCLI(entry))	
	 	APCliInstallPairwiseKey(pAd, entry);
	else
#endif /* APCLI_SUPPORT */
	WPAInstallPairwiseKey(pAd, entry->apidx, entry, authenticator);
}

#ifdef APCLI_SUPPORT
static void ez_apcli_install_group_key(
	RTMP_ADAPTER *ad,
	struct _ez_peer_security_info *ez_peer,
	MAC_TABLE_ENTRY *entry)
{
	/* Set Group key material, TxMic and RxMic for AP-Client*/
	APCliInstallSharedKey(
		ad, 
		ez_peer->gtk, 
		ez_peer->gtk_len, 
		1, 
		entry);
}
#endif /* APCLI_SUPPORT */

#else /* OLD_PRJ */
static void ez_install_pairwise_key(
	void *ad_obj,
	void *entry_obj,
	unsigned char *pmk,
	unsigned char *ptk,
	unsigned char authenticator)
{
	RTMP_ADAPTER *pAd;
	MAC_TABLE_ENTRY *entry;
	ASIC_SEC_INFO Info;
	STA_TR_ENTRY *tr_entry;
	struct wifi_dev *wdev;
	
	pAd = (RTMP_ADAPTER *)ad_obj;
	entry = (MAC_TABLE_ENTRY *)entry_obj;
	wdev = entry->wdev;
	tr_entry = &pAd->MacTab.tr_entry[entry->tr_tb_idx];

	SET_AKM_WPA2PSK(entry->SecConfig.AKMMap);
	SET_CIPHER_CCMP128(entry->SecConfig.PairwiseCipher);
	SET_CIPHER_CCMP128(entry->SecConfig.GroupCipher);
	entry->SecConfig.PairwiseKeyId = 1;
	os_zero_mem(&entry->SecConfig.PMK[0], LEN_PMK);
	NdisCopyMemory(&entry->SecConfig.PMK[0], pmk, LEN_PMK);
	os_zero_mem(&entry->SecConfig.PTK[0], LEN_PTK);
	NdisCopyMemory(&entry->SecConfig.PTK[0], ptk, LEN_PTK);
	/* Set key material to Asic */
	NdisZeroMemory(&Info, sizeof(ASIC_SEC_INFO));
	Info.Operation = SEC_ASIC_ADD_PAIRWISE_KEY;
	Info.Direction = SEC_ASIC_KEY_BOTH;
	Info.Wcid = entry->wcid;
	Info.BssIndex = entry->func_tb_idx;
	Info.Cipher = entry->SecConfig.PairwiseCipher;
	Info.KeyIdx = entry->SecConfig.PairwiseKeyId;
	NdisCopyMemory(&Info.PeerAddr[0], entry->Addr, MAC_ADDR_LEN);
	NdisCopyMemory(Info.Key.Key,&entry->SecConfig.PTK[LEN_PTK_KCK + LEN_PTK_KEK], (LEN_TK + LEN_TK2));
	WPAInstallKey(pAd, &Info, authenticator, TRUE);
	
	/* Update status and set Port as Secured */
	entry->SecConfig.Handshake.WpaState = AS_PTKINITDONE;
	entry->SecConfig.Handshake.GTKState = REKEY_ESTABLISHED;
	entry->PrivacyFilter = Ndis802_11PrivFilterAcceptAll;
	tr_entry->PortSecured = WPA_802_1X_PORT_SECURED;

	WifiSysUpdatePortSecur(pAd, entry, &Info);
}

#ifdef APCLI_SUPPORT
static void ez_apcli_install_group_key(
	RTMP_ADAPTER *ad,
	struct _ez_peer_security_info *ez_peer,
	MAC_TABLE_ENTRY *entry)
{
	ASIC_SEC_INFO Info = {0};

	/* set key material, TxMic and RxMic		*/
	NdisMoveMemory(entry->SecConfig.GTK, ez_peer->gtk, ez_peer->gtk_len);
	entry->SecConfig.GroupKeyId = 1;

	/* Set key material to Asic */
	os_zero_mem(&Info, sizeof(ASIC_SEC_INFO));
	Info.Operation = SEC_ASIC_ADD_GROUP_KEY;
	Info.Direction = SEC_ASIC_KEY_RX;
	Info.Wcid = entry->wdev->bss_info_argument.ucBcMcWlanIdx;
	Info.BssIndex = BSS0;  // TODO: OMAC index?
	Info.Cipher = entry->SecConfig.GroupCipher;
	Info.KeyIdx = entry->SecConfig.GroupKeyId;
	os_move_mem(&Info.PeerAddr[0], entry->Addr, MAC_ADDR_LEN);
	os_move_mem(Info.Key.Key, entry->SecConfig.GTK, LEN_MAX_GTK);

	WPAInstallKey(ad, &Info, FALSE, TRUE);
}
#endif /* APCLI_SUPPORT */

#endif /* !OLD_PRJ */

static unsigned char ez_gen_dh_public_key(
	void *ez_sec_obj)
{
	struct _ez_security *ez_sec_info;
	unsigned char tmp_key[EZ_RAW_KEY_LEN];
	int idx;
	unsigned int dh_len;
	unsigned int DiffCnt;

	ez_sec_info = (struct _ez_security *)ez_sec_obj;
	dh_len = EZ_RAW_KEY_LEN;
	
	/* Enrollee 192 random bytes for DH key generation */
	for (idx = 0; idx < EZ_RAW_KEY_LEN; idx++)
		ez_sec_info->self_dh_random_seed[idx] = RandomByte(ez_sec_info->ad);
	
	NdisZeroMemory(&ez_sec_info->self_pke[0], EZ_RAW_KEY_LEN);
	RT_DH_PublicKey_Generate (
		__DH_G_VALUE, sizeof(__DH_G_VALUE),
		__DH_P_VALUE, sizeof(__DH_P_VALUE),
		&ez_sec_info->self_dh_random_seed[0], EZ_RAW_KEY_LEN,
		&ez_sec_info->self_pke[0], (UINT *) &dh_len);

	/* Need to prefix zero padding */
	if (dh_len < EZ_RAW_KEY_LEN)
	{
		DiffCnt = EZ_RAW_KEY_LEN - dh_len;

		NdisZeroMemory(&tmp_key[0], EZ_RAW_KEY_LEN);
		NdisCopyMemory(&tmp_key[DiffCnt], &ez_sec_info->self_pke[0], dh_len);
		NdisCopyMemory(&ez_sec_info->self_pke[0], &tmp_key[0], EZ_RAW_KEY_LEN);
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s: Do zero padding!\n", __FUNCTION__));
	}
	else if (dh_len > EZ_RAW_KEY_LEN) {
		
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s: dh_len(=%d) exceeds EZ_RAW_KEY_LEN(=%d)!\n", 
			__FUNCTION__,
			dh_len,
			EZ_RAW_KEY_LEN));

		return FALSE;
	}

	return TRUE;
}

static unsigned char ez_gen_dh_private_key(
	void *ez_sec_obj,
	struct _ez_peer_security_info *ez_peer_info)
{
	struct _ez_security *ez_sec_info;
	unsigned char tmp_key[EZ_RAW_KEY_LEN];
	unsigned int dh_len;
	unsigned int DiffCnt;

	ez_sec_info = (struct _ez_security *)ez_sec_obj;
	dh_len = EZ_RAW_KEY_LEN;
	
	RTMPZeroMemory(&ez_sec_info->self_pkr[0], EZ_RAW_KEY_LEN);
	RT_DH_SecretKey_Generate (
		&ez_peer_info->peer_pke[0], EZ_RAW_KEY_LEN,
		__DH_P_VALUE, sizeof(__DH_P_VALUE),
		&ez_sec_info->self_dh_random_seed[0],  sizeof(ez_sec_info->self_dh_random_seed),
		&ez_sec_info->self_pkr[0], (UINT *) &dh_len);
	
	/* Need to prefix zero padding */
	if (dh_len < EZ_RAW_KEY_LEN)
	{
		DiffCnt = EZ_RAW_KEY_LEN - dh_len;

		NdisZeroMemory(&tmp_key[0], EZ_RAW_KEY_LEN);
		NdisCopyMemory(&tmp_key[DiffCnt], &ez_sec_info->self_pkr[0], dh_len);
		NdisCopyMemory(&ez_sec_info->self_pkr[0], &tmp_key[0], EZ_RAW_KEY_LEN);
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s: Do zero padding!\n", __FUNCTION__));
	}
	else if (dh_len > EZ_RAW_KEY_LEN) {
		
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s: dh_len(=%d) exceeds EZ_RAW_KEY_LEN(=%d)!\n", 
			__FUNCTION__,
			dh_len,
			EZ_RAW_KEY_LEN));

		return FALSE;
	}
	return TRUE;
}

static void ez_compute_dh_key(
	void *ez_sec_obj,
	struct _ez_peer_security_info *ez_peer)
{
	struct _ez_security *ez_sec_info;

	ez_sec_info = (struct _ez_security *)ez_sec_obj;

	os_zero_mem(&ez_peer->dh_key[0], EZ_DH_KEY_LEN);
	/* Compute the DHKey based on the DH secret */
	RT_SHA256(&ez_sec_info->self_pkr[0], EZ_RAW_KEY_LEN, &ez_peer->dh_key[0]);
	hex_dump("DH Key", &ez_peer->dh_key[0], EZ_DH_KEY_LEN);
}

static void ez_get_sw_encrypted_key(
	void *ez_sec_obj,
	struct _ez_peer_security_info *ez_peer,
	unsigned char *a_addr,
	unsigned char *s_addr)
{
	struct _ez_security *ez_sec_info;
	RTMP_ADAPTER *pAd;
	unsigned char addr1[MAC_ADDR_LEN];
	unsigned char addr2[MAC_ADDR_LEN];

	ez_sec_info = (struct _ez_security *)ez_sec_obj;
	pAd = (RTMP_ADAPTER *)ez_sec_info->ad;
	os_zero_mem(&ez_peer->sw_key[0], EZ_PTK_LEN);
	NdisCopyMemory(&addr1[0], &mtk_oui[0], MTK_OUI_LEN);
	NdisCopyMemory(&addr1[MTK_OUI_LEN], &a_addr[MTK_OUI_LEN], MTK_OUI_LEN);
	NdisCopyMemory(&addr2[0], &ralink_oui[0], RALINK_OUI_LEN);
	NdisCopyMemory(&addr2[RALINK_OUI_LEN], &s_addr[RALINK_OUI_LEN], RALINK_OUI_LEN);
	EZ_DERIVE_PTK(pAd, 
			&ez_peer->dh_key[0], 
			&ez_peer->dh_key[0], 
			&addr1[0], 
			&ez_peer->dh_key[16], 
			&addr2[0], 
			&ez_peer->sw_key[0], 
			LEN_PTK);
	hex_dump("dh_key", &ez_peer->dh_key[0], EZ_DH_KEY_LEN);
	hex_dump("addr1", &addr1[0], 6);
	hex_dump("addr2", &addr2[0], 6);
	hex_dump("sw_key", &ez_peer->sw_key[0], LEN_PTK);
}

static void ez_calculate_mic(
	unsigned char *sw_key,
	unsigned char *msg,
	unsigned int msg_len,
	unsigned char *mic)
{
	unsigned char	digest[80];

	os_zero_mem(mic, sizeof(mic));
	os_zero_mem(digest, sizeof(digest));

	RT_HMAC_SHA1(sw_key, LEN_PTK_KCK, msg,  msg_len, digest, SHA1_DIGEST_SIZE);
	NdisCopyMemory(mic, digest, EZ_MIC_LEN);
}

static unsigned short ez_probe_request_sanity(
	struct wifi_dev *wdev,
	void *msg,
	unsigned long msg_len,
	struct _ez_peer_security_info *ez_peer)
{	
	unsigned char tag_count;
	FRAME_802_11 *Fr;
	unsigned char *Ptr;
	EID_STRUCT *pEid;
	unsigned long Length;
	unsigned char tag;
	unsigned char data_len;
	unsigned char capability0;

	tag_count = 0;
	Length = 0;
	Fr = (PFRAME_802_11)msg;
	
	Ptr = Fr->Octet;
	Length += LENGTH_802_11;
		
	pEid = (PEID_STRUCT) Ptr;

	/* get variable fields from payload and advance the pointer*/
	while ((Length + 2 + pEid->Len) <= msg_len)    
	{
		switch(pEid->Eid)
		{
			case IE_VENDOR_SPECIFIC:				
				if (NdisEqualMemory(&pEid->Octet[0], &mtk_oui[0], MTK_OUI_LEN)) {
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
						("%s() - Found MTK Proprietary OUI.\n", __FUNCTION__));
					capability0 = pEid->Octet[MTK_OUI_LEN];
					if (capability0 & MTK_VENDOR_EASY_SETUP) {
						tag = pEid->Octet[EZ_TAG_OFFSET];
						data_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
							("%s() - tag = %d, data_len = %d\n", 
							__FUNCTION__, tag, data_len));
						if (tag == EZ_TAG_SDH_PUBLIC_KEY) {
							if (data_len == EZ_RAW_KEY_LEN) {
								NdisCopyMemory(&ez_peer->peer_pke[0], 
									&pEid->Octet[EZ_TAG_DATA_OFFSET], 
									data_len);
								tag_count++;
							} else {
								return EZ_STATUS_CODE_INVALID_DATA;
							}
						}
#ifdef EZ_NETWORK_MERGE_SUPPORT
						else if (tag == EZ_TAG_CAPABILITY_INFO) {
						//! aditional capability tag is added in probe request so that AP is aware of CLIs group merge capability
							if (data_len == EZ_CAPABILITY_LEN) {
								NdisCopyMemory(&ez_peer->capability, 
									&pEid->Octet[EZ_TAG_DATA_OFFSET], 
									EZ_CAPABILITY_LEN);
								
								ez_peer->capability = be2cpu32(ez_peer->capability);
								tag_count++;
							}
#endif
							else
								return EZ_STATUS_CODE_INVALID_DATA;
						}							
					}
				}
				break;
			default:
				break;
		}

		Length = Length + 2 + pEid->Len;  /* Eid[1] + Len[1]+ content[Len]*/
		pEid = (PEID_STRUCT)((unsigned char *)pEid + 2 + pEid->Len);
	}

	if (tag_count == EZ_PROB_REQ_TAG_COUNT) {
		return EZ_STATUS_CODE_SUCCESS;
	}
	else
		return EZ_STATUS_CODE_INVALID_DATA;
}

static unsigned short ez_probe_beacon_response_sanity(
	void *msg,
	unsigned long msg_len,
	struct _ez_peer_security_info *ez_peer)
{	
	unsigned char tag_count;
	unsigned char target_tag_count;
	FRAME_802_11 *Fr;
	unsigned char *Ptr;
	EID_STRUCT *pEid;
	unsigned long Length;
	unsigned char tag;
	unsigned char data_len;
	unsigned char capability0;

	tag_count = 0;
	Length = 0;
	Fr = (PFRAME_802_11)msg;

	if (Fr->Hdr.FC.SubType == SUBTYPE_PROBE_RSP) {
		target_tag_count = EZ_PROB_RSP_TAG_COUNT;
	}
	else
		target_tag_count = EZ_BEACON_TAG_COUNT;
	
	Ptr = Fr->Octet;
	Length += LENGTH_802_11;
	
	Ptr += (TIMESTAMP_LEN + 4);
	Length += (TIMESTAMP_LEN + 4);
	
	pEid = (PEID_STRUCT) Ptr;

	/* get variable fields from payload and advance the pointer*/
	while ((Length + 2 + pEid->Len) <= msg_len)    
	{
		switch(pEid->Eid)
		{
			case IE_VENDOR_SPECIFIC:
				if (NdisEqualMemory(&pEid->Octet[0], &mtk_oui[0], MTK_OUI_LEN)) {
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
						("%s() - Found MTK Proprietary OUI.\n", __FUNCTION__));
					capability0 = pEid->Octet[MTK_OUI_LEN];
					if (capability0 & MTK_VENDOR_EASY_SETUP) {
						tag = pEid->Octet[EZ_TAG_OFFSET];
						data_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
							("%s() - tag = %d, data_len = %d\n", 
							__FUNCTION__, tag, data_len));
						if (tag == EZ_TAG_ADH_PUBLIC_KEY) {
							if (data_len == EZ_RAW_KEY_LEN) {
								NdisCopyMemory(&ez_peer->peer_pke[0], 
									&pEid->Octet[EZ_TAG_DATA_OFFSET], 
									data_len);
								tag_count++;
							}
							else
								return EZ_STATUS_CODE_INVALID_DATA;
						}							
						if (tag == EZ_TAG_CAPABILITY_INFO) {
							if (data_len == EZ_CAPABILITY_LEN) {
								NdisCopyMemory(&ez_peer->capability, 
									&pEid->Octet[EZ_TAG_DATA_OFFSET], 
									EZ_CAPABILITY_LEN);
								ez_peer->capability = be2cpu32(ez_peer->capability);
								tag_count++;
							}
							else
								return EZ_STATUS_CODE_INVALID_DATA;
						}
					}
				}
				break;
			default:
				break;
		}

		Length = Length + 2 + pEid->Len;  /* Eid[1] + Len[1]+ content[Len]*/
		pEid = (PEID_STRUCT)((unsigned char *)pEid + 2 + pEid->Len);
	}

	if (tag_count == target_tag_count) {
		return EZ_STATUS_CODE_SUCCESS;
	}
	else
		return EZ_STATUS_CODE_INVALID_DATA;
}

static unsigned short ez_auth_request_sanity(
	void *msg,
	unsigned long msg_len,
	struct _ez_peer_security_info *ez_peer)
{	
	unsigned char tag_count;
	FRAME_802_11 *Fr;
	unsigned char *Ptr;
	EID_STRUCT *pEid;
	unsigned long Length;
	unsigned char tag;
	unsigned char data_len;
	unsigned char capability0;
	unsigned char *data_buf;
	unsigned int data_buf_len;
	unsigned char mic[EZ_MIC_LEN];

	data_buf_len = EZ_AUTH_REQ_TAG_COUNT*255;
	EZ_MEM_ALLOC(NULL, &data_buf, data_buf_len);

	if (data_buf == NULL) {
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
						("%s() - malloc fail.\n", __FUNCTION__));
		return EZ_STATUS_CODE_NO_RESOURCE;
	}
	
	os_zero_mem(data_buf, data_buf_len);
	os_zero_mem(&mic[0], EZ_MIC_LEN);
	data_buf_len = 0;
	
	tag_count = 0;
	Length = 0;
	Fr = (PFRAME_802_11)msg;		
	Ptr = Fr->Octet;
	Length += LENGTH_802_11;
	
	Ptr += 6;
	Length += 6;
	
	pEid = (PEID_STRUCT) Ptr;

	/* get variable fields from payload and advance the pointer*/
	while ((Length + 2 + pEid->Len) <= msg_len)    
	{
		switch(pEid->Eid)
		{
			case IE_VENDOR_SPECIFIC:
				if (NdisEqualMemory(&pEid->Octet[0], &mtk_oui[0], MTK_OUI_LEN)) {
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
						("%s() - Found MTK Proprietary OUI.\n", __FUNCTION__));
					capability0 = pEid->Octet[MTK_OUI_LEN];
					if (capability0 & MTK_VENDOR_EASY_SETUP) {
						tag = pEid->Octet[EZ_TAG_OFFSET];
						data_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
							("%s() - tag = %d, data_len = %d\n", 
							__FUNCTION__, tag, data_len));
						if (tag == EZ_TAG_SNONCE) {
							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							if (data_len == EZ_NONCE_LEN){
								NdisCopyMemory(&ez_peer->peer_nonce[0], 
									&pEid->Octet[EZ_TAG_DATA_OFFSET], 
									data_len);
								tag_count++;
							}
							else {
								if (data_buf)
									EZ_MEM_FREE(NULL, data_buf);
								return EZ_STATUS_CODE_INVALID_DATA;
							}
						}
						if (tag == EZ_TAG_GROUP_ID) {
							unsigned char *encrypted_data;
							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							if (ez_peer->group_id_len != 0) {
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
									("%s() - free previous group id\n", __FUNCTION__));
								ez_peer->group_id_len = 0;
								EZ_MEM_FREE(NULL, ez_peer->group_id);
							}
							EZ_MEM_ALLOC(NULL, &ez_peer->group_id, data_len);
							if (ez_peer->group_id) {
								os_zero_mem(ez_peer->group_id, data_len);
								encrypted_data = &pEid->Octet[EZ_TAG_DATA_OFFSET];			
								/* AES */
								AES_Key_Unwrap(encrypted_data, data_len,
											   &ez_peer->sw_key[0], LEN_PTK_KEK, 
											   ez_peer->group_id, &ez_peer->group_id_len);
								tag_count++;
							}
							else {
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
									("%s() - malloc failed\n", __FUNCTION__));
								if (data_buf)
									EZ_MEM_FREE(NULL, data_buf);
								return EZ_STATUS_CODE_NO_RESOURCE;
							}
						}
#ifdef NEW_CONNECTION_ALGO						
						if (tag == EZ_TAG_OPEN_GROUP_ID) {
							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							ez_peer->open_group_id_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
							NdisCopyMemory(ez_peer->open_group_id, &pEid->Octet[EZ_TAG_DATA_OFFSET], pEid->Octet[EZ_TAG_LEN_OFFSET]);
							tag_count++;
						}
#endif						
						if (tag == EZ_TAG_MIC) {
							ez_calculate_mic(ez_peer->sw_key, data_buf, data_buf_len, &mic[0]);
							if (NdisEqualMemory(&mic[0], &pEid->Octet[EZ_TAG_DATA_OFFSET], EZ_MIC_LEN)) {
								tag_count++;
							}
							else {
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
									("%s() - MIC different......\n", __FUNCTION__));
							}
						}
					}
				}
				break;
			default:
				break;
		}

		Length = Length + 2 + pEid->Len;  /* Eid[1] + Len[1]+ content[Len]*/
		pEid = (PEID_STRUCT)((unsigned char *)pEid + 2 + pEid->Len);
	}

	if (data_buf)
		EZ_MEM_FREE(NULL, data_buf);
	if (tag_count == EZ_AUTH_REQ_TAG_COUNT) {
		return EZ_STATUS_CODE_SUCCESS;
	}
	else
		return EZ_STATUS_CODE_INVALID_DATA;
}

static unsigned short ez_auth_response_sanity(
	void *msg,
	unsigned long msg_len,
	struct _ez_peer_security_info *ez_peer)
{	
	unsigned char tag_count;
	FRAME_802_11 *Fr;
	unsigned char *Ptr;
	EID_STRUCT *pEid;
	unsigned long Length;
	unsigned char tag;
	unsigned char data_len;
	unsigned char capability0;
	unsigned char *data_buf;
	unsigned int data_buf_len;
	unsigned char mic[EZ_MIC_LEN];

	data_buf_len = EZ_AUTH_RSP_TAG_COUNT*255;
	EZ_MEM_ALLOC(NULL, &data_buf, data_buf_len);

	if (data_buf == NULL) {
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
						("%s() - malloc fail.\n", __FUNCTION__));
		return EZ_STATUS_CODE_NO_RESOURCE;
	}

	os_zero_mem(data_buf, data_buf_len);
	os_zero_mem(&mic[0], EZ_MIC_LEN);
	data_buf_len = 0;

	Length = 0;
	Fr = (PFRAME_802_11)msg;
	Ptr = Fr->Octet;
	Length += LENGTH_802_11;
	
	Ptr += 6;
	Length += 6;
	
	pEid = (PEID_STRUCT) Ptr;

	tag_count = 0;
	/* get variable fields from payload and advance the pointer*/
	while ((Length + 2 + pEid->Len) <= msg_len)
	{
		switch(pEid->Eid)
		{
			case IE_VENDOR_SPECIFIC:
				if (NdisEqualMemory(&pEid->Octet[0], &mtk_oui[0], MTK_OUI_LEN)) {
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
					("%s() - Found MTK Proprietary OUI.\n", __FUNCTION__));
					capability0 = pEid->Octet[MTK_OUI_LEN];
					if (capability0 & MTK_VENDOR_EASY_SETUP) {
						tag = pEid->Octet[EZ_TAG_OFFSET];
						data_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
							("%s() - tag = %d, data_len = %d\n", 
							__FUNCTION__, tag, data_len));
						if (tag == EZ_TAG_PMK) {
							unsigned char *encrypted_data;
							unsigned char *pmk;
							unsigned int pmk_len;
							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							encrypted_data = &pEid->Octet[EZ_TAG_DATA_OFFSET];
							EZ_MEM_ALLOC(NULL, &pmk, data_len+EZ_AES_KEY_ENCRYPTION_EXTEND);
							if (pmk) {
								/* AES */
								AES_Key_Unwrap(encrypted_data, data_len,
											   &ez_peer->sw_key[0], LEN_PTK_KEK, 
											   pmk, &pmk_len);
								os_zero_mem(&ez_peer->this_band_info.pmk[0], EZ_PMK_LEN);
								NdisCopyMemory(&ez_peer->this_band_info.pmk[0], pmk, EZ_PMK_LEN);
								tag_count++;
								EZ_MEM_FREE(NULL, pmk);
							}
						}
						if (tag == EZ_TAG_ANONCE) {
							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							if (data_len == EZ_NONCE_LEN) {
								NdisCopyMemory(&ez_peer->peer_nonce[0], 
									&pEid->Octet[EZ_TAG_DATA_OFFSET], 
									data_len);
								tag_count++;
							}
							else {
								if (data_buf)
									EZ_MEM_FREE(NULL, data_buf);
								return EZ_STATUS_CODE_INVALID_DATA;
							}
						}
						if (tag == EZ_TAG_GROUP_ID) {
							unsigned char *encrypted_data;
							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							EZ_MEM_ALLOC(NULL, &ez_peer->group_id, data_len);
							if (ez_peer->group_id) {
								os_zero_mem(ez_peer->group_id, data_len);
								encrypted_data = &pEid->Octet[EZ_TAG_DATA_OFFSET];			
								/* AES */
								AES_Key_Unwrap(encrypted_data, data_len,
											   &ez_peer->sw_key[0], LEN_PTK_KEK, 
											   ez_peer->group_id, &ez_peer->group_id_len);								
								tag_count++;
							}
						}
#ifdef NEW_CONNECTION_ALGO						
						if (tag == EZ_TAG_OPEN_GROUP_ID) {
							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							ez_peer->open_group_id_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
							NdisCopyMemory(ez_peer->open_group_id, &pEid->Octet[EZ_TAG_DATA_OFFSET], pEid->Octet[EZ_TAG_LEN_OFFSET]);
							tag_count++;
						}
#endif
						if (tag == EZ_TAG_MIC) {
							ez_calculate_mic(ez_peer->sw_key, data_buf, data_buf_len, &mic[0]);
							if (NdisEqualMemory(&mic[0], &pEid->Octet[EZ_TAG_DATA_OFFSET], EZ_MIC_LEN)) {
								tag_count++;
							}
							else {
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
									("%s() - MIC different......\n", __FUNCTION__));
							}
						}
					}
				}
				break;
			default:
				break;
		}

		Length = Length + 2 + pEid->Len;  /* Eid[1] + Len[1]+ content[Len]*/
		pEid = (PEID_STRUCT)((unsigned char *)pEid + 2 + pEid->Len);
	}

	if (data_buf)
		EZ_MEM_FREE(NULL, data_buf);
	
	if (tag_count >= EZ_AUTH_RSP_TAG_COUNT) {
		return EZ_STATUS_CODE_SUCCESS;
	}
	else
		return EZ_STATUS_CODE_INVALID_DATA;
}

static unsigned short ez_assoc_request_sanity(
	unsigned char isReassoc,
	void *msg,
	unsigned long msg_len,
	struct _ez_peer_security_info *ez_peer)
{
	unsigned char tag_count;
	FRAME_802_11 *Fr;
	unsigned char *Ptr;
	EID_STRUCT *pEid;
	unsigned long Length;
	unsigned char tag;
	unsigned char data_len;
	unsigned char capability0;
	unsigned char *data_buf;
	unsigned int data_buf_len;
	unsigned char mic[EZ_MIC_LEN];
	unsigned char expected_tag_count = EZ_ASSOC_REQ_TAG_COUNT;
	
	os_zero_mem(&mic[0], EZ_MIC_LEN);
	data_buf = msg;
	data_buf_len = 0;
	
	Length = 0;
	Fr = (PFRAME_802_11)msg;
	Ptr = Fr->Octet;
	Length += LENGTH_802_11;

	if (isReassoc)
	{
		Ptr += 10;
		Length += 10;
	}
	else
	{
		Ptr += 4;
		Length += 4;
	}	
	
	pEid = (PEID_STRUCT) Ptr;

	tag_count = 0;
	/* get variable fields from payload and advance the pointer*/
	while ((Length + 2 + pEid->Len) <= msg_len)
	{
		switch(pEid->Eid)
		{
			case IE_VENDOR_SPECIFIC:
				if (NdisEqualMemory(&pEid->Octet[0], &mtk_oui[0], MTK_OUI_LEN)) {
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
						("%s() - Found MTK Proprietary OUI.\n", __FUNCTION__));
					capability0 = pEid->Octet[MTK_OUI_LEN];
					if (capability0 & MTK_VENDOR_EASY_SETUP) {
						Ptr = (unsigned char *)pEid;
						data_buf_len = (unsigned int)(Ptr-(unsigned char *)msg);
						tag = pEid->Octet[EZ_TAG_OFFSET];
						data_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
							("%s() - tag = %d, data_len = %d\n", 
							__FUNCTION__, tag, data_len));
						if (tag == EZ_TAG_MIC) {
							/*
								Exclude 802.11 header to calculate mic data.
							*/
							ez_calculate_mic(ez_peer->sw_key, data_buf+LENGTH_802_11, data_buf_len-LENGTH_802_11, &mic[0]);
							if (NdisEqualMemory(&mic[0], &pEid->Octet[EZ_TAG_DATA_OFFSET], EZ_MIC_LEN)) {
								tag_count++;
							}
							else {
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
									("%s() - MIC different......\n", __FUNCTION__));
							}
						}
#ifdef NEW_CONNECTION_ALGO
						if (tag == EZ_TAG_CAPABILITY_INFO) {
							EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("ez_peer->capability, Before--->%x\n", ez_peer->capability));
							if (data_len == EZ_CAPABILITY_LEN) {
								NdisCopyMemory(&ez_peer->capability,
									&pEid->Octet[EZ_TAG_DATA_OFFSET], 
									EZ_CAPABILITY_LEN);
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("ez_peer->capability, received--->%x\n", ez_peer->capability));
							
								ez_peer->capability = be2cpu32(ez_peer->capability);
								tag_count++;
								//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_peer->capability, After--->%x\n", ez_peer->capability));
							
							}
							else
								return EZ_STATUS_CODE_INVALID_DATA;
						}
#endif
#ifdef NEW_CONNECTION_ALGO
						//! send netwrok weight in assoc response, this is stored in ez_peer info
						//! will be copied to ez_security if configuration adapt is required
						if(tag == EZ_TAG_NETWORK_WEIGHT)
						{
							NdisCopyMemory(ez_peer->device_info.network_weight,&pEid->Octet[EZ_TAG_DATA_OFFSET],NETWORK_WEIGHT_LEN);
							tag_count++;
						}
#ifndef EZ_DUAL_BAND_SUPPORT
						if (tag == EZ_TAG_AP_MAC) {
							if (data_len == MAC_ADDR_LEN) {
								NdisCopyMemory(&ez_peer->this_band_info.shared_info.ap_mac_addr, 
									&pEid->Octet[EZ_TAG_DATA_OFFSET], 
									MAC_ADDR_LEN);
								//ez_peer->capability = be2cpu32(ez_peer->capability);
								tag_count++;
							}
							else
								return EZ_STATUS_CODE_INVALID_DATA;
						}
#else
						if (tag == EZ_TAG_INTERFACE_INFO) {
							interface_info_tag_t *shared_info = (interface_info_tag_t *)&pEid->Octet[EZ_TAG_DATA_OFFSET];
							struct wifi_dev *wdev = ez_peer->wdev;
							PRTMP_ADAPTER ad = wdev->sys_handle;
							interface_info_t other_band_config;
							NdisCopyMemory(&ez_peer->this_band_info.shared_info,&shared_info[0], sizeof(interface_info_tag_t));
							NdisCopyMemory(&ez_peer->other_band_info.shared_info,&shared_info[1], sizeof(interface_info_tag_t));
							if (!ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_config) && !wdev->ez_security.other_band_info_backup.interface_activated)
							{
								struct wifi_dev *cli_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx].wdev;
								
								wdev->ez_security.other_band_info_backup.shared_info.ssid_len = shared_info[1].ssid_len;
								NdisCopyMemory(wdev->ez_security.other_band_info_backup.shared_info.ssid,shared_info[1].ssid,  shared_info[1].ssid_len);
								NdisCopyMemory(&wdev->ez_security.other_band_info_backup.shared_info.channel_info, &shared_info[1].channel_info, sizeof(channel_info_t));
#ifdef DOT11R_FT_SUPPORT
								FT_SET_MDID(wdev->ez_security.other_band_info_backup.shared_info.FtMdId, shared_info[1].FtMdId);
#endif

								wdev->ez_security.other_band_info_backup.interface_activated = TRUE;
								NdisCopyMemory(&cli_wdev->ez_security.other_band_info_backup,&wdev->ez_security.other_band_info_backup,sizeof(interface_info_t));
							}
							tag_count++;
							
						}

#endif
#endif

					}
				}
				break;
				
			default:
				break;
		}
		Length = Length + 2 + pEid->Len;  /* Eid[1] + Len[1]+ content[Len]*/
		pEid = (PEID_STRUCT)((unsigned char *)pEid + 2 + pEid->Len);
	}
#ifdef EZ_API_SUPPORT
	{
		struct wifi_dev *wdev = ez_peer->wdev;
		if (wdev->ez_security.ez_api_mode == CONNECTION_OFFLOAD)
		{
			expected_tag_count -= 2;
		}
	}
#endif

	if (tag_count == expected_tag_count) {
		return EZ_STATUS_CODE_SUCCESS;
	}
	else
		return EZ_STATUS_CODE_INVALID_DATA;
}

static unsigned short ez_assoc_response_sanity(
	void *msg,
	unsigned long msg_len,
	struct _ez_peer_security_info *ez_peer,
	struct wifi_dev *apcli_wdev)
{
	unsigned char tag_count;
	FRAME_802_11 *Fr;
	unsigned char *Ptr;
	EID_STRUCT *pEid;
	unsigned long Length;
	unsigned char tag;
	unsigned char data_len;
	unsigned char capability0;
	unsigned char *data_buf;
	unsigned int data_buf_len;
	unsigned char mic[EZ_MIC_LEN];
	unsigned char expected_tag_count = EZ_ASSOC_RSP_TAG_COUNT;

	data_buf_len = EZ_ASSOC_RSP_TAG_COUNT*255;
	EZ_MEM_ALLOC(NULL, &data_buf, data_buf_len);

	if (data_buf == NULL) {
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
						("%s() - malloc fail.\n", __FUNCTION__));
		return EZ_STATUS_CODE_NO_RESOURCE;
	}

	os_zero_mem(data_buf, data_buf_len);
	os_zero_mem(&mic[0], EZ_MIC_LEN);
	data_buf_len = 0;

	Length = 0;
	Fr = (PFRAME_802_11)msg;
	Ptr = Fr->Octet;
	Length += LENGTH_802_11;
	
	Ptr += 6;
	Length += 6;
	
	pEid = (PEID_STRUCT) Ptr;

	tag_count = 0;
	/* get variable fields from payload and advance the pointer*/
	while ((Length + 2 + pEid->Len) <= msg_len)
	{
		switch(pEid->Eid)
		{
			case IE_VENDOR_SPECIFIC:
				if (NdisEqualMemory(&pEid->Octet[0], &mtk_oui[0], MTK_OUI_LEN)) {
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
						("%s() - Found MTK Proprietary OUI.\n", __FUNCTION__));
					capability0 = pEid->Octet[MTK_OUI_LEN];
					if (capability0 & MTK_VENDOR_EASY_SETUP) {
						tag = pEid->Octet[EZ_TAG_OFFSET];
						data_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
							("%s() - tag = %d, data_len = %d\n", 
							__FUNCTION__, tag, data_len));
						if (tag == EZ_TAG_GTK) {
							if (data_len != 0) {
								EZ_MEM_ALLOC(NULL, &ez_peer->gtk, data_len+EZ_AES_KEY_ENCRYPTION_EXTEND);
								if (ez_peer->gtk) {
									unsigned char *encrypted_data;
									encrypted_data = &pEid->Octet[EZ_TAG_DATA_OFFSET];
									/* AES */
									AES_Key_Unwrap(encrypted_data, data_len,
												   &ez_peer->sw_key[0], LEN_PTK_KEK, 
												   ez_peer->gtk, &ez_peer->gtk_len);
									tag_count++;
									NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
									data_buf_len += (pEid->Len + 2);
								}
								else {
									ez_peer->gtk = NULL;
									if (data_buf)
										EZ_MEM_FREE(NULL, data_buf);
									return EZ_STATUS_CODE_NO_RESOURCE;
								}
							}
							else {
								if (data_buf)
									EZ_MEM_FREE(NULL, data_buf);
								return EZ_STATUS_CODE_INVALID_DATA;
							}
						}
#ifdef EZ_NETWORK_MERGE_SUPPORT	
						//! other band and weight parameters are not send in assoc request because 
						//! weight comparision after connection is performed by CLI, 		
						//! send oter band PMK in ecrypted form also in the assoc response			
						if (tag == EZ_TAG_OTHER_BAND_PMK)
						{
							unsigned int other_band_pmk_len;
							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							AES_Key_Unwrap(&pEid->Octet[EZ_TAG_DATA_OFFSET], data_len,
								   &ez_peer->sw_key[0], LEN_PTK_KEK, 
						    ez_peer->other_band_info.pmk, &other_band_pmk_len);
							tag_count++;
						}
#ifndef EZ_DUAL_BAND_SUPPORT		
						//! send netwrok weight in assoc response, this is stored in ez_peer info
						//! will be copied to ez_security if configuration adapt is required
						if(tag == EZ_TAG_NETWORK_WEIGHT)
						{

							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							NdisCopyMemory(ez_peer->device_info.network_weight,&pEid->Octet[EZ_TAG_DATA_OFFSET],NETWORK_WEIGHT_LEN);
							tag_count++;
						}
#else
						//! send netwrok weight in assoc response, this is stored in ez_peer info
						//! will be copied to ez_security if configuration adapt is required
						if(tag == EZ_TAG_DEVICE_INFO)
						{

							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							NdisCopyMemory(&ez_peer->device_info,&pEid->Octet[EZ_TAG_DATA_OFFSET], sizeof(device_info_t));
							tag_count++;
						}
#endif
#if 0
						//! send other band SSID in assoc response
						if(tag == EZ_TAG_OTHER_BAND_SSID)
						{

							NdisCopyMemory(data_buf+data_buf_len, pEid, (pEid->Len + 2));
							data_buf_len += (pEid->Len + 2);
							ez_peer->other_band_info.shared_info.ssid_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
							NdisZeroMemory(ez_peer->other_band_info.shared_info.ssid,32);
							NdisCopyMemory(ez_peer->other_band_info.shared_info.ssid,&pEid->Octet[EZ_TAG_DATA_OFFSET],ez_peer->other_band_info.shared_info.ssid_len);
							tag_count++;
						}

#else
						if (tag == EZ_TAG_INTERFACE_INFO) {
							interface_info_tag_t *shared_info = (interface_info_tag_t *)&pEid->Octet[EZ_TAG_DATA_OFFSET];
							NdisCopyMemory(&ez_peer->this_band_info.shared_info,&shared_info[0], sizeof(interface_info_tag_t));
							NdisCopyMemory(&ez_peer->other_band_info.shared_info,&shared_info[1], sizeof(interface_info_tag_t));
							tag_count++;
							
						}

#endif

#endif
						if (tag == EZ_TAG_MIC) {
							ez_calculate_mic(ez_peer->sw_key, data_buf, data_buf_len, &mic[0]);
							if (NdisEqualMemory(&mic[0], &pEid->Octet[EZ_TAG_DATA_OFFSET], EZ_MIC_LEN)) {
								tag_count++;
							}
							else {
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
									("%s() - MIC different......\n", __FUNCTION__));
							}
						}

					}
				}
				break;
				
			default:
				break;
		}
		Length = Length + 2 + pEid->Len;  /* Eid[1] + Len[1]+ content[Len]*/
		pEid = (PEID_STRUCT)((unsigned char *)pEid + 2 + pEid->Len);
	}

	if (data_buf)
		EZ_MEM_FREE(NULL, data_buf);

#ifdef EZ_API_SUPPORT
	{
		struct wifi_dev *wdev = ez_peer->wdev;
		if (wdev->ez_security.ez_api_mode == CONNECTION_OFFLOAD)
		{
			expected_tag_count -= 3;
		}
	}
#endif	
	if (tag_count == expected_tag_count) {
		return EZ_STATUS_CODE_SUCCESS;
	}
	else
		return EZ_STATUS_CODE_INVALID_DATA;
}

static struct _ez_apcli_entry *ez_find_apcli_entry(
	LIST_HEADER *ez_apcli_list,
	unsigned char *peer_addr)
{
	struct _ez_apcli_entry *ez_apcli_entry;
	RT_LIST_ENTRY *list_entry;

	list_entry = ez_apcli_list->pHead;
	ez_apcli_entry = (struct _ez_apcli_entry *)list_entry;
	while (ez_apcli_entry != NULL)
	{
		if (NdisEqualMemory(ez_apcli_entry->mac_addr, peer_addr, MAC_ADDR_LEN))
			return ez_apcli_entry;
		list_entry = list_entry->pNext;
		ez_apcli_entry = (struct _ez_apcli_entry *)list_entry;
	}

	return NULL;
}

static void ez_insert_apcli_entry_by_mac(
	LIST_HEADER *ez_apcli_list,
	unsigned char *peer_addr)
{
	struct _ez_apcli_entry *ez_apcli_entry;

	ez_apcli_entry = ez_find_apcli_entry(ez_apcli_list, peer_addr);
	if (ez_apcli_entry)
	{
		NdisGetSystemUpTime(&ez_apcli_entry->receive_time);
	}
	else
	{
		os_alloc_mem(NULL, (UCHAR **)&ez_apcli_entry, sizeof(struct _ez_apcli_entry));
		if (ez_apcli_entry)
		{
			NdisZeroMemory(ez_apcli_entry, sizeof(struct _ez_apcli_entry));
			ez_apcli_entry->next = NULL;
			NdisMoveMemory(ez_apcli_entry->mac_addr, peer_addr, MAC_ADDR_LEN);
			NdisGetSystemUpTime(&ez_apcli_entry->receive_time);
			insertTailList(ez_apcli_list, (RT_LIST_ENTRY *)ez_apcli_entry);
		}
		else {
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
					("%s() - ez_apcli_entry alloc fail......\n", __FUNCTION__));
		}
	}
}

static void ez_add_entry_to_acl_list(
	void *ad_obj,
	unsigned char if_idx,
	unsigned char *sta_addr)
{
	RTMP_ADAPTER *ad;
	PRT_802_11_ACL	pACL = NULL;
	INT				i;
	BOOLEAN			bFound = FALSE;

	ad = (RTMP_ADAPTER *)ad_obj;
	
	pACL = &ad->ApCfg.MBSSID[if_idx].AccessControlList;

	if ((pACL->Policy == 0) ||
		(pACL->Policy == 2))
		return;
	
	if (pACL->Num >= (MAX_NUM_OF_ACL_LIST - 1))
    {
    	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_WARN, 
				("%s() - The AccessControlList is full, and no more entry can join the list!\n", 
				__FUNCTION__));
		return;
	}

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				("%s() ra%d - Add this entry(%02x:%02x:%02x:%02x:%02x:%02x) to AccessControlList\n", 
				__FUNCTION__,
				if_idx,
				PRINT_MAC(sta_addr)));

	for (i=0; i<pACL->Num; i++)
	{
		if (NdisEqualMemory(pACL->Entry[i].Addr, sta_addr, MAC_ADDR_LEN))
			bFound = TRUE;
	}
	if (bFound == FALSE)
	{
		NdisMoveMemory(pACL->Entry[i].Addr, sta_addr, MAC_ADDR_LEN);
		pACL->Num++;
	}
}

void ez_del_apcli_entry_by_mac(
	LIST_HEADER *ez_apcli_list,
	unsigned char *peer_addr)
{
	RT_LIST_ENTRY *list_entry;
	list_entry = (RT_LIST_ENTRY *)WscFindPeerEntry(ez_apcli_list, peer_addr);
	if (list_entry)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s: entry addr = %02X:%02X:%02X:%02X:%02X:%02X\n", 
			__FUNCTION__, PRINT_MAC(peer_addr)));
		delEntryList(ez_apcli_list, list_entry);
		os_free_mem(list_entry);
	}
}

void ez_clear_apcli_list(
	LIST_HEADER	*apcli_list)
{
	RT_LIST_ENTRY *entry = NULL;

	entry = apcli_list->pHead;

	while (entry != NULL)
	{
		removeHeadList(apcli_list);
		os_free_mem(entry);
		entry = apcli_list->pHead;
	}

	return;
}

static struct _ez_peer_security_info *ez_peer_table_insert(
	void *wdev_obj,
	unsigned char *addr)
{
	int i;
	struct wifi_dev *wdev;
	struct _ez_peer_security_info *ez_peer;

	ez_peer = NULL;
	wdev = (struct wifi_dev *)wdev_obj;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
						("------> %s()\n", __FUNCTION__));
	ez_hex_dump("addr", addr, 6);
	ez_peer = ez_peer_table_search_by_addr(wdev, addr);
	if (ez_peer)
		return ez_peer;
	RTMP_SEM_LOCK(&wdev->ez_peer_table_lock);
	for (i = 0; i < EZ_MAX_STA_NUM; i++) {		
		if (wdev->ez_peer_table[i].valid == FALSE) {
			ez_peer = &wdev->ez_peer_table[i];
			ez_peer->valid = TRUE;
#ifdef NEW_CONNECTION_ALGO
			NdisGetSystemUpTime(&ez_peer->creation_time);
			ez_peer->ez_peer_table_index = i;
			ez_peer->wdev = wdev;
#endif
			NdisCopyMemory(&ez_peer->mac_addr[0], addr, MAC_ADDR_LEN);
			break;
		}
	}
	RTMP_SEM_UNLOCK(&wdev->ez_peer_table_lock);
	return ez_peer;
}

void ez_peer_table_delete(
	void *wdev_obj,
	unsigned char *addr)
{
	struct _ez_peer_security_info *ez_peer;
	struct wifi_dev *wdev;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER pAd;
#endif
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
						("------> %s()\n", __FUNCTION__));
	ez_hex_dump("addr", addr, 6);
	wdev = (struct wifi_dev *)wdev_obj;

	ez_peer = ez_peer_table_search_by_addr(wdev_obj, addr);
	RTMP_SEM_LOCK(&wdev->ez_peer_table_lock);
	if (ez_peer) {		
#ifdef DUAL_CHIP
	pAd = wdev->sys_handle;
	if(!IS_SINGLE_CHIP_DBDC(pAd)) 
		RTMP_SEM_LOCK(&pAd->ez_set_peer_lock);
#endif		
		if (ez_peer->gtk) {
			EZ_MEM_FREE(NULL, ez_peer->gtk);
			ez_peer->gtk = NULL;
			ez_peer->gtk_len = 0;
		}
		if (ez_peer->group_id) {
			EZ_MEM_FREE(NULL, ez_peer->group_id);
			ez_peer->group_id = NULL;
			ez_peer->group_id_len= 0;
		}
		NdisZeroMemory(ez_peer, sizeof(struct _ez_peer_security_info));
#ifdef DUAL_CHIP
			if(!IS_SINGLE_CHIP_DBDC(pAd))
				RTMP_SEM_UNLOCK(&pAd->ez_set_peer_lock);
#endif
	}else{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
							("------> %s()ez_peer_table Entry not found\n", __FUNCTION__));
	}
	RTMP_SEM_UNLOCK(&wdev->ez_peer_table_lock);
}

struct _ez_peer_security_info *ez_peer_table_search_by_addr(
	void *wdev_obj,
	unsigned char *addr)
{
	int i;
	struct wifi_dev *wdev;
	struct _ez_peer_security_info *ez_peer;

	ez_peer = NULL;
	wdev = (struct wifi_dev *)wdev_obj;
	RTMP_SEM_LOCK(&wdev->ez_peer_table_lock);
	for (i = 0; i < EZ_MAX_STA_NUM; i++) {		
		if (wdev->ez_peer_table[i].valid &&
			NdisEqualMemory(addr, wdev->ez_peer_table[i].mac_addr, MAC_ADDR_LEN)) {
			ez_peer = &wdev->ez_peer_table[i];
			break;
		}
	}
	RTMP_SEM_UNLOCK(&wdev->ez_peer_table_lock);
	return ez_peer;
}

void ez_show_peer_table_info(
	void *wdev_obj)
{
	int i;
	int j;
	struct wifi_dev *wdev;
	struct _ez_peer_security_info *ez_peer;

	wdev = (struct wifi_dev *)wdev_obj;

	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Show peer information - \n"));
	for (i = 0; i < EZ_MAX_STA_NUM; i++) {
			ez_peer = &wdev->ez_peer_table[i];

			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\t[%d] valid = %d, %02x:%02x:%02x:%02x:%02x:%02x\n", 
					i,
					ez_peer->valid,
					ez_peer->mac_addr[0],
					ez_peer->mac_addr[1],
					ez_peer->mac_addr[2],
					ez_peer->mac_addr[3],
					ez_peer->mac_addr[4],
					ez_peer->mac_addr[5]));
			if (ez_peer->valid) {
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tCapability   = 0x%04x\n", ez_peer->capability));
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tGroup ID     = "));
				for (j=0; j<ez_peer->group_id_len; j++) {
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", ez_peer->group_id[j]));
				}
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
				ez_hex_dump("\tNodeNumber    = ", (PUCHAR)&ez_peer->device_info.ez_node_number, sizeof(EZ_NODE_NUMBER));
				ez_hex_dump("\tWeight    = ", (PUCHAR)&ez_peer->device_info.network_weight, NETWORK_WEIGHT_LEN);

				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tPKE         = "));
			
				for (j=0; j<EZ_RAW_KEY_LEN; j++) {
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", ez_peer->peer_pke[j]));
				}
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tNonce         = "));
				for (j=0; j<EZ_NONCE_LEN; j++) {
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", ez_peer->peer_nonce[j]));
				}
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tSHA256 DH KEY= "));
				for (j=0; j<EZ_PMK_LEN; j++) {
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", ez_peer->dh_key[j]));
				}
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tPMK          = "));
				for (j=0; j<EZ_PMK_LEN; j++) {
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", ez_peer->this_band_info.pmk[j]));
				}
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tSW Key       = "));
				for (j=0; j<EZ_PTK_LEN; j++) {
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", ez_peer->sw_key[j]));
				}
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
			}
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
	}
}

static void ez_insert_tlv(
	unsigned char tag,
	unsigned char *data,
	unsigned char data_len,
	unsigned char *buffer,
	unsigned long *msg_len)
{
	struct _mediatek_ie mtk_ie;
	unsigned char mtk_tag;
	unsigned char mtk_data_len;
	
	NdisZeroMemory(&mtk_ie, sizeof(struct _mediatek_ie));
	mtk_ie.ie_hdr.eid = IE_VENDOR_SPECIFIC;
	mtk_ie.ie_hdr.len = MTK_OUI_LEN + MTK_VENDOR_CAPABILITY_SIZE;
	mtk_ie.ie_hdr.len = MTK_OUI_LEN + MTK_VENDOR_CAPABILITY_SIZE + EZ_TLV_TAG_SIZE + EZ_TLV_LEN_SIZE + data_len;
	NdisCopyMemory(&mtk_ie.oui, &mtk_oui[0], MTK_OUI_LEN);
	mtk_ie.cap0 |= MEDIATEK_EASY_SETUP;
	mtk_tag = tag;
	mtk_data_len = data_len;
	if (data && data_len) {
		MakeOutgoingFrame(buffer, msg_len, 
			sizeof(struct _mediatek_ie), &mtk_ie,
			1, &mtk_tag,
			1, &mtk_data_len,
			data_len, data,
			END_OF_ARGS);
	}
	else {
		MakeOutgoingFrame(buffer, msg_len, 
				sizeof(struct _mediatek_ie), &mtk_ie,
				1, &mtk_tag,
				1, &mtk_data_len,
				END_OF_ARGS);
	}
}

unsigned long ez_build_beacon_ie(
	void *wdev_obj,
	unsigned char *frame_buf)
{
	struct wifi_dev *wdev;
	unsigned int capability;
	unsigned long frame_len;
	unsigned long tmp_len;
	beacon_info_tag_t beacon_info_tag;
	interface_info_t other_band_info;
	wdev = (struct wifi_dev *)wdev_obj;
	
	if (wdev->enable_easy_setup) {
		frame_len = 0;
		tmp_len = 0;
		capability = cpu2be32(wdev->ez_security.capability);

		/*
			Insert Capability TLV
		*/
		ez_insert_tlv(EZ_TAG_CAPABILITY_INFO, 
			(unsigned char *)&capability, 
			EZ_CAPABILITY_LEN, 
			frame_buf, 
			&tmp_len);
		frame_len += tmp_len;
#ifdef EZ_API_SUPPORT
		if (wdev->ez_security.ez_api_mode != CONNECTION_OFFLOAD) {
#endif
#ifdef NEW_CONNECTION_ALGO
#if 0
		ez_insert_tlv(EZ_TAG_NETWORK_WEIGHT, 
			(unsigned char *)(wdev->ez_security.device_info.network_weight), 
			NETWORK_WEIGHT_LEN, 
			frame_buf+frame_len, 
			&tmp_len);
		frame_len += tmp_len;

		ez_insert_tlv(EZ_TAG_NODE_NUMBER, 
			(unsigned char *)&(wdev->ez_security.device_info.ez_node_number), 
			sizeof(EZ_NODE_NUMBER), 
			frame_buf+frame_len, 
			&tmp_len);
		frame_len += tmp_len;

		{
			interface_info_tag_t shared_info[2];
			interface_info_t other_band_info;
			NdisCopyMemory(&shared_info[0],&wdev->ez_security.this_band_info.shared_info,sizeof(interface_info_tag_t));
			if (ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info)){
				NdisCopyMemory(&shared_info[1],&other_band_info.shared_info,sizeof(interface_info_tag_t));
			} else {
				NdisCopyMemory(&shared_info[1],&wdev->ez_security.this_band_info.shared_info,sizeof(interface_info_tag_t));
			}
			ez_insert_tlv(EZ_TAG_INTERFACE_INFO, 
				(unsigned char *)&shared_info[0], 
				sizeof(shared_info), 
				frame_buf + frame_len, 
				&tmp_len);
			frame_len += tmp_len;
		}
#endif
		NdisZeroMemory(&beacon_info_tag,sizeof(beacon_info_tag_t));
		NdisCopyMemory(beacon_info_tag.network_weight, wdev->ez_security.device_info.network_weight, NETWORK_WEIGHT_LEN);
		NdisCopyMemory(&beacon_info_tag.node_number,&wdev->ez_security.device_info.ez_node_number,sizeof(EZ_NODE_NUMBER));
		ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info);
		NdisCopyMemory(beacon_info_tag.other_ap_mac,other_band_info.shared_info.ap_mac_addr,MAC_ADDR_LEN);
		beacon_info_tag.other_ap_channel = other_band_info.shared_info.channel_info.channel;
		
		ez_insert_tlv(EZ_TAG_BEACON_INFO, 
			(unsigned char *)&beacon_info_tag, 
			sizeof(beacon_info_tag_t), 
			frame_buf+frame_len, 
			&tmp_len);
		frame_len += tmp_len;
		
		ez_insert_tlv(EZ_TAG_OPEN_GROUP_ID, 
			(unsigned char *)(wdev->ez_security.open_group_id), 
			wdev->ez_security.open_group_id_len, 
			frame_buf+frame_len, 
			&tmp_len);
		frame_len += tmp_len;
#endif
#ifdef EZ_API_SUPPORT
			}
#endif
	}
	else
		frame_len = 0;

	return frame_len;
}

unsigned long ez_build_probe_request_ie(
	void *wdev_obj,
	unsigned char *frame_buf)
{
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
#ifdef EZ_NETWORK_MERGE_SUPPORT
	unsigned int capability;
#endif	
	unsigned long frame_len;
	unsigned long tmp_len;

	frame_len = 0;
	tmp_len = 0;
	wdev = (struct wifi_dev *)wdev_obj;
	ez_sec_info = (struct _ez_security *)&wdev->ez_security;
#ifdef EZ_NETWORK_MERGE_SUPPORT	
	capability = cpu2be32(wdev->ez_security.capability);

	/*
		Insert capability TLV
	*/
	ez_insert_tlv(EZ_TAG_CAPABILITY_INFO, 
		(unsigned char *)&capability, 
		EZ_CAPABILITY_LEN, 
		frame_buf + frame_len, 
		&tmp_len);
	frame_len += tmp_len;
#endif		
	/*
		Insert Supplicant DH Public Key TLV
	*/
	ez_insert_tlv(EZ_TAG_SDH_PUBLIC_KEY, 
			&ez_sec_info->self_pke[0], 
			EZ_RAW_KEY_LEN, 
			frame_buf + frame_len, 
			&tmp_len);
	frame_len += tmp_len;

	return frame_len;
}

unsigned long ez_build_probe_response_ie(
	void *wdev_obj,
	unsigned char *frame_buf)
{
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
	unsigned long frame_len;
	unsigned long tmp_len;	
	unsigned int capability;
	
	frame_len = 0;
	tmp_len = 0;
	wdev = (struct wifi_dev *)wdev_obj;
	ez_sec_info = (struct _ez_security *)&wdev->ez_security;
	capability = cpu2be32(ez_sec_info->capability);
	
	/*
		Insert Authenticator DH Public Key TLV
	*/
	ez_insert_tlv(EZ_TAG_ADH_PUBLIC_KEY, 
			&ez_sec_info->self_pke[0], 
			EZ_RAW_KEY_LEN, 
			frame_buf + frame_len, 
			&tmp_len);
	frame_len += tmp_len;
	return frame_len;
}

unsigned long ez_build_auth_request_ie(
	void *wdev_obj,
	unsigned char *peer_addr,
	unsigned char *frame_buf)
{
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
	unsigned long frame_len;
	unsigned long tmp_len;
	unsigned char *entrypted_data;
	unsigned int entrypted_data_len;
	struct _ez_peer_security_info *ez_peer;
	unsigned char mic[EZ_MIC_LEN];

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()\n", __FUNCTION__));

	entrypted_data_len = 0;
	frame_len = 0;
	tmp_len = 0;
	wdev = (struct wifi_dev *)wdev_obj;
	ez_sec_info = (struct _ez_security *)&wdev->ez_security;

	ez_peer = ez_peer_table_search_by_addr(wdev, peer_addr);
	if (ez_peer) {
		/*
			Insert Encrypted Group ID
		*/
		EZ_MEM_ALLOC(NULL, &entrypted_data, ez_sec_info->group_id_len + EZ_AES_KEY_ENCRYPTION_EXTEND);
		if (entrypted_data) {
			/* encrypt */
			AES_Key_Wrap((unsigned char *)ez_sec_info->group_id, ez_sec_info->group_id_len, 
						ez_peer->sw_key, LEN_PTK_KEK, 
						entrypted_data, &entrypted_data_len);
			
			ez_insert_tlv(EZ_TAG_GROUP_ID, 
				entrypted_data, 
				entrypted_data_len, 
				frame_buf + frame_len, 
				&tmp_len);
			frame_len += tmp_len;
			
			EZ_MEM_FREE(NULL, entrypted_data);
		}
#ifdef NEW_CONNECTION_ALGO
		ez_insert_tlv(EZ_TAG_OPEN_GROUP_ID, 
						ez_sec_info->open_group_id, 
						ez_sec_info->open_group_id_len, 
						frame_buf + frame_len, 
						&tmp_len);
					frame_len += tmp_len;

#endif
		/*
			Insert Supplicant Nonce TLV
		*/
		ez_insert_tlv(EZ_TAG_SNONCE, &ez_sec_info->self_nonce[0], EZ_NONCE_LEN, frame_buf+frame_len, &tmp_len);
		frame_len += tmp_len;

		/*
			Insert MIC for validation
		*/
		ez_calculate_mic(ez_peer->sw_key, frame_buf, frame_len, &mic[0]);		
		ez_insert_tlv(EZ_TAG_MIC, &mic[0], EZ_MIC_LEN, frame_buf+frame_len, &tmp_len);
		frame_len += tmp_len;
	}
	else {
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
					("%s(): cannot find ez_peer\n", __FUNCTION__));
	}
	return frame_len;
}

unsigned long ez_build_auth_response_ie(
	void *wdev_obj,
	struct _ez_peer_security_info *ez_peer,
	unsigned char *frame_buf)
{
	RTMP_ADAPTER *ad;
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
	unsigned long frame_len;
	unsigned long tmp_len;
	unsigned char *entrypted_gmk;
	unsigned int entrypted_gmk_len;
	unsigned char *entrypted_data;
	unsigned int entrypted_data_len;
	unsigned char mic[EZ_MIC_LEN];

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()\n", __FUNCTION__));

	frame_len = 0;
	tmp_len = 0;
	wdev = (struct wifi_dev *)wdev_obj;
	ez_sec_info = (struct _ez_security *)&wdev->ez_security;
	ad = (RTMP_ADAPTER *)ez_sec_info->ad;

	/*
		Insert Encrypted Group ID
	*/
	EZ_MEM_ALLOC(NULL, &entrypted_data, ez_sec_info->group_id_len + EZ_AES_KEY_ENCRYPTION_EXTEND);	
	if (entrypted_data) {
		/* encrypt */
		AES_Key_Wrap((unsigned char *)ez_sec_info->group_id, ez_sec_info->group_id_len, 
					ez_peer->sw_key, LEN_PTK_KEK, 
					entrypted_data, &entrypted_data_len);
		
		ez_insert_tlv(EZ_TAG_GROUP_ID, 
			entrypted_data, 
			entrypted_data_len, 
			frame_buf + frame_len, 
			&tmp_len);
		frame_len += tmp_len;
		
		EZ_MEM_FREE(NULL, entrypted_data);
	}
#ifdef NEW_CONNECTION_ALGO
			ez_insert_tlv(EZ_TAG_OPEN_GROUP_ID, 
							ez_sec_info->open_group_id, 
							ez_sec_info->open_group_id_len, 
							frame_buf + frame_len, 
							&tmp_len);
						frame_len += tmp_len;
	
#endif

	/*
		Insert Encrypted PMK if need.
	*/
	if (ez_sec_info->configured_status == EZ_CONFIGURED) {
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("%s() - EZ configured status is configured. Insert encrypted PMK.\n", 
					__FUNCTION__));
		EZ_MEM_ALLOC(NULL, &entrypted_gmk, LEN_PMK + EZ_AES_KEY_ENCRYPTION_EXTEND);	
		if (entrypted_gmk) {
			hex_dump("AP PMK", &wdev->SecConfig.PMK[0], LEN_PMK);
			/* encrypt */
			AES_Key_Wrap(&wdev->SecConfig.PMK[0], LEN_PMK, 
						ez_peer->sw_key, LEN_PTK_KEK, 
						entrypted_gmk, &entrypted_gmk_len);
			
			ez_insert_tlv(EZ_TAG_PMK, 
				entrypted_gmk, 
				entrypted_gmk_len, 
				frame_buf + frame_len, 
				&tmp_len);
			frame_len += tmp_len;
			
			EZ_MEM_FREE(NULL, entrypted_gmk);
		}
	}
	
	/*
		Insert Authenticator Nonce TLV
	*/
	ez_insert_tlv(EZ_TAG_ANONCE, &ez_sec_info->self_nonce[0], EZ_NONCE_LEN, frame_buf + frame_len, &tmp_len);
	frame_len += tmp_len;

	/*
		Insert MIC for validation
	*/
	os_zero_mem(&mic[0], EZ_MIC_LEN);
	ez_calculate_mic(ez_peer->sw_key, frame_buf, frame_len, &mic[0]);
	ez_insert_tlv(EZ_TAG_MIC, &mic[0], EZ_MIC_LEN, frame_buf+frame_len, &tmp_len);
	frame_len += tmp_len;

	return frame_len;
}

BOOLEAN ez_apcli_is_link_duplicate(void * ad_obj, struct wifi_dev *wdev,unsigned char * peer_addr)
{
		PRTMP_ADAPTER pAd = ad_obj;
		struct _ez_peer_security_info * ez_other_cli_peer_ap;
		interface_info_t other_band_info;
		
#ifdef DUAL_CHIP
		PRTMP_ADAPTER adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if (!IS_SINGLE_CHIP_DBDC(wdev->sys_handle)){
			if(adOthBand == NULL) {
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
				ASSERT(FALSE);
				return FALSE;
			}
		}
#endif
		if (ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info) == FALSE)
			return FALSE;

		if (IS_SINGLE_CHIP_DBDC(wdev->sys_handle)){
			struct wifi_dev *other_band_wdev = &pAd->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev;
			ez_other_cli_peer_ap = ez_peer_table_search_by_addr(other_band_wdev, other_band_info.cli_peer_ap_mac);
		}
#ifdef DUAL_CHIP
		else {
			struct wifi_dev *other_band_wdev = &adOthBand->ApCfg.ApCliTab[0].wdev;
			ez_other_cli_peer_ap = ez_peer_table_search_by_addr(other_band_wdev, other_band_info.cli_peer_ap_mac);
		}
		if (ez_other_cli_peer_ap 
			&& NdisEqualMemory(peer_addr,ez_other_cli_peer_ap->other_band_info.shared_info.ap_mac_addr,MAC_ADDR_LEN))
		{
			//! since internal_force_connect_bssid is set, we are attempting  duplicate link, AP will simply store it in its ez_peer
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("TRUE\n"));
			return TRUE;
		}
	
#endif
		return FALSE;
}

unsigned long ez_build_assoc_request_ie(
	void *ad_obj,
	void *wdev_obj,
	unsigned char *peer_addr,
	unsigned char *frame_buf,
	unsigned int frame_buf_len)
{

	PRTMP_ADAPTER pAd = ad_obj;
	struct wifi_dev *wdev;
	unsigned long frame_len;
	unsigned long tmp_len;
	unsigned char mic[EZ_MIC_LEN];
	struct _ez_peer_security_info *ez_peer;

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()\n", __FUNCTION__));

	frame_len = 0;
	tmp_len = 0;
	wdev = (struct wifi_dev *)wdev_obj;

	ez_peer = ez_peer_table_search_by_addr(wdev, peer_addr);
	if (ez_peer) {
		/*
			Insert MIC for validation
		*/
		os_zero_mem(&mic[0], EZ_MIC_LEN);
		/*
			Because driver cannot know the vaule of duration and sequence now,
			exclude 802.11 header to calculate mic data.
		*/
		ez_calculate_mic(ez_peer->sw_key, (frame_buf-frame_buf_len+LENGTH_802_11), frame_buf_len-LENGTH_802_11, &mic[0]);
		ez_insert_tlv(EZ_TAG_MIC, 
			(unsigned char *)&mic[0], 
			EZ_MIC_LEN, 
			frame_buf, 
			&tmp_len);
		frame_len += tmp_len;
#ifdef NEW_CONNECTION_ALGO
		{
			unsigned int capability;
			capability = be2cpu32(wdev->ez_security.capability);
			ez_insert_tlv(EZ_TAG_CAPABILITY_INFO, 
				(unsigned char *)&capability, 
				EZ_CAPABILITY_LEN, 
				frame_buf + frame_len, 
				&tmp_len);
			frame_len += tmp_len;
		}

#endif
#ifdef EZ_API_SUPPORT
		if (wdev->ez_security.ez_api_mode != CONNECTION_OFFLOAD) {
#endif
#ifdef NEW_CONNECTION_ALGO
#ifndef EZ_DUAL_BAND_SUPPORT
		{
				ez_insert_tlv(EZ_TAG_AP_MAC, 
					(unsigned char *)&(pAd->ApCfg.MBSSID[wdev->func_idx].wdev.bssid), 
					MAC_ADDR_LEN, 
					frame_buf + frame_len, 
					&tmp_len);
				frame_len += tmp_len;
		}
#else
{
		interface_info_tag_t shared_info[2];
		interface_info_t other_band_info;
		NdisCopyMemory(&shared_info[0],&wdev->ez_security.this_band_info.shared_info,sizeof(interface_info_tag_t));
		if (ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info)){
			NdisCopyMemory(&shared_info[1],&other_band_info.shared_info,sizeof(interface_info_tag_t));
		} else {
			NdisZeroMemory(&shared_info[1], sizeof(interface_info_tag_t));
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("other band interface not activated\n"));
			if (wdev->ez_security.other_band_info_backup.interface_activated)
			{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("will use backup configs\n"));
				shared_info[1].ssid_len = wdev->ez_security.other_band_info_backup.shared_info.ssid_len;
				NdisCopyMemory(shared_info[1].ssid, wdev->ez_security.other_band_info_backup.shared_info.ssid, wdev->ez_security.other_band_info_backup.shared_info.ssid_len);
				NdisCopyMemory(&shared_info[1].channel_info, &wdev->ez_security.other_band_info_backup.shared_info.channel_info, sizeof(channel_info_t));
#ifdef DOT11R_FT_SUPPORT
				FT_SET_MDID(shared_info[1].FtMdId, wdev->ez_security.other_band_info_backup.shared_info.FtMdId);
#endif

			}
		}
		ez_hex_dump("peer_addr", peer_addr, MAC_ADDR_LEN);
		ez_hex_dump("other_band_info.cli_peer_ap_mac", other_band_info.cli_peer_ap_mac, MAC_ADDR_LEN);

		if (ez_apcli_is_link_duplicate(pAd,wdev,peer_addr) == TRUE)
		{
			shared_info[0].link_duplicate = TRUE;
			shared_info[1].link_duplicate = TRUE;
		}
		ez_insert_tlv(EZ_TAG_INTERFACE_INFO, 
			(unsigned char *)&shared_info[0], 
			sizeof(shared_info), 
			frame_buf + frame_len, 
			&tmp_len);
		frame_len += tmp_len;
}
#endif
#endif
#ifdef NEW_CONNECTION_ALGO
		ez_insert_tlv(EZ_TAG_NETWORK_WEIGHT, 
			(unsigned char *)(wdev->ez_security.device_info.network_weight), 
			NETWORK_WEIGHT_LEN, 
			frame_buf+frame_len, 
			&tmp_len);
		frame_len += tmp_len;
#endif
#ifdef EZ_API_SUPPORT
		}
#endif



	}

	return frame_len;
}

unsigned long ez_build_assoc_response_ie(
	void *wdev_obj,
	unsigned char *peer_addr,
	unsigned char *ap_gtk,
	unsigned int ap_gtk_len,
	unsigned char *frame_buf)
{
	struct wifi_dev *wdev;
	RTMP_ADAPTER *pAd;
	struct _ez_security *ez_sec_info;
	struct _ez_peer_security_info *ez_peer;
	unsigned long frame_len;
	unsigned long tmp_len;
	unsigned char mic[EZ_MIC_LEN];
	unsigned char *entrypted_gtk;
	unsigned int entrypted_gtk_len;
#ifdef EZ_NETWORK_MERGE_SUPPORT	
	unsigned char *other_band_pmk;
	unsigned int encrypted_pmk_len;
#endif	

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()\n", __FUNCTION__));

	frame_len = 0;
	tmp_len = 0;
	wdev = (struct wifi_dev *)wdev_obj;
	ez_sec_info = (struct _ez_security *)&wdev->ez_security;
	pAd = wdev->sys_handle;	
	ez_peer = ez_peer_table_search_by_addr(wdev_obj, peer_addr);
	if (ez_peer == NULL)
	{
		ASSERT(FALSE);
		return 0;
	}
	EZ_MEM_ALLOC(NULL, &entrypted_gtk, ap_gtk_len + EZ_AES_KEY_ENCRYPTION_EXTEND);	
	if (entrypted_gtk && ez_peer) {
		NdisZeroMemory(entrypted_gtk, ap_gtk_len + EZ_AES_KEY_ENCRYPTION_EXTEND);

		hex_dump("AP GTK", ap_gtk, ap_gtk_len);
		/* encrypt */
		AES_Key_Wrap(ap_gtk, ap_gtk_len, ez_peer->sw_key, LEN_PTK_KEK, 
					 entrypted_gtk, &entrypted_gtk_len);
			
		/*
			Insert encrypted GTK.
		*/
		ez_insert_tlv(EZ_TAG_GTK, 
			entrypted_gtk, 
			entrypted_gtk_len, 
			frame_buf, 
			&tmp_len);
		frame_len += tmp_len;
#ifdef EZ_API_SUPPORT
				if (wdev->ez_security.ez_api_mode != CONNECTION_OFFLOAD) {
#endif

#ifdef EZ_NETWORK_MERGE_SUPPORT	
		EZ_MEM_ALLOC(NULL, &other_band_pmk, PMK_LEN + EZ_AES_KEY_ENCRYPTION_EXTEND);
			if (other_band_pmk) {
				interface_info_t other_band_info;
				if (ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info)) {
					
					/* encrypt */
					AES_Key_Wrap(other_band_info.pmk, PMK_LEN, ez_peer->sw_key, LEN_PTK_KEK, 
								 other_band_pmk, &encrypted_pmk_len);
					} else {
					NdisZeroMemory(other_band_pmk, PMK_LEN + EZ_AES_KEY_ENCRYPTION_EXTEND);
					if (IS_SINGLE_CHIP_DBDC(pAd))
					{
						if (pAd->ApCfg.BssidNum == 1 && pAd->CommonCfg.dbdc_mode == 0)
						{
							NdisCopyMemory(&other_band_info.pmk,&wdev->ez_security.other_band_info_backup.pmk,PMK_LEN);
							AES_Key_Wrap(other_band_info.pmk, PMK_LEN, ez_peer->sw_key, LEN_PTK_KEK, 
								 other_band_pmk, &encrypted_pmk_len);
						}
					}	
					encrypted_pmk_len = PMK_LEN + EZ_AES_KEY_ENCRYPTION_EXTEND;
				}
				ez_insert_tlv(EZ_TAG_OTHER_BAND_PMK, 
					(unsigned char *)other_band_pmk, 
					encrypted_pmk_len, 
					frame_buf + frame_len, 
					&tmp_len);
				frame_len += tmp_len;
				EZ_MEM_FREE(NULL, other_band_pmk);
#ifndef EZ_DUAL_BAND_SUPPORT				
				ez_insert_tlv(EZ_TAG_OTHER_BAND_SSID, 
				(unsigned char *)ez_sec_info->other_band_info.shared_info.ssid, 
				ez_sec_info->other_band_info.shared_info.ssid_len, 
				frame_buf + frame_len, 
				&tmp_len);
				frame_len += tmp_len;
				
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Build assoc response ---> %s, %d\n", ez_sec_info->other_band_info.shared_info.ssid, ez_sec_info->other_band_info.shared_info.ssid_len));
#endif
			} else {
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
					("%s() - Allocate encryption buffer fail!\n", 
					__FUNCTION__));
				
				EZ_MEM_FREE(NULL, entrypted_gtk);
				return 0;
			}
#endif

#ifdef EZ_API_SUPPORT
					}
#endif
		/*
			Insert MIC TLV
		*/
		os_zero_mem(&mic[0], EZ_MIC_LEN);
		ez_calculate_mic(ez_peer->sw_key, frame_buf, frame_len, &mic[0]);
		ez_insert_tlv(EZ_TAG_MIC, 
			(unsigned char *)&mic[0], 
			EZ_MIC_LEN, 
			frame_buf + frame_len, 
			&tmp_len);
		frame_len += tmp_len;
#ifdef EZ_API_SUPPORT
				if (wdev->ez_security.ez_api_mode != CONNECTION_OFFLOAD) {
#endif		
#ifdef NEW_CONNECTION_ALGO
	{
		device_info_t device_info;
		NdisCopyMemory(&device_info ,&wdev->ez_security.device_info, sizeof(device_info_t));
		NdisCopyMemory(&device_info.ez_node_number ,&ez_peer->device_info.ez_node_number, sizeof(EZ_NODE_NUMBER));
		ez_insert_tlv(EZ_TAG_DEVICE_INFO, 
				(unsigned char *)(&device_info), 
				sizeof(device_info_t), 
				frame_buf+frame_len, 
				&tmp_len);
			frame_len += tmp_len;
	}
#endif
	{
		interface_info_tag_t shared_info[2];
		interface_info_t other_band_info;
		NdisZeroMemory(shared_info,sizeof(shared_info));
		NdisCopyMemory(&shared_info[0],&wdev->ez_security.this_band_info.shared_info,sizeof(interface_info_tag_t));
		if (ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info)) {
			NdisCopyMemory(&shared_info[1],&other_band_info.shared_info,sizeof(interface_info_tag_t));
		} else {
			NdisZeroMemory(&shared_info[1], sizeof(interface_info_tag_t));
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("otherband interface not activated\n"));
			if (wdev->ez_security.other_band_info_backup.interface_activated)
			{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("--->will use backup\n"));
				shared_info[1].ssid_len = wdev->ez_security.other_band_info_backup.shared_info.ssid_len;
				NdisCopyMemory(shared_info[1].ssid, wdev->ez_security.other_band_info_backup.shared_info.ssid, wdev->ez_security.other_band_info_backup.shared_info.ssid_len);
				NdisCopyMemory(&shared_info[1].channel_info, &wdev->ez_security.other_band_info_backup.shared_info.channel_info, sizeof(channel_info_t));
#ifdef DOT11R_FT_SUPPORT
				FT_SET_MDID(shared_info[1].FtMdId,wdev->ez_security.other_band_info_backup.shared_info.FtMdId);
#endif
			}
		}
 		ez_insert_tlv(EZ_TAG_INTERFACE_INFO, 
			(unsigned char *)&shared_info[0], 
			sizeof(shared_info), 
			frame_buf + frame_len, 
			&tmp_len);
		frame_len += tmp_len;
	}
#ifdef EZ_API_SUPPORT
	}
#endif


		EZ_MEM_FREE(NULL, entrypted_gtk);
		return frame_len;
	}
	else {
		if (!entrypted_gtk) {
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
					("%s() - Allocate encryption buffer fail!\n", 
					__FUNCTION__));
		}
		if (!ez_peer) {
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
					("%s() - Cannot find information of easy setup peer!\n", 
					__FUNCTION__));
		}
		return 0;
	}
}

unsigned char ez_process_probe_request(
	void *ad_obj,
	void *wdev_obj,
	unsigned char *peer_addr,
	void *msg,
	unsigned long msg_len)
{
	RTMP_ADAPTER *ad;
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
	struct _ez_peer_security_info *ez_peer;
	unsigned short status;
	FRAME_802_11 *Fr;

	ad = (RTMP_ADAPTER *)ad_obj;
	wdev = (struct wifi_dev *)wdev_obj;

	Fr = (PFRAME_802_11)msg;

	/*
		Only process unicast probe request.
	*/
	if (!NdisEqualMemory(wdev->if_addr, Fr->Hdr.Addr1, MAC_ADDR_LEN)) {
		return FALSE;
	}
	
	ez_peer = ez_peer_table_insert(wdev, peer_addr);

	status = FALSE;
	RTMP_SEM_LOCK(&wdev->ez_peer_table_lock);
	if (ez_peer) {
		ez_sec_info = &wdev->ez_security;
		status = ez_probe_request_sanity(wdev, msg, msg_len, ez_peer);
	}
	else
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("%s:EzPeer is NULL!!!\n", __FUNCTION__));
	}
	RTMP_SEM_UNLOCK(&wdev->ez_peer_table_lock);
	if (status == EZ_STATUS_CODE_SUCCESS) {
#ifdef APCLI_SUPPORT
		APCLI_STRUCT *apcli_entry;
		apcli_entry = &ad->ApCfg.ApCliTab[wdev->func_idx];
		/*
			Peer found me and start to do easy setup.
			Stop apcli auto connect to prevent easy setup handshaking failed.
		*/
			if (apcli_entry->wdev.ez_security.ez_scan_timer_running
				&& apcli_entry->wdev.ez_security.this_band_info.interface_activated) {
				EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_scan_timer,
					apcli_entry->wdev.ez_security.ez_scan_timer_running);
			}

		if (apcli_entry->wdev.enable_easy_setup &&
			apcli_entry->wdev.ez_security.keep_finding_provider
			&& apcli_entry->wdev.ez_security.this_band_info.interface_activated) {

			RTMP_SEM_LOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);

			apcli_entry->stop_auto_connect = TRUE;

			if (!apcli_entry->wdev.ez_security.ez_scan_pause_timer_running) {
				EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
					("(%s) Set scan pause timer(time = %d). \n", __FUNCTION__, EZ_PAUSE_SCAN_TIME_OUT));
				RTMPSetTimer(&apcli_entry->wdev.ez_security.ez_scan_pause_timer, EZ_PAUSE_SCAN_TIME_OUT);
				apcli_entry->wdev.ez_security.ez_scan_pause_timer_running = TRUE;
			}
			else{// timer already set, imples another ez peer apcli also attempting ap, set the timer again
				EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_scan_pause_timer,
					apcli_entry->wdev.ez_security.ez_scan_pause_timer_running);

				RTMP_SEM_UNLOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);
                // In case timer got fired, release & retake lock to avoid the timeout handler reset state
				RTMP_SEM_LOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);

				EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
					("(%s) Set scan pause timer(time = %d). \n", __FUNCTION__, EZ_PAUSE_SCAN_TIME_OUT));
				RTMPSetTimer(&apcli_entry->wdev.ez_security.ez_scan_pause_timer, EZ_PAUSE_SCAN_TIME_OUT);
				apcli_entry->wdev.ez_security.ez_scan_pause_timer_running = TRUE;
			}

    		RTMP_SEM_UNLOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);

		}
#endif /* APCLI_SUPPORT */
		return TRUE;
	}
	else {
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ProbeReq sanity failed\n"));
		ez_update_connection(ad_obj,wdev_obj);
		ez_peer_table_delete(wdev, peer_addr);
		return FALSE;
	}
}

void ez_process_beacon_probe_response(
	struct _ez_security *ez_sec_info,
	void *msg,
	unsigned long msg_len)
{
	FRAME_802_11 *Fr;
	struct wifi_dev *wdev;
	struct _ez_peer_security_info *ez_peer;
	USHORT Status;
	wdev = (struct wifi_dev *)ez_sec_info->wdev;
	Fr = (PFRAME_802_11)msg;

	ez_peer = ez_peer_table_insert(wdev, Fr->Hdr.Addr2);
	
	if (ez_peer) {
		Status = ez_probe_beacon_response_sanity(msg, 
					msg_len, ez_peer);
		if (Status)
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("beacon_rsp sanity failed\n"));
	} 
	else
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("%s: ezpeer is null\n", __FUNCTION__));
	}
}

unsigned char ez_process_auth_request(
	void *ad_obj,
	void *wdev_obj,
	void *auth_info_obj,
	void *msg,
	unsigned long msg_len)
{
	RTMP_ADAPTER *pAd;
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
	AUTH_FRAME_INFO *auth_info;
	HEADER_802_11 auth_hdr;
	unsigned short reason_code;
	unsigned char *pOutBuffer;
	unsigned long FrameLen;
	struct _ez_peer_security_info *ez_peer;

	pAd = (RTMP_ADAPTER *)ad_obj;
	wdev = (struct wifi_dev *)wdev_obj;

#ifdef NEW_CONNECTION_ALGO
	if (ez_is_connection_allowed(wdev) == FALSE)
		return FALSE;
#endif
	if (MlmeAllocateMemory(pAd, &pOutBuffer)) {
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
				("%s() - no memory, cannot send auth response.\n", 
				__FUNCTION__));
		return FALSE;
	}
	
	auth_info = (AUTH_FRAME_INFO *)auth_info_obj;
	
	reason_code = 0;
	FrameLen = 0;
	ez_sec_info = &wdev->ez_security;
	
	ez_peer = ez_peer_table_search_by_addr(wdev, auth_info->addr2);
	if (ez_peer) {
		reason_code = ez_auth_request_sanity(msg, msg_len, ez_peer);
#ifdef EZ_NETWORK_MERGE_SUPPORT
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("peer_capabilities :%x\n",ez_peer->capability));
		//! if addr2 mathches the address provided by host, bypass group ID check	
		if (NdisEqualMemory(ez_sec_info->merge_peer_addr,auth_info->addr2,MAC_ADDR_LEN)){
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("%s(): different group id, Group Merge going on, allow Connection.\n",
					__FUNCTION__));
			
		}
		//! or if peer supports group merge and host has not given a specific address for merge, bypass group ID check
		else if (EZ_GET_CAP_ALLOW_MERGE(ez_peer->capability)
			&& MAC_ADDR_EQUAL(ez_sec_info->merge_peer_addr, BROADCAST_ADDR)){
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("%s(): allow Connection as both sides ignore group ID.\n",
					__FUNCTION__));
			
		}
		//! if above two checks fail, compare group ID 
		else {
#endif		
		if ((reason_code == EZ_STATUS_CODE_SUCCESS) &&
				((ez_peer->group_id_len != ez_sec_info->group_id_len)||
			 	(!NdisEqualMemory(ez_sec_info->group_id, ez_peer->group_id, ez_peer->group_id_len)))) {
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("%s(): different group id, reject this auth request.\n",
					__FUNCTION__));
				ez_hex_dump("My Group ID", ez_sec_info->group_id, ez_sec_info->group_id_len);
				ez_hex_dump("Peer Group ID", ez_peer->group_id, ez_peer->group_id_len);
				reason_code = EZ_STATUS_CODE_INVALID_DATA;
			}
#ifdef EZ_NETWORK_MERGE_SUPPORT			
		}
#endif		
	}
	else
		reason_code = EZ_STATUS_CODE_NO_RESOURCE;

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
		("AUTH - Send AUTH response (alg = 0x%x, reason = 0x%x)\n", 
		auth_info->auth_alg, reason_code));
	
	MgtMacHeaderInit(pAd, &auth_hdr, SUBTYPE_AUTH, 0, auth_info->addr2,
				wdev->if_addr,
				wdev->bssid);

	auth_info->auth_alg = cpu2le16(auth_info->auth_alg);
	auth_info->auth_seq++;
	MakeOutgoingFrame(pOutBuffer, &FrameLen,
			sizeof(HEADER_802_11),	&auth_hdr,
			2,			&auth_info->auth_alg,
			2,			&auth_info->auth_seq,
			2,			&reason_code,
			END_OF_ARGS);

	if (reason_code == EZ_STATUS_CODE_SUCCESS) {
		FrameLen += ez_build_auth_response_ie(wdev, ez_peer, pOutBuffer+FrameLen);
	}

	MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
	EZ_MEM_FREE(NULL, pOutBuffer);

	if (reason_code == EZ_STATUS_CODE_SUCCESS) { // Scan is already paused. 

		//EZ_CANCEL_TIMER(&wdev->ez_security.ez_scan_timer, 
		//	wdev->ez_security.ez_scan_timer_running);

		//EZ_CANCEL_TIMER(&wdev->ez_security.ez_stop_scan_timer, 
		//	wdev->ez_security.ez_stop_scan_timer_running);
		//wdev->ez_security.keep_finding_provider = FALSE;
		return TRUE;
	}
	else
		return FALSE;
}

void ez_process_auth_response(
	void *ad_obj,
	void *wdev_obj,
	unsigned char *peer_addr,
	unsigned long *current_state,
	void *msg,
	unsigned long msg_len)
{
	RTMP_ADAPTER *ad;
	struct wifi_dev *wdev;
	APCLI_CTRL_MSG_STRUCT ApCliCtrlMsg; 
	struct _ez_peer_security_info *ez_peer;

	ad = (RTMP_ADAPTER *)ad_obj;
	wdev = (struct wifi_dev *)wdev_obj;

	ez_peer = ez_peer_table_search_by_addr(wdev, peer_addr);

	os_zero_mem(&ez_peer->this_band_info.pmk[0], EZ_PMK_LEN);
	NdisCopyMemory(&ez_peer->this_band_info.pmk[0], &ez_peer->dh_key[0], EZ_PMK_LEN);
	if (ez_peer && 
		ez_auth_response_sanity(msg, msg_len, ez_peer)
			== EZ_STATUS_CODE_SUCCESS) {
#ifdef EZ_NETWORK_MERGE_SUPPORT
			//! if peer addr matches addr by host, bypass group ID check			
			if (NdisEqualMemory(wdev->ez_security.merge_peer_addr,peer_addr,MAC_ADDR_LEN)){
				ApCliCtrlMsg.Status = MLME_SUCCESS;
			}
			//! or if peer supports open merge, by pass groupID check
			else if (EZ_GET_CAP_ALLOW_MERGE(wdev->ez_security.capability) && EZ_GET_CAP_ALLOW_MERGE(ez_peer->capability)){
					ApCliCtrlMsg.Status = MLME_SUCCESS;
			} else {
#endif			
				if ((wdev->ez_security.group_id_len == ez_peer->group_id_len)
					&& NdisEqualMemory(wdev->ez_security.group_id, ez_peer->group_id, ez_peer->group_id_len))
						ApCliCtrlMsg.Status = MLME_SUCCESS;
				else {
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
						("%s(): different group id, reject this auth response.\n",
						__FUNCTION__));
					ez_hex_dump("My Group ID", wdev->ez_security.group_id, wdev->ez_security.group_id_len);
					ez_hex_dump("Peer Group ID", ez_peer->group_id, ez_peer->group_id_len);
					ApCliCtrlMsg.Status = MLME_INVALID_FORMAT;
					}
#ifdef EZ_NETWORK_MERGE_SUPPORT
				}
#endif				
			}
	else {
		ApCliCtrlMsg.Status = MLME_FAIL_NO_RESOURCE;
	}

	*current_state = APCLI_AUTH_REQ_IDLE;
	MlmeEnqueue(ad, APCLI_CTRL_STATE_MACHINE, APCLI_CTRL_AUTH_RSP,
			sizeof(APCLI_CTRL_MSG_STRUCT), &ApCliCtrlMsg, wdev->func_idx);
}

unsigned short ez_process_assoc_request(
	void *wdev_obj,
	void *entry_obj,
	unsigned char isReassoc,
	void *msg,
	unsigned long msg_len)
{
	struct wifi_dev *wdev;
	struct _ez_peer_security_info *ez_peer;
	MAC_TABLE_ENTRY *entry;

	wdev = (struct wifi_dev *)wdev_obj;
	entry = (MAC_TABLE_ENTRY *)entry_obj;

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
		("------> %s\n", 
		__FUNCTION__));
	
	entry->easy_setup_mic_valid = FALSE;
	ez_peer = ez_peer_table_search_by_addr(wdev, entry->Addr);
	if (ez_peer) {
		if (ez_assoc_request_sanity(isReassoc, msg, msg_len, ez_peer)
				== EZ_STATUS_CODE_SUCCESS) {
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("is duplicate link: %d\n",
																ez_peer->this_band_info.shared_info.link_duplicate));
				if (ez_is_weight_same(wdev->ez_security.device_info.network_weight,ez_peer->device_info.network_weight)					
					&& !ez_peer->this_band_info.shared_info.link_duplicate
					)
					{
						return EZ_STATUS_CODE_LOOP;
					}
			entry->easy_setup_mic_valid = TRUE;
			return EZ_STATUS_CODE_SUCCESS;
		}
		else
			return EZ_STATUS_CODE_INVALID_DATA;
	}
	else
	{
		return EZ_STATUS_CODE_UNKNOWN;
	}

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
		("<------ %s\n", 
		__FUNCTION__));
}

unsigned short ez_process_assoc_response(
	void *wdev_obj,
	unsigned char *peer_addr,
	void *msg,
	unsigned long msg_len)
{
	struct wifi_dev *wdev;
	struct _ez_peer_security_info *ez_peer;

	wdev = (struct wifi_dev *)wdev_obj;

	ez_peer = ez_peer_table_search_by_addr(wdev, peer_addr);
	if (ez_peer) {
		return ez_assoc_response_sanity(msg, msg_len, ez_peer,wdev);
	}
	else
		return EZ_STATUS_CODE_UNKNOWN;
}

unsigned char ez_install_ptk(
	void *ad_obj,
	void *entry_obj,
	unsigned char authenticator)
{
	RTMP_ADAPTER *pAd;
	struct wifi_dev *wdev;
	MAC_TABLE_ENTRY *entry;
	struct _ez_security *ez_sec_info;
	unsigned char ptk[EZ_PTK_LEN];
	struct _ez_peer_security_info *ez_peer;
	
	pAd = (RTMP_ADAPTER *)ad_obj;
	entry = (MAC_TABLE_ENTRY *)entry_obj;
	wdev = (struct wifi_dev *)entry->wdev;
	ez_sec_info = &wdev->ez_security;

	ez_peer = ez_peer_table_search_by_addr(wdev, entry->Addr);

	if (ez_peer) {
		if (authenticator) {
#ifdef RELEASE_EXCLUDE
			hex_dump("A_Nonce", ez_sec_info->self_nonce, EZ_NONCE_LEN);
			hex_dump("A_Addr", wdev->if_addr, 6);
			hex_dump("S_Nonce", ez_peer->peer_nonce, EZ_NONCE_LEN);
			hex_dump("S_Addr", entry->Addr, 6);
#endif /* RELEASE_EXCLUDE */
			EZ_DERIVE_PTK(pAd, 
				&ez_peer->this_band_info.pmk[0], 
				ez_sec_info->self_nonce, 
				wdev->if_addr, 
				ez_peer->peer_nonce, 
				entry->Addr, 
				&ptk[0], 
				LEN_PTK);		
		}
		else {
#ifdef RELEASE_EXCLUDE
			hex_dump("A_Nonce", ez_peer->peer_nonce, EZ_NONCE_LEN);
			hex_dump("A_Addr", entry->Addr, 6);
			hex_dump("S_Nonce", ez_sec_info->self_nonce, EZ_NONCE_LEN);
			hex_dump("S_Addr", wdev->if_addr, 6);
#endif /* RELEASE_EXCLUDE */
			EZ_DERIVE_PTK(pAd, 
				&ez_peer->this_band_info.pmk[0], 
				ez_peer->peer_nonce,
				entry->Addr, 
				ez_sec_info->self_nonce, 
				wdev->if_addr,
				&ptk[0], 
				LEN_PTK);
		}
		hex_dump("PTK", &ptk[0], LEN_PTK);
		ez_install_pairwise_key(pAd, entry, &ez_peer->this_band_info.pmk[0], &ptk[0], authenticator);
		return TRUE;
	}
	else {
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s - Install PTK failed?? This case shalln't happen....\n", 
			__FUNCTION__));
		return FALSE;
	}
}

#ifdef APCLI_SUPPORT
unsigned char ez_apcli_install_gtk(
	void *ad_obj,
	void *entry_obj)
{
	RTMP_ADAPTER *ad;
	MAC_TABLE_ENTRY *entry;
	struct wifi_dev *wdev;
	struct _ez_peer_security_info *ez_peer;

	ad = (RTMP_ADAPTER *)ad_obj;
	entry = (MAC_TABLE_ENTRY *)entry_obj;
	wdev = (struct wifi_dev *)entry->wdev;
	ez_peer = ez_peer_table_search_by_addr(wdev, entry->Addr);

	if (ez_peer) {
		ez_apcli_install_group_key(ad, ez_peer, entry);
		return TRUE;
	}
	else {
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s - Install PTK failed?? This case shalln't happen....\n", 
			__FUNCTION__));
		return FALSE;
	}
}

void ez_apcli_link_down(
	void *ad_obj,
	void *apcli_obj,
	unsigned char if_idx)
{
	RTMP_ADAPTER *ad;
	APCLI_STRUCT *apcli_entry;
	unsigned char wcid;
	struct wifi_dev *ap_wdev;

	ad = (RTMP_ADAPTER *)ad_obj;
	apcli_entry = (APCLI_STRUCT *)apcli_obj;
	wcid = apcli_entry->MacTabWCID;
	ap_wdev = &ad->ApCfg.MBSSID[if_idx].wdev;
	if (apcli_entry->wdev.enable_easy_setup
		&& VALID_UCAST_ENTRY_WCID(ad, wcid)) {
		STA_TR_ENTRY *tr_entry;
		tr_entry = &ad->MacTab.tr_entry[wcid];
		if (tr_entry->PortSecured == WPA_802_1X_PORT_SECURED) {
			//! ez_peer table delete will be taken care of from MAC table delete entry
			//ez_peer_table_delete(&apcli_entry->wdev, apcli_entry->wdev.bssid);

			/*
				Clear easy setup flag and CfgBssid for roaming.
			*/
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_ERROR, 
				("(%s) ApCli interface[%d] Clear easy setup flag and CfgBssid for roaming.\n", 
				__FUNCTION__, if_idx));
			apcli_entry->MlmeAux.support_easy_setup = FALSE;
			os_zero_mem(&apcli_entry->CfgApCliBssid[0], MAC_ADDR_LEN);
			apcli_entry->wdev.ez_security.first_scan = TRUE;
			EZ_CLEAR_CAP_CONNECTED(apcli_entry->wdev.ez_security.capability);
			EZ_UPDATE_CAPABILITY_INFO(ad, EZ_CLEAR_ACTION, CONNECTED, if_idx);
			
#ifdef SYSTEM_LOG_SUPPORT
			RTMPSendWirelessEvent(ad, IW_WH_EZ_MY_APCLI_DISCONNECTED, NULL, ap_wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
			RtmpOSWrielessEventSend(ap_wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_MY_APCLI_DISCONNECTED,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */

#ifdef NEW_CONNECTION_ALGO
		//	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_apcli_link_down: Link down, wait for 2 min on same channel %d\n", apcli_entry->wdev.wdev_idx));
			apcli_entry->wdev.ez_security.ez_scan_same_channel = TRUE;
			NdisGetSystemUpTime(&apcli_entry->wdev.ez_security.ez_scan_same_channel_timestamp);
#endif

		}
	}
}

void ez_apclient_info_action_frame(
	void *ad_obj,
	void *wdev_obj)
{
	unsigned char *out_buf;
	NDIS_STATUS NStatus;
	FRAME_ACTION_HDR frame;
	unsigned long frame_len;
	unsigned long tmp_len;
	RTMP_ADAPTER *ad;
	struct wifi_dev *wdev;

	out_buf = NULL;
	frame_len = 0;
	tmp_len = 0;
	ad = (RTMP_ADAPTER *)ad_obj;
	wdev = (struct wifi_dev *)wdev_obj;
	
	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("------> %s\n", __FUNCTION__));

	NStatus = MlmeAllocateMemory(ad, &out_buf);	/*Get an unused nonpaged memory */
	if (NStatus != NDIS_STATUS_SUCCESS) {
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			 ("%s(): allocate memory failed \n",
			 __FUNCTION__));
		return;
	}

	ActHeaderInit(ad, &frame.Hdr, wdev->bssid, wdev->if_addr, wdev->bssid);
	frame.Category = CATEGORY_PUBLIC;
	frame.Action = ACTION_WIFI_DIRECT;	// Action == 0x09, for vendor specific Action
	
	MakeOutgoingFrame(out_buf, &frame_len,
				  sizeof(FRAME_ACTION_HDR), &frame,
				  END_OF_ARGS);

	/*	Insert OUI Information	*/

	NdisMoveMemory(&out_buf[frame_len], mtk_oui, MTK_OUI_LEN);
	frame_len += MTK_OUI_LEN;

	/*
		Insert APCLI Action Information
	*/
	ez_insert_tlv(EZ_TAG_APCLI_ACTION_INFO, 
		NULL, 
		0, 
		out_buf + frame_len, 
		&tmp_len);
	frame_len += tmp_len;

	MiniportMMRequest(ad, QID_AC_BE, out_buf, frame_len);
	EZ_MEM_FREE(NULL, out_buf);
}
#endif /* APCLI_SUPPORT */

BOOLEAN ez_is_loop_formed(void *ad_obj,struct _ez_peer_security_info *ez_peer)
{
	int i;
	PRTMP_ADAPTER pAd = ad_obj;
	for (i=0; i<WDEV_NUM_MAX;i++)
	{
		struct wifi_dev *wdev = pAd->wdev_list[i];
		if(wdev && ez_is_ap_apcli(pAd->wdev_list[i]))
		{
			if (MAC_ADDR_EQUAL(wdev->if_addr,&ez_peer->device_info.network_weight[1])){
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("Loop Formed !!!\n"));
				return TRUE;
			}
		}
	}
	return FALSE;
}

void ez_process_action_frame(
	void *ad_obj,
	void *elem_obj)
{
	RTMP_ADAPTER *ad = (RTMP_ADAPTER *)ad_obj;
	RTMP_ADAPTER *ad2P4 = ad;
	MLME_QUEUE_ELEM *elem;
	MAC_TABLE_ENTRY *entry;
	struct wifi_dev *wdev;
	unsigned char capability0;
	unsigned char tag;
	EID_STRUCT *pEid;
#if defined (NEW_CONNECTION_ALGO) || defined (EZ_NETWORK_MERGE_SUPPORT)
	unsigned char data_len;
	int Length;
	int msg_len;
	struct _ez_peer_security_info *ez_peer;
	struct wifi_dev *ap_wdev;
	BOOLEAN check_for_weight = TRUE;
#endif
#ifdef EZ_NETWORK_MERGE_SUPPORT
	unsigned char *encrypted_data;
	unsigned char tag_count = 0;
	BOOLEAN group_id_updated = FALSE;
#endif	
#ifdef DUAL_CHIP
		PRTMP_ADAPTER adOthBand = NULL;
		if (!IS_SINGLE_CHIP_DBDC(ad)){
			adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
			if(adOthBand == NULL){
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
						("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
				ASSERT(FALSE);
			}
			
		}
#endif


	
	elem = (MLME_QUEUE_ELEM *)elem_obj;
	capability0 = 0;
	pEid = (EID_STRUCT *)&elem->Msg[LENGTH_802_11 + 2 + 3];

	entry = &ad->MacTab.Content[elem->Wcid];
	wdev = entry->wdev;
#ifdef DUAL_CHIP
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		if (ez_get_band(wdev)){
			ad2P4 = adOthBand;
		}
	}
#endif
#if defined (NEW_CONNECTION_ALGO) || defined (EZ_NETWORK_MERGE_SUPPORT)
	ap_wdev = &ad->ApCfg.MBSSID[wdev->func_idx].wdev; 
	msg_len = elem->MsgLen;
	Length = 0;
	Length += LENGTH_802_11;
		
	Length += 2; //! action and category
	Length += 3; //! MTK OUI	
	

	ez_peer = ez_peer_table_search_by_addr(wdev, entry->Addr);
	if (ez_peer == NULL)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("Action frame from a non connected peer???\n"));
		return;
	}
	
	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_ERROR, 
			("------> %s (%02x:%02x:%02x:%02x:%02x:%02x)\n", __FUNCTION__,PRINT_MAC(entry->Addr)));
	//! parse all the TAGS present in this action frame
	while ((Length + 2 + pEid->Len) <= msg_len){
#endif			
		if (wdev->enable_easy_setup &&
			NdisEqualMemory(&pEid->Octet[0], &mtk_oui[0], MTK_OUI_LEN)) {
			capability0 = pEid->Octet[MTK_OUI_LEN];
			tag = pEid->Octet[EZ_TAG_OFFSET];
			if ((capability0 & MTK_VENDOR_EASY_SETUP) &&
				(tag == EZ_TAG_APCLI_ACTION_INFO)) {
				EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
					("%s(): this entry(%02x:%02x:%02x:%02x:%02x:%02x) is apcli.\n", 
					__FUNCTION__, PRINT_MAC(entry->Addr)));
				entry->is_apcli = TRUE;
				RTMP_SEM_LOCK(&wdev->ez_security.ez_apcli_list_sem_lock);
				ez_insert_apcli_entry_by_mac(&wdev->ez_security.ez_apcli_list, entry->Addr);
				RTMP_SEM_UNLOCK(&wdev->ez_security.ez_apcli_list_sem_lock);
#ifdef SYSTEM_LOG_SUPPORT
				RTMPSendWirelessEvent(ad, IW_WH_EZ_MY_AP_HAS_APCLI, entry->Addr, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
				RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_MY_AP_HAS_APCLI,
							    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
#if defined (NEW_CONNECTION_ALGO) || defined (EZ_NETWORK_MERGE_SUPPORT)
				continue;
#endif
			} 
#ifdef EZ_NETWORK_MERGE_SUPPORT
			switch(tag)
			{
			case EZ_TAG_NOTIFY_ROAM:
				{
					//! Roaming is triggered somewhere in the tree, disallow all connections for 1 min.
					if(IS_SINGLE_CHIP_DBDC(ad)) {
						ez_update_connection_permission(ad, wdev, EZ_DISALLOW_ALL);
						ez_wait_for_connection_allow(&ad->ApCfg.MBSSID[0].wdev, ad->ez_roam_time * EZ_SEC_TO_MSEC);
					}
#ifdef DUAL_CHIP
					else
					{
								ez_update_connection_permission(ad, wdev, EZ_DISALLOW_ALL);
								if (!ez_get_band(wdev)){			
									ez_wait_for_connection_allow(&ad->ApCfg.MBSSID[0].wdev, ad->ez_roam_time * EZ_SEC_TO_MSEC);
								} else {
									ez_wait_for_connection_allow(&adOthBand->ApCfg.MBSSID[0].wdev, adOthBand->ez_roam_time * EZ_SEC_TO_MSEC);	
								}
					}
#endif
					ez_notify_roam(ad, ez_peer);
				}
			case EZ_TAG_DELAY_DISCONNECT_COUNT:
				{
					//! disconect due to beacon loss will be delayed by delay_disconnect_count number of times sent by peer
					wdev->ez_security.delay_disconnect_count = pEid->Octet[EZ_TAG_DATA_OFFSET];
					break;
				}
			case EZ_TAG_GROUP_ID_UPDATE:
				{
					//! flag to show if this action is triggered due to a group ID merge
					group_id_updated = pEid->Octet[EZ_TAG_DATA_OFFSET];
					//! flag to show that confg comaprision is reqyired
					tag_count++;
					break;
				}
			case EZ_TAG_OPEN_GROUP_ID:
				{
					NdisCopyMemory(ez_peer->open_group_id, &pEid->Octet[EZ_TAG_DATA_OFFSET], pEid->Octet[EZ_TAG_LEN_OFFSET]);
					ez_peer->open_group_id_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
					tag_count++;
					break;
				}
			case EZ_TAG_GROUP_ID:
				{
					data_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
					//! delete previous group ID corresponding to this peer
					if (ez_peer->group_id)
					{
						EZ_MEM_FREE(NULL, ez_peer->group_id);
					}
					//!allocate new memroy for new group ID
					EZ_MEM_ALLOC(NULL, &ez_peer->group_id, data_len);
					if (ez_peer->group_id) {
						os_zero_mem(ez_peer->group_id, data_len);
						encrypted_data = &pEid->Octet[EZ_TAG_DATA_OFFSET];
						/* AES */
						AES_Key_Unwrap(encrypted_data, data_len,
									   &ez_peer->sw_key[0], LEN_PTK_KEK, 
									   ez_peer->group_id, &ez_peer->group_id_len);	
		
						tag_count++;
					}
					break;
				}
				case EZ_TAG_PMK:
					{
						unsigned char *encrypted_data;
						unsigned char *pmk;
						unsigned int pmk_len;
						encrypted_data = &pEid->Octet[EZ_TAG_DATA_OFFSET];
						data_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
							
						EZ_MEM_ALLOC(NULL, &pmk, data_len+EZ_AES_KEY_ENCRYPTION_EXTEND);
						if (pmk) {
							/* AES */
							AES_Key_Unwrap(encrypted_data, data_len,
										   &ez_peer->sw_key[0], LEN_PTK_KEK, 
										   pmk, &pmk_len);
							os_zero_mem(&ez_peer->this_band_info.pmk[0], EZ_PMK_LEN);
							NdisCopyMemory(&ez_peer->this_band_info.pmk[0], pmk, EZ_PMK_LEN);
							EZ_MEM_FREE(NULL, pmk);
							tag_count++;
						}
						break;
					}
				case EZ_TAG_OTHER_BAND_PMK :
					{
						unsigned char *encrypted_data;
						unsigned char *pmk;
						unsigned int pmk_len;
						encrypted_data = &pEid->Octet[EZ_TAG_DATA_OFFSET];
						data_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
				
						EZ_MEM_ALLOC(NULL, &pmk, data_len+EZ_AES_KEY_ENCRYPTION_EXTEND);
						if (pmk) {
							/* AES */
							AES_Key_Unwrap(encrypted_data, data_len,
										   &ez_peer->sw_key[0], LEN_PTK_KEK, 
										   pmk, &pmk_len);
							os_zero_mem(&ez_peer->other_band_info.pmk[0], EZ_PMK_LEN);
							NdisCopyMemory(&ez_peer->other_band_info.pmk[0], pmk, EZ_PMK_LEN);
							EZ_MEM_FREE(NULL, pmk);
							tag_count++;
						}
						break;
					}
#if 0				
				case EZ_TAG_SSID :
					{
						ez_peer->this_band_info.shared_info.ssid_len  = pEid->Octet[EZ_TAG_LEN_OFFSET];
						NdisCopyMemory(ez_peer->this_band_info.shared_info.ssid, &pEid->Octet[EZ_TAG_DATA_OFFSET],ez_peer->this_band_info.shared_info.ssid_len );
						tag_count++;
						break;
					}
				case EZ_TAG_OTHER_BAND_SSID :
					{
						ez_peer->other_band_info.shared_info.ssid_len = pEid->Octet[EZ_TAG_LEN_OFFSET];
						NdisCopyMemory(ez_peer->other_band_info.shared_info.ssid, &pEid->Octet[EZ_TAG_DATA_OFFSET],ez_peer->other_band_info.shared_info.ssid_len);
						tag_count++;
						break;
					}
#endif				
				case EZ_TAG_DEVICE_INFO	:
					{
						NdisCopyMemory(&ez_peer->device_info, &pEid->Octet[EZ_TAG_DATA_OFFSET],sizeof(device_info_t));
						ez_hex_dump("EZ_TAG_NETWORK_WEIGHT",ez_peer->device_info.network_weight, NETWORK_WEIGHT_LEN);
						
						if (ez_is_loop_formed(ad, ez_peer))
						{
								ez_send_unicast_deauth(ad, ez_peer->mac_addr);
                            //todo: don't do deauth if only first bytes change between ) 0xE/0x0 (forced) but root same.
							break;
						}
						if (NdisEqualMemory(ez_peer->device_info.network_weight,wdev->ez_security.device_info.network_weight,NETWORK_WEIGHT_LEN))
						{
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("SameWtRx Disconnect\n"));
								ez_send_unicast_deauth(ad, ez_peer->mac_addr);
                            //todo: don't do deauth if only first bytes change between ) 0xE/0x0 (forced) but root same.
							break;
						}
						if (ez_peer->device_info.network_weight[0] & BIT(7))
						{
							EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("will update weight here\n"));
							//ez_peer->device_info.network_weight[0] &= ~(BIT(7));
							check_for_weight = FALSE;
							//update_and_push_weight(ad, ez_peer, ez_peer->device_info.network_weight);
						}  
                        
						tag_count++;
						
						break;
					}
				case EZ_TAG_INTERFACE_INFO :
					{
						interface_info_tag_t *shared_info = (interface_info_tag_t *)&pEid->Octet[EZ_TAG_DATA_OFFSET];
						unsigned char link_duplicate;
						link_duplicate = ez_peer->this_band_info.shared_info.link_duplicate;
						NdisCopyMemory(&ez_peer->this_band_info.shared_info,&shared_info[0], sizeof(interface_info_tag_t));
						NdisCopyMemory(&ez_peer->other_band_info.shared_info,&shared_info[1], sizeof(interface_info_tag_t));
						ez_peer->this_band_info.shared_info.link_duplicate = link_duplicate;
						ez_peer->other_band_info.shared_info.link_duplicate = link_duplicate;
						tag_count++;
					}
				}
#endif	
			}
#if defined (NEW_CONNECTION_ALGO) || defined (EZ_NETWORK_MERGE_SUPPORT)
		Length = Length + 2 + pEid->Len;  /* Eid[1] + Len[1]+ content[Len]*/
		pEid = (PEID_STRUCT)((unsigned char *)pEid + 2 + pEid->Len);
	
	}


	if (tag_count == EZ_UDATE_CONFIG_TAG_COUNT 
#ifdef NEW_CONNECTION_ALGO
                    && ad2P4->ApCfg.MBSSID[0].wdev.ez_security.weight_update_going_on == FALSE
#endif
         ) {
		
		push_and_update_config(ad, wdev,ez_peer,group_id_updated ? 0: check_for_weight, FALSE ,group_id_updated);
	}
#endif
	MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("<------ %s\n", __FUNCTION__));
}

void ez_prepare_security_key(
	void *wdev_obj,
	unsigned char *peer_addr,
	unsigned char authenticator)
{
	struct wifi_dev *wdev = wdev_obj;
	struct _ez_security *ez_sec_info;
	struct _ez_peer_security_info *ez_peer;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(wdev->sys_handle)){
		adOthBand = ((PRTMP_ADAPTER)(wdev->sys_handle))->pAdOthBand;
		if(adOthBand == NULL){
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		
	}
#endif

	wdev = (struct wifi_dev *)wdev_obj;
	ez_sec_info = &wdev->ez_security;

	ez_peer = ez_peer_table_search_by_addr(wdev_obj, peer_addr);
	if (ez_peer) {
		RTMP_SEM_LOCK(&wdev->ez_peer_table_lock);
		ez_gen_dh_private_key(ez_sec_info, ez_peer);
		ez_compute_dh_key(ez_sec_info, ez_peer);
		if (authenticator) {
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s - Configure Status = %d\n", 
				__FUNCTION__, ez_sec_info->configured_status));
			ez_get_sw_encrypted_key(ez_sec_info, ez_peer, wdev->if_addr, peer_addr);
			if (ez_sec_info->configured_status == EZ_UNCONFIGURED) {
				os_zero_mem(&ez_peer->this_band_info.pmk[0], EZ_PMK_LEN);
				NdisCopyMemory(&ez_peer->this_band_info.pmk[0], &ez_peer->dh_key[0], EZ_PMK_LEN);
				NdisCopyMemory(ez_sec_info->this_band_info.pmk, &ez_peer->dh_key[0], EZ_PMK_LEN);
				if(IS_SINGLE_CHIP_DBDC(wdev->sys_handle))
				{
					PRTMP_ADAPTER ad = wdev->sys_handle;
					struct wifi_dev *other_wdev = &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev;
					NdisCopyMemory(other_wdev->ez_security.this_band_info.pmk,ez_peer->dh_key,EZ_PMK_LEN);
					if (ad->ApCfg.BssidNum == 1 && ad->CommonCfg.dbdc_mode == 0)
					{
						struct wifi_dev *cli_wdev;
						struct _ez_security *cli_ez_sec_info;
						cli_wdev = &ad->ApCfg.ApCliTab[0].wdev;
						cli_ez_sec_info = &cli_wdev->ez_security;
						NdisCopyMemory(wdev->ez_security.other_band_info_backup.pmk,ez_peer->dh_key,EZ_PMK_LEN);
						NdisCopyMemory(cli_wdev->ez_security.other_band_info_backup.pmk, ez_peer->dh_key,PMK_LEN);
					}
				} 
#if DUAL_CHIP
				else {
					
					struct wifi_dev *other_wdev = &adOthBand->ApCfg.MBSSID[wdev->func_idx].wdev;
					NdisCopyMemory(other_wdev->ez_security.this_band_info.pmk,ez_peer->dh_key,EZ_PMK_LEN);
				}
#endif				
			}
			else {
				os_zero_mem(&ez_peer->this_band_info.pmk[0], EZ_PMK_LEN);
				NdisCopyMemory(&ez_peer->this_band_info.pmk[0], &wdev->SecConfig.PMK[0], EZ_PMK_LEN);
				NdisCopyMemory(ez_sec_info->this_band_info.pmk, &wdev->SecConfig.PMK[0], EZ_PMK_LEN);
				if(IS_SINGLE_CHIP_DBDC(wdev->sys_handle))
				{
					PRTMP_ADAPTER ad = wdev->sys_handle;
					struct wifi_dev *other_wdev = &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev;
					NdisCopyMemory(other_wdev->ez_security.this_band_info.pmk,other_wdev->SecConfig.PMK,EZ_PMK_LEN);
				}
#if DUAL_CHIP
				else {
					
					struct wifi_dev *other_wdev = &adOthBand->ApCfg.MBSSID[wdev->func_idx].wdev;
					NdisCopyMemory(other_wdev->ez_security.this_band_info.pmk,other_wdev->SecConfig.PMK,EZ_PMK_LEN);
				}
#endif						
				hex_dump("PMK", ez_sec_info->this_band_info.pmk, EZ_PMK_LEN);
			}
		}
		else
			ez_get_sw_encrypted_key(ez_sec_info, ez_peer, peer_addr, wdev->if_addr);
		RTMP_SEM_UNLOCK(&wdev->ez_peer_table_lock);
	}
}
void ez_show_interface_info(struct wifi_dev *wdev)
{
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Interface Activated = %d\n\n",
								wdev->ez_security.this_band_info.interface_activated));
	//if(wdev->ez_security.this_band_info.interface_activated)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("SSID: %s\n",
							wdev->ez_security.this_band_info.shared_info.ssid));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("SSID Len = %d\n",
							wdev->ez_security.this_band_info.shared_info.ssid_len));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Channel: %d\n", 
							wdev->ez_security.this_band_info.shared_info.channel_info.channel));
#ifdef EZ_PUSH_BW_SUPPORT
		//if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tHT-BW: %d, CFG:%d OPER:%d\n", 
								wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw,
								wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tVHT-BW: %d CFG:%d OPER:%d\n", 
								wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw,
								wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
		}
#else
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tHT-BW: CFG:%d OPER:%d\n", 
								wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tVHT-BW: CFG:%d OPER:%d\n", 
								wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
		}
#endif
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\tEXTCHA: %d CFG:%d OPER:%d\n", 
							wdev->ez_security.this_band_info.shared_info.channel_info.extcha,
							wlan_config_get_ext_cha(wdev),wlan_operate_get_ext_cha(wdev)));
		ez_hex_dump("ap_mac_addr", wdev->ez_security.this_band_info.shared_info.ap_mac_addr, MAC_ADDR_LEN);
		ez_hex_dump("cli_mac_addr", wdev->ez_security.this_band_info.shared_info.cli_mac_addr, MAC_ADDR_LEN);
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Cli Link Duplicate = %d\n",
							wdev->ez_security.this_band_info.shared_info.link_duplicate));
	
		ez_hex_dump("cli_peer_ap_addr", wdev->ez_security.this_band_info.cli_peer_ap_mac, MAC_ADDR_LEN);
		ez_hex_dump("PMK", wdev->ez_security.this_band_info.pmk, PMK_LEN);
#ifdef DOT11R_FT_SUPPORT
		if((wdev->wdev_type == WDEV_TYPE_AP) && (wdev->FtCfg.FtCapFlag.Dot11rFtEnable)){
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s::FtMdid =%c%c\n", __FUNCTION__,
									wdev->ez_security.this_band_info.shared_info.FtMdId[0],
									wdev->ez_security.this_band_info.shared_info.FtMdId[1]));
		}
#endif

	}
	
}
void ez_show_device_info(device_info_t ez_device_info)
{
	ez_hex_dump("Network Wt", (PUCHAR)ez_device_info.network_weight, NETWORK_WEIGHT_LEN);
	ez_hex_dump("WDL MAC", ez_device_info.weight_defining_link.peer_mac, MAC_ADDR_LEN);
	ez_hex_dump("NodeNumber", (void *)&ez_device_info.ez_node_number,sizeof(EZ_NODE_NUMBER));
}

void ez_show_information(
	void *wdev_obj)
{
	int j;
	struct wifi_dev *wdev = wdev_obj;
	struct _ez_security *ez_sec_info;

	if (wdev_obj) {
		wdev = (struct wifi_dev *)wdev_obj;
		ez_sec_info = &wdev->ez_security;
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("        -------------------------------        \n"));
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Easy Setup is %s.\n", wdev->enable_easy_setup ? "enabled":"disabled"));
		if (wdev->enable_easy_setup) {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Own Capability	 = 0x%04x\n", ez_sec_info->capability));
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Own Group ID	 = "));
			for (j=0; j<ez_sec_info->group_id_len; j++) {
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", ez_sec_info->group_id[j]));
			}
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Own DH PublicKey = "));
			for (j=0; j<EZ_RAW_KEY_LEN; j++) {
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", ez_sec_info->self_pke[j]));
			}
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Own Nonce = "));
			for (j=0; j<EZ_NONCE_LEN; j++) {
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", ez_sec_info->self_nonce[j]));
			}
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("WDEV PMK  = "));
			for (j=0; j<LEN_PMK; j++) {
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", wdev->SecConfig.PMK[j]));
			}
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("WDEV GTK  = "));
			for (j=0; j<LEN_MAX_GTK; j++) {
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x", wdev->SecConfig.GTK[j]));
			}
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("WDEV PSK  = %s\n", wdev->SecConfig.PSK));
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
			ez_show_peer_table_info(wdev_obj);
		}
	}
	else {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s - wdev_obj is NULL.\n", __FUNCTION__));
	}

	{
		PRTMP_ADAPTER pAd = wdev->sys_handle;
		for (j=0; j<WDEV_NUM_MAX; j++)
		{
			struct wifi_dev *wdev = pAd->wdev_list[j];
			if (wdev && ez_is_ap_apcli(pAd->wdev_list[j]))
			{
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("		------------------------------- 	   \n"));
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Info for wdev %d\n", wdev->wdev_idx));
				ez_show_interface_info(wdev);
				ez_show_device_info(wdev->ez_security.device_info);
			}
		}
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("        -------------------------------        \n"));
	}
}

/*
	If addr1 > addr2, return TRUE
	else return FALSE.
*/
static unsigned char ez_mac_addr_compare(
	unsigned char *addr1,
	unsigned char *addr2)
{
	int i;
	unsigned char higher_mac;

	higher_mac = FALSE;
	for (i = 0; i < 6; i++)
	{
		if (addr1[i] > addr2[i])
		{
			higher_mac = TRUE;
			break;
		}
		else if (addr1[i] < addr2[i])
			break;
	}
	return higher_mac;
}

#ifdef EZ_NETWORK_MERGE_SUPPORT
VOID ez_APMlmeBroadcastDeauthReqAction(
		IN PRTMP_ADAPTER pAd,
		IN MLME_QUEUE_ELEM *Elem)
{
	MLME_BROADCAST_DEAUTH_REQ_STRUCT	*pInfo;
    HEADER_802_11			Hdr;
    PUCHAR					pOutBuffer = NULL;
    NDIS_STATUS				NStatus;
    ULONG					FrameLen = 0;
    MAC_TABLE_ENTRY			*pEntry;
	UCHAR					apidx = 0;
    struct wifi_dev         *wdev;
	int wcid, startWcid;
	startWcid = 1;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s\n", __FUNCTION__));
	pInfo = (PMLME_BROADCAST_DEAUTH_REQ_STRUCT)Elem->Msg;
	if (!MAC_ADDR_EQUAL(pInfo->Addr,BROADCAST_ADDR))
	{
		return;
	}
	wdev = pInfo->wdev;
	if (!IS_EZ_SETUP_ENABLED(wdev))
	{
		EZ_DEBUG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				("%s: EZ Setup not enabled.\n", __FUNCTION__));
		return;
	}
	apidx = wdev->func_idx;
	for (wcid = startWcid; VALID_UCAST_ENTRY_WCID(pAd, wcid); wcid++)
	{
		pEntry = &pAd->MacTab.Content[wcid];
		if ((pEntry->wdev != wdev))
		{
			continue;
		}
		if (ez_peer_table_search_by_addr(pEntry->wdev, pEntry->Addr) != NULL)
		{
			continue;
		}
		RTMPSendWirelessEvent(pAd, IW_DEAUTH_EVENT_FLAG, pEntry->Addr, 0, 0);
		ApLogEvent(pAd, pInfo->Addr, EVENT_DISASSOCIATED);
		ez_hex_dump("DeleteEntryAddr",pEntry->Addr,6);
		
		MacTableDeleteEntry(pAd, wcid, pEntry->Addr);
#ifdef WH_EVENT_NOTIFIER
		{
			EventHdlr pEventHdlrHook = NULL;
			pEventHdlrHook = GetEventNotiferHook(WHC_DRVEVNT_STA_LEAVE);
			if(pEventHdlrHook && wdev)
				pEventHdlrHook(pAd, wdev, pEntry->Addr, Elem->Channel);
		}
#endif /* WH_EVENT_NOTIFIER */
	}
	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);
	if (NStatus != NDIS_STATUS_SUCCESS)
		return;
	EZ_DEBUG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			("AUTH - Send DE-AUTH req to %02x:%02x:%02x:%02x:%02x:%02x\n",
			PRINT_MAC(pInfo->Addr)));
	MgtMacHeaderInit(pAd, &Hdr, SUBTYPE_DEAUTH, 0, pInfo->Addr,
					pAd->ApCfg.MBSSID[apidx].wdev.if_addr,
					pAd->ApCfg.MBSSID[apidx].wdev.bssid);
	MakeOutgoingFrame(pOutBuffer,				&FrameLen,
					  sizeof(HEADER_802_11),	&Hdr,
					  2,						&pInfo->Reason,
					  END_OF_ARGS);
	MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
	MlmeFreeMemory( pOutBuffer);
}
#endif
#ifdef NEW_CONNECTION_ALGO
void ez_allocate_node_number(
	void *ad_obj,
	EZ_NODE_NUMBER *node_number,
	unsigned char if_index)
{
#ifdef DUAL_CHIP
	struct wifi_dev* wdev;
	PRTMP_ADAPTER ad = (PRTMP_ADAPTER)ad_obj;
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
		if(adOthBand == NULL){
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
	}
#endif
	//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s -->\n", __FUNCTION__));

		/*Node number of the device will be the mac address of the 2.4GHz AP*/
	node_number->path[0] = 0;
	NdisZeroMemory(node_number,sizeof(EZ_NODE_NUMBER));
	node_number->path_len = MAC_ADDR_LEN;
	if (IS_SINGLE_CHIP_DBDC(ad_obj))
		NdisCopyMemory(node_number->root_mac,((PRTMP_ADAPTER)(ad_obj))->ApCfg.MBSSID[0].wdev.bssid,MAC_ADDR_LEN);
#ifdef DUAL_CHIP
	else {
		wdev = &ad->ApCfg.MBSSID[0].wdev;
		if(wdev->channel <= 14)
			NdisCopyMemory(node_number->root_mac,((PRTMP_ADAPTER)(ad_obj))->ApCfg.MBSSID[0].wdev.bssid,MAC_ADDR_LEN);
		else
			NdisCopyMemory(node_number->root_mac, adOthBand->ApCfg.MBSSID[0].wdev.bssid,MAC_ADDR_LEN);	
	}
#endif
	ez_hex_dump("OwnNodeNumber", (PUCHAR)node_number, sizeof(EZ_NODE_NUMBER));
}

void ez_apcli_allocate_self_node_number(
	EZ_NODE_NUMBER *node_number, 
	void * entry_obj)
{
	PMAC_TABLE_ENTRY pEntry = (PMAC_TABLE_ENTRY)entry_obj;
	PRTMP_ADAPTER pAd = pEntry->wdev->sys_handle;
	UCHAR ifIndex = pEntry->wdev->func_idx;
	//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s -->\n", __FUNCTION__));

// TODO: Raghav: check if node number on other band is already given. if true then don't allocate another node number
	NdisZeroMemory(node_number,sizeof(EZ_NODE_NUMBER));
	NdisCopyMemory(node_number->root_mac,pEntry->bssid,MAC_ADDR_LEN);
	if (ez_get_band(pEntry->wdev) == BAND0)
	node_number->path[0] = pAd->ApCfg.ApCliTab[ifIndex].MlmeAux.Aid;
	else if (ez_get_band(pEntry->wdev) == BAND1)
		node_number->path[0] = (1<< 7) | (pAd->ApCfg.ApCliTab[ifIndex].MlmeAux.Aid);

	node_number->path_len = MAC_ADDR_LEN + 1;
	
	ez_hex_dump("OwnSelfNodeNumber", (PUCHAR)node_number, sizeof(EZ_NODE_NUMBER));
}

#if 0
void ez_adopt_new_node_number(
	void *ad_obj, 
	EZ_NODE_NUMBER *new_node_number, 
	unsigned char if_index)
{
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER)ad_obj;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s -->\n", __FUNCTION__));

	NdisCopyMemory(&wdev.ez_security.ez_node_number,new_node_number,sizeof(EZ_NODE_NUMBER));
}
#endif

struct _ez_peer_security_info * ez_get_duplicate_ez_peer(struct _ez_peer_security_info * ez_peer)
{
	return NULL;
}

static void ez_restore_node_number(EZ_NODE_NUMBER *ez_node_number)
{
	// delete the last entry in the node number to get the parent's node number
	ez_node_number->path[ez_node_number->path_len -6 -1] = 0;
	ez_node_number->path_len-=1;
	
}

void ez_allocate_node_number_sta(
	void *ad_obj,
	unsigned char if_index,
	void * entry_obj,
	BOOLEAN is_forced)
{
	PMAC_TABLE_ENTRY pEntry = (PMAC_TABLE_ENTRY)entry_obj;
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER)ad_obj;
	EZ_NODE_NUMBER *own_node_number = &pAd->ApCfg.MBSSID[if_index].wdev.ez_security.device_info.ez_node_number;
	struct wifi_dev *wdev = pEntry->wdev;
	struct _ez_peer_security_info *ez_peer = ez_peer_table_search_by_addr(wdev,pEntry->Addr);
	
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s -->\n", __FUNCTION__));

	if (ez_peer == NULL) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s: ez_peer is NULL", __FUNCTION__)); 
		return;
	}

	
	//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Node number for STA %d =\n", pEntry->wcid));
	ez_hex_dump("PeerMac",ez_peer->mac_addr,6);

 #if 1
 	if (is_forced == FALSE && ez_peer->this_band_info.shared_info.link_duplicate)
	{
		struct _ez_peer_security_info *first_ez_peer = ez_get_other_band_ez_peer(wdev, ez_peer);
		if (first_ez_peer) {
			NdisCopyMemory(&ez_peer->device_info.ez_node_number,&first_ez_peer->device_info.ez_node_number,sizeof(EZ_NODE_NUMBER));
			ez_hex_dump("PeerNodeNum:", (PUCHAR)&ez_peer->device_info.ez_node_number, sizeof(EZ_NODE_NUMBER));
			return;
		}
		else {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_allocate_node_number_sta: BUG:is duplicate link but first peer missing. "));
		}
	}
#endif
	RTMP_SEM_LOCK(&wdev->ez_peer_table_lock);

	NdisZeroMemory(&ez_peer->device_info.ez_node_number,sizeof(EZ_NODE_NUMBER));
	NdisCopyMemory(ez_peer->device_info.ez_node_number.root_mac,own_node_number->root_mac,own_node_number->path_len);
	if (IS_ENTRY_APCLI(pEntry))  // if allocating for the AP : for AP node number , 6th bit will be set, for 5Ghz device, 7th bit will be set
	{
		if (ez_get_band(pEntry->wdev) == BAND0)
		{
			ez_peer->device_info.ez_node_number.path[own_node_number->path_len -MAC_ADDR_LEN] = (1<<6) | (ez_peer->ez_peer_table_index+1);
		}
		else if (ez_get_band(pEntry->wdev) == BAND1)
		{
			ez_peer->device_info.ez_node_number.path[own_node_number->path_len -MAC_ADDR_LEN] = (3<<6) | (ez_peer->ez_peer_table_index+1);
		}
	}
	else {  // allocating node number for the connected clients (APCLI entries)
		if (ez_get_band(pEntry->wdev) == BAND0)
		{
			ez_peer->device_info.ez_node_number.path[own_node_number->path_len -MAC_ADDR_LEN] = (ez_peer->ez_peer_table_index+1);
		}
		else if (ez_get_band(pEntry->wdev) == BAND1)
		{
			ez_peer->device_info.ez_node_number.path[own_node_number->path_len -MAC_ADDR_LEN] = (1<<7) | (ez_peer->ez_peer_table_index+1);
		}
	}
	ez_peer->device_info.ez_node_number.path_len = own_node_number->path_len + 1;

	RTMP_SEM_UNLOCK(&wdev->ez_peer_table_lock);

	ez_hex_dump("PeerNodeNum:", (PUCHAR)&ez_peer->device_info.ez_node_number, sizeof(EZ_NODE_NUMBER));
}

/*check whether peer node is child node of the own node*/
BOOLEAN ez_is_child_node(
	EZ_NODE_NUMBER own_node_number, 
	EZ_NODE_NUMBER peer_node_number)
{
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s -->\n", __FUNCTION__));

	ez_hex_dump("PeerNodeNum", (PUCHAR)&peer_node_number, sizeof(EZ_NODE_NUMBER));
	if ((MAC_ADDR_EQUAL(own_node_number.root_mac,peer_node_number.root_mac))
		&& NdisEqualMemory(own_node_number.path,peer_node_number.path ,own_node_number.path_len - MAC_ADDR_LEN))
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("TRUE\n"));
		return TRUE;
	}
	else
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("FALSE\n"));
		return FALSE;
	}
}
BOOLEAN ez_is_same_open_group_id(struct wifi_dev *wdev, BSS_ENTRY * pBss)
{
	/*connection to third party AP*/
	if(pBss->support_easy_setup == FALSE){
		return TRUE;
	}
	if (wdev->ez_security.open_group_id_len == pBss->open_group_id_len
		&& NdisEqualMemory(wdev->ez_security.open_group_id,pBss->open_group_id,pBss->open_group_id_len)) {
	        ez_hex_dump("OwnOpenGroupID",wdev->ez_security.open_group_id, wdev->ez_security.open_group_id_len);
	        ez_hex_dump("PeerOpenGroupID",pBss->open_group_id, pBss->open_group_id_len);
		//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" TRUE\n"));
		return TRUE;
	}
	else
		//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_is_same_open_group_id: FALSE\n"));
		return FALSE;
}

BOOLEAN ez_is_other_band_connection_to_same_bss(struct wifi_dev *wdev, BSS_ENTRY *pBss)
{
	PRTMP_ADAPTER pAd = wdev->sys_handle;
	APCLI_STRUCT *other_band_apcli_entry;
#ifdef DUAL_CHIP
			PRTMP_ADAPTER adOthBand = NULL;
			if (!IS_SINGLE_CHIP_DBDC(pAd)){
				adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
				if(adOthBand == NULL){
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
							("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
					ASSERT(FALSE);
				}
				other_band_apcli_entry = &adOthBand->ApCfg.ApCliTab[wdev->func_idx];
			}
			else { 
#endif
			other_band_apcli_entry = &pAd->ApCfg.ApCliTab[wdev->func_idx ^ 1];
#ifdef DUAL_CHIP
	}
#endif

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s(funcIdx=%d) wdev_idx=%d -->\n", __FUNCTION__, wdev->func_idx, wdev->wdev_idx));
	if(other_band_apcli_entry->Valid && MAC_ADDR_EQUAL(other_band_apcli_entry->wdev.bssid,pBss->beacon_info.other_ap_mac) )
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("TRUE\n"));
		return TRUE;
	}
	else
	{	
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%d \n",other_band_apcli_entry->Valid));
		ez_hex_dump("OtherbandBssid",other_band_apcli_entry->wdev.bssid,6);
		ez_hex_dump("Bss",pBss->beacon_info.other_ap_mac,6);
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("FALSE"));
		return FALSE;
	}
}
#if 1
char best_ap_rssi_threshld[10] = {-110, -110, -110, -110, -110};
char best_ap_rssi_threshld_max = 1;
void increment_best_ap_rssi_threshold(struct _ez_security *ez_security)
{
	ez_security->best_ap_rssi_threshold++;
	if (ez_security->best_ap_rssi_threshold > BEST_AP_RSSI_THRESHOLD_LEVEL_MAX)
	{
		ez_security->best_ap_rssi_threshold = BEST_AP_RSSI_THRESHOLD_LEVEL_MAX; 
	}
	
	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s:: ez_security->best_ap_rssi_threshold = %d\n", __FUNCTION__, ez_security->best_ap_rssi_threshold));
}

BOOLEAN check_best_ap_rssi_threshold(struct _ez_security *ez_security, BSS_ENTRY *bss_entry)
{
	if(bss_entry->Rssi >= best_ap_rssi_threshld[ez_security->best_ap_rssi_threshold - 1])
	{
		return TRUE;
	}
	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s:: RSSI = %d, Threshold = %d, REJECT CONNECTION\n", __FUNCTION__,
		bss_entry->Rssi, best_ap_rssi_threshld[ez_security->best_ap_rssi_threshold - 1]));
	return FALSE;
}
#endif
BOOLEAN ez_apcli_search_best_ap_configured(
	void *ad_obj,
	void *out_table_obj,
	void *apcli_entry_obj)
{
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER)ad_obj;
	PBSS_TABLE out_table = (PBSS_TABLE)out_table_obj;
	PAPCLI_STRUCT apcli_entry = (PAPCLI_STRUCT)apcli_entry_obj;
	struct wifi_dev *wdev = &apcli_entry->wdev;
	BOOLEAN found_ap=FALSE;
	char rssi_threshold = wdev->ez_security.rssi_threshold;
	BSS_ENTRY *bss_entry = NULL;
	unsigned long bss_idx;
	
	UCHAR i=0;
#ifdef EZ_NETWORK_MERGE_SUPPORT	
	BSS_ENTRY *temp_bss_entry = NULL;
UCHAR temp_bss_index = 0;
	enum_group_merge_action_t group_merge_action;
#endif	
	struct wifi_dev *ap_wdev = &pAd->ApCfg.MBSSID[wdev->func_idx].wdev; /* apcli0 find ra0, apcli1 find ra1, etc. */
#ifdef EZ_ROAM_SUPPORT
	BOOLEAN do_roam = FALSE;
#endif
	ULONG now;
//	static UINT32 scan_delay = 0;

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s(apcli%d) -->\n", __FUNCTION__, wdev->func_idx));
	apcli_entry->MlmeAux.support_easy_setup = FALSE;

	if (wdev->ez_security.first_scan)
	{
		wdev->ez_security.first_scan = FALSE;
		
		MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("(%s) Scan again.\n", __FUNCTION__));
		wdev->ez_security.ez_scan = TRUE;
		if (wdev->ez_security.ez_scan_same_channel == TRUE)
			wdev->ez_security.scan_one_channel = TRUE;
		ApSiteSurvey_by_wdev(pAd, NULL, SCAN_ACTIVE, FALSE, wdev);
		return FALSE;
//		goto found;
	}

// TODO: Raghav : add channel check. if forced by user. and scan only on that channel
	if (wdev->ez_security.ez_apcli_force_ssid_len != 0)
	{
		if(out_table->BssNr == 0){ 
			/*
				Find all matching BSS in the lastest SCAN result (inBssTab)
				Sort by RSSI order
			*/
			BssTableSsidSort(pAd, wdev, out_table,
					 (PCHAR) wdev->ez_security.ez_apcli_force_ssid, wdev->ez_security.ez_apcli_force_ssid_len);
			BssTableSortByRssi(out_table, FALSE);
		}
	}
	else if(out_table->BssNr == 0){ /* no easy devices detected yet*/
			BssTableInit(out_table);
#ifdef EZ_DUAL_BAND_SUPPORT
				{
					interface_info_t other_band_info;
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("get other_band_info\n"));
					if (ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info)){
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("get other CLI peer\n"));
						ez_hex_dump("other_band_info.cli_peer_ap_mac", other_band_info.cli_peer_ap_mac, 6);
						if (!MAC_ADDR_EQUAL(other_band_info.cli_peer_ap_mac, ZERO_MAC_ADDR)
							&& ! wdev->ez_security.internal_force_connect_bssid_timeout
							&& MAC_ADDR_EQUAL(wdev->ez_security.ez_apcli_force_bssid,ZERO_MAC_ADDR)
							&& MAC_ADDR_EQUAL(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR)
							&& other_band_info.non_easy_connection == FALSE)
						{
							
							struct _ez_peer_security_info * ez_other_cli_peer_ap;
							PRTMP_ADAPTER ad = wdev->sys_handle;
#ifdef DUAL_CHIP
							PRTMP_ADAPTER adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
							if (!IS_SINGLE_CHIP_DBDC(wdev->sys_handle)){
								if(adOthBand == NULL) {
								EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
								("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
									ASSERT(FALSE);
								}		
							}	
#endif
							if (IS_SINGLE_CHIP_DBDC(wdev->sys_handle)){
								struct wifi_dev *other_band_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev;
								ez_other_cli_peer_ap = ez_peer_table_search_by_addr(other_band_wdev, other_band_info.cli_peer_ap_mac);
							}
#ifdef DUAL_CHIP
							else {
								struct wifi_dev *other_band_wdev = &adOthBand->ApCfg.ApCliTab[0].wdev;
								ez_other_cli_peer_ap = ez_peer_table_search_by_addr(other_band_wdev, other_band_info.cli_peer_ap_mac);
							}
#endif
							if ( ez_other_cli_peer_ap != NULL
								&& !MAC_ADDR_EQUAL(other_band_info.cli_peer_ap_mac, ZERO_MAC_ADDR)){

								ez_hex_dump("Other Band CLI connected to", other_band_info.cli_peer_ap_mac, MAC_ADDR_LEN);

								ez_hex_dump("will attempt connection to",ez_other_cli_peer_ap->other_band_info.shared_info.ap_mac_addr, MAC_ADDR_LEN);
															
								bss_idx = BssTableSearchWithBssId(&pAd->ScanTab,ez_other_cli_peer_ap->other_band_info.shared_info.ap_mac_addr,0);
								if (bss_idx == BSS_NOT_FOUND)
								{
									found_ap = FALSE;
									if (!wdev->ez_security.internal_force_connect_bssid) {
										NdisGetSystemUpTime(&wdev->ez_security.force_connect_bssid_time_stamp);
										wdev->ez_security.internal_force_connect_bssid = TRUE;
									}

									goto found;
								} else {
									BSS_ENTRY *pBss = &pAd->ScanTab.BssEntry[bss_idx];
								
									bss_entry = &out_table->BssEntry[0];
									NdisMoveMemory(bss_entry, pBss, sizeof(BSS_ENTRY)); // Don't do out_table->BssNr++ as this is to be tried immediately;

									found_ap = TRUE;
									if (!wdev->ez_security.internal_force_connect_bssid) {
										NdisGetSystemUpTime(&wdev->ez_security.force_connect_bssid_time_stamp);
										wdev->ez_security.internal_force_connect_bssid = TRUE;
									}
									goto found;

								}
							}
						} else {
							wdev->ez_security.internal_force_connect_bssid = FALSE;
						}
					}
				}
#endif
	
			for (i = 0; i < pAd->ScanTab.BssNr; i++) 
			{
				bss_entry = &pAd->ScanTab.BssEntry[i];
#if 1
				if (!check_best_ap_rssi_threshold(&apcli_entry->wdev.ez_security, bss_entry))
				{
					continue;
				}
#endif
#ifdef EZ_NETWORK_MERGE_SUPPORT
				group_merge_action = is_group_merge_candidate(bss_entry, temp_bss_entry, &apcli_entry->wdev.ez_security);
				//ez_hex_dump("BSS_MAC",bss_entry->Bssid,MAC_ADDR_LEN);
				switch (group_merge_action)
					{
						case EXIT_SWITCH_NOT_GROUP_MERGE:
							break;
						case TERMINATE_LOOP_MULTIPLE_AP_FOUND:
							found_ap = FALSE;
							goto found;
							break;
						case TERMINATE_LOOP_TARGET_AP_FOUND:
						
							if (((WMODE_2G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel <= 14)) 
									|| (WMODE_5G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel> 14)))
									&& (!ez_is_weight_same(wdev->ez_security.device_info.network_weight,bss_entry->beacon_info.network_weight)))
							{
								BSS_ENTRY *pBss = &pAd->ScanTab.BssEntry[i];
								
								bss_entry = &out_table->BssEntry[0];
								NdisMoveMemory(bss_entry, pBss, sizeof(BSS_ENTRY)); // Don't do out_table->BssNr++ as this is to be tried immediately;							
								found_ap = TRUE;
								goto found;
							} 
							break;
						case CONTINUE_LOOP_TARGET_AP_FOUND:
							if (((WMODE_2G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel <= 14)) 
									|| (WMODE_5G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel > 14)))
									&&  !ez_is_weight_same(wdev->ez_security.device_info.network_weight,bss_entry->beacon_info.network_weight)){
								BSS_ENTRY *pBss = &pAd->ScanTab.BssEntry[i];
								
								temp_bss_entry = &out_table->BssEntry[0];
								NdisMoveMemory(temp_bss_entry, pBss, sizeof(BSS_ENTRY)); // Don't do out_table->BssNr++ as this is to be tried immediately;

								temp_bss_index = i;
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("temp bss_entry = %s\n", temp_bss_entry->Ssid));
							}
							else{
								temp_bss_entry = NULL;
							}
							continue;
							break;
						case CONTINUE_LOOP:
							continue;
							break;
					}
				
#endif
#ifdef DBDC_MODE
				if(pAd->CommonCfg.dbdc_mode){
					if( ( WMODE_2G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel <= 14) ) ||
						( WMODE_5G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel > 14) ) )
					{
						// Own band network
					}
					else{
						//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
						//("%s(line.%d) - Ignore other band network.\n", 
						//__FUNCTION__, __LINE__));
						continue;
					}
				}
#endif
				if (ez_is_same_open_group_id(wdev, bss_entry) == FALSE) {
					continue;
				}
#ifdef EZ_ROAM_SUPPORT
				if (!MAC_ADDR_EQUAL(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid, ZERO_MAC_ADDR))
				{
					if (NdisEqualMemory(bss_entry->Bssid,wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,MAC_ADDR_LEN))
					{
						BSS_ENTRY *pBss = &pAd->ScanTab.BssEntry[i];
						if (ez_is_weight_same(wdev->ez_security.device_info.network_weight,bss_entry->beacon_info.network_weight)
							&& ez_is_other_band_connection_to_same_bss(wdev,bss_entry) == FALSE)
						{
							EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("Roam AP found but wt is same. Wait for some time\n"));
							continue;
						}
						
						bss_entry = &out_table->BssEntry[0];
						NdisMoveMemory(bss_entry, pBss, sizeof(BSS_ENTRY)); // Don't do out_table->BssNr++ as this is to be tried immediately;

						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Roam ssid =%s\n", bss_entry->Ssid));
						ez_hex_dump("Roam BSSID", wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid, MAC_ADDR_LEN);
						found_ap = TRUE;
						do_roam = TRUE;
						goto found;
					}
					continue;
				}
#endif
				if (!ez_is_weight_same(wdev->ez_security.device_info.network_weight,bss_entry->beacon_info.network_weight) 
								|| ez_is_other_band_connection_to_same_bss(wdev,bss_entry))
				{
					BSS_ENTRY *pOutBss = &out_table->BssEntry[out_table->BssNr];
					interface_info_t other_band_info;
					NdisZeroMemory(&other_band_info,sizeof(interface_info_t));
					ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info);
						if(!MAC_ADDR_EQUAL(other_band_info.cli_peer_ap_mac, ZERO_MAC_ADDR))
						{
							if(other_band_info.non_easy_connection
								&& (!bss_entry->support_easy_setup))
							{
							 	/* If other band connected to third party, will allow this band to connect only with third party */
								{
									NdisMoveMemory(pOutBss, bss_entry, sizeof(BSS_ENTRY));
									out_table->BssNr++;
								}
							}
							else /* Easy setup Enabled Devices */
							{
								/* If other band connected to Easy Device, will allow this band to connect only with Easy Device */
								if((!other_band_info.non_easy_connection)
									&& (bss_entry->support_easy_setup))
								{
									NdisMoveMemory(pOutBss, bss_entry, sizeof(BSS_ENTRY));
									out_table->BssNr++;
								}
							}
						}
					else 
					{
						NdisMoveMemory(pOutBss, bss_entry, sizeof(BSS_ENTRY));
						out_table->BssNr++;
					}
				}
			}
#ifdef EZ_NETWORK_MERGE_SUPPORT
			if (temp_bss_entry != NULL){
				bss_entry = temp_bss_entry;
				i = temp_bss_index; // no use as such

				found_ap = TRUE;
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("setting bss_entry here, %s\n", bss_entry->Ssid));
				goto found;
			}
#endif
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("number of valid entries = %d\n", out_table->BssNr));
			BssTableSortByRssi(out_table, FALSE);
			//Raghav: sort by a different algo
		}
	

#ifdef DBG
	for (i=0; i<out_table->BssNr; i++) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("[%d] %02x:%02x:%02x:%02x:%02x:%02x RSSI=%d EZ=%d Attempted= %x\n", i, 
			out_table->BssEntry[i].Bssid[0],
			out_table->BssEntry[i].Bssid[1],
			out_table->BssEntry[i].Bssid[2],
			out_table->BssEntry[i].Bssid[3],
			out_table->BssEntry[i].Bssid[4],
			out_table->BssEntry[i].Bssid[5],
			out_table->BssEntry[i].Rssi, out_table->BssEntry[i].support_easy_setup,out_table->BssEntry[i].bConnectAttemptFailed));
	}
	
	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
		("%s(line.%d) - apcli_entry->CfgSsid-%s, apcli_entry->Ssid-%s\n", 
		__FUNCTION__, __LINE__,apcli_entry->CfgSsid, apcli_entry->Ssid));
#endif
	if (!MAC_ADDR_EQUAL(wdev->ez_security.ez_apcli_force_bssid, ZERO_MAC_ADDR))
	{
		/*if force bssid is given, then don't connect to any other bssid.*/
		for (i=0; i<out_table->BssNr; i++) {
			
			if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
			}
			bss_entry = &out_table->BssEntry[i];
			if (MAC_ADDR_EQUAL(wdev->ez_security.ez_apcli_force_bssid,bss_entry->Bssid)) {
				found_ap = TRUE;
				COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("%s(line.%d) - Find peer with force bssid.\n", 
					__FUNCTION__, __LINE__));
				break;
			}
		}
		goto found;
	}

	/*
		Select normal ap which doesn't support easy setup and matches the SSID and RSSI threshold
	*/
	for (i = 0; i < out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (bss_entry->Rssi >= rssi_threshold && (!bss_entry->support_easy_setup)
			&& (apcli_entry->CfgSsidLen != 0 && SSID_EQUAL(apcli_entry->CfgSsid, apcli_entry->CfgSsidLen,bss_entry->Ssid, bss_entry->SsidLen))
			&& IS_CIPHER_CCMP128(bss_entry->PairwiseCipher)
			&& IS_CIPHER_CCMP128(bss_entry->GroupCipher)
			&& IS_AKM_WPA2PSK(bss_entry->AKMMap)){
			found_ap = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			hex_dump("ApcliSsid",apcli_entry->Ssid,apcli_entry->SsidLen );
			hex_dump("BssSsid",bss_entry->Ssid,bss_entry->SsidLen);
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found ap.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}
	/*Find configured AP with internet, having the same SSID.*/
	for (i = 0; i < out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability) &&
			EZ_GET_CAP_INTERNET(bss_entry->easy_setup_capability) &&
			SSID_EQUAL(apcli_entry->CfgSsid, apcli_entry->CfgSsidLen,bss_entry->Ssid, bss_entry->SsidLen)
			//SSID_EQUAL(apcli_entry->Ssid, apcli_entry->SsidLen,bss_entry->Ssid, bss_entry->SsidLen)
			){
			found_ap = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found ap.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}

	/*Find configured AP with Internet. SSID can be different.*/
	for (i = 0; i < out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability) &&
			EZ_GET_CAP_INTERNET(bss_entry->easy_setup_capability)
			){
			found_ap = TRUE;
			apcli_entry->MlmeAux.support_easy_setup = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found ap.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}

	/*Find configured AP, having the same SSID.*/
	for (i = 0; i < out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability) &&
			SSID_EQUAL(apcli_entry->CfgSsid, apcli_entry->CfgSsidLen,bss_entry->Ssid, bss_entry->SsidLen)
			//SSID_EQUAL(apcli_entry->Ssid, apcli_entry->SsidLen,bss_entry->Ssid, bss_entry->SsidLen)
		){
			found_ap = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found ap.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}

	/*Find configured AP. SSID can be different.*/
	for (i = 0; i < out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)
			){
			found_ap = TRUE;
			apcli_entry->MlmeAux.support_easy_setup = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found ap.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}

	/*
		Select normal ap with RSSI less than threshold which doesn't support easy setup and matches the SSID.
	*/
	for (i = 0; i < out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if ((!bss_entry->support_easy_setup)
			&& (apcli_entry->CfgSsidLen != 0 && SSID_EQUAL(apcli_entry->CfgSsid, apcli_entry->CfgSsidLen,bss_entry->Ssid, bss_entry->SsidLen))
			&& IS_CIPHER_CCMP128(bss_entry->PairwiseCipher)
			&& IS_CIPHER_CCMP128(bss_entry->GroupCipher)
			&& IS_AKM_WPA2PSK(bss_entry->AKMMap)){
			found_ap = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			hex_dump("ApcliSsid",apcli_entry->Ssid,apcli_entry->SsidLen );
			hex_dump("BssSsid",bss_entry->Ssid,bss_entry->SsidLen);
			EZ_DEBUG(DBG_CAT_MLME, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found ap.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}
found:
	if((bss_entry!=NULL) && (found_ap == TRUE)){
		// for single chip DBDC operation, as common scan table is present for both band interfaces,
		// and as there is possbility for scan table update/clear,
		// do safety check that bss entry is having valid values
		if(MAC_ADDR_EQUAL(bss_entry->Bssid, ZERO_MAC_ADDR)){
			EZ_DEBUG(DBG_CAT_MLME, CATCLIENT_APCLI, DBG_LVL_ERROR,("(%s) Chosen BSS entry not Valid\n",__FUNCTION__));
			found_ap = FALSE;
			out_table->BssNr = 0;
		}
	}

	if (!found_ap) {
		EZ_DEBUG(DBG_CAT_MLME, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("(%s) No matching AP.(apcli_entry_count=%d)\n", __FUNCTION__, ap_wdev->ez_security.ez_apcli_list.size));
#ifndef EZ_NETWORK_MERGE_SUPPORT
		wdev->ez_security.scan_one_channel = TRUE;
#endif
		apcli_entry->MlmeAux.attempted_candidate_index = EZ_INDEX_NOT_FOUND;

		if(!wdev->ez_security.ez_scan_timer_running){
			ULONG time;
			UINT32 random_time = (UINT32)(RandomByte(pAd)*100);
			if(wdev->ez_security.internal_force_connect_bssid == TRUE)
			{
				EZ_DEBUG(DBG_CAT_MLME, CATCLIENT_APCLI, DBG_LVL_TRACE, 
					("Duplicate Connection... Scan after  2 seconds\n"));
				RTMPSetTimer(&wdev->ez_security.ez_scan_timer, 2000);
				wdev->ez_security.ez_scan_timer_running = TRUE;
				//ApSiteSurvey_by_wdev(pAd, NULL, SCAN_ACTIVE, FALSE, wdev);
			}
			else if (wdev->ez_security.ez_scan_same_channel == TRUE)
			{
			
			if (!MAC_ADDR_EQUAL(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid, ZERO_MAC_ADDR))
			{
				if (wdev->ez_security.ez_roam_info.roam_channel != 0 && 
					wdev->channel != wdev->ez_security.ez_roam_info.roam_channel)
				{
					/*Move to the bss channel if not already set.*/
					EZ_DEBUG(DBG_CAT_MLME, CATCLIENT_APCLI, DBG_LVL_ERROR, 
						("Roam: Curr Chan=%d RoamChannel=%d\n",wdev->channel,wdev->ez_security.ez_roam_info.roam_channel));
					ap_wdev->ez_security.do_not_restart_interfaces = 1;
					rtmp_set_channel(wdev->sys_handle,ap_wdev, wdev->ez_security.ez_roam_info.roam_channel);
					ap_wdev->ez_security.do_not_restart_interfaces = 0;
				}

			}
				wdev->ez_security.scan_one_channel = TRUE;
				RTMPSetTimer(&wdev->ez_security.ez_scan_timer, EZ_MAX_SCAN_TIME_OUT/2);
				wdev->ez_security.ez_scan_timer_running = TRUE;
			}
			else
			{
				wdev->ez_security.scan_one_channel = FALSE;
			if (random_time > EZ_MAX_SCAN_TIME_OUT)
				random_time = EZ_MAX_SCAN_TIME_OUT;
				wdev->ez_security.ez_scan_delay +=2000;
				if (wdev->ez_security.ez_scan_delay > (wdev->ez_security.ez_max_scan_delay + EZ_SCAN_DELAY_WAIT))
					wdev->ez_security.ez_scan_delay = wdev->ez_security.ez_max_scan_delay;
				if(wdev->ez_security.ez_scan_delay > EZ_SCAN_DELAY_WAIT)
					time = random_time + wdev->ez_security.ez_scan_delay - EZ_SCAN_DELAY_WAIT;
				else
					time = random_time;
				RTMPSetTimer(&wdev->ez_security.ez_scan_timer, time);
				EZ_DEBUG(DBG_CAT_MLME, CATCLIENT_APCLI, DBG_LVL_TRACE,("Scan Delay Timeout = %d\n",(UINT32)time));
			wdev->ez_security.ez_scan_timer_running = TRUE;
		}
		}

#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(pAd, IW_WH_EZ_CONFIGURED_AP_SEARCHING, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_CONFIGURED_AP_SEARCHING,
							NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
		return FALSE;
	}
	else {
#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(pAd, IW_WH_EZ_CONFIGURED_AP_FOUND, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_CONFIGURED_AP_FOUND,
							NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
		/*if we need to create an easy setup connection, then adopt the bss parameters*/
		ez_hex_dump("FoundAP MAC", bss_entry->Bssid, MAC_ADDR_LEN);
		wdev->ez_security.ez_scan_delay = 0;

		if (bss_entry->support_easy_setup == TRUE)
		{
			apcli_entry->MlmeAux.support_easy_setup = TRUE;
		}
		COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
		NdisZeroMemory(apcli_entry->CfgSsid, MAX_LEN_OF_SSID);
		NdisMoveMemory(apcli_entry->CfgSsid, bss_entry->Ssid, bss_entry->SsidLen);
		apcli_entry->CfgSsidLen = bss_entry->SsidLen;
		wdev->SecConfig.AKMMap = bss_entry->AKMMap;
		wdev->SecConfig.PairwiseCipher = bss_entry->PairwiseCipher;
		wdev->SecConfig.GroupCipher = bss_entry->GroupCipher;
#ifdef EZ_NETWORK_MERGE_SUPPORT
		if(wdev->ez_security.internal_force_connect_bssid == TRUE)
		{
			if (wdev->channel != bss_entry->Channel)
			{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("stale scan list %d %d!!!\n",wdev->channel,bss_entry->Channel));
				//ASSERT(FALSE);
				ez_initiate_new_scan(pAd);
				return FALSE;
			}

		}
		//! adjust APCLI's operating bandwidth to that of peer
		ez_ApCliAutoConnectBWAdjust(pAd, wdev, bss_entry);
								
		ez_ApCliAutoConnectBWAdjust(pAd, ap_wdev, bss_entry);

#ifdef EZ_NETWORK_MERGE_SUPPORT
#ifdef EZ_DUAL_BAND_SUPPORT
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_apcli_search_best_ap_configured\nAPCLI=> CurrChannel: %d, TarChannel: %d\n", 
			wdev->ez_security.this_band_info.shared_info.channel_info.channel,
							bss_entry->Channel));
#ifdef EZ_PUSH_BW_SUPPORT
		//if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: %d, CFG:%d OPER:%d\n",
								wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw,
								wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: %d CFG:%d OPER:%d\n", 
								wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw,
								wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
		}
#else
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: CFG:%d OPER:%d\n",
								wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: CFG:%d OPER:%d\n", 
								wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
		}
#endif
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tEXTCHA: %d CFG:%d OPER:%d\n",
							wdev->ez_security.this_band_info.shared_info.channel_info.extcha,
							wlan_config_get_ext_cha(wdev),wlan_operate_get_ext_cha(wdev)));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("AP=> CurrChannel: %d, TarChannel: %d\n", 
			ap_wdev->ez_security.this_band_info.shared_info.channel_info.channel,
							bss_entry->Channel));
#ifdef EZ_PUSH_BW_SUPPORT
		//if( ((PRTMP_ADAPTER)(ap_wdev->sys_handle))->push_bw_config )
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: %d, CFG:%d OPER:%d\n",
								ap_wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw,
								wlan_config_get_ht_bw(ap_wdev),wlan_operate_get_ht_bw(ap_wdev)));
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: %d CFG:%d OPER:%d\n", 
								ap_wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw,
								wlan_config_get_vht_bw(ap_wdev),wlan_operate_get_vht_bw(ap_wdev)));
		}
#else
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: CFG:%d OPER:%d\n",
								wlan_config_get_ht_bw(ap_wdev),wlan_operate_get_ht_bw(ap_wdev)));
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: CFG:%d OPER:%d\n", 
								wlan_config_get_vht_bw(ap_wdev),wlan_operate_get_vht_bw(ap_wdev)));
		}
#endif

		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tEXTCHA: %d CFG:%d OPER:%d\n", 
							ap_wdev->ez_security.this_band_info.shared_info.channel_info.extcha,
							wlan_config_get_ext_cha(ap_wdev),wlan_operate_get_ext_cha(ap_wdev)));
#endif
#endif

		ap_wdev->ez_security.do_not_restart_interfaces = 1;
								
		rtmp_set_channel(pAd, ap_wdev, bss_entry->Channel);

		ap_wdev->ez_security.do_not_restart_interfaces = 0;
#else
		if ((ap_wdev->channel != bss_entry->Channel) || (wdev->channel != bss_entry->Channel)) {
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s - Switch channel to ch.%d\n", __FUNCTION__, bss_entry->Channel));
			rtmp_set_channel(pAd, ap_wdev, bss_entry->Channel);
#ifdef APCLI_AUTO_CONNECT_SUPPORT
#ifdef APCLI_AUTO_BW_TMP
			if(ApCliAutoConnectBWAdjust(pAd, wdev, bss_entry))
				rtmp_set_channel(pAd, wdev, bss_entry->Channel);
			 else
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): ApCliAutoConnectBWAdjust() return FALSE\n", __FUNCTION__));
			
#endif //APCLI_AUTO_BW_TMP
#endif //APCLI_AUTO_CONNECT_SUPPORT
		}
#endif
		NdisGetSystemUpTime(&now);
		if (RTMP_TIME_AFTER(now,wdev->partial_scan_time_stamp + pAd->ez_partial_scan_time*OS_HZ))
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				("%s() Eligible candidate found !!! Restart partial scan timer\n", __FUNCTION__));
			NdisGetSystemUpTime(&wdev->partial_scan_time_stamp);
			
		}

// TODO: Raghav: channel change check. only if force channel not there.
		apcli_entry->MlmeAux.attempted_candidate_index = i;
	}

	return TRUE;

}
BOOLEAN ez_apcli_search_best_ap_unconfigured(
	void *ad_obj,
	void *out_table_obj,
	void *apcli_entry_obj)
{
	ULONG now;
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER)ad_obj;
	PBSS_TABLE out_table = (PBSS_TABLE)out_table_obj;
	PAPCLI_STRUCT apcli_entry = (PAPCLI_STRUCT)apcli_entry_obj;
	struct wifi_dev *wdev = &apcli_entry->wdev;
	char rssi_threshold = wdev->ez_security.rssi_threshold;
	UCHAR provider_idx = EZ_INDEX_NOT_FOUND;
	BSS_ENTRY *bss_entry;
	UCHAR i=0;
	MLME_AUX *apcli_mlme_aux = &apcli_entry->MlmeAux;
	struct wifi_dev *ap_wdev = &pAd->ApCfg.MBSSID[wdev->func_idx].wdev; /* apcli0 find ra0, apcli1 find ra1, etc. */
#ifdef EZ_NETWORK_MERGE_SUPPORT	
		enum_group_merge_action_t group_merge_action;
		BSS_ENTRY *temp_bss_entry = NULL;
		UCHAR bss_channel;
#endif	
	apcli_entry->MlmeAux.support_easy_setup = FALSE;

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s(apcli%d) -->\n", __FUNCTION__, wdev->func_idx));

	if(out_table->BssNr == 0){ /* no easy devices detected yet*/
		BssTableInit(out_table);
		for (i = 0; i < pAd->ScanTab.BssNr; i++) 
		{
			bss_entry = &pAd->ScanTab.BssEntry[i];			
#if 1
			if (!check_best_ap_rssi_threshold(&apcli_entry->wdev.ez_security, bss_entry))
			{
				continue;
			}
#endif

#ifdef EZ_NETWORK_MERGE_SUPPORT
			group_merge_action = is_group_merge_candidate(bss_entry, temp_bss_entry, &apcli_entry->wdev.ez_security);
			switch (group_merge_action)
				{
					case EXIT_SWITCH_NOT_GROUP_MERGE:
						break;
					case TERMINATE_LOOP_MULTIPLE_AP_FOUND:
						out_table->BssNr = 0;
						provider_idx = EZ_INDEX_NOT_FOUND;
						goto provider_found;
						break;
					case TERMINATE_LOOP_TARGET_AP_FOUND:
						bss_channel = bss_entry->Channel;
						if (((WMODE_2G_ONLY(apcli_entry->wdev.PhyMode) && (bss_channel <= 14)) 
								|| (WMODE_5G_ONLY(apcli_entry->wdev.PhyMode) && (bss_channel > 14)))
								&& !ez_is_weight_same(wdev->ez_security.device_info.network_weight,bss_entry->beacon_info.network_weight)){
							BSS_ENTRY *pOutBss = &out_table->BssEntry[out_table->BssNr];
							NdisMoveMemory(pOutBss, bss_entry, sizeof(BSS_ENTRY));
							provider_idx = out_table->BssNr;
							out_table->BssNr++;
							goto provider_found;
						} 
						break;
					case CONTINUE_LOOP_TARGET_AP_FOUND:
						bss_channel = bss_entry->Channel;
						if (((WMODE_2G_ONLY(apcli_entry->wdev.PhyMode) && (bss_channel <= 14)) 
								|| (WMODE_5G_ONLY(apcli_entry->wdev.PhyMode) && (bss_channel > 14)))
								&&  !ez_is_weight_same(wdev->ez_security.device_info.network_weight,bss_entry->beacon_info.network_weight)){

							BSS_ENTRY *pOutBss = &out_table->BssEntry[out_table->BssNr];
							NdisMoveMemory(pOutBss, bss_entry, sizeof(BSS_ENTRY));
							provider_idx = out_table->BssNr;
							out_table->BssNr++;

							temp_bss_entry = bss_entry;
							EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("temp bss_entry = %s\n", temp_bss_entry->Ssid));
						}
						else{
							temp_bss_entry = NULL;
						}						
						continue;
						break;
					case CONTINUE_LOOP:
						continue;
						break;
				}
#endif
#ifdef DBDC_MODE
			if(pAd->CommonCfg.dbdc_mode){
				if( ( WMODE_2G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel <= 14) ) ||
					( WMODE_5G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel > 14) ) )
				{
					// Own band network
				}
				else{
					//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					//("%s(line.%d) - Ignore other band network.\n", 
					//__FUNCTION__, __LINE__));
					continue;
				}
			}
#endif
			if (ez_is_same_open_group_id(wdev, bss_entry) == FALSE) {
				continue;
			}
			if (bss_entry->support_easy_setup
				&& !ez_is_weight_same(wdev->ez_security.device_info.network_weight,bss_entry->beacon_info.network_weight)
				)
			{
				BSS_ENTRY *pOutBss = &out_table->BssEntry[out_table->BssNr];
				NdisMoveMemory(pOutBss, bss_entry, sizeof(BSS_ENTRY));
				out_table->BssNr++;
			}
		}
#ifdef EZ_NETWORK_MERGE_SUPPORT
		if (temp_bss_entry){
			// Open merge candidate found
			goto provider_found;
		}
#endif
		BssTableSortByRssi(out_table, FALSE);
		//Raghav: sort by a different algo
	}

	if (out_table->BssNr == 0)
		goto provider_found;

#ifdef DBG
	for (i=0; i<out_table->BssNr; i++) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("[%d] %02x:%02x:%02x:%02x:%02x:%02x RSSI=%d EZ=%d Attempted=%x\n", i, 
			out_table->BssEntry[i].Bssid[0],
			out_table->BssEntry[i].Bssid[1],
			out_table->BssEntry[i].Bssid[2],
			out_table->BssEntry[i].Bssid[3],
			out_table->BssEntry[i].Bssid[4],
			out_table->BssEntry[i].Bssid[5],
			out_table->BssEntry[i].Rssi, out_table->BssEntry[i].support_easy_setup,out_table->BssEntry[i].bConnectAttemptFailed));
	}
#endif
	if (!MAC_ADDR_EQUAL(wdev->ez_security.ez_apcli_force_bssid, ZERO_MAC_ADDR))
	{
		/*if force bssid is given, then don't connect to any other bssid.*/
		for (i=0; i<out_table->BssNr; i++) {
			
			if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
			}
			bss_entry = &out_table->BssEntry[i];
			if (MAC_ADDR_EQUAL(wdev->ez_security.ez_apcli_force_bssid,bss_entry->Bssid)) {
				provider_idx = i;
				COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("%s(line.%d) - Find peer with force bssid.\n", 
					__FUNCTION__, __LINE__));
				break;
			}
		}
		goto provider_found;
	}

	/* 
		Find rssi >= threshold, higher bssid and configured peer 
		which can go to internet to be provider. 
	*/
	for (i=0; i<out_table->BssNr; i++) {
		
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if ((bss_entry->Rssi >= rssi_threshold) &&
			EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability) &&
			EZ_GET_CAP_INTERNET(bss_entry->easy_setup_capability)) {
			provider_idx = i;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s(line.%d) - Find configured peer with good rssi and higher mac.\n", 
				__FUNCTION__, __LINE__));
			goto provider_found;
		}
	}
	
	
	for (i=0; i<out_table->BssNr; i++) {
		
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if ((bss_entry->Rssi >= rssi_threshold) &&
			EZ_GET_CAP_INTERNET(bss_entry->easy_setup_capability)) {
			provider_idx = i;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s(line.%d) - Find configured peer with good rssi and higher mac.\n", 
				__FUNCTION__, __LINE__));
			goto provider_found;
		}
	}

	/*
		Find rssi >= threshold, higher bssid and configured peer to be provider. 
	*/
	for (i=0; i<out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if ((bss_entry->Rssi >= rssi_threshold) &&
			EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)) {
			provider_idx = i;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s(line.%d) - Find configured peer with good rssi %d\n", 
				__FUNCTION__, __LINE__,bss_entry->easy_setup_capability));
			goto provider_found;
		}
	}

	/* 
		Find rssi >= threshold and higher bssid to be provider. 
	*/
	for (i=0; i<out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if ((bss_entry->Rssi >= rssi_threshold) &&
			ez_mac_addr_compare(bss_entry->Bssid, ap_wdev->bssid)) {
			provider_idx = i;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s(line.%d) - Find higher mac peer with good rssi.\n", __FUNCTION__, __LINE__));
			goto provider_found;
		}
	}
	
	for (i=0; i<out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability) &&
			EZ_GET_CAP_INTERNET(bss_entry->easy_setup_capability)) {
			provider_idx = i;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s(line.%d) - Find configured peer with good rssi and higher mac.\n", 
				__FUNCTION__, __LINE__));
			goto provider_found;
		}
	}
	
	for (i=0; i<out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (EZ_GET_CAP_INTERNET(bss_entry->easy_setup_capability)) {
			provider_idx = i;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s(line.%d) - Find configured peer with good rssi and higher mac.\n", 
				__FUNCTION__, __LINE__));
			goto provider_found;
		}
	}
	/*
		Find configured peer to be provider.
	*/
	for (i=0; i<out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)) {
			provider_idx = i;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s(line.%d) - Find configured peer.\n", __FUNCTION__, __LINE__));
			goto provider_found;
		}
	}
	/*
		Find higher bssid peer to be provider.
	*/
	for (i=0; i<out_table->BssNr; i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (ez_mac_addr_compare(bss_entry->Bssid, ap_wdev->bssid)) {
			provider_idx = i;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s(line.%d) - Find higher mac peer.\n", __FUNCTION__, __LINE__));
			goto provider_found;
		}
	}
	
	for (i=0; (i<out_table->BssNr); i++) {
		if(out_table->BssEntry[i].bConnectAttemptFailed){
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			//	("%s(line.%d) - Skip already attempted candidate.\n", 
			//	__FUNCTION__, __LINE__));
			continue;
		}
		bss_entry = &out_table->BssEntry[i];
		if (!EZ_GET_CAP_HAS_APCLI_INF(bss_entry->easy_setup_capability)) {
			provider_idx = i;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s(line.%d) - Found peer with no active apcli link.\n", __FUNCTION__, __LINE__));
			goto provider_found;
		}
	}

provider_found:

	if(provider_idx != EZ_INDEX_NOT_FOUND){
		// for single chip DBDC operation, as common scan table is present for both band interfaces,
		// and as there is possbility for scan table update/clear,
		// do safety check that bss entry is having valid values
		if(MAC_ADDR_EQUAL(out_table->BssEntry[provider_idx].Bssid, ZERO_MAC_ADDR)){
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_ERROR,("(%s) Chosen BSS entry not Valid\n",__FUNCTION__));
			provider_idx = EZ_INDEX_NOT_FOUND;
			out_table->BssNr = 0;
		}
	}

	if (provider_idx != EZ_INDEX_NOT_FOUND){
		/*
			Provider found and I am joiner.
		*/
		bss_entry = &out_table->BssEntry[provider_idx];
		if(bss_entry->support_easy_setup)
		{
			apcli_entry->MlmeAux.support_easy_setup = TRUE;
		}
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s - Provider(%02x:%02x:%02x:%02x:%02x:%02x) found and I am joiner Cap=%x.\n", 
			__FUNCTION__, 
			bss_entry->Bssid[0],bss_entry->Bssid[1],bss_entry->Bssid[2],
			bss_entry->Bssid[3],bss_entry->Bssid[4],bss_entry->Bssid[5],bss_entry->easy_setup_capability));


		COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
		NdisZeroMemory(apcli_entry->CfgSsid, MAX_LEN_OF_SSID);
		NdisMoveMemory(apcli_entry->CfgSsid, bss_entry->Ssid, bss_entry->SsidLen);
		apcli_entry->CfgSsidLen = bss_entry->SsidLen;

		wdev->SecConfig.AKMMap = bss_entry->AKMMap;
		wdev->SecConfig.PairwiseCipher = bss_entry->PairwiseCipher;
		wdev->SecConfig.GroupCipher = bss_entry->GroupCipher;


#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(pAd, IW_WH_EZ_PROVIDER_FOUND, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_PROVIDER_FOUND,
							NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
#ifdef EZ_NETWORK_MERGE_SUPPORT
				
				ez_ApCliAutoConnectBWAdjust(pAd, wdev, bss_entry);				
				ez_ApCliAutoConnectBWAdjust(pAd, ap_wdev, bss_entry);

#ifdef EZ_NETWORK_MERGE_SUPPORT
#ifdef EZ_DUAL_BAND_SUPPORT
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("search_unconf_ap\nAPCLI=> CurrChannel: %d, TarChannel: %d\n", 
					wdev->ez_security.this_band_info.shared_info.channel_info.channel,
					bss_entry->Channel));
#ifdef EZ_PUSH_BW_SUPPORT
				//if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: %d, CFG:%d OPER:%d\n", wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw,
						wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: %d CFG:%d OPER:%d\n", wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw,
						wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
				}
#else
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: CFG:%d OPER:%d\n",
						wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: CFG:%d OPER:%d\n",
						wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
				}
#endif

				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tEXTCHA: %d CFG:%d OPER:%d\n", wdev->ez_security.this_band_info.shared_info.channel_info.extcha,
					wlan_config_get_ext_cha(wdev),wlan_operate_get_ext_cha(wdev)));

				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("AP=> CurrChannel: %d, TarChannel: %d\n", 
					ap_wdev->ez_security.this_band_info.shared_info.channel_info.channel,
					bss_entry->Channel));

#ifdef EZ_PUSH_BW_SUPPORT
				//if( ((PRTMP_ADAPTER)(ap_wdev->sys_handle))->push_bw_config )
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: %d, CFG:%d OPER:%d\n", ap_wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw,
						wlan_config_get_ht_bw(ap_wdev),wlan_operate_get_ht_bw(ap_wdev)));
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: %d CFG:%d OPER:%d\n", ap_wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw,
						wlan_config_get_vht_bw(ap_wdev),wlan_operate_get_vht_bw(ap_wdev)));
				}
#else
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: CFG:%d OPER:%d\n",
						wlan_config_get_ht_bw(ap_wdev),wlan_operate_get_ht_bw(ap_wdev)));
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: CFG:%d OPER:%d\n",
						wlan_config_get_vht_bw(ap_wdev),wlan_operate_get_vht_bw(ap_wdev)));
				}
#endif

				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tEXTCHA: %d CFG:%d OPER:%d\n", ap_wdev->ez_security.this_band_info.shared_info.channel_info.extcha,
					wlan_config_get_ext_cha(ap_wdev),wlan_operate_get_ext_cha(ap_wdev)));

#endif
#endif

				ap_wdev->ez_security.do_not_restart_interfaces = 1;
				rtmp_set_channel(pAd, ap_wdev, bss_entry->Channel);
				ap_wdev->ez_security.do_not_restart_interfaces = 0;

#else
				if ((ap_wdev->channel != bss_entry->Channel) || (wdev->channel != bss_entry->Channel)) {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s - Switch channel to ch.%d\n", __FUNCTION__, bss_entry->Channel));
			rtmp_set_channel(pAd, ap_wdev, bss_entry->Channel);
#ifdef APCLI_AUTO_CONNECT_SUPPORT
#ifdef APCLI_AUTO_BW_TMP
					if(ApCliAutoConnectBWAdjust(pAd, wdev, bss_entry))
						rtmp_set_channel(pAd, wdev, bss_entry->Channel);
					 else
						EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): ApCliAutoConnectBWAdjust() return FALSE\n", __FUNCTION__));
		
#endif //APCLI_AUTO_BW_TMP
#endif //APCLI_AUTO_CONNECT_SUPPORT
		}
#endif
		NdisGetSystemUpTime(&now);
		if (RTMP_TIME_AFTER(now,wdev->partial_scan_time_stamp + pAd->ez_partial_scan_time*OS_HZ))
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				(" %s() Eligible candidate found !!! Restart partial scan timer \n", __FUNCTION__));
			NdisGetSystemUpTime(&wdev->partial_scan_time_stamp);
			
		}

		apcli_mlme_aux->attempted_candidate_index = provider_idx;

		return TRUE;
	}

	BssTableInit(out_table);
	apcli_mlme_aux->attempted_candidate_index = EZ_INDEX_NOT_FOUND;

	COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, ZERO_MAC_ADDR);
	//NdisZeroMemory(apcli_entry->CfgSsid, MAX_LEN_OF_SSID);
	//apcli_entry->CfgSsidLen = 0;

	{
#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(pAd, IW_WH_EZ_PROVIDER_SEARCHING, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_PROVIDER_SEARCHING,
							NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
		if (wdev->ez_security.first_scan) {
			wdev->ez_security.first_scan = FALSE;
			wdev->ez_security.ez_scan = TRUE;
			ApSiteSurvey_by_wdev(pAd, NULL, SCAN_ACTIVE, FALSE, wdev);

			if (!wdev->ez_security.ez_stop_scan_timer_running) {
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("%s - set full channel scan stop timer here.\n", __FUNCTION__));
				wdev->ez_security.ez_stop_scan_timer_running = TRUE;
				RTMPSetTimer(&wdev->ez_security.ez_stop_scan_timer, EZ_STOP_SCAN_TIME_OUT);
			}

			return FALSE;
		}

		if (!wdev->ez_security.ez_scan_timer_running) {
			UINT random_time;

			random_time = (UINT)(RandomByte(pAd)*100);
			if (random_time > EZ_MAX_SCAN_TIME_OUT)
				random_time = EZ_MAX_SCAN_TIME_OUT;
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_OFF, 
				("(%s) Set scan timer(random_time = %d) and wait scan result.\n", __FUNCTION__, random_time));
			RTMPSetTimer(&wdev->ez_security.ez_scan_timer, random_time);
			wdev->ez_security.ez_scan_timer_running = TRUE;
		}

	}
	return FALSE;
}

#ifdef EZ_NETWORK_MERGE_SUPPORT
enum_group_merge_action_t is_group_merge_candidate(void *bss_entry_obj,void *temp_bss_entry_obj ,struct _ez_security *ez_security)
{
	BSS_ENTRY * bss_entry = bss_entry_obj;
	BSS_ENTRY *temp_bss_entry = temp_bss_entry_obj;
	struct wifi_dev *wdev = ez_security->wdev;
	PRTMP_ADAPTER pAd = ez_security->ad;
	if (EZ_GET_CAP_ALLOW_MERGE(ez_security->capability) 
			&& MAC_ADDR_EQUAL(ez_security->merge_peer_addr, BROADCAST_ADDR)) {
		if (!ez_security->ez_group_merge_timer_running){			
			EzStartGroupMergeTimer(ez_security);
		}
		if (EZ_GET_CAP_ALLOW_MERGE(bss_entry->easy_setup_capability))
		{	
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Searching for provider, Open merge allowed, MAC match, %s\n", bss_entry->Ssid));
			if (temp_bss_entry != NULL){
				
				NdisZeroMemory(ez_security->merge_peer_addr, MAC_ADDR_LEN);
				EZ_CLEAR_CAP_ALLOW_MERGE(ez_security->capability);
				EZ_UPDATE_APCLI_CAPABILITY_INFO(pAd, EZ_CLEAR_ACTION, ALLOW_MERGE, wdev->func_idx);
				if (ez_security->ez_group_merge_timer_running)
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Group Merge completed, cancel timer here\n"));
					EZ_CANCEL_TIMER(&ez_security->ez_group_merge_timer, 
								ez_security->ez_group_merge_timer_running);
				}
				return TERMINATE_LOOP_MULTIPLE_AP_FOUND;
			} else {
				temp_bss_entry = bss_entry;
				EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
					("%s(line.%d): found ap.\n", 
					__FUNCTION__, __LINE__));
				return CONTINUE_LOOP_TARGET_AP_FOUND;
			}
		} else {
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Searching for provider, Open Merge not allowed, %s\n", bss_entry->Ssid));
			return CONTINUE_LOOP;
		}
	} 
	else if (EZ_GET_CAP_ALLOW_MERGE(ez_security->capability) 
			&& EZ_GET_CAP_ALLOW_MERGE(bss_entry->easy_setup_capability)
			&& !MAC_ADDR_EQUAL(ez_security->merge_peer_addr, ZERO_MAC_ADDR))
	{
		if (!ez_security->ez_group_merge_timer_running){			
			EzStartGroupMergeTimer(ez_security);
		}
		if (NdisEqualMemory(bss_entry->Bssid, ez_security->merge_peer_addr, MAC_ADDR_LEN))
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Searching for provider, MAC match, %s\n", bss_entry->Ssid));
			temp_bss_entry = bss_entry;
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found ap.\n", 
				__FUNCTION__, __LINE__));
			return TERMINATE_LOOP_TARGET_AP_FOUND;
		} else 
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Searching for provider, MAC do not match, %s\n", bss_entry->Ssid));
			return CONTINUE_LOOP;
		}
	}
	return EXIT_SWITCH_NOT_GROUP_MERGE;
}
#endif

BOOLEAN ez_apcli_search_best_ap(
	void *ad_obj,
	void *apcli_entry_obj,
	unsigned char inf_idx)
{
	RTMP_ADAPTER *ad;
	APCLI_STRUCT *apcli_entry;
	BSS_TABLE *out_table;
	struct wifi_dev *wdev;
	MLME_AUX *apcli_mlme_aux;
	PRTMP_ADAPTER pAd = ad_obj;
	int index;

	ad = (RTMP_ADAPTER *)ad_obj;
	apcli_entry = (APCLI_STRUCT *)apcli_entry_obj;
	apcli_mlme_aux = &apcli_entry->MlmeAux;
	wdev = &apcli_entry->wdev;
	out_table = &apcli_mlme_aux->SsidBssTab;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,(" %s -->%d\n", __FUNCTION__,wdev->func_idx));
#ifdef EZ_API_SUPPORT
	if (wdev->ez_security.ez_api_mode != CONNECTION_OFFLOAD){
	
#endif

	if (apcli_entry->stop_auto_connect) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Provider search Paused.\n", 
					__FUNCTION__, __LINE__));
		return FALSE;
	}
#ifdef EZ_DUAL_BAND_SUPPORT
	{
		interface_info_t other_band_info;
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("get other_band_info\n"));
		if (ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info)){
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("get other CLI peer\n"));
			ez_hex_dump("other_band_info.cli_peer_ap_mac", other_band_info.cli_peer_ap_mac, 6);
			if (!MAC_ADDR_EQUAL(other_band_info.cli_peer_ap_mac, ZERO_MAC_ADDR)
				&& ! wdev->ez_security.internal_force_connect_bssid_timeout
				&& MAC_ADDR_EQUAL(wdev->ez_security.ez_apcli_force_bssid,ZERO_MAC_ADDR)
				&& MAC_ADDR_EQUAL(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR)
				&& other_band_info.non_easy_connection == FALSE)
			{
					if (!wdev->ez_security.internal_force_connect_bssid) {
						NdisGetSystemUpTime(&wdev->ez_security.force_connect_bssid_time_stamp);
						wdev->ez_security.internal_force_connect_bssid = TRUE;
						pAd->ScanTab.BssNr = 0;
						out_table->BssNr = 0;
					}
			}
		}
	}
#endif		

	if (wdev->ez_security.ez_scan_timer_running) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
					("%s(line.%d) - Wait for next scan.\n", 
					__FUNCTION__, __LINE__));
		return FALSE;
	}
	if (wdev->enable_easy_setup){
		
		struct wifi_dev *ap_wdev = &pAd->ApCfg.MBSSID[wdev->func_idx].wdev;
		//! first send an action frame to EZ peers so that they do not disconnect
		for (index = 0; index < EZ_MAX_STA_NUM; index ++)
		{
			if (ap_wdev->ez_peer_table[index].port_secured){
				send_action_delay_disconnect(ad_obj, ap_wdev,&ap_wdev->ez_peer_table[index], pAd->ez_delay_disconnect_count);
			}
			
		}
	}

	if (wdev->ez_security.ez_connect_wait_timer_running) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("%s(line.%d) - Wait for connection allow.\n", 
					__FUNCTION__, __LINE__));
		return FALSE;
	}

		if(wdev->ez_security.configured_status == EZ_CONFIGURED) //(EZ_GET_CAP_CONFIGRED(wdev->ez_security.capability))
		{
			return ez_apcli_search_best_ap_configured(ad,out_table, apcli_entry);
		}
		else if (wdev->ez_security.configured_status == EZ_UNCONFIGURED)
		{
			return ez_apcli_search_best_ap_unconfigured(ad,out_table,apcli_entry);
		}

#ifdef EZ_API_SUPPORT
		}
	else {
		out_table = &pAd->ScanTab;
		if (!MAC_ADDR_EQUAL(wdev->ez_security.ez_apcli_force_bssid,ZERO_MAC_ADDR))
		{
			ULONG bss_index;
			BSS_ENTRY *bss_entry;
			struct wifi_dev *ap_wdev;
			bss_index = BssTableSearchWithBssId(out_table, wdev->ez_security.ez_apcli_force_bssid, 0);
			if (bss_index == BSS_NOT_FOUND)
			{
				// TODO: Hasan send failure to host
#ifdef SYSTEM_LOG_SUPPORT
			RTMPSendWirelessEvent(ad, IW_WH_EZ_MY_APCLI_DISCONNECTED, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
			RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_MY_APCLI_DISCONNECTED,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
				return FALSE;
			} else {
				/*
					Provider found and I am joiner.
				*/
				bss_entry = &out_table->BssEntry[bss_index];
				
				COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
				NdisZeroMemory(apcli_entry->CfgSsid, MAX_LEN_OF_SSID);
				NdisMoveMemory(apcli_entry->CfgSsid, bss_entry->Ssid, bss_entry->SsidLen);
				NdisMoveMemory(apcli_entry->MlmeAux.Ssid, bss_entry->Ssid, bss_entry->SsidLen);

				apcli_entry->CfgSsidLen = bss_entry->SsidLen;
				apcli_entry->MlmeAux.SsidLen = bss_entry->SsidLen;
				
				wdev->SecConfig.AKMMap = bss_entry->AKMMap;
				wdev->SecConfig.PairwiseCipher = bss_entry->PairwiseCipher;
				wdev->SecConfig.GroupCipher = bss_entry->GroupCipher;

				ap_wdev = &pAd->ApCfg.MBSSID[wdev->func_idx].wdev;
	
#ifdef EZ_NETWORK_MERGE_SUPPORT
				
				ez_ApCliAutoConnectBWAdjust(pAd, wdev, bss_entry);				
				ez_ApCliAutoConnectBWAdjust(pAd, ap_wdev, bss_entry);
				
				ap_wdev->ez_security.do_not_restart_interfaces = 1;
				rtmp_set_channel(pAd, ap_wdev, bss_entry->Channel);
				ap_wdev->ez_security.do_not_restart_interfaces = 0;
				
#endif				
				apcli_mlme_aux->attempted_candidate_index = bss_index;
			
				return TRUE;

			}
		} else {
			// TODO: Hasan send failure to host	
#ifdef SYSTEM_LOG_SUPPORT
						RTMPSendWirelessEvent(ad, IW_WH_EZ_MY_APCLI_DISCONNECTED, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
						RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_MY_APCLI_DISCONNECTED,
										NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */

			return FALSE;
		}
	}
#endif
	return FALSE;
}




void ez_apcli_force_ssid(
	void *ad_obj,
	unsigned char if_index, 
	unsigned char *ssid, 
	unsigned char ssid_len)
{
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER)ad_obj;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s -->\n", __FUNCTION__));
	
	//if (IS_SINGLE_CHIP_DBDC(pAd))
	{
		NdisZeroMemory(pAd->ApCfg.ApCliTab[if_index].wdev.ez_security.ez_apcli_force_ssid,MAX_LEN_OF_SSID);
		NdisCopyMemory(pAd->ApCfg.ApCliTab[if_index].wdev.ez_security.ez_apcli_force_ssid,ssid,ssid_len);
		pAd->ApCfg.ApCliTab[if_index].wdev.ez_security.ez_apcli_force_ssid_len = ssid_len;
	}
}

void ez_apcli_force_bssid(
	void *ad_obj,
	unsigned char if_index, 
	unsigned char *bssid)
{
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER)ad_obj;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s -->\n", __FUNCTION__));
	//if (IS_SINGLE_CHIP_DBDC(pAd))
		COPY_MAC_ADDR(pAd->ApCfg.ApCliTab[if_index].wdev.ez_security.ez_apcli_force_bssid,bssid);
 	//}
}

void ez_apcli_force_channel(
	void *ad_obj,
	unsigned char if_index, 
	unsigned char channel)
{
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER)ad_obj;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s -->\n", __FUNCTION__));

//	if (IS_SINGLE_CHIP_DBDC(pAd))
	pAd->ApCfg.ApCliTab[if_index].wdev.ez_security.ez_apcli_force_channel = channel;
}


/* Indicates whether connection wait timer is running on any of the interfaces*/
static BOOLEAN ez_conn_wait_timer_running(void *ad_obj)
{
	int i = 0;
	PRTMP_ADAPTER pAd = ad_obj;
	BOOLEAN ret = FALSE;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(pAd)){
	adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL){
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
	}
#endif

	//	if(IS_SINGLE_CHIP_DBDC(pAd))
	{
		for (i=0; i<WDEV_NUM_MAX; i++) {
			if (pAd->wdev_list[i]!=NULL && ez_is_ap_apcli(pAd->wdev_list[i]))
			{
				if (pAd->wdev_list[i]->ez_security.ez_connect_wait_timer_running == TRUE){
					ret = TRUE;
					break;
				}
			}
		}
	}
#ifdef DUAL_CHIP
	if( (!IS_SINGLE_CHIP_DBDC(pAd)) && (ret == FALSE) )
	{
		for (i=0; i<WDEV_NUM_MAX; i++) {
			if (adOthBand->wdev_list[i]!=NULL && ez_is_ap_apcli(adOthBand->wdev_list[i]))
			{
				if (adOthBand->wdev_list[i]->ez_security.ez_connect_wait_timer_running == TRUE){
					ret = TRUE;
					break;
				}
			}
		}
	}
#endif

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s-->   %d \n", __FUNCTION__, ret));

	return ret;
}


BOOLEAN ez_update_connection_permission(
	void *ad_obj,
	struct wifi_dev *wdev,
	enum EZ_CONN_ACTION action)
{
	int i = 0;
	PRTMP_ADAPTER pAd = ad_obj;
	static struct wifi_dev *wdev_permission_pending = NULL;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(pAd)){
	adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL){
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
	}
#endif
	if(!IS_SINGLE_CHIP_DBDC(pAd))
		RTMP_SEM_LOCK(&ez_conn_perm_lock);
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s-->%d\n", __FUNCTION__, action));
	if (wdev)
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" wdevIdx=%d\n", wdev->wdev_idx));
	switch (action)
	{
		case EZ_ALLOW_ALL:
		{
			BOOLEAN conn_wait_tmr_running = ez_conn_wait_timer_running(ad_obj);
			if (ez_is_connection_allowed(wdev))
			{
			if(conn_wait_tmr_running == FALSE){
				//	if(IS_SINGLE_CHIP_DBDC(pAd))
				{
					for (i=0; i<WDEV_NUM_MAX; i++) {
						if (pAd->wdev_list[i]!=NULL && ez_is_ap_apcli(pAd->wdev_list[i]))
						{
							if ((wdev_permission_pending == NULL) || (wdev_permission_pending == pAd->wdev_list[i]))
							{
								pAd->wdev_list[i]->ez_security.ez_is_connection_allowed = TRUE;
							}
						}
					}
				}
#ifdef DUAL_CHIP
				if(!IS_SINGLE_CHIP_DBDC(pAd))
				{
					for (i=0; i<WDEV_NUM_MAX; i++) {
						if (adOthBand->wdev_list[i]!=NULL && ez_is_ap_apcli(adOthBand->wdev_list[i]))
						{
							if ((wdev_permission_pending == NULL) || (wdev_permission_pending == adOthBand->wdev_list[i]))
							{
								adOthBand->wdev_list[i]->ez_security.ez_is_connection_allowed = TRUE;
							}

						}
					}
				}
#endif
			}
			}
			else{
				if(!IS_SINGLE_CHIP_DBDC(pAd))
					RTMP_SEM_UNLOCK(&ez_conn_perm_lock);
				return FALSE;
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s: EZ_ALLOW_ALL action ignored as conn wait timer running\n", __FUNCTION__));				
			}
			
			break;

		}
		case EZ_DISALLOW_ALL:
		{
			
			//if(IS_SINGLE_CHIP_DBDC(pAd))
			{
			for (i=0; i<WDEV_NUM_MAX; i++) {
				if (pAd->wdev_list[i]!=NULL && ez_is_ap_apcli(pAd->wdev_list[i]))
				{
					pAd->wdev_list[i]->ez_security.ez_is_connection_allowed = FALSE;
				}
			}
			}
#ifdef DUAL_CHIP
			if(!IS_SINGLE_CHIP_DBDC(pAd))
			{
				for (i=0; i<WDEV_NUM_MAX; i++) {
					if (adOthBand->wdev_list[i]!=NULL && ez_is_ap_apcli(adOthBand->wdev_list[i]))
					{
					adOthBand->wdev_list[i]->ez_security.ez_is_connection_allowed = FALSE;
		}
				}
			}
#endif
			break;
		}
		case EZ_ADD_DISALLOW:
			if (wdev) {
				wdev->ez_security.ez_is_connection_allowed = FALSE;
				wdev->ez_security.ez_connection_permission_backup = FALSE;
			}
			break;
		case EZ_ADD_ALLOW:
			if (wdev) {
				wdev->ez_security.ez_is_connection_allowed = TRUE;
				wdev->ez_security.ez_connection_permission_backup = TRUE;
			}

			break;
		case EZ_DISALLOW_ALL_ALLOW_ME:
			{
				if (ez_is_connection_allowed(wdev))
				{
					for (i=0; i<WDEV_NUM_MAX; i++) {
						if (pAd->wdev_list[i]!=NULL && ez_is_ap_apcli(pAd->wdev_list[i]))
						{
							pAd->wdev_list[i]->ez_security.ez_is_connection_allowed = FALSE;
						}
					}
#ifdef DUAL_CHIP
					if(!IS_SINGLE_CHIP_DBDC(pAd))
					{
						for (i=0; i<WDEV_NUM_MAX; i++) {
							if (adOthBand->wdev_list[i]!=NULL && ez_is_ap_apcli(adOthBand->wdev_list[i]))
							{
								adOthBand->wdev_list[i]->ez_security.ez_is_connection_allowed = FALSE;
							}
						}
					}
#endif	
					{
						if (wdev) {
							wdev->ez_security.ez_is_connection_allowed = TRUE;
						}
					}
					}
				else {
					if(!IS_SINGLE_CHIP_DBDC(pAd))
					RTMP_SEM_UNLOCK(&ez_conn_perm_lock);
					return FALSE;
				}
			}		
			break;
		case EZ_ALLOW_ALL_TIMEOUT:
		{
			for (i=0; i<WDEV_NUM_MAX; i++) {
				if (pAd->wdev_list[i]!=NULL && ez_is_ap_apcli(pAd->wdev_list[i]))
				{
					if ((wdev_permission_pending == NULL) || (wdev_permission_pending == pAd->wdev_list[i]))
					{
						pAd->wdev_list[i]->ez_security.ez_is_connection_allowed = TRUE;
					}
				}
			}
#ifdef DUAL_CHIP
			if(!IS_SINGLE_CHIP_DBDC(pAd))
			{
				for (i=0; i<WDEV_NUM_MAX; i++) {
					if (adOthBand->wdev_list[i]!=NULL && ez_is_ap_apcli(adOthBand->wdev_list[i]))
					{
						if ((wdev_permission_pending == NULL) || (wdev_permission_pending == adOthBand->wdev_list[i]))
						{
							adOthBand->wdev_list[i]->ez_security.ez_is_connection_allowed = TRUE;
						}
					}
				}
			}
#endif
			break;
		}
		case EZ_ENQUEUE_PERMISSION:
		{
			if (wdev_permission_pending == NULL)
			{
				wdev_permission_pending = wdev;
			}
			break;
		}
		case EZ_DEQUEUE_PERMISSION:
		{
			if (wdev_permission_pending == wdev)
			{
				wdev_permission_pending = NULL;
			}
			break;
		}
		default:
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" Unknown Action\n"));

	}
	if(!IS_SINGLE_CHIP_DBDC(pAd))
		RTMP_SEM_UNLOCK(&ez_conn_perm_lock);
	return TRUE;
}

BOOLEAN ez_is_connection_allowed(struct wifi_dev *wdev)
{
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s:wdevIdx=%d, is allowed=%d\n", __FUNCTION__, wdev->wdev_idx,wdev->ez_security.ez_is_connection_allowed ));
#ifdef EZ_API_SUPPORT 
	if (wdev->ez_security.ez_api_mode == CONNECTION_OFFLOAD)
	{
		return TRUE;
	}
#endif
	return wdev->ez_security.ez_is_connection_allowed;
}
#ifdef NEW_CONNECTION_ALGO
void ez_update_capability(void *ad_obj, void *wdev_obj)
{	
	PRTMP_ADAPTER pAd = ad_obj;
	struct wifi_dev *wdev;
	wdev = (struct wifi_dev *)wdev_obj;
	if (pAd->ApCfg.MBSSID[wdev->func_idx].wdev.ez_security.ez_apcli_list.size != 0)
		EZ_SET_CAP_AP_CONFIGURED(wdev->ez_security.capability);
}
#endif
#ifdef APCLI_AUTO_CONNECT_SUPPORT
BOOLEAN ez_probe_count_handle(PAPCLI_STRUCT pApCliEntry)
{
	BOOLEAN attempt_same_peer= FALSE;
    pApCliEntry->ProbeReqCnt = 0;
	return attempt_same_peer;
}
#endif
BOOLEAN ez_join_timeout_handle(void *ad_obj, unsigned char ifIndex)
{
	PRTMP_ADAPTER pAd = ad_obj;
	PAPCLI_STRUCT pApCliEntry;
	PULONG pCurrState = &pAd->ApCfg.ApCliTab[ifIndex].CtrlCurrState;
	BSS_TABLE *aux_bss_table;
#ifndef NEW_CONNECTION_ALGO
	UCHAR ez_connection;
#endif
	pApCliEntry = &pAd->ApCfg.ApCliTab[ifIndex];	
	NdisZeroMemory(pApCliEntry->MlmeAux.Bssid, MAC_ADDR_LEN);
	NdisZeroMemory(pApCliEntry->MlmeAux.Ssid, MAX_LEN_OF_SSID);
	pApCliEntry->MlmeAux.SsidLen = 0;
	aux_bss_table = &pApCliEntry->MlmeAux.SsidBssTab;
    if((pApCliEntry->MlmeAux.attempted_candidate_index != EZ_INDEX_NOT_FOUND) &&
		(pApCliEntry->MlmeAux.attempted_candidate_index <= aux_bss_table->BssNr) ){
		aux_bss_table->BssEntry[pApCliEntry->MlmeAux.attempted_candidate_index].bConnectAttemptFailed = TRUE;
    }
#ifdef NEW_CONNECTION_ALGO
	if (pApCliEntry->wdev.enable_easy_setup && !ez_apcli_search_best_ap(pAd,pApCliEntry,ifIndex)){
		*pCurrState = APCLI_CTRL_DISCONNECTED;
		return FALSE;
			}
#else
	ez_connection = FALSE;
	if (pApCliEntry->wdev.enable_easy_setup && 
		pApCliEntry->wdev.ez_security.keep_finding_provider) {
		ez_connection = TRUE;
		COPY_MAC_ADDR(pApCliEntry->CfgApCliBssid, ZERO_MAC_ADDR);
		NdisZeroMemory(pApCliEntry->CfgSsid, MAX_LEN_OF_SSID);
		pApCliEntry->CfgSsidLen = 0;
		if ( ez_search_provider(pAd, pApCliEntry, ifIndex) == FALSE ) {
			EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_OFF, 
				("(%s) No provider found.\n", __FUNCTION__));
			*pCurrState = APCLI_CTRL_DISCONNECTED;
			return FALSE;
		}
	}
	if (ez_connection == FALSE) {
		if (ez_avoid_looping_connection(pAd, pApCliEntry, ifIndex) == FALSE) {
			*pCurrState = APCLI_CTRL_DISCONNECTED;
			return FALSE;
		}
	}
#endif
	return TRUE;
}
void ez_send_unicast_deauth_apcli(void *ad_obj, USHORT idx)
{
	MLME_QUEUE_ELEM *Elem;
	struct _ez_peer_security_info *ez_peer = NULL;
	struct wifi_dev *wdev;
	PRTMP_ADAPTER ad = ad_obj;

	wdev = &ad->ApCfg.ApCliTab[idx].wdev;
	os_alloc_mem(ad_obj, (UCHAR **)&Elem, sizeof(MLME_QUEUE_ELEM));
	if(Elem == NULL)
	{
		EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Set::OID_802_11_DEAUTHENTICATION, Failed!!\n"));
		return;
	}
	ez_peer = ez_peer_table_search_by_addr(wdev, wdev->bssid);
#if 0
	if (ez_peer == NULL)
	{
		ASSERT(FALSE);
		return;
	}

	if(ez_peer && ez_peer->ez_disconnect_due_roam)
	{
		ez_update_connection_permission(wdev->sys_handle, wdev,EZ_ENQUEUE_PERMISSION);
		ez_update_connection_permission(wdev->sys_handle, wdev,EZ_DISALLOW_ALL);				
	
	}
#endif

	if (ez_peer && !ez_peer->delete_in_differred_context){
		Elem->Priv = idx | IMM_DISCONNECT;
		ApCliCtrlDeAuthAction(ad_obj, Elem);
	} else {
		MlmeEnqueue(ad, APCLI_CTRL_STATE_MACHINE, APCLI_CTRL_DISCONNECT_REQ, 0, NULL, idx);
	}

	os_free_mem(Elem);
}
#ifdef NEW_CONNECTION_ALGO
BOOLEAN ez_probe_rsp_join_action(void *ad_obj, void *wdev_obj, OUT BCN_IE_LIST *ie_list, unsigned long  Bssidx)
{	
	struct wifi_dev *wdev;
	wdev = (struct wifi_dev *)wdev_obj;
		if (ez_is_weight_same(wdev->ez_security.device_info.network_weight,ie_list->vendor_ie.beacon_info.network_weight))
		{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" Discard Probe Rsp as it is a child node\n"));
				return TRUE;
		}
	return FALSE;
}
#endif
void ez_update_connection(void *ad_obj, void *wdev_obj)
{
	PRTMP_ADAPTER pAd = ad_obj;
	struct wifi_dev *wdev;
	wdev = (struct wifi_dev *)wdev_obj;	
	{
		UCHAR sta_count=0;
		int i;
		for (i=0; i<EZ_MAX_STA_NUM;i++)
		{
			if (wdev->ez_peer_table[i].valid && wdev->ez_peer_table[i].port_secured == FALSE)
				sta_count++;
		}
		if (sta_count <= 1)
		{
			ez_update_connection_permission(pAd,wdev,EZ_ALLOW_ALL);
		}
		else
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("--> don't allow all connections as still some connection pending on AP: %d\n", sta_count));
	}
}
#ifdef NEW_CONNECTION_ALGO
BOOLEAN ez_is_link_duplicate(struct _ez_peer_security_info *ez_peer)
{
	struct wifi_dev *wdev = ez_peer->wdev;

	if(wdev->wdev_type == WDEV_TYPE_APCLI)
	{
		return wdev->ez_security.this_band_info.shared_info.link_duplicate;
	} else {
		return ez_peer->this_band_info.shared_info.link_duplicate;
	}
}
void ez_handle_pairmsg4(void *ad_obj, IN MAC_TABLE_ENTRY *pEntry)
{
	RTMP_ADAPTER *pAd = ad_obj;
	struct wifi_dev *ap_wdev = &pAd->ApCfg.MBSSID[pEntry->wdev->func_idx].wdev;
	APCLI_STRUCT *apcli_entry = &pAd->ApCfg.ApCliTab[pEntry->wdev->func_idx];

#ifdef EZ_API_SUPPORT
	if (pEntry->wdev->ez_security.ez_api_mode == CONNECTION_OFFLOAD){
		return;
	}	
#endif
#if 0
	struct wifi_dev *wdev = pEntry->wdev;
	PMAC_TABLE_ENTRY pWdlEntry = NULL;
	struct wifi_dev *WdlWdev = pEntry->wdev;
	struct _ez_peer_security_info *WdlEzPeer;
	struct _ez_peer_security_info *WdlOtherBandEzPeer;
#endif
	apcli_entry->MlmeAux.attempted_candidate_index = EZ_INDEX_NOT_FOUND;

	/*APCLI has connected to a non-easy setup AP, allocate itself a new node number according to the MAC address of the root AP and its own aid.*/
	COPY_MAC_ADDR(pEntry->wdev->ez_security.this_band_info.cli_peer_ap_mac, pEntry->Addr);
	COPY_MAC_ADDR(ap_wdev->ez_security.this_band_info.cli_peer_ap_mac, pEntry->Addr);
	pEntry->wdev->ez_security.ez_wps_reconnect = FALSE;
	NdisZeroMemory(pEntry->wdev->ez_security.ez_wps_bssid, MAC_ADDR_LEN);
	pEntry->wdev->ez_security.best_ap_rssi_threshold = 0;
#if 0
	//! a new connection with third party is formed. chechk and jandle older older weight defining connections
	if (wdev->ez_security.device_info.network_weight[0] == 0xF)
	{
		WdlWdev = wdev->ez_security.device_info.weight_defining_link.wdev;
		pWdlEntry = MacTableLookup(WdlWdev->sys_handle, wdev->ez_security.device_info.weight_defining_link.peer_mac);
		if (pWdlEntry == NULL)
		{
			ASSERT(FALSE);
			return;
		}
		if (pWdlEntry->easy_setup_enabled)
		{
			WdlEzPeer = ez_peer_table_search_by_addr(WdlWdev, wdev->ez_security.device_info.weight_defining_link.peer_mac);
			if (WdlEzPeer == NULL)
			{
				ASSERT(FALSE);
			}
			if (ez_is_link_duplicate(WdlEzPeer))
			{
				WdlOtherBandEzPeer = ez_get_other_band_ez_peer(WdlWdev,WdlEzPeer);
				if (WdlOtherBandEzPeer == NULL)
				{
					ASSERT(FALSE);
				}
			}

			if (WdlOtherBandEzPeer != NULL)
			{
				ez_send_unicast_deauth(WdlOtherBandEzPeer->wdev->system_handle, WdlOtherBandEzPeer->mac_addr)
			}
			ez_send_unicast_deauth(WdlEzPeer->wdev->system_handle, WdlEzPeer->mac_addr)			
		}
	}
#endif	
	update_and_push_weight(pEntry->wdev, pEntry, NULL);

	//ez_apcli_allocate_self_node_number(&pEntry->wdev->ez_security.device_info.ez_node_number,pEntry);
	//ez_update_node_number(pAd,pEntry->wdev,pEntry->wdev->ez_security.device_info.ez_node_number);

#ifdef EZ_DUAL_BAND_SUPPORT
	pEntry->wdev->ez_security.this_band_info.non_easy_connection = TRUE;
	pEntry->wdev->ez_security.first_loop_check = TRUE;
	ez_chk_loop_thru_non_ez_ap(ad_obj, pEntry);
#endif	
}
void ez_update_bss_entry(OUT BSS_ENTRY *pBss, IN BCN_IE_LIST *ie_list)
{
	//NdisCopyMemory(pBss->ez_network_weight, ie_list->vendor_ie.ez_network_weight, NETWORK_WEIGHT_LEN);
	//NdisCopyMemory(&(pBss->ez_node_number), &ie_list->vendor_ie.ez_node_number, sizeof(EZ_NODE_NUMBER));
	//NdisCopyMemory(&pBss->other_band_info,&ie_list->vendor_ie.other_band_info,sizeof(interface_info_t));
	NdisCopyMemory(&pBss->beacon_info,&ie_list->vendor_ie.beacon_info,sizeof(beacon_info_tag_t));

	NdisCopyMemory(pBss->open_group_id,ie_list->vendor_ie.open_group_id, ie_list->vendor_ie.open_group_id_len);
	pBss->open_group_id_len = ie_list->vendor_ie.open_group_id_len;
}
#endif
void ez_send_broadcast_deauth(void *ad_obj, struct wifi_dev *wdev)
{
	MLME_BROADCAST_DEAUTH_REQ_STRUCT  *pInfo = NULL;
	MLME_QUEUE_ELEM *Elem;
	RTMP_ADAPTER *pAd = ad_obj;
	os_alloc_mem(pAd, (UCHAR **)&Elem, sizeof(MLME_QUEUE_ELEM));
	if(Elem == NULL)
	{
		EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Set::OID_802_11_DEAUTHENTICATION, Failed!!\n"));
		return;
	}
	if (Elem)
	{
		pInfo = (MLME_BROADCAST_DEAUTH_REQ_STRUCT *) Elem->Msg;
		pInfo->wdev = wdev;
		Elem->Wcid = WCID_ALL;
		pInfo->Reason = MLME_EZ_DISCONNECT_NON_EZ;
		NdisCopyMemory(pInfo->Addr, BROADCAST_ADDR, MAC_ADDR_LEN);
		APMlmeDeauthReqAction(pAd, Elem);
		os_free_mem(Elem);
	}
}

/*! \brief	 Enqueue a message for other threads, if they want to send messages to MLME thread
 *	\param	*Queue	  The MLME Queue
 *	\param	 Machine  The State Machine Id
 *	\param	 MsgType  The Message Type
 *	\param	 MsgLen   The Message length
 *	\param	*Msg	  The message pointer
 *	\return  TRUE if enqueue is successful, FALSE if the queue is full
 *	\pre
 *	\post
 *	\note	 The message has to be initialized
 */
BOOLEAN EzMlmeEnqueue(
	IN RTMP_ADAPTER *pAd,
	IN ULONG Machine,
	IN ULONG MsgType,
	IN ULONG MsgLen,
	IN VOID *Msg,
	IN ULONG Priv)
{
	INT Tail;
	MLME_QUEUE	*Queue = (MLME_QUEUE *)&pAd->Mlme.Queue;

	/* Do nothing if the driver is starting halt state.*/
	/* This might happen when timer already been fired before cancel timer with mlmehalt*/
	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_HALT_IN_PROGRESS | fRTMP_ADAPTER_NIC_NOT_EXIST))
		return FALSE;

	/* First check the size, it MUST not exceed the mlme queue size*/
	if (MsgLen > MGMT_DMA_BUFFER_SIZE)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("MlmeEnqueue: msg too large, size = %ld \n", MsgLen));
		return FALSE;
	}

	if (MlmeQueueFull(Queue, 1))
	{
#ifdef RELEASE_EXCLUDE
		/* Can't add debug print here. It'll make Mlme Stat machine freeze.*/
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s():full, msg dropped and may corrupt MLME\n", __FUNCTION__));
#endif /* RELEASE_EXCLUDE */
		return FALSE;
	}

	NdisAcquireSpinLock(&(Queue->Lock));
	Tail = Queue->Tail;
	/*
		Double check for safety in multi-thread system.
	*/
	if (Queue->Entry[Tail].Occupied)
	{
		NdisReleaseSpinLock(&(Queue->Lock));
		return FALSE;
	}
	Queue->Tail++;
	Queue->Num++;
	if (Queue->Tail == MAX_LEN_OF_MLME_QUEUE)
		Queue->Tail = 0;

	Queue->Entry[Tail].Wcid = ((MLME_QUEUE_ELEM *)Msg)->Wcid;
	Queue->Entry[Tail].Occupied = TRUE;
	Queue->Entry[Tail].Machine = Machine;
	Queue->Entry[Tail].MsgType = MsgType;
	Queue->Entry[Tail].MsgLen = MsgLen;
	Queue->Entry[Tail].Priv = Priv;

	if (Msg != NULL)
	{
		NdisMoveMemory(Queue->Entry[Tail].Msg, Msg, MsgLen);
	}

	NdisReleaseSpinLock(&(Queue->Lock));
#ifdef RELEASE_EXCLUDE
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("MlmeEnqueue, num=%ld\n",Queue->Num));
#endif /* RELEASE_EXCLUDE */

	return TRUE;
}

void ez_send_unicast_deauth_ap(void *ad_obj, UCHAR *peer_addr)
{
	MLME_DEAUTH_REQ_STRUCT  *pInfo = NULL;
	MLME_QUEUE_ELEM *Elem;
	MAC_TABLE_ENTRY *pEntry = NULL;
	RTMP_ADAPTER *pAd = ad_obj;
	struct _ez_peer_security_info *ez_peer;
	os_alloc_mem(pAd, (UCHAR **)&Elem, sizeof(MLME_QUEUE_ELEM));
	if(Elem == NULL)
	{
		EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Set::OID_802_11_DEAUTHENTICATION, Failed!!\n"));
		return;
	}
	if (Elem)
	{
		pInfo = (MLME_DEAUTH_REQ_STRUCT *) Elem->Msg;
		pInfo->Reason = REASON_NO_LONGER_VALID;
		NdisCopyMemory(pInfo->Addr, peer_addr, MAC_ADDR_LEN);
		if ((pEntry = MacTableLookup(pAd, peer_addr)) != NULL)
		{
			Elem->Wcid = pEntry->wcid;
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("WCID = %d\n;", Elem->Wcid));
			ez_hex_dump("address :", pEntry->Addr, 6);
			ez_peer = ez_peer_table_search_by_addr(pEntry->wdev,pEntry->Addr);
#if 0
			if (ez_peer == NULL)
			{
				ASSERT(FALSE);
				return;
			}

			if(ez_peer && ez_peer->ez_disconnect_due_roam)
			{
				ez_update_connection_permission(ez_peer->wdev->sys_handle, ez_peer->wdev,EZ_DISALLOW_ALL);				
				ez_update_connection_permission(ez_peer->wdev->sys_handle, ez_peer->wdev,EZ_ENQUEUE_PERMISSION);
			}
#endif
			if (ez_peer && !ez_peer->delete_in_differred_context){
				APMlmeDeauthReqAction(pAd, Elem);
			} else {
			
				EzMlmeEnqueue(pAd, AP_AUTH_STATE_MACHINE, APMT2_MLME_DEAUTH_REQ,
					sizeof(MLME_DEAUTH_REQ_STRUCT), Elem, 0);
			}
			EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("EZ Set::OID_802_11_DEAUTHENTICATION (Reason=%d)\n", pInfo->Reason));
		}
		os_free_mem(Elem);
	}
}
void ez_send_unicast_deauth(void *ad_obj, UCHAR *peer_addr)
{
	MAC_TABLE_ENTRY *pEntry = NULL;
	pEntry = MacTableLookup(ad_obj,peer_addr);
	RtmpOsMsDelay(50);
	if (pEntry && pEntry->wdev->wdev_type == WDEV_TYPE_AP)
	{
		ez_send_unicast_deauth_ap(ad_obj, peer_addr);
	} else if (pEntry && pEntry->wdev->wdev_type == WDEV_TYPE_APCLI) {
		ez_send_unicast_deauth_apcli(ad_obj, pEntry->wdev->func_idx);
	}
}
VOID ez_ApCliCtrlJoinFailAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM *Elem)
{
	PAPCLI_STRUCT pApCliEntry;
	USHORT ifIndex = (USHORT)(Elem->Priv);
	PULONG pCurrState = &pAd->ApCfg.ApCliTab[ifIndex].CtrlCurrState;
	BSS_TABLE *aux_bss_table;
	APCLI_MLME_JOIN_REQ_STRUCT JoinReq;
#ifndef NEW_CONNECTION_ALGO
	UCHAR ez_connection;
#endif
	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("(%s)\n", __FUNCTION__));

	{
		struct wifi_dev *ap_wdev =  &pAd->ApCfg.MBSSID[ifIndex].wdev;
		ez_restore_channel_config(ap_wdev);
		NdisZeroMemory(pAd->ApCfg.ApCliTab[ifIndex].CfgSsid,MAX_LEN_OF_SSID);
		pAd->ApCfg.ApCliTab[ifIndex].CfgSsidLen = 0;
			pAd->ApCfg.ApCliTab[ifIndex].CfgSsidLen = pAd->ApCfg.MBSSID[ifIndex].SsidLen;
			NdisCopyMemory(pAd->ApCfg.ApCliTab[ifIndex].CfgSsid,pAd->ApCfg.MBSSID[ifIndex].Ssid,pAd->ApCfg.MBSSID[ifIndex].SsidLen);
		}
	if (ifIndex >= MAX_APCLI_NUM)
		return;
	pApCliEntry = &pAd->ApCfg.ApCliTab[ifIndex];
	if (ApScanRunning(pAd) == TRUE)
	{
#ifdef NEW_CONNECTION_ALGO
			ez_update_connection_permission(pAd,&pApCliEntry->wdev,EZ_ALLOW_ALL);
#endif
		*pCurrState = APCLI_CTRL_DISCONNECTED;
		return;
	}

#ifdef EZ_API_SUPPORT
		if (pApCliEntry->wdev.ez_security.ez_api_mode == CONNECTION_OFFLOAD)
		{
			NdisZeroMemory(pApCliEntry->wdev.ez_security.ez_apcli_force_bssid,MAC_ADDR_LEN);
#ifdef SYSTEM_LOG_SUPPORT
				RTMPSendWirelessEvent(pAd, IW_WH_EZ_MY_APCLI_DISCONNECTED, NULL, pApCliEntry->wdev.wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
				RtmpOSWrielessEventSend(pApCliEntry->wdev.if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_MY_APCLI_DISCONNECTED,
								NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */	
		}
#endif	
	
	NdisZeroMemory(pApCliEntry->MlmeAux.Bssid, MAC_ADDR_LEN);
	NdisZeroMemory(pApCliEntry->MlmeAux.Ssid, MAX_LEN_OF_SSID);
	pApCliEntry->MlmeAux.SsidLen = 0;
	aux_bss_table = &pApCliEntry->MlmeAux.SsidBssTab;
	if((pApCliEntry->MlmeAux.attempted_candidate_index != EZ_INDEX_NOT_FOUND) &&
			(pApCliEntry->MlmeAux.attempted_candidate_index <= aux_bss_table->BssNr) ){
		aux_bss_table->BssEntry[pApCliEntry->MlmeAux.attempted_candidate_index].bConnectAttemptFailed = TRUE;
	}
#ifdef APCLI_AUTO_CONNECT_SUPPORT
	pApCliEntry->ProbeReqCnt = 0;
#endif
	pApCliEntry->AuthReqCnt = 0;
	pApCliEntry->AssocReqCnt = 0;
	*pCurrState = APCLI_CTRL_PROBE;
	NdisZeroMemory(&JoinReq, sizeof(APCLI_MLME_JOIN_REQ_STRUCT));

#ifdef WSC_AP_SUPPORT
    if ((pAd->ApCfg.ApCliTab[ifIndex].wdev.WscControl.WscConfMode != WSC_DISABLE) &&
		(pAd->ApCfg.ApCliTab[ifIndex].wdev.WscControl.bWscTrigger == TRUE))
    {
        NdisZeroMemory(JoinReq.Ssid, MAX_LEN_OF_SSID);
        JoinReq.SsidLen = pAd->ApCfg.ApCliTab[ifIndex].wdev.WscControl.WscSsid.SsidLength;
		NdisMoveMemory(JoinReq.Ssid, pAd->ApCfg.ApCliTab[ifIndex].wdev.WscControl.WscSsid.Ssid, JoinReq.SsidLen);
    }
    else
#endif /* WSC_AP_SUPPORT */
	{
#ifdef NEW_CONNECTION_ALGO
			if (pApCliEntry->wdev.enable_easy_setup && !ez_apcli_search_best_ap(pAd,pApCliEntry,ifIndex) && !pApCliEntry->wdev.ez_security.ez_wps_reconnect){
					*pCurrState = APCLI_CTRL_DISCONNECTED;
					if (!ez_update_connection_permission(pAd,&pApCliEntry->wdev,EZ_ALLOW_ALL))
					{
						ASSERT(FALSE);
					}
					return;
			}
#else
			ez_connection = FALSE;
			if (pApCliEntry->wdev.enable_easy_setup && 
				pApCliEntry->wdev.ez_security.keep_finding_provider) {
				ez_connection = TRUE;
				COPY_MAC_ADDR(pApCliEntry->CfgApCliBssid, ZERO_MAC_ADDR);
				NdisZeroMemory(pApCliEntry->CfgSsid, MAX_LEN_OF_SSID);
				pApCliEntry->CfgSsidLen = 0;
				if ( ez_search_provider(pAd, pApCliEntry, ifIndex) == FALSE ) {
					EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
						("(%s) No provider found.\n", __FUNCTION__));
					*pCurrState = APCLI_CTRL_DISCONNECTED;
					return;
				}
			}
			if (ez_connection == FALSE) {
				if (ez_avoid_looping_connection(pAd, pApCliEntry, ifIndex) == FALSE) {
					*pCurrState = APCLI_CTRL_DISCONNECTED;
					return;
				}
			}
#endif

		if (pApCliEntry->CfgSsidLen != 0)
		{
			JoinReq.SsidLen = pApCliEntry->CfgSsidLen;
			NdisMoveMemory(&(JoinReq.Ssid), pApCliEntry->CfgSsid, JoinReq.SsidLen);
		}
	}

	if (!MAC_ADDR_EQUAL(pApCliEntry->CfgApCliBssid, ZERO_MAC_ADDR))
	{
		COPY_MAC_ADDR(JoinReq.Bssid, pApCliEntry->CfgApCliBssid);
	}

	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("(%s) Probe Ssid=%s, Bssid=%02x:%02x:%02x:%02x:%02x:%02x\n",
		__FUNCTION__, JoinReq.Ssid, JoinReq.Bssid[0], JoinReq.Bssid[1], JoinReq.Bssid[2],
		JoinReq.Bssid[3], JoinReq.Bssid[4], JoinReq.Bssid[5]));
	MlmeEnqueue(pAd, APCLI_SYNC_STATE_MACHINE, APCLI_MT2_MLME_PROBE_REQ,
		sizeof(APCLI_MLME_JOIN_REQ_STRUCT), &JoinReq, ifIndex);
	return;
}
#endif

void ez_wait_for_connection_allow_timeout(
		IN PVOID SystemSpecific1,
		IN PVOID FunctionContext,
		IN PVOID SystemSpecific2,
		IN PVOID SystemSpecific3)
{
	struct _ez_security *ez_sec_info;
	RTMP_ADAPTER *ad;
	struct wifi_dev *wdev;
	int i=0;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
#endif
	//BOOLEAN scan_paused = FALSE;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s -->\n", __FUNCTION__));

	if (FunctionContext) {
		ez_sec_info = (struct _ez_security *)FunctionContext;
		ad = (RTMP_ADAPTER *)ez_sec_info->ad;
#ifdef DUAL_CHIP
		if (!IS_SINGLE_CHIP_DBDC(ad)){
	        adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
        	if(adOthBand == NULL){
                	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
                        ("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
			}
		}
#endif
		wdev = (struct wifi_dev *)ez_sec_info->wdev;
		if (ez_sec_info->ez_connect_wait_timer_running) {
			ez_sec_info->ez_connect_wait_timer_running = FALSE;
			ez_update_connection_permission(ad,wdev,EZ_ALLOW_ALL_TIMEOUT);
			ad->ApCfg.MBSSID[0].wdev.ez_security.weight_update_going_on = FALSE;
			//if (IS_SINGLE_CHIP_DBDC(ad))
			{
				for(i=0; i< MAX_APCLI_NUM;i++)
			{
					if (ad->ApCfg.ApCliTab[i].Enable == 0)
						continue;
					if(ad->ApCfg.ApCliTab[i].wdev.ez_security.ez_apcli_immediate_connect == TRUE &&
						ad->ApCfg.ApCliTab[i].CtrlCurrState == APCLI_CTRL_DISCONNECTED) {
						
						ad->ApCfg.ApCliTab[i].wdev.ez_security.ez_apcli_immediate_connect = FALSE;
						MlmeEnqueue(ad, APCLI_CTRL_STATE_MACHINE, APCLI_CTRL_JOIN_REQ, 0, NULL, i);
					}
				}
			}
#ifdef DUAL_CHIP
			if (!IS_SINGLE_CHIP_DBDC(ad))
			{
				for(i=0; i< MAX_APCLI_NUM;i++)
				{
					if (adOthBand->ApCfg.ApCliTab[i].Enable == 0)
						continue;
					if(adOthBand->ApCfg.ApCliTab[i].wdev.ez_security.ez_apcli_immediate_connect == TRUE &&
						adOthBand->ApCfg.ApCliTab[i].CtrlCurrState == APCLI_CTRL_DISCONNECTED) {
						adOthBand->ApCfg.ApCliTab[i].wdev.ez_security.ez_apcli_immediate_connect = FALSE;
						MlmeEnqueue(ad, APCLI_CTRL_STATE_MACHINE, APCLI_CTRL_JOIN_REQ, 0, NULL, i);
					}
				}
			}
#endif
		}
		else {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
				("%s - Timer expired but timer running flag is FALSE. Do nothing here.\n", 
				__FUNCTION__));
		}
	}
	else {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s - FunctionContext is null?? CHECK!!\n", __FUNCTION__));
	}
}




void ez_wait_for_connection_allow(
	struct wifi_dev *wdev, 
	unsigned long time)
{
	unsigned long now;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s --> %d\n", __FUNCTION__, (int)time));
	NdisGetSystemUpTime(&now);

	if (wdev->ez_security.ez_connect_wait_timer_running)
	{
		if (!RTMP_TIME_AFTER(wdev->ez_security.ez_connect_wait_timer_value + wdev->ez_security.ez_connect_wait_timer_timestamp
			,now + time))
		{
			
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,(" %s --> Cancel previous timer\n", __FUNCTION__));
			EZ_CANCEL_TIMER(&wdev->ez_security.ez_connect_wait_timer,wdev->ez_security.ez_connect_wait_timer_running);
		} else {
		
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s --> rely on previous timer\n", __FUNCTION__));
			return;
		}

	}
	if (!(ez_get_band(wdev) == BAND0 && wdev->wdev_type == WDEV_TYPE_AP))
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,(" BUG:Timer should run on 2.4GHz AP interface only!!!\n"));
	}
	wdev->ez_security.ez_connect_wait_timer_running = TRUE;
	RTMPSetTimer(&wdev->ez_security.ez_connect_wait_timer, time);
	wdev->ez_security.ez_connect_wait_timer_value = time;
	wdev->ez_security.ez_connect_wait_timer_timestamp = now;
	
}

#ifdef EZ_ROAM_SUPPORT
void ez_apcli_check_roaming_status(void *ad_obj)
{
	ULONG now;
	PRTMP_ADAPTER pAd = ad_obj;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(pAd)){
	 adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL){
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		}
#endif
	NdisGetSystemUpTime(&now);
	
	//if (IS_SINGLE_CHIP_DBDC(pAd))
	{
		int i=0;
		for (i=0; i < MAX_APCLI_NUM; i++) {
			struct wifi_dev *wdev = &pAd->ApCfg.ApCliTab[i].wdev;
			if(pAd->ApCfg.ApCliTab[i].Enable == 0 || !IS_EZ_SETUP_ENABLED(wdev))
				continue;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_INFO,
				("%s(): pAd->ez_roam_time %d\n", __FUNCTION__, pAd->ez_roam_time));	
			if (!MAC_ADDR_EQUAL(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR)
				&& (RTMP_TIME_AFTER(now,wdev->ez_security.ez_roam_info.timestamp + pAd->ez_roam_time*OS_HZ))){
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,(" Roaming for Idx=%d failed within 1 min\n",i));
				NdisZeroMemory(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,MAC_ADDR_LEN);
				COPY_MAC_ADDR(pAd->ApCfg.MBSSID[wdev->func_idx].wdev.ez_security.ez_ap_roam_blocked_mac,ZERO_MAC_ADDR);
				ez_update_connection_permission(pAd, wdev,EZ_DEQUEUE_PERMISSION);
				ez_update_connection_permission(pAd, wdev,EZ_ALLOW_ALL);
			}
		}
	}
#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		int i=0;
		for (i=0; i < MAX_APCLI_NUM; i++) {
			struct wifi_dev *wdev = &adOthBand->ApCfg.ApCliTab[i].wdev;
			if(adOthBand->ApCfg.ApCliTab[i].Enable == 0 || !IS_EZ_SETUP_ENABLED(wdev))
				continue;
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_INFO,
				(" %s(): adOthBand->ez_roam_time %d\n", __FUNCTION__, adOthBand->ez_roam_time));	
			if (!MAC_ADDR_EQUAL(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR)
				&& (RTMP_TIME_AFTER(now,wdev->ez_security.ez_roam_info.timestamp + adOthBand->ez_roam_time*OS_HZ))){
				NdisZeroMemory(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,MAC_ADDR_LEN);
				COPY_MAC_ADDR(adOthBand->ApCfg.MBSSID[wdev->func_idx].wdev.ez_security.ez_ap_roam_blocked_mac,ZERO_MAC_ADDR);
				ez_update_connection_permission(adOthBand, wdev,EZ_DEQUEUE_PERMISSION);
				ez_update_connection_permission(adOthBand, wdev,EZ_ALLOW_ALL);
			}
		}
	}
#endif

}
#endif

void ez_peer_table_maintenance(void *ad_obj)
{
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER)ad_obj;
	ULONG now;
#ifdef EZ_NETWORK_MERGE_SUPPORT
	MAC_TABLE_ENTRY *pEntry;
#endif
	struct _ez_peer_security_info *ez_peer = NULL;
	int i,j, sta_count= 0, flag=0;
	
	NdisGetSystemUpTime(&now);

	for (i=0; i<pAd->ApCfg.BssidNum; i++)
	{
		struct wifi_dev *wdev = &pAd->ApCfg.MBSSID[i].wdev;
		struct wifi_dev *apcli_wdev = &pAd->ApCfg.ApCliTab[i].wdev;
		if(!IS_EZ_SETUP_ENABLED(wdev))
			continue;
#ifdef EZ_NETWORK_MERGE_SUPPORT
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,(" pAd->ez_wdl_missing_time : %d \n", pAd->ez_wdl_missing_time));
			pEntry = MacTableLookup(pAd,wdev->ez_security.device_info.weight_defining_link.peer_mac);
			if (pEntry && pEntry->wdev == wdev)
			{
				if (RTMP_TIME_AFTER(now,wdev->ez_security.device_info.weight_defining_link.ap_time_stamp + pAd->ez_wdl_missing_time*OS_HZ))
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,(" Weight defining CLI missing\n"));
					ez_hex_dump("peer AP", wdev->ez_security.device_info.weight_defining_link.peer_ap_mac, 6);
					ez_peer = ez_peer_table_search_by_addr(pEntry->wdev,pEntry->Addr);
					if (ez_peer == NULL)
					{
						ASSERT(FALSE);
						return;
					}
					ez_peer->delete_in_differred_context = TRUE;
					ez_send_unicast_deauth(pAd,wdev->ez_security.device_info.weight_defining_link.peer_mac);
					//update_and_push_weight(wdev, NULL, NULL);
				}
				
			}

			if(IS_SINGLE_CHIP_DBDC(pAd)){		
			if ((!MAC_ADDR_EQUAL(wdev->ez_security.device_info.weight_defining_link.peer_mac,ZERO_MAC_ADDR)) 
				&& (MacTableLookup(pAd,wdev->ez_security.device_info.weight_defining_link.peer_mac) == NULL)
				&& RTMP_TIME_AFTER(now,wdev->ez_security.device_info.weight_defining_link.time_stamp + 120*OS_HZ))
			{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" Wt defining entry did not connect\n"));
				ASSERT(FALSE);
				//update_and_push_weight(wdev, NULL, NULL);
			}
			}
#ifdef DUAL_CHIP
			else
			{ 
				if(wdev == wdev->ez_security.device_info.weight_defining_link.wdev){
					if ((!MAC_ADDR_EQUAL(wdev->ez_security.device_info.weight_defining_link.peer_mac,ZERO_MAC_ADDR))
                                        && (MacTableLookup(pAd,wdev->ez_security.device_info.weight_defining_link.peer_mac) == NULL)
                                        && RTMP_TIME_AFTER(now,wdev->ez_security.device_info.weight_defining_link.time_stamp + 120*OS_HZ))
	                                {
											EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" Wt defining entry did not connect wdev\n"));
											ASSERT(FALSE);
									}
				}
			}
#endif

            //todo: update internet based weight, if not done already for some reason
            //if current weight first byte 0xFF, no change required
            //if current weight first byte 0x00 and internet available, send forced weight update for 0xE i.e. FE
            //if current weight first byte 0x0E and internet gone, send forced weight update for 0x0 i.e. 0xF0
            //remember further 6 bytes not to be changed i.e. root not to be changed.

	
#ifdef EZ_DUAL_BAND_SUPPORT
			if (pAd->ApCfg.ApCliTab[wdev->func_idx].wdev.ez_security.internal_force_connect_bssid &&
					pAd->ApCfg.ApCliTab[wdev->func_idx].wdev.ez_security.internal_force_connect_bssid_timeout == FALSE)
			{
				if (RTMP_TIME_AFTER(now, pAd->ApCfg.ApCliTab[wdev->func_idx].wdev.ez_security.force_connect_bssid_time_stamp + pAd->ez_force_connect_bssid_time*OS_HZ))
				{
					pAd->ApCfg.ApCliTab[wdev->func_idx].wdev.ez_security.internal_force_connect_bssid= FALSE;
					pAd->ApCfg.ApCliTab[wdev->func_idx].wdev.ez_security.internal_force_connect_bssid_timeout = TRUE;
				}
			}
#endif
#endif		
		for (j=0; j<EZ_MAX_STA_NUM; j++)
		{
			if ((wdev->ez_peer_table[j].valid == TRUE) && (wdev->ez_peer_table[j].port_secured== FALSE))
			{
				sta_count++;
				if (RTMP_TIME_AFTER(now,wdev->ez_peer_table[j].creation_time + pAd->ez_peer_entry_age_out_time*OS_HZ))
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,(" %s Deleting peer entry due to ageout\n", __FUNCTION__));
					ez_hex_dump("Mac",(PUCHAR)wdev->ez_peer_table[j].mac_addr, MAC_ADDR_LEN);
					pEntry = NULL;
					pEntry = MacTableLookup(pAd,wdev->ez_peer_table[j].mac_addr);
					if (pEntry){
						EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Mac table entry was formed, send unicast de-auth\n"));
						ez_peer = ez_peer_table_search_by_addr(pEntry->wdev,pEntry->Addr);
						if (ez_peer == NULL)
						{
							ASSERT(FALSE);
							return;
						}
						
						ez_peer->delete_in_differred_context = TRUE;
						ez_send_unicast_deauth(pAd,pEntry->Addr);
					} else {
						EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("No mac table entry present, just remove from ez_table\n"));
						ez_peer_table_delete(wdev,wdev->ez_peer_table[j].mac_addr);
					}
					sta_count--;
					flag=1;
				}
			}
				
		}
		if (sta_count == 0 && flag==1)
		{
			flag = 0;
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" %s Updating connection permission\n", __FUNCTION__));
			ez_update_connection_permission(pAd,wdev,EZ_ALLOW_ALL);
		}
		
		if (apcli_wdev->ez_security.ez_scan_same_channel == TRUE 
			&& RTMP_TIME_AFTER(now,apcli_wdev->ez_security.ez_scan_same_channel_timestamp + pAd->ez_scan_same_channel_time*OS_HZ))
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,(" %s Timeout for scan same channel, scan all channels now.\n", __FUNCTION__));
			apcli_wdev->ez_security.ez_scan_same_channel = FALSE;
			apcli_wdev->ez_security.scan_one_channel = FALSE;
		}

		if (apcli_wdev->ez_security.ez_wps_reconnect && RTMP_TIME_AFTER(now,apcli_wdev->ez_security.ez_wps_reconnect_timestamp + 60*OS_HZ))
		{
			apcli_wdev->ez_security.ez_wps_reconnect = FALSE;
			NdisZeroMemory(apcli_wdev->ez_security.ez_wps_bssid,MAC_ADDR_LEN);
		}
	}

#ifdef EZ_ROAM_SUPPORT
	ez_apcli_check_roaming_status(pAd);
#endif
}


#ifdef EZ_ROAM_SUPPORT

BOOLEAN ez_is_roaming_ongoing(void *ad_obj)
{
	
	PRTMP_ADAPTER pAd = (PRTMP_ADAPTER)ad_obj;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(pAd)){
	adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
	if(adOthBand == NULL) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
		ASSERT(FALSE);
		}
	}
#endif
	//if (IS_SINGLE_CHIP_DBDC(pAd))
	{
		int i=0;
		for (i=0; i < MAX_APCLI_NUM; i++) {
			if (pAd->ApCfg.ApCliTab[i].Enable == 0 || MAC_ADDR_EQUAL(pAd->ApCfg.ApCliTab[i].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR))
				continue;
#ifdef DUAL_CHIP
			else if ((!IS_SINGLE_CHIP_DBDC(pAd)) &&	
				 (adOthBand->ApCfg.ApCliTab[i].Enable == 0 || MAC_ADDR_EQUAL(adOthBand->ApCfg.ApCliTab[i].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR))) 
				continue;
#endif
			else
				return TRUE;
		}
	}
	return FALSE;
}



struct _ez_peer_security_info * ez_peer_table_search_by_node_number(void *wdev_obj, EZ_NODE_NUMBER ez_node_number)
{
	int i;
	struct wifi_dev *wdev;
	struct _ez_peer_security_info *ez_peer;

	ez_peer = NULL;
	wdev = (struct wifi_dev *)wdev_obj;
	RTMP_SEM_LOCK(&wdev->ez_peer_table_lock);
	for (i = 0; i < EZ_MAX_STA_NUM; i++) {		
		if (wdev->ez_peer_table[i].valid &&
			NdisEqualMemory(&ez_node_number, &wdev->ez_peer_table[i].device_info.ez_node_number,ez_node_number.path_len + 1)) {
			ez_peer = &wdev->ez_peer_table[i];
			break;
		}
	}
	RTMP_SEM_UNLOCK(&wdev->ez_peer_table_lock);
	return ez_peer;
}



struct _ez_peer_security_info *ez_find_link_to_roam_candidate(PRTMP_ADAPTER pAd, struct wifi_dev *wdev,EZ_NODE_NUMBER target_node_number)
{
	EZ_NODE_NUMBER *own_node_number = &wdev->ez_security.device_info.ez_node_number;
	EZ_NODE_NUMBER link_node_number;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(pAd)){
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL){
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
	}
#endif
	NdisZeroMemory(&link_node_number,sizeof(EZ_NODE_NUMBER));
	if (ez_is_child_node(*own_node_number, target_node_number) == TRUE)
	{
		NdisCopyMemory(link_node_number.root_mac,target_node_number.root_mac,own_node_number->path_len+1);
		link_node_number.path_len = own_node_number->path_len+1;
	}
	else
	{
		NdisCopyMemory(link_node_number.root_mac,own_node_number->root_mac,own_node_number->path_len-1);
		link_node_number.path_len = own_node_number->path_len-1;
	}
	hex_dump("link Node Number ", (PUCHAR)&link_node_number,sizeof(EZ_NODE_NUMBER));
	//if (IS_SINGLE_CHIP_DBDC(pAd))
	{
		//find the ez_peer for this link node number
		int i;
		struct _ez_peer_security_info *ez_peer = NULL, *tmp_ez_peer=NULL;
		for (i=0; i<WDEV_NUM_MAX; i++) {
			if (pAd->wdev_list[i]!=NULL && ez_is_ap_apcli(pAd->wdev_list[i]))
			{
				ez_peer = ez_peer_table_search_by_node_number(pAd->wdev_list[i],link_node_number);
				if (ez_peer)
				{
					if (ez_peer->wdev == wdev)
					{
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("own APCLI interface is the link.\n"));
					ez_hex_dump("Mac",ez_peer->mac_addr, MAC_ADDR_LEN);
					break;
					}
					else
					{
						tmp_ez_peer = ez_peer;
						EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_peer found\n"));
						ez_hex_dump("MAC", ez_peer->mac_addr,6);
						ez_peer = NULL;
						continue;
					}
				}
#ifdef DUAL_CHIP
				if(!IS_SINGLE_CHIP_DBDC(pAd))
				{
					ez_peer = ez_peer_table_search_by_node_number(adOthBand->wdev_list[i],link_node_number);
					if (ez_peer)
					{
						if (ez_peer->wdev == wdev)
						{
							EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("own APCLI interface is the link.\n"));
							ez_hex_dump("Mac",ez_peer->mac_addr, MAC_ADDR_LEN);
							break;
						}
						else
						{
							tmp_ez_peer = ez_peer;
							EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_peer found\n"));
							ez_hex_dump("MAC", ez_peer->mac_addr,6);
							ez_peer = NULL;
							continue;
						}
					}
				}
#endif
			}
		}
		return ez_peer != NULL? ez_peer: tmp_ez_peer;
	}
}


PUCHAR ez_get_other_band_bssid(BSS_ENTRY *pBss)
{
	return pBss->beacon_info.other_ap_mac;
}
UCHAR ez_get_other_band_channel(BSS_ENTRY *pBss)
{	
	return pBss->beacon_info.other_ap_channel;
}

void ez_initiate_roam(struct wifi_dev *wdev, PUCHAR roam_bssid, UCHAR roam_channel)
{
	MAC_TABLE_ENTRY *pEntry = NULL;
	struct _ez_peer_security_info *ez_peer = NULL;
	if (roam_bssid) {
		NdisCopyMemory(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,
						roam_bssid,MAC_ADDR_LEN);
		ez_hex_dump("RoamBssid",roam_bssid,6);
		wdev->ez_security.ez_roam_info.roam_channel = roam_channel;
		NdisGetSystemUpTime(&wdev->ez_security.ez_roam_info.timestamp);
	}
	else
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_initiate_roam: RoamBssid is NULL!!! \n"));
	pEntry = MacTableLookup(wdev->sys_handle, wdev->bssid);	
        if (pEntry)
	{
		ez_hex_dump("address :", pEntry->Addr, 6);
		ez_peer = ez_peer_table_search_by_addr(pEntry->wdev,pEntry->Addr);
		if (ez_peer == NULL)
		{
			ASSERT(FALSE);
			return;
		}
		ez_peer->delete_in_differred_context = TRUE;
		ez_peer->ez_disconnect_due_roam = TRUE;
	}			
	ez_send_unicast_deauth(wdev->sys_handle,wdev->bssid);
}
BOOLEAN ez_is_bss_user_configured(BSS_ENTRY *pBssEntry)
{
	return (pBssEntry->beacon_info.network_weight[0] == 0x0f);
}

void ez_roam(struct wifi_dev *wdev,BSS_ENTRY *pBssEntry)
{
	PRTMP_ADAPTER pAd = wdev->sys_handle;
	struct _ez_peer_security_info *ez_peer = NULL;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(pAd)){
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL) {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		}
#endif
		
	if(pBssEntry->support_easy_setup)
	{
		if (NdisEqualMemory(wdev->ez_security.device_info.network_weight,pBssEntry->beacon_info.network_weight,NETWORK_WEIGHT_LEN))
		{
			// connect within the same network
			// it means we provided the node number to that device.
			// break the link to that device. wait for weight change and then connect.
			struct _ez_peer_security_info *ez_link_peer = NULL, *ez_dup_link_peer = NULL;
			ez_link_peer = ez_find_link_to_roam_candidate(pAd, wdev,pBssEntry->beacon_info.node_number);
			if (ez_link_peer != NULL)
			{
				//ez_dup_link_peer = ez_find_duplicate_link(ez_link_peer);
				//if (IS_SINGLE_CHIP_DBDC(pAd))
				{
					if (ez_link_peer->wdev->wdev_type == WDEV_TYPE_APCLI) {

						/*link to the target AP is apcli interface on which roaming is triggered.*/
						if (ez_link_peer->wdev == wdev)
						{
							//if(ez_link_peer->this_band_info.shared_info.link_duplicate == TRUE)
							if(wdev->ez_security.this_band_info.shared_info.link_duplicate == TRUE)
								ez_dup_link_peer = ez_get_other_band_ez_peer(ez_link_peer->wdev,ez_link_peer);

							ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
							//both apcli are connected to the same AP. 
							//break both and move to the new AP
							

							if (ez_dup_link_peer != NULL)
							{
									hex_dump("APCLIDuplicateLinkAddr", ez_dup_link_peer->mac_addr, MAC_ADDR_LEN);
									ez_initiate_roam(ez_dup_link_peer->wdev, ez_get_other_band_bssid(pBssEntry),ez_get_other_band_channel(pBssEntry));
							}
							else
							{
								//link is with some other AP. do nothing and don't break the link
							}
						}
						else
						{
							// if link to the device is through the other apcli, break the link and make it connect to the same AP
							ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
							ez_initiate_roam(ez_link_peer->wdev, ez_get_other_band_bssid(pBssEntry),ez_get_other_band_channel(pBssEntry));
						}
					}
					else
					{
					// link is through the AP interface
					// Break the linkto the target device.
					
						if(ez_link_peer->this_band_info.shared_info.link_duplicate == TRUE)
							ez_dup_link_peer = ez_get_other_band_ez_peer(ez_link_peer->wdev,ez_link_peer);

						COPY_MAC_ADDR(ez_link_peer->wdev->ez_security.ez_ap_roam_blocked_mac,ez_link_peer->mac_addr);
						ez_link_peer->ez_disconnect_due_roam = TRUE;
						ez_send_unicast_deauth(pAd,ez_link_peer->mac_addr);
						if(ez_dup_link_peer)
						{
							ez_dup_link_peer->ez_disconnect_due_roam = TRUE;
							COPY_MAC_ADDR(ez_dup_link_peer->wdev->ez_security.ez_ap_roam_blocked_mac,ez_dup_link_peer->mac_addr);
							if(IS_SINGLE_CHIP_DBDC(pAd))
							ez_send_unicast_deauth(pAd,ez_dup_link_peer->mac_addr);
#ifdef DUAL_CHIP
							else
								ez_send_unicast_deauth(adOthBand,ez_dup_link_peer->mac_addr);
#endif
						}
						if (wdev->ez_security.this_band_info.shared_info.link_duplicate)
						{
							struct wifi_dev * other_band_wdev = NULL;
							if(IS_SINGLE_CHIP_DBDC(pAd))
							{
								other_band_wdev = &pAd->ApCfg.ApCliTab[wdev->func_idx^1].wdev;
							}
#ifdef DUAL_CHIP
							else
							{
								other_band_wdev = &adOthBand->ApCfg.ApCliTab[0].wdev;
							}
#endif
							ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
							ez_initiate_roam(other_band_wdev,ez_get_other_band_bssid(pBssEntry),ez_get_other_band_channel(pBssEntry));
						}
						else
						{
							ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
						}
						
					}
				}
			}
			else
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_link peer is NULL!!!\n"));
		}
		else
		{
			//weight is different, connect to it.
			/* if the link to be broken is the only link and it is the wt defining link, 
				break it, assign self a new node number/wt and then connect to the new bssid */
						// if going to another user configured, then break both links
			/*if link to be broken is not the wt defining link or there are 2 links, then break the link without updating the node number and wt and connect
			to the new one.*/
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("weight is different\n"));
			if (wdev->ez_security.device_info.network_weight[0] == 0xf && ez_is_bss_user_configured(pBssEntry))
			{
				struct wifi_dev * other_band_wdev = NULL;
				struct wifi_dev * wt_defining_wdev = wdev->ez_security.device_info.weight_defining_link.wdev;
				if (wdev->ez_security.user_configured == TRUE)
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("This is User configured device, can't roam to another UserConfigured device\n"));
					return;
				}
				/*If AP interface is the wt defining link, then break it before roam*/
				if(wt_defining_wdev->wdev_type == WDEV_TYPE_AP)
				{
					struct _ez_peer_security_info *ez_peer = ez_peer_table_search_by_addr(wt_defining_wdev,
																			wt_defining_wdev->ez_security.device_info.weight_defining_link.peer_mac);
					struct _ez_peer_security_info *ez_dup_link_peer=NULL;
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ApInterface is the wt defining link\n"));
					if (ez_peer == NULL)
					{
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("Ez_peer Not found!!!\n"));
						return;
					}
					if (ez_peer->this_band_info.shared_info.link_duplicate == TRUE)
						ez_dup_link_peer =ez_get_other_band_ez_peer(wt_defining_wdev,ez_peer);

					COPY_MAC_ADDR(ez_peer->wdev->ez_security.ez_ap_roam_blocked_mac,ez_peer->mac_addr);
					ez_peer->ez_disconnect_due_roam = TRUE;
					ez_send_unicast_deauth(pAd,ez_peer->mac_addr);
					if(ez_dup_link_peer)
					{
						ez_dup_link_peer->ez_disconnect_due_roam = TRUE;
						COPY_MAC_ADDR(ez_dup_link_peer->wdev->ez_security.ez_ap_roam_blocked_mac,ez_dup_link_peer->mac_addr);
						if(IS_SINGLE_CHIP_DBDC(pAd))
						ez_send_unicast_deauth(pAd,ez_dup_link_peer->mac_addr);
#ifdef DUAL_CHIP
						else
							ez_send_unicast_deauth(adOthBand,ez_dup_link_peer->mac_addr);
#endif
					}
					ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
				}
				else
				{
					/*If roaming APCLI is the wt defining link, then break it and roam only that interface.*/
					if((wt_defining_wdev == wdev) && (!wdev->ez_security.this_band_info.shared_info.link_duplicate) )
					{
						EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Roam only APCLI interface\n"));
						ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
					}
					else
					{
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("both are user configured, roam both device."));
						if(IS_SINGLE_CHIP_DBDC(pAd))
						{
							other_band_wdev = &pAd->ApCfg.ApCliTab[wdev->func_idx^1].wdev;
						}
#ifdef DUAL_CHIP
						else
						{
							other_band_wdev = &adOthBand->ApCfg.ApCliTab[0].wdev;
						}
#endif
						ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
						ez_initiate_roam(other_band_wdev,ez_get_other_band_bssid(pBssEntry),ez_get_other_band_channel(pBssEntry));
					}
				}
			}
			else
			{
				ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
			}
		}
	}
	else
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Roaming to Non easy setup AP\n"));
		//ez_hex_dump("Bssid", pBssEntry->Bssid,6);
		//ez_hex_dump("OwnWtMac");
		if (1)//MAC_ADDR_EQUAL(pBssEntry->Bssid,&wdev->ez_security.device_info.network_weight[1] ))
		{
			
			// both are connected to same AP, roam both interfaces otherwise loop will be created
			struct wifi_dev * other_band_wdev = NULL;
			MAC_TABLE_ENTRY *pEntry = NULL;
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Roam both interfaces\n"));
			if(IS_SINGLE_CHIP_DBDC(pAd))
			{
				other_band_wdev = &pAd->ApCfg.ApCliTab[wdev->func_idx^1].wdev;
			}
#ifdef DUAL_CHIP
			else
			{
				other_band_wdev = &adOthBand->ApCfg.ApCliTab[0].wdev;
			}
#endif
		ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
			//ez_initiate_roam(other_band_wdev,ez_get_other_band_bssid(pBssEntry),ez_get_other_band_channel(pBssEntry));
			pEntry = MacTableLookup(other_band_wdev->sys_handle,other_band_wdev->bssid);
		        if (pEntry)
        		{
		                ez_hex_dump("address :", pEntry->Addr, 6);
                		ez_peer = ez_peer_table_search_by_addr(pEntry->wdev,pEntry->Addr);
		                if (ez_peer == NULL)
                		{
                      		  ASSERT(FALSE);
	                          return;
          		        }
                		ez_peer->delete_in_differred_context = TRUE;
						ez_peer->ez_disconnect_due_roam = TRUE;
        		}
			ez_send_unicast_deauth(other_band_wdev->sys_handle,other_band_wdev->bssid);

		} else {
			ez_initiate_roam(wdev,pBssEntry->Bssid,pBssEntry->Channel);
		}
	}

	/*if roaming is initiated, disallow all pending connections and allow only roaming connection.*/
	NdisAcquireSpinLock(&ez_mlme_sync_lock);
	ez_update_connection_permission(wdev->sys_handle,wdev,EZ_ALLOW_ALL_TIMEOUT);
	ez_update_connection_permission(wdev->sys_handle, wdev,EZ_ENQUEUE_PERMISSION);
	ez_update_connection_permission(wdev->sys_handle, wdev,EZ_DISALLOW_ALL_ALLOW_ME);
	NdisReleaseSpinLock(&ez_mlme_sync_lock);
	ez_notify_roam(pAd, NULL);
}

ULONG
BssTableSearchWithBssId(
    IN BSS_TABLE *Tab,
    IN PUCHAR     Bssid,
    IN UCHAR      Channel)
{
    UCHAR i;
    UINT BssNr = Tab->BssNr;
    
    for (i = 0; i < BssNr; i++)
    {
        if ((i < MAX_LEN_OF_BSS_TABLE) &&
            MAC_ADDR_EQUAL(&(Tab->BssEntry[i].Bssid), Bssid))
        {
            return i;
        }
    }
    return (ULONG)BSS_NOT_FOUND;
}

BSS_ENTRY *ez_find_roam_candidate(void * ad_obj, unsigned char *bssid, struct wifi_dev *wdev)
{
	PRTMP_ADAPTER pAd = ad_obj;
	ULONG bss_idx;
//	BSS_ENTRY * pBssEntry = NULL;
	//if (IS_SINGLE_CHIP_DBDC(pAd))
	{
		bss_idx = BssTableSearchWithBssId(&pAd->ScanTab,bssid,0);
	}
	if (bss_idx == BSS_NOT_FOUND)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_find_roam_candidate: Roam entry not found\n"));
		return NULL;
	}
	else
	{
		return &pAd->ScanTab.BssEntry[bss_idx];
	}

}


INT Set_EasySetup_RoamBssid_Proc(
	IN  PRTMP_ADAPTER pAd,
	IN  RTMP_STRING *arg)
{
	INT i;
	
	RTMP_STRING *value;
	UCHAR ifIndex;
	POS_COOKIE pObj;
	BSS_ENTRY *pBssEntry = NULL;
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	if (pObj->ioctl_if_type != INT_APCLI)
		return FALSE;

	ifIndex = pObj->ioctl_if;

	if (ez_is_roaming_ongoing(pAd) == TRUE)
		return FALSE;// Roaming already ongoing on some interface.

	if(strlen(arg) == 17)  /* Mac address acceptable format 01:02:03:04:05:06 length 17 */
	{
		for (i=0, value = rstrtok(arg,":"); value; value = rstrtok(NULL,":"), i++)
		{
			if((strlen(value) != 2) || (!isxdigit(*value)) || (!isxdigit(*(value+1))) )
				return FALSE;  /* Invalid */

			AtoH(value, &pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid[i], 1);
		}

		if(i != 6)
			return FALSE;  /* Invalid */
	}
	NdisGetSystemUpTime(&pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.timestamp);

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Set_EasySetup_ForceBssid_Proc (%2X:%2X:%2X:%2X:%2X:%2X)\n",
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid[0],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid[1],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid[2],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid[3],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid[4],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid[5]));

	/*if connection not already ongoing, then initiate a connection.*/
	pBssEntry = ez_find_roam_candidate(pAd,pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid,&pAd->ApCfg.ApCliTab[ifIndex].wdev );
	if (pBssEntry!= NULL){
		ez_roam(&pAd->ApCfg.ApCliTab[ifIndex].wdev, pBssEntry);
		return TRUE;
	}
	else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("bss entry for this bssid not found!!\n"));
		COPY_MAC_ADDR(pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR);
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.roam_channel =0;
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_roam_info.timestamp = 0;

		return FALSE;
	}
}
#endif

#endif

#if 0
unsigned char ez_search_provider(
	void *ad_obj,
	void *apcli_entry_obj,
	unsigned char inf_idx)
{
	RTMP_ADAPTER *ad;
	APCLI_STRUCT *apcli_entry;
	BSS_TABLE *table;
	BSS_TABLE *out_table;
	struct wifi_dev *ap_wdev;
	struct wifi_dev *wdev;
	unsigned char found_easy_setup_peer;
	int i;
	MLME_AUX *apcli_mlme_aux;
	BSS_ENTRY *bss_entry;
	unsigned char rv;
	unsigned char provider_idx;
#ifdef EZ_NETWORK_MERGE_SUPPORT	
	unsigned char merge_provider_found = FALSE;
	UCHAR bss_channel;
	int index;
#endif	
	char rssi_threshold;

	provider_idx = EZ_INDEX_NOT_FOUND;
	rv = FALSE;
	ad = (RTMP_ADAPTER *)ad_obj;
	apcli_entry = (APCLI_STRUCT *)apcli_entry_obj;
	apcli_mlme_aux = &apcli_entry->MlmeAux;
	wdev = &apcli_entry->wdev;
	rssi_threshold = wdev->ez_security.rssi_threshold;
	ap_wdev = &ad->ApCfg.MBSSID[inf_idx].wdev; /* apcli0 find ra0, apcli1 find ra1, etc. */
	table = &ad->ScanTab;
	found_easy_setup_peer = FALSE;
	out_table = &apcli_mlme_aux->SsidBssTab;

	if (apcli_entry->stop_auto_connect) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Provider search Paused.\n", 
					__FUNCTION__, __LINE__));
		return FALSE;
	}

	if (wdev->ez_security.ez_scan_timer_running) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Wait for next scan.\n", 
					__FUNCTION__, __LINE__));
		return FALSE;
	}

    if(out_table->BssNr == 0){ /* no easy devices detected yet*/
		BssTableInit(out_table);

		for (i = 0; i < table->BssNr; i++) 
		{
			BSS_ENTRY *pOutBss;
			bss_entry = &table->BssEntry[i];
			if (bss_entry->support_easy_setup) 
			{
#ifdef EZ_NETWORK_MERGE_SUPPORT
			//! if CLI is looking for an open group merge capable
			if (EZ_GET_CAP_ALLOW_MERGE(apcli_entry->wdev.ez_security.capability)
				&& MAC_ADDR_EQUAL(apcli_entry->wdev.ez_security.merge_peer_addr, BROADCAST_ADDR)) {
				//! trigger the timer if it is not already running
				if (!apcli_entry->wdev.ez_security.ez_group_merge_timer_running){
					EzStartGroupMergeTimer(&apcli_entry->wdev.ez_security);
				}
				//! check if bss_entry supports group merge
				if (EZ_GET_CAP_ALLOW_MERGE(bss_entry->easy_setup_capability))
				{
					//! if already a merge capable AP is present and this is second AP with merge capability, do not connect to any
					if (merge_provider_found){
						out_table->BssNr = 0;
						NdisZeroMemory(apcli_entry->wdev.ez_security.merge_peer_addr, MAC_ADDR_LEN);
						EZ_CLEAR_CAP_ALLOW_MERGE(apcli_entry->wdev.ez_security.capability);
						EZ_UPDATE_APCLI_CAPABILITY_INFO(ad, EZ_CLEAR_ACTION, ALLOW_MERGE, apcli_entry->wdev.func_idx);
						if (apcli_entry->wdev.ez_security.ez_group_merge_timer_running)
						{
							EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Group Merge completed, cancel timer here\n"));
							EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_group_merge_timer, 
										apcli_entry->wdev.ez_security.ez_group_merge_timer_running);

						}
						goto provider_found;
					} else {
					//! this is the first AP with merge capability, store it in the out_table but keep looking if any other AP present
						merge_provider_found = TRUE;
						bss_channel = bss_entry->Channel;
						if ((WMODE_2G_ONLY(apcli_entry->wdev.PhyMode) && (bss_channel <= 14)) 
							|| (WMODE_5G_ONLY(apcli_entry->wdev.PhyMode) && (bss_channel > 14))){
							BSS_ENTRY *pOutBss = &out_table->BssEntry[out_table->BssNr];
							NdisMoveMemory(pOutBss, bss_entry, sizeof(BSS_ENTRY));
							out_table->BssNr++;
						} 
						continue;
					}
				} else {
					//! current AP does not support open merge, check next
					continue;
				}
			} 
			//! CLI is looking for a specific AP with open merge support
			else if (!MAC_ADDR_EQUAL(apcli_entry->wdev.ez_security.merge_peer_addr, ZERO_MAC_ADDR))
			{
				//! if group merge timer is not already running, trigger it
				if (!apcli_entry->wdev.ez_security.ez_group_merge_timer_running){
					EzStartGroupMergeTimer(&apcli_entry->wdev.ez_security);
				}
				//! if MAC address match, add it to table, else continue
				if (NdisEqualMemory(bss_entry->Bssid, apcli_entry->wdev.ez_security.merge_peer_addr, MAC_ADDR_LEN))
				{
				} else 
				{
					continue;
				}
			}
#endif
			pOutBss = &out_table->BssEntry[out_table->BssNr];
			if ((bss_entry->SsidLen == ad->ApCfg.MBSSID[inf_idx].SsidLen) && 
				(NdisEqualMemory(bss_entry->Ssid,ad->ApCfg.MBSSID[inf_idx].Ssid,ad->ApCfg.MBSSID[inf_idx].SsidLen)))
			{
				continue;
			}
#ifdef DBDC_MODE
				if(ad->CommonCfg.dbdc_mode){
					if( ( WMODE_2G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel <= 14) ) ||
						( WMODE_5G_ONLY(apcli_entry->wdev.PhyMode) && (bss_entry->Channel > 14) ) )
					{
						// Own band network
					}
					else{
						EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
						("%s(line.%d) - Ignore other band network.\n", 
						__FUNCTION__, __LINE__));
						continue;
					}
				}
#endif
			    NdisMoveMemory(pOutBss, bss_entry, sizeof(BSS_ENTRY));
			    out_table->BssNr++;
					
			}
		}

		BssTableSortByRssi(out_table, FALSE);
    }
	
	if (out_table->BssNr != 0) {
#ifdef DBG
		for (i=0; i<out_table->BssNr; i++) {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				("[%d] %02x:%02x:%02x:%02x:%02x:%02x RSSI=%d  Attempted=%d\n", i, 
				out_table->BssEntry[i].Bssid[0],
				out_table->BssEntry[i].Bssid[1],
				out_table->BssEntry[i].Bssid[2],
				out_table->BssEntry[i].Bssid[3],
				out_table->BssEntry[i].Bssid[4],
				out_table->BssEntry[i].Bssid[5],
				out_table->BssEntry[i].Rssi,
				out_table->BssEntry[i].bConnectAttemptFailed));
		}
#endif
		found_easy_setup_peer = TRUE;

		/* 
			Find rssi >= threshold, higher bssid and configured peer 
			which can go to internet to be provider. 
		*/
		for (i=0; (i<out_table->BssNr); i++) {

            if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
           	}

			bss_entry = &out_table->BssEntry[i];
			if ((bss_entry->Rssi >= rssi_threshold) &&
				ez_mac_addr_compare(bss_entry->Bssid, ap_wdev->bssid) &&
				EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability) &&
				EZ_GET_CAP_INTERNET(bss_entry->easy_setup_capability)) {
				provider_idx = i;
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Found configured peer with good rssi,higher mac & Internet.\n", 
					__FUNCTION__, __LINE__));
				goto provider_found;
			}
		}

		/*
			My AP doesn't have apcli entry.
			Find rssi >= threshold and configured peer which can go to internet to be provider.
		*/
		for (i=0; (i<out_table->BssNr); i++) {

            if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
           	}

			bss_entry = &out_table->BssEntry[i];
			if ((ap_wdev->ez_security.ez_apcli_list.size == 0) &&
				(bss_entry->Rssi >= rssi_threshold) &&
				EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability) &&
				EZ_GET_CAP_INTERNET(bss_entry->easy_setup_capability)) {
				provider_idx = i;
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Found configured peer with good rssi & Internet.\n", __FUNCTION__, __LINE__));
				goto provider_found;
			}
		}
		
		/* 
			Find rssi >= threshold, higher bssid and configured peer to be provider. 
		*/
		for (i=0; (i<out_table->BssNr); i++) {

            if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
           	}

			bss_entry = &out_table->BssEntry[i];
			if ((bss_entry->Rssi >= rssi_threshold) &&
				ez_mac_addr_compare(bss_entry->Bssid, ap_wdev->bssid) &&
				EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)) {
				provider_idx = i;
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Found configured peer with good rssi & higher mac.\n", 
					__FUNCTION__, __LINE__));
				goto provider_found;
			}
		}

		/*
			My AP doesn't have apcli entry.
			Find rssi >= threshold and configured peer to be provider.
		*/
		for (i=0; (i<out_table->BssNr); i++) {

            if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
           	}

			bss_entry = &out_table->BssEntry[i];
			if ((ap_wdev->ez_security.ez_apcli_list.size == 0) &&
				(bss_entry->Rssi >= rssi_threshold) &&
				EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)) {
				provider_idx = i;
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Found configured peer with good rssi.\n", __FUNCTION__, __LINE__));
				goto provider_found;
			}
		}
		
		/* 
			Find rssi >= threshold and higher bssid to be provider. 
		*/
		for (i=0; (i<out_table->BssNr); i++) {

            if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
           	}

			bss_entry = &out_table->BssEntry[i];
			if ((bss_entry->Rssi >= rssi_threshold) &&
				ez_mac_addr_compare(bss_entry->Bssid, ap_wdev->bssid)) {
				provider_idx = i;
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Found peer with good rssi & higher mac.\n", __FUNCTION__, __LINE__));
				goto provider_found;
			}
		}
#if 0
		/*
			Find higher bssid peer to be provider.
		*/
		for (i=0; (i<out_table->BssNr); i++) {

            if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
           	}

			bss_entry = &out_table->BssEntry[i];
			if (ez_mac_addr_compare(bss_entry->Bssid, ap_wdev->bssid)) {
				provider_idx = i;
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Found higher mac peer.\n", __FUNCTION__, __LINE__));
				goto provider_found;
			}
		}

		/*
			My AP doesn't have apcli entry.
			Find configured peer to be provider.
		*/
		for (i=0; (i<out_table->BssNr); i++) {

            if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
           	}

			bss_entry = &out_table->BssEntry[i];
			if ((ap_wdev->ez_security.ez_apcli_list.size == 0) &&
				EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)) {
				provider_idx = i;
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Found configured peer.\n", __FUNCTION__, __LINE__));
				goto provider_found;
			}
		}
#endif
		/*
			Find peer which doesn't have apcli to be provider.
		*/
		for (i=0; (i<out_table->BssNr); i++) {

            if(out_table->BssEntry[i].bConnectAttemptFailed){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				//	("%s(line.%d) - Skip already attempted candidate.\n", 
				//	__FUNCTION__, __LINE__));
				continue;
           	}

			bss_entry = &out_table->BssEntry[i];
			if ((bss_entry->Rssi >= rssi_threshold) &&
				!EZ_GET_CAP_HAS_APCLI_INF(bss_entry->easy_setup_capability)) {
				provider_idx = i;
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Found peer with no active apcli link.\n", __FUNCTION__, __LINE__));
				goto provider_found;
			}
		}
	}
provider_found:
	if (provider_idx != EZ_INDEX_NOT_FOUND) {
		/*
			Provider found and I am joiner.
		*/
		bss_entry = &out_table->BssEntry[provider_idx];
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			("%s - Provider(%02x:%02x:%02x:%02x:%02x:%02x) found and I am joiner.\n", 
			__FUNCTION__, 
			bss_entry->Bssid[0],
			bss_entry->Bssid[1],
			bss_entry->Bssid[2],
			bss_entry->Bssid[3],
			bss_entry->Bssid[4],
			bss_entry->Bssid[5]));

		//if (wdev->ez_security.ez_stop_scan_timer_running) {
		//	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
		//		("%s - Cancel stop scan timer.\n", __FUNCTION__));
		//	EZ_CANCEL_TIMER(&wdev->ez_security.ez_stop_scan_timer,
		//		wdev->ez_security.ez_stop_scan_timer_running);
		//}

		COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
		NdisZeroMemory(apcli_entry->CfgSsid, MAX_LEN_OF_SSID);
		NdisMoveMemory(apcli_entry->CfgSsid, bss_entry->Ssid, bss_entry->SsidLen);
		apcli_entry->CfgSsidLen = bss_entry->SsidLen;

		wdev->SecConfig.AKMMap = bss_entry->AKMMap;
		wdev->SecConfig.PairwiseCipher = bss_entry->PairwiseCipher;
		wdev->SecConfig.GroupCipher = bss_entry->GroupCipher;

		//EZ_CANCEL_TIMER(&wdev->ez_security.ez_scan_timer,
		//	wdev->ez_security.ez_scan_timer_running);
		//EZ_CANCEL_TIMER(&wdev->ez_security.ez_stop_scan_timer,
		//	wdev->ez_security.ez_stop_scan_timer_running);

#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(ad, IW_WH_EZ_PROVIDER_FOUND, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_PROVIDER_FOUND,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */

#ifdef EZ_NETWORK_MERGE_SUPPORT
		//! sane AP'scurrent channel to ez_sec base channel
		ap_wdev->ez_security.base_channel = ap_wdev->channel;
		//! save target AP's channel to target_channle
		ap_wdev->ez_security.target_channel = bss_entry->Channel;
			
		//! adjust APCLI's operating bandwidth to that of peer
		if (ez_ApCliAutoConnectBWAdjust(ad, wdev, bss_entry))
		{
			ez_ApCliAutoConnectBWAdjust(ad, ap_wdev, bss_entry);
			MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_ERROR, ("Switch to channel :%d\n", bss_entry->Channel));
			//! switch to target channel
			rtmp_set_channel(ad, ap_wdev, bss_entry->Channel);
		}
#else
		if ((ap_wdev->channel != bss_entry->Channel) || (wdev->channel != bss_entry->Channel)) {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				("%s - Switch channel to ch.%d\n", __FUNCTION__, bss_entry->Channel));
			rtmp_set_channel(ad, ap_wdev, bss_entry->Channel);
#ifdef APCLI_AUTO_CONNECT_SUPPORT
#ifdef APCLI_AUTO_BW_TMP
			if(ApCliAutoConnectBWAdjust(ad, wdev, bss_entry))
				rtmp_set_channel(ad, wdev, bss_entry->Channel);
			 else
             	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): ApCliAutoConnectBWAdjust() return FALSE\n", __FUNCTION__));

#endif //APCLI_AUTO_BW_TMP
#endif //APCLI_AUTO_CONNECT_SUPPORT
		}
#endif
		apcli_mlme_aux->attempted_candidate_index = provider_idx;

		return TRUE;
	}

	BssTableInit(out_table);
	apcli_mlme_aux->attempted_candidate_index = EZ_INDEX_NOT_FOUND;

	COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, ZERO_MAC_ADDR);
	NdisZeroMemory(apcli_entry->CfgSsid, MAX_LEN_OF_SSID);
	apcli_entry->CfgSsidLen = 0;

#if (0)	// allow to keep finding provider on all channels
	if (found_easy_setup_peer) {
		/*
			Other easy setup device exists and I am provider.
			Stop to scanning for waiting joiner.
		*/

		//wdev->ez_security.keep_finding_provider = FALSE; allow to keep finding provider on same channel
		
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				("%s - Other easy setup device exists and I am provider. (apcli_entry_count=%d)\n", 
				__FUNCTION__, ap_wdev->ez_security.ez_apcli_list.size));
		EZ_CANCEL_TIMER(&wdev->ez_security.ez_stop_scan_timer,
			wdev->ez_security.ez_stop_scan_timer_running);
		EZ_CANCEL_TIMER(&wdev->ez_security.ez_scan_timer,
			wdev->ez_security.ez_scan_timer_running);

	}
	else 
#endif
	{
#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(ad, IW_WH_EZ_PROVIDER_SEARCHING, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_PROVIDER_SEARCHING,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
		if (wdev->ez_security.first_scan) {
			wdev->ez_security.first_scan = FALSE;
			ApSiteSurvey_by_wdev(ad, NULL, SCAN_ACTIVE, FALSE, wdev);

			if (!wdev->ez_security.ez_stop_scan_timer_running) {
#ifdef EZ_NETWORK_MERGE_SUPPORT			
							//! first send an action frame to EZ peers so that they do not disconnect
			for (index = 0; index < EZ_MAX_STA_NUM; index ++)
			{
				if (ap_wdev->ez_peer_table[index].port_secured){
					send_action_delay_disconnect(ad, ap_wdev,&ap_wdev->ez_peer_table[index]);
				}
			}
#endif			
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s - set full channel scan stop timer here.\n", __FUNCTION__));
				wdev->ez_security.ez_stop_scan_timer_running = TRUE;
				RTMPSetTimer(&wdev->ez_security.ez_stop_scan_timer, EZ_STOP_SCAN_TIME_OUT);
			}

			return FALSE;
		}

		if (!wdev->ez_security.ez_scan_timer_running) {
			UINT random_time;

			random_time = (UINT)(RandomByte(ad)*100);
			if (random_time > EZ_MAX_SCAN_TIME_OUT)
				random_time = EZ_MAX_SCAN_TIME_OUT;
			MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_OFF, 
				("(%s) Set scan timer(random_time = %d) and wait scan result.\n", __FUNCTION__, random_time));
			RTMPSetTimer(&wdev->ez_security.ez_scan_timer, random_time);
			wdev->ez_security.ez_scan_timer_running = TRUE;
		}

	}
	return FALSE;
}
#endif
VOID ez_scan_timeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	struct _ez_security *ez_sec_info;
	RTMP_ADAPTER *ad;
	struct wifi_dev *wdev;
    BOOLEAN scan_paused = FALSE;

	if (FunctionContext) {
		ez_sec_info = (struct _ez_security *)FunctionContext;
		ad = (RTMP_ADAPTER *)ez_sec_info->ad;
		wdev = (struct wifi_dev *)ez_sec_info->wdev;
		if (ez_sec_info->ez_scan_timer_running) {
			ez_sec_info->ez_scan_timer_running = FALSE;

			RTMP_SEM_LOCK(&ez_sec_info->ez_scan_pause_timer_lock);
            if(ez_sec_info->ez_scan_pause_timer_running)
				scan_paused = TRUE;
			RTMP_SEM_UNLOCK(&ez_sec_info->ez_scan_pause_timer_lock);

            if(!scan_paused){

				if (!ez_sec_info->ez_stop_scan_timer_running){
#ifndef EZ_NETWORK_MERGE_SUPPORT
				    wdev->ez_security.scan_one_channel = TRUE;
#endif
                }
				wdev->ez_security.ez_scan = TRUE;
				ApSiteSurvey_by_wdev(ad, NULL, SCAN_ACTIVE, FALSE, wdev);
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("%s - Scan for finding ap.\n",
					__FUNCTION__));
            }
			else{
			    EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				    ("%s - Scan paused.\n", 
				    __FUNCTION__));
			}

		}
		else {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
				("%s - Timer expired but timer running flag is FALSE. Do nothing here.\n", 
				__FUNCTION__));
		}
	}
	else {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s - FunctionContext is null?? CHECK!!\n", __FUNCTION__));
	}
}

VOID ez_stop_scan_timeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	struct _ez_security *ez_sec_info;
	RTMP_ADAPTER *ad;
	struct wifi_dev *wdev;
	//struct wifi_dev *ap_wdev;

	if (FunctionContext) {
		ez_sec_info = (struct _ez_security *)FunctionContext;
		ad = (RTMP_ADAPTER *)ez_sec_info->ad;
		wdev = (struct wifi_dev *)ez_sec_info->wdev;
		if (ez_sec_info->ez_stop_scan_timer_running) {
			ez_sec_info->ez_stop_scan_timer_running = FALSE;
			if (ez_sec_info->ez_scan_timer_running) {
				EZ_CANCEL_TIMER(&ez_sec_info->ez_scan_timer,
					ez_sec_info->ez_scan_timer_running);
			}
			//ez_sec_info->keep_finding_provider = FALSE;  allow finding provider on Ap Channel
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
				("%s - Stop all channel provider search. Continue search on own Ap channel.\n",
				__FUNCTION__));
#ifndef EZ_NETWORK_MERGE_SUPPORT
			wdev->ez_security.scan_one_channel = TRUE;
#endif

		    //ap_wdev = &ad->ApCfg.MBSSID[wdev->func_idx].wdev;			
			//ap_wdev->ez_security.scan_one_channel = TRUE;

#ifdef SYSTEM_LOG_SUPPORT
			RTMPSendWirelessEvent(ad, IW_WH_EZ_PROVIDER_STOP_SEARCHING, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
			RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_PROVIDER_STOP_SEARCHING,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
		}
		else {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("%s - Timer expired but timer running flag is FALSE. Do nothing here.\n", 
				__FUNCTION__));
		}
	}
	else {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s - FunctionContext is null?? CHECK!!\n", __FUNCTION__));
	}
}

#ifdef EZ_NETWORK_MERGE_SUPPORT
void EzStartGroupMergeTimer(struct _ez_security *ez_sec_info)
{
	ez_sec_info->ez_group_merge_timer_running = TRUE;
	RTMPSetTimer(&ez_sec_info->ez_group_merge_timer, EZ_GROUP_MERGE_TIMEOUT);
}
VOID ez_group_merge_timeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	struct _ez_security *ez_sec_info;
	struct wifi_dev *wdev;
	wdev = (struct wifi_dev *)FunctionContext;
	ez_sec_info = &wdev->ez_security;
	ez_sec_info->ez_group_merge_timer_running = FALSE;
	NdisZeroMemory(ez_sec_info->merge_peer_addr, MAC_ADDR_LEN);
	EZ_CLEAR_CAP_ALLOW_MERGE(ez_sec_info->capability);
	if (wdev->wdev_type == WDEV_TYPE_AP)
	{
		UpdateBeaconHandler(ez_sec_info->ad, wdev, BCN_UPDATE_IE_CHG);
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Beacon Updated\n"));
	}
}

#endif
VOID ez_scan_pause_timeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	struct _ez_security *ez_sec_info;
	RTMP_ADAPTER *ad;
	struct wifi_dev *wdev;
#ifdef APCLI_SUPPORT
	APCLI_STRUCT *apcli_entry;
#endif

	if (FunctionContext) {
		ez_sec_info = (struct _ez_security *)FunctionContext;
		ad = (RTMP_ADAPTER *)ez_sec_info->ad;
		wdev = (struct wifi_dev *)ez_sec_info->wdev;

		RTMP_SEM_LOCK(&ez_sec_info->ez_scan_pause_timer_lock);

		if (ez_sec_info->ez_scan_pause_timer_running) {
			ez_sec_info->ez_scan_pause_timer_running = FALSE;

#ifdef APCLI_SUPPORT
			/* Timeout for peer apcli to conenct to my ap is over.
			     Allow scan on apcli interface now.
			*/
			apcli_entry = &ad->ApCfg.ApCliTab[wdev->func_idx];
			apcli_entry->stop_auto_connect = FALSE;

            // Let internal periodic apcli join logic handle when to resume scan

#endif /* APCLI_SUPPORT */			

		}
		else {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
				("%s - Timer expired but timer running flag is FALSE. Do nothing here.\n", 
				__FUNCTION__));
		}

		RTMP_SEM_UNLOCK(&ez_sec_info->ez_scan_pause_timer_lock);

	}
	else {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s - FunctionContext is null?? CHECK!!\n", __FUNCTION__));
	}
}

#ifdef WSC_AP_SUPPORT
static void ez_updage_ap_wsc_profile(
	RTMP_ADAPTER *ad,
	struct wifi_dev *wdev,
	unsigned char if_idx)
{
	WSC_CTRL *wsc_ctrl;

	wsc_ctrl = &ad->ApCfg.MBSSID[if_idx].wdev.WscControl;
	os_zero_mem(&wsc_ctrl->WpaPsk[0], LEN_PSK);
	wsc_ctrl->WpaPskLen = strlen(wdev->SecConfig.PSK);
	NdisCopyMemory(&wsc_ctrl->WpaPsk[0], wdev->SecConfig.PSK, wsc_ctrl->WpaPskLen);
#ifdef APCLI_SUPPORT
	if ((wdev->wdev_type == WDEV_TYPE_APCLI)
		&& (ad->ApCfg.MBSSID[if_idx].wdev.enable_easy_setup)) {
		struct _SECURITY_CONFIG *ap_sec_cfg;
		ap_sec_cfg = &ad->ApCfg.MBSSID[if_idx].wdev.SecConfig;
		os_zero_mem(ap_sec_cfg->PSK, sizeof(ap_sec_cfg->PSK));
		NdisCopyMemory(ap_sec_cfg->PSK, wdev->SecConfig.PSK, sizeof(ap_sec_cfg->PSK));
	}
#endif /* APCLI_SUPPORT */
	wsc_ctrl->WscConfStatus = WSC_SCSTATE_CONFIGURED;
}
#endif /* WSC_AP_SUPPORT */

static void ez_update_security_setting(
	RTMP_ADAPTER *ad,
	struct wifi_dev *wdev,
	unsigned char *pmk)
{
	int i;
	unsigned char *ptr;

	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("------> %s()\n", __FUNCTION__));

	NdisCopyMemory(&wdev->SecConfig.PMK[0], pmk, LEN_PMK);
	hex_dump("wdev_pmk", &wdev->SecConfig.PMK[0], LEN_PMK);
	ptr = &wdev->SecConfig.PSK[0];
	NdisZeroMemory(ptr, sizeof(wdev->SecConfig.PSK));
	for (i = 0; i < LEN_PMK; i++) {
		snprintf(ptr, (LEN_PSK+1), "%s%02x", ptr, pmk[i]);
	}
	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_INFO, 
			("%s() wdev->SecConfig.PSK: %s (%d)\n", 
			__FUNCTION__, wdev->SecConfig.PSK, (int)strlen(wdev->SecConfig.PSK)));	
	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("<------ %s()\n", __FUNCTION__));
}
#ifdef EZ_NETWORK_MERGE_SUPPORT
#ifdef EZ_PUSH_BW_SUPPORT
static void update_ap_peer_record(RTMP_ADAPTER *pAd, void * wdev, BOOLEAN this_band_changed, BOOLEAN other_band_changed)
{

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s >>>\n",__FUNCTION__));

	if(this_band_changed)
		ez_update_this_band_ap_peer_record(pAd, wdev);

	if(other_band_changed)	
		ez_update_other_band_ap_peer_record(pAd, wdev);

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s <<<\n",__FUNCTION__));

}

static void update_cli_peer_record(RTMP_ADAPTER *pAd, void * wdev, BOOLEAN this_band_changed, BOOLEAN other_band_changed)
{
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s >>>\n",__FUNCTION__));

	if(this_band_changed)
		ez_update_this_band_cli_peer_record(pAd, wdev);

	if(other_band_changed)
		ez_update_other_band_cli_peer_record(pAd, wdev);
	
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s <<<\n",__FUNCTION__));

}

static void update_peer_record(RTMP_ADAPTER *pAd, void * wdev, BOOLEAN this_band_changed, BOOLEAN other_band_changed)
{
	if(!pAd->push_bw_config)
		return;

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s >>>\n",__FUNCTION__));

	update_ap_peer_record(pAd, wdev, this_band_changed, other_band_changed);

	update_cli_peer_record(pAd, wdev, this_band_changed, other_band_changed);

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s <<<\n",__FUNCTION__));

}
#endif

BOOLEAN push_and_update_ap_config(RTMP_ADAPTER *pAd, void * wdev, updated_configs_t *updated_configs, BOOL group_id_diff)
{

	BOOLEAN action_sent = FALSE;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s >>>\n",__FUNCTION__));

	if (ez_update_this_band_ap(pAd, wdev, updated_configs, group_id_diff))
	{
		action_sent = TRUE;
	}
	
	if (ez_update_other_band_ap(pAd, wdev, updated_configs, group_id_diff))
	{
		action_sent = TRUE;
	}
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s <<<\n",__FUNCTION__));
	return action_sent;
}


BOOLEAN push_and_update_cli_config(RTMP_ADAPTER *pAd, void * wdev, updated_configs_t *updated_configs, BOOL group_id_diff)
{
	BOOLEAN action_sent = FALSE;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s >>>\n",__FUNCTION__));

	if (ez_update_this_band_cli(pAd, wdev, updated_configs, group_id_diff))
	{
		action_sent = TRUE;
	}
	
	if (ez_update_other_band_cli(pAd, wdev, updated_configs, group_id_diff))
	{
		action_sent = TRUE;
	}
	
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s <<<\n",__FUNCTION__));
	return action_sent;

}

/*this function is called to push own weight to all connected devices.*/
void update_and_push_weight(void *wdev_obj, void * pEntry_obj, unsigned char * network_weight)
{
	struct wifi_dev *wdev = wdev_obj;
	PRTMP_ADAPTER ad = wdev->sys_handle;
	//struct _ez_security *ez_sec_info = &wdev->ez_security;
	BOOLEAN action_sent = FALSE;
	PMAC_TABLE_ENTRY pEntry = pEntry_obj;
	updated_configs_t updated_configs;			
	channel_info_t current_chan_info;
	struct wifi_dev *ap_wdev = NULL;
	BOOLEAN this_band_changed = FALSE;

#ifdef DUAL_CHIP
		PRTMP_ADAPTER adOthBand = NULL;
		if (!IS_SINGLE_CHIP_DBDC(ad)){
			adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
			if(adOthBand == NULL){
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
						("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
				ASSERT(FALSE);
			}
		}
#endif
		ez_update_connection_permission(wdev->sys_handle,wdev,EZ_DISALLOW_ALL);
	//! run loop for all active AP interfaces
	if (pEntry == NULL){
		//! Weight providing link gone, assign self weight.
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("WDL Gone, assign self params\n"));
		NdisZeroMemory(wdev->ez_security.device_info.weight_defining_link.peer_mac, MAC_ADDR_LEN);
		NdisZeroMemory(wdev->ez_security.device_info.weight_defining_link.peer_ap_mac, MAC_ADDR_LEN);
		if (IS_SINGLE_CHIP_DBDC(ad))
			NdisCopyMemory(&wdev->ez_security.device_info.network_weight[1],ad->ApCfg.MBSSID[0].wdev.bssid,MAC_ADDR_LEN);
#ifdef DUAL_CHIP
		else {
			if(wdev->channel <= 14)
				NdisCopyMemory(&wdev->ez_security.device_info.network_weight[1],ad->ApCfg.MBSSID[0].wdev.bssid,MAC_ADDR_LEN);
			else
				NdisCopyMemory(&wdev->ez_security.device_info.network_weight[1], adOthBand->ApCfg.MBSSID[0].wdev.bssid,MAC_ADDR_LEN);	
		}
#endif
		if (wdev->ez_security.user_configured) {
			wdev->ez_security.device_info.network_weight[0] = 0xF;
		} else 
#ifdef WEIGHT_DEPENDS_ON_INET
		if (wdev->ez_security.go_internet) {
			wdev->ez_security.device_info.network_weight[0] = 0xE;
		} else 
#endif
		{
			wdev->ez_security.device_info.network_weight[0] = 0x0;

		}

		ez_allocate_node_number(ad,&wdev->ez_security.device_info.ez_node_number,wdev->func_idx);

	} else {
		APCLI_STRUCT *apcli_entry = &ad->ApCfg.ApCliTab[wdev->func_idx];;

		ap_wdev = &ad->ApCfg.MBSSID[wdev->func_idx].wdev;

		wdev->ez_security.keep_finding_provider = FALSE;
		NdisCopyMemory(wdev->ez_security.this_band_info.shared_info.ssid,apcli_entry->Ssid,apcli_entry->SsidLen);
		wdev->ez_security.this_band_info.shared_info.ssid_len = apcli_entry->SsidLen;
		NdisCopyMemory(wdev->ez_security.this_band_info.pmk, pEntry->SecConfig.PMK,PMK_LEN);
		EZ_CANCEL_TIMER(&wdev->ez_security.ez_scan_timer, 
			wdev->ez_security.ez_scan_timer_running);
		EZ_CANCEL_TIMER(&wdev->ez_security.ez_stop_scan_timer, 
			wdev->ez_security.ez_stop_scan_timer_running);

		RTMP_SEM_LOCK(&wdev->ez_security.ez_scan_pause_timer_lock);
		EZ_CANCEL_TIMER(&wdev->ez_security.ez_scan_pause_timer,
			wdev->ez_security.ez_scan_pause_timer_running);
		apcli_entry->stop_auto_connect = FALSE;
		RTMP_SEM_UNLOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);

#if 0//def EZ_ROAM_SUPPORT    Todo: Third Party Roam handling
		if(!MAC_ADDR_EQUAL(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR))
		{
			NdisZeroMemory(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,MAC_ADDR_LEN);
			NdisZeroMemory(ap_wdev->ez_security.ez_ap_roam_blocked_mac,MAC_ADDR_LEN);
		}
#endif

		// 08/2016 : Rakesh: when channel switch happens on A band, currently many events are seen which delay other Rx
		// causing Link loss. Workaround to delay linkloss
		wdev->ez_security.delay_disconnect_count = ad->ez_delay_disconnect_count;
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Delay linkloss detection during Third party config adapt\n"));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("1 update & push index = %d, delay_disconnect_count=%d\n",
									wdev->wdev_idx, wdev->ez_security.delay_disconnect_count));

		//! I am taking configuration from this peer so this becomes my weight providing link.
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Updating to WDL\n"));
		NdisCopyMemory(wdev->ez_security.device_info.weight_defining_link.peer_mac, pEntry->Addr, MAC_ADDR_LEN);
		NdisCopyMemory(wdev->ez_security.device_info.weight_defining_link.peer_ap_mac, pEntry->Addr, MAC_ADDR_LEN);
		NdisCopyMemory(&wdev->ez_security.device_info.network_weight[1], pEntry->Addr,MAC_ADDR_LEN);
		
		NdisGetSystemUpTime(&wdev->ez_security.device_info.weight_defining_link.ap_time_stamp);
		NdisGetSystemUpTime(&wdev->ez_security.device_info.weight_defining_link.time_stamp);
		wdev->ez_security.device_info.weight_defining_link.wdev = wdev;

		// Note: Backup current OPERATING params i.e. NOT CONFIG params
		NdisZeroMemory(&current_chan_info, sizeof(current_chan_info));
		current_chan_info.channel = wdev->channel;
#ifdef EZ_PUSH_BW_SUPPORT
		if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
		{
			current_chan_info.ht_bw = wlan_operate_get_ht_bw(wdev); // operating ht bw
			current_chan_info.vht_bw = wlan_operate_get_vht_bw(wdev);// operating vht bw
		}
#endif
		current_chan_info.extcha= wlan_operate_get_ext_cha(wdev); // operating ext cha

		ez_restore_channel_config(ap_wdev);

		if( (wdev->ez_security.this_band_info.shared_info.channel_info.channel != current_chan_info.channel) ||
#ifdef EZ_PUSH_BW_SUPPORT
			( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config && 
			  ((wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw != current_chan_info.ht_bw ) ||
			  (wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw != current_chan_info.vht_bw ))) ||
#endif
			(wdev->ez_security.this_band_info.shared_info.channel_info.extcha != current_chan_info.extcha) )
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("This Band Info different \n"));
	
			this_band_changed = TRUE;
		}

		wdev->ez_security.this_band_info.shared_info.channel_info.channel= current_chan_info.channel;
#ifdef EZ_PUSH_BW_SUPPORT
		if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
		{
			wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw = current_chan_info.ht_bw;
			wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw = current_chan_info.vht_bw;
		}
#endif
		wdev->ez_security.this_band_info.shared_info.channel_info.extcha= current_chan_info.extcha;

#ifdef DOT11R_FT_SUPPORT // MdId will not be changed on conenction to third party Ap
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s::FtMdid =%c%c\n", __FUNCTION__,
		//							wdev->ez_security.this_band_info.shared_info.FtMdId[0],
		//							wdev->ez_security.this_band_info.shared_info.FtMdId[1]));
#endif


		wdev->ez_security.device_info.network_weight[0] = 0xF;
		
		COPY_MAC_ADDR(wdev->ez_security.this_band_info.cli_peer_ap_mac, pEntry->bssid);
				
		
		COPY_MAC_ADDR(ap_wdev->ez_security.this_band_info.cli_peer_ap_mac, pEntry->bssid);
		ez_apcli_allocate_self_node_number(&wdev->ez_security.device_info.ez_node_number,pEntry);

	}

	ez_inform_all_interfaces(wdev->sys_handle,wdev,ACTION_UPDATE_DEVICE_INFO);
	//! initialize a local structure that will hold all the inforation to be pushed to peer AP
	NdisZeroMemory(&updated_configs, sizeof(updated_configs_t));
	ez_init_updated_configs_for_push(&updated_configs, wdev);

	updated_configs.device_info.network_weight[0] |= BIT(7);

	if (pEntry == NULL){ // when disconnected
		updated_configs.context_linkdown = TRUE;
	}
	
	if (push_and_update_ap_config(wdev->sys_handle, wdev, &updated_configs,FALSE)){
		action_sent = TRUE;
	}
	if (push_and_update_cli_config(wdev->sys_handle, wdev, &updated_configs,FALSE))
	{
		action_sent = TRUE;
	}
	
#ifdef EZ_ROAM_SUPPORT
	if(pEntry != NULL && !MAC_ADDR_EQUAL(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR))
	{
		NdisZeroMemory(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,MAC_ADDR_LEN);
		NdisZeroMemory(ap_wdev->ez_security.ez_ap_roam_blocked_mac,MAC_ADDR_LEN);
		ez_update_connection_permission(ad, wdev,EZ_DEQUEUE_PERMISSION);
	}
#endif

	if (action_sent == FALSE)
	{
		ez_update_connection_permission(wdev->sys_handle,wdev,EZ_ALLOW_ALL_TIMEOUT);
	}

	if (pEntry && ap_wdev){ // move back to third party ap channel
		//! switch back APCli channel to target channel
		ez_restore_channel_config(ap_wdev);
#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3))
		if(ap_wdev->ez_security.ap_did_fallback){
			if(ap_wdev->ez_security.fallback_channel != ap_wdev->ez_security.this_band_info.shared_info.channel_info.channel){
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("\nupdate_and_push_weight: Last channel(%d) and current channel(%d) different, reset fallback context\n",
					ap_wdev->ez_security.fallback_channel, ap_wdev->ez_security.this_band_info.shared_info.channel_info.channel));
				ez_set_ap_fallback_context(ap_wdev,FALSE,0);
			}
		}
#endif
		UpdateBeaconHandler(ad, ap_wdev, BCN_UPDATE_IE_CHG);
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			("Central channel = %d\n", wlan_operate_get_cen_ch_1(ap_wdev)));

#ifdef EZ_PUSH_BW_SUPPORT
		// as CLI conencted, it's peer record should be already correct
		// update AP peer info to new config only for this band
		if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config && this_band_changed){
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Change AP peer records as this band changed\n"));
			ez_update_this_band_ap_peer_record(wdev->sys_handle, wdev);
		}
#endif
	}
	
}

void ez_init_updated_configs_for_adapt(updated_configs_t *updated_config, struct _ez_peer_security_info *ez_peer, struct wifi_dev* wdev)
{
	channel_info_t null_channel_info;
	NdisZeroMemory(&null_channel_info,sizeof(null_channel_info));
	//! copy MAC adrss of the peer from where the config are received so that we do not send them back to the same peer
	COPY_MAC_ADDR(updated_config->mac_addr, ez_peer->mac_addr);

	//! take peer device configurations like weight and node number, node number will be update din the end while sending fram to specific peer
	NdisCopyMemory(&updated_config->device_info, &ez_peer->device_info,sizeof(device_info_t));

	//! TODO: RAGHAV update peer node number here, peer previously sent the weight that we should adapt, now we need to restore it for future refference.
	//! take current band info
	NdisCopyMemory(&updated_config->this_band_info, &ez_peer->this_band_info,sizeof(interface_info_t));
	//! take other band info
	NdisCopyMemory(&updated_config->other_band_info, &ez_peer->other_band_info,sizeof(interface_info_t));
	if(NdisEqualMemory(&null_channel_info,&updated_config->other_band_info.shared_info.channel_info,sizeof(channel_info_t)))
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("peer other band channel info is NULL\n"));
		updated_config->other_band_info.interface_activated = FALSE;
	} else {
			updated_config->other_band_info.interface_activated = TRUE;
	}
	updated_config->this_band_info.interface_activated = TRUE;
	
	//! init pointer to group ID

	updated_config->group_id = ez_peer->group_id;
	updated_config->group_id_len = ez_peer->group_id_len;

	//! init open group ID
	updated_config->open_group_id_len = ez_peer->open_group_id_len;
	NdisCopyMemory(updated_config->open_group_id, ez_peer->open_group_id, ez_peer->open_group_id_len);
	
	//! I am taking configuration from this peer so this becomes my weight providing link.
	NdisCopyMemory(wdev->ez_security.device_info.network_weight,ez_peer->device_info.network_weight, NETWORK_WEIGHT_LEN);
	NdisCopyMemory(&wdev->ez_security.device_info.ez_node_number,&ez_peer->device_info.ez_node_number, sizeof(EZ_NODE_NUMBER));
	// ez_peer->device_info.ez_node_number is overloaded to the node number of the own device that is to be allocated.
	//restore it once the allocation is done.
	ez_restore_node_number(&ez_peer->device_info.ez_node_number);
	
	NdisCopyMemory(wdev->ez_security.device_info.weight_defining_link.peer_mac,ez_peer->mac_addr,MAC_ADDR_LEN);
	NdisCopyMemory(wdev->ez_security.device_info.weight_defining_link.peer_ap_mac,ez_peer->this_band_info.shared_info.ap_mac_addr,MAC_ADDR_LEN);
	NdisGetSystemUpTime(&wdev->ez_security.device_info.weight_defining_link.ap_time_stamp);
	hex_dump("peer_ap_mac", ez_peer->this_band_info.shared_info.ap_mac_addr, 6);
	NdisGetSystemUpTime(&wdev->ez_security.device_info.weight_defining_link.time_stamp);
	wdev->ez_security.device_info.weight_defining_link.wdev = wdev;
											
	ez_inform_all_interfaces(wdev->sys_handle,wdev,ACTION_UPDATE_DEVICE_INFO);
}

void ez_init_updated_configs_for_push(updated_configs_t *updated_config, struct wifi_dev* wdev)
{

	NdisCopyMemory(&updated_config->this_band_info, &wdev->ez_security.this_band_info , sizeof(interface_info_t));
	if (ez_get_other_band_info(wdev->sys_handle, wdev, &updated_config->other_band_info)){
	} else {
		NdisZeroMemory(&updated_config->other_band_info.shared_info, sizeof(interface_info_tag_t));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("otherband interface not activated\n"));
		if (wdev->ez_security.other_band_info_backup.interface_activated)
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_init_updated_configs_for_push --->will use backup\n"));
			updated_config->other_band_info.shared_info.ssid_len = wdev->ez_security.other_band_info_backup.shared_info.ssid_len;
			NdisCopyMemory(updated_config->other_band_info.shared_info.ssid, wdev->ez_security.other_band_info_backup.shared_info.ssid, wdev->ez_security.other_band_info_backup.shared_info.ssid_len);
			NdisCopyMemory(&updated_config->other_band_info.shared_info.channel_info, &wdev->ez_security.other_band_info_backup.shared_info.channel_info, sizeof(channel_info_t));
#ifdef DOT11R_FT_SUPPORT
			FT_SET_MDID(updated_config->other_band_info.shared_info.FtMdId,wdev->ez_security.other_band_info_backup.shared_info.FtMdId);
#endif
		}

	}
	COPY_MAC_ADDR(updated_config->mac_addr, wdev->ez_security.device_info.weight_defining_link.peer_mac);
	NdisCopyMemory(&updated_config->device_info, &wdev->ez_security.device_info,sizeof(device_info_t));
	updated_config->group_id = wdev->ez_security.group_id;
	updated_config->group_id_len= wdev->ez_security.group_id_len;
	updated_config->open_group_id_len= wdev->ez_security.open_group_id_len;
	NdisCopyMemory(updated_config->open_group_id,wdev->ez_security.open_group_id,wdev->ez_security.open_group_id_len);

}

#ifdef EZ_PUSH_BW_SUPPORT
static void ez_chk_bw_config_different(struct wifi_dev* wdev, struct _ez_peer_security_info *ez_peer, BOOLEAN *pthis_band_changed, BOOLEAN *pOther_band_changed)
{
	interface_info_t *peer_this_band_info = NULL;
	interface_info_t *peer_other_band_info = NULL;
	interface_info_t *own_this_band_info = NULL;

	interface_info_t own_other_band_info;

	struct _ez_security *ez_sec_info = &wdev->ez_security;

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("ez_bw_config_different ----> \n"));

	*pthis_band_changed = FALSE;
	*pOther_band_changed = FALSE;

	if(!ez_sec_info || !ez_peer){
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_bw_config_different: invalid params \n"));
	}

	peer_this_band_info = &ez_peer->this_band_info;
	peer_other_band_info = &ez_peer->this_band_info;

	own_this_band_info = &ez_sec_info->this_band_info;

	// check for interface_activated ??
	if( (own_this_band_info->shared_info.channel_info.channel != peer_this_band_info->shared_info.channel_info.channel) ||
		( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config && 
		  ((own_this_band_info->shared_info.channel_info.ht_bw != peer_this_band_info->shared_info.channel_info.ht_bw ) ||
		  (own_this_band_info->shared_info.channel_info.vht_bw != peer_this_band_info->shared_info.channel_info.vht_bw ))) ||
		(own_this_band_info->shared_info.channel_info.extcha != peer_this_band_info->shared_info.channel_info.extcha) )
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("ez_chk_bw_config_different: This Band Info different \n"));
		*pthis_band_changed = TRUE;
	}

	NdisZeroMemory(&own_other_band_info,sizeof(interface_info_t));
	// check for interface_activated ??
	if(ez_get_other_band_info(ez_sec_info->ad,ez_sec_info->wdev,&own_other_band_info)){

		if( (own_other_band_info.shared_info.channel_info.channel != peer_other_band_info->shared_info.channel_info.channel) ||
			( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config && 
			  ((own_other_band_info.shared_info.channel_info.ht_bw != peer_other_band_info->shared_info.channel_info.ht_bw ) ||
			  (own_other_band_info.shared_info.channel_info.vht_bw != peer_other_band_info->shared_info.channel_info.vht_bw ))) ||
			(own_other_band_info.shared_info.channel_info.extcha != peer_other_band_info->shared_info.channel_info.extcha) )
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("ez_chk_bw_config_different: Other band Info different \n"));
			*pOther_band_changed = TRUE;
		}
	}
#if 0
	else if(ez_sec_info->other_band_info_backup.interface_activated){
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_chk_bw_config_different: Backup other Band Info diff\n"));

		if( NdisCmpMemory(&ez_sec_info->other_band_info_backup.shared_info.channel_info,
				&peer_other_band_info->shared_info.channel_info,
				sizeof(channel_info_t)) != 0 ){
			*pOther_band_changed = TRUE;
		}		
	}
#endif
	else{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_chk_bw_config_different: Other band Info not obtained \n"));
	}

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_bw_config_different: ThisBandChng:%x, OtherBandChng:%x \n", *pthis_band_changed, *pOther_band_changed));

}
#endif
enum_config_update_action_t push_and_update_config(void *ad_obj , struct wifi_dev *wdev,
	struct _ez_peer_security_info *ez_peer, 
	BOOL check_for_weight, 
	BOOL from_port_secured,
	BOOL surely_a_group_merge
	)
{
	struct wifi_dev *ap_wdev;
	struct _ez_security *ez_sec_info;
	unsigned int peer_groupid_len = ez_peer->group_id_len;
	unsigned char *peer_groupid = ez_peer->group_id;
	int group_id_different = FALSE;
	int if_index   =  wdev->func_idx;
	BOOL is_apcli  = (wdev->wdev_type == WDEV_TYPE_APCLI);
	RTMP_ADAPTER *pAd = ad_obj;	
	int i;
	enum_config_update_action_t config_update_action = ACTION_ADAPT;
	
	BSS_STRUCT *mbss;
	APCLI_STRUCT *apcli_entry;
	/*
		Update my apclient SSID/AuthMode/EncrypType setting
	*/
	mbss = &pAd->ApCfg.MBSSID[if_index]; 
	apcli_entry = 	&pAd->ApCfg.ApCliTab[if_index];	
	ap_wdev = &pAd->ApCfg.MBSSID[if_index].wdev;

	ez_sec_info = &wdev->ez_security;
	//! we need not check for weight if, 
	//! function is called from port ecured when same interface AP was not in a configured state, or
	//! function is called while processing a group ID update action frame
	if (check_for_weight)
	{
		for (i = 0; i < NETWORK_WEIGHT_LEN; i++)
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%x:%x\t", ez_peer->device_info.network_weight[i], ez_sec_info->device_info.network_weight[i]));
			if (ez_peer->device_info.network_weight[i] > ez_sec_info->device_info.network_weight[i])
			{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("---> ACTION_ADAPT\n"));
				config_update_action = ACTION_ADAPT;
				break;
			} else if (ez_peer->device_info.network_weight[i] < ez_sec_info->device_info.network_weight[i]){
				config_update_action = ACTION_PUSH;
				break;
			} else if (ez_peer->device_info.network_weight[i] == ez_sec_info->device_info.network_weight[i]){
				config_update_action = ACTION_NOTHING;
			}
			}
		}
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\n"));
	if (config_update_action == ACTION_NOTHING)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Assert!!! ACTION_NOTHING\n"));

	}
	//! group ID comparision
	if (((wdev->ez_security.group_id_len != peer_groupid_len) ||
		!NdisEqualMemory(wdev->ez_security.group_id, peer_groupid, peer_groupid_len)))
	{
		group_id_different = TRUE;
		ez_hex_dump("wdev->ez_security.group_id",wdev->ez_security.group_id,wdev->ez_security.group_id_len);
		ez_hex_dump("peer_groupid", peer_groupid, peer_groupid_len);
		//! group ID is different, yet we need not update configuration if:
		//! function is called from port secured of AP interface, or
		//! function is called from action frame processing but group ID update bit is not set
		if ((from_port_secured && !is_apcli) || (!from_port_secured && !surely_a_group_merge))
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("---> ACTION_NOTHING\n"));
			config_update_action = ACTION_NOTHING;
		} else if ((from_port_secured && is_apcli) || (!from_port_secured && surely_a_group_merge)) {
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("---> ACTION_ADAPT\n"));
			config_update_action = ACTION_ADAPT;
		} else {
#ifdef DBG		
			ASSERT(FALSE);
#endif
		}
	}

	//! if we need to update the configuration	
	if (config_update_action == ACTION_ADAPT)
	{
		updated_configs_t updated_configs;
		BOOLEAN action_sent = FALSE;
#ifdef EZ_PUSH_BW_SUPPORT
		BOOLEAN this_band_changed = FALSE;
		BOOLEAN other_band_changed = FALSE;

		//if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
			ez_chk_bw_config_different(wdev,ez_peer,&this_band_changed,&other_band_changed);
#endif
		if(is_apcli){
			// no need to restore channel in case of AP as it is already on the same channel.
			ez_restore_channel_config(ap_wdev);
		// 08/2016 : Rakesh: when channel switch happens on A band, currently many events are seen which delay other Rx
			// causing Link loss. Workaround to delay linkloss.
			wdev->ez_security.delay_disconnect_count = pAd->ez_delay_disconnect_count;
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Delay linkloss detection during config adapt, delay_disconnect_count=%d\n", 
																	pAd->ez_delay_disconnect_count));

		}
		
		//! copy configurations to be adapted from the ez_peer and send update configuration to connected peers
		NdisZeroMemory(&updated_configs, sizeof(updated_configs_t));
		ez_init_updated_configs_for_adapt(&updated_configs, ez_peer, wdev);
		
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("updated_configs->ssid --- > %s\n", updated_configs.this_band_info.shared_info.ssid));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("updated_configs->other_band ssid --- > %s\n", updated_configs.other_band_info.shared_info.ssid));
		
		if ( push_and_update_ap_config(pAd, wdev, &updated_configs, group_id_different))
		{
			action_sent = TRUE;
		}
		if (push_and_update_cli_config(pAd, wdev, &updated_configs, group_id_different))
		{
			action_sent = TRUE;
		}
		//! run loop for all CLI interfaces
		if (action_sent == FALSE)
		{
			
			//ez_update_connection_permission(pAd,NULL,EZ_ALLOW_ALL);
			ez_update_connection_permission(pAd,wdev,EZ_ALLOW_ALL);
		}

		//! switch back AP channel to target channel

		ez_restore_channel_config(ap_wdev);
#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3))
		if(ap_wdev->ez_security.ap_did_fallback){
			if(ap_wdev->ez_security.fallback_channel != ap_wdev->ez_security.this_band_info.shared_info.channel_info.channel){
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("\npush_and_update_config:Last channel(%d) and current channel(%d) different, reset fallback context\n",
					ap_wdev->ez_security.fallback_channel, ap_wdev->ez_security.this_band_info.shared_info.channel_info.channel));
				ez_set_ap_fallback_context(ap_wdev,FALSE,0);
			}
		}
#endif

		UpdateBeaconHandler(pAd, ap_wdev, BCN_UPDATE_IE_CHG);

#ifdef EZ_PUSH_BW_SUPPORT
		//update peer info to new config
		//Rakesh: Optimization can be added of using from_port_secured to avoid updating for connected AP
		if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
			update_peer_record(pAd, wdev, this_band_changed, other_band_changed);
#endif
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Central channel = %d\n",wlan_operate_get_cen_ch_1(wdev)));//! if action frame is received by APCLI, send de-auth	
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Initiate New scan after adapt\n"));
		ez_initiate_new_scan(pAd);

	}
	return config_update_action;
	
}

#endif

static char * ez_CheckAuthMode(UINT32 _AKMMap)
{

	if(IS_AKM_OPEN(_AKMMap))
		return "OPEN";
 	else if(IS_AKM_SHARED(_AKMMap))
		return "SHARED";
	else if(IS_AKM_AUTOSWITCH(_AKMMap))
		return "WEPAUTO";
	else if(IS_AKM_WPA1(_AKMMap)) 
		return "WPA";
  	else if(IS_AKM_WPA1PSK(_AKMMap))
		return "WPAPSK";
 	else if(IS_AKM_WPANONE(_AKMMap))  
		return "WPANONE";
 	else if(IS_AKM_WPA2(_AKMMap))
		return "WPA2";
	else if(IS_AKM_WPA2PSK(_AKMMap))
		return "WPA2PSK";

	return NULL ;
}

static char * ez_CheckEncrypType(UINT32 Cipher)
{
	if (IS_CIPHER_NONE(Cipher))
		return "NONE";
	else if (IS_CIPHER_WEP(Cipher))
		return "WEP";
	else if (IS_CIPHER_TKIP(Cipher))
		return "TKIP";
	else if (IS_CIPHER_CCMP128(Cipher))
		return "AES";
	else if (IS_CIPHER_CCMP256(Cipher))
		return "CCMP256";
	else if (IS_CIPHER_GCMP128(Cipher))
		return "GCMP128";
	else if (IS_CIPHER_GCMP256(Cipher))
		return "GCMP256";
	else if (IS_CIPHER_TKIP(Cipher)||IS_CIPHER_CCMP128(Cipher))
		return "TKIPAES";
	else if (IS_CIPHER_TKIP(Cipher)|| IS_CIPHER_CCMP128(Cipher))
		return "WPA_AES_WPA2_TKIPAES";
#ifdef WAPI_SUPPORT
	else if (IS_CIPHER_WPI_SMS4(Cipher))
		return "SMS4";
	
#endif /* WAPI_SUPPORT */
	else
	{
		return NULL;
	}

}

int ez_parse_set_command(void *ad_obj, RTMP_IOCTL_INPUT_STRUCT *wrq, IN int cmd)
{
        RTMP_ADAPTER *pAd;
	struct wifi_dev *wdev;
	UCHAR inf_idx;
	int Status = NDIS_STATUS_SUCCESS;
	POS_COOKIE pObj;
	pAd = (RTMP_ADAPTER *)ad_obj;
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	inf_idx = pObj->ioctl_if;
	switch(cmd & 0x7FFF)
	{
		
		case OID_WH_EZ_ENABLE:
			inf_idx = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
			if (pObj->ioctl_if_type == INT_APCLI) {
				wdev = &pAd->ApCfg.ApCliTab[inf_idx].wdev;
				if (!pAd->ApCfg.ApCliTab[inf_idx].Enable)
					return FALSE;
	
				MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("IF(apcli%d) %s:: ", 
					inf_idx, __FUNCTION__));
			}
			else 
#endif /* APCLI_SUPPORT */
			{
				wdev = &pAd->ApCfg.MBSSID[inf_idx].wdev;
				MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("IF(ra%d) %s:: ", 
					inf_idx, __FUNCTION__));
			}
		
			if (wrq->u.data.length != sizeof(UCHAR))
				Status = -EINVAL;
			else
			{
				Status = copy_from_user(&wdev->enable_easy_setup, wrq->u.data.pointer, wrq->u.data.length);
					MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:: enable_easy_setup = %d.\n", 
					__FUNCTION__, wdev->enable_easy_setup));
			}
			break;
		
		case OID_WH_EZ_CONF_STATUS:
			inf_idx = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
			if (pObj->ioctl_if_type == INT_APCLI) {
				wdev = &pAd->ApCfg.ApCliTab[inf_idx].wdev;
			if (!pAd->ApCfg.ApCliTab[inf_idx].Enable)
				return FALSE;
		
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("IF(apcli%d) %s:: ", 
				inf_idx, __FUNCTION__));
			}
			else 
#endif /* APCLI_SUPPORT */
			{
				wdev = &pAd->ApCfg.MBSSID[inf_idx].wdev;
				MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("IF(ra%d) %s:: ", 
					inf_idx, __FUNCTION__));
					}
				if (wrq->u.data.length != sizeof(UCHAR))
					Status = -EINVAL;
				else
				{
					Status = copy_from_user(&wdev->ez_security.configured_status, wrq->u.data.pointer, wrq->u.data.length);
					if (wdev->ez_security.configured_status == EZ_CONFIGURED)
					{
						wdev->ez_security.user_configured = TRUE;
					}
					MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:: configured_status = %d.\n", 
						__FUNCTION__, wdev->enable_easy_setup));
				}
				break;
		
			case OID_WH_EZ_GROUP_ID:
				inf_idx = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
				if (pObj->ioctl_if_type == INT_APCLI) {
					wdev = &pAd->ApCfg.ApCliTab[inf_idx].wdev;
				if (!pAd->ApCfg.ApCliTab[inf_idx].Enable)
					return FALSE;
		
					MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					 ("IF(apcli%d) %s:: ", 
					 inf_idx, __FUNCTION__));
				}
				else 
#endif /* APCLI_SUPPORT */
				{
					wdev = &pAd->ApCfg.MBSSID[inf_idx].wdev;
					MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
						("IF(ra%d) %s:: ", 
						inf_idx, __FUNCTION__));
				}
				ez_set_ezgroup_id(&wdev->ez_security, wrq->u.data.pointer, wrq->u.data.length, inf_idx);
				ez_set_group_id(&wdev->ez_security, wrq->u.data.pointer, wrq->u.data.length, inf_idx);
				break;
		
				case OID_WH_EZ_GEN_GROUP_ID:
					inf_idx = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
					if (pObj->ioctl_if_type == INT_APCLI) {
						wdev = &pAd->ApCfg.ApCliTab[inf_idx].wdev;
						if (!pAd->ApCfg.ApCliTab[inf_idx].Enable)
							return FALSE;
		
						MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
							("IF(apcli%d) %s:: ", 
							inf_idx, __FUNCTION__));
					}
					else 
#endif /* APCLI_SUPPORT */
					{
						wdev = &pAd->ApCfg.MBSSID[inf_idx].wdev;
						MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
							("IF(ra%d) %s:: ", 
							inf_idx, __FUNCTION__));
					}
					if (wrq->u.data.length == 0) {
						Status = -EINVAL;
					}
					else {
						Status = ez_set_gen_group_id(&wdev->ez_security, wrq->u.data.pointer, wrq->u.data.length, inf_idx);
					}
					break;
		
				case OID_WH_EZ_RSSI_THRESHOLD:
					inf_idx = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
					if (pObj->ioctl_if_type == INT_APCLI) {
						wdev = &pAd->ApCfg.ApCliTab[inf_idx].wdev;
						if (!pAd->ApCfg.ApCliTab[inf_idx].Enable)
							return FALSE;
		
						MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
							("IF(apcli%d) %s:: ", 
							inf_idx, __FUNCTION__));
					}
					else 
#endif /* APCLI_SUPPORT */
					{
						wdev = &pAd->ApCfg.MBSSID[inf_idx].wdev;
						MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
							("IF(ra%d) %s:: ", 
							inf_idx, __FUNCTION__));
					}
					if (wrq->u.data.length != sizeof(CHAR))
						Status = -EINVAL;
					else
					{
						Status = copy_from_user(&wdev->ez_security.rssi_threshold, wrq->u.data.pointer, wrq->u.data.length);
						MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:: rssi_threshold = %d.\n", 
							__FUNCTION__, wdev->enable_easy_setup));
					}
					break;
					
				case OID_WH_EZ_INTERNET_COMMAND:
					Status = ez_Internet_MsgHandle(pAd, wrq);
					if(Status != NDIS_STATUS_SUCCESS)
					{
						Status = -NDIS_STATUS_FAILURE;
					}
						   
					break;

#ifdef EZ_PUSH_BW_SUPPORT
				case OID_WH_EZ_PUSH_BW:
				{
					PRTMP_ADAPTER adOthBand = NULL;

					if (wrq->u.data.length != sizeof(CHAR))
						Status = -EINVAL;
					else
					{
						Status = copy_from_user(&pAd->push_bw_config, wrq->u.data.pointer, wrq->u.data.length);
						MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:: push_bw_config = %d.\n", 
							__FUNCTION__, pAd->push_bw_config));
					}
#ifdef DUAL_CHIP
					if(!IS_SINGLE_CHIP_DBDC(pAd))
					{
						adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
						if(adOthBand == NULL)
						{
							EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
									("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
							ASSERT(FALSE);
						}
						else
						{
							adOthBand->push_bw_config	= pAd->push_bw_config;
							EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): adOthBand-> Push BW = %d\n", 
																__FUNCTION__, adOthBand->push_bw_config));
						}
					}
#endif
				}
					break;
#endif						
				default:
					MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Set::unknown IOCTL's subcmd = 0x%08x\n", cmd));
					Status = -EOPNOTSUPP;
					break;	
	}
	return Status;
}

int ez_parse_query_command(void *ad_obj, RTMP_IOCTL_INPUT_STRUCT *wrq, IN int cmd)
{
    RTMP_ADAPTER *pAd;
    struct wifi_dev *wdev;
    UCHAR ifIndex;
    POS_COOKIE  pObj;	
    UCHAR apidx;
    BOOLEAN apcliEn=FALSE;
    int Status = NDIS_STATUS_SUCCESS;
	struct ez_GUI_info GUI_info;
	struct wifi_dev *apcli_wdev;
	APCLI_STRUCT *apcli_entry;
    pAd = (RTMP_ADAPTER *)ad_obj;
    pObj = (POS_COOKIE) pAd->OS_Cookie;

    apidx = pObj->ioctl_if;	
	
    switch(cmd & 0x7FFF)
    {
	case OID_WH_EZ_ENABLE:
		ifIndex = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
		if (pObj->ioctl_if_type == INT_APCLI) {
			wdev = &pAd->ApCfg.ApCliTab[ifIndex].wdev;
			apcliEn = pAd->ApCfg.ApCliTab[ifIndex].Enable;
			if (!apcliEn)
				return FALSE;
	
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("IF(apcli%d) %s:: ", 
				ifIndex, __FUNCTION__));
		}
		else 
#endif /* APCLI_SUPPORT */
		{
			wdev = &pAd->ApCfg.MBSSID[ifIndex].wdev;
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("IF(ra%d) %s:: ", 
				ifIndex, __FUNCTION__));
		}
			wrq->u.data.length = sizeof(wdev->enable_easy_setup);
			Status = copy_to_user(wrq->u.data.pointer, &wdev->enable_easy_setup, wrq->u.data.length);
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("Status = %d, enable_easy_setup = %d\n", 
					Status, wdev->enable_easy_setup));
			break;
	
	case OID_WH_EZ_CONF_STATUS:
			ifIndex = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
			if (pObj->ioctl_if_type == INT_APCLI) {
				wdev = &pAd->ApCfg.ApCliTab[ifIndex].wdev;
				apcliEn = pAd->ApCfg.ApCliTab[ifIndex].Enable;
				if (!apcliEn)
					return FALSE;
	
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("IF(apcli%d) %s:: ", 
				ifIndex, __FUNCTION__));
			}
			else 
#endif /* APCLI_SUPPORT */
			{
				wdev = &pAd->ApCfg.MBSSID[ifIndex].wdev;
				MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("IF(ra%d) %s:: ", 
					ifIndex, __FUNCTION__));
			}
	
			wrq->u.data.length = sizeof(wdev->ez_security.configured_status);
			Status = copy_to_user(wrq->u.data.pointer, 
				&wdev->ez_security.configured_status, wrq->u.data.length);
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("Status = %d, configured_status = %d\n", 
				Status, wdev->ez_security.configured_status));
			break;
	
	case OID_WH_EZ_GROUP_ID:
			ifIndex = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
			if (pObj->ioctl_if_type == INT_APCLI) {
				wdev = &pAd->ApCfg.ApCliTab[ifIndex].wdev;
				apcliEn = pAd->ApCfg.ApCliTab[ifIndex].Enable;
				if (!apcliEn)
					return FALSE;
	
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("IF(apcli%d) %s:: ", 
				ifIndex, __FUNCTION__));
			}
			else 
#endif /* APCLI_SUPPORT */
			{
				wdev = &pAd->ApCfg.MBSSID[ifIndex].wdev;
				MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("IF(ra%d) %s:: ", 
					ifIndex, __FUNCTION__));
			}
				wrq->u.data.length = wdev->ez_security.group_id_len;
				Status = copy_to_user(wrq->u.data.pointer, 
					&wdev->ez_security.group_id, wrq->u.data.length);
				MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("Status = %d, OID_WH_EZ_GROUP_ID\n", 
					Status));
				break;
	
	case OID_WH_EZ_RSSI_THRESHOLD:
			ifIndex = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
			if (pObj->ioctl_if_type == INT_APCLI) {
				wdev = &pAd->ApCfg.ApCliTab[ifIndex].wdev;
				apcliEn = pAd->ApCfg.ApCliTab[ifIndex].Enable;
				if (!apcliEn)
					return FALSE;
	
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("IF(apcli%d) %s:: ", 
				ifIndex, __FUNCTION__));
			}
			else 
#endif /* APCLI_SUPPORT */
			{
				wdev = &pAd->ApCfg.MBSSID[ifIndex].wdev;
				MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
					("IF(ra%d) %s:: ", 
					ifIndex, __FUNCTION__));
			}
	
			wrq->u.data.length = sizeof(wdev->ez_security.rssi_threshold);
			Status = copy_to_user(wrq->u.data.pointer, 
				&wdev->ez_security.rssi_threshold, wrq->u.data.length);
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("Status = %d, rssi_threshold = %d\n", 
				Status, wdev->ez_security.rssi_threshold));
			break;

	case  OID_WH_EZ_GET_GUI_INFO:

			ifIndex = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
			apcli_entry = &pAd->ApCfg.ApCliTab[ifIndex];
			apcli_wdev = &pAd->ApCfg.ApCliTab[ifIndex].wdev;
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("IF(apcli%d) %s:: ", ifIndex, __FUNCTION__));
#endif /* APCLI_SUPPORT */

			wdev = &pAd->ApCfg.MBSSID[ifIndex].wdev;
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("IF(ra%d) %s:: ", ifIndex, __FUNCTION__));

			memset(&GUI_info, '\0', sizeof(GUI_info));
			NdisCopyMemory(&GUI_info.EzEnable, &wdev->enable_easy_setup, sizeof(wdev->enable_easy_setup));
			NdisCopyMemory(&GUI_info.EzConfStatus, &wdev->ez_security.configured_status, sizeof(wdev->ez_security.configured_status));
			NdisCopyMemory(GUI_info.EzGroupID, wdev->ez_security.ez_group_id, wdev->ez_security.ez_group_id_len);
			NdisCopyMemory(GUI_info.EzGenGroupId, wdev->ez_security.gen_group_id, wdev->ez_security.gen_group_id_len);
			NdisCopyMemory(GUI_info.EzOpenGroupID, wdev->ez_security.open_group_id, wdev->ez_security.open_group_id_len);
#ifdef APCLI_SUPPORT
			NdisCopyMemory(&GUI_info.ApCliEzConfStatus, &apcli_wdev->ez_security.configured_status, sizeof(apcli_wdev->ez_security.configured_status));
			NdisCopyMemory(GUI_info.ApCliEzGroupID, apcli_wdev->ez_security.ez_group_id, apcli_wdev->ez_security.ez_group_id_len);
			NdisCopyMemory(GUI_info.ApCliEzGenGroupId, apcli_wdev->ez_security.gen_group_id, apcli_wdev->ez_security.gen_group_id_len);
			NdisCopyMemory(GUI_info.ApCliEzOpenGroupID, apcli_wdev->ez_security.open_group_id, apcli_wdev->ez_security.open_group_id_len);
			NdisCopyMemory(GUI_info.ApCliHideSSID, apcli_entry->CfgHideSsid, apcli_entry->CfgHideSsidLen);
			if(ez_CheckAuthMode(apcli_wdev->SecConfig.AKMMap))
				NdisCopyMemory(GUI_info.ApCliAuthMode, ez_CheckAuthMode(apcli_wdev->SecConfig.AKMMap), strlen(ez_CheckAuthMode(apcli_wdev->SecConfig.AKMMap)));
			if(ez_CheckEncrypType(apcli_wdev->SecConfig.PairwiseCipher))
				NdisCopyMemory(GUI_info.ApCliEncrypType, ez_CheckEncrypType(apcli_wdev->SecConfig.PairwiseCipher), strlen(ez_CheckEncrypType(apcli_wdev->SecConfig.PairwiseCipher)));
			if(apcli_wdev->SecConfig.PSK)
				NdisCopyMemory(GUI_info.ApCliWPAPSK, apcli_wdev->SecConfig.PSK, strlen(apcli_wdev->SecConfig.PSK));
			NdisCopyMemory(GUI_info.ApCliSsid, apcli_entry->CfgSsid, apcli_entry->CfgSsidLen);
			NdisCopyMemory(&GUI_info.ApCliEnable, &pAd->ApCfg.ApCliTab[ifIndex].Enable, sizeof(pAd->ApCfg.ApCliTab[ifIndex].Enable));
			NdisCopyMemory(&GUI_info.ApCliEzEnable, &apcli_wdev->enable_easy_setup, sizeof(apcli_wdev->enable_easy_setup));
#endif

			wrq->u.data.length = sizeof(GUI_info);
			Status = copy_to_user(wrq->u.data.pointer, &GUI_info, sizeof(GUI_info));

			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Status = %d, OID_WH_EZ_GROUP_ID\n", Status));
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("sizeof(GUI_info):%d\n", (int)(sizeof(GUI_info))));
			
		break;
		
		default:
			MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("Query::unknown IOCTL's subcmd = 0x%08x, apidx=%d\n", cmd, apidx));
			Status = -EOPNOTSUPP;
			break;	
    }	
    return Status;
}

#ifdef EZ_API_SUPPORT
BOOLEAN ez_port_secured_for_connection_offload(
	void *ad_obj,
	void *entry_obj,
	unsigned char if_idx,
	unsigned char ap_mode)
{
	RTMP_ADAPTER *ad;
	MAC_TABLE_ENTRY *entry;
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
#ifdef APCLI_SUPPORT
	APCLI_STRUCT *apcli_entry;
	unsigned char ori_apcli_enable;
#endif /* APCLI_SUPPORT */
	struct _ez_peer_security_info *ez_peer;
	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("------> %s()\n", __FUNCTION__));
	ad = (RTMP_ADAPTER *)ad_obj;
	entry = (MAC_TABLE_ENTRY *)entry_obj;
	wdev = entry->wdev;
	ez_sec_info = &wdev->ez_security;
	entry->easy_setup_enabled = TRUE;
#ifdef APCLI_SUPPORT
	apcli_entry = &ad->ApCfg.ApCliTab[if_idx];
	ori_apcli_enable = apcli_entry->Enable;
	apcli_entry->Enable = FALSE;
#endif /* APCLI_SUPPORT */
#if defined (NEW_CONNECTION_ALGO) || defined (EZ_NETWORK_MERGE_SUPPORT)
		ez_peer = ez_peer_table_search_by_addr(wdev, entry->Addr);
		ez_peer->port_secured = TRUE;
		
#endif

	if (ap_mode) {
		entry->is_apcli = TRUE;
#ifdef EZ_NETWORK_MERGE_SUPPORT
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("connected peer capabilities --->%x\n", ez_peer->capability));
		if (EZ_GET_CAP_ALLOW_MERGE(ez_peer->capability)) {
			NdisZeroMemory(ez_sec_info->merge_peer_addr, MAC_ADDR_LEN);
			EZ_CLEAR_CAP_ALLOW_MERGE(ez_sec_info->capability);
			EZ_UPDATE_CAPABILITY_INFO(ad, EZ_CLEAR_ACTION, ALLOW_MERGE, if_idx);
			if (ez_sec_info->ez_group_merge_timer_running)
			{
				EZ_CANCEL_TIMER(&ez_sec_info->ez_group_merge_timer, 
							ez_sec_info->ez_group_merge_timer_running);

			}
		}
#endif		
		ez_install_ptk(ad, entry, TRUE);
	} else {
		/* Install Key */
		ez_install_ptk(ad, entry, FALSE);
		ez_apcli_install_gtk((RTMP_ADAPTER *)wdev->ez_security.ad, entry);
		entry->SecConfig.Handshake.WpaState = AS_PTKINITDONE;
		
		//! clear off group merge related params
		NdisZeroMemory(ez_sec_info->merge_peer_addr, MAC_ADDR_LEN);
		EZ_CLEAR_CAP_ALLOW_MERGE(ez_sec_info->capability);
		EZ_UPDATE_APCLI_CAPABILITY_INFO(ad, EZ_CLEAR_ACTION, ALLOW_MERGE, if_idx);
		if (ez_sec_info->ez_group_merge_timer_running)
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Group Merge completed, cancel timer\n"));
			EZ_CANCEL_TIMER(&ez_sec_info->ez_group_merge_timer, 
						ez_sec_info->ez_group_merge_timer_running);

		}

	}

	if (ap_mode) {
#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(ad, IW_WH_EZ_MY_AP_HAS_APCLI, entry->Addr, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_MY_AP_HAS_APCLI,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
	}
	else {
#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(ad, IW_WH_EZ_MY_APCLI_CONNECTED, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_MY_APCLI_CONNECTED,
						    NULL, (PUCHAR)ez_peer, sizeof(struct _ez_peer_security_info));
#endif /* !SYSTEM_LOG_SUPPORT */
	}
	
#ifdef APCLI_SUPPORT
		apcli_entry->Enable = ori_apcli_enable;
#endif /* APCLI_SUPPORT */
	
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("<------ %s()\n", __FUNCTION__));
	return TRUE;
}
#endif

void ez_initiate_new_scan(void *ad_obj)
{

	PRTMP_ADAPTER pAd = ad_obj;
	UCHAR i=0;

	for (i=0; i<WDEV_NUM_MAX; i++)
	{
		struct wifi_dev *wdev = pAd->wdev_list[i];
		if (wdev && wdev->wdev_type == WDEV_TYPE_APCLI)
		{
			wdev->ez_security.first_scan = TRUE;
		}
	}
#ifdef DUAL_CHIP
	{
		PRTMP_ADAPTER adOthBand = NULL;
		if (!IS_SINGLE_CHIP_DBDC(pAd)){
			adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
			if(adOthBand == NULL) {
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
				ASSERT(FALSE);
			} else {
				for (i=0; i<WDEV_NUM_MAX; i++)
				{
					struct wifi_dev *wdev = adOthBand->wdev_list[i];
					if (wdev && wdev->wdev_type == WDEV_TYPE_APCLI)
					{
						wdev->ez_security.first_scan = TRUE;
					}
				}
			}
		}
	}
#endif

}
BOOLEAN ez_port_secured(
	void *ad_obj,
	void *entry_obj,
	unsigned char if_idx,
	unsigned char ap_mode)
{
	RTMP_ADAPTER *ad;
	MAC_TABLE_ENTRY *entry;
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
#if defined (NEW_CONNECTION_ALGO) || defined (EZ_NETWORK_MERGE_SUPPORT)
	struct _ez_peer_security_info *ez_peer;
	BOOLEAN allow_ap_connection = FALSE;
#endif
	BOOLEAN ret = TRUE;

#ifdef EZ_NETWORK_MERGE_SUPPORT	
	int check_for_weight = TRUE;
	enum_config_update_action_t config_update_action = ACTION_NOTHING;
#endif
#ifdef APCLI_SUPPORT
	APCLI_STRUCT *apcli_entry;
	unsigned char ori_apcli_enable;
#endif /* APCLI_SUPPORT */

	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("------> %s()\n", __FUNCTION__));

	ad = (RTMP_ADAPTER *)ad_obj;
	entry = (MAC_TABLE_ENTRY *)entry_obj;
	wdev = entry->wdev;
	ez_sec_info = &wdev->ez_security;
	entry->easy_setup_enabled = TRUE;
#ifdef EZ_API_SUPPORT
		if (wdev->ez_security.ez_api_mode == CONNECTION_OFFLOAD)
		{
			ez_port_secured_for_connection_offload(ad_obj, entry_obj, if_idx, ap_mode);
			return TRUE;
		}
#endif

#ifdef APCLI_SUPPORT
	apcli_entry = &ad->ApCfg.ApCliTab[if_idx];
	ori_apcli_enable = apcli_entry->Enable;
	apcli_entry->Enable = FALSE;
#endif /* APCLI_SUPPORT */
#if defined (NEW_CONNECTION_ALGO) || defined (EZ_NETWORK_MERGE_SUPPORT)
	ez_peer = ez_peer_table_search_by_addr(wdev, entry->Addr);
	if (ez_peer == NULL){
		
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
				("%s(): Ez_peer is NULL \n", __FUNCTION__));
		ez_hex_dump("MAC",entry->Addr, MAC_ADDR_LEN);
		return FALSE;
	}
 	ez_peer->port_secured = TRUE;
	
#endif

#ifdef EZ_NETWORK_MERGE_SUPPORT
	wdev->ez_security.first_scan = FALSE;
	wdev->ez_security.scan_one_channel = FALSE;
	wdev->ez_security.best_ap_rssi_threshold = 0;

#endif

	if (ap_mode) {
	
#ifndef EZ_NETWORK_MERGE_SUPPORT
	//! CLI scan should no tbe controlled by AP
#ifdef APCLI_SUPPORT
	if (apcli_entry->wdev.enable_easy_setup) {
		
		apcli_entry->wdev.ez_security.keep_finding_provider = FALSE;
		EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_scan_timer, 
			apcli_entry->wdev.ez_security.ez_scan_timer_running);
		EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_stop_scan_timer, 
			apcli_entry->wdev.ez_security.ez_stop_scan_timer_running);

		RTMP_SEM_LOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);
		EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_scan_pause_timer,
			apcli_entry->wdev.ez_security.ez_scan_pause_timer_running);
		apcli_entry->stop_auto_connect = FALSE;
		RTMP_SEM_UNLOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);

	}
#endif /* APCLI_SUPPORT */
#else
	if (apcli_entry->wdev.enable_easy_setup) {
		RTMP_SEM_LOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);

		EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_scan_pause_timer,
					apcli_entry->wdev.ez_security.ez_scan_pause_timer_running);
				apcli_entry->stop_auto_connect = FALSE;
		RTMP_SEM_UNLOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);

	}
#endif

		entry->is_apcli = TRUE;
		/* Install PTK */
		ez_install_ptk(ad, entry, TRUE);
		RTMP_SEM_LOCK(&ez_sec_info->ez_apcli_list_sem_lock);
		ez_insert_apcli_entry_by_mac(&ez_sec_info->ez_apcli_list, entry->Addr);
		RTMP_SEM_UNLOCK(&ez_sec_info->ez_apcli_list_sem_lock);
		ez_add_entry_to_acl_list(ad, if_idx, entry->Addr);

#ifdef EZ_NETWORK_MERGE_SUPPORT
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("connected peer capabilities --->%x\n", ez_peer->capability));
		if (EZ_GET_CAP_ALLOW_MERGE(ez_peer->capability)) {
			NdisZeroMemory(ez_sec_info->merge_peer_addr, MAC_ADDR_LEN);
			EZ_CLEAR_CAP_ALLOW_MERGE(ez_sec_info->capability);
			EZ_UPDATE_CAPABILITY_INFO(ad, EZ_CLEAR_ACTION, ALLOW_MERGE, if_idx);
			if (ez_sec_info->ez_group_merge_timer_running)
			{
				EZ_CANCEL_TIMER(&ez_sec_info->ez_group_merge_timer, 
							ez_sec_info->ez_group_merge_timer_running);

			}
		}
#endif
#ifdef NEW_CONNECTION_ALGO
		ez_peer->port_secured = TRUE;
		{
			UCHAR sta_count=0;
			int i;
			for (i=0; i<EZ_MAX_STA_NUM;i++)
			{
				if (wdev->ez_peer_table[i].valid && wdev->ez_peer_table[i].port_secured == FALSE) {
					sta_count++;
					allow_ap_connection = TRUE;
				}
			}
			if (sta_count == 0)
			{
					ez_update_connection_permission(ad,wdev,EZ_ALLOW_ALL);
			}
			else
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("-> don't allow all connections as still some connection pending on AP\n"));
		}
#endif
#if EZ_DUAL_BAND_SUPPORT
		{
			if (ez_peer->this_band_info.shared_info.link_duplicate)
			{
				struct _ez_peer_security_info *other_band_cli_peer = ez_get_other_band_ez_peer(wdev, ez_peer);
				MAC_TABLE_ENTRY *other_band_cli_peer_macentry= NULL;

				entry->link_duplicate = TRUE;
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x : Mark self connected cli [%02x-%02x-%02x-%02x-%02x-%02x] mac_entry as duplicate link\n",
					wdev->wdev_idx,wdev->wdev_type,wdev->func_idx, 
					ez_peer->mac_addr[0],ez_peer->mac_addr[1],ez_peer->mac_addr[2],
					ez_peer->mac_addr[3],ez_peer->mac_addr[4],ez_peer->mac_addr[5]));

				if (other_band_cli_peer != NULL) {
					other_band_cli_peer->this_band_info.shared_info.link_duplicate = TRUE;
					other_band_cli_peer->other_band_info.shared_info.link_duplicate = TRUE;

					other_band_cli_peer_macentry = MacTableLookup(other_band_cli_peer->wdev->sys_handle,other_band_cli_peer->mac_addr);
					if(other_band_cli_peer_macentry != NULL){
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x: Mark other AP connected peer cli[%02x-%02x-%02x-%02x-%02x-%02x] as duplicate link\n",
							other_band_cli_peer->wdev->wdev_idx,other_band_cli_peer->wdev->wdev_type,other_band_cli_peer->wdev->func_idx,
							other_band_cli_peer->mac_addr[0],other_band_cli_peer->mac_addr[1],other_band_cli_peer->mac_addr[2],
							other_band_cli_peer->mac_addr[3],other_band_cli_peer->mac_addr[4],other_band_cli_peer->mac_addr[5]));
						other_band_cli_peer_macentry->link_duplicate = TRUE;
					}
					else{
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ERROR !!! not found other ap's clients mac entry\n"));
						ASSERT(FALSE);
					}

				} else {
					ASSERT(FALSE);
				}
			}
		}

#endif
	}
#ifdef APCLI_SUPPORT
	else {
		struct wifi_dev *ap_wdev;
		BSS_STRUCT *mbss;

		entry->is_apcli = FALSE;
		ap_wdev = &ad->ApCfg.MBSSID[if_idx].wdev;
		mbss = &ad->ApCfg.MBSSID[if_idx];

		apcli_entry->MlmeAux.attempted_candidate_index = EZ_INDEX_NOT_FOUND;

		apcli_entry->wdev.ez_security.keep_finding_provider = FALSE;
		EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_scan_timer, 
			apcli_entry->wdev.ez_security.ez_scan_timer_running);
		EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_stop_scan_timer, 
			apcli_entry->wdev.ez_security.ez_stop_scan_timer_running);

		RTMP_SEM_LOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);
		EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_scan_pause_timer,
			apcli_entry->wdev.ez_security.ez_scan_pause_timer_running);
		apcli_entry->stop_auto_connect = FALSE;
		RTMP_SEM_UNLOCK(&apcli_entry->wdev.ez_security.ez_scan_pause_timer_lock);


		/* Install Key */
		ez_install_ptk(ad, entry, FALSE);
		ez_apcli_install_gtk((RTMP_ADAPTER *)wdev->ez_security.ad, entry);
		entry->SecConfig.Handshake.WpaState = AS_PTKINITDONE;
		if (ap_wdev->enable_easy_setup &&
			(ap_wdev->ez_security.configured_status == EZ_UNCONFIGURED)) {
			/* Update PMK to ra interface. */
			ap_wdev->ez_security.configured_status = EZ_CONFIGURED;
			EZ_SET_CAP_CONFIGRED(ap_wdev->ez_security.capability);
#ifndef EZ_NETWORK_MERGE_SUPPORT	
			UpdateBeaconHandler(ad, ap_wdev, BCN_UPDATE_IE_CHG);
#else
			check_for_weight = FALSE;
		}

		EZ_SET_CAP_CONNECTED(ap_wdev->ez_security.capability);
		UpdateBeaconHandler(ad, ap_wdev, BCN_UPDATE_IE_CHG);

		//! clear off group merge related params
		NdisZeroMemory(ez_sec_info->merge_peer_addr, MAC_ADDR_LEN);
		EZ_CLEAR_CAP_ALLOW_MERGE(ez_sec_info->capability);
		EZ_UPDATE_APCLI_CAPABILITY_INFO(ad, EZ_CLEAR_ACTION, ALLOW_MERGE, if_idx);
		if (ez_sec_info->ez_group_merge_timer_running)
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Group Merge completed, cancel timer here\n"));
			EZ_CANCEL_TIMER(&ez_sec_info->ez_group_merge_timer, 
						ez_sec_info->ez_group_merge_timer_running);

		}
		wdev->ez_security.delay_disconnect_count = 0;

#ifdef EZ_ROAM_SUPPORT
		if(!MAC_ADDR_EQUAL(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,ZERO_MAC_ADDR))
		{
			NdisZeroMemory(wdev->ez_security.ez_roam_info.ez_apcli_roam_bssid,MAC_ADDR_LEN);
			NdisZeroMemory(ap_wdev->ez_security.ez_ap_roam_blocked_mac,MAC_ADDR_LEN);
			ez_update_connection_permission(ad, wdev,EZ_DEQUEUE_PERMISSION);
		}
#endif
#ifdef EZ_DUAL_BAND_SUPPORT
		if (ez_apcli_is_link_duplicate(ad,wdev,ez_peer->mac_addr))//(wdev->ez_security.internal_force_connect_bssid)
		{
			
			wdev->ez_security.internal_force_connect_bssid = FALSE;
			wdev->ez_security.this_band_info.shared_info.link_duplicate = TRUE;
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x : Duplicate Link made\n",
				wdev->wdev_idx,wdev->wdev_type,wdev->func_idx));
		} 
		else
		{
			if (check_for_weight == TRUE)
			{
				if (ez_is_weight_same(wdev->ez_security.device_info.network_weight,ez_peer->device_info.network_weight))
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("Wt same when link is not duplicate!!! Loop!!!\n"));
					wdev->ez_security.internal_force_connect_bssid_timeout = FALSE;
					ez_send_unicast_deauth(ad,ez_peer->mac_addr);
					return FALSE;
				}
			}

		}
		wdev->ez_security.internal_force_connect_bssid_timeout = FALSE;
		COPY_MAC_ADDR(wdev->ez_security.this_band_info.cli_peer_ap_mac, ez_peer->mac_addr);
				
		
		COPY_MAC_ADDR(ap_wdev->ez_security.this_band_info.cli_peer_ap_mac, ez_peer->mac_addr);
		
		ez_inform_all_interfaces(ad, wdev, ACTION_UPDATE_DUPLICATE_LINK_ENTRY);
#endif
#ifdef NEW_CONNECTION_ALGO
		wdev->ez_security.ez_scan_same_channel = FALSE;
		wdev->ez_security.scan_one_channel = FALSE;
#endif

		//! check if configuration update and push is required
		config_update_action = push_and_update_config(ad, wdev, ez_peer, check_for_weight,TRUE,FALSE);
		//! if configuration push os required, send an action frame to connected AP
		if (config_update_action == ACTION_PUSH)
		{

			updated_configs_t updated_configs;			
#ifdef EZ_PUSH_BW_SUPPORT
			BOOLEAN this_band_changed = FALSE;
			BOOLEAN other_band_changed = FALSE;

			//if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
				ez_chk_bw_config_different(wdev,ez_peer,&this_band_changed,&other_band_changed);
#endif
			//! this is a configuration push so I need to switch back to my older configutration.
			NdisZeroMemory(apcli_entry->Ssid,apcli_entry->SsidLen);
			apcli_entry->SsidLen = wdev->ez_security.this_band_info.shared_info.ssid_len;
			NdisCopyMemory(apcli_entry->Ssid, wdev->ez_security.this_band_info.shared_info.ssid,wdev->ez_security.this_band_info.shared_info.ssid_len );
			NdisZeroMemory(apcli_entry->CfgSsid,apcli_entry->SsidLen);
			apcli_entry->CfgSsidLen = wdev->ez_security.this_band_info.shared_info.ssid_len ;
			NdisCopyMemory(apcli_entry->CfgSsid, wdev->ez_security.this_band_info.shared_info.ssid,wdev->ez_security.this_band_info.shared_info.ssid_len );

			//! initialize a local structure that will hold all the inforation to be pushed to peer AP
			ez_init_updated_configs_for_push(&updated_configs, wdev);
			//! send updated configurations to peer 
			if(send_action_update_config(ad, ez_peer, wdev, &updated_configs, TRUE, FALSE) == FALSE)
			{
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					("%s(): Error: Could not send action frame for push. Disconnect\n", __FUNCTION__));
				if(ez_peer) {
					ez_peer->delete_in_differred_context = TRUE;
					ez_send_unicast_deauth(ad,ez_peer->mac_addr);
				}
				ez_update_connection_permission(ad,wdev,EZ_ALLOW_ALL);
			}

			ez_restore_channel_config(ap_wdev);

			if(IS_SINGLE_CHIP_DBDC(ad))
			{
			//Reset the scan table so that other band device gets correct bss information.
			BssTableInit(&ad->ScanTab);
			} else {
#ifdef DUAL_CHIP
				PRTMP_ADAPTER adOthBand = NULL;
				adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
				if(adOthBand == NULL) {
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
						("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
					ASSERT(FALSE);
				}
				BssTableInit(&adOthBand->ScanTab);
#endif

			}
			UpdateBeaconHandler(ad, ap_wdev, BCN_UPDATE_IE_CHG);
		
#ifdef EZ_PUSH_BW_SUPPORT
			//update peer info to new config			
			if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
				update_peer_record(ad, wdev, this_band_changed, other_band_changed);
#endif
#endif				
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Initiate New scan after push\n"));
			ez_initiate_new_scan(ad);
		}
		else if (config_update_action == ACTION_NOTHING)
		{
			if(wdev->ez_security.this_band_info.shared_info.link_duplicate == TRUE)
			{
				struct _ez_peer_security_info *ez_other_band_peer = ez_get_other_band_ez_peer(wdev,ez_peer);
				if(ez_other_band_peer == NULL)
				{
					ASSERT(FALSE);
					return FALSE;
				}
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s:duplicateLink: Update the node Number\n", __FUNCTION__));
				NdisCopyMemory(&ez_peer->device_info.ez_node_number,&ez_other_band_peer->device_info.ez_node_number,sizeof(EZ_NODE_NUMBER));
			}
			else
			ez_restore_node_number(&ez_peer->device_info.ez_node_number);
				ez_update_connection_permission(ad,wdev,EZ_ALLOW_ALL);
		}
		

#ifdef APCLI_AUTO_CONNECT_SUPPORT
		ad->ApCfg.ApCliAutoConnectRunning[if_idx] = FALSE;
#endif /* APCLI_AUTO_CONNECT_SUPPORT */

	}

	if (wdev->ez_security.configured_status == EZ_UNCONFIGURED) {
		wdev->ez_security.configured_status = EZ_CONFIGURED;
		ez_update_security_setting(ad, wdev, wdev->ez_security.this_band_info.pmk);
		ez_updage_ap_wsc_profile(ad, wdev, wdev->func_idx);
		if (wdev->wdev_type == WDEV_TYPE_AP)
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Move AP into configured state\n"));
			EZ_UPDATE_CAPABILITY_INFO(ad, EZ_SET_ACTION, CONFIGRED, wdev->func_idx);
		} else {
			
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Move CLI into configured state\n"));
			EZ_UPDATE_APCLI_CAPABILITY_INFO(ad, EZ_SET_ACTION, CONFIGRED, wdev->func_idx);
		}
		//EZ_SET_CAP_CONFIGRED(wdev->ez_security.capability);
		ez_inform_all_interfaces(ad, wdev, ACTION_UPDATE_CONFIG_STATUS);
	}
	

#endif /* APCLI_SUPPORT */
	if (ap_mode) {
#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(ad, IW_WH_EZ_MY_AP_HAS_APCLI, entry->Addr, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_MY_AP_HAS_APCLI,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
	}
	else {
#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(ad, IW_WH_EZ_MY_APCLI_CONNECTED, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_MY_APCLI_CONNECTED,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
	}


#ifdef APCLI_SUPPORT
	apcli_entry->Enable = ori_apcli_enable;
#endif /* APCLI_SUPPORT */

	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("<------ %s()\n", __FUNCTION__));

    return ret;
}

#ifndef NEW_CONNECTION_ALGO
unsigned char ez_avoid_looping_connection(
	void *ad_obj,
	void *apcli_entry_obj,
	unsigned char if_idx)
{
	RTMP_ADAPTER *ad;
	APCLI_STRUCT *apcli_entry;
	int i;
#ifdef EZ_NETWORK_MERGE_SUPPORT	
	int merge_provider_found = FALSE;
#endif	
	struct wifi_dev *wdev;
	struct wifi_dev *ap_wdev;
	unsigned char found_ap = FALSE;
	BSS_ENTRY *bss_entry;
	unsigned char bss_nr;
	BSS_TABLE *out_table;

	ad = (RTMP_ADAPTER *)ad_obj;
	apcli_entry = (APCLI_STRUCT *)apcli_entry_obj;
	wdev = &apcli_entry->wdev;
	ap_wdev = &ad->ApCfg.MBSSID[if_idx].wdev;
	out_table = &apcli_entry->MlmeAux.SsidBssTab;

	if (apcli_entry->stop_auto_connect) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - AP search Paused.\n", 
					__FUNCTION__, __LINE__));
		return FALSE;
	}
	
	if (wdev->ez_security.ez_scan_timer_running) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
					("%s(line.%d) - Wait for next scan.\n", 
					__FUNCTION__, __LINE__));
		return FALSE;
	}

	// TODO: consider if this device only enables apcli interface. (we don't need to avoid loop in this case)
	
	if (!apcli_entry->avoid_loop) {
		MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("(%s) skip looping connection checking.\n", __FUNCTION__));
		return TRUE;
	}

	if (wdev->ez_security.first_scan) {
		wdev->ez_security.scan_one_channel = TRUE;
		wdev->ez_security.first_scan = FALSE;
		MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("(%s) Scan current channel only.\n", __FUNCTION__));
		ApSiteSurvey_by_wdev(ad, NULL, SCAN_ACTIVE, FALSE, wdev);
		return FALSE;
	}

    if(apcli_entry->MlmeAux.SsidBssTab.BssNr == 0){	
		/*
			Find all matching BSS in the latest SCAN result (inBssTab)
			Sort by RSSI order
		*/
		BssTableSsidSort(ad, wdev, &apcli_entry->MlmeAux.SsidBssTab,
				 (PCHAR) apcli_entry->CfgSsid, apcli_entry->CfgSsidLen);
    }

	found_ap = FALSE;
	bss_nr = apcli_entry->MlmeAux.SsidBssTab.BssNr;
#ifdef EZ_NETWORK_MERGE_SUPPORT
	for (i = 0; i < bss_nr; i++) {
		bss_entry = &apcli_entry->MlmeAux.SsidBssTab.BssEntry[i];
		
		if (EZ_GET_CAP_ALLOW_MERGE(apcli_entry->wdev.ez_security.capability)) {
			if (!apcli_entry->wdev.ez_security.ez_group_merge_timer_running){			
				EzStartGroupMergeTimer(&apcli_entry->wdev.ez_security);
			}
			if (EZ_GET_CAP_ALLOW_MERGE(bss_entry->easy_setup_capability))
			{	
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Searching for provider, Open merge allowed, MAC match, %s\n", bss_entry->Ssid));
				if (merge_provider_found){
					found_ap = FALSE;
					NdisZeroMemory(apcli_entry->wdev.ez_security.merge_peer_addr, MAC_ADDR_LEN);
					EZ_CLEAR_CAP_ALLOW_MERGE(apcli_entry->wdev.ez_security.capability);
					EZ_UPDATE_APCLI_CAPABILITY_INFO(ad, EZ_CLEAR_ACTION, ALLOW_MERGE, apcli_entry->wdev.func_idx);
					if (apcli_entry->wdev.ez_security.ez_group_merge_timer_running)
					{
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Group Merge completed, cancel timer here\n"));
						EZ_CANCEL_TIMER(&apcli_entry->wdev.ez_security.ez_stop_scan_timer, 
									apcli_entry->wdev.ez_security.ez_stop_scan_timer_running);
					}
					goto found;
				} else {
					merge_provider_found = TRUE;
					found_ap = TRUE;
					apcli_entry->MlmeAux.support_easy_setup = TRUE;
					COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
					apcli_entry->CfgSsidLen = bss_entry->SsidLen;
					NdisCopyMemory(apcli_entry->CfgSsid,bss_entry->Ssid,bss_entry->SsidLen);
					MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
						("%s(line.%d): found ap.\n", 
						__FUNCTION__, __LINE__));
					continue;
				}
			} else {
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Searching for provider, Open Merge not allowed, %s\n", bss_entry->Ssid));
				continue;
			}
		} 
		else if (!MAC_ADDR_EQUAL(apcli_entry->wdev.ez_security.merge_peer_addr, ZERO_MAC_ADDR))
			{
				if (!apcli_entry->wdev.ez_security.ez_group_merge_timer_running){			
					EzStartGroupMergeTimer(&apcli_entry->wdev.ez_security);
				}
				if (NdisEqualMemory(bss_entry->Bssid, apcli_entry->wdev.ez_security.merge_peer_addr, MAC_ADDR_LEN))
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Searching for provider, MAC match, %s\n", bss_entry->Ssid));
					found_ap = TRUE;
					apcli_entry->MlmeAux.support_easy_setup = TRUE;
					COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
					apcli_entry->CfgSsidLen = bss_entry->SsidLen;
					NdisCopyMemory(apcli_entry->CfgSsid,bss_entry->Ssid,bss_entry->SsidLen);
					MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
						("%s(line.%d): found ap.\n", 
						__FUNCTION__, __LINE__));
					break;
				} else 
				{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Searching for provider, MAC do not match, %s\n", bss_entry->Ssid));
					continue;
				}
			}
		}

	if (found_ap){
		goto found;
	}
#endif

	/*
		My AP doesn't have apcli entry.
		Select configured and higher bssid ap.
	*/
	for (i = 0; i < bss_nr; i++) {

        if(out_table->BssEntry[i].bConnectAttemptFailed){
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			//	("%s(line.%d) - Skip already attempted candidate.\n", 
			//	__FUNCTION__, __LINE__));
			continue;
        }

		bss_entry = &apcli_entry->MlmeAux.SsidBssTab.BssEntry[i];
		if ((ap_wdev->ez_security.ez_apcli_list.size == 0)
			&& ez_mac_addr_compare(bss_entry->Bssid, ap_wdev->bssid)
			&& EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)) {
			found_ap = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found configured ap with higher mac.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}

	/*
		My AP has apcli entry.
		Select configured and higher bssid ap which doesn't connect to root ap.
	*/
	for (i = 0; i < bss_nr; i++) {

        if(out_table->BssEntry[i].bConnectAttemptFailed){
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			//	("%s(line.%d) - Skip already attempted candidate.\n", 
			//	__FUNCTION__, __LINE__));
			continue;
        }

		bss_entry = &apcli_entry->MlmeAux.SsidBssTab.BssEntry[i];
		if (ez_mac_addr_compare(bss_entry->Bssid, ap_wdev->bssid)
			&& EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)
			&& !EZ_GET_CAP_CONNECTED(bss_entry->easy_setup_capability)) {
			found_ap = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found configured ap with higher mac & non-active apcli.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}

	/*
		My AP doesn't have apcli entry.
		Select configured and higher RSSI ap which already connect to root ap.
	*/
	for (i = 0; i < bss_nr; i++) {

        if(out_table->BssEntry[i].bConnectAttemptFailed){
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			//	("%s(line.%d) - Skip already attempted candidate.\n", 
			//	__FUNCTION__, __LINE__));
			continue;
        }

		bss_entry = &apcli_entry->MlmeAux.SsidBssTab.BssEntry[i];
		if ((ap_wdev->ez_security.ez_apcli_list.size == 0)
			&& EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)
			&& EZ_GET_CAP_CONNECTED(bss_entry->easy_setup_capability)) {
			found_ap = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found configured ap with connected apcli.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}

	/*
		Select configured ap which doesn't have apcli.
	*/
	for (i = 0; i < bss_nr; i++) {

        if(out_table->BssEntry[i].bConnectAttemptFailed){
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			//	("%s(line.%d) - Skip already attempted candidate.\n", 
			//	__FUNCTION__, __LINE__));
			continue;
        }

		bss_entry = &apcli_entry->MlmeAux.SsidBssTab.BssEntry[i];
		if (EZ_GET_CAP_CONFIGRED(bss_entry->easy_setup_capability)
			&& !EZ_GET_CAP_HAS_APCLI_INF(bss_entry->easy_setup_capability)) {
			found_ap = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found configured ap with noapcli interface.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}

	/*
		Select normal ap which doesn't support easy setup.
	*/
	for (i = 0; i < bss_nr; i++) {

        if(out_table->BssEntry[i].bConnectAttemptFailed){
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			//	("%s(line.%d) - Skip already attempted candidate.\n", 
			//	__FUNCTION__, __LINE__));
			continue;
        }

		bss_entry = &apcli_entry->MlmeAux.SsidBssTab.BssEntry[i];
		if (!bss_entry->support_easy_setup 
			&& IS_CIPHER_CCMP128(bss_entry->PairwiseCipher)
			&& IS_CIPHER_CCMP128(bss_entry->GroupCipher)
			&& IS_AKM_WPA2PSK(bss_entry->AKMMap)){
			found_ap = TRUE;
			COPY_MAC_ADDR(apcli_entry->CfgApCliBssid, bss_entry->Bssid);
			MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
				("%s(line.%d): found normal ap.\n", 
				__FUNCTION__, __LINE__));
			goto found;
		}
	}

found:
	if (!found_ap) {
		MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("(%s) No matching AP.(apcli_entry_count=%d)\n", __FUNCTION__, ap_wdev->ez_security.ez_apcli_list.size));
		wdev->ez_security.scan_one_channel = TRUE;

		apcli_entry->MlmeAux.attempted_candidate_index = EZ_INDEX_NOT_FOUND;

        if(!wdev->ez_security.ez_scan_timer_running){
			RTMPSetTimer(&wdev->ez_security.ez_scan_timer, EZ_MAX_SCAN_TIME_OUT/2);
			wdev->ez_security.ez_scan_timer_running = TRUE;
        }

#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(ad, IW_WH_EZ_CONFIGURED_AP_SEARCHING, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_CONFIGURED_AP_SEARCHING,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */
		return FALSE;
	}
	else {
#ifdef SYSTEM_LOG_SUPPORT
		RTMPSendWirelessEvent(ad, IW_WH_EZ_CONFIGURED_AP_FOUND, NULL, wdev->wdev_idx, 0);
#else /* SYSTEM_LOG_SUPPORT */
		RtmpOSWrielessEventSend(wdev->if_dev, RT_WLAN_EVENT_CUSTOM, IW_WH_EZ_CONFIGURED_AP_FOUND,
						    NULL, NULL, 0);
#endif /* !SYSTEM_LOG_SUPPORT */

#ifdef APCLI_AUTO_CONNECT_SUPPORT
#ifdef APCLI_AUTO_BW_TMP
			if(ApCliAutoConnectBWAdjust(ad, wdev, bss_entry))
				rtmp_set_channel(ad, wdev, bss_entry->Channel);
			else 
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): ApCliAutoConnectBWAdjust() return FALSE\n", __FUNCTION__));
#endif //APCLI_AUTO_BW_TMP
#endif //APCLI_AUTO_CONNECT_SUPPORT


		apcli_entry->MlmeAux.attempted_candidate_index = i;

	}

	return TRUE;
}
#endif

#ifdef EZ_NETWORK_MERGE_SUPPORT
BOOLEAN ez_get_other_band_info(void * ad_obj, void * wdev_obj, void *other_band_config)
{
	struct wifi_dev* wdev = wdev_obj;
	PRTMP_ADAPTER ad = (PRTMP_ADAPTER)ad_obj;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
	if(adOthBand == NULL) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
		ASSERT(FALSE);
		}
	}
#endif
	if (IS_SINGLE_CHIP_DBDC(ad))
	{
		struct _ez_security* other_band_sec_info;
		if (wdev->wdev_type == WDEV_TYPE_AP){
			other_band_sec_info =  &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev.ez_security;
		} else {
			other_band_sec_info =  &ad->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev.ez_security;
			//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s, func_idx = %d\n", __FUNCTION__, wdev->func_idx));
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s, other band ssid = %s\n", __FUNCTION__, other_band_sec_info->this_band_info.shared_info.ssid));
		}
		if (other_band_sec_info->this_band_info.interface_activated) {
			NdisCopyMemory(other_band_config, &other_band_sec_info->this_band_info, sizeof(interface_info_t));
			return TRUE;
		} else {
			return FALSE;
		}
	} 
#ifdef DUAL_CHIP	
	else {
		struct _ez_security* other_band_sec_info;
		if (wdev->wdev_type == WDEV_TYPE_AP){
			other_band_sec_info =  &adOthBand->ApCfg.MBSSID[0].wdev.ez_security;
	} else {
			other_band_sec_info =  &adOthBand->ApCfg.ApCliTab[0].wdev.ez_security;
			//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s, func_idx = %d\n", __FUNCTION__, wdev->func_idx));
		}
		if (other_band_sec_info->this_band_info.interface_activated) {
			NdisCopyMemory(other_band_config, &other_band_sec_info->this_band_info, sizeof(interface_info_t));
			return TRUE;
		} else {
			return FALSE;
		}
	}
#endif	
	return FALSE;		
}
struct _ez_peer_security_info *ez_get_other_band_ez_peer(void * wdev_obj, struct _ez_peer_security_info *ez_peer)
{
	struct wifi_dev* wdev = wdev_obj;
	PRTMP_ADAPTER ad = wdev->sys_handle;
	unsigned char *mac_addr;
#ifdef DUAL_CHIP
        PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
        	adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
        if(adOthBand == NULL) {
                EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
                        ("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
                ASSERT(FALSE);
		}
        }
#endif
	if(IS_SINGLE_CHIP_DBDC(ad))
	{
		struct wifi_dev* other_band_wdev;
		if (wdev->wdev_type == WDEV_TYPE_AP){
			other_band_wdev = &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev;
			mac_addr = ez_peer->other_band_info.shared_info.cli_mac_addr;
		} else {
			other_band_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev;
			mac_addr = ez_peer->other_band_info.shared_info.ap_mac_addr;
		}
		return ez_peer_table_search_by_addr(other_band_wdev, mac_addr); 
	}
#ifdef DUAL_CHIP
	else {
		struct wifi_dev* other_band_wdev;
		if (wdev->wdev_type == WDEV_TYPE_AP){
			other_band_wdev = &adOthBand->ApCfg.MBSSID[0].wdev;
			mac_addr = ez_peer->other_band_info.shared_info.cli_mac_addr;
	} else {
			other_band_wdev = &adOthBand->ApCfg.ApCliTab[0].wdev;
			mac_addr = ez_peer->other_band_info.shared_info.ap_mac_addr;
		}
		return ez_peer_table_search_by_addr(other_band_wdev, mac_addr);		
	}
#endif
	return NULL;
}
void ez_inform_all_interfaces(void * ad_obj, void * wdev_obj, inform_other_band_action_t action)
{
	struct wifi_dev* wdev = wdev_obj;
	PRTMP_ADAPTER ad = ad_obj;
		struct _ez_security* security_info;
		struct wifi_dev *target_wdev;
		int index;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		 adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
	if(adOthBand == NULL) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
	}
#endif
		for(index = 0; index < WDEV_NUM_MAX; index++){
			target_wdev = ad->wdev_list[index];
			if (target_wdev == NULL || target_wdev == wdev)
			{
				continue;
			}
			security_info =  &target_wdev->ez_security;
			if (security_info->this_band_info.interface_activated) {
				switch (action)
				{
					case ACTION_UPDATE_DUPLICATE_LINK_ENTRY: // since only wdev of other CLI interface updated here, separate funtion to update other band cli can be used instead
						if((wdev->wdev_type == WDEV_TYPE_APCLI) && (target_wdev->wdev_type == WDEV_TYPE_APCLI)){
							security_info->this_band_info.shared_info.link_duplicate = wdev->ez_security.this_band_info.shared_info.link_duplicate;
							EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x : Change Duplicate Link status to: %x\n",
								target_wdev->wdev_idx,target_wdev->wdev_type,target_wdev->func_idx,security_info->this_band_info.shared_info.link_duplicate));
						}
						break;
						
					case ACTION_UPDATE_INTERNET_STATUS:
					{
						if (target_wdev->enable_easy_setup && (target_wdev->wdev_type == WDEV_TYPE_AP))
						{
							target_wdev->ez_security.go_internet = wdev->ez_security.go_internet;
					
							if(wdev->ez_security.go_internet)
							{
								EZ_UPDATE_CAPABILITY_INFO(ad, EZ_SET_ACTION, INTERNET, index);
							}
							else
							{
								EZ_UPDATE_CAPABILITY_INFO(ad, EZ_CLEAR_ACTION, INTERNET, index);
							}				
						}
						break;
					}
					case ACTION_UPDATE_DEVICE_INFO:
						NdisCopyMemory(&security_info->device_info,&wdev->ez_security.device_info, sizeof(device_info_t));
						break;
					case ACTION_UPDATE_CONFIG_STATUS:
						if (target_wdev->ez_security.configured_status == EZ_UNCONFIGURED) {
							target_wdev->ez_security.configured_status = EZ_CONFIGURED;
							ez_update_security_setting(ad, target_wdev, target_wdev->ez_security.this_band_info.pmk);
							ez_updage_ap_wsc_profile(ad, target_wdev, target_wdev->func_idx);
							if (target_wdev->wdev_type == WDEV_TYPE_AP)
							{
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Move AP into configured state\n"));
								EZ_UPDATE_CAPABILITY_INFO(ad, EZ_SET_ACTION, CONFIGRED, target_wdev->func_idx);
							} else {
								
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Move CLI into configured state\n"));
								EZ_UPDATE_APCLI_CAPABILITY_INFO(ad, EZ_SET_ACTION, CONFIGRED, target_wdev->func_idx);
							}
							EZ_SET_CAP_CONFIGRED(target_wdev->ez_security.capability);
						}
						break;
						
					default:
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("INVALID ACTION = 0x%x\n", action));
						break;
				}
			}
		}
	 
#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(ad))
	{	
		for(index = 0; index < WDEV_NUM_MAX; index++){
			target_wdev = adOthBand->wdev_list[index];
			if (target_wdev == NULL)
			{
				continue;
			}
			security_info =  &target_wdev->ez_security;
			if (security_info->this_band_info.interface_activated) {
				switch (action)
				{
					case ACTION_UPDATE_DUPLICATE_LINK_ENTRY:// since only wdev of other CLI interface updated here, separate funtion to update other band cli can be used instead
						if((wdev->wdev_type == WDEV_TYPE_APCLI) && (target_wdev->wdev_type == WDEV_TYPE_APCLI)){
							security_info->this_band_info.shared_info.link_duplicate = wdev->ez_security.this_band_info.shared_info.link_duplicate;	 // not applicable for ap
							EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x : Change Duplicate Link status to: %x\n",
								target_wdev->wdev_idx,target_wdev->wdev_type,target_wdev->func_idx,security_info->this_band_info.shared_info.link_duplicate));
						}
						break;
						
					case ACTION_UPDATE_INTERNET_STATUS:
					{
						if (target_wdev->enable_easy_setup && (target_wdev->wdev_type == WDEV_TYPE_AP))
						{
							target_wdev->ez_security.go_internet = wdev->ez_security.go_internet;
					
							if(wdev->ez_security.go_internet)
							{
								EZ_UPDATE_CAPABILITY_INFO(adOthBand, EZ_SET_ACTION, INTERNET, index);
							}
							else
							{
								EZ_UPDATE_CAPABILITY_INFO(adOthBand, EZ_CLEAR_ACTION, INTERNET, index);
							}				
						}
						break;
					}
					
					case ACTION_UPDATE_DEVICE_INFO:
						NdisCopyMemory(&security_info->device_info,&wdev->ez_security.device_info, sizeof(device_info_t));
						break;
					case ACTION_UPDATE_CONFIG_STATUS:
						if (target_wdev->ez_security.configured_status == EZ_UNCONFIGURED) {
							target_wdev->ez_security.configured_status = EZ_CONFIGURED;
							ez_update_security_setting(adOthBand, target_wdev, target_wdev->ez_security.this_band_info.pmk);
							ez_updage_ap_wsc_profile(adOthBand, target_wdev, target_wdev->func_idx);
							if (target_wdev->wdev_type == WDEV_TYPE_AP)
							{
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Move AP into configured state\n"));
								EZ_UPDATE_CAPABILITY_INFO(adOthBand, EZ_SET_ACTION, CONFIGRED, target_wdev->func_idx);
							} else {
								
								EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Move CLI into configured state\n"));
								EZ_UPDATE_APCLI_CAPABILITY_INFO(adOthBand, EZ_SET_ACTION, CONFIGRED, target_wdev->func_idx);
							}
							EZ_SET_CAP_CONFIGRED(target_wdev->ez_security.capability);
						}
						break;
					
					}
				}
			}
		}
	
#endif		 
}

static BOOLEAN ez_ap_basic_config_changed(void * wdev_obj, updated_configs_t *updated_configs)
{
	struct wifi_dev* wdev = wdev_obj;
	interface_info_t *curr_band_info = NULL;
	interface_info_t *update_band_info = NULL;

	if(!wdev_obj || !updated_configs){
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_ap_basic_config_changed: Invalid params\n"));
	}

	curr_band_info = &wdev->ez_security.this_band_info;
	update_band_info = &updated_configs->this_band_info;

	if(curr_band_info->shared_info.ssid_len != update_band_info->shared_info.ssid_len)
		return TRUE;

	if( NdisCmpMemory(curr_band_info->shared_info.ssid,
		    update_band_info->shared_info.ssid,
		    update_band_info->shared_info.ssid_len) != 0 ){
		return TRUE;
	}

	if( (curr_band_info->shared_info.channel_info.channel != update_band_info->shared_info.channel_info.channel) ||
#ifdef EZ_PUSH_BW_SUPPORT
		( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config && 
		  ((curr_band_info->shared_info.channel_info.ht_bw != update_band_info->shared_info.channel_info.ht_bw ) ||
		  (curr_band_info->shared_info.channel_info.vht_bw != update_band_info->shared_info.channel_info.vht_bw ))) ||
#endif
		(curr_band_info->shared_info.channel_info.extcha != update_band_info->shared_info.channel_info.extcha) )
	{
		return TRUE;
	}

	if( NdisCmpMemory(curr_band_info->pmk,
			update_band_info->pmk,
			PMK_LEN) != 0 ){
		return TRUE;
	}

#ifdef DOT11R_FT_SUPPORT
	if(wdev->FtCfg.FtCapFlag.Dot11rFtEnable && ( NdisCmpMemory(curr_band_info->shared_info.FtMdId,
			update_band_info->shared_info.FtMdId,
			FT_MDID_LEN) != 0 ) )
	{
		return TRUE;
	}
#endif

	return FALSE;
}
VOID APScanCnclAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem);

BOOLEAN ez_update_other_band_ap(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOL group_id_diff)
{
	struct wifi_dev* wdev = wdev_obj;
	struct wifi_dev *other_band_wdev = NULL; 
	PRTMP_ADAPTER ad = (PRTMP_ADAPTER)ad_obj;
	BOOLEAN action_frame_sent = FALSE;
	updated_configs_t updated_configs_local;
	struct wifi_dev* ap_wdev = &ad->ApCfg.MBSSID[wdev->func_idx].wdev;
	struct wifi_dev* cli_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx].wdev;

#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		 adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
	if(adOthBand == NULL) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
		ASSERT(FALSE);
		}
	}
#endif
	if (ApScanRunning(ad))
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("--->Cancel scan on other band\n"));

		APScanCnclAction(ad,NULL);
	}

#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(ad))
	{
		if (ApScanRunning(adOthBand))
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("--->Cancel scan on other band\n"));
			APScanCnclAction(adOthBand,NULL);
		}
	}
#endif	
	if (IS_SINGLE_CHIP_DBDC(ad))
		other_band_wdev = &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev;
#ifdef DUAL_CHIP 
	else
		other_band_wdev = &adOthBand->ApCfg.MBSSID[0].wdev;
#endif
		if(other_band_wdev == NULL || other_band_wdev->ez_security.this_band_info.interface_activated != TRUE)
		{
			if(other_band_wdev){
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_update_other_band_ap -->other_band interface down !!!! %d\n",
												other_band_wdev->ez_security.this_band_info.interface_activated));
			}

			NdisCopyMemory(&ap_wdev->ez_security.other_band_info_backup,&updated_configs->other_band_info,sizeof(interface_info_t));
			ap_wdev->ez_security.other_band_info_backup.interface_activated = 1;
			NdisCopyMemory(&cli_wdev->ez_security.other_band_info_backup,&updated_configs->other_band_info,sizeof(interface_info_t));
			cli_wdev->ez_security.other_band_info_backup.interface_activated = 1;

			return FALSE;
		}
		NdisCopyMemory(&updated_configs_local,updated_configs,sizeof(updated_configs_t));
		NdisCopyMemory(&updated_configs_local.this_band_info,&updated_configs->other_band_info,sizeof(interface_info_t));
		NdisCopyMemory(&updated_configs_local.other_band_info,&updated_configs->this_band_info,sizeof(interface_info_t));
		if (IS_SINGLE_CHIP_DBDC(ad))
		action_frame_sent = ez_update_ap(ad, other_band_wdev, &updated_configs_local, group_id_diff, TRUE);
#ifdef DUAL_CHIP
        	else
			action_frame_sent = ez_update_ap(adOthBand, other_band_wdev, &updated_configs_local, group_id_diff, TRUE);
#endif
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("update beacon for other band\n"));
		//UpdateBeaconHandler(ad, other_band_wdev, BCN_UPDATE_IE_CHG);
		return action_frame_sent;
//	} else {
//	}
//	return FALSE;
}
BOOLEAN ez_update_this_band_ap(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOL group_id_diff)
{
	return ez_update_ap(ad_obj, wdev_obj, updated_configs, group_id_diff, FALSE);
}
BOOLEAN ez_update_ap(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOL group_id_diff, BOOLEAN band_switched)
{
	struct wifi_dev* wdev = wdev_obj;
	PRTMP_ADAPTER ad = ad_obj;
	BOOLEAN ret_value =FALSE;
	BOOLEAN deauth_non_ez_sta = TRUE;

#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		 adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
		if(adOthBand == NULL) {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		}
#endif

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s >>>\n", __FUNCTION__));

	if (updated_configs->this_band_info.interface_activated == FALSE)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("do not update as no configs provided\n"));
		return FALSE;
	}
	//if (IS_SINGLE_CHIP_DBDC(ad))
	{
		
		BSS_STRUCT *mbss;
		if (wdev->wdev_type == WDEV_TYPE_APCLI)
		{
			wdev = &ad->ApCfg.MBSSID[wdev->func_idx].wdev;
		}
		mbss = wdev->func_dev;
		
		//NdisCopyMemory(&wdev->ez_security.device_info, &updated_configs->device_info, sizeof(device_info_t));
		wdev->ez_security.device_info.network_weight[0] &= ~(BIT(7));

		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s, wdev_idx:%x wdev->type: %x weight_defining_link, mac = %02x:%02x:%02x:%02x:%02x:%02x\n", 
			__FUNCTION__,wdev->wdev_idx, wdev->wdev_type, PRINT_MAC(updated_configs->mac_addr)));

		deauth_non_ez_sta = ez_ap_basic_config_changed(wdev,updated_configs);

		wdev->ez_security.this_band_info.shared_info.ssid_len = updated_configs->this_band_info.shared_info.ssid_len;
		NdisZeroMemory(wdev->ez_security.this_band_info.shared_info.ssid,MAX_LEN_OF_SSID);
		NdisCopyMemory(wdev->ez_security.this_band_info.shared_info.ssid, updated_configs->this_band_info.shared_info.ssid, updated_configs->this_band_info.shared_info.ssid_len);

		wdev->ez_security.this_band_info.shared_info.channel_info.channel = updated_configs->this_band_info.shared_info.channel_info.channel;
		wdev->ez_security.this_band_info.shared_info.channel_info.extcha = updated_configs->this_band_info.shared_info.channel_info.extcha;
#ifdef EZ_PUSH_BW_SUPPORT
		if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config ){
			if(updated_configs->this_band_info.shared_info.channel_info.ht_bw != 0xFF)
				wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw = updated_configs->this_band_info.shared_info.channel_info.ht_bw;
			if(updated_configs->this_band_info.shared_info.channel_info.vht_bw != 0xFF)
				wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw = updated_configs->this_band_info.shared_info.channel_info.vht_bw;
		}
#endif

		NdisCopyMemory(wdev->ez_security.this_band_info.pmk, updated_configs->this_band_info.pmk, PMK_LEN);
#ifdef DOT11R_FT_SUPPORT
		FT_SET_MDID(wdev->ez_security.this_band_info.shared_info.FtMdId, updated_configs->this_band_info.shared_info.FtMdId);
#endif

		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s, weight_defining_link, new channel will be %d\n", __FUNCTION__,updated_configs->this_band_info.shared_info.channel_info.channel));
#ifdef DUAL_CHIP
		if((!IS_SINGLE_CHIP_DBDC((PRTMP_ADAPTER)ad_obj)) && 
			band_switched)
			RTMP_SEM_LOCK(&((PRTMP_ADAPTER)ad_obj)->ez_set_peer_lock);
#endif
		ret_value = ez_send_action_update_config_for_this_band(ad_obj, wdev,updated_configs, group_id_diff, band_switched, deauth_non_ez_sta);
#ifdef DUAL_CHIP
		if((!IS_SINGLE_CHIP_DBDC((PRTMP_ADAPTER)ad_obj)) && 
			band_switched)
			RTMP_SEM_UNLOCK(&((PRTMP_ADAPTER)ad_obj)->ez_set_peer_lock);
#endif

		//! if group ID is different, update group ID
		if (group_id_diff)
		{
			if (updated_configs->group_id == NULL)
			{
				ASSERT(FALSE);
			}
			EZ_MEM_FREE(NULL,wdev->ez_security.group_id);
			EZ_MEM_ALLOC(NULL,&wdev->ez_security.group_id,updated_configs->group_id_len);
			NdisCopyMemory(wdev->ez_security.group_id,updated_configs->group_id,updated_configs->group_id_len);
			wdev->ez_security.open_group_id_len = updated_configs->open_group_id_len;
			NdisCopyMemory(wdev->ez_security.open_group_id,updated_configs->open_group_id,updated_configs->open_group_id_len);
			
			wdev->ez_security.group_id_len = updated_configs->group_id_len;
		}
		//! update my own parameters
		{
			mbss->SsidLen = updated_configs->this_band_info.shared_info.ssid_len ;
			os_zero_mem(mbss->Ssid, MAX_LEN_OF_SSID);
			NdisCopyMemory(mbss->Ssid, updated_configs->this_band_info.shared_info.ssid, mbss->SsidLen);
			NdisCopyMemory(&wdev->SecConfig.PMK[0], updated_configs->this_band_info.pmk, LEN_PMK);
			hex_dump("updated AP PMK", updated_configs->this_band_info.pmk, PMK_LEN);

			if (wdev->ez_security.configured_status == EZ_UNCONFIGURED) {
				wdev->ez_security.configured_status = EZ_CONFIGURED;
				EZ_SET_CAP_CONFIGRED(wdev->ez_security.capability);
			}

			CLEAR_SEC_AKM(wdev->SecConfig.AKMMap);
			SET_AKM_WPA2PSK(wdev->SecConfig.AKMMap);
			SET_CIPHER_CCMP128(wdev->SecConfig.PairwiseCipher);
			SET_CIPHER_CCMP128(wdev->SecConfig.GroupCipher);
			ez_update_security_setting(ad, wdev, updated_configs->this_band_info.pmk);
			ez_updage_ap_wsc_profile(ad, wdev, wdev->func_idx);

#ifdef DOT11R_FT_SUPPORT
			FT_SET_MDID(wdev->FtCfg.FtMdId, updated_configs->this_band_info.shared_info.FtMdId);
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s::FtCfg FtMdid =%c%c\n", __FUNCTION__,
			//							wdev->FtCfg.FtMdId[0],
			//							wdev->FtCfg.FtMdId[1]));
#endif

#ifdef EZ_PUSH_BW_SUPPORT
			if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
			{
				if(updated_configs->this_band_info.shared_info.channel_info.ht_bw != 0xFF)
					wlan_config_set_ht_bw(wdev, updated_configs->this_band_info.shared_info.channel_info.ht_bw);
				if(updated_configs->this_band_info.shared_info.channel_info.vht_bw != 0xFF)
					wlan_config_set_vht_bw(wdev, updated_configs->this_band_info.shared_info.channel_info.vht_bw);
			}
#endif
			wlan_config_set_ext_cha(wdev, updated_configs->this_band_info.shared_info.channel_info.extcha);

#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3))
			if(wdev->ez_security.ap_did_fallback){
				if(wdev->ez_security.fallback_channel == updated_configs->this_band_info.shared_info.channel_info.channel){
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("\nez_update_ap:Restoring ap to fallback mode\n"));
					wlan_operate_set_ht_bw(wdev,HT_BW_20, EXTCHA_NONE);
				}
			}
#endif

			SetCommonHtVht(ad,wdev);
			
 			UpdateBeaconHandler(wdev->sys_handle, wdev, BCN_UPDATE_IE_CHG);
			
 		}
		
	}
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s <<<\n", __FUNCTION__));

	return ret_value;
}
BOOLEAN ez_update_other_band_cli(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOL group_id_diff)
{
	struct wifi_dev* wdev = wdev_obj;
	PRTMP_ADAPTER ad = ad_obj;
	struct wifi_dev *other_band_wdev = NULL, *other_ap_band_wdev=NULL;
	updated_configs_t updated_configs_local;
	BOOLEAN action_frame_sent;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
	 adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
	if(adOthBand == NULL) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
		ASSERT(FALSE);
		}
	}
#endif
	if (IS_SINGLE_CHIP_DBDC(ad))
	{
		other_band_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev;
		other_ap_band_wdev = &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev;
	}
#ifdef DUAL_CHIP
	else
	{
		other_band_wdev = &adOthBand->ApCfg.ApCliTab[wdev->func_idx].wdev;
		other_ap_band_wdev = &adOthBand->ApCfg.MBSSID[wdev->func_idx].wdev;
	}
#endif

		if(other_band_wdev == NULL || other_band_wdev->ez_security.this_band_info.interface_activated != TRUE)
		{
			if(other_band_wdev){
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_update_other_band_cli -->other_band interface down !!!! %d\n",
											other_band_wdev->ez_security.this_band_info.interface_activated));
			}
			
			//NdisCopyMemory(&wdev->ez_security.other_band_info_backup,&updated_configs->other_band_info,sizeof(interface_info_t));
			//wdev->ez_security.other_band_info_backup.interface_activated = 1;
			if (other_ap_band_wdev->ez_security.this_band_info.interface_activated && (updated_configs->context_linkdown == FALSE)) {	
				ez_restore_channel_config(other_ap_band_wdev);
#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3))
				if(other_ap_band_wdev->ez_security.ap_did_fallback){
					if(other_ap_band_wdev->ez_security.fallback_channel != other_ap_band_wdev->ez_security.this_band_info.shared_info.channel_info.channel){
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("\nez_update_other_band_cli: Last channel(%d) and current channel(%d) different, reset fallback context\n",
							other_ap_band_wdev->ez_security.fallback_channel, other_ap_band_wdev->ez_security.this_band_info.shared_info.channel_info.channel));
						ez_set_ap_fallback_context(other_ap_band_wdev,FALSE,0);
					}
				}
#endif

				if (IS_SINGLE_CHIP_DBDC(ad))
				UpdateBeaconHandler(ad, other_ap_band_wdev, BCN_UPDATE_IE_CHG);
#ifdef DUAL_CHIP
				else
					UpdateBeaconHandler(adOthBand, other_ap_band_wdev, BCN_UPDATE_IE_CHG);
#endif
			}
			return FALSE;
		}
		NdisCopyMemory(&updated_configs_local,updated_configs,sizeof(updated_configs_t));
		NdisCopyMemory(&updated_configs_local.this_band_info,&updated_configs->other_band_info,sizeof(interface_info_t));
		NdisCopyMemory(&updated_configs_local.other_band_info,&updated_configs->this_band_info,sizeof(interface_info_t));
		if (IS_SINGLE_CHIP_DBDC(ad))
		{
		action_frame_sent = ez_update_cli(ad, other_band_wdev, &updated_configs_local, group_id_diff, TRUE);
		if ((updated_configs->context_linkdown == FALSE)){
			ez_restore_channel_config(other_ap_band_wdev);
#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3))
			if(other_ap_band_wdev->ez_security.ap_did_fallback){
				if(other_ap_band_wdev->ez_security.fallback_channel != other_ap_band_wdev->ez_security.this_band_info.shared_info.channel_info.channel){
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("\nez_update_other_band_cli: Last channel(%d) and current channel(%d) different, reset fallback context\n",
						other_ap_band_wdev->ez_security.fallback_channel, other_ap_band_wdev->ez_security.this_band_info.shared_info.channel_info.channel));
					ez_set_ap_fallback_context(other_ap_band_wdev,FALSE,0);
				}
			}
#endif
			UpdateBeaconHandler(ad, other_ap_band_wdev, BCN_UPDATE_IE_CHG);
		}
		}
#ifdef DUAL_CHIP
		else
		{
			action_frame_sent = ez_update_cli(adOthBand, other_band_wdev, &updated_configs_local, group_id_diff, TRUE);
			if ((updated_configs->context_linkdown == FALSE)){
				ez_restore_channel_config(other_ap_band_wdev);
#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3))
				if(other_ap_band_wdev->ez_security.ap_did_fallback){
					if(other_ap_band_wdev->ez_security.fallback_channel != other_ap_band_wdev->ez_security.this_band_info.shared_info.channel_info.channel){
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("\nez_update_other_band_cli: Last channel(%d) and current channel(%d) different, reset fallback context\n",
							other_ap_band_wdev->ez_security.fallback_channel, other_ap_band_wdev->ez_security.this_band_info.shared_info.channel_info.channel));
						ez_set_ap_fallback_context(other_ap_band_wdev,FALSE,0);
					}
				}
#endif

				UpdateBeaconHandler(adOthBand, other_ap_band_wdev, BCN_UPDATE_IE_CHG);
			}	
	}
#endif
		return action_frame_sent;
}

BOOLEAN ez_update_this_band_cli(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOL group_id_diff)
{
	return ez_update_cli(ad_obj, wdev_obj, updated_configs, group_id_diff, FALSE);
}
BOOLEAN ez_update_cli(void * ad_obj, void * wdev_obj, updated_configs_t *updated_configs, BOOL group_id_diff, BOOLEAN band_switched)
{
	struct wifi_dev* wdev = wdev_obj;
	APCLI_STRUCT *apcli_entry;
	PRTMP_ADAPTER ad = ad_obj;
	BOOLEAN ret_value = FALSE;
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s >>>\n", __FUNCTION__));
	
	//if (IS_SINGLE_CHIP_DBDC(ad))
//	{
		
		if (updated_configs->this_band_info.interface_activated == FALSE)
		{
			
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("do not update as no configs provided\n"));
			return FALSE;
		}
		if (wdev->wdev_type == WDEV_TYPE_AP)
		{
			wdev = &ad->ApCfg.ApCliTab[wdev->func_idx].wdev;
		}
		apcli_entry = wdev->func_dev;
		
		//NdisCopyMemory(&wdev->ez_security.device_info, &updated_configs->device_info, sizeof(device_info_t));
		wdev->ez_security.device_info.network_weight[0] &= ~(BIT(7));
		
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s, wdve_idx:%x wdev_type:%x weight_defining_link, mac = %02x:%02x:%02x:%02x:%02x:%02x\n", 
			__FUNCTION__,wdev->wdev_idx, wdev->wdev_type,PRINT_MAC(updated_configs->mac_addr)));
				
		wdev->ez_security.this_band_info.shared_info.ssid_len = updated_configs->this_band_info.shared_info.ssid_len;
		NdisZeroMemory(wdev->ez_security.this_band_info.shared_info.ssid,MAX_LEN_OF_SSID);
		NdisCopyMemory(wdev->ez_security.this_band_info.shared_info.ssid, updated_configs->this_band_info.shared_info.ssid, updated_configs->this_band_info.shared_info.ssid_len);

		wdev->ez_security.this_band_info.shared_info.channel_info.channel = updated_configs->this_band_info.shared_info.channel_info.channel;
		wdev->ez_security.this_band_info.shared_info.channel_info.extcha = updated_configs->this_band_info.shared_info.channel_info.extcha;
#ifdef EZ_PUSH_BW_SUPPORT
		if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config ){
			if(updated_configs->this_band_info.shared_info.channel_info.ht_bw != 0xFF)
				wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw = updated_configs->this_band_info.shared_info.channel_info.ht_bw;
			if(updated_configs->this_band_info.shared_info.channel_info.vht_bw != 0xFF)
				wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw = updated_configs->this_band_info.shared_info.channel_info.vht_bw;
		}
#endif

		NdisCopyMemory(wdev->ez_security.this_band_info.pmk, updated_configs->this_band_info.pmk, PMK_LEN);

#ifdef DOT11R_FT_SUPPORT
		FT_SET_MDID(wdev->ez_security.this_band_info.shared_info.FtMdId, updated_configs->this_band_info.shared_info.FtMdId);
#endif

		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s, weight_defining_link, new channel will be %d\n", __FUNCTION__,updated_configs->this_band_info.shared_info.channel_info.channel));

		//ret_value = ez_send_action_update_config_for_this_band(ad_obj, wdev,updated_configs, group_id_diff, band_switched);
				

		//! if group ID is different, update group ID
		if (group_id_diff)
		{
			if (updated_configs->group_id == NULL)
			{
				ASSERT(FALSE);
			}
			EZ_MEM_FREE(NULL,wdev->ez_security.group_id);
			EZ_MEM_ALLOC(NULL,&wdev->ez_security.group_id,updated_configs->group_id_len);
			NdisCopyMemory(wdev->ez_security.group_id,updated_configs->group_id,updated_configs->group_id_len);
			wdev->ez_security.open_group_id_len = updated_configs->open_group_id_len;
			NdisCopyMemory(wdev->ez_security.open_group_id,updated_configs->open_group_id,updated_configs->open_group_id_len);
			
			wdev->ez_security.group_id_len = updated_configs->group_id_len;
		}
		//! update my own parameters
		{
		
			NdisZeroMemory(apcli_entry->Ssid,MAX_LEN_OF_SSID);
			apcli_entry->SsidLen = updated_configs->this_band_info.shared_info.ssid_len ;
			NdisCopyMemory(apcli_entry->Ssid, updated_configs->this_band_info.shared_info.ssid,updated_configs->this_band_info.shared_info.ssid_len );
			
			NdisZeroMemory(apcli_entry->CfgSsid,MAX_LEN_OF_SSID);
			apcli_entry->CfgSsidLen = updated_configs->this_band_info.shared_info.ssid_len ;
			NdisCopyMemory(apcli_entry->CfgSsid, updated_configs->this_band_info.shared_info.ssid,updated_configs->this_band_info.shared_info.ssid_len );
	
			NdisCopyMemory(&wdev->SecConfig.PMK[0], updated_configs->this_band_info.pmk, LEN_PMK);

			
			if (wdev->ez_security.configured_status == EZ_UNCONFIGURED) {
				wdev->ez_security.configured_status = EZ_CONFIGURED;
				ez_update_security_setting(ad, wdev, updated_configs->this_band_info.pmk);
				ez_updage_ap_wsc_profile(ad, wdev, wdev->func_idx);
				EZ_SET_CAP_CONFIGRED(wdev->ez_security.capability);
			}
			CLEAR_SEC_AKM(wdev->SecConfig.AKMMap);
			SET_AKM_WPA2PSK(wdev->SecConfig.AKMMap);
			SET_CIPHER_CCMP128(wdev->SecConfig.PairwiseCipher);
			SET_CIPHER_CCMP128(wdev->SecConfig.GroupCipher);
#ifdef EZ_PUSH_BW_SUPPORT
			if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
			{
				if(updated_configs->this_band_info.shared_info.channel_info.ht_bw != 0xFF)
					wlan_config_set_ht_bw(wdev, updated_configs->this_band_info.shared_info.channel_info.ht_bw);
				if(updated_configs->this_band_info.shared_info.channel_info.vht_bw != 0xFF)
					wlan_config_set_vht_bw(wdev, updated_configs->this_band_info.shared_info.channel_info.vht_bw);
			}
#endif
			wlan_config_set_ext_cha(wdev, updated_configs->this_band_info.shared_info.channel_info.extcha);

			SetCommonHtVht(ad,wdev);		
		}
				

#ifdef DUAL_CHIP
		if((!IS_SINGLE_CHIP_DBDC(ad)) && 
			band_switched) 
			RTMP_SEM_LOCK(&ad->ez_set_peer_lock);
#endif
		//! if action is from AP_CLI and same band, no need to send a de-auth and action frame
		hex_dump("this_band cli_peer_ap_mac",wdev->ez_security.this_band_info.cli_peer_ap_mac, 6);
		if (!MAC_ADDR_EQUAL(wdev->ez_security.this_band_info.cli_peer_ap_mac, updated_configs->mac_addr) 
			&& !MAC_ADDR_EQUAL(wdev->ez_security.this_band_info.cli_peer_ap_mac, ZERO_MAC_ADDR))
		{
			if(wdev->ez_security.this_band_info.shared_info.link_duplicate && band_switched)
			{
				struct _ez_peer_security_info *ez_peer  = ez_peer_table_search_by_addr(wdev, wdev->ez_security.this_band_info.cli_peer_ap_mac);
				if (ez_peer){
					struct _ez_peer_security_info *ez_other_band_peer = ez_get_other_band_ez_peer(wdev_obj,ez_peer);
					if(ez_other_band_peer == NULL)
					{
						ASSERT(FALSE);
					}
					NdisCopyMemory(&ez_peer->device_info.ez_node_number,&ez_other_band_peer->device_info.ez_node_number, sizeof(EZ_NODE_NUMBER));
				}
			} else {
				struct _ez_peer_security_info *ez_peer = NULL;
				ez_peer  = ez_peer_table_search_by_addr(wdev, wdev->ez_security.this_band_info.cli_peer_ap_mac);
				if ((ez_peer) && (ez_peer->port_secured)){
					if (send_action_update_config(ad, ez_peer, wdev, updated_configs, TRUE, group_id_diff)== TRUE)
					ret_value = TRUE;
				}
			}
		}
#ifdef DUAL_CHIP
		if((!IS_SINGLE_CHIP_DBDC(ad)) && 
			band_switched)
			RTMP_SEM_UNLOCK(&ad->ez_set_peer_lock);
#endif

		
//	} else {
//	}
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s <<<\n", __FUNCTION__));
	return ret_value;
}

#ifdef EZ_PUSH_BW_SUPPORT

#ifdef DOT11_N_SUPPORT
/*
	========================================================================
	Rakesh: based on ApCliCheckHt

	========================================================================
*/
static BOOLEAN ez_ApStaSetHt(
	IN struct wifi_dev *wdev,
	MAC_TABLE_ENTRY *pEntry)
{
	HT_CAPABILITY_IE *aux_ht_cap;
	UCHAR cfg_ht_bw;
	PRTMP_ADAPTER ad = (PRTMP_ADAPTER)wdev->sys_handle;

	cfg_ht_bw = wlan_config_get_ht_bw(wdev);

	aux_ht_cap = &pEntry->HTCapability;
	/* choose smaller setting */

#ifdef CONFIG_MULTI_CHANNEL
	aux_ht_cap->HtCapInfo.ChannelWidth = cfg_ht_bw; //pAddHtInfo->AddHtInfo.RecomWidth;
#else /* CONFIG_MULTI_CHANNEL */
	aux_ht_cap->HtCapInfo.ChannelWidth = cfg_ht_bw; //pAddHtInfo->AddHtInfo.RecomWidth & cfg_ht_bw;
#endif /* !CONFIG_MULTI_CHANNEL */

	/* Fix throughput issue for some vendor AP with AES mode */
	if (cfg_ht_bw) // remove pAddHtInfo->AddHtInfo.RecomWidth & check
		aux_ht_cap->HtCapInfo.CCKmodein40 = ad->CommonCfg.HtCapability.HtCapInfo.CCKmodein40;
	else 
		aux_ht_cap->HtCapInfo.CCKmodein40 = 0;

	return TRUE;
}

/*
	========================================================================
	Rakesh: based on ApCliCheckHt

	========================================================================
*/
static BOOLEAN ez_ApCliSetHt(
	IN APCLI_STRUCT *pApCliEntry,
	MAC_TABLE_ENTRY *pEntry)
{
	HT_CAPABILITY_IE *aux_ht_cap;
	UCHAR cfg_ht_bw;
	PRTMP_ADAPTER ad = (PRTMP_ADAPTER)(pApCliEntry->wdev.sys_handle);

	cfg_ht_bw = wlan_config_get_ht_bw(&pApCliEntry->wdev);

	aux_ht_cap = &pApCliEntry->MlmeAux.HtCapability;
	/* choose smaller setting */

#ifdef CONFIG_MULTI_CHANNEL
	aux_ht_cap->HtCapInfo.ChannelWidth = cfg_ht_bw; //pAddHtInfo->AddHtInfo.RecomWidth;
#else /* CONFIG_MULTI_CHANNEL */
	aux_ht_cap->HtCapInfo.ChannelWidth = cfg_ht_bw; //pAddHtInfo->AddHtInfo.RecomWidth & cfg_ht_bw;
#endif /* !CONFIG_MULTI_CHANNEL */

	/* Fix throughput issue for some vendor AP with AES mode */
	if (cfg_ht_bw) // remove pAddHtInfo->AddHtInfo.RecomWidth & check
		aux_ht_cap->HtCapInfo.CCKmodein40 = ad->CommonCfg.HtCapability.HtCapInfo.CCKmodein40;
	else 
		aux_ht_cap->HtCapInfo.CCKmodein40 = 0;

	/* Record the RxMcs of AP */
	NdisMoveMemory(pApCliEntry->RxMcsSet, ad->CommonCfg.HtCapability.MCSSet, 16);

	NdisMoveMemory(&pEntry->HTCapability, &pApCliEntry->MlmeAux.HtCapability, sizeof(HT_CAPABILITY_IE));
	NdisMoveMemory(pEntry->HTCapability.MCSSet, pApCliEntry->RxMcsSet, 16);

	return TRUE;
}

#endif

#ifdef DOT11_VHT_AC
/*
	========================================================================
	Rakesh: based on build_vht_ies & build_vht_cap_ie

	========================================================================
*/
static BOOLEAN ez_ApStaSetVht(
	IN struct wifi_dev *wdev,
	MAC_TABLE_ENTRY *pEntry)
{
	UCHAR cfg_vht_bw;
	VHT_CAP_IE *pVht_cap_ie = NULL;
	PRTMP_ADAPTER pAd = NULL;
	UCHAR bw;

	pAd = (PRTMP_ADAPTER)wdev->sys_handle;
	bw = pAd->CommonCfg.vht_bw;
	cfg_vht_bw = wlan_config_get_vht_bw(wdev);
	pVht_cap_ie = &pEntry->vht_cap_ie;

	//Use cfg_vht_bw instead of pAd->CommonCfg.vht_bw

	if (cfg_vht_bw == VHT_BW_160)
	{
		pVht_cap_ie->vht_cap.ch_width = 1;
		pVht_cap_ie->vht_cap.sgi_160M = pAd->CommonCfg.vht_sgi;
	}
	else if (cfg_vht_bw == VHT_BW_8080)
	{
		pVht_cap_ie->vht_cap.ch_width = 2;
		pVht_cap_ie->vht_cap.sgi_160M = pAd->CommonCfg.vht_sgi;
	}
	else
	{
		pVht_cap_ie->vht_cap.ch_width = 0;
	}
	
	return TRUE;
}

/*
	========================================================================
	Rakesh: based on build_vht_ies & build_vht_cap_ie

	========================================================================
*/
static BOOLEAN ez_ApCliSetVht(
	IN APCLI_STRUCT *pApCliEntry,
	MAC_TABLE_ENTRY *pEntry)
{
	UCHAR cfg_vht_bw;
	VHT_CAP_IE *pVht_cap_ie = NULL;
	PRTMP_ADAPTER pAd = NULL;
	UCHAR bw;
	VHT_OP_IE *pVht_op = NULL;
	UCHAR cent_ch;
	UCHAR prim_ch;

	pAd = (PRTMP_ADAPTER)pApCliEntry->wdev.sys_handle;
	bw = pAd->CommonCfg.vht_bw;
	cfg_vht_bw = wlan_config_get_vht_bw(&pApCliEntry->wdev);
	pVht_cap_ie = &pApCliEntry->MlmeAux.vht_cap;
	pVht_op = &pApCliEntry->MlmeAux.vht_op;

	//Use cfg_vht_bw instead of pAd->CommonCfg.vht_bw

	if (cfg_vht_bw == VHT_BW_160)
	{
		pVht_cap_ie->vht_cap.ch_width = 1;
		pVht_cap_ie->vht_cap.sgi_160M = pAd->CommonCfg.vht_sgi;
	}
	else if (cfg_vht_bw == VHT_BW_8080)
	{
		pVht_cap_ie->vht_cap.ch_width = 2;
		pVht_cap_ie->vht_cap.sgi_160M = pAd->CommonCfg.vht_sgi;
	}
	else
	{
		pVht_cap_ie->vht_cap.ch_width = 0;
	}

	// Rakesh: assuming pApCliEntry->MlmeAux.vht_cap is correct
	NdisMoveMemory(&pEntry->vht_cap_ie, &pApCliEntry->MlmeAux.vht_cap, sizeof(VHT_CAP_IE));

#ifdef CONFIG_AP_SUPPORT
	if (pApCliEntry->wdev.channel > 14 && 
		(pAd->CommonCfg.bIEEE80211H == 1) && 
		(pAd->Dot11_H.RDMode == RD_SWITCHING_MODE)) {
		cent_ch = vht_cent_ch_freq(pAd->Dot11_H.org_ch, bw);
		prim_ch = pAd->Dot11_H.org_ch;
	} else
#endif /* CONFIG_AP_SUPPORT */
	{
		cent_ch = vht_cent_ch_freq(pApCliEntry->wdev.channel, bw);
		prim_ch = pApCliEntry->wdev.channel;
	}

	switch (bw)
	{
		case VHT_BW_2040:
			pVht_op->vht_op_info.ch_width = 0;
			pVht_op->vht_op_info.center_freq_1 = 0;
			pVht_op->vht_op_info.center_freq_2 = 0;
			break;
		case VHT_BW_80:
			pVht_op->vht_op_info.ch_width = 1;
			pVht_op->vht_op_info.center_freq_1 = cent_ch;
			pVht_op->vht_op_info.center_freq_2 = 0;
			break;
		case VHT_BW_160:
#ifdef DOT11_VHT_R2
			pVht_op->vht_op_info.ch_width = 1;
			pVht_op->vht_op_info.center_freq_1 = (prim_ch > cent_ch) ? (cent_ch + 8) : (cent_ch - 8);
			pVht_op->vht_op_info.center_freq_2 = cent_ch;
#else
			pVht_op->vht_op_info.ch_width = 2;
			pVht_op->vht_op_info.center_freq_1 = cent_ch;
			pVht_op->vht_op_info.center_freq_2 = 0;
#endif /* DOT11_VHT_R2 */
			break;
		case VHT_BW_8080:
#ifdef DOT11_VHT_R2 
			pVht_op->vht_op_info.ch_width = 1;
			pVht_op->vht_op_info.center_freq_1 = cent_ch;
			pVht_op->vht_op_info.center_freq_2 = pAd->CommonCfg.vht_cent_ch2;
#else
			pVht_op->vht_op_info.ch_width = 3;
			pVht_op->vht_op_info.center_freq_1 = cent_ch;
			pVht_op->vht_op_info.center_freq_2 = pAd->CommonCfg.vht_cent_ch2;
#endif /* DOT11_VHT_R2 */
			break;
	}
					
	return TRUE;
}

#endif /* DOT11_N_SUPPORT */

void ez_update_other_band_ap_peer_record(void * ad_obj, void * wdev_obj)
{
	struct wifi_dev* wdev = wdev_obj;
	struct wifi_dev *other_band_wdev = NULL; 
	PRTMP_ADAPTER ad = (PRTMP_ADAPTER)ad_obj;

#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		 adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
	if(adOthBand == NULL) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
		ASSERT(FALSE);
		}
	}
#endif

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s >>>\n",__FUNCTION__));

	if (ApScanRunning(ad))
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("--->Cancel scan on other band\n"));

		APScanCnclAction(ad,NULL);
	}

#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(ad))
	{
		if (ApScanRunning(adOthBand))
		{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("--->Cancel scan on other band\n"));
			APScanCnclAction(adOthBand,NULL);
		}
	}
#endif	
	if (IS_SINGLE_CHIP_DBDC(ad))
		other_band_wdev = &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev;
#ifdef DUAL_CHIP 
	else
		other_band_wdev = &adOthBand->ApCfg.MBSSID[0].wdev;
#endif

	if(other_band_wdev == NULL || other_band_wdev->ez_security.this_band_info.interface_activated != TRUE)
	{
		return;
	}

	if (IS_SINGLE_CHIP_DBDC(ad))
		ez_update_ap_peer_record(ad, other_band_wdev, TRUE);
#ifdef DUAL_CHIP
    else
		ez_update_ap_peer_record(adOthBand, other_band_wdev, TRUE);
#endif

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s <<<\n", __FUNCTION__));
}
void ez_update_this_band_ap_peer_record(void * ad_obj, void * wdev_obj)
{
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s >>>\n",__FUNCTION__));

	ez_update_ap_peer_record(ad_obj, wdev_obj, FALSE);

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s <<<\n", __FUNCTION__));

}
void ez_update_ap_peer_record(void * ad_obj, void * wdev_obj, BOOLEAN band_switched)
{
	struct wifi_dev* wdev = wdev_obj;
	PRTMP_ADAPTER pAd = ad_obj;
	int index =0;
	MAC_TABLE_ENTRY *pEntry= NULL;
	BSS_STRUCT *mbss;
#ifdef DOT11_N_SUPPORT
	UCHAR supported_bw;
#endif
#ifdef DOT11_VHT_AC
	UCHAR vht_bw;
#endif

#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(pAd)){
		 adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL) {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		}
#endif
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s >>>\n",__FUNCTION__));

	if (wdev->wdev_type == WDEV_TYPE_APCLI)
	{
		wdev = &pAd->ApCfg.MBSSID[wdev->func_idx].wdev;
	}
	mbss = wdev->func_dev;


	for (index = 0; index < EZ_MAX_STA_NUM; index ++)
	{
	
#ifdef DUAL_CHIP
		if((!IS_SINGLE_CHIP_DBDC((PRTMP_ADAPTER)ad_obj)) && 
			band_switched)
			RTMP_SEM_LOCK(&((PRTMP_ADAPTER)ad_obj)->ez_set_peer_lock);
#endif
		if (wdev->ez_peer_table[index].port_secured){
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("%s, wdev->idx:%x ap_peer_mac = %02x:%02x:%02x:%02x:%02x:%02x\n", 
				__FUNCTION__,wdev->wdev_idx,PRINT_MAC(wdev->ez_peer_table[index].mac_addr)));

			pEntry = MacTableLookup(wdev->sys_handle,wdev->ez_peer_table[index].mac_addr);
			
#ifdef DUAL_CHIP
				if((!IS_SINGLE_CHIP_DBDC((PRTMP_ADAPTER)ad_obj)) && 
					band_switched)
					RTMP_SEM_UNLOCK(&((PRTMP_ADAPTER)ad_obj)->ez_set_peer_lock);
#endif
			if(pEntry != NULL){

				// Rakesh: print current info pMacEntry->HTPhyMode.word	pMacEntry->MaxHTPhyMode.word	ClientStatusFlags
				// pApCliEntry->MlmeAux.HtCapability	pMacEntry->HTCapability	(pApCliEntry->MlmeAux.vht_cap), (pApCliEntry->MlmeAux.vht_op)
				// pMacEntry->vht_cap_ie
				MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s(),MacEntry CURRENT MODE = %d, BW = %d\n", __FUNCTION__, 
					pEntry->MaxHTPhyMode.field.MODE, 
					pEntry->MaxHTPhyMode.field.BW));

				// Rakesh: following code taken from update_associated_mac_entry & ap_cmm_peer_assoc_req_action	

#ifdef DOT11_N_SUPPORT
				supported_bw = wlan_config_get_ht_bw(wdev);

				if(((PRTMP_ADAPTER)wdev->sys_handle)->CommonCfg.HtCapability.HtCapInfo.ChannelWidth != supported_bw){
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("**** CmnCfg HtCap chan width not in sync with current ht bw\n"));
					((PRTMP_ADAPTER)wdev->sys_handle)->CommonCfg.HtCapability.HtCapInfo.ChannelWidth = supported_bw;
				}
				
				ez_ApStaSetHt(wdev,pEntry); // will update pEntry->HTCapability
#endif
#ifdef DOT11_VHT_AC
				vht_bw = wlan_config_get_vht_bw(wdev);

				if(((PRTMP_ADAPTER)wdev->sys_handle)->CommonCfg.vht_bw != vht_bw){
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("**** CmnCfg VHt Cap chan width not in sync with current vht bw\n"));
					((PRTMP_ADAPTER)wdev->sys_handle)->CommonCfg.vht_bw = vht_bw;
				}

				ez_ApStaSetVht(wdev,pEntry); // will update pEntry->vht_cap_ie
#endif
				RTMPSetSupportMCS(wdev->sys_handle,
								OPMODE_AP,
								pEntry,
								wdev->rate.SupRate, //ie_list->SupportedRates,	// Rakesh: use ap values as same phy mode on all devices, no need to use RTMPCheckRates as done by Cli
								wdev->rate.SupRateLen, //ie_list->SupportedRatesLen,
								NULL,  				//wdev->rate.ExtRate can be used
								0,				//wdev->rate.ExtRateLen can be used
#ifdef DOT11_VHT_AC
								sizeof(pEntry->vht_cap_ie),	 //use build_vht_cap_ie??
								&pEntry->vht_cap_ie,
#endif /* DOT11_VHT_AC */
								&pEntry->HTCapability,
								sizeof(pEntry->HTCapability));

#ifdef DOT11_N_SUPPORT

				/* If this Entry supports 802.11n, upgrade to HT rate. */
				if (//(ie_list->ht_cap_len != 0) &&			// Rakesh: todo check peer capability first before updating
					//(wdev->DesiredHtPhyInfo.bHtEnable) &&
					WMODE_CAP_N(wdev->PhyMode))	// Rakesh: current code assumes all devices on same PhyMode
				{
					// Rakesh refer ht_mode_adjust() for partial changes taken here as applicable
					
					if ( //(peer->HtCapInfo.ChannelWidth) &&			Rakesh: todo check peer capability before updating
						(wlan_config_get_ht_bw(wdev)) && (wlan_operate_get_ht_bw(wdev)) && (supported_bw == BW_40))
					{
						pEntry->MaxHTPhyMode.field.BW= BW_40;
					}
					else
					{	
						pEntry->MaxHTPhyMode.field.BW = BW_20;
						pAd->MacTab.fAnyStation20Only = TRUE;
					}
						
					MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s(),MacEntry Updated MODE = %d, BW = %d\n", __FUNCTION__, 
						pEntry->MaxHTPhyMode.field.MODE, 
						pEntry->MaxHTPhyMode.field.BW));
					

#ifdef DOT11_VHT_AC
					if ( WMODE_CAP_AC(wdev->PhyMode)  // Rakesh: current code assumes PhyMode same on all devices
						//&& (Channel > 14) &&
						//ie_list->vht_cap_len	//Rakesh  Todo: check actual apability
						)
					{
						//Referred vht_mode_adjust()
						pEntry->MaxHTPhyMode.field.MODE = MODE_VHT;
						
						if ((pEntry->MaxHTPhyMode.field.BW == BW_40) && (pEntry->wdev))
						{
							//Rakesh: check config vht bw instead of DesiredHtPhyInfo
	
							if (vht_bw) {
	
								//if((vht_bw >= VHT_BW_80) && (cap->vht_cap.ch_width == 0)		Rakesh: todo check peer capability
								//	)
								//{
									//if (op != NULL) { Rakesh: todo check peer capability
									//	if(op->vht_op_info.ch_width == 0) { //peer support VHT20,40
									//		pMacEntry->MaxHTPhyMode.field.BW = BW_40;
									//	} else {
									//		pMacEntry->MaxHTPhyMode.field.BW = BW_80;
									//	}
									//} else 
									//{
										/* can not know peer capability, use it's maximum capability */
									//	pEntry->MaxHTPhyMode.field.BW = BW_80;
									//}
								//} else 
								if((vht_bw == VHT_BW_80) //&& (cap->vht_cap.ch_width != 0)	Rakesh: todo: check peer capability
										) 
								{
									pEntry->MaxHTPhyMode.field.BW = BW_80;
								} else if (((vht_bw == VHT_BW_160) || (vht_bw == VHT_BW_8080)) //&& (cap->vht_cap.ch_width != 0)  Rakesh: check peer capability
										)
								{
									pEntry->MaxHTPhyMode.field.BW = BW_160;
								}
							}
						}

						dot11_vht_mcs_to_internal_mcs(pAd, wdev, &pEntry->vht_cap_ie, &pEntry->MaxHTPhyMode); /* Rakesh: choose vht cap ie to use */
			
					}
			
#endif /* DOT11_VHT_AC */

				}
				//else	Rakesh: todo: check actual cability
				//{
				//	pAd->MacTab.fAnyStationIsLegacy = TRUE;
				//	NdisZeroMemory(&pEntry->HTCapability, sizeof(HT_CAPABILITY_IE));
//#ifdef DOT11_VHT_AC
				//	// TODO: shiang-usw, it's ugly and need to revise it
				//	NdisZeroMemory(&pEntry->vht_cap_ie, sizeof(VHT_CAP_IE));
				//	pEntry->SupportVHTMCS1SS = 0;
				//	pEntry->SupportVHTMCS2SS = 0;
				//	pEntry->SupportVHTMCS3SS = 0;
				//	pEntry->SupportVHTMCS4SS = 0;
				//	pEntry->SupportRateMode &= (~SUPPORT_VHT_MODE);
//#endif /* DOT11_VHT_AC */
				//}
#endif /* DOT11_N_SUPPORT */
			
				pEntry->HTPhyMode.word = pEntry->MaxHTPhyMode.word;

#ifdef MT_MAC
				if ((IS_HIF_TYPE((PRTMP_ADAPTER)wdev->sys_handle), HIF_MT))
				{
					if (wdev->bAutoTxRateSwitch == TRUE)
					{
						pEntry->bAutoTxRateSwitch = TRUE;
					}
					else
					{
						pEntry->HTPhyMode.field.MCS = wdev->HTPhyMode.field.MCS;
						pEntry->bAutoTxRateSwitch = FALSE;
			
#ifdef WFA_VHT_PF
						if (WMODE_CAP_AC(wdev->PhyMode)) {
							pEntry->HTPhyMode.field.MCS = wdev->DesiredTransmitSetting.field.MCS +
														((wlan_operate_get_tx_stream(wdev) - 1) << 4);
						}
#endif /* WFA_VHT_PF */
			
						if (pEntry->HTPhyMode.field.MODE == MODE_VHT)
						{
							pEntry->HTPhyMode.field.MCS = wdev->DesiredTransmitSetting.field.MCS +
														((wlan_operate_get_tx_stream(wdev) - 1) << 4);
						}
			
						/* If the legacy mode is set, overwrite the transmit setting of this entry. */
						RTMPUpdateLegacyTxSetting((UCHAR)wdev->DesiredTransmitSetting.field.FixedTxMode, pEntry);
					}
			
				}
#endif /* MT_MAC */

				WifiSysApPeerChBwUpdate(((PRTMP_ADAPTER)wdev->sys_handle),pEntry);//,ie_list); // Rakesh: todo pass peer capabilities

			}
			else{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ERROR !!! not found other peer mac entry\n"));
				ASSERT(FALSE);
			}

		}else {
		
#ifdef DUAL_CHIP
			if((!IS_SINGLE_CHIP_DBDC((PRTMP_ADAPTER)ad_obj)) && 
				band_switched)
				RTMP_SEM_UNLOCK(&((PRTMP_ADAPTER)ad_obj)->ez_set_peer_lock);
#endif
		}
	}

	
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s <<<\n", __FUNCTION__));


}
void ez_update_other_band_cli_peer_record(void * ad_obj, void * wdev_obj)
{
	struct wifi_dev* wdev = wdev_obj;
	PRTMP_ADAPTER ad = ad_obj;
	struct wifi_dev *other_band_wdev = NULL, *other_ap_band_wdev=NULL;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
		if(adOthBand == NULL) {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
	}
#endif
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s >>>\n",__FUNCTION__));

	if (IS_SINGLE_CHIP_DBDC(ad))
	{
		other_band_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev;
		other_ap_band_wdev = &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev;
	}
#ifdef DUAL_CHIP
	else
	{
		other_band_wdev = &adOthBand->ApCfg.ApCliTab[wdev->func_idx].wdev;
		other_ap_band_wdev = &adOthBand->ApCfg.MBSSID[wdev->func_idx].wdev;
	}
#endif

	if(other_band_wdev == NULL || other_band_wdev->ez_security.this_band_info.interface_activated != TRUE)
	{
		return;
	}

	if (IS_SINGLE_CHIP_DBDC(ad))
	{
		ez_update_cli_peer_record(ad, other_band_wdev, TRUE);
	}
#ifdef DUAL_CHIP
	else
	{
		ez_update_cli_peer_record(adOthBand, other_band_wdev, TRUE);
	}
#endif
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s <<<\n", __FUNCTION__));

}

void ez_update_this_band_cli_peer_record(void * ad_obj, void * wdev_obj)
{
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s >>>\n",__FUNCTION__));

	ez_update_cli_peer_record(ad_obj, wdev_obj, FALSE);

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("%s <<<\n", __FUNCTION__));

}
void ez_update_cli_peer_record(void * ad_obj, void * wdev_obj, BOOLEAN band_switched)
{
	struct wifi_dev* wdev = wdev_obj;
	struct wifi_dev *ap_wdev = NULL;
	APCLI_STRUCT *pApCliEntry;
	PRTMP_ADAPTER pAd = ad_obj;
	MAC_TABLE_ENTRY *pMacEntry= NULL;
#ifdef DOT11_N_SUPPORT
	UCHAR supported_bw;
#endif
#ifdef DOT11_VHT_AC
	unsigned char vht_bw;
#endif

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s >>>\n", __FUNCTION__));

	if (wdev->wdev_type == WDEV_TYPE_AP)
	{
		wdev = &pAd->ApCfg.ApCliTab[wdev->func_idx].wdev;
	}
	pApCliEntry = wdev->func_dev;
	

	if ( // !MAC_ADDR_EQUAL(wdev->ez_security.this_band_info.cli_peer_ap_mac, updated_configs->mac_addr)  &&   Rakesh: from port secured should be checked if just connected ap
		!MAC_ADDR_EQUAL(wdev->ez_security.this_band_info.cli_peer_ap_mac, ZERO_MAC_ADDR))
	{
		struct _ez_peer_security_info *ez_peer = NULL;

		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("%s, wdev_idx:%x, cli_peer_ap_mac = %02x:%02x:%02x:%02x:%02x:%02x\n", 
			__FUNCTION__, wdev->wdev_idx, PRINT_MAC(wdev->ez_security.this_band_info.cli_peer_ap_mac)));
#ifdef DUAL_CHIP // Rakesh: required??	release lock quickly by validating mac entry present??
					if((!IS_SINGLE_CHIP_DBDC(pAd)) && 
						band_switched) 
						RTMP_SEM_LOCK(&pAd->ez_set_peer_lock);
#endif	
		ez_peer  = ez_peer_table_search_by_addr(wdev, wdev->ez_security.this_band_info.cli_peer_ap_mac);
		if ((ez_peer) && (ez_peer->port_secured)){

#if defined(MAC_REPEATER_SUPPORT) || defined(MT_MAC)
			UCHAR CliIdx = 0xFF;
#endif

			pMacEntry = MacTableLookup(wdev->sys_handle,ez_peer->mac_addr);
#ifdef DUAL_CHIP // Rakesh: required??	release lock quickly by validating mac entry present??
			if((!IS_SINGLE_CHIP_DBDC(pAd)) && 
				band_switched) 
				RTMP_SEM_UNLOCK(&pAd->ez_set_peer_lock);
#endif

			if(pMacEntry != NULL){

				// Rakesh: print current info pMacEntry->HTPhyMode.word	pMacEntry->MaxHTPhyMode.word	ClientStatusFlags
				// pApCliEntry->MlmeAux.HtCapability	pMacEntry->HTCapability	(pApCliEntry->MlmeAux.vht_cap), (pApCliEntry->MlmeAux.vht_op)
				// pMacEntry->vht_cap_ie
				MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s(),MacEntry CURRENT MODE = %d, BW = %d\n", __FUNCTION__, 
					pMacEntry->MaxHTPhyMode.field.MODE, 
					pMacEntry->MaxHTPhyMode.field.BW));

				// Rakesh: following code taken from ApCliLinkUp

				ap_wdev = &(((PRTMP_ADAPTER)wdev->sys_handle)->ApCfg.MBSSID[wdev->func_idx].wdev);

#ifdef DOT11_N_SUPPORT
				supported_bw = wlan_config_get_ht_bw(wdev);

				if(((PRTMP_ADAPTER)wdev->sys_handle)->CommonCfg.HtCapability.HtCapInfo.ChannelWidth != supported_bw){
					MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("**** CmnCfg HtCap chan width not in sync with current ht bw\n"));
					((PRTMP_ADAPTER)wdev->sys_handle)->CommonCfg.HtCapability.HtCapInfo.ChannelWidth = supported_bw;
				}
				
				ez_ApCliSetHt(pApCliEntry,pMacEntry); // will update pEntry->HTCapability
#endif
#ifdef DOT11_VHT_AC
				vht_bw = wlan_config_get_vht_bw(wdev);

				if(((PRTMP_ADAPTER)wdev->sys_handle)->CommonCfg.vht_bw != vht_bw){
					MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("**** CmnCfg VHt Cap chan width not in sync with current vht bw\n"));
					((PRTMP_ADAPTER)wdev->sys_handle)->CommonCfg.vht_bw = vht_bw;
				}

				ez_ApCliSetVht(pApCliEntry,pMacEntry); // will update pEntry->vht_cap_ie
#endif

#ifdef DOT11_N_SUPPORT
				/* If this Entry supports 802.11n, upgrade to HT rate. */
				//if (pApCliEntry->MlmeAux.HtCapabilityLen != 0)		Rakesh: todo check peer capability before updating
				if (WMODE_CAP_N(pApCliEntry->wdev.PhyMode))  // Rakesh: code written asuming all device suport same PhyMode
				{
					// Rakesh refer ht_mode_adjust() for partial changes taken here as applicable

					if ( //(peer->HtCapInfo.ChannelWidth) && 			Rakesh: todo check peer capability before updating
						(wlan_config_get_ht_bw(wdev)) && (wlan_operate_get_ht_bw(wdev)) && (supported_bw == BW_40))
					{
						pMacEntry->MaxHTPhyMode.field.BW= BW_40;
					}
					else
					{	
						pMacEntry->MaxHTPhyMode.field.BW = BW_20;
						pAd->MacTab.fAnyStation20Only = TRUE;
					}
						
					MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s(),MacEntry Updated MODE = %d, BW = %d\n", __FUNCTION__, 
						pMacEntry->MaxHTPhyMode.field.MODE, 
						pMacEntry->MaxHTPhyMode.field.BW));

					pMacEntry->HTPhyMode.word = pMacEntry->MaxHTPhyMode.word;
	
				}
				//else	Rakesh: Todo check AP capability
				//{
				//	pAd->MacTab.fAnyStationIsLegacy = TRUE;
				//	MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("ApCliLinkUp - MaxSupRate=%d Mbps\n",
				//					  RateIdToMbps[pMacEntry->MaxSupportedRate]));
				//}
#endif /* DOT11_N_SUPPORT */
				
				
#ifdef DOT11_VHT_AC
				//if (WMODE_CAP_AC(pApCliEntry->wdev.PhyMode) && pApCliEntry->MlmeAux.vht_cap_len &&	pApCliEntry->MlmeAux.vht_op_len)    Rakesh: Todo: check capability
				if (WMODE_CAP_AC(pApCliEntry->wdev.PhyMode))  // Rakesh: code written asuming all device suport same PhyMode
				{
					//Rakesh: referred vht_mode_adjust()
					pMacEntry->MaxHTPhyMode.field.MODE = MODE_VHT;
					
					if ((pMacEntry->MaxHTPhyMode.field.BW == BW_40) && (pMacEntry->wdev))
					{
						//Rakesh: check config vht bw instead of DesiredHtPhyInfo

						if (vht_bw) {

							//if((vht_bw >= VHT_BW_80) && (cap->vht_cap.ch_width == 0)		Rakesh: todo check peer capability
							//	)
							//{
								//if (op != NULL) {	Rakesh: todo check peer capability
								//	if(op->vht_op_info.ch_width == 0) { //peer support VHT20,40
								//		pMacEntry->MaxHTPhyMode.field.BW = BW_40;
								//	} else {
								//		pMacEntry->MaxHTPhyMode.field.BW = BW_80;
								//	}
								//} else 
								//{
									/* can not know peer capability, use it's maximum capability */
								//	pMacEntry->MaxHTPhyMode.field.BW = BW_80;
								//}
							//} else 
							if((vht_bw == VHT_BW_80) //&& (cap->vht_cap.ch_width != 0)	Rakesh: todo: check peer capability
									) 
							{
								pMacEntry->MaxHTPhyMode.field.BW = BW_80;
							} else if (((vht_bw == VHT_BW_160) || (vht_bw == VHT_BW_8080)) //&& (cap->vht_cap.ch_width != 0)  Rakesh: check peer capability
									)
							{
								pMacEntry->MaxHTPhyMode.field.BW = BW_160;
							}
						}
					}

					dot11_vht_mcs_to_internal_mcs(((PRTMP_ADAPTER)wdev->sys_handle), wdev, &pApCliEntry->MlmeAux.vht_cap, &pMacEntry->MaxHTPhyMode); /* Rakesh: keeping this as it refers BW */
	
				}
#endif /* DOT11_VHT_AC */
				
				pMacEntry->HTPhyMode.word = pMacEntry->MaxHTPhyMode.word;

				pApCliEntry->MlmeAux.SupRateLen = ap_wdev->rate.SupRateLen;
				NdisMoveMemory(pApCliEntry->MlmeAux.SupRate, ap_wdev->rate.SupRate, pApCliEntry->MlmeAux.SupRateLen); // Rakesh: RTMPCheckRates not required as same phy mode on all devices
				
				pApCliEntry->MlmeAux.ExtRateLen = ap_wdev->rate.ExtRateLen;
				NdisMoveMemory(pApCliEntry->MlmeAux.ExtRate, ap_wdev->rate.ExtRate, pApCliEntry->MlmeAux.ExtRateLen); // Rakesh: RTMPCheckRates not required as same phy mode on all devices
				
				RTMPSetSupportMCS(wdev->sys_handle,
								OPMODE_AP,
								pMacEntry,
								pApCliEntry->MlmeAux.SupRate,	
								pApCliEntry->MlmeAux.SupRateLen,
								pApCliEntry->MlmeAux.ExtRate,
								pApCliEntry->MlmeAux.ExtRateLen,
#ifdef DOT11_VHT_AC
								pApCliEntry->MlmeAux.vht_cap_len,
								&pApCliEntry->MlmeAux.vht_cap,
#endif /* DOT11_VHT_AC */
								&pApCliEntry->MlmeAux.HtCapability,
								pApCliEntry->MlmeAux.HtCapabilityLen);
				
				WifiSysApCliChBwUpdate(((PRTMP_ADAPTER)wdev->sys_handle),pApCliEntry,CliIdx, pMacEntry);
				
#ifdef MT_MAC
				if (IS_HIF_TYPE(pAd, HIF_MT)) {

					if (wdev->bAutoTxRateSwitch == TRUE)
					{
						pMacEntry->bAutoTxRateSwitch = TRUE;
					}
					else
					{
						pMacEntry->HTPhyMode.field.MCS = wdev->HTPhyMode.field.MCS;
						pMacEntry->bAutoTxRateSwitch = FALSE;
	
						/* If the legacy mode is set, overwrite the transmit setting of this entry. */
						RTMPUpdateLegacyTxSetting((UCHAR)wdev->DesiredTransmitSetting.field.FixedTxMode, pMacEntry);
					}

					RAInit(((PRTMP_ADAPTER)wdev->sys_handle), pMacEntry);
	
				}
#endif

			}
			else{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ERROR !!! not found other peer mac entry\n"));
				ASSERT(FALSE);
			}

		}else {
#ifdef DUAL_CHIP // Rakesh: required??	release lock quickly by validating mac entry present??
		if((!IS_SINGLE_CHIP_DBDC(pAd)) && 
			band_switched) 
			RTMP_SEM_UNLOCK(&pAd->ez_set_peer_lock);
#endif

		} 
	}

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("%s <<<\n", __FUNCTION__));
}
#endif

void ez_switch_wdl_to_other_band(struct wifi_dev *wdev, void *other_band_obj)
{
	if (wdev->wdev_type == WDEV_TYPE_AP)
	{
		struct _ez_peer_security_info *ez_other_band_peer = other_band_obj;
		COPY_MAC_ADDR(wdev->ez_security.device_info.weight_defining_link.peer_mac, ez_other_band_peer->this_band_info.shared_info.cli_mac_addr);
		COPY_MAC_ADDR(wdev->ez_security.device_info.weight_defining_link.peer_ap_mac, ez_other_band_peer->this_band_info.shared_info.ap_mac_addr);
		wdev->ez_security.device_info.weight_defining_link.wdev = ez_other_band_peer->wdev;
		NdisGetSystemUpTime(&wdev->ez_security.device_info.weight_defining_link.ap_time_stamp);
		NdisGetSystemUpTime(&wdev->ez_security.device_info.weight_defining_link.time_stamp);
		ez_inform_all_interfaces(wdev->sys_handle, wdev, ACTION_UPDATE_DEVICE_INFO);
	} else {
		PRTMP_ADAPTER ad;
#ifdef DUAL_CHIP
		PRTMP_ADAPTER pAdOthBand=NULL;
#endif
		interface_info_t *other_band_interface = other_band_obj;
		struct wifi_dev *other_band_wdev=NULL;
		ad = wdev->sys_handle;
#ifdef DUAL_CHIP
		if (!IS_SINGLE_CHIP_DBDC(ad))	
		pAdOthBand = ad->pAdOthBand;
#endif
		if (IS_SINGLE_CHIP_DBDC(wdev->sys_handle)){
			other_band_wdev = &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev;
		}
#ifdef DUAL_CHIP
		else {
			other_band_wdev = &pAdOthBand->ApCfg.MBSSID[0].wdev;
		}
#endif
		COPY_MAC_ADDR(wdev->ez_security.device_info.weight_defining_link.peer_mac, other_band_interface->cli_peer_ap_mac);
		COPY_MAC_ADDR(wdev->ez_security.device_info.weight_defining_link.peer_ap_mac, other_band_interface->cli_peer_ap_mac);
		wdev->ez_security.device_info.weight_defining_link.wdev = other_band_wdev;
		NdisGetSystemUpTime(&wdev->ez_security.device_info.weight_defining_link.ap_time_stamp);
		NdisGetSystemUpTime(&wdev->ez_security.device_info.weight_defining_link.time_stamp);
		ez_inform_all_interfaces(wdev->sys_handle, wdev, ACTION_UPDATE_DEVICE_INFO);
	}
}

void ez_notify_roam(PRTMP_ADAPTER pAd, struct _ez_peer_security_info * from_ez_peer)
{
	int index, i;
	BOOLEAN ap_band_switched = FALSE;
	BOOLEAN cli_band_switched = FALSE;
	
	//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("%s\n", __FUNCTION__));

	for (i=0; i<WDEV_NUM_MAX; i++)
	{
		//if (pAd->wdev_list[i]!=NULL)
		if (pAd->wdev_list[i]!=NULL &&
			ez_is_ap_apcli(pAd->wdev_list[i]))
		{
			//! first send an action frame to EZ peers so that they do not disconnect
			for (index = 0; index < EZ_MAX_STA_NUM; index ++)
			{
				if (pAd->wdev_list[i]->ez_peer_table[index].port_secured
					&& !pAd->wdev_list[i]->ez_peer_table[index].ez_disconnect_due_roam
					&& &pAd->wdev_list[i]->ez_peer_table[index] != from_ez_peer){
					
					if (from_ez_peer && (ez_is_link_duplicate(from_ez_peer) 
						&& (ez_get_other_band_ez_peer(from_ez_peer->wdev ,from_ez_peer) == &pAd->wdev_list[i]->ez_peer_table[index])))
					{
						continue;
					}

					if (ez_is_link_duplicate(&pAd->wdev_list[i]->ez_peer_table[index]))
					{
						if ((pAd->wdev_list[i]->wdev_type == WDEV_TYPE_AP) && ap_band_switched)
						{
							continue;
						} 
						else if (cli_band_switched)
						{
							continue;
						}
					}
					send_action_notify_roam(pAd, pAd->wdev_list[i],&pAd->wdev_list[i]->ez_peer_table[index]);
				}
			}
			if (pAd->wdev_list[i]->wdev_type == WDEV_TYPE_AP)
			{
				ap_band_switched = TRUE;
			} else {
				cli_band_switched = TRUE;
			}
		}
	}
#ifdef DUAL_CHIP	
	if (!IS_SINGLE_CHIP_DBDC(pAd))
	{
		PRTMP_ADAPTER pOtherBandAd = pAd->pAdOthBand;
		for (i=0; i<WDEV_NUM_MAX; i++)
		{
			if (pOtherBandAd->wdev_list[i]!=NULL &&
				ez_is_ap_apcli(pOtherBandAd->wdev_list[i]))
			{
				//! first send an action frame to EZ peers so that they do not disconnect
				for (index = 0; index < EZ_MAX_STA_NUM; index ++)
				{
					if (pOtherBandAd->wdev_list[i]->ez_peer_table[index].port_secured
						&& !pOtherBandAd->wdev_list[i]->ez_peer_table[index].ez_disconnect_due_roam
						&& &pOtherBandAd->wdev_list[i]->ez_peer_table[index] != from_ez_peer){
						if (from_ez_peer && (ez_is_link_duplicate(from_ez_peer) 
							&& (ez_get_other_band_ez_peer(from_ez_peer->wdev ,from_ez_peer) == &pOtherBandAd->wdev_list[i]->ez_peer_table[index])))
						{
							continue;
						}

						if (ez_is_link_duplicate(&pOtherBandAd->wdev_list[i]->ez_peer_table[index]))
						{
							if ((pOtherBandAd->wdev_list[i]->wdev_type == WDEV_TYPE_AP) && ap_band_switched)
							{
								continue;
							} 
							else if (cli_band_switched)
							{
								continue;
							}
						}
						send_action_notify_roam(pOtherBandAd, pOtherBandAd->wdev_list[i],&pOtherBandAd->wdev_list[i]->ez_peer_table[index]);
					}
				}
				if (pOtherBandAd->wdev_list[i]->wdev_type == WDEV_TYPE_AP)
				{
					ap_band_switched = TRUE;
				} else {
					cli_band_switched = TRUE;
				}
			}
		}
	}
#endif		

}
void ez_handle_peer_disconnection(struct wifi_dev *wdev, unsigned char * mac_addr)
{
#ifdef DUAL_CHIP	
	if (!IS_SINGLE_CHIP_DBDC(wdev->sys_handle))
		RTMP_SEM_LOCK(&ez_handle_disconnect_lock);	
#endif
	if(wdev->wdev_type == WDEV_TYPE_AP){
		struct _ez_peer_security_info *ez_peer = ez_peer_table_search_by_addr(wdev, mac_addr);
		BOOLEAN last_port_secured_state;

		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("AP's Peer down\n"));
		if (ez_peer == NULL)
		{
#ifdef DUAL_CHIP	
			if (!IS_SINGLE_CHIP_DBDC(wdev->sys_handle))
				RTMP_SEM_UNLOCK(&ez_handle_disconnect_lock);	
#endif
			return;
		}

		last_port_secured_state = ez_peer->port_secured;

		if (ez_peer->this_band_info.shared_info.link_duplicate)
		{
			MAC_TABLE_ENTRY *this_band_cli_macentry= NULL;
			MAC_TABLE_ENTRY *other_band_cli_peer_macentry= NULL;
			struct _ez_peer_security_info *ez_other_band_peer = ez_get_other_band_ez_peer(wdev, ez_peer);

			// even though entry would be deleted later, just clearing anyway
			ez_peer->this_band_info.shared_info.link_duplicate = FALSE;
			ez_peer->other_band_info.shared_info.link_duplicate = FALSE;

			this_band_cli_macentry = MacTableLookup(ez_peer->wdev->sys_handle,ez_peer->mac_addr);
			this_band_cli_macentry->link_duplicate = FALSE;
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x : Clear self connected cli [%02x-%02x-%02x-%02x-%02x-%02x] mac_entry as duplicate link\n",
				wdev->wdev_idx,wdev->wdev_type,wdev->func_idx, 
				ez_peer->mac_addr[0],ez_peer->mac_addr[1],ez_peer->mac_addr[2],
				ez_peer->mac_addr[3],ez_peer->mac_addr[4],ez_peer->mac_addr[5]));

			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("duplicate cli link down, inform others\n"));

			if (ez_other_band_peer != NULL) {
				ez_other_band_peer->this_band_info.shared_info.link_duplicate = FALSE;
				ez_other_band_peer->other_band_info.shared_info.link_duplicate = FALSE;

				
				other_band_cli_peer_macentry = MacTableLookup(ez_other_band_peer->wdev->sys_handle,ez_other_band_peer->mac_addr);
				if(other_band_cli_peer_macentry != NULL){
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,(" wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x: Clear other AP connected peer cli[%02x-%02x-%02x-%02x-%02x-%02x] as duplicate link\n",
						ez_other_band_peer->wdev->wdev_idx,ez_other_band_peer->wdev->wdev_type,ez_other_band_peer->wdev->func_idx,
						ez_other_band_peer->mac_addr[0],ez_other_band_peer->mac_addr[1],ez_other_band_peer->mac_addr[2],
						ez_other_band_peer->mac_addr[3],ez_other_band_peer->mac_addr[4],ez_other_band_peer->mac_addr[5]));
					other_band_cli_peer_macentry->link_duplicate = FALSE;
				}
				else{
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ERROR !!! not found other ap's clients mac entry\n"));
					ASSERT(FALSE);
				}

			} else {
				ASSERT(FALSE);
			}

			ez_hex_dump("MAC Addr", mac_addr, 6);
			ez_hex_dump("weight_defining_link", wdev->ez_security.device_info.weight_defining_link.peer_mac, 6);
			if (NdisEqualMemory(mac_addr, wdev->ez_security.device_info.weight_defining_link.peer_mac,MAC_ADDR_LEN))
			{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("weight defining link down, switch to other band\n"));
				ez_switch_wdl_to_other_band(wdev, ez_other_band_peer);
			}

		} else {
		
			if (NdisEqualMemory(mac_addr, wdev->ez_security.device_info.weight_defining_link.peer_mac,MAC_ADDR_LEN))
			{
					ez_peer->port_secured = FALSE; // Mark port_secured FALSE to avoid sending update_action frame to this device
					NdisGetSystemUpTime(&ez_peer->creation_time); // to avoid peer ageout logic to interfere
					
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("weight defining link down, update weight\n"));
					update_and_push_weight(wdev, NULL, NULL);
					
					EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Initiate New scan after update wt\n"));
					ez_initiate_new_scan(wdev->sys_handle);
			}

		}
		if (last_port_secured_state != TRUE)
			ez_update_connection(wdev->sys_handle,wdev);

	} else {
		PRTMP_ADAPTER ad = wdev->sys_handle;
		NdisZeroMemory(wdev->ez_security.this_band_info.cli_peer_ap_mac, MAC_ADDR_LEN);
		NdisZeroMemory(ad->ApCfg.MBSSID[wdev->func_idx].wdev.ez_security.this_band_info.cli_peer_ap_mac, MAC_ADDR_LEN);
		//dump_stack();
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("CLI Link Down\n"));

#ifdef EZ_DUAL_BAND_SUPPORT
		ez_cancel_loop_chk(wdev);
		wdev->ez_security.this_band_info.non_easy_connection = FALSE;
#endif
		if (wdev->ez_security.this_band_info.shared_info.link_duplicate)
		{
			interface_info_t other_band_config;

			NdisZeroMemory(&other_band_config, sizeof(interface_info_t));
			ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_config);
			wdev->ez_security.this_band_info.shared_info.link_duplicate = FALSE;
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x : duplicate link down, inform others\n",
				wdev->wdev_idx,wdev->wdev_type,wdev->func_idx));
			ez_inform_all_interfaces(wdev->sys_handle,wdev, ACTION_UPDATE_DUPLICATE_LINK_ENTRY);
			ez_hex_dump("MAC Addr", mac_addr, 6);
			ez_hex_dump("weight_defining_link", wdev->ez_security.device_info.weight_defining_link.peer_mac, 6);

			if (NdisEqualMemory(mac_addr, wdev->ez_security.device_info.weight_defining_link.peer_mac,MAC_ADDR_LEN))
			{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("weight defining link down, switch to other band\n"));
				ez_switch_wdl_to_other_band(wdev, &other_band_config);
			}
		} else {
			if (NdisEqualMemory(mac_addr,wdev->ez_security.device_info.weight_defining_link.peer_mac,MAC_ADDR_LEN))
			{
				interface_info_t other_band_info;
				BOOLEAN other_band_active = FALSE;
				PRTMP_ADAPTER ad = wdev->sys_handle;
				struct _ez_peer_security_info *ez_other_band_peer = NULL;
				struct wifi_dev *other_band_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev;
				struct _ez_peer_security_info *ez_peer = ez_peer_table_search_by_addr(wdev, mac_addr);
#ifdef DUAL_CHIP
				if (IS_DUAL_CHIP_DBDC(ad))
				{
					PRTMP_ADAPTER adOtherBand = ad->pAdOthBand;
					other_band_wdev = &adOtherBand->ApCfg.ApCliTab[wdev->func_idx].wdev;
				}
#endif



					if (ez_peer)
						ez_peer->port_secured = FALSE; // Mark port_secured FALSE to avoid sending update_action frame to this device

					other_band_active = ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info);
						
					if (other_band_active && !NdisEqualMemory(other_band_info.cli_peer_ap_mac,ZERO_MAC_ADDR,MAC_ADDR_LEN))
					{
						ez_other_band_peer = ez_peer_table_search_by_addr(other_band_wdev,other_band_info.cli_peer_ap_mac);
						if (ez_other_band_peer == NULL)
						{
							PMAC_TABLE_ENTRY pOtherBandEntry = NULL;
							pOtherBandEntry = MacTableLookup(other_band_wdev->sys_handle,other_band_info.cli_peer_ap_mac);
							if (pOtherBandEntry == NULL)
							{
								ASSERT(FALSE);
#ifdef DUAL_CHIP	
								if (!IS_SINGLE_CHIP_DBDC(wdev->sys_handle))
								RTMP_SEM_UNLOCK(&ez_handle_disconnect_lock);	
#endif
								return;
							}
							EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("weight defining link down, Other Band connected to non Easy, switch WDL to other band\n"));
							update_and_push_weight(other_band_wdev, pOtherBandEntry, NULL);
						} else {
							EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("weight defining link down, update weight\n"));
							update_and_push_weight(wdev, NULL, NULL);
						}
					} else {
						EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("weight defining link down, update weight\n"));
						update_and_push_weight(wdev, NULL, NULL);
					}

			} else if (ad->ApCfg.ApCliTab[wdev->func_idx].MlmeAux.support_easy_setup == 0) {
				EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("ez_handle_peer_disconnection: Non Easy Connection fail\n"));
				ez_update_connection_permission(ad,wdev,EZ_ALLOW_ALL);
			}	
		}

		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s() Link fail over !!! Restart partial scan timer\n", __FUNCTION__));
		NdisGetSystemUpTime(&wdev->partial_scan_time_stamp);

	}
#if 0			
		if (NdisEqualMemory(mac_addr,wdev->ez_security.device_info.weight_defining_link.peer_mac,MAC_ADDR_LEN))
		{
			if (wdev->ez_security.this_band_info.shared_info.link_duplicate){
				update_and_push_weight(wdev, NULL, NULL);
			}
		}
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("weight updated for all peers\n"));	
#endif	
#ifdef DUAL_CHIP	
	if (!IS_SINGLE_CHIP_DBDC(wdev->sys_handle))
		RTMP_SEM_UNLOCK(&ez_handle_disconnect_lock);
#endif		
}


BOOLEAN ez_is_channel_same(struct wifi_dev *wdev)
{
	PRTMP_ADAPTER pAd = wdev->sys_handle;
	struct wifi_dev *apcli_wdev = &pAd->ApCfg.ApCliTab[wdev->func_idx].wdev;
	channel_info_t *channel_info = &wdev->ez_security.this_band_info.shared_info.channel_info;

	if ((wdev->channel == channel_info->channel && apcli_wdev->channel == channel_info->channel) &&
#ifdef EZ_PUSH_BW_SUPPORT
	    ( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config && 
	     (wlan_config_get_ht_bw(wdev) == channel_info->ht_bw && wlan_config_get_ht_bw(apcli_wdev) == channel_info->ht_bw) &&
	     (wlan_config_get_vht_bw(wdev) == channel_info->vht_bw && wlan_config_get_vht_bw(apcli_wdev) == channel_info->vht_bw)) &&
#endif
	    (wlan_config_get_ext_cha(wdev) == channel_info->extcha && wlan_config_get_ext_cha(apcli_wdev) == channel_info->extcha)
	){
#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3))
		if(wdev->ez_security.ap_did_fallback){
			if(wdev->ez_security.fallback_channel == channel_info->channel){
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("\nez_is_channel_same: Restoring ap to fallback mode\n"));
				wlan_operate_set_ht_bw(wdev,HT_BW_20, EXTCHA_NONE);
			}
		}
#endif
		return TRUE;

	}
	else
		return FALSE;
}

void ez_restore_channel_config(struct wifi_dev *wdev)
{
	PRTMP_ADAPTER ad;
	struct wifi_dev *apcli_wdev;
	ad = wdev->sys_handle;
	apcli_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx].wdev;
	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s\n", __FUNCTION__));

	// Rakesh: Disabling this as doing it here is not right in various scenarios.
	// Optimization can be done in future for caller to choose/inform whether to skip.
	if( 
#ifdef EZ_PUSH_BW_SUPPORT
		( !(((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config) ) &&
#endif
	    (ez_is_channel_same(wdev) == TRUE) )
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_restore_channel_config: Channel already same\n")); 
		return;
	}

#ifdef EZ_PUSH_BW_SUPPORT
	if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
	{
		if(wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw != 0xFF)
			wlan_config_set_ht_bw(wdev, wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw);
		if(wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw != 0xFF)
			wlan_config_set_vht_bw(wdev, wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw);	
	}
#endif

	wlan_config_set_ext_cha(wdev, wdev->ez_security.this_band_info.shared_info.channel_info.extcha);

#ifdef EZ_PUSH_BW_SUPPORT
	if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
	{
		if(wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw != 0xFF)
			wlan_config_set_ht_bw(apcli_wdev, wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw);
		if(wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw != 0xFF)
			wlan_config_set_vht_bw(apcli_wdev, wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw); 
	}
#endif

	wlan_config_set_ext_cha(apcli_wdev, wdev->ez_security.this_band_info.shared_info.channel_info.extcha);

#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3))
	if(wdev->ez_security.ap_did_fallback){
		if(wdev->ez_security.fallback_channel == wdev->ez_security.this_band_info.shared_info.channel_info.channel){
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("\nez_restore_channel_config: Restoring ap to fallback mode\n"));
			wlan_operate_set_ht_bw(wdev,HT_BW_20, EXTCHA_NONE);
		}
	}
#endif
		
#ifdef EZ_NETWORK_MERGE_SUPPORT
#ifdef EZ_DUAL_BAND_SUPPORT
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_restore_channel_config\n APCLI=> wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x\nChannel: %d\n", 
		apcli_wdev->wdev_idx,apcli_wdev->wdev_type,apcli_wdev->func_idx,
		apcli_wdev->ez_security.this_band_info.shared_info.channel_info.channel));
#ifdef EZ_PUSH_BW_SUPPORT
	//if( ((PRTMP_ADAPTER)(apcli_wdev->sys_handle))->push_bw_config )
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: %d, CFG:%d OPER:%d\n", apcli_wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw,
			wlan_config_get_ht_bw(apcli_wdev),wlan_operate_get_ht_bw(apcli_wdev)));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: %d CFG:%d OPER:%d\n", apcli_wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw,
			wlan_config_get_vht_bw(apcli_wdev),wlan_operate_get_vht_bw(apcli_wdev)));
	}
#else
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: CFG:%d OPER:%d\n",
			wlan_config_get_ht_bw(apcli_wdev),wlan_operate_get_ht_bw(apcli_wdev)));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: CFG:%d OPER:%d\n",
			wlan_config_get_vht_bw(apcli_wdev),wlan_operate_get_vht_bw(apcli_wdev)));
	}
#endif

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tEXTCHA: %d CFG:%d OPER:%d\n", apcli_wdev->ez_security.this_band_info.shared_info.channel_info.extcha,
		wlan_config_get_ext_cha(apcli_wdev),wlan_operate_get_ext_cha(apcli_wdev)));

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("AP=>wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x\nChannel: %d\n", 
		wdev->wdev_idx,wdev->wdev_type,wdev->func_idx,
		wdev->ez_security.this_band_info.shared_info.channel_info.channel));
#ifdef EZ_PUSH_BW_SUPPORT
	//if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: %d, CFG:%d OPER:%d\n", wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw,
			wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: %d CFG:%d OPER:%d\n", wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw,
			wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
	}
#else
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: CFG:%d OPER:%d\n",
			wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: CFG:%d OPER:%d\n",
			wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
	}
#endif

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tEXTCHA: %d CFG:%d OPER:%d\n", wdev->ez_security.this_band_info.shared_info.channel_info.extcha,
		wlan_config_get_ext_cha(wdev),wlan_operate_get_ext_cha(wdev)));

#endif
#endif

	wdev->ez_security.do_not_restart_interfaces = 1;
	rtmp_set_channel(wdev->sys_handle, wdev, wdev->ez_security.this_band_info.shared_info.channel_info.channel);
	wdev->ez_security.do_not_restart_interfaces = 0;
	
}

#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3))
void ez_set_ap_fallback_context(struct wifi_dev *wdev, BOOLEAN fallback, unsigned char fallback_channel)
{
	if(wdev){
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("\nez_set_ap_fallback_context: wdev idx %x, type %x, fallback %x, chan %d\n",
			wdev->wdev_idx, wdev->wdev_type, fallback, fallback_channel));
		wdev->ez_security.ap_did_fallback = fallback;
		wdev->ez_security.fallback_channel = fallback_channel;
	}
}
#endif

#endif
void ez_start(
	void *wdev_obj,
	unsigned char ap_mode)
{
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
	RTMP_ADAPTER *ad;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand;
#endif
#ifdef APCLI_SUPPORT
	APCLI_STRUCT *apcli_entry;
#endif /* APCLI_SUPPORT */
	
	wdev = (struct wifi_dev *)wdev_obj;
	ez_sec_info = &wdev->ez_security;
	ad = (RTMP_ADAPTER *)ez_sec_info->ad;
#ifdef DUAL_CHIP
	adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
#endif
	EZ_DEBUG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n\n=== pAd->SingleChip - %d \n\n", ad->SingleChip));
	EZ_DEBUG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n\nr=== pAd = %p, pAd2=%p, pAd_5 = %p, ad->pAdOthBand = %p \n\n", ad,  pAd_2, pAd_5, ad->pAdOthBand));
	EZ_DEBUG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n\n=== wdev->channel - %d \n\n", wdev->channel));
	if (!wdev->enable_easy_setup) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s - easy setup function is disabled.(wdev_type=0x%x)\n", 
			__FUNCTION__, wdev->wdev_type));
		return;
	}

	if (ez_sec_info->group_id_len == 0) {
		/*
			Do NOT enable easy function if there is no group id information.
		*/
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%s - No group id information. return and disable easy set up.\n", 
			__FUNCTION__));
		wdev->enable_easy_setup = FALSE;
		return;
	}

	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("------> %s(): wdev_type = 0x%x\n", __FUNCTION__, wdev->wdev_type));
	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s - ez_sec_info->configured_status = %d\n", 
			__FUNCTION__, ez_sec_info->configured_status));
	ez_hex_dump("Group ID ", ez_sec_info->group_id, ez_sec_info->group_id_len);


	ez_sec_info->ez_api_mode = ad->ApCfg.MBSSID[0].wdev.ez_security.ez_api_mode;

	if (ez_sec_info->configured_status == EZ_UNCONFIGURED) {
		ez_sec_info->keep_finding_provider = TRUE; 
		SET_AKM_WPA2PSK(wdev->SecConfig.AKMMap);
		SET_CIPHER_CCMP128(wdev->SecConfig.PairwiseCipher);
		SET_CIPHER_CCMP128(wdev->SecConfig.GroupCipher);
		if (ap_mode) {
			BSS_STRUCT *ap_mbss;
			struct wifi_dev *apcli_wdev;
			STA_REC_CTRL_T *sta_rec;

			ap_mbss = &ad->ApCfg.MBSSID[wdev->func_idx];
			apcli_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx].wdev;
			os_zero_mem(&ap_mbss->Ssid[0], MAX_LEN_OF_SSID);
			snprintf(&ap_mbss->Ssid[0], MAX_LEN_OF_SSID, "MTK_AP_%02x%02x%02x", 
				wdev->if_addr[3], wdev->if_addr[4], wdev->if_addr[5]);
			snprintf(&ap_mbss->Ssid[0], MAX_LEN_OF_SSID, "%s_%02x%02x", 
				&ap_mbss->Ssid[0], RandomByte(ad), RandomByte(ad));
			ap_mbss->SsidLen = strlen(&ap_mbss->Ssid[0]);
			SetWdevEncrypMode(&wdev->SecConfig, "AES");
			SetWdevAuthMode(&wdev->SecConfig, "WPA2PSK");
			SetWdevEncrypMode(&apcli_wdev->SecConfig, "AES");
			SetWdevAuthMode(&apcli_wdev->SecConfig, "WPA2PSK");
			APSecInit(ez_sec_info->ad, wdev);
			sta_rec = &ad->MacTab.tr_entry[wdev->tr_tb_idx].StaRec;	// Correct ??, recheck
			APKeyTableInit(ez_sec_info->ad, wdev, sta_rec);
		}
	}
	else {
		BSS_STRUCT *ap_mbss;
		ap_mbss = &ad->ApCfg.MBSSID[wdev->func_idx];
		SET_AKM_WPA2PSK(wdev->SecConfig.AKMMap);
		SET_CIPHER_CCMP128(wdev->SecConfig.PairwiseCipher);
		SET_CIPHER_CCMP128(wdev->SecConfig.GroupCipher);
		if (ap_mode) {
			struct wifi_dev *apcli_wdev;
			apcli_wdev = &ad->ApCfg.ApCliTab[wdev->func_idx].wdev;
			SetWdevEncrypMode(&wdev->SecConfig, "AES");
			SetWdevAuthMode(&wdev->SecConfig, "WPA2PSK");
			SetWdevEncrypMode(&apcli_wdev->SecConfig, "AES");
			SetWdevAuthMode(&apcli_wdev->SecConfig, "WPA2PSK");
			APSecInit(ez_sec_info->ad, wdev);
		}
		ez_sec_info->keep_finding_provider = FALSE;
		SetWPAPSKKey(ad, wdev->SecConfig.PSK, strlen(wdev->SecConfig.PSK), ap_mbss->Ssid, ap_mbss->SsidLen, ap_mbss->PMK);
		NdisCopyMemory(wdev->SecConfig.PMK,ap_mbss->PMK,PMK_LEN);
		NdisCopyMemory(ap_mbss->wdev.SecConfig.PMK,ap_mbss->PMK,PMK_LEN);
		NdisCopyMemory(ap_mbss->wdev.ez_security.this_band_info.pmk,ap_mbss->PMK,PMK_LEN);
		NdisCopyMemory(ez_sec_info->this_band_info.pmk,ap_mbss->PMK,PMK_LEN);
	}

	
#ifdef EZ_NETWORK_MERGE_SUPPORT
		{
#ifdef EZ_DUAL_BAND_SUPPORT		
			BSS_STRUCT *ap_mbss;
			//APCLI_STRUCT *apcli_entry;
			struct _ez_security *other_band_sec_info = NULL;
			ap_mbss = &ad->ApCfg.MBSSID[wdev->func_idx];
			apcli_entry = &ad->ApCfg.ApCliTab[wdev->func_idx];
			if (IS_SINGLE_CHIP_DBDC(ad))
			{
				if (wdev->wdev_type == WDEV_TYPE_AP){
					other_band_sec_info = &ad->ApCfg.MBSSID[wdev->func_idx ^ 1].wdev.ez_security;
				} else {
					other_band_sec_info = &ad->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev.ez_security;
				}
			}
#ifdef DUAL_CHIP
			 else 
			{
				if(adOthBand != NULL){
					if (wdev->wdev_type == WDEV_TYPE_AP){
                                        	other_band_sec_info = &adOthBand->ApCfg.MBSSID[0].wdev.ez_security;
			} else {
                               		       	other_band_sec_info = &adOthBand->ApCfg.ApCliTab[0].wdev.ez_security;
                                	}
				}
			}
#endif
			if (other_band_sec_info->other_band_info_backup.interface_activated)
			{
				NdisCopyMemory(&ez_sec_info->device_info,&other_band_sec_info->device_info,sizeof(device_info_t));
				NdisCopyMemory(&ez_sec_info->this_band_info,&other_band_sec_info->other_band_info_backup,sizeof(interface_info_t));
#ifdef EZ_PUSH_BW_SUPPORT
				if(ez_sec_info->this_band_info.shared_info.channel_info.ht_bw == 0xFF)
					ez_sec_info->this_band_info.shared_info.channel_info.ht_bw = wlan_config_get_ht_bw(&ap_mbss->wdev);
				if(ez_sec_info->this_band_info.shared_info.channel_info.vht_bw == 0xFF)
					ez_sec_info->this_band_info.shared_info.channel_info.vht_bw = wlan_config_get_vht_bw(&ap_mbss->wdev);
#else
				ez_sec_info->this_band_info.shared_info.channel_info.rsvd1 = 0xFF;
				ez_sec_info->this_band_info.shared_info.channel_info.rsvd1 = 0xFF;
#endif
			}
			else{
				ez_sec_info->this_band_info.shared_info.ssid_len  = ap_mbss->SsidLen;
				ez_sec_info->this_band_info.shared_info.channel_info.channel = ap_mbss->wdev.channel;
#ifdef EZ_PUSH_BW_SUPPORT
				if( ((PRTMP_ADAPTER)(ap_mbss->wdev.sys_handle))->push_bw_config )
				{
					ez_sec_info->this_band_info.shared_info.channel_info.ht_bw = wlan_config_get_ht_bw(&ap_mbss->wdev);
					ez_sec_info->this_band_info.shared_info.channel_info.vht_bw = wlan_config_get_vht_bw(&ap_mbss->wdev);
				}
				else{
					ez_sec_info->this_band_info.shared_info.channel_info.ht_bw = 0xFF;
					ez_sec_info->this_band_info.shared_info.channel_info.vht_bw = 0xFF;
				}
#else
				ez_sec_info->this_band_info.shared_info.channel_info.rsvd1 = 0xFF;
				ez_sec_info->this_band_info.shared_info.channel_info.rsvd1 = 0xFF;
#endif
				ez_sec_info->this_band_info.shared_info.channel_info.extcha = wlan_config_get_ext_cha(&ap_mbss->wdev);
				NdisCopyMemory(ez_sec_info->this_band_info.shared_info.ssid, ap_mbss->Ssid, ap_mbss->SsidLen);
				NdisCopyMemory(ez_sec_info->this_band_info.pmk, ap_mbss->wdev.SecConfig.PMK, PMK_LEN);
				hex_dump("This Band PMK", ez_sec_info->this_band_info.pmk, PMK_LEN);
#ifdef DOT11R_FT_SUPPORT
				FT_SET_MDID(ez_sec_info->this_band_info.shared_info.FtMdId, ap_mbss->wdev.FtCfg.FtMdId);
#endif
			}
			ez_sec_info->this_band_info.interface_activated = TRUE;
			COPY_MAC_ADDR(ez_sec_info->this_band_info.shared_info.ap_mac_addr,ap_mbss->wdev.if_addr);

			if (wdev->wdev_type == WDEV_TYPE_APCLI){
				COPY_MAC_ADDR(ez_sec_info->this_band_info.shared_info.cli_mac_addr,apcli_entry->wdev.if_addr);
				COPY_MAC_ADDR(ap_mbss->wdev.ez_security.this_band_info.shared_info.cli_mac_addr,apcli_entry->wdev.if_addr);
			}

#endif

#if (defined(DOT11_N_SUPPORT) && defined(DOT11N_DRAFT3)) // common init for all wdev types, but used only for ap
			ez_sec_info->ap_did_fallback = FALSE;
			ez_sec_info->fallback_channel = 0;
#endif

			if (wdev->wdev_type == WDEV_TYPE_AP)
			{

				if(IS_SINGLE_CHIP_DBDC(ad)){
				NdisCopyMemory(&ez_sec_info->device_info.network_weight[1], ad->ApCfg.MBSSID[0].wdev.if_addr,MAC_ADDR_LEN);
				}
#ifdef DUAL_CHIP
				 else {
					if(ad->ApCfg.MBSSID[0].wdev.channel > 14){
						NdisCopyMemory(&ez_sec_info->device_info.network_weight[1], adOthBand->ApCfg.MBSSID[0].wdev.if_addr,MAC_ADDR_LEN);
					}
					else
					     NdisCopyMemory(&ez_sec_info->device_info.network_weight[1], ad->ApCfg.MBSSID[0].wdev.if_addr,MAC_ADDR_LEN);	
				}
#endif

#ifdef WEIGHT_DEPENDS_ON_INET
				if (ez_sec_info->go_internet) {
					ez_sec_info->device_info.network_weight[0] = 0xE;
				} else {
#endif				
					ez_sec_info->device_info.network_weight[0] = 0x0;			
#ifdef WEIGHT_DEPENDS_ON_INET
				}
#endif
				
				if (ez_sec_info->user_configured) {
					ez_sec_info->device_info.network_weight[0] = 0xF;
				}
			} else {
				NdisCopyMemory(ez_sec_info->device_info.network_weight, ad->ApCfg.MBSSID[wdev->func_idx].wdev.ez_security.device_info.network_weight,NETWORK_WEIGHT_LEN);
			}
		}		
#endif

	ez_gen_dh_public_key(ez_sec_info);

#ifdef NEW_CONNECTION_ALGO
	/*Allocate new node number for this interface.*/
	ez_allocate_node_number(ad,&ez_sec_info->device_info.ez_node_number,wdev->func_idx);
	ez_update_connection_permission(ad,ez_sec_info->wdev,EZ_ADD_ALLOW);
	wdev->ez_security.ez_max_scan_delay = EZ_MAX_SCAN_DELAY;
	wdev->ez_security.ez_scan_delay = 0;
#endif
	/* 
		Generate random Self Nonce
	*/
	GenRandom(ez_sec_info->ad, (unsigned char *)&wdev->if_addr[0], &ez_sec_info->self_nonce[0]);

#ifdef APCLI_SUPPORT
	if (wdev->wdev_type == WDEV_TYPE_APCLI) {
#ifdef EZ_NETWORK_MERGE_SUPPORT
		BSS_STRUCT *ap_mbss;
		//APCLI_STRUCT *apcli_entry;
		ap_mbss = &ad->ApCfg.MBSSID[wdev->func_idx];
#endif
		apcli_entry = &ad->ApCfg.ApCliTab[wdev->func_idx];
		apcli_entry->MlmeAux.SsidBssTab.BssNr = 0;
		apcli_entry->MlmeAux.attempted_candidate_index = EZ_INDEX_NOT_FOUND;
		apcli_entry->avoid_loop = TRUE;
		apcli_entry->stop_auto_connect = FALSE;
		SET_AKM_WPA2PSK(wdev->SecConfig.AKMMap);
		SET_CIPHER_CCMP128(wdev->SecConfig.PairwiseCipher);
		SET_CIPHER_CCMP128(wdev->SecConfig.GroupCipher);
#ifdef EZ_NETWORK_MERGE_SUPPORT
		apcli_entry->CfgSsidLen = ap_mbss->SsidLen;
		NdisCopyMemory(apcli_entry->CfgSsid, ap_mbss->Ssid, ap_mbss->SsidLen);
#endif
	}
#endif /* APCLI_SUPPORT */

#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)
	if ((wf_fwd_set_easy_setup_mode != NULL) && (ez_sec_info->ez_api_mode != CONNECTION_OFFLOAD)){
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("SET EASY SETUP MODE IN FWD MODULE\n"));
		wf_fwd_set_easy_setup_mode(TRUE);
	}
#endif

	if (ap_mode) {
		if (ez_sec_info->configured_status == EZ_CONFIGURED) {
			EZ_SET_CAP_CONFIGRED(ez_sec_info->capability);
		}

		if (ez_sec_info->go_internet)
			EZ_SET_CAP_INTERNET(ez_sec_info->capability);
		else
			EZ_CLEAR_CAP_INTERNET(ez_sec_info->capability);

#ifdef APCLI_SUPPORT
		if (wdev->func_idx < MAX_APCLI_NUM) {
			apcli_entry = &ad->ApCfg.ApCliTab[wdev->func_idx];
			if (APCLI_IF_UP_CHECK(ad, wdev->func_idx)
				&& apcli_entry->Enable) {
				EZ_SET_CAP_HAS_APCLI_INF(ez_sec_info->capability);
			}
			
			if (VALID_WCID(apcli_entry->MacTabWCID)) {
				if (ad->MacTab.tr_entry[apcli_entry->MacTabWCID].PortSecured 
						== WPA_802_1X_PORT_SECURED) {
						EZ_SET_CAP_CONNECTED(ez_sec_info->capability);
				}
			}
		}
#endif /* APCLI_SUPPORT */
					
		
		UpdateBeaconHandler(ad, wdev, BCN_UPDATE_IE_CHG);
	}

	EZ_TIMER_INIT(ad, ez_sec_info, 
		&ez_sec_info->ez_scan_timer, 
		ez_sec_info->ez_scan_timer_running, 
		ez_scan_timeout);
	EZ_TIMER_INIT(ad, ez_sec_info, 
		&ez_sec_info->ez_stop_scan_timer, 
		ez_sec_info->ez_stop_scan_timer_running, 
		ez_stop_scan_timeout);
	EZ_TIMER_INIT(ad, ez_sec_info, 
		&ez_sec_info->ez_scan_pause_timer, 
		ez_sec_info->ez_scan_pause_timer_running, 
		ez_scan_pause_timeout);
#ifdef EZ_NETWORK_MERGE_SUPPORT
	EZ_TIMER_INIT(ad, wdev, 
			&ez_sec_info->ez_group_merge_timer, 
			ez_sec_info->ez_group_merge_timer_running, 
			ez_group_merge_timeout);
#endif
#ifdef NEW_CONNECTION_ALGO
	EZ_TIMER_INIT(ad,ez_sec_info,
	&ez_sec_info->ez_connect_wait_timer,
	ez_sec_info->ez_connect_wait_timer_running,
	ez_wait_for_connection_allow_timeout);
#endif
#ifdef EZ_DUAL_BAND_SUPPORT
	ez_sec_info->first_loop_check = FALSE;
	EZ_TIMER_INIT(ad, wdev, 
		&ez_sec_info->ez_loop_chk_timer, 
		ez_sec_info->ez_loop_chk_timer_running, 
		ez_loop_chk_timeout);
#endif

#ifdef EZ_NETWORK_MERGE_SUPPORT
#ifdef EZ_DUAL_BAND_SUPPORT
	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_start: wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x\nChannel: %d\n", 
		wdev->wdev_idx,wdev->wdev_type,wdev->func_idx,
		wdev->ez_security.this_band_info.shared_info.channel_info.channel));
#ifdef EZ_PUSH_BW_SUPPORT
	//if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: %d, CFG:%d OPER:%d\n", wdev->ez_security.this_band_info.shared_info.channel_info.ht_bw,
			wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: %d CFG:%d OPER:%d\n", wdev->ez_security.this_band_info.shared_info.channel_info.vht_bw,
			wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
	}
#else
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tHT-BW: CFG:%d OPER:%d\n",
			wlan_config_get_ht_bw(wdev),wlan_operate_get_ht_bw(wdev)));
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tVHT-BW: CFG:%d OPER:%d\n",
			wlan_config_get_vht_bw(wdev),wlan_operate_get_vht_bw(wdev)));
	}
#endif

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("\tEXTCHA: %d CFG:%d OPER:%d\n", wdev->ez_security.this_band_info.shared_info.channel_info.extcha,
		wlan_config_get_ext_cha(wdev),wlan_operate_get_ext_cha(wdev)));
#endif
#endif
	wdev->ez_security.ez_is_connection_allowed = FALSE;

	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("<------ %s()\n", __FUNCTION__));
}

void ez_stop(
	void *wdev_obj)
{
	int i;
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
	struct _ez_peer_security_info *ez_peer;
	
	wdev = (struct wifi_dev *)wdev_obj;

	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("------> %s(): wdev_type = 0x%x\n", __FUNCTION__, wdev->wdev_type));

#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)
	if ((wdev->enable_easy_setup) && (wf_fwd_set_easy_setup_mode != NULL)){
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("CLEAR EASY SETUP MODE IN FWD MODULE\n"));
		wf_fwd_set_easy_setup_mode(FALSE);
	}
#endif
	
	ez_sec_info = &wdev->ez_security;
	ez_sec_info->client_count = 0;
	ez_sec_info->capability = 0;
	ez_sec_info->keep_finding_provider = FALSE;
	EZ_RELEASE_TIMER(&ez_sec_info->ez_scan_timer,
		ez_sec_info->ez_scan_timer_running);
	EZ_RELEASE_TIMER(&ez_sec_info->ez_stop_scan_timer,
		ez_sec_info->ez_stop_scan_timer_running);
	EZ_RELEASE_TIMER(&ez_sec_info->ez_scan_pause_timer,
		ez_sec_info->ez_scan_pause_timer_running);
#ifdef EZ_NETWORK_MERGE_SUPPORT	
	EZ_RELEASE_TIMER(&ez_sec_info->ez_group_merge_timer,
		ez_sec_info->ez_group_merge_timer_running);
	NdisZeroMemory(ez_sec_info->merge_peer_addr, MAC_ADDR_LEN);
	EZ_CLEAR_CAP_ALLOW_MERGE(ez_sec_info->capability);
#ifdef EZ_DUAL_BAND_SUPPORT	
	ez_sec_info->this_band_info.interface_activated = FALSE;
	ez_sec_info->other_band_info_backup.interface_activated = FALSE;
#endif
#endif	

#ifdef NEW_CONNECTION_ALGO
	EZ_RELEASE_TIMER(&ez_sec_info->ez_connect_wait_timer,
		ez_sec_info->ez_connect_wait_timer_running);

#endif

#ifdef EZ_DUAL_BAND_SUPPORT
    EZ_RELEASE_TIMER(&ez_sec_info->ez_loop_chk_timer,
	    ez_sec_info->ez_loop_chk_timer_running);
#endif

	for (i = 0; i < EZ_MAX_STA_NUM; i++) {
		ez_peer = &wdev->ez_peer_table[i];
		if (ez_peer->gtk) {
			EZ_MEM_FREE(NULL, ez_peer->gtk);
			ez_peer->gtk = NULL;
			ez_peer->gtk_len = 0;
		}
	}
#ifdef APCLI_SUPPORT
	if (wdev->wdev_type == WDEV_TYPE_APCLI) {
		RTMP_ADAPTER *ad;
		APCLI_STRUCT *apcli_entry;
		ad = (RTMP_ADAPTER *)ez_sec_info->ad;
		apcli_entry = &ad->ApCfg.ApCliTab[wdev->func_idx];
		apcli_entry->avoid_loop = FALSE;
	}
#endif /* APCLI_SUPPORT */
#if 0
#ifdef DUAL_CHIP
        if(!IS_SINGLE_CHIP_DBDC(ez_sec_info->ad))
        {
		RTMP_ADAPTER *ad;
                ad = (RTMP_ADAPTER *)ez_sec_info->ad;
                NdisFreeSpinLock(&ad->ez_beacon_update_lock);
                NdisFreeSpinLock(&ad->ez_miniport_lock);
                NdisFreeSpinLock(&ad->ez_set_channel_lock);
                if(wdev->channel < 14){
                        NdisFreeSpinLock(&ez_conn_perm_lock);
                }
                }
#endif
#endif

	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("<------ %s()\n", __FUNCTION__));
}

void ez_init(
	void *ad_obj,
	void *wdev_obj,
	unsigned char ap_mode)
{
	int i;
	RTMP_ADAPTER *ad;
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;
	struct _ez_peer_security_info *ez_peer_info;

	ad = (RTMP_ADAPTER *)ad_obj;
	wdev = (struct wifi_dev *)wdev_obj;

	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s(): wdev_type = 0x%x.\n", __FUNCTION__, wdev->wdev_type));
#ifdef DUAL_CHIP
	{
		if(wdev->wdev_type == WDEV_TYPE_AP 
			&& (first_init < 2))
		{
			EZ_DEBUG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, (" === pAd = %p\n", ad));
			if(!first_init){
				pAd_2 = ad;
				ad->SingleChip = TRUE;
				first_init++;
				NdisAllocateSpinLock(ad, &ad->ez_beacon_update_lock);
	                        NdisAllocateSpinLock(ad, &ad->ez_miniport_lock);
        	                NdisAllocateSpinLock(ad, &ad->ez_set_channel_lock);
							NdisAllocateSpinLock(ad, &ad->ez_set_peer_lock);
				EZ_DEBUG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("=== pAd_2 = %p, pAd_5 = %p, ad->pAdOthBand = %p\n", ad,  pAd_5, ad->pAdOthBand));
				EZ_DEBUG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("=== pAd->SingleChip - %d\n", ad->SingleChip));
#ifdef EZ_PUSH_BW_SUPPORT
				ad->push_bw_config = FALSE; 	// default behavior to not push BW config to peers
#endif

			}
			else {
				if(ad == pAd_2){
					first_init++;
					ad->SingleChip = TRUE;
					NdisFreeSpinLock(&ad->ez_beacon_update_lock);
			                NdisFreeSpinLock(&ad->ez_miniport_lock);
			                NdisFreeSpinLock(&ad->ez_set_channel_lock);
							NdisFreeSpinLock(&ad->ez_set_peer_lock);
					EZ_DEBUG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("=== in single chip casepAd->SingleChip - %d\n", ad->SingleChip));
				}
				else
				{	
					pAd_5 = ad;
					ad->pAdOthBand = pAd_2;
					((PRTMP_ADAPTER)pAd_2)->pAdOthBand = pAd_5;
					ad->SingleChip = FALSE;
					first_init++;
					((PRTMP_ADAPTER)pAd_2)->SingleChip = FALSE;
					NdisAllocateSpinLock(ad, &ez_conn_perm_lock);
					NdisAllocateSpinLock(ad, &ez_handle_disconnect_lock);
					NdisAllocateSpinLock(ad, &ez_mlme_sync_lock);
					NdisAllocateSpinLock(ad, &ad->ez_beacon_update_lock);
                    NdisAllocateSpinLock(ad, &ad->ez_miniport_lock);
                    NdisAllocateSpinLock(ad, &ad->ez_set_channel_lock);
					NdisAllocateSpinLock(ad, &ad->ez_set_peer_lock);
										

					EZ_DEBUG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("=== pAd_5 = %p, pAd_2 = %p, ad->pAdOthBand = %p,\n", ad, pAd_2, ad->pAdOthBand));
					EZ_DEBUG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("=== pAd->SingleChip - %d, pAd_2->SingleChip-%d\n", ad->SingleChip,((PRTMP_ADAPTER)pAd_2)->SingleChip));
#ifdef EZ_PUSH_BW_SUPPORT
					ad->push_bw_config = FALSE; 	// default behavior to not push BW config to peers
#endif

				}
			}
		}
	}	
#endif
	
	ez_sec_info = &wdev->ez_security;

	NdisAllocateSpinLock(ad, &wdev->ez_peer_table_lock);
	ez_sec_info->ad = ad_obj;
	ez_sec_info->wdev = wdev_obj;
	for (i = 0; i < EZ_MAX_STA_NUM; i++) {
		ez_peer_info = &wdev->ez_peer_table[i];
		NdisZeroMemory(ez_peer_info, sizeof(struct _ez_peer_security_info));
		ez_peer_info->gtk = NULL;
		ez_peer_info->group_id = NULL;
	}
	if (ez_sec_info->configured_status == 0)
		ez_sec_info->configured_status = EZ_UNCONFIGURED;
	ez_sec_info->first_scan = TRUE;
	ez_sec_info->scan_one_channel = FALSE;
	if (ez_sec_info->rssi_threshold == 0)
		ez_sec_info->rssi_threshold = EZ_DEFAULT_RSSI_THRESHOLD;

	initList(&ez_sec_info->ez_apcli_list);
	NdisAllocateSpinLock(ad, &ez_sec_info->ez_apcli_list_sem_lock);

    NdisAllocateSpinLock(ad, &ez_sec_info->ez_scan_pause_timer_lock);
#ifdef DUAL_CHIP	
	//ez_sec_info->ez_is_connection_allowed = TRUE;
#endif	
#ifdef DBG
	ez_memory_alloc_num = 0;
	ez_memory_free_num = 0;
#endif /* DBG */

	ad->ez_roam_time = 60;					//sec
	ad->ez_delay_disconnect_count = 4;
	ad->ez_wait_for_info_transfer = 1;		//sec
	ad->ez_wdl_missing_time = 8;			//sec
	ad->ez_force_connect_bssid_time = 300;	//sec
	ad->ez_peer_entry_age_out_time = 4;		//sec
	ad->ez_scan_same_channel_time = 60;		//sec
	ad->ez_partial_scan_time = 300;			//sec
}

void ez_exit(
	void *wdev_obj)
{
	struct wifi_dev *wdev;
	struct _ez_security *ez_sec_info;

	wdev = (struct wifi_dev *)wdev_obj;
	ez_sec_info = &wdev->ez_security;
	if (ez_sec_info->group_id_len != 0) {
		EZ_MEM_FREE(NULL, ez_sec_info->group_id);
		ez_sec_info->group_id = NULL;
		ez_sec_info->group_id_len = 0;
	}
	NdisFreeSpinLock(&wdev->ez_peer_table_lock);
	ez_clear_apcli_list(&ez_sec_info->ez_apcli_list);
	NdisFreeSpinLock(&ez_sec_info->ez_apcli_list_sem_lock);
	NdisFreeSpinLock(&ez_sec_info->ez_scan_pause_timer_lock);
#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(ez_sec_info->ad))
	{
		RTMP_ADAPTER *ad;
		ad = (RTMP_ADAPTER *)ez_sec_info->ad;
		ad->SingleChip = TRUE;
		NdisFreeSpinLock(&ad->ez_beacon_update_lock);
		NdisFreeSpinLock(&ad->ez_miniport_lock);
		NdisFreeSpinLock(&ad->ez_set_channel_lock);
		NdisFreeSpinLock(&ad->ez_set_peer_lock);
		if(wdev->channel < 14){
			 NdisFreeSpinLock(&ez_conn_perm_lock);
			 NdisFreeSpinLock(&ez_handle_disconnect_lock);		
     		NdisFreeSpinLock(&ez_mlme_sync_lock);
		}
	}
#endif
}

void ez_read_parms_from_file(
	void *ad_obj,
	char *tmpbuf,
	char *buffer)
{
	int i;
	RTMP_STRING *macptr;
	RTMP_ADAPTER *ad;

	ad = (RTMP_ADAPTER *)ad_obj;
	if(RTMPGetKeyParameter("EzEnable", tmpbuf, 10, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			INT ez_enable = simple_strtol(macptr, 0, 10);

			if (i >= ad->ApCfg.BssidNum)
				break;

			if (ez_enable == 0)
			{
				ad->ApCfg.MBSSID[i].wdev.enable_easy_setup = FALSE;
			}
			else
			{
				ad->ApCfg.MBSSID[i].wdev.enable_easy_setup = TRUE;
			}

			EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("I/F(ra%d) EzEnable=%d\n", 
				i, ad->ApCfg.MBSSID[i].wdev.enable_easy_setup));
		}
	}
	if(RTMPGetKeyParameter("EzConfStatus", tmpbuf, 10, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			INT ConfStatus = simple_strtol(macptr, 0, 10);

			if (i >= ad->ApCfg.BssidNum)
				break;

			if (ConfStatus == 2)
			{
				ad->ApCfg.MBSSID[i].wdev.ez_security.configured_status = EZ_CONFIGURED;
				ad->ApCfg.MBSSID[i].wdev.ez_security.user_configured = TRUE;
			}
			else
			{
				ad->ApCfg.MBSSID[i].wdev.ez_security.configured_status = EZ_UNCONFIGURED;
			}

			EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("I/F(ra%d) EzConfStatus=%d\n", 
				i, ad->ApCfg.MBSSID[i].wdev.ez_security.configured_status));
		}
	}
	if(RTMPGetKeyParameter("EzGroupID", tmpbuf, 256, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			struct _ez_security *ez_sec_info;

			if (i >= ad->ApCfg.BssidNum)
				break;
			ez_sec_info = &ad->ApCfg.MBSSID[i].wdev.ez_security;
		
			ez_set_ezgroup_id(ez_sec_info, macptr, strlen(macptr), i);
			ez_set_group_id(ez_sec_info, macptr, strlen(macptr), i);
		}
	}
	if(RTMPGetKeyParameter("EzGenGroupID", tmpbuf, 256, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			struct _ez_security *ez_sec_info;

			if (i >= ad->ApCfg.BssidNum)
				break;

			ez_sec_info = &ad->ApCfg.MBSSID[i].wdev.ez_security;
			ez_set_gen_group_id(ez_sec_info, macptr, strlen(macptr), i);
		}
	}
	if(RTMPGetKeyParameter("EzOpenGroupID", tmpbuf, 256, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			struct _ez_security *ez_sec_info;

			if (i >= ad->ApCfg.BssidNum)
				break;
			ez_sec_info = &ad->ApCfg.MBSSID[i].wdev.ez_security;
			ez_set_open_group_id(ez_sec_info, macptr, strlen(macptr), i);
		}
	}
#ifdef EZ_API_SUPPORT
	if(RTMPGetKeyParameter("EzApiMode", tmpbuf, 256, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			set_EasySetup_Api_Mode(ad, macptr);
			break;
		}
	}
#endif
#ifdef EZ_PUSH_BW_SUPPORT
	if(RTMPGetKeyParameter("EzPushBW", tmpbuf, 10, buffer, TRUE))
	{
		INT ez_push_bw = 0;

		macptr = rstrtok(tmpbuf,";");
		if(macptr)
		ez_push_bw = simple_strtol(macptr, 0, 10);

		if (ez_push_bw == 0)
		{
			ad->push_bw_config = FALSE;
		}
		else
		{
			ad->push_bw_config = TRUE;
		}

		EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("EzPushBW=%d\n", 
			ad->push_bw_config));
	}
#endif
#ifdef APCLI_SUPPORT
	if(RTMPGetKeyParameter("ApCliEzEnable", tmpbuf, 10, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			INT ez_enable = simple_strtol(macptr, 0, 10);

			if (i >= MAX_APCLI_NUM)
				break;

			if (ez_enable == 0)
			{
				ad->ApCfg.ApCliTab[i].wdev.enable_easy_setup = FALSE;
			}
			else
			{
				ad->ApCfg.ApCliTab[i].wdev.enable_easy_setup = TRUE;
			}

			EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("I/F(apcli%d) ApCliEzEnable=%d\n", 
				i, ad->ApCfg.MBSSID[i].wdev.enable_easy_setup));
		}
	}
	if(RTMPGetKeyParameter("ApCliEzConfStatus", tmpbuf, 10, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			INT ConfStatus = simple_strtol(macptr, 0, 10);

			if (i >= MAX_APCLI_NUM)
				break;

			if (ConfStatus == 2)
			{
				ad->ApCfg.ApCliTab[i].wdev.ez_security.configured_status = EZ_CONFIGURED;
				ad->ApCfg.ApCliTab[i].wdev.ez_security.user_configured = TRUE;
			}
			else
			{
				ad->ApCfg.ApCliTab[i].wdev.ez_security.configured_status = EZ_UNCONFIGURED;
			}

			EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("I/F(apcli%d) ApCliEzConfStatus=%d\n", 
				i, ad->ApCfg.ApCliTab[i].wdev.ez_security.configured_status));
		}
	}
	if(RTMPGetKeyParameter("ApCliEzGroupID", tmpbuf, 256, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			struct _ez_security *ez_sec_info;

			if (i >= MAX_APCLI_NUM)
				break;

			ez_sec_info = &ad->ApCfg.ApCliTab[i].wdev.ez_security;
			ez_set_ezgroup_id(ez_sec_info, macptr, strlen(macptr), i);
			ez_set_group_id(ez_sec_info, macptr, strlen(macptr), i);
		}
	}
	if(RTMPGetKeyParameter("ApCliEzGenGroupID", tmpbuf, 256, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			struct _ez_security *ez_sec_info;
			
			if (i >= MAX_APCLI_NUM)
				break;

			ez_sec_info = &ad->ApCfg.ApCliTab[i].wdev.ez_security;

			ez_set_gen_group_id(ez_sec_info, macptr, strlen(macptr), i);
		}
	}
	
	if(RTMPGetKeyParameter("ApCliEzOpenGroupID", tmpbuf, 256, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			struct _ez_security *ez_sec_info;

			if (i >= MAX_APCLI_NUM)
				break;

			ez_sec_info = &ad->ApCfg.ApCliTab[i].wdev.ez_security;
			ez_set_open_group_id(ez_sec_info, macptr, strlen(macptr), i);
		}
	}
	if(RTMPGetKeyParameter("ApCliEzRssiThreshold", tmpbuf, 10, buffer, TRUE))
	{
		for (i = 0, macptr = rstrtok(tmpbuf,";"); macptr; macptr = rstrtok(NULL,";"), i++)
		{
			INT rssi_threshold = simple_strtol(macptr, 0, 10);

			if (i >= MAX_APCLI_NUM)
				break;

			ad->ApCfg.ApCliTab[i].wdev.ez_security.rssi_threshold = (CHAR)(-1)*rssi_threshold;

			EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("I/F(apcli%d) rssi_threshold=%d\n", 
				i, ad->ApCfg.ApCliTab[i].wdev.ez_security.rssi_threshold));
		}
	}
#endif /* APCLI_SUPPORT */
}

unsigned char ez_set_group_id(
	struct _ez_security *ez_sec_info,
	unsigned char *group_id,
	unsigned int group_id_len,
	unsigned char inf_idx)
{
	int i;
	if (ez_sec_info->group_id_len != 0) {
		EZ_MEM_FREE(NULL, ez_sec_info->group_id);
		ez_sec_info->group_id_len = 0;
	}
	ez_sec_info->group_id_len = group_id_len;
	EZ_MEM_ALLOC(NULL, &ez_sec_info->group_id, ez_sec_info->group_id_len);
	if (ez_sec_info->group_id) {
		os_zero_mem(ez_sec_info->group_id, ez_sec_info->group_id_len);
		NdisCopyMemory(ez_sec_info->group_id, group_id, ez_sec_info->group_id_len);
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("IF(ra%d) %s :: group id \n", 
			inf_idx, __FUNCTION__));
		for (i = 0; i < ez_sec_info->group_id_len; i++) {
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%02x ", ez_sec_info->group_id[i]));
		}
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("\n"));
		return TRUE;
	}
	else {
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("IF(ra%d) %s::Memory alloc fails\n\n", 
			inf_idx, __FUNCTION__));
		ez_sec_info->group_id_len = 0;
		return FALSE;
	}
}

unsigned char ez_set_ezgroup_id(
	struct _ez_security *ez_sec_info,
	unsigned char *ez_group_id,
	unsigned int ez_group_id_len,
	unsigned char inf_idx)
{
	int i;
	if (ez_sec_info->ez_group_id_len != 0) {
		EZ_MEM_FREE(NULL, ez_sec_info->ez_group_id);
		ez_sec_info->ez_group_id_len = 0;
	}
	ez_sec_info->ez_group_id_len = ez_group_id_len;
	EZ_MEM_ALLOC(NULL, &ez_sec_info->ez_group_id, ez_sec_info->ez_group_id_len);
	if (ez_sec_info->ez_group_id) {
		os_zero_mem(ez_sec_info->ez_group_id, ez_sec_info->ez_group_id_len);
		NdisCopyMemory(ez_sec_info->ez_group_id, ez_group_id, ez_sec_info->ez_group_id_len);
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("IF(ra%d) %s :: group id \n", 
			inf_idx, __FUNCTION__));
		for (i = 0; i < ez_sec_info->ez_group_id_len; i++) {
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%02x ", ez_sec_info->ez_group_id[i]));
		}
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("\n"));
		return TRUE;
	}
	else {
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("IF(ra%d) %s::Memory alloc fails\n\n", 
			inf_idx, __FUNCTION__));
		ez_sec_info->ez_group_id_len = 0;
		return FALSE;
	}
}

unsigned char ez_set_gen_group_id(
	struct _ez_security *ez_sec_info,
	unsigned char *gen_group_id,
	unsigned int gen_group_id_len,
	unsigned char inf_idx)
{
	int i;
	UCHAR hash_data[LEN_PMK];

	if (ez_sec_info->gen_group_id_len != 0) 
	{
		EZ_MEM_FREE(NULL, ez_sec_info->gen_group_id);
		ez_sec_info->gen_group_id_len = 0;
	}

	os_zero_mem(&hash_data[0], LEN_PMK);
	RT_SHA256(gen_group_id, gen_group_id_len, &hash_data[0]);
	ez_set_group_id(ez_sec_info, &hash_data[0], LEN_PMK, inf_idx);

	ez_sec_info->gen_group_id_len = gen_group_id_len;
	EZ_MEM_ALLOC(NULL, &ez_sec_info->gen_group_id, ez_sec_info->gen_group_id_len);

	if (ez_sec_info->gen_group_id)
	{
		os_zero_mem(ez_sec_info->gen_group_id, ez_sec_info->gen_group_id_len);
		NdisCopyMemory(ez_sec_info->gen_group_id, gen_group_id, ez_sec_info->gen_group_id_len);
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			("IF(ra%d) %s :: group id \n", 
			inf_idx, __FUNCTION__));
		for (i = 0; i < ez_sec_info->gen_group_id_len; i++) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			("%02x ", ez_sec_info->gen_group_id[i]));
		}
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			("\n"));
		return TRUE;
	}
	else 
	{
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("IF(ra%d) %s::Memory alloc fails\n\n", 
			inf_idx, __FUNCTION__));
		ez_sec_info->gen_group_id_len = 0;
		return FALSE;
	}
}



#ifdef NEW_CONNECTION_ALGO
unsigned char ez_set_open_group_id(
	struct _ez_security *ez_sec_info,
	unsigned char *open_group_id,
	unsigned int open_group_id_len,
	unsigned char inf_idx)
{
	int i;
	if (ez_sec_info->open_group_id_len != 0) {
		NdisZeroMemory(ez_sec_info->open_group_id,OPEN_GROUP_MAX_LEN);
		ez_sec_info->open_group_id_len = 0;
	}
	if(open_group_id_len > OPEN_GROUP_MAX_LEN)
		return FALSE;
	ez_sec_info->open_group_id_len = open_group_id_len;
	//EZ_MEM_ALLOC(NULL, &ez_sec_info->group_id, ez_sec_info->group_id_len);
		os_zero_mem(ez_sec_info->open_group_id, OPEN_GROUP_MAX_LEN);
		NdisCopyMemory(ez_sec_info->open_group_id, open_group_id, ez_sec_info->open_group_id_len);
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("IF(ra%d) %s :: open_group id \n", 
			inf_idx, __FUNCTION__));
		for (i = 0; i < ez_sec_info->open_group_id_len; i++) {
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("%02x ", ez_sec_info->open_group_id[i]));
		}
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("\n"));
		return TRUE;
}
#endif

#ifdef EZ_NETWORK_MERGE_SUPPORT

/*check whether peer node is child node of the own node*/
BOOLEAN ez_is_weight_same(
	PUCHAR own_weight, 
	PUCHAR peer_weight)
{
	
	//ez_hex_dump("PeerWeight", (PUCHAR)peer_weight, NETWORK_WEIGHT_LEN);

	if ((own_weight[0] == 0xF) && (peer_weight[0] == 0xF))
	{
	
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_INFO,("Both are User Configured \n"));
		return TRUE;
	}
	else if (NdisEqualMemory(own_weight, peer_weight, NETWORK_WEIGHT_LEN))
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Wt Same\n"));
		ez_hex_dump("PeerWeight", (PUCHAR)peer_weight, NETWORK_WEIGHT_LEN);
		return TRUE;
	}
	else
	{
		//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("FALSE\n"));
		return FALSE;
	}
}
void send_action_notify_roam(void *ad_obj, 
					struct wifi_dev *wdev, 
					struct _ez_peer_security_info *ez_peer
					)
{

	unsigned char *out_buf;
	NDIS_STATUS NStatus;
	FRAME_ACTION_HDR frame;
	unsigned long frame_len;
	unsigned long tmp_len;
	PRTMP_ADAPTER pAd = ad_obj;
	out_buf = NULL;
	frame_len = 0;
	tmp_len = 0;
	
	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("------> %s, Peer = %x:%x:%x:%x:%x:%x\n", __FUNCTION__, PRINT_MAC(ez_peer->mac_addr)));

	NStatus = MlmeAllocateMemory(pAd, &out_buf); /*Get an unused nonpaged memory */
	if (NStatus != NDIS_STATUS_SUCCESS) {
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			 ("%s(): allocate memory failed \n",
			 __FUNCTION__));
		return;
	}
	
	wdev->ez_security.ez_action_type = ACTION_TYPE_NOTIFY_ROAM;
	ActHeaderInit(pAd, &frame.Hdr, ez_peer->mac_addr, wdev->if_addr, wdev->bssid);
	frame.Category = CATEGORY_PUBLIC;
	frame.Action = ACTION_WIFI_DIRECT;	// Action == 0x09, for vendor specific Action
	
	MakeOutgoingFrame(out_buf, &frame_len,
				  sizeof(FRAME_ACTION_HDR), &frame,
				  END_OF_ARGS);

	/*	Insert OUI Information	*/

	NdisMoveMemory(&out_buf[frame_len], mtk_oui, MTK_OUI_LEN);
	frame_len += MTK_OUI_LEN;
	
	
	ez_insert_tlv(EZ_TAG_NOTIFY_ROAM, 
		NULL, 
		0, 
		out_buf + frame_len, 
		&tmp_len);
	frame_len += tmp_len;

	MiniportMMRequest(pAd, QID_AC_BE, out_buf, frame_len);
	
	wdev->ez_security.ez_action_type = ACTION_TYPE_NONE;
	os_msec_delay(100);
	EZ_MEM_FREE(NULL, out_buf);
}

void send_action_delay_disconnect(void *ad_obj, 
					struct wifi_dev *wdev, 
					struct _ez_peer_security_info *ez_peer,
					unsigned char delay_disconnect_count
					)
{

	unsigned char *out_buf;
	NDIS_STATUS NStatus;
	FRAME_ACTION_HDR frame;
	unsigned long frame_len;
	unsigned long tmp_len;
	PRTMP_ADAPTER pAd = ad_obj;
	out_buf = NULL;
	frame_len = 0;
	tmp_len = 0;
	
	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("------> %s\n", __FUNCTION__));

	EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("delay_disconnect_count = %d\n", pAd->ez_delay_disconnect_count));
	
	NStatus = MlmeAllocateMemory(pAd, &out_buf); /*Get an unused nonpaged memory */
	if (NStatus != NDIS_STATUS_SUCCESS) {
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			 ("%s(): allocate memory failed \n",
			 __FUNCTION__));
		return;
	}
	
	wdev->ez_security.ez_action_type = ACTION_TYPE_DELAY_DISCONNECT;
	ActHeaderInit(pAd, &frame.Hdr, ez_peer->mac_addr, wdev->if_addr, wdev->bssid);
	frame.Category = CATEGORY_PUBLIC;
	frame.Action = ACTION_WIFI_DIRECT;	// Action == 0x09, for vendor specific Action
	
	MakeOutgoingFrame(out_buf, &frame_len,
				  sizeof(FRAME_ACTION_HDR), &frame,
				  END_OF_ARGS);

	/*	Insert OUI Information	*/

	NdisMoveMemory(&out_buf[frame_len], mtk_oui, MTK_OUI_LEN);
	frame_len += MTK_OUI_LEN;
	
	
	ez_insert_tlv(EZ_TAG_DELAY_DISCONNECT_COUNT, 
		&delay_disconnect_count, 
		1, 
		out_buf + frame_len, 
		&tmp_len);
	frame_len += tmp_len;

	MiniportMMRequest(pAd, QID_AC_BE, out_buf, frame_len);
	
	wdev->ez_security.ez_action_type = ACTION_TYPE_NONE;
	os_msec_delay(100);
	EZ_MEM_FREE(NULL, out_buf);
}
void send_action_update_weight(void *ad_obj,
					unsigned char *mac_addr,
					struct wifi_dev *wdev, 
					unsigned char * network_weight)
{
	unsigned char *out_buf;
	NDIS_STATUS NStatus;
	FRAME_ACTION_HDR frame;
	unsigned long frame_len;
	unsigned long tmp_len;
	PRTMP_ADAPTER pAd = ad_obj;
	unsigned char network_weight_local[NETWORK_WEIGHT_LEN];

	
	NStatus = MlmeAllocateMemory(pAd, &out_buf); /*Get an unused nonpaged memory */
	if (NStatus != NDIS_STATUS_SUCCESS) {
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			 ("%s(): allocate memory failed \n",
			 __FUNCTION__));
		return;
	}
	
	ActHeaderInit(pAd, &frame.Hdr, mac_addr, wdev->if_addr, wdev->bssid);
	frame.Category = CATEGORY_PUBLIC;
	frame.Action = ACTION_WIFI_DIRECT;	// Action == 0x09, for vendor specific Action
	
	MakeOutgoingFrame(out_buf, &frame_len,
				  sizeof(FRAME_ACTION_HDR), &frame,
				  END_OF_ARGS);

	/*	Insert OUI Information	*/

	NdisMoveMemory(&out_buf[frame_len], mtk_oui, MTK_OUI_LEN);
	frame_len += MTK_OUI_LEN;
	NdisCopyMemory(network_weight_local,network_weight,NETWORK_WEIGHT_LEN);
	network_weight_local[0] |= BIT(7);
	ez_hex_dump("Update peer weight", network_weight_local, NETWORK_WEIGHT_LEN);
	ez_insert_tlv(EZ_TAG_NETWORK_WEIGHT, 
							(unsigned char *)network_weight_local, 
							NETWORK_WEIGHT_LEN, 
							out_buf + frame_len, 
							&tmp_len);
	
	//hex_dump("Update peer weight", &out_buf[frame_len], NETWORK_WEIGHT_LEN);
		

	frame_len += tmp_len;
	MiniportMMRequest(pAd, QID_AC_BE, out_buf, frame_len);

	EZ_MEM_FREE(NULL, out_buf);
	ez_update_connection_permission(pAd,wdev,EZ_DISALLOW_ALL);

			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
						 ("%s(): pAd->ez_wait_for_info_transfer : %d\n",
						 __FUNCTION__, pAd->ez_wait_for_info_transfer));

			ez_wait_for_connection_allow(&pAd->ApCfg.MBSSID[0].wdev, pAd->ez_wait_for_info_transfer * EZ_SEC_TO_MSEC);
			pAd->ApCfg.MBSSID[0].wdev.ez_security.weight_update_going_on = TRUE;
	//}
	//! TODO
	//! Add Node number as well
	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("<------ %s\n", __FUNCTION__));
}

BOOLEAN ez_send_action_update_config_for_this_band(void *ad_obj, void *wdev_obj, updated_configs_t *updated_configs, BOOLEAN group_id_diff, BOOLEAN band_switched, BOOLEAN deauth_non_ez_sta)
{
	int index =0;
	PRTMP_ADAPTER pAd = ad_obj;
	struct wifi_dev *wdev = wdev_obj;
	BOOLEAN action_sent = FALSE;

	for (index = 0; index < EZ_MAX_STA_NUM; index ++)
	{
		//! if ez_peer is in connected state send action frame
		if (wdev->ez_peer_table[index].port_secured && (!MAC_ADDR_EQUAL(wdev->ez_peer_table[index].mac_addr, updated_configs->mac_addr))){
			if (band_switched && wdev->ez_peer_table[index].this_band_info.shared_info.link_duplicate)
			{
				struct _ez_peer_security_info * ez_peer = ez_get_other_band_ez_peer(wdev_obj,&wdev->ez_peer_table[index]);
				if(ez_peer == NULL)
				{
					ASSERT(FALSE);
					return FALSE;
				}
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("duplicateLink: Update the node Number\n"));
				NdisCopyMemory(&wdev->ez_peer_table[index].device_info.ez_node_number,&ez_peer->device_info.ez_node_number,sizeof(EZ_NODE_NUMBER));
				hex_dump("ez_peerMAC",wdev->ez_peer_table[index].mac_addr,6);
				hex_dump("ez_node_number", (PUCHAR)&wdev->ez_peer_table[index].device_info.ez_node_number, sizeof(EZ_NODE_NUMBER));
				continue;
			}
			if (send_action_update_config(pAd, &wdev->ez_peer_table[index], wdev, updated_configs, TRUE, group_id_diff)== TRUE)
			action_sent = TRUE;
		}
	}

	if (updated_configs->context_linkdown == FALSE) {

		if(deauth_non_ez_sta){
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			//			("------> %s(): AP BASIC CONFIG CHANGED, BRDCST DEAUTH\n", __FUNCTION__));

			//! send out a broadcast de-auth
			ez_send_broadcast_deauth(pAd, wdev);
		}
		else{
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			//			("------> %s(): AVOID DEAUTH TO NON EZ STA\n", __FUNCTION__));
		}

	}
	return action_sent;
}

BOOLEAN send_action_update_config(void *ad_obj, 
					struct _ez_peer_security_info *ez_peer,
					struct wifi_dev *wdev, 
					updated_configs_t *updated_configs,
					BOOL same_band,
					BOOL group_id_update)
{

	unsigned char *out_buf;
	NDIS_STATUS NStatus;
	FRAME_ACTION_HDR frame;
	unsigned long frame_len;
	unsigned long tmp_len;
	unsigned char *entrypted_data;
	unsigned int entrypted_data_len;
	struct _ez_security *ez_sec_info;
	PRTMP_ADAPTER pAd = ad_obj;
	PMAC_TABLE_ENTRY pEntry = MacTableLookup(pAd,ez_peer->mac_addr);
	
	unsigned char update_group_id = group_id_update ? 1:0;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(pAd)){
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL){
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
	}
#endif
	hex_dump("Send Action to peer",ez_peer->mac_addr,MAC_ADDR_LEN);
	if (pEntry == NULL)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("pEntry not available, exit\n"));
		return FALSE;
	}

	ez_sec_info = &wdev->ez_security;
	out_buf = NULL;
	frame_len = 0;
	tmp_len = 0;
	
	
	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("------> %s\n", __FUNCTION__));

	if (ez_peer == NULL)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_peer empty\n"));
		return FALSE;
	}
	
	if (wdev == NULL)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("wdev empty\n"));
		return FALSE;
	}
	
	if (updated_configs == NULL)
	{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("updated_configs empty\n"));
		return FALSE;
	}
	NStatus = MlmeAllocateMemory(pAd, &out_buf); /*Get an unused nonpaged memory */
	if (NStatus != NDIS_STATUS_SUCCESS) {
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			 ("%s(): allocate memory failed \n",
			 __FUNCTION__));
		return FALSE;
	}
	
	ActHeaderInit(pAd, &frame.Hdr, ez_peer->mac_addr, wdev->if_addr, wdev->bssid);
	frame.Category = CATEGORY_PUBLIC;
	frame.Action = ACTION_WIFI_DIRECT;	// Action == 0x09, for vendor specific Action
	
	MakeOutgoingFrame(out_buf, &frame_len,
				  sizeof(FRAME_ACTION_HDR), &frame,
				  END_OF_ARGS);

	/*	Insert OUI Information	*/

	NdisMoveMemory(&out_buf[frame_len], mtk_oui, MTK_OUI_LEN);
	frame_len += MTK_OUI_LEN;
	
	
	ez_insert_tlv(EZ_TAG_GROUP_ID_UPDATE, 
		&update_group_id, 
		1, 
		out_buf + frame_len, 
		&tmp_len);
	frame_len += tmp_len;
	
	
	/*
		Insert Encrypted Group ID
	*/
	EZ_MEM_ALLOC(NULL, &entrypted_data, updated_configs->group_id_len + EZ_AES_KEY_ENCRYPTION_EXTEND);
	if (entrypted_data) {
		/* encrypt */
		AES_Key_Wrap((unsigned char *)updated_configs->group_id, updated_configs->group_id_len, 
					ez_peer->sw_key, LEN_PTK_KEK, 
					entrypted_data, &entrypted_data_len);
		
		ez_insert_tlv(EZ_TAG_GROUP_ID, 
			entrypted_data, 
			entrypted_data_len, 
			out_buf + frame_len, 
			&tmp_len);
		frame_len += tmp_len;
		
		EZ_MEM_FREE(NULL, entrypted_data);

	}
#ifdef NEW_CONNECTION_ALGO
			ez_insert_tlv(EZ_TAG_OPEN_GROUP_ID, 
							updated_configs->open_group_id, 
							updated_configs->open_group_id_len, 
							out_buf + frame_len, 
							&tmp_len);
						frame_len += tmp_len;
	
#endif

	
	EZ_MEM_ALLOC(NULL, &entrypted_data, PMK_LEN + EZ_AES_KEY_ENCRYPTION_EXTEND);
	if (entrypted_data) {
		/* encrypt */
		AES_Key_Wrap((unsigned char *)updated_configs->this_band_info.pmk, PMK_LEN, 
					ez_peer->sw_key, LEN_PTK_KEK, 
					entrypted_data, &entrypted_data_len);
		ez_insert_tlv(EZ_TAG_PMK, 
			entrypted_data, 
			entrypted_data_len, 
			out_buf + frame_len, 
			&tmp_len);
		frame_len += tmp_len;

		AES_Key_Wrap((unsigned char *)updated_configs->other_band_info.pmk, PMK_LEN, 
					ez_peer->sw_key, LEN_PTK_KEK, 
					entrypted_data, &entrypted_data_len);

		ez_insert_tlv(EZ_TAG_OTHER_BAND_PMK, 
			entrypted_data, 
			entrypted_data_len, 
			out_buf + frame_len, 
			&tmp_len);
		frame_len += tmp_len;
		
		EZ_MEM_FREE(NULL, entrypted_data);

	}


{
		interface_info_tag_t shared_info[2];
		interface_info_t other_band_info;
		NdisCopyMemory(&shared_info[0],&wdev->ez_security.this_band_info.shared_info,sizeof(interface_info_tag_t));
		if (ez_get_other_band_info(wdev->sys_handle, wdev, &other_band_info)){
			NdisCopyMemory(&shared_info[1],&other_band_info.shared_info,sizeof(interface_info_tag_t));
		} else {
			NdisZeroMemory(&shared_info[1],sizeof(interface_info_tag_t));
		}
		shared_info[1].ssid_len = updated_configs->other_band_info.shared_info.ssid_len;
		NdisCopyMemory(shared_info[1].ssid, updated_configs->other_band_info.shared_info.ssid, updated_configs->other_band_info.shared_info.ssid_len);
		NdisCopyMemory(&shared_info[1].channel_info, &updated_configs->other_band_info.shared_info.channel_info, sizeof(channel_info_t));
#ifdef DOT11R_FT_SUPPORT
		FT_SET_MDID(shared_info[1].FtMdId, updated_configs->other_band_info.shared_info.FtMdId);
#endif


#if 0
		NdisCopyMemory(&shared_info[0],&updated_configs->this_band_info.shared_info,sizeof(interface_info_tag_t));
		NdisCopyMemory(&shared_info[1],&updated_configs->other_band_info.shared_info,sizeof(interface_info_tag_t));			
#endif

		ez_insert_tlv(EZ_TAG_INTERFACE_INFO, 
			(unsigned char *)&shared_info[0], 
			sizeof(shared_info), 
			out_buf + frame_len, 
			&tmp_len);
		frame_len += tmp_len;

		ez_allocate_node_number_sta(pAd,wdev->func_idx,pEntry, TRUE);
		NdisCopyMemory(&updated_configs->device_info.ez_node_number,&ez_peer->device_info.ez_node_number,sizeof(EZ_NODE_NUMBER));

		ez_insert_tlv(EZ_TAG_DEVICE_INFO, 
			(unsigned char *)&updated_configs->device_info, 
			sizeof(device_info_t), 
			out_buf + frame_len, 
			&tmp_len);
		frame_len += tmp_len;
}


	MiniportMMRequest(pAd, QID_AC_BE, out_buf, frame_len);

	EZ_MEM_FREE(NULL, out_buf);
	
	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("%s(): pAd->ez_wait_for_info_transfer : %d\n",
				 __FUNCTION__, pAd->ez_wait_for_info_transfer));
		if(IS_SINGLE_CHIP_DBDC(pAd)) {
			ez_update_connection_permission(pAd, wdev, EZ_DISALLOW_ALL);
			ez_wait_for_connection_allow(&pAd->ApCfg.MBSSID[0].wdev, pAd->ez_wait_for_info_transfer * EZ_SEC_TO_MSEC);
		}
#ifdef DUAL_CHIP
		else
	{
				ez_update_connection_permission(pAd, wdev, EZ_DISALLOW_ALL);
				if (!ez_get_band(wdev)){			
					ez_wait_for_connection_allow(&pAd->ApCfg.MBSSID[0].wdev, pAd->ez_wait_for_info_transfer * EZ_SEC_TO_MSEC);
				} else {
					ez_wait_for_connection_allow(&adOthBand->ApCfg.MBSSID[0].wdev, adOthBand->ez_wait_for_info_transfer * EZ_SEC_TO_MSEC);	
				}
	}
#endif
			//ez_update_connection_permission(pAd,NULL,EZ_ALLOW_ALL);
		//	ez_update_connection_permission(ad,ap_wdev,EZ_ADD_ALLOW);

	//}
	
	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, 
			("<------ %s\n", __FUNCTION__));
	return TRUE;

}

#if 0
void ez_process_command_startup(PRTMP_ADAPTER pAd, 
	p_ez_startup_event_t p_ez_startup_event)
{
	struct _ez_security *ez_sec_info;
	POS_COOKIE pObj = (POS_COOKIE) pAd->OS_Cookie;
	UCHAR apidx = pObj->ioctl_if;
	ez_sec_info = &pAd->ApCfg.ApCliTab[apidx].wdev.ez_security;
	ez_sec_info->other_band_ssid_len = p_ez_startup_event->ssid_len;
	NdisCopyMemory(ez_sec_info->other_band_ssid,p_ez_startup_event->ssid,p_ez_startup_event->ssid_len);
	NdisCopyMemory(ez_sec_info->other_band_pmk, p_ez_startup_event->PMK, PMK_LEN);

	ez_sec_info = &pAd->ApCfg.MBSSID[apidx].wdev.ez_security;
	ez_sec_info->other_band_ssid_len = p_ez_startup_event->ssid_len;
	NdisCopyMemory(ez_sec_info->other_band_ssid,p_ez_startup_event->ssid,p_ez_startup_event->ssid_len);
	NdisCopyMemory(ez_sec_info->other_band_pmk, p_ez_startup_event->PMK, PMK_LEN);
}
void ez_process_command_update_config(PRTMP_ADAPTER pAd, 
	p_ez_group_id_event_t ez_group_id, char band_id, char intf_type)
{
	struct _ez_security *ez_sec_info;
	struct wifi_dev *wdev;
	struct _ez_peer_security_info *ez_peer;
	int index = 0;
	POS_COOKIE pObj = (POS_COOKIE) pAd->OS_Cookie;
	UCHAR apidx = pObj->ioctl_if;
	struct wifi_dev *ap_wdev;
	BSS_STRUCT *mbss;
	if (pObj->ioctl_if_type == INT_APCLI)
	{
		wdev = &pAd->ApCfg.ApCliTab[apidx].wdev;
		ez_sec_info = &wdev->ez_security;
		ez_sec_info->group_id_len = ez_group_id->group_id_len;
		NdisCopyMemory(ez_sec_info->group_id, ez_group_id->group_id, ez_sec_info->group_id_len);
		if (pAd->ApCfg.ApCliTab[apidx].Valid)
		{
			
			ez_peer = ez_peer_table_search_by_addr(wdev, wdev->bssid);
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Send Action frame to AP of this APCLI\n"));
			//send_action_update_config(pAd, ez_peer, wdev,  ez_group_id->group_id, ez_sec_info->group_id_len);
		}
	} else {
		wdev = &pAd->ApCfg.MBSSID[apidx].wdev;
		ez_sec_info = &wdev->ez_security;
		ez_sec_info->group_id_len = ez_group_id->group_id_len;
		NdisCopyMemory(ez_sec_info->group_id, ez_group_id->group_id, ez_sec_info->group_id_len);
		ez_hex_dump("update params command", (char *)ez_group_id, sizeof(ez_group_id_event_t) + ez_group_id->group_id_len);
		{
			

			ap_wdev = wdev;
			mbss = &pAd->ApCfg.MBSSID[apidx];
		
					/* Update PMK to ra interface. */
			ap_wdev->ez_security.configured_status = EZ_CONFIGURED;
			mbss->SsidLen = ez_group_id->ssid_len;
			os_zero_mem(mbss->Ssid, MAX_LEN_OF_SSID);
			NdisCopyMemory(mbss->Ssid, ez_group_id->ssid, mbss->SsidLen);
			NdisCopyMemory(&ap_wdev->SecConfig.PMK[0], ez_group_id->PMK, LEN_PMK);
			CLEAR_SEC_AKM(ap_wdev->SecConfig.AKMMap);
			SET_AKM_WPA2PSK(ap_wdev->SecConfig.AKMMap);
			SET_CIPHER_CCMP128(ap_wdev->SecConfig.PairwiseCipher);
			SET_CIPHER_CCMP128(ap_wdev->SecConfig.GroupCipher);
			EZ_SET_CAP_CONFIGRED(ap_wdev->ez_security.capability);
			EZ_SET_CAP_CONNECTED(ap_wdev->ez_security.capability);
			UpdateBeaconHandler(pAd, ap_wdev, BCN_UPDATE_IE_CHG);
		}
		for (index = 0; index < EZ_MAX_STA_NUM; index ++)
		{
			if (wdev->ez_peer_table[index].valid){
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Send Action frame to connected EZ peer\n"));
				send_action_update_config(pAd, &wdev->ez_peer_table[index], wdev, 
					mbss->Ssid, mbss->SsidLen);
				}
	
		}
	}
	    
}

int ez_MsgHandle(PRTMP_ADAPTER pAd, RTMP_IOCTL_INPUT_STRUCT *wrq)
{
	p_ez_command_t p_ez_command = NULL;
	int status = NDIS_STATUS_FAILURE;
	
	os_alloc_mem(NULL, (UCHAR **)&p_ez_command, wrq->u.data.length);
	if (p_ez_command == NULL)
	{
		MTWF_LOG(DBG_CAT_PROTO, CATPROTO_RRM, DBG_LVL_OFF, ("!!!(%s) : no memory!!!\n", __FUNCTION__));
		return NDIS_STATUS_FAILURE;
	}

	copy_from_user(p_ez_command, wrq->u.data.pointer, wrq->u.data.length);
	switch (p_ez_command->command_id)
		{
			
			case OID_802_11_EZ_CMD_STARTUP:
				ez_process_command_startup(pAd,(void *) &p_ez_command->command_body[0]);
				break;
			case OID_802_11_EZ_CMD_UPDATE_GROUP_ID:
				ez_process_command_update_config(pAd,(void *) &p_ez_command->command_body[0], p_ez_command->band_id, p_ez_command->intf_type);
				break;
		}
	return status;
}
#endif



BOOLEAN ez_ApCliAutoConnectBWAdjust(
	IN void	*ad_obj,
	IN struct wifi_dev	*wdev,
	IN void		*bss_entry_obj)
{
	RTMP_ADAPTER *pAd = ad_obj;
	BSS_ENTRY		*bss_entry = bss_entry_obj;
    BOOLEAN bAdjust = FALSE;
	BOOLEAN bAdjust_by_channel = FALSE;
	BOOLEAN bAdjust_by_ht = FALSE;
	BOOLEAN bAdjust_by_vht = FALSE;
    UCHAR 	orig_op_ht_bw;
	UCHAR 	orig_op_vht_bw;
	UCHAR	orig_ext_cha;
#ifdef DOT11_VHT_AC
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
#endif

	if (pAd == NULL || wdev == NULL || bss_entry == NULL) {
		EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_ERROR,
            	          ("(%s)  Error! entry is NULL.\n", __FUNCTION__));
		return FALSE;
	}

	EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE,
        	          ("BW info of root AP (%s):\n",bss_entry->Ssid));
	orig_op_ht_bw = wlan_config_get_ht_bw(wdev);
	orig_op_vht_bw = wlan_config_get_vht_bw(wdev);
	orig_ext_cha = wlan_config_get_ext_cha(wdev);

    if((wdev->channel != bss_entry->Channel)) {
		bAdjust = TRUE;
		bAdjust_by_channel = TRUE;
	}

#ifdef DOT11_N_SUPPORT
    if (WMODE_CAP_N(wdev->PhyMode) && (bss_entry->AddHtInfoLen != 0))
    {
        ADD_HTINFO *add_ht_info = &bss_entry->AddHtInfo.AddHtInfo;
		UCHAR op_ht_bw = wlan_config_get_ht_bw(wdev);
		UCHAR ext_cha = wlan_config_get_ext_cha(wdev);
        EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE,
            	          ("(%s)op_ht_bw = %d, ext_cha = %d, recommended = %d\n", __FUNCTION__, op_ht_bw, ext_cha, add_ht_info->RecomWidth));
        if(!bAdjust && 
           ((ext_cha != add_ht_info->ExtChanOffset) ||
			(op_ht_bw != add_ht_info->RecomWidth))) {
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Need to adjust bandwidth\n"));
			bAdjust = TRUE;
		}

        if (bAdjust)
        {
			switch (add_ht_info->RecomWidth) //peer side vht bw
			{
				case BW_20:
					if (op_ht_bw == BW_40) {
						EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Bring it down to 20\n"));
#ifdef EZ_PUSH_BW_SUPPORT
						if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
						{
							wlan_config_set_ht_bw(wdev,add_ht_info->RecomWidth);
						}
#endif
						bAdjust_by_ht = TRUE;
					}
					break;
				case BW_40:
					if (op_ht_bw == BW_20) {
							EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("bring it up to 40 ans set EXTXHA\n"));
#ifdef EZ_PUSH_BW_SUPPORT
							if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
							{
								wlan_config_set_ht_bw(wdev,add_ht_info->RecomWidth);
							}
#endif
							wlan_config_set_ext_cha(wdev,add_ht_info->ExtChanOffset);
							bAdjust_by_ht = TRUE;
					} else {
							EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("just set the EXTCHA\n"));
							wlan_config_set_ext_cha(wdev,add_ht_info->ExtChanOffset);
							bAdjust_by_ht = TRUE;
					}
					break;
			}
        }
    }
#endif /* DOT11_N_SUPPORT */


#ifdef DOT11_VHT_AC
	if (WMODE_CAP_AC(wdev->PhyMode) && IS_CAP_BW160(cap) &&
		(bss_entry->vht_cap_len != 0) && (bss_entry->vht_op_len != 0)) {

		VHT_OP_INFO *vht_op = &bss_entry->vht_op_ie.vht_op_info;
		UCHAR bw = VHT_BW_2040;
#ifdef DOT11_VHT_R2
        bw = check_vht_op_bw (vht_op);
#else
        bw = vht_op->ch_width;
        print_vht_op_info(vht_op);
#endif /* DOT11_VHT_R2 */

#ifdef EZ_PUSH_BW_SUPPORT
		if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
		{
			wlan_config_set_vht_bw(wdev, bw);
		}
#endif

    }
#endif /* DOT11_VHT_AC */
	bAdjust = FALSE;
	if (bAdjust_by_channel == TRUE)
		bAdjust = TRUE;
	if (bAdjust_by_ht == TRUE)
		bAdjust = TRUE;
	if (bAdjust_by_vht == TRUE)
		bAdjust = TRUE;
	if (bAdjust) {
		EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE,("%s:Adjust (%d %d %d)\n\r",__func__,
			bAdjust_by_channel,bAdjust_by_ht,bAdjust_by_vht));
		EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE,("%s:HT BW:%d to %d. MAX(%d)\n\r",__func__,
			orig_op_ht_bw,wlan_operate_get_ht_bw(wdev),wlan_config_get_ht_bw(wdev)));
		EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE,("%s:VHT BW:%d to %d. MAX(%d)\n\r",__func__,
				 orig_op_vht_bw,wlan_operate_get_vht_bw(wdev),wlan_config_get_vht_bw(wdev)));
		EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE,("%s:EXT CH:%d to %d. CFG(%d)\n\r",__func__,
				 orig_ext_cha,wlan_operate_get_ext_cha(wdev),wlan_config_get_ext_cha(wdev)));
	}
	
	SetCommonHtVht(pAd,wdev);
	return bAdjust;
}

#endif
/*
=====================================================================
Description:
	This function is used for 
	- handle internet status OID 
	- Update beacon accordingly
	
=====================================================================
*/


int ez_Internet_MsgHandle(void *ad_obj, RTMP_IOCTL_INPUT_STRUCT *wrq)
{
	RTMP_ADAPTER *pAd;
	int status;
	POS_COOKIE	pObj;
	int apidx;
	struct wifi_dev *wdev;
	p_internet_command_t p_internet_command;
	p_internet_command = NULL;
	status = NDIS_STATUS_SUCCESS;
	pAd = (RTMP_ADAPTER *)ad_obj;
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;
	wdev = &pAd->ApCfg.MBSSID[apidx].wdev;

	os_alloc_mem(NULL, (UCHAR **)&p_internet_command, wrq->u.data.length);

	if (p_internet_command == NULL)
	{
		EZ_DEBUG(DBG_CAT_PROTO, CATPROTO_RRM, DBG_LVL_ERROR, ("!!!(%s) : no memory!!!\n", __FUNCTION__));
		return NDIS_STATUS_FAILURE;
	}

	copy_from_user(p_internet_command, wrq->u.data.pointer, wrq->u.data.length);
	
	EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Net_status =%d,\n",
		p_internet_command->Net_status));

	if (wdev->enable_easy_setup && (wdev->wdev_type == WDEV_TYPE_AP))
	{
		wdev->ez_security.go_internet = (unsigned char)p_internet_command->Net_status;

		if(p_internet_command->Net_status == 1)
		{
			EZ_UPDATE_CAPABILITY_INFO(pAd, EZ_SET_ACTION, INTERNET, apidx);
		}
		else
		{
			EZ_UPDATE_CAPABILITY_INFO(pAd, EZ_CLEAR_ACTION, INTERNET, apidx);
		}				
		ez_inform_all_interfaces(wdev->sys_handle,wdev,ACTION_UPDATE_INTERNET_STATUS);

	}
	
	os_free_mem(p_internet_command);
	return status;
}
void ez_vendor_ie_parse(struct _vendor_ie_cap *vendor_ie, PEID_STRUCT info_elem)
{
	vendor_ie->support_easy_setup = TRUE;

	if (info_elem->Octet[EZ_TAG_OFFSET]
		== EZ_TAG_CAPABILITY_INFO) {
		NdisCopyMemory(&vendor_ie->ez_capability, 
				&info_elem->Octet[EZ_TAG_DATA_OFFSET], 
				EZ_CAPABILITY_LEN);
		vendor_ie->ez_capability = be2cpu32(vendor_ie->ez_capability);
	}
#if 0	
#ifdef NEW_CONNECTION_ALGO
	if (info_elem->Octet[EZ_TAG_OFFSET]
		== EZ_TAG_NODE_NUMBER) {
		NdisCopyMemory(&vendor_ie->ez_node_number, 
				&info_elem->Octet[EZ_TAG_DATA_OFFSET], 
				info_elem->Octet[EZ_TAG_LEN_OFFSET]);
	}
#endif
#ifdef NEW_CONNECTION_ALGO
	if (info_elem->Octet[EZ_TAG_OFFSET]
		== EZ_TAG_NETWORK_WEIGHT) {
		NdisCopyMemory(vendor_ie->ez_network_weight, 
				&info_elem->Octet[EZ_TAG_DATA_OFFSET], 
				info_elem->Octet[EZ_TAG_LEN_OFFSET]);
	}

	if (info_elem->Octet[EZ_TAG_OFFSET]
	== EZ_TAG_INTERFACE_INFO) {
		interface_info_tag_t *shared_info = (interface_info_tag_t *)&info_elem->Octet[EZ_TAG_DATA_OFFSET];
		NdisCopyMemory(&vendor_ie->this_band_info.shared_info,&shared_info[0], sizeof(interface_info_tag_t));
		NdisCopyMemory(&vendor_ie->other_band_info.shared_info,&shared_info[1], sizeof(interface_info_tag_t));
	}
#endif
#endif
	if (info_elem->Octet[EZ_TAG_OFFSET]
	== EZ_TAG_BEACON_INFO) {
		NdisCopyMemory(&vendor_ie->beacon_info,&info_elem->Octet[EZ_TAG_DATA_OFFSET], info_elem->Octet[EZ_TAG_LEN_OFFSET]);
	}

	if (info_elem->Octet[EZ_TAG_OFFSET]
		== EZ_TAG_OPEN_GROUP_ID) {
		NdisCopyMemory(vendor_ie->open_group_id, 
				&info_elem->Octet[EZ_TAG_DATA_OFFSET], 
				info_elem->Octet[EZ_TAG_LEN_OFFSET]);
		vendor_ie->open_group_id_len = info_elem->Octet[EZ_TAG_LEN_OFFSET];
	}

}
INT Show_EasySetupInfo_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	POS_COOKIE  pObj;
    UCHAR	    apidx;
	struct wifi_dev *wdev;
	BOOLEAN bFromApCli;
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;
	bFromApCli = FALSE;
#ifdef APCLI_SUPPORT
    if (pObj->ioctl_if_type == INT_APCLI)
    {
		bFromApCli = TRUE;
		wdev = &pAd->ApCfg.ApCliTab[apidx].wdev;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(apcli%d) %s:: This command is from apcli interface now.\n",
			apidx, __FUNCTION__));
    }
    else
#endif /* APCLI_SUPPORT */
	{
		wdev = &pAd->ApCfg.MBSSID[apidx].wdev;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(ra%d) %s:: This command is from ra interface now.\n",
			apidx, __FUNCTION__));
	}
	ez_show_information(wdev);
	return TRUE;
}



/*
    ==========================================================================
    Description:
        For Debug information
        Change DebugLevel
    Return:
        TRUE if all parameters are OK, FALSE otherwise
    ==========================================================================
*/
INT Set_EasySetup_Debug_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	ULONG dbg;

	dbg = simple_strtol(arg, 0, 10);
	if( dbg <= DBG_LVL_MAX)
		EzDebugLevel = dbg;

	MTWF_PRINT("%s(): (EzDebugLevel = %d)\n", __FUNCTION__, EzDebugLevel);

	return TRUE;
}

INT Set_EasySetup_Best_Ap_RSSI_Threshold(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	char *value;
	int i;
	for (i=0, value = rstrtok(arg,";"); value; value = rstrtok(NULL,";"), i++)
	{
		if (i == 0)
		{
			best_ap_rssi_threshld_max = simple_strtol(value, 0, 10);
		} else {
			best_ap_rssi_threshld[i - 1] = simple_strtol(value, 0, 10);
		}
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%d;", best_ap_rssi_threshld[i]));
	}
	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
	return TRUE;
}

INT Set_EasySetup_RoamTime_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{

	UINT8 roam_time;
	PRTMP_ADAPTER adOthBand = NULL;
	
	roam_time = simple_strtol(arg, 0, 10);

	pAd->ez_roam_time = roam_time;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): Roam Time = %d\n", 
										__FUNCTION__, pAd->ez_roam_time));

#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL)
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		else
		{
			adOthBand->ez_roam_time	= roam_time;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): adOthBand->ez_roam_time = %d\n", 
												__FUNCTION__, adOthBand->ez_roam_time));
		}
	}
#endif

	return TRUE;
}

INT Set_EasySetup_Delay_Disconnect_Count_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{

	unsigned char delay_disconnect_count;
	PRTMP_ADAPTER adOthBand = NULL;

	delay_disconnect_count = simple_strtol(arg, 0, 10);

	pAd->ez_delay_disconnect_count = delay_disconnect_count;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): Delay disconnect count = %d\n", 
		__FUNCTION__, pAd->ez_delay_disconnect_count));

#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL)
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		else
			{
			adOthBand->ez_delay_disconnect_count = delay_disconnect_count;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): adOthBand->ez_delay_disconnect_count %d\n", 
					__FUNCTION__, adOthBand->ez_delay_disconnect_count));
			}
	}
#endif

	return TRUE;
}

INT Set_EasySetup_Wait_For_Info_Transfer_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{

	UINT8 wait_for_info_transfer;
	PRTMP_ADAPTER adOthBand = NULL;

	wait_for_info_transfer = simple_strtol(arg, 0, 10);

	pAd->ez_wait_for_info_transfer = wait_for_info_transfer;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): wait_for_info_transfer = %d\n",
			__FUNCTION__, pAd->ez_wait_for_info_transfer));

#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL)
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		else
		{
			adOthBand->ez_wait_for_info_transfer = wait_for_info_transfer;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): adOthBand->ez_wait_for_info_transfer %d\n",
							__FUNCTION__, adOthBand->ez_wait_for_info_transfer));
		}
	}
#endif

	return TRUE;
}

INT Set_EasySetup_WDL_Missing_Time_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{

	UINT8 wdl_missing_time;
	PRTMP_ADAPTER adOthBand = NULL;

	wdl_missing_time = simple_strtol(arg, 0, 10);

	pAd->ez_wdl_missing_time = wdl_missing_time;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): ez_wdl_missing_time = %d\n", 
												__FUNCTION__, pAd->ez_wdl_missing_time));

#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL)
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		else
		{
			adOthBand->ez_wdl_missing_time = wdl_missing_time;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): pAd->adOthBand.ez_wdl_missing_time = %d\n", 
						__FUNCTION__, adOthBand->ez_wdl_missing_time));
		}
	}
#endif

	return TRUE;
}

INT Set_EasySetup_Force_Connect_Bssid_Time_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{

	UINT32 force_connect_bssid_time;
	PRTMP_ADAPTER adOthBand = NULL;

	force_connect_bssid_time = simple_strtol(arg, 0, 10);

	pAd->ez_force_connect_bssid_time = force_connect_bssid_time;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): ez_force_connect_bssid_time = %d\n", 
		__FUNCTION__, pAd->ez_force_connect_bssid_time));

#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL)
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		else
		{
			adOthBand->ez_force_connect_bssid_time = force_connect_bssid_time;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): adOthBand->ez_force_connect_bssid_time = %d\n", 
									__FUNCTION__, adOthBand->ez_force_connect_bssid_time));
		}
	}
#endif

	return TRUE;
}

INT Set_EasySetup_Peer_Entry_Age_Out_time_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{

	UINT8 peer_entry_age_out_time;
	PRTMP_ADAPTER adOthBand = NULL;

	peer_entry_age_out_time = simple_strtol(arg, 0, 10);

	pAd->ez_peer_entry_age_out_time = peer_entry_age_out_time;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): ez_peer_entry_age_out_time = %d\n", 
							__FUNCTION__, pAd->ez_peer_entry_age_out_time));
		
#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL)
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		else
		{
			adOthBand->ez_peer_entry_age_out_time = peer_entry_age_out_time;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): adOthBand->ez_peer_entry_age_out_time = %d\n", 
							__FUNCTION__, adOthBand->ez_peer_entry_age_out_time));

		}
	}
#endif

	return TRUE;
}

INT Set_EasySetup_Scan_Same_Channel_Time_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{

	UINT8 scan_same_channel_time;
	PRTMP_ADAPTER adOthBand = NULL;

	scan_same_channel_time = simple_strtol(arg, 0, 10);

	pAd->ez_scan_same_channel_time = scan_same_channel_time;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): ez_scan_same_channel_time = %d\n", 
									__FUNCTION__, pAd->ez_scan_same_channel_time));
		
#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL)
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		else
		{
			adOthBand->ez_scan_same_channel_time = scan_same_channel_time;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): adOthBand->ez_scan_same_channel_time = %d\n", 
								__FUNCTION__, adOthBand->ez_scan_same_channel_time));
		}
	}
#endif

	return TRUE;
}


INT Set_EasySetup_Partial_Scan_Time_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{

	UINT32 partial_scan_time;
	PRTMP_ADAPTER adOthBand = NULL;

	partial_scan_time = simple_strtol(arg, 0, 10);

	pAd->ez_partial_scan_time = partial_scan_time;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): pAd->ez_partial_scan_time = %d\n", 
		__FUNCTION__, pAd->ez_partial_scan_time));

#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL)
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		else
		{
			adOthBand->ez_partial_scan_time = partial_scan_time;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): adOthBand->ez_partial_scan_time = %d\n", 
									__FUNCTION__, adOthBand->ez_partial_scan_time));
		}
	}
#endif

	return TRUE;
}

INT Set_EasySetup_ConfStatus_Proc(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	POS_COOKIE  pObj;
    UCHAR	    apidx;
	struct _ez_security *ez_sec_info;
	UINT ConfStatus;
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;
	ConfStatus = simple_strtol(arg, 0, 10);
#ifdef APCLI_SUPPORT
    if (pObj->ioctl_if_type == INT_APCLI)
    {
		ez_sec_info = &pAd->ApCfg.ApCliTab[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(apcli%d) %s:: This command is from apcli interface now.\n",
			apidx, __FUNCTION__));
    }
    else
#endif /* APCLI_SUPPORT */
	{
		ez_sec_info = &pAd->ApCfg.MBSSID[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(ra%d) %s:: This command is from ra interface now.\n",
			apidx, __FUNCTION__));
	}
	if (ConfStatus == EZ_UNCONFIGURED ||
		ConfStatus == EZ_CONFIGURED) {
		ez_sec_info->configured_status = ConfStatus;
		if (ez_sec_info->configured_status == EZ_CONFIGURED)
		{
			ez_sec_info->user_configured = TRUE;
		}
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(ra%d) %s:: ez_sec_info->configured_status = %d.\n", 
			apidx, __FUNCTION__, ez_sec_info->configured_status));
		return TRUE;
	}
	else {
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
			("IF(ra%d) %s:: Incorrect setting(=%d)\n", 
			apidx, __FUNCTION__, ConfStatus));
		return FALSE;
	}
}
INT Set_EasySetup_GroupID_Proc(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	POS_COOKIE  pObj;
    UCHAR	    apidx;
	struct _ez_security *ez_sec_info;
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;
#ifdef APCLI_SUPPORT
    if (pObj->ioctl_if_type == INT_APCLI)
    {
		ez_sec_info = &pAd->ApCfg.ApCliTab[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(apcli%d) %s:: This command is from apcli interface now.\n", 
			apidx, __FUNCTION__));
    }
    else
#endif /* APCLI_SUPPORT */
	{
		ez_sec_info = &pAd->ApCfg.MBSSID[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(ra%d) %s:: This command is from ra interface now.\n",
			apidx, __FUNCTION__));
	}
	ez_set_ezgroup_id(ez_sec_info, arg, strlen(arg), apidx);
	return ez_set_group_id(ez_sec_info, arg, strlen(arg), apidx);
}
INT Set_EasySetup_Enable_Proc(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	POS_COOKIE  pObj;
    UCHAR	    apidx;
	struct wifi_dev *wdev;
	UINT Enable;
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;
	Enable = simple_strtol(arg, 0, 10);
#ifdef APCLI_SUPPORT
    if (pObj->ioctl_if_type == INT_APCLI)
    {
		wdev = &pAd->ApCfg.ApCliTab[apidx].wdev;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(apcli%d) Set_EasySetup_Enable_Proc:: This command is from apcli interface now.\n", apidx));
    }
    else
#endif /* APCLI_SUPPORT */
	{
		wdev = &pAd->ApCfg.MBSSID[apidx].wdev;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(ra%d) Set_EasySetup_Enable_Proc:: This command is from ra interface now.\n", apidx));
	}
	wdev->enable_easy_setup = (Enable==0) ? 0:1;
	if (wdev->enable_easy_setup) {
		if (wdev->wdev_type == WDEV_TYPE_AP)
			ez_start(wdev, TRUE);
		else
			ez_start(wdev, FALSE);
	}
	else {
		ez_stop(wdev);
	}
	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s:: - wdev->enable_easy_setup = %d.\n", 
				__FUNCTION__, wdev->enable_easy_setup));
	return TRUE;
}

INT Set_EasySetup_GenGroupID_Proc(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	POS_COOKIE  pObj;
    UCHAR	    apidx;
	struct _ez_security *ez_sec_info;
	
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;

#ifdef APCLI_SUPPORT
    if (pObj->ioctl_if_type == INT_APCLI)
    {
		ez_sec_info = &pAd->ApCfg.ApCliTab[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(apcli%d) %s:: This command is from apcli interface now.\n", 
			apidx, __FUNCTION__));
    }
    else
#endif /* APCLI_SUPPORT */
	{
		ez_sec_info = &pAd->ApCfg.MBSSID[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(ra%d) %s:: This command is from ra interface now.\n",
			apidx, __FUNCTION__));
	}

	return ez_set_gen_group_id(ez_sec_info, arg, strlen(arg), apidx);
}

INT Set_EasySetup_RssiThreshold_Proc(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	POS_COOKIE  pObj;
    UCHAR	    apidx;
	struct _ez_security *ez_sec_info;
	INT rssi_threshold;

	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;
	rssi_threshold = simple_strtol(arg, 0, 10);

#ifdef APCLI_SUPPORT
    if (pObj->ioctl_if_type == INT_APCLI)
    {
		ez_sec_info = &pAd->ApCfg.ApCliTab[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(apcli%d) %s:: This command is from apcli interface now.\n", 
			apidx, __FUNCTION__));
    }
    else
#endif /* APCLI_SUPPORT */
	{
		ez_sec_info = &pAd->ApCfg.MBSSID[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(ra%d) %s:: This command is from ra interface now.\n", 
			apidx, __FUNCTION__));
	}

	ez_sec_info->rssi_threshold = (CHAR)(-1)*rssi_threshold;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			("%s:: - wdev->rssi_threshold = %d.\n", 
				__FUNCTION__, ez_sec_info->rssi_threshold));

	return TRUE;
}

INT Set_EasySetup_MaxScanDelay(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	POS_COOKIE  pObj;
    UCHAR	    apidx;
	//struct _ez_security *ez_sec_info;
	UINT32 max_scan_delay;
	UCHAR i;

	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;
	max_scan_delay = simple_strtol(arg, 0, 10);

	for (i=0; i<WDEV_NUM_MAX; i++)
	{
		struct wifi_dev *wdev = pAd->wdev_list[i];
		if (wdev && wdev->wdev_type == WDEV_TYPE_APCLI)
		{
			wdev->ez_security.ez_max_scan_delay = max_scan_delay;
		}
	}
#ifdef DUAL_CHIP
	{
		PRTMP_ADAPTER adOthBand = NULL;
		if (!IS_SINGLE_CHIP_DBDC(pAd)){
			adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
			if(adOthBand == NULL) {
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
				ASSERT(FALSE);
			} else {
				for (i=0; i<WDEV_NUM_MAX; i++)
				{
					struct wifi_dev *wdev = adOthBand->wdev_list[i];
					if (wdev && wdev->wdev_type == WDEV_TYPE_APCLI)
					{
						wdev->ez_security.ez_max_scan_delay = max_scan_delay;
					}
				}
			}
		}
	}
#endif
	return TRUE;
}

#ifdef EZ_API_SUPPORT
INT set_EasySetup_Api_Mode(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	UCHAR ez_api_mode;
	UCHAR 		*macptr;
	int i;
	macptr = arg;
	
	if (0)
	{
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
					("%s:: POSSIBLE VALUES 0/1/2\n", __FUNCTION__));
		return FALSE;
	} else {
		AtoH(macptr, &ez_api_mode, 1);
		if (ez_api_mode > 2)
		{
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
						("%s:: POSSIBLE VALUES 0/1/2, ez_api_mode = %d\n", __FUNCTION__, ez_api_mode));
			return FALSE;
		}
	}
	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, 
				("%s:: POSSIBLE VALUES 0/1/2, ez_api_mode = %d\n", __FUNCTION__, ez_api_mode));

		for (i=0; i<WDEV_NUM_MAX; i++) {
			if (pAd->wdev_list[i]!=NULL && ez_is_ap_apcli(pAd->wdev_list[i]))
			{
				pAd->wdev_list[i]->ez_security.ez_api_mode = ez_api_mode;
			}
		}
		
	return TRUE;
}

#endif
#ifdef EZ_NETWORK_MERGE_SUPPORT
extern UCHAR BROADCAST_ADDR[];
INT set_EasySetup_MergeGroup_proc(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	POS_COOKIE  pObj;
    UCHAR	    apidx;
	UCHAR 		*macptr;
	int 		j;
	UCHAR 		macAddress[6];
	UCHAR 		broadcast_address_string[] = "FF:FF:FF:FF:FF:FF";
	struct _ez_security *ez_sec_info;
	
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;
	macptr = arg;
	if (strlen(macptr) == 0)
	{
		macptr = broadcast_address_string;
	}
	if(strlen(macptr) != 17)  /*Mac address acceptable format 01:02:03:04:05:06 length 17*/
	{
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			("Incorrect Peer Address Format %s, expected is XX:XX:XX:XX:XX:XX.\n", 
			macptr));
		return FALSE;
	}
	if(strcmp(macptr,"00:00:00:00:00:00") == 0)
	{
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			("Incorrect Peer Address Format %s, expected is XX:XX:XX:XX:XX:XX. All zeros not allowed\n", 
			macptr));
		return FALSE;
	}
	for (j=0; j<MAC_ADDR_LEN; j++)
	{
		AtoH(macptr, &macAddress[j], 1);
		if (macptr[2] != ':' && j < 5)
			{
				EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				("Incorrect Peer Address Format %s, expected is XX:XX:XX:XX:XX:XX.\n", 
					macptr));
				return FALSE;
			}
		macptr=macptr+3;
	}
	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%x:%x:%x:%x:%x:%x\n", macAddress[0],macAddress[1],macAddress[2], macAddress[3],macAddress[4],macAddress[5]));
#ifdef APCLI_SUPPORT
		if (pObj->ioctl_if_type == INT_APCLI)
		{
			if (pAd->ApCfg.ApCliTab[apidx].Enable == TRUE)
			{
				
				EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				("CLI Interface already enabled.\n"));
				return FALSE;
			}
			ez_sec_info = &pAd->ApCfg.ApCliTab[apidx].wdev.ez_security;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("IF(apcli%d) %s:: This command is from apcli interface now.\n", 
				apidx, __FUNCTION__));
#if 1
			if (ez_sec_info->ez_group_merge_timer_running)
			{
				EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				("Merge going on.\n"));
				return FALSE;
			}
			
#endif
			EZ_UPDATE_APCLI_CAPABILITY_INFO(pAd, EZ_SET_ACTION, ALLOW_MERGE, apidx);
			COPY_MAC_ADDR(ez_sec_info->merge_peer_addr, macAddress);
						
		}
		else
#endif /* APCLI_SUPPORT */
		{
			ez_sec_info = &pAd->ApCfg.MBSSID[apidx].wdev.ez_security;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				("IF(ra%d) %s:: This command is from ra interface now.\n", 
				apidx, __FUNCTION__));
#if 1
			if (ez_sec_info->ez_group_merge_timer_running)
			{
				EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
				("Merge going on.\n"));
				return FALSE;
			}
			EzStartGroupMergeTimer(ez_sec_info);
#endif
			EZ_UPDATE_CAPABILITY_INFO(pAd, EZ_SET_ACTION, ALLOW_MERGE, apidx);
			COPY_MAC_ADDR(ez_sec_info->merge_peer_addr, macAddress);
		}
		
		return TRUE;
}
#endif

#ifdef NEW_CONNECTION_ALGO



INT Set_EasySetup_Open_GenGroupID_Proc(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	//UCHAR hash_data[LEN_PMK];
	POS_COOKIE  pObj;
    UCHAR	    apidx;
	UINT32 data_len;
	struct _ez_security *ez_sec_info;
	
	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;

#ifdef APCLI_SUPPORT
    if (pObj->ioctl_if_type == INT_APCLI)
    {
		ez_sec_info = &pAd->ApCfg.ApCliTab[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(apcli%d) %s:: This command is from apcli interface now.\n", 
			apidx, __FUNCTION__));
    }
    else
#endif /* APCLI_SUPPORT */
	{
		ez_sec_info = &pAd->ApCfg.MBSSID[apidx].wdev.ez_security;
		EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("IF(ra%d) %s:: This command is from ra interface now.\n",
			apidx, __FUNCTION__));
	}

	data_len = strlen(arg);

//	os_zero_mem(&hash_data[0], LEN_PMK);
//	RT_SHA256(arg, data_len, &hash_data[0]);

	return ez_set_open_group_id(ez_sec_info, arg, data_len, apidx);
}

INT Set_EasySetup_ForceSsid_Proc(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	POS_COOKIE pObj;
	UCHAR ifIndex;
	INT success = FALSE;

	pObj = (POS_COOKIE) pAd->OS_Cookie;
	if (pObj->ioctl_if_type != INT_APCLI)
		return FALSE;

	ifIndex = pObj->ioctl_if;

	if(strlen(arg) <= MAX_LEN_OF_SSID)
	{
		ez_apcli_force_ssid(pAd,ifIndex,(PUCHAR)arg,strlen(arg));
	}
	else
		success = FALSE;

	return success;
}
INT Set_ez_connection_allow_all(
	IN  PRTMP_ADAPTER pAd,
	IN  RTMP_STRING *arg)
{
	int i;
	
	struct wifi_dev *wdev;
	struct wifi_dev *cli_wdev;
	PRTMP_ADAPTER pAdOtherBand;	
	if (IS_SINGLE_CHIP_DBDC(pAd))
	{
		if (pAd->ApCfg.BssidNum == 1 && pAd->CommonCfg.dbdc_mode == 0)
		{
			struct _ez_security *ez_sec_info, *cli_ez_sec_info;
			BSS_STRUCT *ap_mbss;
			CHAR Ssid5[]="MTAP5";
			CHAR Ssid2[]="MTAP2";
			wdev = &pAd->ApCfg.MBSSID[0].wdev;
			cli_wdev = &pAd->ApCfg.ApCliTab[0].wdev;
			ap_mbss = &pAd->ApCfg.MBSSID[wdev->func_idx];
			ez_sec_info = &wdev->ez_security;
			cli_ez_sec_info = &cli_wdev->ez_security;
			if(wdev->channel > 14)
			{
				ez_sec_info->other_band_info_backup.shared_info.ssid_len  = strlen(&Ssid2[0]);
				ez_sec_info->other_band_info_backup.shared_info.channel_info.channel = 1;
#ifdef EZ_PUSH_BW_SUPPORT
				if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
				{
					ez_sec_info->other_band_info_backup.shared_info.channel_info.ht_bw = 1;
					ez_sec_info->other_band_info_backup.shared_info.channel_info.vht_bw = 0;
				}
				else
				{
					ez_sec_info->other_band_info_backup.shared_info.channel_info.ht_bw = 0xFF;
					ez_sec_info->other_band_info_backup.shared_info.channel_info.vht_bw = 0xFF;
				}
#else
				ez_sec_info->other_band_info_backup.shared_info.channel_info.rsvd1 = 0xFF;
				ez_sec_info->other_band_info_backup.shared_info.channel_info.rsvd2 = 0xFF;
#endif
				ez_sec_info->other_band_info_backup.shared_info.channel_info.extcha = 0x1;
				NdisCopyMemory(ez_sec_info->other_band_info_backup.shared_info.ssid, Ssid2, strlen(&Ssid2[0]));

			}
			else
			{
				ez_sec_info->other_band_info_backup.shared_info.ssid_len  = strlen(&Ssid5[0]);
				ez_sec_info->other_band_info_backup.shared_info.channel_info.channel = 36;
#ifdef EZ_PUSH_BW_SUPPORT
				if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
				{
					ez_sec_info->other_band_info_backup.shared_info.channel_info.ht_bw = 1;
					ez_sec_info->other_band_info_backup.shared_info.channel_info.vht_bw = 1;
				}
				else
				{
					ez_sec_info->other_band_info_backup.shared_info.channel_info.ht_bw = 0xFF;
					ez_sec_info->other_band_info_backup.shared_info.channel_info.vht_bw = 0xFF;
				}
#else
				ez_sec_info->other_band_info_backup.shared_info.channel_info.rsvd1 = 0xFF;
				ez_sec_info->other_band_info_backup.shared_info.channel_info.rsvd2 = 0xFF;

#endif
				ez_sec_info->other_band_info_backup.shared_info.channel_info.extcha = 0x1;
				NdisCopyMemory(ez_sec_info->other_band_info_backup.shared_info.ssid, Ssid5, strlen(&Ssid5[0]));
			}

#ifdef DOT11R_FT_SUPPORT
			FT_SET_MDID(ez_sec_info->other_band_info_backup.shared_info.FtMdId, ap_mbss->wdev.FtCfg.FtMdId);
#endif
			ez_sec_info->other_band_info_backup.interface_activated = TRUE;		
			if(wdev->channel > 14)
			{
				cli_ez_sec_info->other_band_info_backup.shared_info.ssid_len  = strlen(&Ssid2[0]);
				cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.channel = 1;
#ifdef EZ_PUSH_BW_SUPPORT
				if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
				{
					cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.ht_bw = 1;
					cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.vht_bw = 0;
				}
				else
				{
					cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.ht_bw = 0xFF;
					cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.vht_bw = 0xFF;
				}
#else
				cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.rsvd1 = 0xFF;
				cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.rsvd2 = 0xFF;
#endif
				cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.extcha = 0x1;
				NdisCopyMemory(cli_ez_sec_info->other_band_info_backup.shared_info.ssid, Ssid2, strlen(&Ssid2[0]));
			}
			else
			{
				cli_ez_sec_info->other_band_info_backup.shared_info.ssid_len  = strlen(&Ssid5[0]);
				cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.channel = 36;
#ifdef EZ_PUSH_BW_SUPPORT
				if( ((PRTMP_ADAPTER)(wdev->sys_handle))->push_bw_config )
				{
					cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.ht_bw = 1;
					cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.vht_bw = 1;
				}
				else
				{
					cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.ht_bw = 0xFF;
					cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.vht_bw = 0xFF;
				}
#else
				cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.rsvd1 = 0xFF;
				cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.rsvd2 = 0xFF;
#endif
				cli_ez_sec_info->other_band_info_backup.shared_info.channel_info.extcha = 0x1;
				NdisCopyMemory(cli_ez_sec_info->other_band_info_backup.shared_info.ssid, Ssid5, strlen(&Ssid5[0]));
			}
#ifdef DOT11R_FT_SUPPORT
			FT_SET_MDID(cli_ez_sec_info->other_band_info_backup.shared_info.FtMdId, ap_mbss->wdev.FtCfg.FtMdId);
#endif
			cli_ez_sec_info->other_band_info_backup.interface_activated = TRUE;		
		}
	}

	for (i = 0; i < pAd->ApCfg.BssidNum; i++)
	{
		wdev = &pAd->ApCfg.MBSSID[i].wdev;
		cli_wdev = &pAd->ApCfg.ApCliTab[i].wdev;
		if (wdev->ez_security.configured_status == EZ_UNCONFIGURED)
		{
			continue;
		}
		SetWPAPSKKey(pAd, wdev->SecConfig.PSK, strlen(wdev->SecConfig.PSK), pAd->ApCfg.MBSSID[i].Ssid, pAd->ApCfg.MBSSID[i].SsidLen, pAd->ApCfg.MBSSID[i].PMK);
		NdisCopyMemory(wdev->SecConfig.PMK,pAd->ApCfg.MBSSID[i].PMK,PMK_LEN);
		NdisCopyMemory(cli_wdev->SecConfig.PMK,pAd->ApCfg.MBSSID[i].PMK,PMK_LEN);
		NdisCopyMemory(wdev->ez_security.this_band_info.pmk,pAd->ApCfg.MBSSID[i].PMK,PMK_LEN);
		NdisCopyMemory(cli_wdev->ez_security.this_band_info.pmk, pAd->ApCfg.MBSSID[i].PMK,PMK_LEN);
	}
	if (IS_DUAL_CHIP_DBDC(pAd))
	{
		pAdOtherBand = pAd->pAdOthBand;
			
		for (i = 0; i < pAdOtherBand->ApCfg.BssidNum; i++)
		{
			wdev = &pAdOtherBand->ApCfg.MBSSID[i].wdev;
			cli_wdev = &pAdOtherBand->ApCfg.ApCliTab[i].wdev;
			if (wdev->ez_security.configured_status == EZ_UNCONFIGURED)
			{
				continue;
			}
			SetWPAPSKKey(pAdOtherBand, wdev->SecConfig.PSK, strlen(wdev->SecConfig.PSK), pAdOtherBand->ApCfg.MBSSID[i].Ssid, pAdOtherBand->ApCfg.MBSSID[i].SsidLen, pAdOtherBand->ApCfg.MBSSID[i].PMK);
			NdisCopyMemory(wdev->SecConfig.PMK, pAdOtherBand->ApCfg.MBSSID[i].PMK,PMK_LEN);
			NdisCopyMemory(cli_wdev->SecConfig.PMK,pAdOtherBand->ApCfg.MBSSID[i].PMK,PMK_LEN);
			NdisCopyMemory(wdev->ez_security.this_band_info.pmk,pAdOtherBand->ApCfg.MBSSID[i].PMK,PMK_LEN);
			NdisCopyMemory(cli_wdev->ez_security.this_band_info.pmk,pAdOtherBand->ApCfg.MBSSID[i].PMK,PMK_LEN);
		}
	}
	ez_update_connection_permission(pAd,&pAd->ApCfg.MBSSID[0].wdev, EZ_ALLOW_ALL_TIMEOUT);
	return TRUE;
}

INT Set_EasySetup_ForceBssid_Proc(
	IN  PRTMP_ADAPTER pAd,
	IN  RTMP_STRING *arg)
{
	INT i;
	RTMP_STRING *value;
	UCHAR ifIndex;
	POS_COOKIE pObj;

	pObj = (POS_COOKIE) pAd->OS_Cookie;
	if (pObj->ioctl_if_type != INT_APCLI)
		return FALSE;

	ifIndex = pObj->ioctl_if;

	if(strlen(arg) == 17)  /* Mac address acceptable format 01:02:03:04:05:06 length 17 */
	{
		for (i=0, value = rstrtok(arg,":"); value; value = rstrtok(NULL,":"), i++)
		{
			if((strlen(value) != 2) || (!isxdigit(*value)) || (!isxdigit(*(value+1))) )
				return FALSE;  /* Invalid */

			AtoH(value, &pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_apcli_force_bssid[i], 1);
		}

		if(i != 6)
			return FALSE;  /* Invalid */
	}

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Set_EasySetup_ForceBssid_Proc (%2X:%2X:%2X:%2X:%2X:%2X)\n",
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_apcli_force_bssid[0],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_apcli_force_bssid[1],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_apcli_force_bssid[2],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_apcli_force_bssid[3],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_apcli_force_bssid[4],
		pAd->ApCfg.ApCliTab[ifIndex].wdev.ez_security.ez_apcli_force_bssid[5]));

	return TRUE;
}
INT Set_EasySetup_ForceChannel_Proc(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	POS_COOKIE	pObj;
	UCHAR		apidx;
	INT channel;

	pObj = (POS_COOKIE) pAd->OS_Cookie;
	apidx = pObj->ioctl_if;
	channel = simple_strtol(arg, 0, 10);

	if (pObj->ioctl_if_type == INT_APCLI)
	{
	
		ez_apcli_force_channel(pAd,apidx,channel);
	}
	else
		return FALSE;


	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, 
			("%s:: - force channel = %d.\n", 
				__FUNCTION__, pAd->ApCfg.ApCliTab[apidx].wdev.ez_security.ez_apcli_force_channel));

	return TRUE;
}
#endif

#ifdef EZ_PUSH_BW_SUPPORT
INT Set_EasySetup_BWPushConfig(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{

	UINT8 same_bw_push;
	PRTMP_ADAPTER adOthBand = NULL;
	
	same_bw_push = simple_strtol(arg, 0, 10);

	pAd->push_bw_config = same_bw_push;

	EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): Push BW = %d\n", 
										__FUNCTION__, pAd->push_bw_config));

#ifdef DUAL_CHIP
	if(!IS_SINGLE_CHIP_DBDC(pAd))
	{
		adOthBand = (PRTMP_ADAPTER)pAd->pAdOthBand;
		if(adOthBand == NULL)
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		else
		{
			adOthBand->push_bw_config	= same_bw_push;
			EZ_DEBUG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s(): adOthBand-> Push BW = %d\n", 
												__FUNCTION__, adOthBand->push_bw_config));
		}
	}
#endif

	return TRUE;
}
#endif

VOID RTMPIoctlGetEzScanTable(
	IN	PRTMP_ADAPTER	pAdapter,
	IN	RTMP_IOCTL_INPUT_STRUCT	*wrq)
{
	RTMP_STRING *msg;
	INT 		i=0;
	INT			WaitCnt;
	INT 		Status=0;
        INT         max_len = LINE_LEN;
	RTMP_STRING *this_char;
	UINT32		bss_start_idx;
	BSS_ENTRY *pBss;
	UINT32 TotalLen, BufLen = IW_SCAN_MAX_DATA;

	this_char = wrq->u.data.pointer;
	MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
		("%s(): Before check, this_char = %s\n" ,
		__FUNCTION__, this_char));
	if (ascii2int(this_char, &bss_start_idx) == FALSE)
		bss_start_idx = 0;

	MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
		("%s(): After check, this_char = %s, out = %d\n" ,
		__FUNCTION__, this_char, bss_start_idx));

	TotalLen = sizeof(CHAR)*((MAX_LEN_OF_BSS_TABLE)*max_len) + 100;

		BufLen = IW_SCAN_MAX_DATA;

	os_alloc_mem(NULL, (PUCHAR *)&msg, TotalLen);

	if (msg == NULL)
	{
		MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s(): msg memory alloc fail.\n", 
			__FUNCTION__));
		return;
	}

	memset(msg, 0 , TotalLen);
	if (pAdapter->ScanTab.BssNr ==0) {
		sprintf(msg,"No BssInfo\n");
		wrq->u.data.length = strlen(msg);
		Status = copy_to_user(wrq->u.data.pointer, msg, wrq->u.data.length);
		MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s(): wrq->u.data.length = %d\n", 
			__FUNCTION__, wrq->u.data.length));
		os_free_mem((PUCHAR)msg);
		return;
	}
	if (bss_start_idx > (pAdapter->ScanTab.BssNr-1)) {
		sprintf(msg,"BssInfo Idx(%d) is out of range(0~%d)\n", 
				bss_start_idx, (pAdapter->ScanTab.BssNr-1));
		wrq->u.data.length = strlen(msg);
		Status = copy_to_user(wrq->u.data.pointer, msg, wrq->u.data.length);
		MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("%s(): wrq->u.data.length = %d\n", __FUNCTION__, wrq->u.data.length));
		os_free_mem((PUCHAR)msg);
		return;
	}
	sprintf(msg,"%s","\n");
#if 0
	sprintf(msg+strlen(msg),"Total=%-4d",pAdapter->ScanTab.BssNr);
#endif
	sprintf(msg+strlen(msg),"%s","\n");
	sprintf(msg+strlen(msg),"%-12s%-4s%-33s%-20s%-23s%-9s%-7s%-7s%-3s\n",
	    " Capability", "Ch", "SSID", "BSSID", "Security", "Siganl(%)", "W-Mode", " ExtCH"," NT");

	WaitCnt = 0;

	while ((ScanRunning(pAdapter) == TRUE) && (WaitCnt++ < 200))
		OS_WAIT(500);

	for(i=bss_start_idx; i<pAdapter->ScanTab.BssNr ;i++)
	{
		pBss = &pAdapter->ScanTab.BssEntry[i];

		if (pBss->support_easy_setup) {			
			if( pBss->Channel==0)
				break;

			if((strlen(msg)+100 ) >= BufLen)
				break;
			
			/*
				EZ Capability
			*/
			sprintf(msg+strlen(msg)," 0x%-9x", pBss->easy_setup_capability);
			
			RTMPCommSiteSurveyData(msg, pBss, TotalLen);
		}

	}
	wrq->u.data.length = strlen(msg);
	Status = copy_to_user(wrq->u.data.pointer, msg, wrq->u.data.length);

	MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
		("%s(): wrq->u.data.length = %d\n", __FUNCTION__, wrq->u.data.length));
	os_free_mem((PUCHAR)msg);
}
void ez_hex_dump(char *str, unsigned char *pSrcBufVA, unsigned int SrcBufLen)
{
#ifdef DBG
		unsigned char *pt;
		int x;
		if (EzDebugLevel < DBG_LVL_TRACE)
			return;
		pt = pSrcBufVA;
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%s: %p, len = %d\n", str, pSrcBufVA, SrcBufLen));
		for (x = 0; x < SrcBufLen; x++) {
			if (x % 16 == 0)
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("0x%04x : ", x));
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("%02x ", ((unsigned char)pt[x])));
			if (x % 16 == 15)
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
		}
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("\n"));
#endif /* DBG */
}

#ifdef EZ_DUAL_BAND_SUPPORT

#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)
static BOOLEAN is_other_band_rcvd_pkt(struct wifi_dev *wdev,struct sk_buff *pSkb)
{
	unsigned int recv_from = 0, band_from = 0;

	band_from = RTMP_GET_PACKET_BAND(pSkb); 
	recv_from = RTMP_GET_PACKET_RECV_FROM(pSkb);

	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("BandFrom:0x%x, RecvdFrom: 0x%x\n",band_from,recv_from));

	if (wdev->channel >= H_CHANNEL_BIGGER_THAN)
	{
		if( (recv_from == RTMP_PACKET_RECV_FROM_5G_AP) ||
			(recv_from == RTMP_PACKET_RECV_FROM_2G_AP) ||
			(recv_from == RTMP_PACKET_RECV_FROM_5G_CLIENT) ||
			(recv_from == RTMP_PACKET_RECV_FROM_2G_CLIENT)
		  )
		{
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Other band rcvd packet\n"));
			return TRUE;
		}

	}
	else if (wdev->channel > 14)
	{
		if( (recv_from == RTMP_PACKET_RECV_FROM_5G_H_AP) ||
			(recv_from == RTMP_PACKET_RECV_FROM_2G_AP) ||
			(recv_from == RTMP_PACKET_RECV_FROM_5G_H_CLIENT) ||
			(recv_from == RTMP_PACKET_RECV_FROM_2G_CLIENT)
		  )
		{
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Other band rcvd packet\n"));
			return TRUE;
		}

	}
	else
	{
		if( (recv_from == RTMP_PACKET_RECV_FROM_5G_AP) ||
			(recv_from == RTMP_PACKET_RECV_FROM_5G_H_AP) ||
			(recv_from == RTMP_PACKET_RECV_FROM_5G_CLIENT) ||
			(recv_from == RTMP_PACKET_RECV_FROM_5G_H_CLIENT)
		  )
		{
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Other band rcvd packet\n"));
			return TRUE;
		}
	}

	return FALSE;
}

static BOOLEAN is_other_band_cli_rcvd_pkt(struct wifi_dev *wdev,struct sk_buff *pSkb)
{
	unsigned int recv_from = 0, band_from = 0;

	band_from = RTMP_GET_PACKET_BAND(pSkb); 
	recv_from = RTMP_GET_PACKET_RECV_FROM(pSkb);

	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("BandFrom:0x%x, RecvdFrom: 0x%x\n",band_from,recv_from));

	if (wdev->channel >= H_CHANNEL_BIGGER_THAN)
	{
		if( (recv_from == RTMP_PACKET_RECV_FROM_5G_CLIENT) ||
			(recv_from == RTMP_PACKET_RECV_FROM_2G_CLIENT)
		  )
		{
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ApCliChannel(%d) : Other band CLI rcvd packet\n",wdev->channel));
			return TRUE;
		}

	}
	else if (wdev->channel > 14)
	{
		if( (recv_from == RTMP_PACKET_RECV_FROM_5G_H_CLIENT) ||
			(recv_from == RTMP_PACKET_RECV_FROM_2G_CLIENT)
		  )
		{
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ApCliChannel(%d) : Other band CLI rcvd packet\n",wdev->channel));
			return TRUE;
		}

	}
	else
	{
		if( (recv_from == RTMP_PACKET_RECV_FROM_5G_CLIENT) ||
			(recv_from == RTMP_PACKET_RECV_FROM_5G_H_CLIENT)
		  )
		{
			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ApCliChannel(%d) : Other band CLI rcvd packet\n",wdev->channel));
			return TRUE;
		}
	}

	return FALSE;
}

#endif /*CONFIG_WIFI_PKT_FWD */

/*
Determines whether Tx group packet is to be dropped by apcli interface

If both apcli interfaces connected to same root ap, then each apcli will
drop packets recvd on other band ap/apcli & allow any other packet.

*/
BOOLEAN ez_apcli_tx_grp_pkt_drop(struct wifi_dev *wdev,struct sk_buff *pSkb)
{
	struct _ez_security *ez_sec_info = &wdev->ez_security;
#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)
	unsigned int recv_from = 0, band_from = 0;
#endif

#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)
	if( (ez_sec_info->this_band_info.non_easy_connection == TRUE) &&
		RTMP_IS_PACKET_APCLI(pSkb)
	  )
	{
		if( (ez_sec_info->loop_chk_info.loop_chk_role == SOURCE) || 
		    (ez_sec_info->loop_chk_info.loop_chk_role == DEST) ){

			if(is_other_band_cli_rcvd_pkt(wdev,pSkb) == TRUE){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_apcli_tx_group_packet_drop: DROP other band CLI rcvd grp packet from non-easy AP!!!\n"));
				return TRUE;
			}
		}
		//else{
		//	EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ERROR: Allow Grp packet as Loop check not yet triggered\n"));
		//}
	}
#endif

	if(!ez_sec_info->this_band_info.shared_info.link_duplicate){
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_apcli_tx_group_packet_drop: Both ApCli not connected to same device \n"));
		return FALSE;
	}

#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)
	band_from = RTMP_GET_PACKET_BAND(pSkb); 
	recv_from = RTMP_GET_PACKET_RECV_FROM(pSkb);

	if( (band_from==0) && (recv_from==0) && 
		( (wdev->channel >= H_CHANNEL_BIGGER_THAN) || (wdev->channel > 14) )){ // just chan 14 check should be enough but kept as in other places
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_apcli_tx_group_packet_drop: DROP untagged grp packet on non2g duplicate link !!!\n"));
		return TRUE;
	}

	if(is_other_band_rcvd_pkt(wdev,pSkb) == TRUE){
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_apcli_tx_group_packet_drop: DROP other band rcvd grp packet !!!\n"));
		return TRUE;
	}
#endif

	return FALSE;
}

/*
Determines whether Tx group packet is to be dropped by Ap interface
for duplicate CLI links ONLY
*/
BOOLEAN ez_ap_tx_grp_pkt_drop_to_ez_apcli(struct wifi_dev *wdev,struct sk_buff *pSkb)
{
#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)
	unsigned int recv_from = 0, band_from = 0;

	band_from = RTMP_GET_PACKET_BAND(pSkb); 
	recv_from = RTMP_GET_PACKET_RECV_FROM(pSkb);

	if( (band_from==0) && (recv_from==0) && 
		( (wdev->channel >= H_CHANNEL_BIGGER_THAN) || (wdev->channel > 14) )){ // just chan 14 check should be enough but kept as in other places
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_ap_tx_grp_pkt_drop_to_ez_apcli: Untagged grp packet on non2g link !!!\n"));
		return TRUE;
	}

	if(is_other_band_rcvd_pkt(wdev,pSkb) == TRUE){
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_ap_tx_grp_pkt_drop_to_ez_apcli: other band rcvd grp packet !!!\n"));
		return TRUE;
	}

	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_ap_tx_grp_pkt_drop_to_ez_apcli : not other band rcvd pkt\n"));
#endif

	return FALSE;
}

void ez_apcli_uni_tx_on_dup_link(struct wifi_dev *wdev,struct sk_buff *pSkb)
{
	struct _ez_security *ez_sec_info = &wdev->ez_security;
#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)
	unsigned int recv_from = 0, band_from = 0;
#endif

	if(!ez_sec_info->this_band_info.shared_info.link_duplicate){
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_apcli_tx_group_packet_drop: Both ApCli not connected to same device \n"));
		return;
	}

#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)
	band_from = RTMP_GET_PACKET_BAND(pSkb); 
	recv_from = RTMP_GET_PACKET_RECV_FROM(pSkb);

	if( (band_from==0) && (recv_from==0) && 
		( (wdev->channel >= H_CHANNEL_BIGGER_THAN) || (wdev->channel > 14) )){ // just chan 14 check should be enough but kept as in other places
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_apcli_uni_tx_on_dup_link: UNICAST PKT ON NON2G DUP LINK !!!\n"));
	}

#endif

}


/* Set/Clear Loop chk context on other band CLI */
void ez_set_other_band_cli_loop_chk_info(void * ad_obj, void * wdev_obj, BOOLEAN test_start)
{	
	struct wifi_dev* wdev = wdev_obj;
	PRTMP_ADAPTER ad = (PRTMP_ADAPTER)ad_obj;
	struct _ez_security *ez_sec_info = NULL;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		 adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
	if(adOthBand == NULL) {
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
		ASSERT(FALSE);
		}
	}
#endif

	if (IS_SINGLE_CHIP_DBDC(ad_obj))
	    ez_sec_info = &ad->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev.ez_security;
#ifdef DUAL_CHIP
	else
		ez_sec_info = &adOthBand->ApCfg.ApCliTab[0].wdev.ez_security;
#endif
		if(test_start){ // can only be done by source
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_set_other_band_cli_loop_chk_info: Set Dest role for other CLI\n"));
		    ez_sec_info->loop_chk_info.loop_chk_role = DEST;
			ez_sec_info->first_loop_check = FALSE;
		    NdisCopyMemory(ez_sec_info->loop_chk_info.source_mac,wdev->ez_security.this_band_info.shared_info.cli_mac_addr,MAC_ADDR_LEN);
		}
		else{// common handling irrespective of role
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_set_other_band_cli_loop_chk_info: Clear Loop Chk role for other CLI\n"));
			NdisZeroMemory(&ez_sec_info->loop_chk_info,sizeof(LOOP_CHK_INFO));
			ez_sec_info->dest_loop_detect = FALSE;

			EZ_CANCEL_TIMER(&ez_sec_info->ez_loop_chk_timer,
				ez_sec_info->ez_loop_chk_timer_running);
		}
}

/* Terminate Loop ck*/
void ez_cancel_loop_chk(struct wifi_dev* wdev)
{	
	if(wdev->ez_security.loop_chk_info.loop_chk_role == SOURCE){
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Source clear loop chk\n"));
		EZ_CANCEL_TIMER(&wdev->ez_security.ez_loop_chk_timer,
			wdev->ez_security.ez_loop_chk_timer_running);

		wdev->ez_security.loop_chk_info.loop_chk_role = NONE; // or zero out struct as below
	    wdev->ez_security.first_loop_check = FALSE;
		wdev->ez_security.dest_loop_detect = FALSE;
		ez_set_other_band_cli_loop_chk_info(wdev->sys_handle,wdev,FALSE);
	}

	if(wdev->ez_security.loop_chk_info.loop_chk_role == DEST){
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("Dest clear loop chk\n"));
		NdisZeroMemory(&wdev->ez_security.loop_chk_info,sizeof(LOOP_CHK_INFO));
		wdev->ez_security.dest_loop_detect = FALSE;
		ez_set_other_band_cli_loop_chk_info(wdev->sys_handle,wdev,FALSE);
	}

}

UCHAR	IPV4TYPE[] = {0x08, 0x00};

INT Set_EasySetup_LoopPktSend(
	IN	PRTMP_ADAPTER	pAd,
	IN	RTMP_STRING *arg)
{
	// Todo: pending
	return TRUE;

}

/* Form and transmit Custom loop detect Pkt*/
static void ez_send_loop_detect_pkt(
	IN	PRTMP_ADAPTER	pAd,
	IN  PMAC_TABLE_ENTRY pMacEntry,
	IN  PUCHAR          pOtherCliMac)
{
	UCHAR BROADCAST_ADDR[MAC_ADDR_LEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	UCHAR Header802_3[14]={0};
	UCHAR               CustomPayload[26]={0x45,0x00, // version(4bit), hdr lenght(4bit), tos
		                                   0x00,0x1A, // total ip datagram length
		                                   0x00,0x01, // identification
		                                   0x40,0x00, // flag & fragmentation
										   0x40,0xFD, // TTL, Protocol type
										   0x39,0xE7, // hdr checksum (considered 0 for calculation)
										   0x00,0x00, // Source IP
										   0x00,0x00, // Source IP
										   0xFF,0xFF, // Dest IP
										   0xFF,0xFF, // Dest IP
										   0x11,0x22, // Random Bytes
										   0x33,0x44, // Random bytes
										   0x55,0x66}; // Random bytes

	//Protocol Type (0x3D any host internal protocol,0x3F any local host network,0xFD & 0xFE for experimentation, 0xFF reserved)
	// 2 byte header checksum field, 	 calculated manually by formula and assuming checksum is zero

	//MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_OFF, ("-----> ez_send_loop_detect_pkt\n"));
	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_send_loop_detect_pkt---->\n"));

	NdisZeroMemory(Header802_3,sizeof(UCHAR)*14);

	MAKE_802_3_HEADER(Header802_3, BROADCAST_ADDR, &pMacEntry->wdev->if_addr[0], IPV4TYPE); // or snap type?

	// Using fixed payload due to checksum calculation required using one's complement
	NdisCopyMemory(&CustomPayload[20],pOtherCliMac,MAC_ADDR_LEN);
	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_send_loop_detect_pkt=> Add in payload Other CLi MAC: %02x-%02x-%02x-%02x-%02x-%02x\n",
	//	CustomPayload[20],CustomPayload[21],CustomPayload[22],CustomPayload[23],CustomPayload[24],CustomPayload[25]));

	// Copy frame to Tx ring

	// Pkt 1
	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_send_loop_detect_pkt: wdev_idx:0x%x => Send Loop Detection Pkt 1\n",pMacEntry->wdev->wdev_idx));
	RTMPToWirelessSta((PRTMP_ADAPTER)pAd, pMacEntry,
					 Header802_3, LENGTH_802_3, (PUCHAR)CustomPayload, 26, FALSE);
	OS_WAIT(5);

	// Pkt 2
	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_send_loop_detect_pkt: wdev_idx:0x%x => Send Loop Detection Pkt 2\n",pMacEntry->wdev->wdev_idx));
	RTMPToWirelessSta((PRTMP_ADAPTER)pAd, pMacEntry,
					 Header802_3, LENGTH_802_3, (PUCHAR)CustomPayload, 26, FALSE);
	OS_WAIT(5);

	// Pkt 3
	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_send_loop_detect_pkt: wdev_idx:0x%x => Send Loop Detection Pkt 3\n",pMacEntry->wdev->wdev_idx));
	RTMPToWirelessSta((PRTMP_ADAPTER)pAd, pMacEntry,
					 Header802_3, LENGTH_802_3, (PUCHAR)CustomPayload, 26, FALSE);

	//EZ_DEBUG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_OFF, ("<----- ez_send_loop_detect_pkt\n"));
}

/* Trigger Loop check process when both CLI connected to non-easy root APs*/
void ez_chk_loop_thru_non_ez_ap(void *ad_obj, IN void *pMacEntry)
{
    unsigned char  other_cli_mac[MAC_ADDR_LEN]={0};
	interface_info_t other_band_info;
	PMAC_TABLE_ENTRY pEntry= (PMAC_TABLE_ENTRY )pMacEntry;
	PRTMP_ADAPTER ad = (PRTMP_ADAPTER)ad_obj;

    NdisZeroMemory(&other_band_info,sizeof(interface_info_t));

	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_chk_loop_thru_non_ez_ap: wdevtype=0x%x, func_idx=0x%x\n",pEntry->wdev->wdev_type,pEntry->wdev->func_idx));

	ez_get_other_band_info(ad_obj, pEntry->wdev, &other_band_info);

	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Other band Info=> Activated:%x, DuplicateLink:%x, NoneasyConnection:%x\n",
	//	other_band_info.interface_activated,
	//	other_band_info.shared_info.link_duplicate,
	//	other_band_info.non_easy_connection));

	if ( !other_band_info.interface_activated )
	{
	    //EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Other band Cli not yet activated \n"));
		return;
	}

	if(pEntry->wdev->ez_security.loop_chk_info.loop_chk_role != SOURCE){

#if 0
		if ( MAC_ADDR_EQUAL(&other_band_info.cli_peer_ap_mac, ZERO_MAC_ADDR) ) // other_band_info.cli_peer_ap_mac??
		{
		    EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Other band Cli not yet connected \n"));
			return;
		}

		if(ad->ApCfg.ApCliTab[pEntry->wdev->func_idx ^ 1].MlmeAux.support_easy_setup == TRUE)
		{
		    EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Other band Cli connected to easy setup Ap\n"));
			return;
		}
#else
		if(other_band_info.non_easy_connection != TRUE)
		{
		    //EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Other band Cli NOT connected to NON Easy Setup Ap\n"));
			return;
		}
#endif

	    pEntry->wdev->ez_security.loop_chk_info.loop_chk_role = SOURCE;

		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Loop chk trigger as source role\n"));

		ez_set_other_band_cli_loop_chk_info(ad_obj,pEntry->wdev,TRUE);
	}

    //trigger loop pkt
    pEntry->wdev->ez_security.dest_loop_detect = FALSE;

	NdisCopyMemory(other_cli_mac,other_band_info.shared_info.cli_mac_addr,MAC_ADDR_LEN);
	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_chk_loop_thru_non_ez_ap=> Add in payload Other CLi MAC: %02x-%02x-%02x-%02x-%02x-%02x\n",
	//	other_cli_mac[0],other_cli_mac[1],other_cli_mac[2],other_cli_mac[3],other_cli_mac[4],other_cli_mac[5]));

	//start timer
	if(pEntry->wdev->ez_security.first_loop_check == TRUE){
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Start loop detect timeout of 5 seconds\n"));
		RTMPSetTimer(&pEntry->wdev->ez_security.ez_loop_chk_timer, EZ_LOOP_CHK_TIMEOUT_5S);
	}else{
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Start loop detect timeout of 10 seconds\n"));
		RTMPSetTimer(&pEntry->wdev->ez_security.ez_loop_chk_timer, EZ_LOOP_CHK_TIMEOUT_10S);
	}

	pEntry->wdev->ez_security.ez_loop_chk_timer_running = TRUE;
	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Start timeout for %d sec\n",EZ_LOOP_CHK_TIMEOUT/1000));

	ez_send_loop_detect_pkt(ad,pEntry,other_cli_mac);

}

/* Loop Check timeout handler*/
VOID ez_loop_chk_timeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	struct _ez_security *ez_sec_info = NULL;
	struct wifi_dev *wdev = NULL;
	MAC_TABLE_ENTRY *pMacEntry = NULL;
	static BOOLEAN last_loop_detect_status = FALSE;
	static UCHAR dup_to_non_dup_trans_detect_count = 0;
	
	if(FunctionContext){
		wdev = (struct wifi_dev *)FunctionContext;
		ez_sec_info = &wdev->ez_security;

	    if(ez_sec_info->ez_loop_chk_timer_running){

			//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_loop_chk_timeout : wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x :clear loop chk context\n",
			//	wdev->wdev_idx,wdev->wdev_type,wdev->func_idx));

			ez_sec_info->ez_loop_chk_timer_running = FALSE;

			if(ez_sec_info->first_loop_check){
				last_loop_detect_status = ez_sec_info->dest_loop_detect;
				dup_to_non_dup_trans_detect_count = 0;
			}
			ez_sec_info->first_loop_check = FALSE;

			//ez_sec_info->loop_chk_info.loop_chk_role = NONE;
			//ez_set_other_band_cli_loop_chk_info(wdev->sys_handle,wdev,FALSE);

			if(ez_sec_info->dest_loop_detect != TRUE){

				if(dup_to_non_dup_trans_detect_count != 0){
					dup_to_non_dup_trans_detect_count++;					
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Non duplicate link confirm : %d\n", dup_to_non_dup_trans_detect_count));
				}
				else if(last_loop_detect_status != ez_sec_info->dest_loop_detect){
					dup_to_non_dup_trans_detect_count++;
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Not a duplicate link now : %d\n", dup_to_non_dup_trans_detect_count));
				}
				else{
					dup_to_non_dup_trans_detect_count = 0;
				}

				if(dup_to_non_dup_trans_detect_count >= 2){
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_loop_chk_timeout: Clear duplciate link status\n"));
					ez_sec_info->this_band_info.shared_info.link_duplicate = FALSE;
					ez_inform_all_interfaces(wdev->sys_handle,wdev, ACTION_UPDATE_DUPLICATE_LINK_ENTRY);

					dup_to_non_dup_trans_detect_count = 0;
				}
			}
			last_loop_detect_status = ez_sec_info->dest_loop_detect;

			pMacEntry = MacTableLookup2(wdev->sys_handle,wdev->bssid,wdev);
			if(pMacEntry != NULL){
				//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("ez_loop_chk_timeout: Recheck for Loop\n"));
				ez_chk_loop_thru_non_ez_ap(wdev->sys_handle,pMacEntry);
			}
			else{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ERROR !!! ez_loop_chk_timeout: not found mac entry\n"));
			}

	    }
		else{
			EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE,("ez_loop_chk_timeout: wdev_idx=0x%x, wdev_type=0x%x, func_idx=0x%x : Timer not running !!!\n",
				wdev->wdev_idx,wdev->wdev_type,wdev->func_idx));
		}
	}
	else{
		EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("ez_loop_chk_timeout: FunctionContext NULL !!!\n"));
	}

}

/* Mark duplicate link and clear Loop chk context*/
static void ez_inform_other_band_cli_loop_detect(void * ad_obj, void * wdev_obj)
{	
	struct wifi_dev* wdev = wdev_obj;
	PRTMP_ADAPTER ad = (PRTMP_ADAPTER)ad_obj;
	struct _ez_security *ez_sec_info = NULL;
#ifdef DUAL_CHIP
	PRTMP_ADAPTER adOthBand = NULL;
	if (!IS_SINGLE_CHIP_DBDC(ad)){
		adOthBand = (PRTMP_ADAPTER)ad->pAdOthBand;
		if(adOthBand == NULL) {
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				("------> %s(): Error: adOthBand address is null\n", __FUNCTION__));
			ASSERT(FALSE);
		}
		}
#endif

	if (IS_SINGLE_CHIP_DBDC(ad_obj)) {
	    ez_sec_info = &ad->ApCfg.ApCliTab[wdev->func_idx ^ 1].wdev.ez_security;
	}		
#ifdef DUAL_CHIP
	else{
		ez_sec_info = &adOthBand->ApCfg.ApCliTab[0].wdev.ez_security;
	}
#endif

	//EZ_CANCEL_TIMER(&ez_sec_info->ez_loop_chk_timer,
	//	ez_sec_info->ez_loop_chk_timer_running);

	//NdisZeroMemory(&ez_sec_info->loop_chk_info,sizeof(LOOP_CHK_INFO));

	if(ez_sec_info->this_band_info.shared_info.link_duplicate != TRUE){
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Mark duplicate link on other band cli\n"));
		ez_sec_info->this_band_info.shared_info.link_duplicate = TRUE;
	}

	if(ez_sec_info->dest_loop_detect){
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Loopk Detect pkt rcvd by Dest when already loop detected\n"));
	}

	// Do this always as source is doing periodic loop check
	ez_sec_info->dest_loop_detect = TRUE;
}

/* Process Rx Pkt for loop pkt detection*/
BOOLEAN ez_is_loop_pkt_rcvd(void * wdev_obj,void *pRxBlk)
{
	struct wifi_dev* wdev = wdev_obj;
	UCHAR BROADCAST_ADDR[MAC_ADDR_LEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	RX_BLK *prxBlk = (RX_BLK *)pRxBlk;
	UCHAR *pPayload = prxBlk->pData;
	//UINT8 dbg_back = DebugLevel;

    // chk source address, dest address, ipv4, payload should contain own bssid

	if(NdisCmpMemory(pPayload,BROADCAST_ADDR,MAC_ADDR_LEN) != 0){
		return FALSE;
	}

	//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Grp packet on Dest\n"));

	if(NdisCmpMemory(&pPayload[6],wdev->ez_security.loop_chk_info.source_mac,MAC_ADDR_LEN) != 0){ // return 0 for same??
		//EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Dest: Source pkt not rcvd\n"));
		return FALSE;
	}

	//DebugLevel = DBG_LVL_ERROR;
	//hex_dump("ez_is_loop_pkt_rcvd: Loop Pkt: \n",prxBlk->pData,prxBlk->MPDUtotalByteCnt);
	//DebugLevel = dbg_back;

	// data pkt chk
	if( (prxBlk->MPDUtotalByteCnt >= 40) &&
		(pPayload[12] == IPV4TYPE[0]) && 
		(pPayload[13] == IPV4TYPE[1]) && 
		(pPayload[14] == 0x45) &&
		(pPayload[23] == 0xFD)
	  )
	{
		//NdisZeroMemory(&wdev->ez_security.loop_chk_info,sizeof(LOOP_CHK_INFO));

		if( !NdisCmpMemory(&pPayload[34],wdev->ez_security.this_band_info.shared_info.cli_mac_addr,MAC_ADDR_LEN) )
		{
			//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_OFF,("Loop Pkt detected for this device\n"));

			if(wdev->ez_security.this_band_info.shared_info.link_duplicate != TRUE)			
			{
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("Loop detected by Dest, Mark link duplicate\n"));
				wdev->ez_security.this_band_info.shared_info.link_duplicate = TRUE;
			}

			// call always as source is doing periodc loop check
			ez_inform_other_band_cli_loop_detect(wdev->sys_handle,wdev);

		}
		//else{
			//EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("Error: Loop Pkt payload : %02x-%02x-%02x-%02x-%02x-%02x\n",
			//	pPayload[34],pPayload[35],pPayload[36],pPayload[37],pPayload[38],pPayload[39]));
		//}

	    return TRUE;	
		
	}

	return FALSE;
}

#endif /* EZ_DUAL_BAND_SUPPORT */

void ez_handle_action_txstatus(void *ad_obj, unsigned int wcid)
{
	MAC_TABLE_ENTRY	*pEntry;
	RTMP_ADAPTER *pAd = ad_obj;
	struct _ez_peer_security_info *ez_peer = NULL;
	
	pEntry = &pAd->MacTab.Content[wcid];
	EZ_DEBUG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
                ("%s(): before calling deauth  for Dev = %02x-%02x-%02x-%02x-%02x-%02x\n", __FUNCTION__, 
                pEntry->Addr[0],pEntry->Addr[1],pEntry->Addr[2],pEntry->Addr[3],pEntry->Addr[4],pEntry->Addr[5]));
	ez_peer = ez_peer_table_search_by_addr(pEntry->wdev,pEntry->Addr);
	if (ez_peer == NULL)
	{
		ASSERT(FALSE);
		return;
	}
	ez_peer->delete_in_differred_context = TRUE;
	if(ez_is_link_duplicate(ez_peer))
	{
		struct _ez_peer_security_info *ez_other_band_peer = ez_get_other_band_ez_peer(pEntry->wdev, ez_peer);
		if (ez_other_band_peer)
		{
			ez_other_band_peer->delete_in_differred_context = TRUE;
			if(IS_SINGLE_CHIP_DBDC(pAd)){
				ez_send_unicast_deauth(pAd, ez_other_band_peer->mac_addr);
			} else {
				ez_send_unicast_deauth(pAd->pAdOthBand, ez_other_band_peer->mac_addr);		
			}
						
		} else {
			ASSERT(NULL);
		}
		
	}
	ez_send_unicast_deauth(pAd, pEntry->Addr);
	
}

BOOLEAN ez_get_band( void * wdev_obj)
{
	struct wifi_dev * wdev= wdev_obj;
	if (wdev->channel >14)
	{
		return TRUE;
	} else {
		return FALSE;
	}
}

void ez_apcli_check_partial_scan(void *ad_obj, CHAR apcli_idx)
{
	ULONG now;
	PRTMP_ADAPTER pAd = ad_obj;
	NdisGetSystemUpTime(&now);
	
	//if (IS_SINGLE_CHIP_DBDC(pAd))
	{
		struct wifi_dev *wdev = &pAd->ApCfg.ApCliTab[apcli_idx].wdev;
		
		EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_INFO,
						("%s(): pAd->ez_partial_scan_time %d\n", __FUNCTION__, pAd->ez_partial_scan_time)); 
		if (RTMP_TIME_AFTER(now,wdev->partial_scan_time_stamp + pAd->ez_partial_scan_time*OS_HZ))
		{
			 if(ez_is_roaming_ongoing(pAd) || ((pAd->ApCfg.ScanReqwdev->ez_security.scan_one_channel 
			 									|| pAd->ApCfg.ScanReqwdev->ez_security.internal_force_connect_bssid)))
			{
				EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Partial scan False !!! \n"));
				pAd->ScanCtrl.PartialScan.bScanning = FALSE;
				pAd->ScanCtrl.PartialScan.LastScanChannel = 0;
			}
			else
			{
				if(pAd->ScanCtrl.PartialScan.bPartialScanAllowed == TRUE)
				{
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Partial scan true !! \n"));
					pAd->ScanCtrl.PartialScan.bScanning = TRUE;
					pAd->ScanCtrl.PartialScan.pwdev = &pAd->ApCfg.ApCliTab[apcli_idx].wdev;
				}
				else
				{
					EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Partial scan false !!\n"));
					pAd->ScanCtrl.PartialScan.bScanning = FALSE;
					pAd->ScanCtrl.PartialScan.LastScanChannel = 0;
				}
			}
		}
		else
		{
			EZ_DEBUG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Partial scan false !!\n"));
			pAd->ScanCtrl.PartialScan.bScanning = FALSE;
			pAd->ScanCtrl.PartialScan.LastScanChannel = 0;

		}
	
	}
}

#endif // WH_EZ_SETUP

