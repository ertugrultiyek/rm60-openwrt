/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	mt7636.c
*/
#ifdef COMPOS_TESTMODE_WIN
#include "config.h"
#else
#include "rt_config.h"
#endif
#include "mcu/mt7636_rom_patch.h"
#include "mcu/mt7636_rom_patch_e3.h"
#include "mcu/mt7636_firmware.h"
#include "eeprom/mt7636_e2p.h"

#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
#include "phy/wf_phy_back.h"
#endif

UCHAR mt7636_ba_range[] = {4, 5, 8, 10, 16, 20, 21, 45};

#if defined(COMPOS_TESTMODE_WIN)
static VOID mt7636_bbp_adjust(struct _RTMP_ADAPTER *pAd, UCHAR Channel)
{
}


static VOID mt7636_switch_channel(struct _RTMP_ADAPTER *pAd, MT_SWITCH_CHANNEL_CFG SwChCfg)
{
	struct _ATE_CTRL *AteCtrl = &pAd->ATECtrl;

	SwChCfg.Bw = AteCtrl->BW;
	SwChCfg.CentralChannel = AteCtrl->Channel;
	SwChCfg.TxStream = 0;
	SwChCfg.RxStream = 0;
	MtCmdChannelSwitch(pAd, SwChCfg);
}


static void mt7636_antenna_default_reset(
	struct _RTMP_ADAPTER *pAd,
	EEPROM_ANTENNA_STRUC *pAntenna)
{
}


static void ToneRadarProgram_v2(struct _RTMP_ADAPTER *pAd, ULONG threshold)
{
}


static void mtusb_cfg_read(struct _RTMP_ADAPTER *pAd, UINT32 *value)
{
}


static void mtusb_cfg_write(struct _RTMP_ADAPTER *pAd, UINT32 value)
{
}

static VOID mt7636_show_pwr_info(struct _RTMP_ADAPTER *pAd)
{
}

static VOID mt7636_bufferModeEfuseFill(struct _RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd)
{
}

#else

static VOID mt7636_bbp_adjust(RTMP_ADAPTER *pAd, UCHAR Channel)
{
	/*do nothing, change to use radio_resource control*/
	/*here should do bbp setting only, bbp is full-offload to fw*/
}


static void mt7636_switch_channel(RTMP_ADAPTER *pAd, MT_SWITCH_CHANNEL_CFG SwChCfg)
{
#ifdef RTMP_MAC_USB
	UINT32 ret = 0;
#endif
#if defined(MT7636_FPGA)
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(%d) todo\n", __func__, SwChCfg.CentralChannel));
	return;
#endif /* MT7636_FPGA */
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd)) {
		RTMP_SEM_EVENT_WAIT(&pAd->hw_atomic, ret);

		if (ret != 0) {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("reg_atomic get failed(ret=%d)\n", ret));
			return;
		}
	}

#endif /* RTMP_MAC_USB */
	MtCmdChannelSwitch(pAd, SwChCfg);
	/* Channel latch */
	pAd->LatchRfRegs.Channel = SwChCfg.CentralChannel;
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd))
		RTMP_SEM_EVENT_UP(&pAd->hw_atomic);

#endif
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			("%s(): Switch to Ch#%d(%dT%dR)\n",
			__func__,
			SwChCfg.CentralChannel,
			pAd->Antenna.field.TxPath,
			pAd->Antenna.field.RxPath));
}


static VOID mt7636_show_pwr_info(RTMP_ADAPTER *pAd)
{
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = &chip_cap->MTTxPwrCap;
	UINT32 value;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel info related to power\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));

	if (pAd->LatchRfRegs.Channel < 14) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("central channel = %d, low_mid_hi = %d\n", pAd->LatchRfRegs.Channel,
				 get_low_mid_hi_index(pAd->LatchRfRegs.Channel)));
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel power(unit: 0.5dbm)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_target_pwr_g_band = 0x%x\n", cap->tx_0_target_pwr_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_target_pwr_g_band = 0x%x\n", cap->tx_1_target_pwr_g_band));
	/* channel power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel power delta(unit: 0.5db)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI]));
	/* bw power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("bw power delta(unit: 0.5db)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("delta_tx_pwr_bw40_g_band = %d\n", cap->delta_tx_pwr_bw40_g_band));
	/* per-rate power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("per-rate power delta\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_cck_1_2 = %d\n", cap->tx_pwr_cck_1_2));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_cck_5_11 = %d\n", cap->tx_pwr_cck_5_11));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_6_9 = %d\n", cap->tx_pwr_g_band_ofdm_6_9));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_12_18 = %d\n", cap->tx_pwr_g_band_ofdm_12_18));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_24_36 = %d\n", cap->tx_pwr_g_band_ofdm_24_36));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_48 = %d\n", cap->tx_pwr_g_band_ofdm_48));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_54 = %d\n", cap->tx_pwr_g_band_ofdm_54));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_bpsk_mcs_32 = %d\n", cap->tx_pwr_ht_bpsk_mcs_32));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_bpsk_mcs_0_8 = %d\n", cap->tx_pwr_ht_bpsk_mcs_0_8));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_qpsk_mcs_1_2_9_10 = %d\n", cap->tx_pwr_ht_qpsk_mcs_1_2_9_10));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_16qam_mcs_3_4_11_12 = %d\n", cap->tx_pwr_ht_16qam_mcs_3_4_11_12));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_5_13 = %d\n", cap->tx_pwr_ht_64qam_mcs_5_13));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_6_14 = %d\n", cap->tx_pwr_ht_64qam_mcs_6_14));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_7_15 = %d\n", cap->tx_pwr_ht_64qam_mcs_7_15));
	/* TMAC POWER INFO */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("per-rate power delta in MAC 0x60130020 ~ 0x60130030\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	RTMP_IO_READ32(pAd, TMAC_FP0R0, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R0 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R1, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R1 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R2, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R2 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R3, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R3 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R4, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R4 = 0x%x\n", value));
	/* TSSI info */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TSSI info\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TSSI enable = %d\n", chip_cap->tssi_enable));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_0_slope_g_band = 0x%x\n", cap->tssi_0_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_slope_g_band = 0x%x\n", cap->tssi_1_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_0_offset_g_band = 0x%x\n", cap->tssi_0_offset_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_offset_g_band = 0x%x\n", cap->tssi_1_offset_g_band));
}


static void mt7636_antenna_default_reset(
	struct _RTMP_ADAPTER *pAd,
	EEPROM_ANTENNA_STRUC *pAntenna)
{
#if defined(MT7636_FPGA)
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s() todo\n", __func__));
	return;
#endif /* MT7636_FPGA */
	pAntenna->word = 0;
	pAd->RfIcType = RFIC_7636;
	pAntenna->field.TxPath = 2;
	pAntenna->field.RxPath = 2;
}


/* Read power per rate */
void mt7636_get_tx_pwr_per_rate(RTMP_ADAPTER *pAd)
{
	BOOLEAN is_empty = 0;
	UINT16 value = 0;
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = &chip_cap->MTTxPwrCap;
	/* G Band tx power for CCK 1M/2M, 5.5M/11M */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_CCK_1_2M, value);

	if (is_empty) {
		cap->tx_pwr_cck_1_2 = 0;
		cap->tx_pwr_cck_5_11 = 0;
	} else {
		/* CCK 1M/2M */
		if (value & TX_PWR_CCK_1_2M_EN) {
			if (value & TX_PWR_CCK_1_2M_SIGN)
				cap->tx_pwr_cck_1_2 = (value & TX_PWR_CCK_1_2M_MASK);
			else
				cap->tx_pwr_cck_1_2 = -(value & TX_PWR_CCK_1_2M_MASK);
		} else
			cap->tx_pwr_cck_1_2 = 0;

		/* CCK 5.5M/11M */
		if (value & TX_PWR_CCK_5_11M_EN) {
			if (value & TX_PWR_CCK_5_11M_SIGN)
				cap->tx_pwr_cck_5_11 = ((value & TX_PWR_CCK_5_11M_MASK) >> 8);
			else
				cap->tx_pwr_cck_5_11 = -((value & TX_PWR_CCK_5_11M_MASK) >> 8);
		} else
			cap->tx_pwr_cck_5_11 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_cck_1_2 = %d\n", cap->tx_pwr_cck_1_2));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_cck_5_11 = %d\n", cap->tx_pwr_cck_5_11));
	/* G Band tx power for OFDM 6M/9M, 12M/18M, 24M/36M, 48M/54M */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_6_9M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_6_9 = 0;
		cap->tx_pwr_g_band_ofdm_12_18 = 0;
	} else {
		/* OFDM 6M/9M */
		if (value & TX_PWR_G_BAND_OFDM_6_9M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_6_9M_SIGN)
				cap->tx_pwr_g_band_ofdm_6_9 = (value & TX_PWR_G_BAND_OFDM_6_9M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_6_9 = -(value & TX_PWR_G_BAND_OFDM_6_9M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_6_9 = 0;

		/* OFDM 12M/18M */
		if (value & TX_PWR_G_BAND_OFDM_12_18M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_12_18M_SIGN)
				cap->tx_pwr_g_band_ofdm_12_18 = ((value & TX_PWR_G_BAND_OFDM_12_18M_MASK) >> 8);
			else
				cap->tx_pwr_g_band_ofdm_12_18 = -((value & TX_PWR_G_BAND_OFDM_12_18M_MASK) >> 8);
		} else
			cap->tx_pwr_g_band_ofdm_12_18 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_6_9 = %d\n", cap->tx_pwr_g_band_ofdm_6_9));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_12_18 = %d\n", cap->tx_pwr_g_band_ofdm_12_18));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_24_36M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_24_36 = 0;
		cap->tx_pwr_g_band_ofdm_48 = 0;
	} else {
		/* OFDM 24M/36M */
		if (value & TX_PWR_G_BAND_OFDM_24_36M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_24_36M_SIGN)
				cap->tx_pwr_g_band_ofdm_24_36 = (value & TX_PWR_G_BAND_OFDM_24_36M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_24_36 = -(value & TX_PWR_G_BAND_OFDM_24_36M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_24_36 = 0;

		/* OFDM 48M */
		if (value & TX_PWR_G_BAND_OFDM_48M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_48M_SIGN)
				cap->tx_pwr_g_band_ofdm_48 = ((value & TX_PWR_G_BAND_OFDM_48M_MASK) >> 8);
			else
				cap->tx_pwr_g_band_ofdm_48 = -((value & TX_PWR_G_BAND_OFDM_48M_MASK) >> 8);
		} else
			cap->tx_pwr_g_band_ofdm_48 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_24_36 = %d\n", cap->tx_pwr_g_band_ofdm_24_36));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_48 = %d\n", cap->tx_pwr_g_band_ofdm_48));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_54M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_54 = 0;
		cap->tx_pwr_ht_bpsk_mcs_0_8 = 0;
	} else {
		/* OFDM 54M */
		if (value & TX_PWR_G_BAND_OFDM_54M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_54M_SIGN)
				cap->tx_pwr_g_band_ofdm_54 = (value & TX_PWR_G_BAND_OFDM_54M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_54 = -(value & TX_PWR_G_BAND_OFDM_54M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_54 = 0;

		/* HT MCS_0, MCS_8 */
		if (value & TX_PWR_HT_BPSK_MCS_0_8_EN) {
			if (value & TX_PWR_HT_BPSK_MCS_0_8_SIGN)
				cap->tx_pwr_ht_bpsk_mcs_0_8 = ((value & TX_PWR_HT_BPSK_MCS_0_8_MASK) >> 8);
			else
				cap->tx_pwr_ht_bpsk_mcs_0_8 = -((value & TX_PWR_HT_BPSK_MCS_0_8_MASK) >> 8);
		} else
			cap->tx_pwr_ht_bpsk_mcs_0_8 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_54 = %d\n", cap->tx_pwr_g_band_ofdm_54));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_bpsk_mcs_0_8 = %d\n", cap->tx_pwr_ht_bpsk_mcs_0_8));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_BPSK_MCS_32, value);

	if (is_empty) {
		cap->tx_pwr_ht_bpsk_mcs_32 = 0;
		cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = 0;
	} else {
		/* HT MCS_0, MCS_8 */
		if (value & TX_PWR_HT_BPSK_MCS_32_EN) {
			if (value & TX_PWR_HT_BPSK_MCS_32_SIGN)
				cap->tx_pwr_ht_bpsk_mcs_32 = (value & TX_PWR_HT_BPSK_MCS_32_MASK);
			else
				cap->tx_pwr_ht_bpsk_mcs_32 = -(value & TX_PWR_HT_BPSK_MCS_32_MASK);
		} else
			cap->tx_pwr_ht_bpsk_mcs_32 = 0;

		/* HT MCS_1, MCS_2, MCS_9, MCS_10 */
		if (value & TX_PWR_HT_QPSK_MCS_1_2_9_10_EN) {
			if (value & TX_PWR_HT_QPSK_MCS_1_2_9_10_SIGN)
				cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = ((value & TX_PWR_HT_QPSK_MCS_1_2_9_10_MASK) >> 8);
			else
				cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = -((value & TX_PWR_HT_QPSK_MCS_1_2_9_10_MASK) >> 8);
		} else
			cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_bpsk_mcs_32 = %d\n", cap->tx_pwr_ht_bpsk_mcs_32));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_qpsk_mcs_1_2_9_10 = %d\n", cap->tx_pwr_ht_qpsk_mcs_1_2_9_10));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_16QAM_MCS_3_4_11_12, value);

	if (is_empty) {
		cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = 0;
		cap->tx_pwr_ht_64qam_mcs_5_13 = 0;
	} else {
		/* HT MCS_3, MCS_4, MCS_11, MCS_12 */
		if (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_EN) {
			if (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_SIGN)
				cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_MASK);
			else
				cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = -(value & TX_PWR_HT_16QAM_MCS_3_4_11_12_MASK);
		} else
			cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = 0;

		/* HT MCS_5, MCS_13 */
		if (value & TX_PWR_HT_64QAM_MCS_5_13_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_5_13_SIGN)
				cap->tx_pwr_ht_64qam_mcs_5_13 = ((value & TX_PWR_HT_64QAM_MCS_5_13_MASK) >> 8);
			else
				cap->tx_pwr_ht_64qam_mcs_5_13 = -((value & TX_PWR_HT_64QAM_MCS_5_13_MASK) >> 8);
		} else
			cap->tx_pwr_ht_64qam_mcs_5_13 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_16qam_mcs_3_4_11_12 = %d\n", cap->tx_pwr_ht_16qam_mcs_3_4_11_12));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_5_13 = %d\n", cap->tx_pwr_ht_64qam_mcs_5_13));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_64QAM_MCS_6_14, value);

	if (is_empty) {
		cap->tx_pwr_ht_64qam_mcs_6_14 = 0;
		cap->tx_pwr_ht_64qam_mcs_7_15 = 0;
	} else {
		/* HT MCS_6, MCS_14 */
		if (value & TX_PWR_HT_64QAM_MCS_6_14_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_6_14_SIGN)
				cap->tx_pwr_ht_64qam_mcs_6_14 = (value & TX_PWR_HT_64QAM_MCS_6_14_MASK);
			else
				cap->tx_pwr_ht_64qam_mcs_6_14 = -(value & TX_PWR_HT_64QAM_MCS_6_14_MASK);
		} else
			cap->tx_pwr_ht_64qam_mcs_6_14 = 0;

		/* HT MCS_7, MCS_15 */
		if (value & TX_PWR_HT_64QAM_MCS_7_15_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_7_15_SIGN)
				cap->tx_pwr_ht_64qam_mcs_7_15 = ((value & TX_PWR_HT_64QAM_MCS_7_15_MASK) >> 8);
			else
				cap->tx_pwr_ht_64qam_mcs_7_15 = -((value & TX_PWR_HT_64QAM_MCS_7_15_MASK) >> 8);
		} else
			cap->tx_pwr_ht_64qam_mcs_7_15 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_6_14 = %d\n", cap->tx_pwr_ht_64qam_mcs_6_14));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_7_15 = %d\n", cap->tx_pwr_ht_64qam_mcs_7_15));
}


void mt7636_get_tx_pwr_info(RTMP_ADAPTER *pAd)
{
	bool is_empty = 0;
	UINT16 value = 0;
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = &chip_cap->MTTxPwrCap;
	/* Read 20/40 BW delta */
	is_empty = RT28xx_EEPROM_READ16(pAd, G_BAND_20_40_BW_PWR_DELTA, value);

	if (is_empty)
		cap->delta_tx_pwr_bw40_g_band = 0x0;
	else {
		/* G Band */
		if (value & G_BAND_20_40_BW_PWR_DELTA_EN) {
			if (value & G_BAND_20_40_BW_PWR_DELTA_SIGN) {
				/* bit[0..5] tx power delta value */
				cap->delta_tx_pwr_bw40_g_band = (value & G_BAND_20_40_BW_PWR_DELTA_MASK);
			} else
				cap->delta_tx_pwr_bw40_g_band = -(value & G_BAND_20_40_BW_PWR_DELTA_MASK);
		} else
			cap->delta_tx_pwr_bw40_g_band = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("delta_tx_pwr_bw40_g_band = %d\n", cap->delta_tx_pwr_bw40_g_band));
	/* ///////////////// Tx0 ////////////////////////// */
	/* Read TSSI slope/offset for TSSI compensation */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_TSSI_SLOPE, value);
	cap->tssi_0_slope_g_band =
		(is_empty) ? TSSI_0_SLOPE_G_BAND_DEFAULT_VALUE : (value & TX0_G_BAND_TSSI_SLOPE_MASK);
	cap->tssi_0_offset_g_band =
		(is_empty) ? TSSI_0_OFFSET_G_BAND_DEFAULT_VALUE : ((value & TX0_G_BAND_TSSI_OFFSET_MASK) >> 8);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_slope_g_band = %d\n", cap->tssi_0_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_offset_g_band = %d\n", cap->tssi_0_offset_g_band));
	/* Read 54M target power */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_TARGET_PWR, value);
	cap->tx_0_target_pwr_g_band =
		(is_empty) ? TX_TARGET_PWR_DEFAULT_VALUE : (value & TX0_G_BAND_TARGET_PWR_MASK);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_target_pwr_g_band = %d\n", cap->tx_0_target_pwr_g_band));

	/* Read power offset (channel delta) */
	if (is_empty)
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x0;
	else {
		/* tx power offset LOW */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_LOW_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_LOW_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = ((value & TX0_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = -((value & TX0_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW]));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_CHL_PWR_DELTA_MID, value);

	if (is_empty) {
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x0;
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x0;
	} else {
		/* tx power offset MID */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_MID_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_MID_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = (value & TX0_G_BAND_CHL_PWR_DELTA_MID_MASK);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = -(value & TX0_G_BAND_CHL_PWR_DELTA_MID_MASK);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x0;

		/* tx power offset HIGH */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_HI_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_HI_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = ((value & TX0_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = -((value & TX0_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_MID] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_HI] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI]));
	/* ///////////////// Tx1 ////////////////////////// */
	/* Read TSSI slope/offset for TSSI compensation */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_TSSI_SLOPE, value);
	cap->tssi_1_slope_g_band = (is_empty) ? TSSI_1_SLOPE_G_BAND_DEFAULT_VALUE : (value & TX1_G_BAND_TSSI_SLOPE_MASK);
	cap->tssi_1_offset_g_band = (is_empty) ? TSSI_1_OFFSET_G_BAND_DEFAULT_VALUE : ((value & TX1_G_BAND_TSSI_OFFSET_MASK) >> 8);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_1_slope_g_band = %d\n", cap->tssi_1_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_1_offset_g_band = %d\n", cap->tssi_1_offset_g_band));
	/* Read 54M target power */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_TARGET_PWR, value);
	cap->tx_1_target_pwr_g_band = (is_empty) ? TX_TARGET_PWR_DEFAULT_VALUE : (value & TX1_G_BAND_TARGET_PWR_MASK);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_target_pwr_g_band = %d\n", cap->tx_1_target_pwr_g_band));

	/* Read power offset (channel delta) */
	if (is_empty)
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] =  0;
	else {
		/* tx power offset LOW */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_LOW_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_LOW_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = ((value & TX1_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = -((value & TX1_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW]));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_CHL_PWR_DELTA_MID, value);

	if (is_empty) {
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0;
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0;
	} else {
		/* tx power offset MID */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_MID_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_MID_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = (value & TX1_G_BAND_CHL_PWR_DELTA_MID_MASK);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = -(value & TX1_G_BAND_CHL_PWR_DELTA_MID_MASK);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0;

		/* tx power offset HIGH */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_HI_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_HI_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = ((value & TX1_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = -((value & TX1_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_MID] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_HI] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI]));
}

static UINT8 mt7636_txpwr_chlist[] = {
	1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
	36, 38, 40, 44, 46, 48, 52, 54, 56, 60, 62, 64,
	100, 102, 104, 108, 110, 112, 116, 118, 120, 124, 126, 128, 132, 134, 136, 140,
	149, 151, 153, 157, 159, 161, 165, 167, 169, 171, 173,
};

UINT32 mt7636_read_chl_pwr(RTMP_ADAPTER *ad)
{
	UINT32 i, choffset;
	/* Read Tx power value for all channels*/
	/* Value from 1 - 0x7f. Default value is 24.*/
	/* Power value : 2.4G 0x00 (0) ~ 0x1F (31)*/
	/*             : 5.5G 0xF9 (-7) ~ 0x0F (15)*/
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()--->\n", __func__));

	for (i = 0; i < sizeof(mt7636_txpwr_chlist); i++) {
		ad->TxPower[i].Channel = mt7636_txpwr_chlist[i];
		ad->TxPower[i].Power = TX_TARGET_PWR_DEFAULT_VALUE;
		ad->TxPower[i].Power2 = TX_TARGET_PWR_DEFAULT_VALUE;
	}

	/* 1. U-NII lower/middle band: 36, 38, 40; 44, 46, 48; 52, 54, 56; 60, 62, 64 (including central frequency in BW 40MHz)*/
	choffset = 14;
	ASSERT((ad->TxPower[choffset].Channel == 36));
	choffset = 14 + 12 + 16 + 11;

	/* 4. Print and Debug*/
	for (i = 0; i < choffset; i++) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Channel=%d, Power[Tx0:%d, Tx1:%d]\n",
				 ad->TxPower[i].Channel, ad->TxPower[i].Power, ad->TxPower[i].Power2));
	}

	return TRUE;
}


static inline VOID bufferModeFieldSet(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd, UINT16 addr)
{
	UINT32 i = pCmd->ucCount;

	pCmd->BinContent[i].u2Addr = cpu2le16(addr);
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[addr];
	pCmd->ucCount++;
}


static VOID mt7636_bufferModeEfuseFill(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd)
{
	UINT16 i = 0;

	pCmd->ucCount = 0;

	for (i = 0x20; i <= 0xff; i++)
		bufferModeFieldSet(pAd, pCmd, i);

	/*must minus last add*/
	pCmd->ucCount--;
}
#endif /* defined(COMPOS_TESTMODE_WIN) */


#ifdef CONFIG_STA_SUPPORT
static VOID mt7636_init_dev_nick_name(RTMP_ADAPTER *ad)
{
#ifdef RTMP_MAC_USB

	if (IS_MT76x6(ad))
		snprintf((RTMP_STRING *) ad->nickname, sizeof(ad->nickname), "mt7636u_sta");

#endif
#ifdef RTMP_MAC_SDIO

	if (IS_MT76x6(ad))
		snprintf((RTMP_STRING *) ad->nickname, sizeof(ad->nickname), "mt7636s_sta");

#endif
}
#endif /* CONFIG_STA_SUPPORT */


static VOID mt7636_init_mac_cr(RTMP_ADAPTER *pAd)
{
	UINT32 mac_val;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
#ifdef MT7636_FPGA
	/* enable MAC2MAC mode */
	RTMP_IO_READ32(pAd, RMAC_MISC, &mac_val);
	mac_val |= BIT18;
	RTMP_IO_WRITE32(pAd, RMAC_MISC, mac_val);
	/*
	sync. MT7628.c
	WHQA_00016749, there are a lots of Tx retry in FPGA.
	per Jacky's comment, enlarge the timeout value of waiting ack.
	real chip shall not have the symptom.
	*/
	mac_val = 0x00d700d7;
	RTMP_IO_WRITE32(pAd, TMAC_CDTR, mac_val);
	mac_val = 0x00d700d7;
	RTMP_IO_WRITE32(pAd, TMAC_ODTR, mac_val);
#endif /* MT7603_FPGA */
	/* Disable 802.11 to 802.3 Hdr tranlation */
	RTMP_IO_READ32(pAd, DMA_DCR0, &mac_val);
	mac_val &= ~BIT19;
	RTMP_IO_WRITE32(pAd, DMA_DCR0, mac_val);

	/* ECO solution */
	/* WHQA_00018345: MAC TX sequence number skip issue */
	if (MTK_REV_GTE(pAd, MT76x6, MT76x6E2)) {
		mac_val = 0;
		RTMP_IO_READ32(pAd, AGG_SCR, &mac_val);
		mac_val |= BIT4;
		RTMP_IO_WRITE32(pAd, AGG_SCR, mac_val);
	}

	/* TxS Setting */
	MtAsicSetTxSClassifyFilter(pAd, TXS2HOST, TXS2H_QID1, TXS2HOST_AGGNUMS, 0x00, 0);
#ifdef DOT11W_PMF_SUPPORT
	/* Enable BIP */
	MAC_IO_READ32(pAd, WTBL_OFF_BCR, &mac_val);
	mac_val |= BIP_EN;
	MAC_IO_WRITE32(pAd, WTBL_OFF_BCR, mac_val);
#endif /* DOT11W_PMF_SUPPORT */
}


static RTMP_CHIP_CAP MT7636_ChipCap;
static RTMP_CHIP_OP MT7636_ChipOp;

static void mt7636_fw_prepare(RTMP_ADAPTER *pAd)
{
	struct fwdl_ctrl *ctrl = &pAd->MCUCtrl.fwdl_ctrl;

#ifdef COMPOS_WIN
#else

	/* ROM Patch*/
	if (IS_MT76x6_FW_VER_E1(pAd)) {
		ctrl->patch_profile[WM_CPU].source.header_ptr = mt7636_rom_patch;
		ctrl->patch_profile[WM_CPU].source.header_len = sizeof(mt7636_rom_patch);
		ctrl->patch_profile[WM_CPU].source.bin_name = MT7636_ROM_PATCH_BIN_FILE_NAME;
	} else if (IS_MT76x6_FW_VER_E3(pAd)) {
		ctrl->patch_profile[WM_CPU].source.header_ptr = mt7636_rom_patch_e3;
		ctrl->patch_profile[WM_CPU].source.header_len = sizeof(mt7636_rom_patch_e3);
		ctrl->patch_profile[WM_CPU].source.bin_name = MT7636_ROM_PATCH_BIN_FILE_NAME_E3;
	} else {
		/* Use E1 rom patch as default */
		ctrl->patch_profile[WM_CPU].source.header_ptr = mt7636_rom_patch;
		ctrl->patch_profile[WM_CPU].source.header_len = sizeof(mt7636_rom_patch);
		ctrl->patch_profile[WM_CPU].source.bin_name = MT7636_ROM_PATCH_BIN_FILE_NAME;
	}

	/* RAM Code */
	ctrl->fw_profile[WM_CPU].source.header_ptr = MT7636_FirmwareImage;
	ctrl->fw_profile[WM_CPU].source.header_len = sizeof(MT7636_FirmwareImage);
	ctrl->fw_profile[WM_CPU].source.bin_name = MT7636_FW_BIN_FILE_NAME;

#endif
}

static VOID mt7636_fwdl_datapath_setup(RTMP_ADAPTER *pAd, BOOLEAN init)
{
#ifdef DMA_SCH_SUPPORT
	MtAsicSetDmaByPassMode(pAd, init);
#endif /* DMA_SCH_SUPPORT */
}

static VOID mt7636_chipCap_init(VOID)
{
	os_zero_mem(&MT7636_ChipCap, sizeof(RTMP_CHIP_CAP));
	MT7636_ChipCap.max_nss = 2;
	MT7636_ChipCap.TXWISize = sizeof(TMAC_TXD_L); /* 32 */
	MT7636_ChipCap.RXWISize = 28;
	MT7636_ChipCap.WtblHwNum = MT7636_MT_WTBL_SIZE;
	MT7636_ChipCap.WtblPseAddr = MT7636_PSE_WTBL_2_ADDR;
#ifdef RTMP_MAC_PCI
	MT7636_ChipCap.WPDMABurstSIZE = 3;
#endif
	MT7636_ChipCap.SnrFormula = SNR_FORMULA4;
	MT7636_ChipCap.FlgIsHwWapiSup = TRUE;
	MT7636_ChipCap.FlgIsHwAntennaDiversitySup = FALSE;
#ifdef STREAM_MODE_SUPPORT
	MT7636_ChipCap.FlgHwStreamMode = FALSE;
#endif
#ifdef TXBF_SUPPORT
	MT7636_ChipCap.FlgHwTxBfCap     = TRUE;
	MT7636_ChipCap.FlgITxBfBinWrite = FALSE;
#endif
	MT7636_ChipCap.asic_caps = (fASIC_CAP_PMF_ENC | fASIC_CAP_MCS_LUT | fASIC_CAP_RDG);
	MT7636_ChipCap.phy_caps = (fPHY_CAP_24G | fPHY_CAP_5G | fPHY_CAP_HT | fPHY_CAP_LDPC);
	MT7636_ChipCap.MaxNumOfRfId = MAX_RF_ID;
	MT7636_ChipCap.pRFRegTable = NULL;
	MT7636_ChipCap.MaxNumOfBbpId = 200;
	MT7636_ChipCap.pBBPRegTable = NULL;
	MT7636_ChipCap.bbpRegTbSize = 0;
#ifdef NEW_MBSSID_MODE
#ifdef ENHANCE_NEW_MBSSID_MODE
	MT7636_ChipCap.MBSSIDMode = MBSSID_MODE4;
#else
	MT7636_ChipCap.MBSSIDMode = MBSSID_MODE1;
#endif /* ENHANCE_NEW_MBSSID_MODE */
#else
	MT7636_ChipCap.MBSSIDMode = MBSSID_MODE0;
#endif /* NEW_MBSSID_MODE */
#ifdef RTMP_EFUSE_SUPPORT
	MT7636_ChipCap.EFUSE_USAGE_MAP_START = 0x1e0;
	MT7636_ChipCap.EFUSE_USAGE_MAP_END = 0x1fc;
	MT7636_ChipCap.EFUSE_USAGE_MAP_SIZE = 29;
	MT7636_ChipCap.EFUSE_RESERVED_SIZE = 22;	/* Cal-Free is 22 free block */
#endif
	MT7636_ChipCap.EEPROM_DEFAULT_BIN = MT7636_E2PImage;
	MT7636_ChipCap.EEPROM_DEFAULT_BIN_SIZE = sizeof(MT7636_E2PImage);
	MT7636_ChipCap.EFUSE_BUFFER_CONTENT_SIZE = 0x80;
#ifdef CONFIG_ANDES_SUPPORT
	MT7636_ChipCap.need_load_patch = BIT(WM_CPU);
	MT7636_ChipCap.need_load_fw = BIT(WM_CPU);
	MT7636_ChipCap.load_patch_flow = PATCH_FLOW_V1;
	MT7636_ChipCap.load_fw_flow = FW_FLOW_V1;
	MT7636_ChipCap.patch_format = PATCH_FORMAT_V1;
	MT7636_ChipCap.fw_format = FW_FORMAT_V2;
#ifdef WCX_SUPPORT
	MT7636_ChipCap.load_patch_method = BIT(BIN_METHOD);
	MT7636_ChipCap.load_fw_method = BIT(BIN_METHOD);
#else
	MT7636_ChipCap.load_patch_method = BIT(HEADER_METHOD);
	MT7636_ChipCap.load_fw_method = BIT(HEADER_METHOD);
#endif /* WCX_SUPPORT */
	MT7636_ChipCap.rom_patch_offset = MT7636_ROM_PATCH_START_ADDRESS;
#endif
	MT7636_ChipCap.MCUType = ANDES;
	MT7636_ChipCap.cmd_header_len = ROM_CODE_CMD_HEADER_LEN;
#ifdef RTMP_PCI_SUPPORT
	MT7636_ChipCap.cmd_padding_len = 0;
#endif
#ifdef RTMP_SDIO_SUPPORT
	MT7636_ChipCap.cmd_padding_len = 4;
#endif
#ifdef RTMP_USB_SUPPORT
	MT7636_ChipCap.cmd_padding_len = 4;
	MT7636_ChipCap.CommandBulkOutAddr = 0x8;
	MT7636_ChipCap.WMM0ACBulkOutAddr[0] = 0x5;
	MT7636_ChipCap.WMM0ACBulkOutAddr[1] = 0x4;
	MT7636_ChipCap.WMM0ACBulkOutAddr[2] = 0x6;
	MT7636_ChipCap.WMM0ACBulkOutAddr[3] = 0x7;
	MT7636_ChipCap.WMM1ACBulkOutAddr	= 0x9;
	MT7636_ChipCap.DataBulkInAddr = 0x84;
	MT7636_ChipCap.CommandRspBulkInAddr = 0x85;
#endif
#ifdef CARRIER_DETECTION_SUPPORT
	MT7636_ChipCap.carrier_func = TONE_RADAR_V2;
#endif
	MT7636_ChipCap.hif_type = HIF_MT;
	MT7636_ChipCap.rf_type = RF_MT;
	MT7636_ChipCap.TxAggLimit = 24;
#ifdef RTMP_SDIO_SUPPORT
	MT7636_ChipCap.RxBAWinSize = 64;
#ifdef COEX_SUPPORT
	MT7636_ChipCap.TxBAWinSize = 64;
#endif /*COEX_SUPPORT */

#endif
#ifdef RTMP_USB_SUPPORT
	MT7636_ChipCap.UsbAggBufSize = 0x8000; /* 32KB */
	MT7636_ChipCap.RxBAWinSize = 64;
#ifdef COEX_SUPPORT
	MT7636_ChipCap.TxBAWinSize = 64;
#endif /* COEX_SUPPORT */
#endif
	MT7636_ChipCap.ht_max_ampdu_len_exp = 3;
#ifdef RACTRL_FW_OFFLOAD_SUPPORT
	MT7636_ChipCap.fgRateAdaptFWOffload = TRUE;
#endif /* RACTRL_FW_OFFLOAD_SUPPORT */
	MT7636_ChipCap.TxOPScenario = 0x0;
	MT7636_ChipCap.CurrentTxOP = 0x0;
	MT7636_ChipCap.default_txop = 0x20;
	MT7636_ChipCap.WmmHwNum = MT7636_MT_WMM_SIZE;
	MT7636_ChipCap.PDA_PORT = MT7636_PDA_PORT;
#if !defined(COMPOS_TESTMODE_WIN)
	MT7636_ChipCap.qm = GENERIC_QM;
#endif
	MT7636_ChipCap.tm = TASKLET_METHOD;
	MT7636_ChipCap.wmm_detect_method = WMM_DETECT_METHOD1;
	/* for interrupt enable mask */
	MT7636_ChipCap.int_enable_mask = ((MT_DELAYINTMASK) | (MT_RxINT | MT_INT_T0_DONE | MT_INT_T1_DONE | 
						MT_INT_T2_DONE | MT_INT_T3_DONE | MT_TxMgmtInt) | MT_INT_BMC_DLY);
#if (CFG_CPU_LOADING_RXRING_DLY == 1)
	MT7636_ChipCap.int_enable_mask &= ~(MT_INT_RX_DATA | MT_INT_RX_CMD);
	MT7636_ChipCap.int_enable_mask |= MT_INT_RX_DLY;
#endif
#if (CFG_CPU_LOADING_DISABLE_TXDONE0 == 1)
	MT7636_ChipCap.int_enable_mask &= ~MT_INT_AC0_DLY;
#endif
	MT7636_ChipCap.ba_range = mt7636_ba_range;
}

#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
static INT Mt7636AsicArchOpsInit(RTMP_ADAPTER *pAd)
{
	RTMP_ARCH_OP *arch_ops = &pAd->archOps;

	arch_ops->archSetDevMac = MtAsicSetDevMacByDriver;
	arch_ops->archSetBssid = MtAsicSetBssidByDriver;
	arch_ops->archSetStaRec = MtAsicSetStaRecByDriver;
	arch_ops->archDisableBeacon = MtSmacAsicDisableBeacon;
	arch_ops->archEnableBeacon = MtSmacAsicEnableBeacon;
	arch_ops->archUpdateBeacon = MtUpdateBeaconToAsic;
#ifdef CONFIG_AP_SUPPORT
	arch_ops->archSetMbssWdevIfAddr = MtAsicSetMbssWdevIfAddrGen1;
	arch_ops->archSetMbssHwCRSetting = MtSmacSetMbssHwCRSetting;
	arch_ops->archSetExtTTTTHwCRSetting = MtSmacSetExtTTTTHwCRSetting;
	arch_ops->archSetExtMbssEnableCR = MtSmacSetExtMbssEnableCR;
#endif /* CONFIG_AP_SUPPORT */
	arch_ops->archGetTsfTime = MtAsicGetTsfTimeByDriver;
	arch_ops->archSetPreTbtt = MtAsicSetPreTbtt;
	arch_ops->archDisableSync = MtAsicDisableSyncByDriver;
	arch_ops->archSetSyncModeAndEnable = MtAsicEnableBssSyncByDriver;
#ifdef CONFIG_STA_SUPPORT
	arch_ops->archEnableIbssSync = MtAsicEnableBssSyncByDriver;
#endif
#ifdef CONFIG_AP_SUPPORT
	arch_ops->archGetTxTsc = MtAsicGetTxTscByDriver;
#endif /* CONFIG_AP_SUPPORT */
	arch_ops->archDelWcidTab = MtAsicDelWcidTabByDriver;
	arch_ops->archAddRemoveKeyTab = MtAsicAddRemoveKeyByDriver;
	arch_ops->archUpdateRxWCIDTable = MtAsicUpdateRxWCIDTableByDriver;
	arch_ops->archUpdateBASession = MtAsicUpdateBASessionByDriver;
	arch_ops->archSetSMPS = MtAsicSetSMPSByDriver;
#ifdef MT_PS
	arch_ops->archSetIgnorePsm = MtSetIgnorePsmByDriver;
#endif
	arch_ops->archSetMacTxRx = MtAsicSetMacTxRx;
	arch_ops->archSetMacMaxLen = MtAsicSetMacMaxLen;
	arch_ops->archSetTxStream = MtAsicSetTxStream;
	arch_ops->archSetRxStream = MtAsicSetRxStream;
	arch_ops->archSetRxFilter = MtAsicSetRxFilter;
#ifdef IGMP_SNOOP_SUPPORT
	arch_ops->archMcastEntryInsert = MulticastFilterTableInsertEntry;
	arch_ops->archMcastEntryDelete = MulticastFilterTableDeleteEntry;
#endif
	arch_ops->write_tmac_info_fixed_rate = mt_write_tmac_info_fixed_rate;
	arch_ops->write_tmac_info = mt_write_tmac_info;
#if !defined(COMPOS_TESTMODE_WIN)
	arch_ops->hw_tx = mt_hw_tx;
	arch_ops->mlme_hw_tx = mt_mlme_hw_tx;
#endif
#ifdef RTMP_PCI_SUPPORT

	if (IS_PCI_INF(pAd)) {
		arch_ops->write_tx_resource = mt_pci_write_tx_resource;
		arch_ops->write_multi_tx_resource = mt_pci_write_multi_tx_resource;
		arch_ops->write_multi_tx_resource = mt_pci_write_final_tx_resource;
		arch_ops->write_frag_tx_resource = mt_pci_write_frag_tx_resource;
		arch_ops->kickout_data_tx = pci_kickout_data_tx;
		arch_ops->get_tx_resource_free_num = pci_get_tx_resource_free_num;
	}

#endif
#ifdef RTMP_USB_SUPPORT

	if (IS_USB_INF(pAd)) {
		arch_ops->write_tx_resource = usb_write_tx_resource;
		arch_ops->write_multi_tx_resource = usb_write_multi_tx_resource;
		arch_ops->write_final_tx_resource = mt_usb_write_final_tx_resource;
		arch_ops->write_frag_tx_resource = usb_write_frag_tx_resource;
		arch_ops->kickout_data_tx = usb_kickout_data_tx;
		arch_ops->get_tx_resource_free_num = usb_get_tx_resource_free_num;
	}

#endif
#ifdef RTMP_SDIO_SUPPORT

	if (IS_SDIO_INF(pAd)) {
		arch_ops->write_tx_resource = sdio_write_tx_resource;
		arch_ops->write_multi_tx_resource = sdio_write_multi_tx_resource;
		arch_ops->write_final_tx_resource = sdio_write_final_tx_resource;
		arch_ops->write_frag_tx_resource = sdio_write_frag_tx_resource;
		arch_ops->kickout_data_tx = sdio_kickout_data_tx;
		arch_ops->get_tx_resource_free_num = sdio_get_tx_resource_free_num;
	}

#endif
	return TRUE;
}
#endif

static VOID mt7636_chipOp_init(VOID)
{
	MT7636_ChipOp.ChipBBPAdjust = mt7636_bbp_adjust;
	MT7636_ChipOp.ChipSwitchChannel = mt7636_switch_channel;
	MT7636_ChipOp.AsicMacInit = mt7636_init_mac_cr;
	MT7636_ChipOp.AsicAntennaDefaultReset = mt7636_antenna_default_reset;
	MT7636_ChipOp.ChipAGCInit = NULL;
#ifdef CONFIG_STA_SUPPORT
	MT7636_ChipOp.ChipAGCAdjust = NULL;
#endif
	MT7636_ChipOp.AsicRfTurnOn = NULL;
	MT7636_ChipOp.AsicHaltAction = NULL;
	MT7636_ChipOp.AsicRfTurnOff = NULL;
	MT7636_ChipOp.AsicReverseRfFromSleepMode = NULL;
#ifdef CONFIG_STA_SUPPORT
	MT7636_ChipOp.NetDevNickNameInit = mt7636_init_dev_nick_name;
#endif
#ifdef CARRIER_DETECTION_SUPPORT
	MT7636_ChipOp.ToneRadarProgram = ToneRadarProgram_v2;
#endif
	MT7636_ChipOp.RxSensitivityTuning = NULL;
	MT7636_ChipOp.DisableTxRx = NULL;
#ifdef RTMP_USB_SUPPORT
	MT7636_ChipOp.AsicRadioOn = NULL;
	MT7636_ChipOp.AsicRadioOff = NULL;
	MT7636_ChipOp.usb_cfg_read = mtusb_cfg_read;
	MT7636_ChipOp.usb_cfg_write = mtusb_cfg_write;
#endif
#ifdef RTMP_PCI_SUPPORT
	/* MT7636_ChipOp.AsicRadioOn = RT28xxPciAsicRadioOn; */
	/* MT7636_ChipOp.AsicRadioOff = RT28xxPciAsicRadioOff; */
#endif
	MT7636_ChipOp.show_pwr_info = mt7636_show_pwr_info;
	MT7636_ChipOp.bufferModeEfuseFill = mt7636_bufferModeEfuseFill;
#ifdef MT_WOW_SUPPORT
	MT7636_ChipOp.AsicWOWEnable = MT76xxAndesWOWEnable;
	MT7636_ChipOp.AsicWOWDisable = MT76xxAndesWOWDisable;
	/* MT7636_ChipOp.AsicWOWInit = MT76xxAndesWOWInit, */
#endif /* MT_WOW_SUPPORT */
	MT7636_ChipOp.MtCmdTx = MtCmdSendMsg;
	MT7636_ChipOp.prepare_fwdl_img = mt7636_fw_prepare;
	MT7636_ChipOp.fwdl_datapath_setup = mt7636_fwdl_datapath_setup;
}


VOID mt7636_init(RTMP_ADAPTER *pAd)
{
	RTMP_CHIP_CAP *pChipCap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);
	struct _RTMP_CHIP_DBG *chip_dbg = hc_get_chip_dbg(pAd->hdev_ctrl);

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
	mt7636_chipCap_init();
	mt7636_chipOp_init();
	memcpy(pChipCap, &MT7636_ChipCap, sizeof(RTMP_CHIP_CAP));
	memcpy(ops, &MT7636_ChipOp, sizeof(RTMP_CHIP_OP));
	pChipCap->hif_type = HIF_MT;
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
	Mt7636AsicArchOpsInit(pAd);
#endif
	mt7636_chip_dbg_init(chip_dbg);
	pChipCap->mac_type = MAC_MT;
#if defined(COMPOS_TESTMODE_WIN)
#else
	mt_phy_probe(pAd);
#endif
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(FW(%x), HW(%x), CHIPID(%x))\n",
			 __func__,
			 pAd->FWVersion,
			 pAd->HWVersion,
			 pAd->ChipID));
#ifdef RTMP_MAC_PCI

	if (IS_PCI_INF(pAd)) {
		pChipCap->tx_hw_hdr_len = pChipCap->TXWISize;
		pChipCap->rx_hw_hdr_len = pChipCap->RXWISize;
	}

#endif /* RTMP_MAC_PCI */
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd)) {
		pChipCap->tx_hw_hdr_len = pChipCap->TXWISize;
		pChipCap->rx_hw_hdr_len = pChipCap->RXWISize;
	}

#endif /* RTMP_MAC_USB */
#ifdef RTMP_MAC_SDIO

	if (IS_SDIO_INF(pAd)) {
		pChipCap->tx_hw_hdr_len = pChipCap->TXWISize;
		pChipCap->rx_hw_hdr_len = pChipCap->RXWISize;
	}

#endif /* RTMP_MAC_PCI */
#ifdef CONFIG_CSO_SUPPORT
	pChipCap->asic_caps |= fASIC_CAP_CSO;
#endif
#if !defined(COMPOS_TESTMODE_WIN)
	RTMP_DRS_ALG_INIT(pAd, RATE_ALG_GRP);
#endif
	/*
		Following function configure beacon related parameters
		in pChipCap
			FlgIsSupSpecBcnBuf / BcnMaxHwNum /
			WcidHwRsvNum / BcnMaxHwSize / BcnBase[]
	*/
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
	/* TODO: BJBJ */
#else
	mt_bcn_buf_init(pAd);
#endif
#ifdef DOT11W_PMF_SUPPORT
	pChipCap->FlgPMFEncrtptMode = PMF_ENCRYPT_MODE_2;
#endif /* DOT11W_PMF_SUPPORT */
	pChipCap->OmacNums = 5;
	pChipCap->BssNums = 4;
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("<--%s()\n", __func__));
}

