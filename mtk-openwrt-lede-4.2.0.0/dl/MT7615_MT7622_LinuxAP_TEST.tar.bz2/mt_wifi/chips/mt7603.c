/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	mt7603.c
*/


#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#ifdef COMPOS_WIN
#include "MtConfig.h"
#if defined(EVENT_TRACING)
#include "mt7603.tmh"
#endif
#endif
#ifdef COMPOS_TESTMODE_WIN
#include "Config.h"
#endif
#else
#include "rt_config.h"
#include "mcu/mt7603_firmware.h"
#include "mcu/mt7603_e2_firmware.h"
#include "eeprom/mt7603_e2p.h"
#include "phy/wf_phy_back.h"
#endif

UCHAR mt7603_ba_range[] = {4, 5, 8, 10, 16, 20, 21, 45};

/*define local variable*/
static RTMP_CHIP_CAP MT7603_ChipCap;
static RTMP_CHIP_OP MT7603_ChipOp;


static VOID mt7603_init_mac_cr(RTMP_ADAPTER *pAd)
{
#if defined(MT7603_FPGA) || defined(DOT11W_PMF_SUPPORT)
	UINT32 mac_val;
#endif
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
#ifdef MT7603_FPGA
	/* enable MAC2MAC mode */
	MAC_IO_READ32(pAd, RMAC_MISC, &mac_val);
	mac_val |= BIT18;
	MAC_IO_WRITE32(pAd, RMAC_MISC, mac_val);
#endif /* MT7603_FPGA */
	MtAsicSetTxSClassifyFilter(pAd, TXS2HOST, TXS2H_QID1, TXS2HOST_AGGNUMS, 0x00, 0);
	MtAsicSetTxSClassifyFilter(pAd, TXS2MCU, TXS2M_QID0, TXS2MCU_AGGNUMS, 0x00, 0);
#ifdef DOT11W_PMF_SUPPORT
	/* Enable BIP */
	MAC_IO_READ32(pAd, WTBL_OFF_BCR, &mac_val);
	mac_val |= BIP_EN;
	MAC_IO_WRITE32(pAd, WTBL_OFF_BCR, mac_val);
#endif /* DOT11W_PMF_SUPPORT */
}


#ifdef COMPOS_WIN
static VOID mt7603_bbp_adjust(RTMP_ADAPTER *pAd, UCHAR Channel)
{
}

static VOID
mt7603_switch_channel(
	PMP_ADAPTER pAd,
	MT_SWITCH_CHANNEL_CFG    CmdChSwitch
)
{
	INT32 iRet = 0x0;
	INT32 iLoop = 0x0;

	/* if switch channel fail, will retry 32time, prevent from channel send beacon is diffrent from channel in the IE channel information, lead to */
	/* client can't connect to AP normally */
	for (iLoop = 0x0; iLoop < SWITCH_CHANNEL_RETRY_COUNT; iLoop++) {
		if (MT_TEST_FLAG(pAd, fRTMP_ADAPTER_NIC_NOT_EXIST) ||
			MT_TEST_FLAG(pAd, fRTMP_ADAPTER_SURPRISE_REMOVED)) {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("mt7603_switch_channel success\n"));
			break;
		}

		iRet = MtCmdChannelSwitch(pAd, CmdChSwitch);

		if (iRet == TRUE) {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("mt7603_switch_channel success\n"));
			break;
		}

		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("mt7603_switch_channel fail, iRet is %d\n", iRet));
		NdisCommonGenericDelay(20000);/* delay 20ms */
	}
}

static void mt7603_antenna_default_reset(
	struct _RTMP_ADAPTER *pAd,
	EEPROM_ANTENNA_STRUC *pAntenna)
{
}

#ifdef CONFIG_STA_SUPPORT
static VOID mt7603_init_dev_nick_name(RTMP_ADAPTER *ad)
{
}
#endif /* CONFIG_STA_SUPPORT */

VOID ToneRadarProgram_v2(PRTMP_ADAPTER pAd, ULONG threshold)
{
}

void mtusb_cfg_read(RTMP_ADAPTER *ad, UINT32 *value)
{
}

void mtusb_cfg_write(RTMP_ADAPTER *ad, UINT32 value)
{
}

#ifdef CAL_FREE_IC_SUPPORT
static BOOLEAN mt7603_is_cal_free_ic(RTMP_ADAPTER *pAd)
{
}

static VOID mt7603_cal_free_data_get(RTMP_ADAPTER *ad)
{
}
#endif /* CAL_FREE_IC_SUPPORT */


static VOID mt7603_show_pwr_info(RTMP_ADAPTER *pAd)
{
}

static VOID mt7603_bufferModeEfuseFill(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd)
{
}
#elif defined(COMPOS_TESTMODE_WIN)
static VOID mt7603_bbp_adjust(struct _RTMP_ADAPTER *pAd, UCHAR Channel)
{
}

static VOID
mt7603_switch_channel(struct _RTMP_ADAPTER *pAd, MT_SWITCH_CHANNEL_CFG SwChCfg)
{
	struct _ATE_CTRL *AteCtrl = &pAd->ATECtrl;

	SwChCfg.Bw = AteCtrl->BW;
	SwChCfg.CentralChannel = AteCtrl->Channel;
	SwChCfg.TxStream = 0;
	SwChCfg.RxStream = 0;
	MtCmdChannelSwitch(pAd, SwChCfg);
}
static void mt7603_antenna_default_reset(
	struct _RTMP_ADAPTER *pAd,
	EEPROM_ANTENNA_STRUC *pAntenna)
{
}
static void ToneRadarProgram_v2(struct _RTMP_ADAPTER *pAd, ULONG threshold)
{
}

static void mtusb_cfg_read(struct _RTMP_ADAPTER *pAd, UINT32 *value)
{
}

static void mtusb_cfg_write(struct _RTMP_ADAPTER *pAd, UINT32 value)
{
}
static VOID mt7603_show_pwr_info(struct _RTMP_ADAPTER *pAd)
{
}

static VOID mt7603_bufferModeEfuseFill(struct _RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd)
{
}
#else
static VOID mt7603_bbp_adjust(RTMP_ADAPTER *pAd, UCHAR Channel)
{
	/*do nothing, change to use radio_resource control*/
	/*here should do bbp setting only, bbp is full-offload to fw*/
}

static void mt7603_switch_channel(RTMP_ADAPTER *pAd, MT_SWITCH_CHANNEL_CFG SwChCfg)
{
#ifdef RTMP_MAC_USB
	UINT32 ret = 0;

	if (IS_USB_INF(pAd)) {
		RTMP_SEM_EVENT_WAIT(&pAd->hw_atomic, ret);

		if (ret != 0) {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("reg_atomic get failed(ret=%d)\n", ret));
			return;
		}
	}

#endif /* RTMP_MAC_USB */
	/* tx pwr gain setting */
	/*offload to fimware*/
#if 0
	mt7603_tx_pwr_gain(pAd, channel);
#endif
	MtCmdChannelSwitch(pAd, SwChCfg);
	/* Channel latch */
	pAd->LatchRfRegs.Channel = SwChCfg.CentralChannel;
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd))
		RTMP_SEM_EVENT_UP(&pAd->hw_atomic);

#endif
}

static UINT8 mt7603_txpwr_chlist[] = {
	1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
};


int mt7603_read_chl_pwr(RTMP_ADAPTER *pAd)
{
	UINT32 i, choffset;
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = &chip_cap->MTTxPwrCap;

	mt7603_get_tx_pwr_info(pAd);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()--->\n", __func__));

	for (i = 0; i < sizeof(mt7603_txpwr_chlist); i++) {
		pAd->TxPower[i].Channel = mt7603_txpwr_chlist[i];
		pAd->TxPower[i].Power = TX_TARGET_PWR_DEFAULT_VALUE;
		pAd->TxPower[i].Power2 = TX_TARGET_PWR_DEFAULT_VALUE;
	}

	for (i = 0; i < 14; i++) {
		pAd->TxPower[i].Power = cap->tx_0_target_pwr_g_band;
		pAd->TxPower[i].Power2 = cap->tx_1_target_pwr_g_band;
	}

	choffset = 14;

	/* 4. Print and Debug*/
	for (i = 0; i < choffset; i++) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("E2PROM: TxPower[%03d], Channel=%d, Power[Tx0:%d, Tx1:%d]\n",
				 i, pAd->TxPower[i].Channel, pAd->TxPower[i].Power, pAd->TxPower[i].Power2));
	}

	return TRUE;
}


/* Read power per rate */
void mt7603_get_tx_pwr_per_rate(RTMP_ADAPTER *pAd)
{
	BOOLEAN is_empty = 0;
	UINT16 value = 0;
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = &chip_cap->MTTxPwrCap;
	/* G Band tx power for CCK 1M/2M, 5.5M/11M */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_CCK_1_2M, value);

	if (is_empty) {
		cap->tx_pwr_cck_1_2 = 0;
		cap->tx_pwr_cck_5_11 = 0;
	} else {
		/* CCK 1M/2M */
		if (value & TX_PWR_CCK_1_2M_EN) {
			if (value & TX_PWR_CCK_1_2M_SIGN)
				cap->tx_pwr_cck_1_2 = (value & TX_PWR_CCK_1_2M_MASK);
			else
				cap->tx_pwr_cck_1_2 = -(value & TX_PWR_CCK_1_2M_MASK);
		} else
			cap->tx_pwr_cck_1_2 = 0;

		/* CCK 5.5M/11M */
		if (value & TX_PWR_CCK_5_11M_EN) {
			if (value & TX_PWR_CCK_5_11M_SIGN)
				cap->tx_pwr_cck_5_11 = ((value & TX_PWR_CCK_5_11M_MASK) >> 8);
			else
				cap->tx_pwr_cck_5_11 = -((value & TX_PWR_CCK_5_11M_MASK) >> 8);
		} else
			cap->tx_pwr_cck_5_11 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_cck_1_2 = %d\n", cap->tx_pwr_cck_1_2));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_cck_5_11 = %d\n", cap->tx_pwr_cck_5_11));
	/* G Band tx power for OFDM 6M/9M, 12M/18M, 24M/36M, 48M/54M */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_6_9M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_6_9 = 0;
		cap->tx_pwr_g_band_ofdm_12_18 = 0;
	} else {
		/* OFDM 6M/9M */
		if (value & TX_PWR_G_BAND_OFDM_6_9M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_6_9M_SIGN)
				cap->tx_pwr_g_band_ofdm_6_9 = (value & TX_PWR_G_BAND_OFDM_6_9M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_6_9 = -(value & TX_PWR_G_BAND_OFDM_6_9M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_6_9 = 0;

		/* OFDM 12M/18M */
		if (value & TX_PWR_G_BAND_OFDM_12_18M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_12_18M_SIGN)
				cap->tx_pwr_g_band_ofdm_12_18 = ((value & TX_PWR_G_BAND_OFDM_12_18M_MASK) >> 8);
			else
				cap->tx_pwr_g_band_ofdm_12_18 = -((value & TX_PWR_G_BAND_OFDM_12_18M_MASK) >> 8);
		} else
			cap->tx_pwr_g_band_ofdm_12_18 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_6_9 = %d\n", cap->tx_pwr_g_band_ofdm_6_9));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_12_18 = %d\n", cap->tx_pwr_g_band_ofdm_12_18));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_24_36M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_24_36 = 0;
		cap->tx_pwr_g_band_ofdm_48 = 0;
	} else {
		/* OFDM 24M/36M */
		if (value & TX_PWR_G_BAND_OFDM_24_36M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_24_36M_SIGN)
				cap->tx_pwr_g_band_ofdm_24_36 = (value & TX_PWR_G_BAND_OFDM_24_36M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_24_36 = -(value & TX_PWR_G_BAND_OFDM_24_36M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_24_36 = 0;

		/* OFDM 48M */
		if (value & TX_PWR_G_BAND_OFDM_48M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_48M_SIGN)
				cap->tx_pwr_g_band_ofdm_48 = ((value & TX_PWR_G_BAND_OFDM_48M_MASK) >> 8);
			else
				cap->tx_pwr_g_band_ofdm_48 = -((value & TX_PWR_G_BAND_OFDM_48M_MASK) >> 8);
		} else
			cap->tx_pwr_g_band_ofdm_48 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_24_36 = %d\n", cap->tx_pwr_g_band_ofdm_24_36));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_48 = %d\n", cap->tx_pwr_g_band_ofdm_48));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_54M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_54 = 0;
		cap->tx_pwr_ht_bpsk_mcs_0_8 = 0;
	} else {
		/* OFDM 54M */
		if (value & TX_PWR_G_BAND_OFDM_54M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_54M_SIGN)
				cap->tx_pwr_g_band_ofdm_54 = (value & TX_PWR_G_BAND_OFDM_54M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_54 = -(value & TX_PWR_G_BAND_OFDM_54M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_54 = 0;

		/* HT MCS_0, MCS_8 */
		if (value & TX_PWR_HT_BPSK_MCS_0_8_EN) {
			if (value & TX_PWR_HT_BPSK_MCS_0_8_SIGN)
				cap->tx_pwr_ht_bpsk_mcs_0_8 = ((value & TX_PWR_HT_BPSK_MCS_0_8_MASK) >> 8);
			else
				cap->tx_pwr_ht_bpsk_mcs_0_8 = -((value & TX_PWR_HT_BPSK_MCS_0_8_MASK) >> 8);
		} else
			cap->tx_pwr_ht_bpsk_mcs_0_8 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_54 = %d\n", cap->tx_pwr_g_band_ofdm_54));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_bpsk_mcs_0_8 = %d\n", cap->tx_pwr_ht_bpsk_mcs_0_8));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_BPSK_MCS_32, value);

	if (is_empty) {
		cap->tx_pwr_ht_bpsk_mcs_32 = 0;
		cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = 0;
	} else {
		/* HT MCS_0, MCS_8 */
		if (value & TX_PWR_HT_BPSK_MCS_32_EN) {
			if (value & TX_PWR_HT_BPSK_MCS_32_SIGN)
				cap->tx_pwr_ht_bpsk_mcs_32 = (value & TX_PWR_HT_BPSK_MCS_32_MASK);
			else
				cap->tx_pwr_ht_bpsk_mcs_32 = -(value & TX_PWR_HT_BPSK_MCS_32_MASK);
		} else
			cap->tx_pwr_ht_bpsk_mcs_32 = 0;

		/* HT MCS_1, MCS_2, MCS_9, MCS_10 */
		if (value & TX_PWR_HT_QPSK_MCS_1_2_9_10_EN) {
			if (value & TX_PWR_HT_QPSK_MCS_1_2_9_10_SIGN)
				cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = ((value & TX_PWR_HT_QPSK_MCS_1_2_9_10_MASK) >> 8);
			else
				cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = -((value & TX_PWR_HT_QPSK_MCS_1_2_9_10_MASK) >> 8);
		} else
			cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_bpsk_mcs_32 = %d\n", cap->tx_pwr_ht_bpsk_mcs_32));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_qpsk_mcs_1_2_9_10 = %d\n", cap->tx_pwr_ht_qpsk_mcs_1_2_9_10));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_16QAM_MCS_3_4_11_12, value);

	if (is_empty) {
		cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = 0;
		cap->tx_pwr_ht_64qam_mcs_5_13 = 0;
	} else {
		/* HT MCS_3, MCS_4, MCS_11, MCS_12 */
		if (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_EN) {
			if (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_SIGN)
				cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_MASK);
			else
				cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = -(value & TX_PWR_HT_16QAM_MCS_3_4_11_12_MASK);
		} else
			cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = 0;

		/* HT MCS_5, MCS_13 */
		if (value & TX_PWR_HT_64QAM_MCS_5_13_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_5_13_SIGN)
				cap->tx_pwr_ht_64qam_mcs_5_13 = ((value & TX_PWR_HT_64QAM_MCS_5_13_MASK) >> 8);
			else
				cap->tx_pwr_ht_64qam_mcs_5_13 = -((value & TX_PWR_HT_64QAM_MCS_5_13_MASK) >> 8);
		} else
			cap->tx_pwr_ht_64qam_mcs_5_13 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_16qam_mcs_3_4_11_12 = %d\n", cap->tx_pwr_ht_16qam_mcs_3_4_11_12));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_5_13 = %d\n", cap->tx_pwr_ht_64qam_mcs_5_13));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_64QAM_MCS_6_14, value);

	if (is_empty) {
		cap->tx_pwr_ht_64qam_mcs_6_14 = 0;
		cap->tx_pwr_ht_64qam_mcs_7_15 = 0;
	} else {
		/* HT MCS_6, MCS_14 */
		if (value & TX_PWR_HT_64QAM_MCS_6_14_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_6_14_SIGN)
				cap->tx_pwr_ht_64qam_mcs_6_14 = (value & TX_PWR_HT_64QAM_MCS_6_14_MASK);
			else
				cap->tx_pwr_ht_64qam_mcs_6_14 = -(value & TX_PWR_HT_64QAM_MCS_6_14_MASK);
		} else
			cap->tx_pwr_ht_64qam_mcs_6_14 = 0;

		/* HT MCS_7, MCS_15 */
		if (value & TX_PWR_HT_64QAM_MCS_7_15_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_7_15_SIGN)
				cap->tx_pwr_ht_64qam_mcs_7_15 = ((value & TX_PWR_HT_64QAM_MCS_7_15_MASK) >> 8);
			else
				cap->tx_pwr_ht_64qam_mcs_7_15 = -((value & TX_PWR_HT_64QAM_MCS_7_15_MASK) >> 8);
		} else
			cap->tx_pwr_ht_64qam_mcs_7_15 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_6_14 = %d\n", cap->tx_pwr_ht_64qam_mcs_6_14));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_7_15 = %d\n", cap->tx_pwr_ht_64qam_mcs_7_15));
}


void mt7603_get_tx_pwr_info(RTMP_ADAPTER *pAd)
{
	bool is_empty = 0;
	UINT16 value = 0;
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = chip_cap->MTTxPwrCap;
	/* Read 20/40 BW delta */
	is_empty = RT28xx_EEPROM_READ16(pAd, G_BAND_20_40_BW_PWR_DELTA, value);

	if (is_empty)
		cap->delta_tx_pwr_bw40_g_band = 0x0;
	else {
		/* G Band */
		if (value & G_BAND_20_40_BW_PWR_DELTA_EN) {
			if (value & G_BAND_20_40_BW_PWR_DELTA_SIGN) {
				/* bit[0..5] tx power delta value */
				cap->delta_tx_pwr_bw40_g_band = (value & G_BAND_20_40_BW_PWR_DELTA_MASK);
			} else
				cap->delta_tx_pwr_bw40_g_band = -(value & G_BAND_20_40_BW_PWR_DELTA_MASK);
		} else
			cap->delta_tx_pwr_bw40_g_band = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("delta_tx_pwr_bw40_g_band = %d\n", cap->delta_tx_pwr_bw40_g_band));
	/* ///////////////// Tx0 ////////////////////////// */
	/* Read TSSI slope/offset for TSSI compensation */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_TSSI_SLOPE, value);
	cap->tssi_0_slope_g_band =
		(is_empty) ? TSSI_0_SLOPE_G_BAND_DEFAULT_VALUE : (value & TX0_G_BAND_TSSI_SLOPE_MASK);
	cap->tssi_0_offset_g_band =
		(is_empty) ? TSSI_0_OFFSET_G_BAND_DEFAULT_VALUE : ((value & TX0_G_BAND_TSSI_OFFSET_MASK) >> 8);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_slope_g_band = %d\n", cap->tssi_0_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_offset_g_band = %d\n", cap->tssi_0_offset_g_band));
	/* Read 54M target power */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_TARGET_PWR, value);
	cap->tx_0_target_pwr_g_band =
		(is_empty) ? TX_TARGET_PWR_DEFAULT_VALUE : (value & TX0_G_BAND_TARGET_PWR_MASK);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_target_pwr_g_band = %d\n", cap->tx_0_target_pwr_g_band));

	/* Read power offset (channel delta) */
	if (is_empty)
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x0;
	else {
		/* tx power offset LOW */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_LOW_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_LOW_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = ((value & TX0_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = -((value & TX0_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW]));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_CHL_PWR_DELTA_MID, value);

	if (is_empty) {
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x0;
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x0;
	} else {
		/* tx power offset MID */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_MID_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_MID_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = (value & TX0_G_BAND_CHL_PWR_DELTA_MID_MASK);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = -(value & TX0_G_BAND_CHL_PWR_DELTA_MID_MASK);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x0;

		/* tx power offset HIGH */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_HI_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_HI_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = ((value & TX0_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = -((value & TX0_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_MID] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_HI] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI]));
	/* ///////////////// Tx1 ////////////////////////// */
	/* Read TSSI slope/offset for TSSI compensation */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_TSSI_SLOPE, value);
	cap->tssi_1_slope_g_band = (is_empty) ? TSSI_1_SLOPE_G_BAND_DEFAULT_VALUE : (value & TX1_G_BAND_TSSI_SLOPE_MASK);
	cap->tssi_1_offset_g_band = (is_empty) ? TSSI_1_OFFSET_G_BAND_DEFAULT_VALUE : ((value & TX1_G_BAND_TSSI_OFFSET_MASK) >> 8);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_1_slope_g_band = %d\n", cap->tssi_1_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_1_offset_g_band = %d\n", cap->tssi_1_offset_g_band));
	/* Read 54M target power */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_TARGET_PWR, value);
	cap->tx_1_target_pwr_g_band = (is_empty) ? TX_TARGET_PWR_DEFAULT_VALUE : (value & TX1_G_BAND_TARGET_PWR_MASK);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_target_pwr_g_band = %d\n", cap->tx_1_target_pwr_g_band));

	/* Read power offset (channel delta) */
	if (is_empty)
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] =  0;
	else {
		/* tx power offset LOW */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_LOW_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_LOW_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = ((value & TX1_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = -((value & TX1_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW]));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_CHL_PWR_DELTA_MID, value);

	if (is_empty) {
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0;
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0;
	} else {
		/* tx power offset MID */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_MID_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_MID_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = (value & TX1_G_BAND_CHL_PWR_DELTA_MID_MASK);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = -(value & TX1_G_BAND_CHL_PWR_DELTA_MID_MASK);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0;

		/* tx power offset HIGH */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_HI_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_HI_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = ((value & TX1_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = -((value & TX1_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_MID] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_HI] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI]));
}


static VOID mt7603_show_pwr_info(RTMP_ADAPTER *pAd)
{
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = chip_cap->MTTxPwrCap;
	UINT32 value;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel info related to power\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));

	if (pAd->LatchRfRegs.Channel < 14) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("central channel = %d, low_mid_hi = %d\n", pAd->LatchRfRegs.Channel,
				 get_low_mid_hi_index(pAd->LatchRfRegs.Channel)));
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel power(unit: 0.5dbm)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_target_pwr_g_band = 0x%x\n", cap->tx_0_target_pwr_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_target_pwr_g_band = 0x%x\n", cap->tx_1_target_pwr_g_band));
	/* channel power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel power delta(unit: 0.5db)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI]));
	/* bw power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("bw power delta(unit: 0.5db)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("delta_tx_pwr_bw40_g_band = %d\n", cap->delta_tx_pwr_bw40_g_band));
	/* per-rate power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("per-rate power delta\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_cck_1_2 = %d\n", cap->tx_pwr_cck_1_2));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_cck_5_11 = %d\n", cap->tx_pwr_cck_5_11));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_6_9 = %d\n", cap->tx_pwr_g_band_ofdm_6_9));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_12_18 = %d\n", cap->tx_pwr_g_band_ofdm_12_18));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_24_36 = %d\n", cap->tx_pwr_g_band_ofdm_24_36));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_48 = %d\n", cap->tx_pwr_g_band_ofdm_48));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_54 = %d\n", cap->tx_pwr_g_band_ofdm_54));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_bpsk_mcs_32 = %d\n", cap->tx_pwr_ht_bpsk_mcs_32));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_bpsk_mcs_0_8 = %d\n", cap->tx_pwr_ht_bpsk_mcs_0_8));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_qpsk_mcs_1_2_9_10 = %d\n", cap->tx_pwr_ht_qpsk_mcs_1_2_9_10));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_16qam_mcs_3_4_11_12 = %d\n", cap->tx_pwr_ht_16qam_mcs_3_4_11_12));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_5_13 = %d\n", cap->tx_pwr_ht_64qam_mcs_5_13));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_6_14 = %d\n", cap->tx_pwr_ht_64qam_mcs_6_14));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_7_15 = %d\n", cap->tx_pwr_ht_64qam_mcs_7_15));
	/* TMAC POWER INFO */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("per-rate power delta in MAC 0x60130020 ~ 0x60130030\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	RTMP_IO_READ32(pAd, TMAC_FP0R0, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R0 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R1, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R1 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R2, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R2 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R3, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R3 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R4, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R4 = 0x%x\n", value));
	/* TSSI info */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TSSI info\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TSSI enable = %d\n", chip_cap->tssi_enable));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_0_slope_g_band = 0x%x\n", cap->tssi_0_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_slope_g_band = 0x%x\n", cap->tssi_1_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_0_offset_g_band = 0x%x\n", cap->tssi_0_offset_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_offset_g_band = 0x%x\n", cap->tssi_1_offset_g_band));
}


#ifdef CAL_FREE_IC_SUPPORT
static BOOLEAN mt7603_is_cal_free_ic(RTMP_ADAPTER *pAd)
{
	UINT16 Value = 0;
	BOOLEAN NotValid;

	NotValid = rtmp_ee_efuse_read16(pAd, 0x54, &Value);

	if (NotValid)
		return FALSE;

	if (((Value >> 8) & 0xff) == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0x56, &Value);

	if (NotValid)
		return FALSE;

	if (Value == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0x5c, &Value);

	if (NotValid)
		return FALSE;

	if (Value == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0xf0, &Value);

	if (NotValid)
		return FALSE;

	if ((Value & 0xff) == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0xf4, &Value);

	if (NotValid)
		return FALSE;

	if ((Value & 0xff) == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0xf6, &Value);

	if (NotValid)
		return FALSE;

	if (((Value >> 8) & 0xff) == 0x00)
		return FALSE;

	return TRUE;
}



static VOID mt7603_cal_free_data_get(RTMP_ADAPTER *ad)

{
	UINT16 value;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s\n", __func__));
	/* 0x55 0x56 0x57 0x5C 0x5D */
	eFuseReadRegisters(ad, A_BAND_EXT_PA_SETTING, 2, &value);
	/*0x55*/
	ad->EEPROMImage[A_BAND_EXT_PA_SETTING + 1] = (value >> 8) & 0xFF;
	eFuseReadRegisters(ad, TX0_G_BAND_TSSI_SLOPE, 2, &value);
	/*0x56,0x57*/
	*(UINT16 *)(&ad->EEPROMImage[TX0_G_BAND_TSSI_SLOPE]) = le2cpu16(value);
	eFuseReadRegisters(ad, TX1_G_BAND_TSSI_SLOPE, 2, &value);
	/*0x5c,0x5d*/
	*(UINT16 *)(&ad->EEPROMImage[TX1_G_BAND_TSSI_SLOPE]) = le2cpu16(value);
	eFuseReadRegisters(ad, TX1_G_BAND_TARGET_PWR, 2, &value);
	/* 0xF0 0xF4 0xF7  */
	eFuseReadRegisters(ad, CP_FT_VERSION, 2, &value);
	ad->EEPROMImage[CP_FT_VERSION] = value & 0xFF;
	eFuseReadRegisters(ad, XTAL_CALIB_FREQ_OFFSET, 2, &value);
	ad->EEPROMImage[XTAL_CALIB_FREQ_OFFSET]  = value & 0xFF;
	eFuseReadRegisters(ad, XTAL_TRIM_3_COMP, 2, &value);
	ad->EEPROMImage[XTAL_TRIM_3_COMP + 1] = (value >> 8) & 0xFF;
}


#endif /* CAL_FREE_IC_SUPPORT */





static void mt7603_antenna_default_reset(
	struct _RTMP_ADAPTER *pAd,
	EEPROM_ANTENNA_STRUC *pAntenna)
{
	pAntenna->word = 0;
	pAd->RfIcType = RFIC_7603;
	pAntenna->field.TxPath = 2;
	pAntenna->field.RxPath = 2;
}


#ifdef CONFIG_STA_SUPPORT
static VOID mt7603_init_dev_nick_name(RTMP_ADAPTER *ad)
{
#ifdef RTMP_MAC_PCI

	if (IS_MT7603(ad))
		snprintf((RTMP_STRING *) ad->nickname, sizeof(ad->nickname), "mt7603e_sta");

#endif
#ifdef RTMP_MAC_USB

	if (IS_MT7603(ad))
		snprintf((RTMP_STRING *) ad->nickname, sizeof(ad->nickname), "mt7603u_sta");

#endif
}
#endif /* CONFIG_STA_SUPPORT */


static inline VOID bufferModeFieldSet(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd, UINT16 addr)
{
	UINT32 i = pCmd->ucCount;

	pCmd->BinContent[i].u2Addr = cpu2le16(addr);
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[addr];
	pCmd->ucCount++;
}


static VOID mt7603_bufferModeEfuseFill(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd)
{
	int i = 0;

	pCmd->BinContent[i].u2Addr = NIC_CONFIGURE_0_TOP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[NIC_CONFIGURE_0_TOP];
	i++;
	pCmd->BinContent[i].u2Addr = NIC_CONFIGURE_1;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[NIC_CONFIGURE_1];
	i++;
	pCmd->BinContent[i].u2Addr = NIC_CONFIGURE_1_TOP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[NIC_CONFIGURE_1_TOP];
	i++;
	pCmd->BinContent[i].u2Addr = WIFI_RF_SETTING;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[WIFI_RF_SETTING];
	i++;
	pCmd->BinContent[i].u2Addr = G_BAND_20_40_BW_PWR_DELTA;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[G_BAND_20_40_BW_PWR_DELTA];
	i++;
	pCmd->BinContent[i].u2Addr = A_BAND_20_80_BW_PWR_DELTA_ANALOG;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[A_BAND_20_80_BW_PWR_DELTA_ANALOG];
	i++;
	pCmd->BinContent[i].u2Addr = A_BAND_EXT_PA_SETTING;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[A_BAND_EXT_PA_SETTING];
	i++;
	pCmd->BinContent[i].u2Addr = TEMP_SENSOR_CAL;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TEMP_SENSOR_CAL];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_TSSI_SLOPE;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_TSSI_SLOPE];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_TSSI_SLOPE_TOP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_TSSI_SLOPE_TOP];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_TARGET_PWR;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_TARGET_PWR];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_OFFSET_LOW;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_OFFSET_LOW];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_CHL_PWR_DELTA_MID;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_CHL_PWR_DELTA_MID];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_OFFSET_HIGH;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_OFFSET_HIGH];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_TSSI_SLOPE;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_TSSI_SLOPE];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_TSSI_SLOPE_TOP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_TSSI_SLOPE_TOP];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_TARGET_PWR;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_TARGET_PWR];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_CHL_PWR_DELATE_LOW;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_CHL_PWR_DELATE_LOW];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_CHL_PWR_DELTA_MID;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_CHL_PWR_DELTA_MID];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_CHL_PWR_DELTA_HIGH;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_CHL_PWR_DELTA_HIGH];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_CCK_1_2M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_CCK_1_2M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_CCK_5_11M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_CCK_5_11M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_G_BAND_OFDM_6_9M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_G_BAND_OFDM_6_9M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_OFDM_12_18M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_OFDM_12_18M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_G_BAND_OFDM_24_36M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_G_BAND_OFDM_24_36M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_G_BNAD_OFDM_48;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_G_BNAD_OFDM_48];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_G_BAND_OFDM_54M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_G_BAND_OFDM_54M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_BPSK_MCS_0_8;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_BPSK_MCS_0_8];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_BPSK_MCS_32;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_BPSK_MCS_32];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_QPSK_MCS_1_2_9_10;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_QPSK_MCS_1_2_9_10];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_16QAM_MCS_3_4_11_12;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_16QAM_MCS_3_4_11_12];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_64QAM_MCS_5_13;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_64QAM_MCS_5_13];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_64QAM_MCS_6_14;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_64QAM_MCS_6_14];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_64QAM_MCS_7_15;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_64QAM_MCS_7_15];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_RX_MODE_GAIN;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_RX_MODE_GAIN];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_RX_MODE_NF;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_RX_MODE_NF];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_RX_MODE_P1DB;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_RX_MODE_P1DB];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_BYPASS_MODE_GAIN;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_BYPASS_MODE_GAIN];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_BYPASS_MODE_NF;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_BYPASS_MODE_NF];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_BYPASS_MODE_P1DB;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_BYPASS_MODE_P1DB];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_7;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_7];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_6;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_6];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_5;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_5];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_4;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_4];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_3;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_3];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_2;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_2];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_1;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_1];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_0;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_0];
	i++;
	pCmd->BinContent[i].u2Addr = REF_STEP_24G;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[REF_STEP_24G];
	i++;
	pCmd->BinContent[i].u2Addr = REF_TEMP_24G;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[REF_TEMP_24G];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_1;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_1];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_2;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_2];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_3;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_3];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_4;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_4];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_5;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_5];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_6;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_6];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_7;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_7];
	i++;
	pCmd->BinContent[i].u2Addr = XTAL_CALIB_FREQ_OFFSET;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[XTAL_CALIB_FREQ_OFFSET];
	i++;
	pCmd->BinContent[i].u2Addr = XTAL_TRIM_2_COMP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[XTAL_TRIM_2_COMP];
	i++;
	pCmd->BinContent[i].u2Addr = XTAL_TRIM_3_COMP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[XTAL_TRIM_3_COMP];
	i++;
	pCmd->BinContent[i].u2Addr = WF_RCAL;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[WF_RCAL];
	i++;
	pCmd->ucCount = i;

	for (i = 0; i < pCmd->ucCount; i++)
		pCmd->BinContent[i].u2Addr = cpu2le16(pCmd->BinContent[i].u2Addr);

	/*extend for function requset, need backward compatible*/
	bufferModeFieldSet(pAd, pCmd, 0x24);
	bufferModeFieldSet(pAd, pCmd, 0x25);
	bufferModeFieldSet(pAd, pCmd, 0x34);
	bufferModeFieldSet(pAd, pCmd, 0x39);
	bufferModeFieldSet(pAd, pCmd, 0x3b);
	bufferModeFieldSet(pAd, pCmd, 0x42);
	bufferModeFieldSet(pAd, pCmd, 0x43);
	bufferModeFieldSet(pAd, pCmd, 0x9e);
	bufferModeFieldSet(pAd, pCmd, 0x9f);
	bufferModeFieldSet(pAd, pCmd, 0xf2);
	bufferModeFieldSet(pAd, pCmd, 0xf8);
	bufferModeFieldSet(pAd, pCmd, 0xf9);
	bufferModeFieldSet(pAd, pCmd, 0xfa);
	bufferModeFieldSet(pAd, pCmd, 0x12e);

	for (i = 0; i <= 0xf; i++)
		bufferModeFieldSet(pAd, pCmd, 0x130 + i);

	/*need minus 1 for add one more time*/
	pCmd->ucCount--;
}

#endif

#define MBSSID_MODE0	0
#define MBSSID_MODE1	1	/* Enhance NEW MBSSID MODE mapping to mode 0 */
#ifdef ENHANCE_NEW_MBSSID_MODE
#define MBSSID_MODE2	2	/* Enhance NEW MBSSID MODE mapping to mode 1 */
#define MBSSID_MODE3	3	/* Enhance NEW MBSSID MODE mapping to mode 2 */
#define MBSSID_MODE4	4	/* Enhance NEW MBSSID MODE mapping to mode 3 */
#define MBSSID_MODE5	5	/* Enhance NEW MBSSID MODE mapping to mode 4 */
#define MBSSID_MODE6	6	/* Enhance NEW MBSSID MODE mapping to mode 5 */
#endif /* ENHANCE_NEW_MBSSID_MODE */


static void  mt7603_fw_prepare(RTMP_ADAPTER *pAd)
{
	struct fwdl_ctrl *ctrl = &pAd->MCUCtrl.fwdl_ctrl;

#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else

	if ((pAd->FWVersion & 0x0000ffff) == 0x8A00) {
		ctrl->fw_profile[WM_CPU].source.header_ptr = MT7603_FirmwareImage;
		ctrl->fw_profile[WM_CPU].source.header_len = sizeof(MT7603_FirmwareImage);
		ctrl->fw_profile[WM_CPU].source.bin_name = "mtk/WIFI_RAM_CODE_MT7603_e1.bin";
	} else if ((pAd->FWVersion & 0x0000ffff) == 0x8A10) {
		ctrl->fw_profile[WM_CPU].source.header_ptr = MT7603_e2_FirmwareImage;
		ctrl->fw_profile[WM_CPU].source.header_len = sizeof(MT7603_e2_FirmwareImage);
		ctrl->fw_profile[WM_CPU].source.bin_name = "mtk/WIFI_RAM_CODE_MT7603_e2.bin";
	} else {
		ctrl->fw_profile[WM_CPU].source.header_ptr = MT7603_e2_FirmwareImage;
		ctrl->fw_profile[WM_CPU].source.header_len = sizeof(MT7603_e2_FirmwareImage);
		ctrl->fw_profile[WM_CPU].source.bin_name = "mtk/WIFI_RAM_CODE_MT7603_e2.bin";
	}

#endif
}

static VOID mt7603_fwdl_datapath_setup(RTMP_ADAPTER *pAd, BOOLEAN init)
{
#ifdef DMA_SCH_SUPPORT
	MtAsicSetDmaByPassMode(pAd, init);
#endif /* DMA_SCH_SUPPORT */
}

static VOID mt7603_chipCap_init(VOID)
{
	os_zero_mem(&MT7603_ChipCap, sizeof(RTMP_CHIP_CAP));
	MT7603_ChipCap.max_nss = 2;
	MT7603_ChipCap.TXWISize = sizeof(TMAC_TXD_L); /* 32 */
	MT7603_ChipCap.RXWISize = 28;
	MT7603_ChipCap.WtblHwNum = MT7603_MT_WTBL_SIZE;
	MT7603_ChipCap.WtblPseAddr = MT7603_PSE_WTBL_2_ADDR;
#ifdef RTMP_MAC_PCI
	MT7603_ChipCap.WPDMABurstSIZE = 3;
#endif
	MT7603_ChipCap.SnrFormula = SNR_FORMULA4;
	MT7603_ChipCap.FlgIsHwWapiSup = TRUE;
	MT7603_ChipCap.FlgIsHwAntennaDiversitySup = FALSE;
#ifdef STREAM_MODE_SUPPORT
	MT7603_ChipCap.FlgHwStreamMode = FALSE;
#endif
	MT7603_ChipCap.asic_caps = (fASIC_CAP_PMF_ENC | fASIC_CAP_MCS_LUT | fASIC_CAP_RDG;);
	MT7603_ChipCap.phy_caps = (fPHY_CAP_24G | fPHY_CAP_HT);
	MT7603_ChipCap.MaxNumOfRfId = MAX_RF_ID;
	MT7603_ChipCap.pRFRegTable = NULL;
	MT7603_ChipCap.MaxNumOfBbpId = 200;
	MT7603_ChipCap.pBBPRegTable = NULL;
	MT7603_ChipCap.bbpRegTbSize = 0;
#ifdef NEW_MBSSID_MODE
#ifdef ENHANCE_NEW_MBSSID_MODE
	MT7603_ChipCap.MBSSIDMode = MBSSID_MODE4;
#else
	MT7603_ChipCap.MBSSIDMode = MBSSID_MODE1;
#endif /* ENHANCE_NEW_MBSSID_MODE */
#else
	MT7603_ChipCap.MBSSIDMode = (ULONG) MBSSID_MODE0;
#endif /* NEW_MBSSID_MODE */
#ifdef RTMP_EFUSE_SUPPORT
	MT7603_ChipCap.EFUSE_USAGE_MAP_START = 0x1e0;
	MT7603_ChipCap.EFUSE_USAGE_MAP_END = 0x1fc;
	MT7603_ChipCap.EFUSE_USAGE_MAP_SIZE = 29;
	MT7603_ChipCap.EFUSE_RESERVED_SIZE = 22;	/* Cal-Free is 22 free block */
#endif
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
	MT7603_ChipCap.EEPROM_DEFAULT_BIN = MT7603_E2PImage;
	MT7603_ChipCap.EEPROM_DEFAULT_BIN_SIZE = sizeof(MT7603_E2PImage);
#endif
	MT7603_ChipCap.EFUSE_BUFFER_CONTENT_SIZE = 0x5b;
#ifdef CONFIG_ANDES_SUPPORT
	MT7603_ChipCap.need_load_patch = 0;
	MT7603_ChipCap.need_load_fw = BIT(WM_CPU);
	MT7603_ChipCap.load_patch_flow = PATCH_FLOW_V1;
	MT7603_ChipCap.load_fw_flow = FW_FLOW_V1;
	MT7603_ChipCap.patch_format = PATCH_FORMAT_V1;
	MT7603_ChipCap.fw_format = FW_FORMAT_V1;
	MT7603_ChipCap.load_patch_method = BIT(HEADER_METHOD);
	MT7603_ChipCap.load_fw_method = BIT(HEADER_METHOD);
#endif
	MT7603_ChipCap.MCUType = ANDES;
	MT7603_ChipCap.cmd_header_len = ROM_CODE_CMD_HEADER_LEN;
#ifdef RTMP_PCI_SUPPORT
	MT7603_ChipCap.cmd_padding_len = 0;
#endif
#ifdef RTMP_USB_SUPPORT
	MT7603_ChipCap.cmd_padding_len = 4;
	MT7603_ChipCap.CommandBulkOutAddr = 0x8;
	MT7603_ChipCap.WMM0ACBulkOutAddr[0] = 0x5;
	MT7603_ChipCap.WMM0ACBulkOutAddr[1] = 0x4;
	MT7603_ChipCap.WMM0ACBulkOutAddr[2] = 0x6;
	MT7603_ChipCap.WMM0ACBulkOutAddr[3] = 0x7;
	MT7603_ChipCap.WMM1ACBulkOutAddr = 0x9;
	MT7603_ChipCap.DataBulkInAddr = 0x84;
	MT7603_ChipCap.CommandRspBulkInAddr = 0x85;
#endif
#ifdef CARRIER_DETECTION_SUPPORT
	MT7603_ChipCap.carrier_func = TONE_RADAR_V2;
#endif
	MT7603_ChipCap.hw_ops_ver = HWCTRL_OP_TYPE_V1;
	MT7603_ChipCap.hif_type = HIF_MT;
	MT7603_ChipCap.rf_type = RF_MT;
	MT7603_ChipCap.TxAggLimit = 21;
#ifdef RTMP_PCI_SUPPORT
	MT7603_ChipCap.RxBAWinSize = 21;
#endif
#ifdef RTMP_USB_SUPPORT
	MT7603_ChipCap.UsbAggBufSize = 0x6000; /* 24KB */
	MT7603_ChipCap.RxBAWinSize = 21;
#endif
	MT7603_ChipCap.ht_max_ampdu_len_exp = 2;
	MT7603_ChipCap.TxOPScenario = 0x0;
	MT7603_ChipCap.CurrentTxOP = 0x0;
	MT7603_ChipCap.default_txop = 0x60;
	/*for multi-wmm*/
	MT7603_ChipCap.WmmHwNum = MT7603_MT_WMM_SIZE;
	/* PDA PORT address */
	MT7603_ChipCap.PDA_PORT = MT7603_PDA_PORT;
	MT7603_ChipCap.qm = GENERIC_QM;
	MT7603_ChipCap.tm = TASKLET_METHOD;
	MT7603_ChipCap.wmm_detect_method = WMM_DETECT_METHOD1;
	/* for interrupt enable mask */
	MT7603_ChipCap.int_enable_mask = ((MT_DELAYINTMASK) | (MT_RxINT | MT_INT_T0_DONE | MT_INT_T1_DONE | 
						MT_INT_T2_DONE | MT_INT_T3_DONE | MT_TxMgmtInt) | MT_INT_BMC_DLY);
#if (CFG_CPU_LOADING_RXRING_DLY == 1)
	MT7603_ChipCap.int_enable_mask &= ~(MT_INT_RX_DATA | MT_INT_RX_CMD);
	MT7603_ChipCap.int_enable_mask |= MT_INT_RX_DLY;
#endif
#if (CFG_CPU_LOADING_DISABLE_TXDONE0 == 1)
	MT7603_ChipCap.int_enable_mask &= ~MT_INT_AC0_DLY;
#endif
	MT7603_ChipCap.ba_range = mt7603_ba_range;
}


static VOID mt7603_chipOp_init(VOID)
{
	MT7603_ChipOp.ChipBBPAdjust = mt7603_bbp_adjust;
	MT7603_ChipOp.ChipSwitchChannel = mt7603_switch_channel;
	MT7603_ChipOp.AsicMacInit = mt7603_init_mac_cr;
	MT7603_ChipOp.AsicAntennaDefaultReset = mt7603_antenna_default_reset;
	MT7603_ChipOp.ChipAGCInit = NULL;
#ifdef CONFIG_STA_SUPPORT
	MT7603_ChipOp.ChipAGCAdjust = NULL;
#endif
	MT7603_ChipOp.AsicRfTurnOn = NULL;
	MT7603_ChipOp.AsicHaltAction = NULL;
	MT7603_ChipOp.AsicRfTurnOff = NULL;
	MT7603_ChipOp.AsicReverseRfFromSleepMode = NULL;
#ifdef CONFIG_STA_SUPPORT
	MT7603_ChipOp.NetDevNickNameInit = mt7603_init_dev_nick_name;
#endif
#ifdef CARRIER_DETECTION_SUPPORT
	MT7603_ChipOp.ToneRadarProgram = ToneRadarProgram_v2;
#endif
	MT7603_ChipOp.RxSensitivityTuning = NULL;
	MT7603_ChipOp.DisableTxRx = NULL;
#ifdef RTMP_USB_SUPPORT
	MT7603_ChipOp.AsicRadioOn = NULL;
	MT7603_ChipOp.AsicRadioOff = NULL;
	MT7603_ChipOp.usb_cfg_read = mtusb_cfg_read;
	MT7603_ChipOp.usb_cfg_write = mtusb_cfg_write;
#endif
#ifdef RTMP_PCI_SUPPORT
	/* .AsicRadioOn = RT28xxPciAsicRadioOn, */
	/* .AsicRadioOff = RT28xxPciAsicRadioOff, */
#endif
#ifdef CAL_FREE_IC_SUPPORT
	MT7603_ChipOp.is_cal_free_ic = mt7603_is_cal_free_ic;
	MT7603_ChipOp.cal_free_data_get = mt7603_cal_free_data_get;
#endif /* CAL_FREE_IC_SUPPORT */
	MT7603_ChipOp.show_pwr_info = mt7603_show_pwr_info;
	MT7603_ChipOp.bufferModeEfuseFill = mt7603_bufferModeEfuseFill;
#ifdef MT_WOW_SUPPORT
	MT7603_ChipOp.AsicWOWEnable = MT76xxAndesWOWEnable;
	MT7603_ChipOp.AsicWOWDisable = MT76xxAndesWOWDisable;
	/* MT7603_ChipOp.AsicWOWInit = MT76xxAndesWOWInit, */
#endif /* MT_WOW_SUPPORT */
	MT7603_ChipOp.MtCmdTx = MtCmdSendMsg;
	MT7603_ChipOp.prepare_fwdl_img = mt7603_fw_prepare;
	MT7603_ChipOp.fwdl_datapath_setup = mt7603_fwdl_datapath_setup;
}

#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
static INT Mt7603AsicArchOpsInit(RTMP_ADAPTER *pAd)
{
	RTMP_ARCH_OP *arch_ops = &pAd->archOps;

	arch_ops->archSetDevMac = MtAsicSetDevMacByDriver;
	arch_ops->archSetBssid = MtAsicSetBssidByDriver;
	arch_ops->archSetStaRec = NULL;
	arch_ops->archDisableBeacon = MtSmacAsicDisableBeacon;
	arch_ops->archEnableBeacon = MtSmacAsicEnableBeacon;
	arch_ops->archUpdateBeacon = MtUpdateBeaconToAsic;
#ifdef CONFIG_AP_SUPPORT
	arch_ops->archSetMbssWdevIfAddr = MtAsicSetMbssWdevIfAddrGen1;
	arch_ops->archSetMbssHwCRSetting = MtSmacSetMbssHwCRSetting;
	arch_ops->archSetExtTTTTHwCRSetting = MtSmacSetExtTTTTHwCRSetting;
	arch_ops->archSetExtMbssEnableCR = MtSmacSetExtMbssEnableCR;
#endif /* CONFIG_AP_SUPPORT */
	arch_ops->archGetTsfTime = MtAsicGetTsfTimeByDriver;
	arch_ops->archSetPreTbtt = MtAsicSetPreTbtt;
	arch_ops->archDisableSync = MtAsicDisableSyncByDriver;
	arch_ops->archSetSyncModeAndEnable = MtAsicEnableBssSyncByDriver;
#ifdef CONFIG_STA_SUPPORT
	arch_ops->archEnableIbssSync = MtAsicEnableBssSyncByDriver;
#endif
#ifdef CONFIG_AP_SUPPORT
	arch_ops->archGetTxTsc = MtAsicGetTxTscByDriver;
#endif /* CONFIG_AP_SUPPORT */
	arch_ops->archDelWcidTab = MtAsicDelWcidTabByDriver;
	arch_ops->archAddRemoveKeyTab = MtAsicAddRemoveKeyByDriver;
	arch_ops->archUpdateRxWCIDTable = MtAsicUpdateRxWCIDTableByDriver;
	arch_ops->archUpdateBASession = MtAsicUpdateBASessionByDriver;
	arch_ops->archSetSMPS = MtAsicSetSMPSByDriver;
#ifdef MT_PS
	arch_ops->archSetIgnorePsm = MtSetIgnorePsmByDriver;
#endif
	arch_ops->archSetMacTxRx = MtAsicSetMacTxRx;
	arch_ops->archSetMacMaxLen = MtAsicSetMacMaxLen;
	arch_ops->archSetTxStream = MtAsicSetTxStream;
	arch_ops->archSetRxStream = MtAsicSetRxStream;
	arch_ops->archSetRxFilter = MtAsicSetRxFilter;
#ifdef IGMP_SNOOP_SUPPORT
	arch_ops->archMcastEntryInsert = MulticastFilterTableInsertEntry;
	arch_ops->archMcastEntryDelete = MulticastFilterTableDeleteEntry;
#endif
	arch_ops->write_tmac_info_fixed_rate = mt_write_tmac_info_fixed_rate;
	arch_ops->write_tmac_info = mt_write_tmac_info;
	arch_ops->hw_tx = mt_hw_tx;
	arch_ops->mlme_hw_tx = mt_mlme_hw_tx;
	arch_ops->rx_done_handle = rtmp_rx_done_handle;
#ifdef RTMP_PCI_SUPPORT

	if (IS_PCIE_INF(pAd)) {
		arch_ops->write_tx_resource = mt_pci_write_tx_resource;
		arch_ops->write_multi_tx_resource = mt_pci_write_multi_tx_resource;
		arch_ops->write_final_tx_resource = mt_pci_write_final_tx_resource;
		arch_ops->write_frag_tx_resource = mt_pci_write_frag_tx_resource;
		arch_ops->kickout_data_tx = pci_kickout_data_tx;
		arch_ops->get_pkt_from_rx_resource = pci_get_pkt_from_rx_resource;
		arch_ops->get_tx_resource_free_num = pci_get_tx_resource_free_num;
	}

#endif
#ifdef RTMP_USB_SUPPORT

	if (IS_USB_INF(pAd)) {
		arch_ops->write_tx_resource = usb_write_tx_resource;
		arch_ops->write_multi_tx_resource = usb_write_multi_tx_resource;
		arch_ops->write_final_tx_resource = mt_usb_write_final_tx_resource;
		arch_ops->write_frag_tx_resource = usb_write_frag_tx_resource;
		arch_ops->kickout_data_tx = usb_kickout_data_tx;
		arch_ops->get_pkt_from_rx_resource = usb_get_pkt_from_rx_resource;
		arch_ops->get_tx_resource_free_num = usb_get_tx_resource_free_num;
	}

#endif
	return TRUE;
}
#endif /*COMPOS_WIN || COMPOS_TESTMODE_WIN */

VOID mt7603_init(RTMP_ADAPTER *pAd)
{
	RTMP_CHIP_CAP *pChipCap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);
	struct _RTMP_CHIP_DBG *chip_dbg = hc_get_chip_dbg(pAd->hdev_ctrl);

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
	mt7603_chipCap_init();
	mt7603_chipOp_init();
	os_move_mem(pChipCap, &MT7603_ChipCap, sizeof(RTMP_CHIP_CAP));
	os_move_mem(ops, &MT7603_ChipOp, sizeof(RTMP_CHIP_OP));
	pChipCap->hif_type = HIF_MT;
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
	Mt7603AsicArchOpsInit(pAd);
#endif
	mt7603_chip_dbg_init(chip_dbg);
	pChipCap->mac_type = MAC_MT;
#if defined(COMPOS_TESTMODE_WIN)
#else
	mt_phy_probe(pAd);
#endif
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(FW(%x), HW(%x), CHIPID(%x))\n",
			 __func__,
			 pAd->FWVersion,
			 pAd->HWVersion,
			 pAd->ChipID));
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
	/* TODO: BJBJ */
#else
#ifdef RTMP_MAC_PCI

	if (IS_PCI_INF(pAd)) {
		pChipCap->tx_hw_hdr_len = pChipCap->TXWISize;
		pChipCap->rx_hw_hdr_len = pChipCap->RXWISize;
	}

#endif /* RTMP_MAC_PCI */
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd)) {
		pChipCap->tx_hw_hdr_len = pChipCap->TXWISize;
		pChipCap->rx_hw_hdr_len = pChipCap->RXWISize;
	}

#endif /* RTMP_MAC_USB */
#endif
#ifdef CONFIG_CSO_SUPPORT
	pChipCap->asic_caps |= fASIC_CAP_CSO,
#endif
#if !defined(COMPOS_TESTMODE_WIN)
						   RTMP_DRS_ALG_INIT(pAd, RATE_ALG_GRP);
#endif
	/*
		Following function configure beacon related parameters
		in pChipCap
			FlgIsSupSpecBcnBuf / BcnMaxHwNum /
			WcidHwRsvNum / BcnMaxHwSize / BcnBase[]
	*/
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
	/* TODO: BJBJ */
#else
	mt_chip_bcn_parameter_init(pAd);
#endif
#ifdef DOT11W_PMF_SUPPORT
	pChipCap->FlgPMFEncrtptMode = PMF_ENCRYPT_MODE_2;
#endif /* DOT11W_PMF_SUPPORT */
	pChipCap->OmacNums = 4;
	pChipCap->BssNums = 3;
	pChipCap->ExtMbssOmacStartIdx = 0x10;
	pChipCap->RepeaterStartIdx = 0x20;
	pChipCap->MaxRepeaterNum = 16;
	pChipCap->fgBcnOffloadSupport = FALSE;
	MtAsicGetAntMode(pAd, &pAd->AntMode);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("<--%s()\n", __func__));
}


#ifdef USB_IOT_WORKAROUND2

void usb_iot_add_padding(struct urb *urb, UINT8 *buf, ra_dma_addr_t dma)
{
	UCHAR pkt2drop[512] = {	0x00, 0x02, 0x00, 0x08, 0x00, 0xcd, 0x02, 0x00, 0x28, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x88, 0x01, 0x00, 0x00, 0x48, 0x02, 0x2a, 0x65, 0x44, 0x30, 0x00, 0x0c, 0x43, 0x26, 0x60, 0x40,
							0x01, 0x00, 0x5e, 0x00, 0x00, 0xfb, 0x60, 0x01, 0x00, 0x00, 0x00, 0x00, 0xaa, 0xaa, 0x03, 0x00,
							0x00, 0x00, 0x08, 0x00, 0x45, 0x00, 0x00, 0x43, 0x51, 0x0e, 0x40, 0x00, 0xff, 0x11, 0xc0, 0x7b,
							0xc0, 0xa8, 0xc8, 0x7b, 0xe0, 0x00, 0x00, 0xfb, 0x14, 0xe9, 0x14, 0xe9, 0x00, 0x2f, 0xc8, 0x6f,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0a, 0x5f, 0x73, 0x61,
							0x6e, 0x65, 0x2d, 0x70, 0x6f, 0x72, 0x74, 0x04, 0x5f, 0x74, 0x63, 0x70, 0x05, 0x6c, 0x6f, 0x63,
							0x61, 0x6c, 0x00, 0x00, 0x0c, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
						  };
	int padding = 0;
	int sendlen = 0;

	if (!urb || !buf) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("usb_iot_add_padding %x %x\n", urb, buf));
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\ntransfer_buffer_length=%d\n", urb->transfer_buffer_length));
		return;
	}

	padding = 512 - ((urb->transfer_buffer_length) % 512);
	/* copy data to new place */
	NdisCopyMemory(buf,	urb->transfer_buffer, urb->transfer_buffer_length);
	sendlen = urb->transfer_buffer_length;
	/* add padding to 512 boundary */
	NdisZeroMemory(buf + sendlen, padding);
	sendlen += padding;
	NdisCopyMemory(buf + sendlen,	pkt2drop, 512);
	sendlen += 512;
	/* add final 4 bytes padding */
	NdisZeroMemory(buf + sendlen, 4);
	sendlen += 4;
	/* update URB */
	urb->transfer_buffer = buf;

	if (dma)
		urb->transfer_dma = dma;

	/* printk("usb_iot_add_padding %d->%d\n", urb->transfer_buffer_length, sendlen); */
	urb->transfer_buffer_length = sendlen;
}
#endif

