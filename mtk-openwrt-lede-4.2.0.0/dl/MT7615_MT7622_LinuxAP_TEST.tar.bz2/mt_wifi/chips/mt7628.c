/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	mt7628.c
*/

#include "rt_config.h"
#include "mcu/mt7628_firmware.h"
#include "eeprom/mt7628_e2p.h"
#include "phy/wf_phy_back.h"

UCHAR mt7628_ba_range[] = {4, 5, 8, 10, 16, 20, 21, 45};

static VOID mt7628_bbp_adjust(RTMP_ADAPTER *pAd, UCHAR Channel)
{
	/*do nothing, change to use radio_resource control*/
	/*here should do bbp setting only, bbp is full-offload to fw*/
}


static void mt7628_switch_channel(RTMP_ADAPTER *pAd, MT_SWITCH_CHANNEL_CFG SwChCfg)
{
#ifdef RTMP_MAC_USB
	UINT32 ret = 0;

	if (IS_USB_INF(pAd)) {
		RTMP_SEM_EVENT_WAIT(&pAd->hw_atomic, ret);

		if (ret != 0) {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("reg_atomic get failed(ret=%d)\n", ret));
			return STATUS_UNSUCCESSFUL;
		}
	}

#endif /* RTMP_MAC_USB */
	MtCmdChannelSwitch(pAd, SwChCfg);
	/* Channel latch */
	pAd->LatchRfRegs.Channel = SwChCfg.CentralChannel;
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd))
		RTMP_SEM_EVENT_UP(&pAd->hw_atomic);

#endif
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			("%s(): Switch to Ch#%d(%dT%dR)\n",
			__func__,
			SwChCfg.CentralChannel,
			pAd->Antenna.field.TxPath,
			pAd->Antenna.field.RxPath));
}


static VOID mt7628_init_mac_cr(RTMP_ADAPTER *pAd)
{
	UINT32 mac_val;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
	/* enable MAC2MAC mode */
#ifdef MT7628_FPGA
	RTMP_IO_READ32(pAd, RMAC_MISC, &mac_val);
	mac_val |= BIT18;
	RTMP_IO_WRITE32(pAd, RMAC_MISC, mac_val);
#ifdef RELEASE_EXCLUDE
	/*
	    WHQA_00016749, there are a lots of Tx retry in FPGA.
	    per Jacky's comment, enlarge the timeout value of waiting ack.
	    real chip shall not have the symptom.
	*/
#endif
	mac_val = 0x00d700d7;
	RTMP_IO_WRITE32(pAd, TMAC_CDTR, mac_val);
	mac_val = 0x00d700d7;
	RTMP_IO_WRITE32(pAd, TMAC_ODTR, mac_val);
#endif /* MT7628_FPGA */
	/* TxS Setting */
	MtAsicSetTxSClassifyFilter(pAd, TXS2HOST, TXS2H_QID1, TXS2HOST_AGGNUMS, 0x00, 0);
#ifdef DOT11W_PMF_SUPPORT
	/* Enable BIP */
	MAC_IO_READ32(pAd, WTBL_OFF_BCR, &mac_val);
	mac_val |= BIP_EN;
	MAC_IO_WRITE32(pAd, WTBL_OFF_BCR, mac_val);
#endif /* DOT11W_PMF_SUPPORT */
}


static UINT8 mt7628_txpwr_chlist[] = {
	1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
};


int mt7628_read_chl_pwr(RTMP_ADAPTER *pAd)
{
	UINT32 i, choffset;
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = &chip_cap->MTTxPwrCap;

	mt7628_get_tx_pwr_info(pAd);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()--->\n", __func__));

	for (i = 0; i < sizeof(mt7628_txpwr_chlist); i++) {
		pAd->TxPower[i].Channel = mt7628_txpwr_chlist[i];
		pAd->TxPower[i].Power = TX_TARGET_PWR_DEFAULT_VALUE;
		pAd->TxPower[i].Power2 = TX_TARGET_PWR_DEFAULT_VALUE;
	}

	for (i = 0; i < 14; i++) {
		pAd->TxPower[i].Power = cap->tx_0_target_pwr_g_band;
		pAd->TxPower[i].Power2 = cap->tx_1_target_pwr_g_band;
	}

	choffset = 14;

	/* 4. Print and Debug*/
	for (i = 0; i < choffset; i++) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("E2PROM: TxPower[%03d], Channel=%d, Power[Tx0:%d, Tx1:%d]\n",
				 i, pAd->TxPower[i].Channel, pAd->TxPower[i].Power, pAd->TxPower[i].Power2));
	}

	return TRUE;
}


/* Read power per rate */
void mt7628_get_tx_pwr_per_rate(RTMP_ADAPTER *pAd)
{
	BOOLEAN is_empty = 0;
	UINT16 value = 0;
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = &chip_cap->MTTxPwrCap;

	/* G Band tx power for CCK 1M/2M, 5.5M/11M */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_CCK_1_2M, value);

	if (is_empty) {
		cap->tx_pwr_cck_1_2 = 0;
		cap->tx_pwr_cck_5_11 = 0;
	} else {
		/* CCK 1M/2M */
		if (value & TX_PWR_CCK_1_2M_EN) {
			if (value & TX_PWR_CCK_1_2M_SIGN)
				cap->tx_pwr_cck_1_2 = (value & TX_PWR_CCK_1_2M_MASK);
			else
				cap->tx_pwr_cck_1_2 = -(value & TX_PWR_CCK_1_2M_MASK);
		} else
			cap->tx_pwr_cck_1_2 = 0;

		/* CCK 5.5M/11M */
		if (value & TX_PWR_CCK_5_11M_EN) {
			if (value & TX_PWR_CCK_5_11M_SIGN)
				cap->tx_pwr_cck_5_11 = ((value & TX_PWR_CCK_5_11M_MASK) >> 8);
			else
				cap->tx_pwr_cck_5_11 = -((value & TX_PWR_CCK_5_11M_MASK) >> 8);
		} else
			cap->tx_pwr_cck_5_11 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_cck_1_2 = %d\n", cap->tx_pwr_cck_1_2));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_cck_5_11 = %d\n", cap->tx_pwr_cck_5_11));
	/* G Band tx power for OFDM 6M/9M, 12M/18M, 24M/36M, 48M/54M */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_6_9M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_6_9 = 0;
		cap->tx_pwr_g_band_ofdm_12_18 = 0;
	} else {
		/* OFDM 6M/9M */
		if (value & TX_PWR_G_BAND_OFDM_6_9M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_6_9M_SIGN)
				cap->tx_pwr_g_band_ofdm_6_9 = (value & TX_PWR_G_BAND_OFDM_6_9M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_6_9 = -(value & TX_PWR_G_BAND_OFDM_6_9M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_6_9 = 0;

		/* OFDM 12M/18M */
		if (value & TX_PWR_G_BAND_OFDM_12_18M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_12_18M_SIGN)
				cap->tx_pwr_g_band_ofdm_12_18 = ((value & TX_PWR_G_BAND_OFDM_12_18M_MASK) >> 8);
			else
				cap->tx_pwr_g_band_ofdm_12_18 = -((value & TX_PWR_G_BAND_OFDM_12_18M_MASK) >> 8);
		} else
			cap->tx_pwr_g_band_ofdm_12_18 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_6_9 = %d\n", cap->tx_pwr_g_band_ofdm_6_9));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_12_18 = %d\n", cap->tx_pwr_g_band_ofdm_12_18));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_24_36M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_24_36 = 0;
		cap->tx_pwr_g_band_ofdm_48 = 0;
	} else {
		/* OFDM 24M/36M */
		if (value & TX_PWR_G_BAND_OFDM_24_36M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_24_36M_SIGN)
				cap->tx_pwr_g_band_ofdm_24_36 = (value & TX_PWR_G_BAND_OFDM_24_36M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_24_36 = -(value & TX_PWR_G_BAND_OFDM_24_36M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_24_36 = 0;

		/* OFDM 48M */
		if (value & TX_PWR_G_BAND_OFDM_48M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_48M_SIGN)
				cap->tx_pwr_g_band_ofdm_48 = ((value & TX_PWR_G_BAND_OFDM_48M_MASK) >> 8);
			else
				cap->tx_pwr_g_band_ofdm_48 = -((value & TX_PWR_G_BAND_OFDM_48M_MASK) >> 8);
		} else
			cap->tx_pwr_g_band_ofdm_48 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_24_36 = %d\n", cap->tx_pwr_g_band_ofdm_24_36));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_48 = %d\n", cap->tx_pwr_g_band_ofdm_48));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_54M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_54 = 0;
		cap->tx_pwr_ht_bpsk_mcs_0_8 = 0;
	} else {
		/* OFDM 54M */
		if (value & TX_PWR_G_BAND_OFDM_54M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_54M_SIGN)
				cap->tx_pwr_g_band_ofdm_54 = (value & TX_PWR_G_BAND_OFDM_54M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_54 = -(value & TX_PWR_G_BAND_OFDM_54M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_54 = 0;

		/* HT MCS_0, MCS_8 */
		if (value & TX_PWR_HT_BPSK_MCS_0_8_EN) {
			if (value & TX_PWR_HT_BPSK_MCS_0_8_SIGN)
				cap->tx_pwr_ht_bpsk_mcs_0_8 = ((value & TX_PWR_HT_BPSK_MCS_0_8_MASK) >> 8);
			else
				cap->tx_pwr_ht_bpsk_mcs_0_8 = -((value & TX_PWR_HT_BPSK_MCS_0_8_MASK) >> 8);
		} else
			cap->tx_pwr_ht_bpsk_mcs_0_8 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_54 = %d\n", cap->tx_pwr_g_band_ofdm_54));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_bpsk_mcs_0_8 = %d\n", cap->tx_pwr_ht_bpsk_mcs_0_8));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_BPSK_MCS_32, value);

	if (is_empty) {
		cap->tx_pwr_ht_bpsk_mcs_32 = 0;
		cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = 0;
	} else {
		/* HT MCS_0, MCS_8 */
		if (value & TX_PWR_HT_BPSK_MCS_32_EN) {
			if (value & TX_PWR_HT_BPSK_MCS_32_SIGN)
				cap->tx_pwr_ht_bpsk_mcs_32 = (value & TX_PWR_HT_BPSK_MCS_32_MASK);
			else
				cap->tx_pwr_ht_bpsk_mcs_32 = -(value & TX_PWR_HT_BPSK_MCS_32_MASK);
		} else
			cap->tx_pwr_ht_bpsk_mcs_32 = 0;

		/* HT MCS_1, MCS_2, MCS_9, MCS_10 */
		if (value & TX_PWR_HT_QPSK_MCS_1_2_9_10_EN) {
			if (value & TX_PWR_HT_QPSK_MCS_1_2_9_10_SIGN)
				cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = ((value & TX_PWR_HT_QPSK_MCS_1_2_9_10_MASK) >> 8);
			else
				cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = -((value & TX_PWR_HT_QPSK_MCS_1_2_9_10_MASK) >> 8);
		} else
			cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_bpsk_mcs_32 = %d\n", cap->tx_pwr_ht_bpsk_mcs_32));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_qpsk_mcs_1_2_9_10 = %d\n", cap->tx_pwr_ht_qpsk_mcs_1_2_9_10));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_16QAM_MCS_3_4_11_12, value);

	if (is_empty) {
		cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = 0;
		cap->tx_pwr_ht_64qam_mcs_5_13 = 0;
	} else {
		/* HT MCS_3, MCS_4, MCS_11, MCS_12 */
		if (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_EN) {
			if (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_SIGN)
				cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_MASK);
			else
				cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = -(value & TX_PWR_HT_16QAM_MCS_3_4_11_12_MASK);
		} else
			cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = 0;

		/* HT MCS_5, MCS_13 */
		if (value & TX_PWR_HT_64QAM_MCS_5_13_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_5_13_SIGN)
				cap->tx_pwr_ht_64qam_mcs_5_13 = ((value & TX_PWR_HT_64QAM_MCS_5_13_MASK) >> 8);
			else
				cap->tx_pwr_ht_64qam_mcs_5_13 = -((value & TX_PWR_HT_64QAM_MCS_5_13_MASK) >> 8);
		} else
			cap->tx_pwr_ht_64qam_mcs_5_13 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_16qam_mcs_3_4_11_12 = %d\n", cap->tx_pwr_ht_16qam_mcs_3_4_11_12));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_5_13 = %d\n", cap->tx_pwr_ht_64qam_mcs_5_13));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_64QAM_MCS_6_14, value);

	if (is_empty) {
		cap->tx_pwr_ht_64qam_mcs_6_14 = 0;
		cap->tx_pwr_ht_64qam_mcs_7_15 = 0;
	} else {
		/* HT MCS_6, MCS_14 */
		if (value & TX_PWR_HT_64QAM_MCS_6_14_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_6_14_SIGN)
				cap->tx_pwr_ht_64qam_mcs_6_14 = (value & TX_PWR_HT_64QAM_MCS_6_14_MASK);
			else
				cap->tx_pwr_ht_64qam_mcs_6_14 = -(value & TX_PWR_HT_64QAM_MCS_6_14_MASK);
		} else
			cap->tx_pwr_ht_64qam_mcs_6_14 = 0;

		/* HT MCS_7, MCS_15 */
		if (value & TX_PWR_HT_64QAM_MCS_7_15_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_7_15_SIGN)
				cap->tx_pwr_ht_64qam_mcs_7_15 = ((value & TX_PWR_HT_64QAM_MCS_7_15_MASK) >> 8);
			else
				cap->tx_pwr_ht_64qam_mcs_7_15 = -((value & TX_PWR_HT_64QAM_MCS_7_15_MASK) >> 8);
		} else
			cap->tx_pwr_ht_64qam_mcs_7_15 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_6_14 = %d\n", cap->tx_pwr_ht_64qam_mcs_6_14));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_7_15 = %d\n", cap->tx_pwr_ht_64qam_mcs_7_15));
}


void mt7628_get_tx_pwr_info(RTMP_ADAPTER *pAd)
{
	bool is_empty = 0;
	UINT16 value = 0;
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = &chip_cap->MTTxPwrCap;
	/* Read 20/40 BW delta */
	is_empty = RT28xx_EEPROM_READ16(pAd, G_BAND_20_40_BW_PWR_DELTA, value);

	if (is_empty)
		cap->delta_tx_pwr_bw40_g_band = 0x0;
	else {
		/* G Band */
		if (value & G_BAND_20_40_BW_PWR_DELTA_EN) {
			if (value & G_BAND_20_40_BW_PWR_DELTA_SIGN) {
				/* bit[0..5] tx power delta value */
				cap->delta_tx_pwr_bw40_g_band = (value & G_BAND_20_40_BW_PWR_DELTA_MASK);
			} else
				cap->delta_tx_pwr_bw40_g_band = -(value & G_BAND_20_40_BW_PWR_DELTA_MASK);
		} else
			cap->delta_tx_pwr_bw40_g_band = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("delta_tx_pwr_bw40_g_band = %d\n", cap->delta_tx_pwr_bw40_g_band));
	/* ///////////////// Tx0 ////////////////////////// */
	/* Read TSSI slope/offset for TSSI compensation */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_TSSI_SLOPE, value);
	cap->tssi_0_slope_g_band =
		(is_empty) ? TSSI_0_SLOPE_G_BAND_DEFAULT_VALUE : (value & TX0_G_BAND_TSSI_SLOPE_MASK);
	cap->tssi_0_offset_g_band =
		(is_empty) ? TSSI_0_OFFSET_G_BAND_DEFAULT_VALUE : ((value & TX0_G_BAND_TSSI_OFFSET_MASK) >> 8);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_slope_g_band = %d\n", cap->tssi_0_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_offset_g_band = %d\n", cap->tssi_0_offset_g_band));
	/* Read 54M target power */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_TARGET_PWR, value);
	cap->tx_0_target_pwr_g_band =
		(is_empty) ? TX_TARGET_PWR_DEFAULT_VALUE : (value & TX0_G_BAND_TARGET_PWR_MASK);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_target_pwr_g_band = %d\n", cap->tx_0_target_pwr_g_band));

	/* Read power offset (channel delta) */
	if (is_empty)
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x0;
	else {
		/* tx power offset LOW */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_LOW_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_LOW_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = ((value & TX0_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = -((value & TX0_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW]));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_CHL_PWR_DELTA_MID, value);

	if (is_empty) {
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x0;
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x0;
	} else {
		/* tx power offset MID */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_MID_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_MID_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = (value & TX0_G_BAND_CHL_PWR_DELTA_MID_MASK);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = -(value & TX0_G_BAND_CHL_PWR_DELTA_MID_MASK);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x0;

		/* tx power offset HIGH */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_HI_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_HI_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = ((value & TX0_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = -((value & TX0_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_MID] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_HI] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI]));
	/* ///////////////// Tx1 ////////////////////////// */
	/* Read TSSI slope/offset for TSSI compensation */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_TSSI_SLOPE, value);
	cap->tssi_1_slope_g_band = (is_empty) ? TSSI_1_SLOPE_G_BAND_DEFAULT_VALUE : (value & TX1_G_BAND_TSSI_SLOPE_MASK);
	cap->tssi_1_offset_g_band = (is_empty) ? TSSI_1_OFFSET_G_BAND_DEFAULT_VALUE : ((value & TX1_G_BAND_TSSI_OFFSET_MASK) >> 8);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_1_slope_g_band = %d\n", cap->tssi_1_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_1_offset_g_band = %d\n", cap->tssi_1_offset_g_band));
	/* Read 54M target power */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_TARGET_PWR, value);
	cap->tx_1_target_pwr_g_band = (is_empty) ? TX_TARGET_PWR_DEFAULT_VALUE : (value & TX1_G_BAND_TARGET_PWR_MASK);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_target_pwr_g_band = %d\n", cap->tx_1_target_pwr_g_band));

	/* Read power offset (channel delta) */
	if (is_empty)
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] =  0;
	else {
		/* tx power offset LOW */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_LOW_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_LOW_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = ((value & TX1_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = -((value & TX1_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW]));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_CHL_PWR_DELTA_MID, value);

	if (is_empty) {
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0;
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0;
	} else {
		/* tx power offset MID */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_MID_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_MID_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = (value & TX1_G_BAND_CHL_PWR_DELTA_MID_MASK);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = -(value & TX1_G_BAND_CHL_PWR_DELTA_MID_MASK);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0;

		/* tx power offset HIGH */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_HI_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_HI_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = ((value & TX1_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = -((value & TX1_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_MID] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_HI] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI]));
}


static VOID mt7628_show_pwr_info(RTMP_ADAPTER *pAd)
{
	struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct MT_TX_PWR_CAP *cap = &chip_cap->MTTxPwrCap;
	UINT32 value;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel info related to power\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));

	if (pAd->LatchRfRegs.Channel < 14) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("central channel = %d, low_mid_hi = %d\n", pAd->LatchRfRegs.Channel,
				 get_low_mid_hi_index(pAd->LatchRfRegs.Channel)));
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel power(unit: 0.5dbm)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_target_pwr_g_band = 0x%x\n", cap->tx_0_target_pwr_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_target_pwr_g_band = 0x%x\n", cap->tx_1_target_pwr_g_band));
	/* channel power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel power delta(unit: 0.5db)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI]));
	/* bw power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("bw power delta(unit: 0.5db)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("delta_tx_pwr_bw40_g_band = %d\n", cap->delta_tx_pwr_bw40_g_band));
	/* per-rate power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("per-rate power delta\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_cck_1_2 = %d\n", cap->tx_pwr_cck_1_2));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_cck_5_11 = %d\n", cap->tx_pwr_cck_5_11));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_6_9 = %d\n", cap->tx_pwr_g_band_ofdm_6_9));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_12_18 = %d\n", cap->tx_pwr_g_band_ofdm_12_18));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_24_36 = %d\n", cap->tx_pwr_g_band_ofdm_24_36));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_48 = %d\n", cap->tx_pwr_g_band_ofdm_48));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_54 = %d\n", cap->tx_pwr_g_band_ofdm_54));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_bpsk_mcs_32 = %d\n", cap->tx_pwr_ht_bpsk_mcs_32));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_bpsk_mcs_0_8 = %d\n", cap->tx_pwr_ht_bpsk_mcs_0_8));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_qpsk_mcs_1_2_9_10 = %d\n", cap->tx_pwr_ht_qpsk_mcs_1_2_9_10));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_16qam_mcs_3_4_11_12 = %d\n", cap->tx_pwr_ht_16qam_mcs_3_4_11_12));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_5_13 = %d\n", cap->tx_pwr_ht_64qam_mcs_5_13));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_6_14 = %d\n", cap->tx_pwr_ht_64qam_mcs_6_14));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_7_15 = %d\n", cap->tx_pwr_ht_64qam_mcs_7_15));
	/* TMAC POWER INFO */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("per-rate power delta in MAC 0x60130020 ~ 0x60130030\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	RTMP_IO_READ32(pAd, TMAC_FP0R0, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R0 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R1, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R1 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R2, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R2 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R3, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R3 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R4, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R4 = 0x%x\n", value));
	/* TSSI info */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TSSI info\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TSSI enable = %d\n", chip_cap->tssi_enable));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_0_slope_g_band = 0x%x\n", cap->tssi_0_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_slope_g_band = 0x%x\n", cap->tssi_1_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_0_offset_g_band = 0x%x\n", cap->tssi_0_offset_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_offset_g_band = 0x%x\n", cap->tssi_1_offset_g_band));
}


#ifdef CAL_FREE_IC_SUPPORT
static BOOLEAN mt7628_is_cal_free_ic(RTMP_ADAPTER *pAd)
{
	UINT16 Value = 0;
	BOOLEAN NotValid;

	NotValid = rtmp_ee_efuse_read16(pAd, 0x54, &Value);

	if (NotValid)
		return FALSE;

	if (((Value >> 8) & 0xff) == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0x56, &Value);

	if (NotValid)
		return FALSE;

	if (Value == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0x5c, &Value);

	if (NotValid)
		return FALSE;

	if (Value == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0xf0, &Value);

	if (NotValid)
		return FALSE;

	if ((Value & 0xff) == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0xf4, &Value);

	if (NotValid)
		return FALSE;

	if ((Value & 0xff) == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0xf6, &Value);

	if (NotValid)
		return FALSE;

	if (((Value >> 8) & 0xff) == 0x00)
		return FALSE;

	return TRUE;
}



static VOID mt7628_cal_free_data_get(RTMP_ADAPTER *ad)

{
	UINT16 value;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s\n", __func__));
	/* 0x55 0x56 0x57 0x5C 0x5D */
	eFuseReadRegisters(ad, A_BAND_EXT_PA_SETTING, 2, &value);
	/*0x55*/
	ad->EEPROMImage[A_BAND_EXT_PA_SETTING + 1] = (value >> 8) & 0xFF;
	eFuseReadRegisters(ad, TX0_G_BAND_TSSI_SLOPE, 2, &value);
	/*0x56,0x57*/
	*(UINT16 *)(&ad->EEPROMImage[TX0_G_BAND_TSSI_SLOPE]) = le2cpu16(value);
	eFuseReadRegisters(ad, TX1_G_BAND_TSSI_SLOPE, 2, &value);
	/*0x5c,0x5d*/
	*(UINT16 *)(&ad->EEPROMImage[TX1_G_BAND_TSSI_SLOPE]) = le2cpu16(value);
	eFuseReadRegisters(ad, TX1_G_BAND_TARGET_PWR, 2, &value);
	/* 0xF0 0xF4 0xF7  */
	eFuseReadRegisters(ad, CP_FT_VERSION, 2, &value);
	ad->EEPROMImage[CP_FT_VERSION] = value & 0xFF;
	eFuseReadRegisters(ad, XTAL_CALIB_FREQ_OFFSET, 2, &value);
	ad->EEPROMImage[XTAL_CALIB_FREQ_OFFSET]  = value & 0xFF;
	eFuseReadRegisters(ad, XTAL_TRIM_3_COMP, 2, &value);
	ad->EEPROMImage[XTAL_TRIM_3_COMP + 1] = (value >> 8) & 0xFF;
}


#endif /* CAL_FREE_IC_SUPPORT */





static void mt7628_antenna_default_reset(
	struct _RTMP_ADAPTER *pAd,
	EEPROM_ANTENNA_STRUC *pAntenna)
{
	pAntenna->word = 0;
	pAd->RfIcType = RFIC_7628;
	pAntenna->field.TxPath = 2;
	pAntenna->field.RxPath = 2;
}

#ifdef CONFIG_STA_SUPPORT
static VOID mt7628_init_dev_nick_name(RTMP_ADAPTER *ad)
{
#ifdef RTMP_MAC_PCI

	if (IS_MT7628(ad))
		snprintf((RTMP_STRING *) ad->nickname, sizeof(ad->nickname), "mt7628_sta");

#endif
}
#endif /* CONFIG_STA_SUPPORT */

static inline VOID bufferModeFieldSet(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd, UINT16 addr)
{
	UINT32 i = pCmd->ucCount;

	pCmd->BinContent[i].u2Addr = cpu2le16(addr);
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[addr];
	pCmd->ucCount++;
}


static VOID mt7628_bufferModeEfuseFill(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd)
{
	int i = 0;

	pCmd->BinContent[i].u2Addr = NIC_CONFIGURE_0_TOP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[NIC_CONFIGURE_0_TOP];
	i++;
	pCmd->BinContent[i].u2Addr = NIC_CONFIGURE_1;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[NIC_CONFIGURE_1];
	i++;
	pCmd->BinContent[i].u2Addr = NIC_CONFIGURE_1_TOP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[NIC_CONFIGURE_1_TOP];
	i++;
	pCmd->BinContent[i].u2Addr = WIFI_RF_SETTING;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[WIFI_RF_SETTING];
	i++;
	pCmd->BinContent[i].u2Addr = G_BAND_20_40_BW_PWR_DELTA;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[G_BAND_20_40_BW_PWR_DELTA];
	i++;
	pCmd->BinContent[i].u2Addr = A_BAND_20_80_BW_PWR_DELTA_ANALOG;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[A_BAND_20_80_BW_PWR_DELTA_ANALOG];
	i++;
	pCmd->BinContent[i].u2Addr = A_BAND_EXT_PA_SETTING;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[A_BAND_EXT_PA_SETTING];
	i++;
	pCmd->BinContent[i].u2Addr = TEMP_SENSOR_CAL;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TEMP_SENSOR_CAL];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_TSSI_SLOPE;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_TSSI_SLOPE];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_TSSI_SLOPE_TOP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_TSSI_SLOPE_TOP];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_TARGET_PWR;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_TARGET_PWR];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_OFFSET_LOW;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_OFFSET_LOW];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_CHL_PWR_DELTA_MID;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_CHL_PWR_DELTA_MID];
	i++;
	pCmd->BinContent[i].u2Addr = TX0_G_BAND_OFFSET_HIGH;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX0_G_BAND_OFFSET_HIGH];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_TSSI_SLOPE;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_TSSI_SLOPE];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_TSSI_SLOPE_TOP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_TSSI_SLOPE_TOP];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_TARGET_PWR;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_TARGET_PWR];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_CHL_PWR_DELATE_LOW;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_CHL_PWR_DELATE_LOW];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_CHL_PWR_DELTA_MID;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_CHL_PWR_DELTA_MID];
	i++;
	pCmd->BinContent[i].u2Addr = TX1_G_BAND_CHL_PWR_DELTA_HIGH;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX1_G_BAND_CHL_PWR_DELTA_HIGH];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_CCK_1_2M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_CCK_1_2M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_CCK_5_11M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_CCK_5_11M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_G_BAND_OFDM_6_9M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_G_BAND_OFDM_6_9M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_OFDM_12_18M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_OFDM_12_18M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_G_BAND_OFDM_24_36M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_G_BAND_OFDM_24_36M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_G_BNAD_OFDM_48;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_G_BNAD_OFDM_48];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_G_BAND_OFDM_54M;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_G_BAND_OFDM_54M];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_BPSK_MCS_0_8;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_BPSK_MCS_0_8];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_BPSK_MCS_32;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_BPSK_MCS_32];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_QPSK_MCS_1_2_9_10;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_QPSK_MCS_1_2_9_10];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_16QAM_MCS_3_4_11_12;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_16QAM_MCS_3_4_11_12];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_64QAM_MCS_5_13;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_64QAM_MCS_5_13];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_64QAM_MCS_6_14;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_64QAM_MCS_6_14];
	i++;
	pCmd->BinContent[i].u2Addr = TX_PWR_HT_64QAM_MCS_7_15;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[TX_PWR_HT_64QAM_MCS_7_15];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_RX_MODE_GAIN;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_RX_MODE_GAIN];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_RX_MODE_NF;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_RX_MODE_NF];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_RX_MODE_P1DB;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_RX_MODE_P1DB];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_BYPASS_MODE_GAIN;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_BYPASS_MODE_GAIN];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_BYPASS_MODE_NF;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_BYPASS_MODE_NF];
	i++;
	pCmd->BinContent[i].u2Addr = ELAN_BYPASS_MODE_P1DB;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[ELAN_BYPASS_MODE_P1DB];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_7;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_7];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_6;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_6];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_5;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_5];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_4;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_4];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_3;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_3];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_2;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_2];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_1;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_1];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_NEG_0;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_NEG_0];
	i++;
	pCmd->BinContent[i].u2Addr = REF_STEP_24G;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[REF_STEP_24G];
	i++;
	pCmd->BinContent[i].u2Addr = REF_TEMP_24G;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[REF_TEMP_24G];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_1;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_1];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_2;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_2];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_3;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_3];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_4;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_4];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_5;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_5];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_6;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_6];
	i++;
	pCmd->BinContent[i].u2Addr = STEP_NUM_PLUS_7;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[STEP_NUM_PLUS_7];
	i++;
	pCmd->BinContent[i].u2Addr = XTAL_CALIB_FREQ_OFFSET;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[XTAL_CALIB_FREQ_OFFSET];
	i++;
	pCmd->BinContent[i].u2Addr = XTAL_TRIM_2_COMP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[XTAL_TRIM_2_COMP];
	i++;
	pCmd->BinContent[i].u2Addr = XTAL_TRIM_3_COMP;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[XTAL_TRIM_3_COMP];
	i++;
	pCmd->BinContent[i].u2Addr = WF_RCAL;
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[WF_RCAL];
	i++;
	pCmd->ucCount = i;

	for (i = 0; i < pCmd->ucCount; i++)
		pCmd->BinContent[i].u2Addr = cpu2le16(pCmd->BinContent[i].u2Addr);

	/*extend for function requset, need backward compatible*/
	bufferModeFieldSet(pAd, pCmd, 0x24);
	bufferModeFieldSet(pAd, pCmd, 0x25);
	bufferModeFieldSet(pAd, pCmd, 0x34);
	bufferModeFieldSet(pAd, pCmd, 0x39);
	bufferModeFieldSet(pAd, pCmd, 0x3b);
	bufferModeFieldSet(pAd, pCmd, 0x42);
	bufferModeFieldSet(pAd, pCmd, 0x43);
	bufferModeFieldSet(pAd, pCmd, 0x9e);
	bufferModeFieldSet(pAd, pCmd, 0x9f);
	bufferModeFieldSet(pAd, pCmd, 0xf2);
	bufferModeFieldSet(pAd, pCmd, 0xf8);
	bufferModeFieldSet(pAd, pCmd, 0xf9);
	bufferModeFieldSet(pAd, pCmd, 0xfa);
	bufferModeFieldSet(pAd, pCmd, 0x12e);

	for (i = 0; i <= 0xf; i++)
		bufferModeFieldSet(pAd, pCmd, 0x130 + i);

	/*need minus 1 for add one more time*/
	pCmd->ucCount--;
}


static void mt7628_fw_prepare(RTMP_ADAPTER *pAd)
{
	struct fwdl_ctrl *ctrl = &pAd->MCUCtrl.fwdl_ctrl;

	ctrl->fw_profile[WM_CPU].source.header_ptr = MT7628_FirmwareImage;
	ctrl->fw_profile[WM_CPU].source.header_len = sizeof(MT7628_FirmwareImage);
	ctrl->fw_profile[WM_CPU].source.bin_name = "mtk/MT7628.bin";
}

static VOID mt7628_fwdl_datapath_setup(RTMP_ADAPTER *pAd, BOOLEAN init)
{
#ifdef DMA_SCH_SUPPORT
	MtAsicSetDmaByPassMode(pAd, init);
#endif /* DMA_SCH_SUPPORT */
}

static const RTMP_CHIP_CAP MT7628_ChipCap = {
	.max_nss = 2,
	.TXWISize = sizeof(TMAC_TXD_L), /* 32 */
	.RXWISize = 28,
	.WtblHwNum = MT7628_MT_WTBL_SIZE,
	.WtblPseAddr = MT7628_PSE_WTBL_2_ADDR,
#ifdef RTMP_MAC_PCI
	.WPDMABurstSIZE = 3,
#endif
	.SnrFormula = SNR_FORMULA4,
	.FlgIsHwWapiSup = TRUE,
	.FlgIsHwAntennaDiversitySup = FALSE,
#ifdef STREAM_MODE_SUPPORT
	.FlgHwStreamMode = FALSE,
#endif
	.asic_caps = (fASIC_CAP_PMF_ENC | fASIC_CAP_MCS_LUT | fASIC_CAP_RDG),
	.phy_caps = (fPHY_CAP_24G | fPHY_CAP_HT),
	.MaxNumOfRfId = MAX_RF_ID,
	.pRFRegTable = NULL,
	.MaxNumOfBbpId = 200,
	.pBBPRegTable = NULL,
	.bbpRegTbSize = 0,
#ifdef NEW_MBSSID_MODE
#ifdef ENHANCE_NEW_MBSSID_MODE
	.MBSSIDMode = MBSSID_MODE4,
#else
	.MBSSIDMode = MBSSID_MODE1,
#endif /* ENHANCE_NEW_MBSSID_MODE */
#else
	.MBSSIDMode = MBSSID_MODE0,
#endif /* NEW_MBSSID_MODE */
#ifdef RTMP_EFUSE_SUPPORT
	.EFUSE_USAGE_MAP_START = 0x1e0,
	.EFUSE_USAGE_MAP_END = 0x1fc,
	.EFUSE_USAGE_MAP_SIZE = 29,
	.EFUSE_RESERVED_SIZE = 22,	/* Cal-Free is 22 free block */
#endif
	.EEPROM_DEFAULT_BIN = MT7628_E2PImage,
	.EEPROM_DEFAULT_BIN_SIZE = sizeof(MT7628_E2PImage),
	.EFUSE_BUFFER_CONTENT_SIZE = 0x5b,
#ifdef CONFIG_ANDES_SUPPORT
	.need_load_patch = 0,
	.need_load_fw = BIT(WM_CPU),
	.load_patch_flow = PATCH_FLOW_V1,
	.load_fw_flow = FW_FLOW_V1,
	.patch_format = PATCH_FORMAT_V1;
	.fw_format = FW_FORMAT_V1;
	.load_patch_method = BIT(HEADER_METHOD);
	.load_fw_method = BIT(HEADER_METHOD);
#endif
	.MCUType = ANDES,
	.cmd_header_len = 12,
#ifdef RTMP_PCI_SUPPORT
	.cmd_padding_len = 0,
#endif
#ifdef CARRIER_DETECTION_SUPPORT
	.carrier_func = TONE_RADAR_V2,
#endif
	.hif_type = HIF_MT,
	.rf_type = RF_MT,
	.TxAggLimit = 21,
	.RxBAWinSize = 64,
	.ht_max_ampdu_len_exp = 3,
	.TxOPScenario = 0x1,
	.CurrentTxOP = 0x0,
	.default_txop = 0x60,
	/*for multi-wmm*/
	.WmmHwNum = MT7628_MT_WMM_SIZE;
	.ba_range = mt7628_ba_range;
};


static const RTMP_CHIP_OP MT7628_ChipOp = {
	.ChipBBPAdjust = mt7628_bbp_adjust,
	.ChipSwitchChannel = mt7628_switch_channel,
	.AsicMacInit = mt7628_init_mac_cr,
	.AsicAntennaDefaultReset = mt7628_antenna_default_reset,
	.ChipAGCInit = NULL,
#ifdef CONFIG_STA_SUPPORT
	.ChipAGCAdjust = NULL,
#endif
	.AsicRfTurnOn = NULL,
	.AsicHaltAction = NULL,
	.AsicRfTurnOff = NULL,
	.AsicReverseRfFromSleepMode = NULL,
#ifdef CONFIG_STA_SUPPORT
	.NetDevNickNameInit = mt7628_init_dev_nick_name,
#endif
#ifdef CARRIER_DETECTION_SUPPORT
	.ToneRadarProgram = ToneRadarProgram_v2,
#endif
	.RxSensitivityTuning = NULL,
	.DisableTxRx = NULL,

#ifdef RTMP_PCI_SUPPORT
	/* .AsicRadioOn = RT28xxPciAsicRadioOn, */
	/* .AsicRadioOff = RT28xxPciAsicRadioOff, */
#endif
#ifdef CAL_FREE_IC_SUPPORT
	.is_cal_free_ic = mt7628_is_cal_free_ic,
	.cal_free_data_get = mt7628_cal_free_data_get,
#endif /* CAL_FREE_IC_SUPPORT */
	.show_pwr_info = mt7628_show_pwr_info,
	.bufferModeEfuseFill = mt7628_bufferModeEfuseFill,
	.MtCmdTx = MtCmdSendMsg,
	.prepare_fwdl_img = mt7628_fw_prepare,
	.fwdl_datapath_setup = mt7628_fwdl_datapath_setup
};


VOID mt7628_init(RTMP_ADAPTER *pAd)
{
	RTMP_CHIP_CAP *pChipCap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);
	struct _RTMP_CHIP_DBG *chip_dbg = hc_get_chip_dbg(pAd->hdev_ctrl);

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
	memcpy(pChipCap, &MT7628_ChipCap, sizeof(RTMP_CHIP_CAP));
	memcpy(ops, &MT7628_ChipOp, sizeof(RTMP_CHIP_OP));
	pChipCap->hif_type = HIF_MT;
	pChipCap->mac_type = MAC_MT;
	mt7628_chip_dbg_init(chip_dbg);
	mt_phy_probe(pAd);
	pChipCap->tx_hw_hdr_len = pChipCap->TXWISize;
	pChipCap->rx_hw_hdr_len = pChipCap->RXWISize;
#ifdef CONFIG_CSO_SUPPORT
	pChipCap->asic_caps |= fASIC_CAP_CSO,
#endif
						   RTMP_DRS_ALG_INIT(pAd, RATE_ALG_GRP);
	/*
		Following function configure beacon related parameters
		in pChipCap
			FlgIsSupSpecBcnBuf / BcnMaxHwNum /
			WcidHwRsvNum / BcnMaxHwSize / BcnBase[]
	*/
	mt_bcn_buf_init(pAd);
#ifdef DOT11W_PMF_SUPPORT
	pChipCap->FlgPMFEncrtptMode = PMF_ENCRYPT_MODE_2;
#endif /* DOT11W_PMF_SUPPORT */
	pChipCap->OmacNums = 4;
	pChipCap->BssNums = 3;
	pChipCap->MBSSStartIdx = 0x10;
	pChipCap->RepeaterStartIdx = 0x20;

	/* for interrupt enable mask */
	pChipCap->int_enable_mask = ((MT_DELAYINTMASK) | (MT_RxINT | MT_INT_T0_DONE | 
					MT_INT_T1_DONE | MT_INT_T2_DONE | MT_INT_T3_DONE | 
					MT_TxMgmtInt) | MT_INT_BMC_DLY);

#if (CFG_CPU_LOADING_RXRING_DLY == 1)
	pChipCap->int_enable_mask &= ~(MT_INT_RX_DATA | MT_INT_RX_CMD);
	pChipCap->int_enable_mask |= MT_INT_RX_DLY;
#endif
#if (CFG_CPU_LOADING_DISABLE_TXDONE0 == 1)
	pChipCap->int_enable_mask &= ~MT_INT_AC0_DLY;
#endif
	MtAsicGetAntMode(pAd, &pAd->AntMode);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("<--%s()\n", __func__));
}

