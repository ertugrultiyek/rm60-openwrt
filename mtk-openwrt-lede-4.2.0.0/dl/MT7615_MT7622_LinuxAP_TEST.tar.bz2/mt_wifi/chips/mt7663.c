/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	mt7663.c
*/

#include "rt_config.h"
#include "mcu/mt7663_firmware.h"
#ifdef NEED_ROM_PATCH
#include "mcu/mt7663_rom_patch_e1.h"
#endif /* NEED_ROM_PATCH */
#include "eeprom/mt7663_e2p.h"

UCHAR mt7663_ba_range[] = {4, 8, 12, 24, 36, 48, 54, 64};

#ifdef INTERNAL_CAPTURE_SUPPORT
extern RBIST_DESC_T MT7663_ICAP_DESC[];
extern UINT8 MT7663_ICapBankNum;
#endif /* INTERNAL_CAPTURE_SUPPORT */

#ifdef WIFI_SPECTRUM_SUPPORT
extern RBIST_DESC_T MT7663_SPECTRUM_DESC[];
extern UINT8 MT7663_SpectrumBankNum;
#endif /* WIFI_SPECTRUM_SUPPORT */

#ifdef MT7663_FPGA
REG_CHK_PAIR hif_dft_cr[] = {
	{HIF_BASE + 0x00, 0xffffffff, 0x76030001},
	{HIF_BASE + 0x04, 0xffffffff, 0x1b},
	{HIF_BASE + 0x10, 0xffffffff, 0x3f01},
	{HIF_BASE + 0x20, 0xffffffff, 0xe01001e0},
	{HIF_BASE + 0x24, 0xffffffff, 0x1e00000f},

	{HIF_BASE + 0x200, 0xffffffff, 0x0},
	{HIF_BASE + 0x204, 0xffffffff, 0x0},
	{HIF_BASE + 0x208, 0xffffffff, 0x10001870},
	{HIF_BASE + 0x20c, 0xffffffff, 0x0},
	{HIF_BASE + 0x210, 0xffffffff, 0x0},
	{HIF_BASE + 0x214, 0xffffffff, 0x0},
	{HIF_BASE + 0x218, 0xffffffff, 0x0},
	{HIF_BASE + 0x21c, 0xffffffff, 0x0},
	{HIF_BASE + 0x220, 0xffffffff, 0x0},
	{HIF_BASE + 0x224, 0xffffffff, 0x0},
	{HIF_BASE + 0x234, 0xffffffff, 0x0},
	{HIF_BASE + 0x244, 0xffffffff, 0x0},
	{HIF_BASE + 0x300, 0xffffffff, 0x0},
	{HIF_BASE + 0x304, 0xffffffff, 0x0},
	{HIF_BASE + 0x308, 0xffffffff, 0x0},
	{HIF_BASE + 0x30c, 0xffffffff, 0x0},
	{HIF_BASE + 0x310, 0xffffffff, 0x0},
	{HIF_BASE + 0x314, 0xffffffff, 0x0},
	{HIF_BASE + 0x318, 0xffffffff, 0x0},
	{HIF_BASE + 0x31c, 0xffffffff, 0x0},
	{HIF_BASE + 0x320, 0xffffffff, 0x0},
	{HIF_BASE + 0x324, 0xffffffff, 0x0},
	{HIF_BASE + 0x328, 0xffffffff, 0x0},
	{HIF_BASE + 0x32c, 0xffffffff, 0x0},
	{HIF_BASE + 0x330, 0xffffffff, 0x0},
	{HIF_BASE + 0x334, 0xffffffff, 0x0},
	{HIF_BASE + 0x338, 0xffffffff, 0x0},
	{HIF_BASE + 0x33c, 0xffffffff, 0x0},

	{HIF_BASE + 0x400, 0xffffffff, 0x0},
	{HIF_BASE + 0x404, 0xffffffff, 0x0},
	{HIF_BASE + 0x408, 0xffffffff, 0x0},
	{HIF_BASE + 0x40c, 0xffffffff, 0x0},
	{HIF_BASE + 0x410, 0xffffffff, 0x0},
	{HIF_BASE + 0x414, 0xffffffff, 0x0},
	{HIF_BASE + 0x418, 0xffffffff, 0x0},
	{HIF_BASE + 0x41c, 0xffffffff, 0x0},
};


INT mt7663_chk_hif_default_cr_setting(RTMP_ADAPTER *pAd)
{
	UINT32 val;
	INT i;
	BOOLEAN match = TRUE;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): Default CR Setting Checking for HIF!\n", __func__));

	for (i = 0; i < sizeof(hif_dft_cr) / sizeof(REG_CHK_PAIR); i++) {
		RTMP_IO_READ32(pAd, hif_dft_cr[i].Register, &val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\t Reg(%x): Current=0x%x(0x%x), Default=0x%x, Mask=0x%x, Match=%s\n",
				 hif_dft_cr[i].Register, val, (val & hif_dft_cr[i].Mask),
				 hif_dft_cr[i].Value, hif_dft_cr[i].Mask,
				 ((val & hif_dft_cr[i].Mask) != hif_dft_cr[i].Value) ? "No" : "Yes"));

		if ((val & hif_dft_cr[i].Mask) != hif_dft_cr[i].Value)
			match = FALSE;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): Checking Done, Result=> %s match!\n",
			 __func__, match == TRUE ? "All" : "No"));
	return match;
}


REG_CHK_PAIR top_dft_cr[] = {
	{TOP_CFG_BASE + 0x1000, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1004, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1008, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1010, 0xffffffff, 0x0},

	{TOP_CFG_BASE + 0x1100, 0xffffffff, 0x26110310},
	{TOP_CFG_BASE + 0x1108, 0x0000ff00, 0x1400},
	{TOP_CFG_BASE + 0x110c, 0x00000000, 0x0},
	{TOP_CFG_BASE + 0x1110, 0x0f0f00ff, 0x02090040},
	{TOP_CFG_BASE + 0x1124, 0xf000f00f, 0x00000008},
	{TOP_CFG_BASE + 0x1130, 0x000f0000, 0x0},
	{TOP_CFG_BASE + 0x1134, 0x00000000, 0x0},
	{TOP_CFG_BASE + 0x1140, 0x00ff00ff, 0x0},

	{TOP_CFG_BASE + 0x1200, 0x00000000, 0x0},
	{TOP_CFG_BASE + 0x1204, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x1208, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x120c, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x1210, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x1214, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x1218, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x121c, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x1220, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x1224, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x1228, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x122c, 0x000fffff, 0x0},
	{TOP_CFG_BASE + 0x1234, 0x00ffffff, 0x0},
	{TOP_CFG_BASE + 0x1238, 0x00ffffff, 0x0},
	{TOP_CFG_BASE + 0x123c, 0xffffffff, 0x5c1fee80},
	{TOP_CFG_BASE + 0x1240, 0xffffffff, 0x6874ae05},
	{TOP_CFG_BASE + 0x1244, 0xffffffff, 0x00fb89f1},

	{TOP_CFG_BASE + 0x1300, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1304, 0xffffffff, 0x8f020006},
	{TOP_CFG_BASE + 0x1308, 0xffffffff, 0x18010000},
	{TOP_CFG_BASE + 0x130c, 0xffffffff, 0x0130484f},
	{TOP_CFG_BASE + 0x1310, 0xffffffff, 0xff000004},
	{TOP_CFG_BASE + 0x1314, 0xffffffff, 0xf0000084},
	{TOP_CFG_BASE + 0x1318, 0x00000000, 0x0},
	{TOP_CFG_BASE + 0x131c, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1320, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1324, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1328, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x132c, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1330, 0xffffffff, 0x00007800},
	{TOP_CFG_BASE + 0x1334, 0x00000000, 0x0},
	{TOP_CFG_BASE + 0x1338, 0xffffffff, 0x0000000a},
	{TOP_CFG_BASE + 0x1400, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1404, 0xffffffff, 0x00005180},
	{TOP_CFG_BASE + 0x1408, 0xffffffff, 0x00001f00},
	{TOP_CFG_BASE + 0x140c, 0xffffffff, 0x00000020},
	{TOP_CFG_BASE + 0x1410, 0xffffffff, 0x0000003a},
	{TOP_CFG_BASE + 0x141c, 0xffffffff, 0x0},

	{TOP_CFG_BASE + 0x1500, 0xffffffff, 0x0},
	{TOP_CFG_BASE + 0x1504, 0xffffffff, 0x0},
};

INT mt7663_chk_top_default_cr_setting(RTMP_ADAPTER *pAd)
{
	UINT32 val;
	INT i;
	BOOLEAN match = TRUE;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): Default CR Setting Checking for TOP!\n", __func__));

	for (i = 0; i < sizeof(top_dft_cr) / sizeof(REG_CHK_PAIR); i++) {
		RTMP_IO_READ32(pAd, top_dft_cr[i].Register, &val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\t Reg(%x): Current=0x%x(0x%x), Default=0x%x, Mask=0x%x, Match=%s\n",
				 top_dft_cr[i].Register, val, (val & top_dft_cr[i].Mask),
				 top_dft_cr[i].Value, top_dft_cr[i].Mask,
				 ((val & top_dft_cr[i].Mask) != top_dft_cr[i].Value) ? "No" : "Yes"));

		if ((val & top_dft_cr[i].Mask) != top_dft_cr[i].Value)
			match = FALSE;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): Checking Done, Result=> %s match!\n",
			 __func__, match == TRUE ? "All" : "No"));
	return match;
}
#endif /* MT7663_FPGA */


static VOID mt7663_bbp_adjust(RTMP_ADAPTER *pAd, UCHAR Channel)
{
	/*do nothing, change to use radio_resource control*/
	/*here should do bbp setting only, bbp is full-offload to fw*/
}


/* TODO: Star */
static void mt7663_switch_channel(RTMP_ADAPTER *pAd, MT_SWITCH_CHANNEL_CFG SwChCfg)
{
	MtCmdChannelSwitch(pAd, SwChCfg);
	MtCmdSetTxRxPath(pAd, SwChCfg);
	pAd->LatchRfRegs.Channel = SwChCfg.CentralChannel;
}

#ifdef NEW_SET_RX_STREAM
static INT mt7663_set_RxStream(RTMP_ADAPTER *pAd, UINT32 StreamNums, UCHAR BandIdx)
{
	UINT32 path = 0;
	UINT i;

	if (StreamNums > 4) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s():illegal StreamNums(%d)\n",
				  __func__, StreamNums));
		StreamNums = 4;
	}

	for (i = 0; i < StreamNums; i++)
		path |= 1 << i;

	return MtCmdSetRxPath(pAd, path, BandIdx);
}
#endif

static inline VOID bufferModeFieldSet(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd, UINT16 addr)
{
	UINT32 i = pCmd->ucCount;

	pCmd->BinContent[i] = pAd->EEPROMImage[addr];
	pCmd->ucCount++;
}


static VOID mt7663_bufferModeEfuseFill(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd)
{
	UINT16 i = 0;

	pCmd->ucCount = 0;

	for (i = 0x34; i <= 0x3AB; i++)
		bufferModeFieldSet(pAd, pCmd, i);

	/*must minus last add*/
	pCmd->ucCount--;
}

#ifdef CAL_FREE_IC_SUPPORT
static inline BOOLEAN check_valid(RTMP_ADAPTER *pAd, UINT16 Offset)
{
	UINT16 Value = 0;
	BOOLEAN NotValid;

	if ((Offset % 2) != 0) {
		NotValid = rtmp_ee_efuse_read16(pAd, Offset - 1, &Value);

		if (NotValid)
			return FALSE;

		if (((Value >> 8) & 0xff) == 0x00)
			return FALSE;

		NotValid = rtmp_ee_efuse_read16(pAd, Offset + 1, &Value);

		if (NotValid)
			return FALSE;

		if ((Value & 0xff) == 0x00)
			return FALSE;
	} else {
		NotValid = rtmp_ee_efuse_read16(pAd, Offset, &Value);

		if (NotValid)
			return FALSE;

		if (Value == 0x00)
			return FALSE;
	}

	return TRUE;
}
static BOOLEAN mt7663_is_cal_free_ic(RTMP_ADAPTER *pAd)
{
	UINT16 Value = 0;
	BOOLEAN NotValid;

	NotValid = rtmp_ee_efuse_read16(pAd, 0x52, &Value);

	if (NotValid)
		return FALSE;

	if (((Value >> 8) & 0xff) == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0x54, &Value);

	if (NotValid)
		return FALSE;

	if (Value == 0x00)
		return FALSE;

	if (check_valid(pAd, 0x56) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x5c) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x62) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x68) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x6e) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x73) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x78) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x7d) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x82) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x87) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x8c) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x91) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x96) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x9b) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0xa0) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0xa5) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0xaa) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0xaf) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0xb4) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0xb9) == FALSE)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0xf4, &Value);

	if (NotValid)
		return FALSE;

	if ((Value & 0xff) == 0x00)
		return FALSE;

	NotValid = rtmp_ee_efuse_read16(pAd, 0xf6, &Value);

	if (NotValid)
		return FALSE;

	if (((Value >> 8) & 0xff) == 0x00)
		return FALSE;

	if (check_valid(pAd, 0x140) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x145) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x14a) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x14f) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x154) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x159) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x15e) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x163) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x168) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x16c) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x172) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x177) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x17c) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x181) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x186) == FALSE)
		return FALSE;

	if (check_valid(pAd, 0x18b) == FALSE)
		return FALSE;

	return TRUE;
}

static inline VOID cal_free_data_get_from_addr(RTMP_ADAPTER *ad, UINT16 Offset)
{
	UINT16 value;

	if ((Offset % 2) != 0) {
		rtmp_ee_efuse_read16(ad, Offset - 1, &value);
		ad->EEPROMImage[Offset] = (value >> 8) & 0xFF;
		rtmp_ee_efuse_read16(ad, Offset + 1, &value);
		ad->EEPROMImage[Offset + 1] =  value & 0xFF;
	} else {
		rtmp_ee_efuse_read16(ad, Offset, &value);
		*(UINT16 *)(&ad->EEPROMImage[Offset]) = le2cpu16(value);
	}
}

static VOID mt7663_cal_free_data_get(RTMP_ADAPTER *ad)

{
	UINT16 value;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s\n", __func__));
	/* 0x53 0x54 0x55 0x56 0x57 0x5C 0x5D */
	rtmp_ee_efuse_read16(ad, 0x52, &value);
	ad->EEPROMImage[0x53] = (value >> 8) & 0xFF;
	rtmp_ee_efuse_read16(ad, 0x54, &value);
	*(UINT16 *)(&ad->EEPROMImage[0x54]) = le2cpu16(value);
	rtmp_ee_efuse_read16(ad, 0x56, &value);
	*(UINT16 *)(&ad->EEPROMImage[0x56]) = le2cpu16(value);
	rtmp_ee_efuse_read16(ad, 0x5c, &value);
	*(UINT16 *)(&ad->EEPROMImage[0x5c]) = le2cpu16(value);
	/* 0x62 0x63 0x68 0x69 0x6E 0x6F */
	cal_free_data_get_from_addr(ad, 0x62);
	cal_free_data_get_from_addr(ad, 0x68);
	cal_free_data_get_from_addr(ad, 0x6e);
	/* 0x73 0x74 0x78 0x79 0x7D 0x7E */
	cal_free_data_get_from_addr(ad, 0x73);
	cal_free_data_get_from_addr(ad, 0x78);
	cal_free_data_get_from_addr(ad, 0x7d);
	/* 0x82 0x83 0x87 0x88 0x8C 0x8D */
	cal_free_data_get_from_addr(ad, 0x82);
	cal_free_data_get_from_addr(ad, 0x87);
	cal_free_data_get_from_addr(ad, 0x8c);
	/* 0x91 0x92 0x96 0x97 0x9B 0x9C */
	cal_free_data_get_from_addr(ad, 0x91);
	cal_free_data_get_from_addr(ad, 0x96);
	cal_free_data_get_from_addr(ad, 0x9b);
	/* 0xA0 0xA1 0xA5 0xA6 0xAA 0xAB 0xAF 0xB0 0xB4 0xB5 0xB9 0xBA */
	cal_free_data_get_from_addr(ad, 0xa0);
	cal_free_data_get_from_addr(ad, 0xa5);
	cal_free_data_get_from_addr(ad, 0xaa);
	cal_free_data_get_from_addr(ad, 0xaf);
	cal_free_data_get_from_addr(ad, 0xb4);
	cal_free_data_get_from_addr(ad, 0xb9);
	/* 0xF4 0xF7  */
	rtmp_ee_efuse_read16(ad, 0xf4, &value);
	ad->EEPROMImage[0xf4]  = value & 0xFF;
	rtmp_ee_efuse_read16(ad, 0xf6, &value);
	ad->EEPROMImage[0xf7] = (value >> 8) & 0xFF;
	/* 0x140 0x141 0x145 0x146 0x14A 0x14B 0x14F 0x150*/
	cal_free_data_get_from_addr(ad, 0x140);
	cal_free_data_get_from_addr(ad, 0x145);
	cal_free_data_get_from_addr(ad, 0x14a);
	cal_free_data_get_from_addr(ad, 0x14f);
	/* 0x154 0x155 0x159 0x15A 0x15E 0x15F */
	cal_free_data_get_from_addr(ad, 0x154);
	cal_free_data_get_from_addr(ad, 0x159);
	cal_free_data_get_from_addr(ad, 0x15e);
	/* 0x163 0x164 0x168 0x169 0x16D 0x16E*/
	cal_free_data_get_from_addr(ad, 0x163);
	cal_free_data_get_from_addr(ad, 0x168);
	cal_free_data_get_from_addr(ad, 0x16d);
	/* 0x172 0x173 0x177 0x178 0x17C 0x17D*/
	cal_free_data_get_from_addr(ad, 0x172);
	cal_free_data_get_from_addr(ad, 0x177);
	cal_free_data_get_from_addr(ad, 0x17c);
	/* 0x181 0x182 0x186 0x187 0x18B 0x18C*/
	cal_free_data_get_from_addr(ad, 0x181);
	cal_free_data_get_from_addr(ad, 0x186);
	cal_free_data_get_from_addr(ad, 0x18b);
}
#endif /* CAL_FREE_IC_SUPPORT */

static INT32 mt7663_dma_shdl_init(RTMP_ADAPTER *pAd)
{
	UINT32 value;
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);

	HIF_DMASHDL_IO_READ32(pAd, MT_HIF_DMASHDL_PKT_MAX_SIZE, &value);
	value &= ~(PLE_PKT_MAX_SIZE_MASK | PSE_PKT_MAX_SIZE_MASK);
	value |= PLE_PKT_MAX_SIZE_NUM(0x1);
	value |= PSE_PKT_MAX_SIZE_NUM(0x8);
	HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_PKT_MAX_SIZE, value);

	/* Enable refill Control Group 0, 1, 2, 4, 5 */
	HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_REFILL_CTRL, 0xffc80000);
	/* Group 0, 1, 2, 4, 5, 15 joint the ask round robin */
	HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_OPTION_CTRL, 0x70068037);
	/*Each group min quota must larger then PLE_PKT_MAX_SIZE_NUM*/
	value = DMASHDL_MIN_QUOTA_NUM(0x40);
	value |= DMASHDL_MAX_QUOTA_NUM(0x1ff);

	HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_GROUP0_CTRL, value);
	HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_GROUP1_CTRL, value);
	HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_GROUP2_CTRL, value);
	HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_GROUP4_CTRL, value);
	value = DMASHDL_MIN_QUOTA_NUM(0x40);
	value |= DMASHDL_MAX_QUOTA_NUM(0x40);
	HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_GROUP5_CTRL, value);

	if (cap->qm == GENERIC_QM) {
		HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_Q_MAP0, 0x42104210);
		HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_Q_MAP1, 0x42104210);
		HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_Q_MAP2, 0x00000005);
		HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_Q_MAP3, 0x0);
#if 0
		HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_Q_MAP2, 0x55555555);
		HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_Q_MAP3, 0x55555555);
#endif
		HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_SHDL_SET0, 0x6012345f);
		HIF_DMASHDL_IO_WRITE32(pAd, MT_HIF_DMASHDL_SHDL_SET1, 0xedcba987);
	}
	return TRUE;
}

#ifdef CFG_SUPPORT_MU_MIMO
#ifdef MANUAL_MU
INT mu_update_profile_tb(RTMP_ADAPTER *pAd, INT profile_id, UCHAR wlan_id)
{
}

INT mu_update_grp_table(RTMP_ADAPTER *pAd, INT grp_id)
{
	return TRUE;
}


INT mu_update_cluster_tb(RTMP_ADAPTER *pAd, UCHAR c_id, UINT32 *m_ship, UINT32 *u_pos)
{
	UINT32 entry_base, mac_val, offset;

	ASSERT(c_id <= 31);
	MAC_IO_READ32(pAd, MU_MUCR1, &mac_val);

	if (c_id < 16)
		mac_val &= (~MUCR1_CLUSTER_TAB_REMAP_CTRL_MASK);
	else
		mac_val |= MUCR1_CLUSTER_TAB_REMAP_CTRL_MASK;

	MAC_IO_WRITE32(pAd, MU_MUCR1, mac_val);
	entry_base = MU_CLUSTER_TABLE_BASE  + (c_id & (~0x10)) * 24;
	/* update membership */
	MAC_IO_WRITE32(pAd, entry_base + 0x0, m_ship[0]);
	MAC_IO_WRITE32(pAd, entry_base + 0x4, m_ship[1]);
	/* Update user position */
	MAC_IO_WRITE32(pAd, entry_base + 0x8, u_pos[0]);
	MAC_IO_WRITE32(pAd, entry_base + 0xc, u_pos[1]);
	MAC_IO_WRITE32(pAd, entry_base + 0x10, u_pos[2]);
	MAC_IO_WRITE32(pAd, entry_base + 0x14, u_pos[3]);
	return TRUE;
}


INT mu_get_wlanId_ac_len(RTMP_ADAPTER *pAd, UINT32 wlan_id, UINT ac)
{
	return TRUE;
}


INT mu_get_mu_tx_retry_cnt(RTMP_ADAPTER *pAd)
{
	return TRUE;
}


INT mu_get_pfid_tx_stat(RTMP_ADAPTER *pAd)
{
}

INT mu_get_gpid_rate_per_stat(RTMP_ADAPTER *pAd)
{
	return TRUE;
}


INT mt7663_mu_init(RTMP_ADAPTER *pAd)
{
	UINT32 mac_val;
	/****************************************************************************
		MU Part
	****************************************************************************/
	/* After power on initial setting,  AC legnth clear */
	MAC_IO_READ32(pAd, MU_MUCR4, &mac_val);
	mac_val = 0x1;
	MAC_IO_WRITE32(pAd, MU_MUCR4, mac_val); /* 820fe010= 0x0000_0001 */
	/* PFID table */
	MAC_IO_WRITE32(pAd, MU_PROFILE_TABLE_BASE + 0x0, 0x1e000);  /* 820fe780= 0x0001_e000 */
	MAC_IO_WRITE32(pAd, MU_PROFILE_TABLE_BASE + 0x4, 0x1e103);  /* 820fe784= 0x0001_e103 */
	MAC_IO_WRITE32(pAd, MU_PROFILE_TABLE_BASE + 0x8, 0x1e205);  /* 820fe788= 0x0001_e205 */
	MAC_IO_WRITE32(pAd, MU_PROFILE_TABLE_BASE + 0xc, 0x1e306);  /* 820fe78c= 0x0001_e306 */
	/* Cluster table */
	MAC_IO_WRITE32(pAd, MU_CLUSTER_TABLE_BASE + 0x0, 0x0);  /* 820fe400= 0x0000_0000 */
	MAC_IO_WRITE32(pAd, MU_CLUSTER_TABLE_BASE + 0x8, 0x0);  /* 820fe408= 0x0000_0000 */
	MAC_IO_WRITE32(pAd, MU_CLUSTER_TABLE_BASE + 0x20, 0x2);  /* 820fe420= 0x0000_0002 */
	MAC_IO_WRITE32(pAd, MU_CLUSTER_TABLE_BASE + 0x28, 0x0);  /* 820fe428= 0x0000_0000 */
	MAC_IO_WRITE32(pAd, MU_CLUSTER_TABLE_BASE + 0x40, 0x2);  /* 820fe440= 0x0000_0002 */
	MAC_IO_WRITE32(pAd, MU_CLUSTER_TABLE_BASE + 0x48, 0x4);  /* 820fe448= 0x0000_0004 */
	MAC_IO_WRITE32(pAd, MU_CLUSTER_TABLE_BASE + 0x60, 0x0);  /* 820fe460= 0x0000_0000 */
	MAC_IO_WRITE32(pAd, MU_CLUSTER_TABLE_BASE + 0x68, 0x0);  /* 820fe468= 0x0000_0000 */
	/* Group rate table */
	MAC_IO_WRITE32(pAd, MU_GRP_TABLE_RATE_MAP + 0x0, 0x4109);  /* 820ff000= 0x0000_4109 */
	MAC_IO_WRITE32(pAd, MU_GRP_TABLE_RATE_MAP + 0x4, 0x99);  /* 820ff004= 0x0000_0099 */
	MAC_IO_WRITE32(pAd, MU_GRP_TABLE_RATE_MAP + 0x8, 0x800000f0);  /* 820ff008= 0x8000_00f0 */
	MAC_IO_WRITE32(pAd, MU_GRP_TABLE_RATE_MAP + 0xc, 0x99);  /* 820ff00c= 0x0000_0099 */
	/* SU Tx minimum setting */
	MAC_IO_WRITE32(pAd, MU_MUCR2, 0x10000001);  /* 820fe008= 0x1000_0001 */
	/* MU max group search entry = 1 group entry */
	MAC_IO_WRITE32(pAd, MU_MUCR1, 0x0);  /* 820fe004= 0x0000_0000 */
	/* MU enable */
	MAC_IO_READ32(pAd, MU_MUCR0, &mac_val);
	mac_val |= 1;
	MAC_IO_WRITE32(pAd, MU_MUCR0, 0x1);  /* 820fe000= 0x1000_0001 */
	/****************************************************************************
		M2M Part
	****************************************************************************/
	/* Enable M2M MU temp mode */
	MAC_IO_READ32(pAd, RMAC_M2M_BAND_CTRL, &mac_val);
	mac_val |= (1 << 16);
	MAC_IO_WRITE32(pAd, RMAC_M2M_BAND_CTRL, mac_val);
	/****************************************************************************
		AGG Part
	****************************************************************************/
	/* 820f20e0[15] = 1 or 0 all need to be verified, because
	    a). if primary is the fake peer, and peer will not ACK to us, cannot setup the TxOP
	    b). Or can use CTS2Self to setup the TxOP
	*/
	MAC_IO_READ32(pAd, AGG_MUCR, &mac_val);
	mac_val &= (~MUCR_PRIM_BAR_MASK);
	/* mac_val |= (1 << MUCR_PRIM_BAR_BIT); */
	MAC_IO_WRITE32(pAd, AGG_MUCR, mac_val);  /* 820fe000= 0x1000_0001 */
	return TRUE;
}
#endif /* MANUAL_MU */
#endif /* CFG_SUPPORT_MU_MIMO */

#ifndef MAC_INIT_OFFLOAD
#ifdef CONFIG_FPGA_MODE
static VOID mt7663_init_mac_cr_for_fpga(RTMP_ADAPTER *pAd)
{
	UINT32 mac_val;

	/* ++Check if anyone touch those CRs */
	MAC_IO_READ32(pAd, LPON_WLANCKCR, &mac_val);
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): LPON_WLANCKCR=0x%x\n", __func__, mac_val));
	MAC_IO_READ32(pAd, TMAC_ICR_BAND_0, &mac_val);
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): TMAC_ICR_BAND_0=0x%x\n", __func__, mac_val));
	MAC_IO_READ32(pAd, TMAC_TRCR0, &mac_val);
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): TMAC_TRCR0=0x%x\n", __func__, mac_val));
	MAC_IO_READ32(pAd, TMAC_RRCR, &mac_val);
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): TMAC_RRCR=0x%x\n", __func__, mac_val));
	/* ---Check if anyone touch those CRs */
#if 0 /* CONNAC M2M_2.0_PHY_MODEL does NOT need to enable MAC2MAC mode */
	/* enable MAC2MAC mode */
	MAC_IO_READ32(pAd, RMAC_MISC, &mac_val);
	mac_val |= BIT18;
	MAC_IO_WRITE32(pAd, RMAC_MISC, mac_val);
#endif
	/* +++Workaround for BCN transmission */
	/* not sure needed, wilsonl */
#if 0 /* done, confirmed with Star */
	MAC_IO_READ32(pAd, CFG_DBDC_CTRL0, &mac_val);
	mac_val |= BIT21;
	MAC_IO_WRITE32(pAd, CFG_DBDC_CTRL0, mac_val);
#endif
	/* ---Workaround for BCN transmission */
#if 0 /* ndef PALLADIUM */
	/* +++workaroudn for LMAC Clock correction */
	/* In FPGA mode, original value 0x2700 is used for 1x=40MHz clock, now FPGA is 1x=20MHZ clock */
	/* In ASIC mode, LMAC have two clock domain, 1x=160MHz, used for RMAC/TMAC/DMA.... */
	/* 2x=320MHz, used for AGG/WTBL/SEC..... */
	MAC_IO_READ32(pAd, LPON_WLANCKCR, &mac_val);
	mac_val &= (~(0xff << 8)); /* Disable Rx Header translation for now! */
	mac_val |= (0x13 << 8);
	MAC_IO_WRITE32(pAd, LPON_WLANCKCR, mac_val);
	/* --- */
#endif /* PALLADIUM */
	/* Band 0 */
	/* TODO: shiang-Mt7615, remove these after FW is ready! */
#if 0 /* honor f/w setting */
	MAC_IO_READ32(pAd, DMA_BN0RCFR0, &mac_val); /* Rx Classify filter 0 */
	mac_val |= 0xc0000000;
	MAC_IO_WRITE32(pAd, DMA_BN0RCFR0, mac_val);
#endif
	/* check if firmware has these settings, wilsonl */
	MAC_IO_READ32(pAd, DMA_BN0RCFR1, &mac_val); /* Rx Classify filter 1 */
	mac_val |= 0xc0000000;
	MAC_IO_WRITE32(pAd, DMA_BN0RCFR1, mac_val);
	MAC_IO_READ32(pAd, DMA_BN0VCFR0, &mac_val); /* Vector Classify filter 0 */
	mac_val = 0x2000;
	MAC_IO_WRITE32(pAd, DMA_BN0VCFR0, mac_val);
	MAC_IO_READ32(pAd, DMA_BN0TCFR0, &mac_val); /* TxS Classify filter 0 */
	mac_val = 0x8000;
	MAC_IO_WRITE32(pAd, DMA_BN0TCFR0, mac_val);
	MAC_IO_READ32(pAd, DMA_BN0TMCFR0, &mac_val); /* TMR Classify filter 0, to HIF and RxRing 1 */
	mac_val = 0x2000;
	MAC_IO_WRITE32(pAd, DMA_BN0TMCFR0, mac_val);
#if 0 /* to remove, wilsonl */
	/* Band 1 */
	MAC_IO_READ32(pAd, DMA_BN1RCFR0, &mac_val); /* Rx Classify filter 0 */
	mac_val |= 0xc0000000;
	MAC_IO_WRITE32(pAd, DMA_BN1RCFR0, mac_val);
	MAC_IO_READ32(pAd, DMA_BN1RCFR1, &mac_val); /* Rx Classify filter 1 */
	mac_val |= 0xc0000000;
	MAC_IO_WRITE32(pAd, DMA_BN1RCFR1, mac_val);
	MAC_IO_READ32(pAd, DMA_BN1VCFR0, &mac_val); /* Vector Classify filter 0 */
	mac_val = 0x2000;
	MAC_IO_WRITE32(pAd, DMA_BN1VCFR0, mac_val);
	MAC_IO_READ32(pAd, DMA_BN1TCFR0, &mac_val); /* TxS Classify filter 0 */
	mac_val = 0x8000;
	MAC_IO_WRITE32(pAd, DMA_BN1TCFR0, mac_val);
	MAC_IO_READ32(pAd, DMA_BN1TMCFR0, &mac_val); /* TMR Classify filter 0, to HIF and RxRing 1 */
	mac_val = 0x2000;
	MAC_IO_WRITE32(pAd, DMA_BN1TMCFR0, mac_val);
#endif
	/* +++work-around for change T2R time for cannot receive Ack issue in FPGA mode */
	/* need to confirm, wilsonl */
	/* done, confirmed by Jacky */
	MAC_IO_READ32(pAd, TMAC_RRCR, &mac_val);
	mac_val = 0;
	MAC_IO_WRITE32(pAd, TMAC_RRCR, mac_val);
	/* ---work-around for change T2R time for cannot receive Ack issue in FPGA mode */
	/* +++work-around for RTS/CTS bandwidth signaling failed issue in FPGA mode */
	/*
	    M2M mode the CTS will not respond the RTS with bandwidth signaling request, and make
	    sender keep sending the RTS, and reduce the throughput
	*/
	/* need to confirm, wilsonl */
#if 0 /* done, confirmed by Jacky */
	MAC_IO_READ32(pAd, TMAC_TCR, &mac_val);
	mac_val &= ~((1 << 12) | (1 << 13) | (1 << 14));
	MAC_IO_WRITE32(pAd, TMAC_TCR, mac_val);
	/* TMAC_TCR1 bit 12 to 14 is reserved, wilsonl */
	MAC_IO_READ32(pAd, TMAC_TCR1, &mac_val);
	mac_val &= ~((1 << 12) | (1 << 13) | (1 << 14));
	MAC_IO_WRITE32(pAd, TMAC_TCR1, mac_val);
#endif
	/* ---work-around for RTS/CTS bandwidth signaling failed issue in FPGA mode */
	/* +++work-around for in-correct TxOP behavior of TMAC when run in M2M mode */
	/*
	    M2M not support real PHY rate control, make Rx response too fast and create
	    un-expected idle behavior, make when TxOP!=0, mostly LMAC is stay in idle state
	    and make throughput redude
	*/
	/* need to confirm, wilsonl */
	/* done, confirmed by Jacky */
	MAC_IO_READ32(pAd, TMAC_ATCR, &mac_val);
	mac_val &= ~(ATCR_TXV_TOUT_MASK);
	mac_val |= ((0x48 & ATCR_TXV_TOUT_MASK) << ATCR_TXV_TOUT_BIT);
	MAC_IO_WRITE32(pAd, TMAC_ATCR, mac_val);
	MAC_IO_READ32(pAd, TMAC_TRCR0, &mac_val);
	mac_val &= ~(TMAC_TR2T_CHK_MASK << TMAC_TR2T_CHK_BIT);
	mac_val |= ((0x6c & TMAC_TR2T_CHK_MASK) << TMAC_TR2T_CHK_BIT);
	MAC_IO_WRITE32(pAd, TMAC_TRCR0, mac_val);
	/* ---work-around for in-correct TxOP behavior of TMAC when run in M2M mode */
}
#endif /* CONFIG_FPGA_MODE */
#endif /* MAC_INIT_OFFLOAD */

/* need to confirm with DE, wilsonl */
static VOID mt7663_init_mac_cr(RTMP_ADAPTER *pAd)
{
	UINT32 mac_val;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
#ifndef MAC_INIT_OFFLOAD
#ifdef CONFIG_FPGA_MODE
	mt7663_init_mac_cr_for_fpga(pAd);
#endif /* CONFIG_FPGA_MODE */
	/* need to confirm with DE, wilsonl */
	/* done, confirmed by Austin */
	/* Set TxFreeEvent packet only go through CR4 */
	HW_IO_READ32(pAd, PLE_HIF_REPORT, &mac_val);
	mac_val |= 0x1;
	HW_IO_WRITE32(pAd, PLE_HIF_REPORT, mac_val);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("%s(): Set TxRxEventPkt path 0x%0x = 0x%08x\n",
			  __func__, PLE_HIF_REPORT, mac_val));
#if 0 /* not needed, confirmed by Allen */
	/* Set PP Flow control */
	HW_IO_READ32(pAd, PP_PAGECTL_0, &mac_val);
	mac_val &= ~(PAGECTL_0_PSE_PG_CNT_MASK);
	mac_val |= 0x30;
	HW_IO_WRITE32(pAd, PP_PAGECTL_0, mac_val);
	HW_IO_READ32(pAd, PP_PAGECTL_1, &mac_val);
	mac_val &= ~(PAGECTL_1_PLE_PG_CNT_MASK);
	mac_val |= 0x10;
	HW_IO_WRITE32(pAd, PP_PAGECTL_1, mac_val);
#endif
	HW_IO_READ32(pAd, PP_PAGECTL_2, &mac_val);
	mac_val &= ~(PAGECTL_2_CUT_PG_CNT_MASK);
	mac_val |= 0x30;
	HW_IO_WRITE32(pAd, PP_PAGECTL_2, mac_val);
#if 0 /* not needed, confirmed by Allen */
	/* Check PP CT setting */
	HW_IO_READ32(pAd, PP_RXCUTDISP, &mac_val);
	/* mac_val |= 0x2; */
	/* RTMP_IO_WRITE32(pAd, mac_reg, mac_val); */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("%s(): Get CutThroughPathController CR 0x%0x = 0x%08x\n",
			  __func__, PP_RXCUTDISP, mac_val));
#endif
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
	/* TxS Setting */
	InitTxSTypeTable(pAd);
#endif
	MtAsicSetTxSClassifyFilter(pAd, TXS2HOST, TXS2H_QID1, TXS2HOST_AGGNUMS, 0x00, 0);
#endif /*MAC_INIT_OFFLOAD*/
	/* MAC D0 2x / MAC D0 1x clock enable */
	MAC_IO_READ32(pAd, CFG_CCR, &mac_val);
	mac_val |= (BIT31 | BIT25);
	MAC_IO_WRITE32(pAd, CFG_CCR, mac_val);
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("%s: MAC D0 2x 1x initial(val=%x)\n", __func__, mac_val));
	/*  Disable RX Header Translation */
	MAC_IO_READ32(pAd, DMA_DCR0, &mac_val);
	mac_val &= ~(DMA_DCR0_RX_HDR_TRANS_EN_BIT | DMA_DCR0_RX_HDR_TRANS_MODE_BIT |
				 DMA_DCR0_RX_RM_VLAN_BIT | DMA_DCR0_RX_INS_VLAN_BIT |
				 DMA_DCR0_RX_HDR_TRANS_CHK_BSSID);
#ifdef HDR_TRANS_RX_SUPPORT

	if (IS_ASIC_CAP(pAd, fASIC_CAP_RX_HDR_TRANS)) {
		UINT32 mac_val2;

		mac_val |= DMA_DCR0_RX_HDR_TRANS_EN_BIT | DMA_DCR0_RX_RM_VLAN_BIT |
				   DMA_DCR0_RX_HDR_TRANS_CHK_BSSID;
		/* TODO: UnifiedSW, take care about Windows for translation mode! */
		/* mac_val |= DMA_DCR0_RX_HDR_TRANS_MODE_BIT; */
		MAC_IO_READ32(pAd, DMA_DCR1, &mac_val2);
		mac_val2 |= RHTR_AMS_VLAN_EN;
		MAC_IO_WRITE32(pAd, DMA_DCR1, mac_val2);
	}

#endif /* HDR_TRANS_RX_SUPPORT */
	MAC_IO_WRITE32(pAd, DMA_DCR0, mac_val);
	/* CCA Setting */
	MAC_IO_READ32(pAd, TMAC_TRCR0, &mac_val);
	mac_val &= ~CCA_SRC_SEL_MASK;
	mac_val |= CCA_SRC_SEL(0x2);
	mac_val &= ~CCA_SEC_SRC_SEL_MASK;
	mac_val |= CCA_SEC_SRC_SEL(0x0);
	MAC_IO_WRITE32(pAd, TMAC_TRCR0, mac_val);
	MAC_IO_READ32(pAd, TMAC_TRCR0, &mac_val);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("%s(): TMAC_TRCR0=0x%x\n", __func__, mac_val));
	/* ---Add by shiang for MT7615 RFB ED issue */
	/* Set BAR rate as 0FDM 6M default, remove after fw set */
	MAC_IO_WRITE32(pAd, AGG_ACR0, 0x04b10496);
	/*Add by Star for zero delimiter*/
	MAC_IO_READ32(pAd, TMAC_CTCR0, &mac_val);
	mac_val &= ~INS_DDLMT_REFTIME_MASK;
	mac_val |= INS_DDLMT_REFTIME(0x3f);
	mac_val |= DUMMY_DELIMIT_INSERTION;
	mac_val |= INS_DDLMT_DENSITY(3);
	MAC_IO_WRITE32(pAd, TMAC_CTCR0, mac_val);
	/* Temporary setting for RTS */
	/*if no protect should enable for CTS-2-Self, WHQA_00025629*/
#if 0 /* not needed, confirmed by Star, wilsonl */

	if (MTK_REV_GTE(pAd, MT7615, MT7615E1) && MTK_REV_LT(pAd, MT7615, MT7615E3) && pAd->CommonCfg.dbdc_mode)
		MAC_IO_WRITE32(pAd, AGG_PCR1, 0xfe0fffff);
	else {
#endif
		MAC_IO_WRITE32(pAd, AGG_PCR1, 0x060003e8);
		MAC_IO_READ32(pAd, AGG_SCR, &mac_val);
		mac_val |= NLNAV_MID_PTEC_DIS;
		MAC_IO_WRITE32(pAd, AGG_SCR, mac_val);
#if 0
	}

#endif
	/*Default disable rf low power beacon mode*/
#define WIFI_SYS_PHY 0x10000
#define RF_LOW_BEACON_BAND0 (WIFI_SYS_PHY+0x1900)
#define RF_LOW_BEACON_BAND1 (WIFI_SYS_PHY+0x1d00)
	PHY_IO_READ32(pAd, RF_LOW_BEACON_BAND0, &mac_val);
	mac_val &= ~(0x3 << 8);
	mac_val |= (0x2 << 8);
	PHY_IO_WRITE32(pAd, RF_LOW_BEACON_BAND0, mac_val);
	PHY_IO_READ32(pAd, RF_LOW_BEACON_BAND1, &mac_val);
	mac_val &= ~(0x3 << 8);
	mac_val |= (0x2 << 8);
	PHY_IO_WRITE32(pAd, RF_LOW_BEACON_BAND1, mac_val);
}


#if 0
static UINT32 mt7663_cbw[] = {0x0, 0x1, 0x2, 0x7, 0xf};
static VOID mt7663_set_bbp_cbw(RTMP_ADAPTER *pAd, BOOLEAN isDBDC, INT *cbw)
{
}
#endif


#ifdef PALLADIUM
#define PALLADIUM_CM_ALL	0xff
INT MT7663_ChannelModelCfg(RTMP_ADAPTER *pAd, INT cm_id, BOOLEAN re_init, UCHAR band)
{
	UINT32 bbp_val, mask, bbp_cr, print_cr;
	UINT32 start_cm, end_cm, cm_num, cm_cr_offset;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("%s(): Run in Palladium mode! Do Channel Model initialization....\n", __func__));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("\tcm_id=%d, re_init=%d\n", cm_id, re_init));

	if (cm_id == PALLADIUM_CM_ALL) {
		start_cm = 0;
		end_cm = 3;
	} else {
		start_cm = cm_id;
		end_cm = cm_id;
	}

	cm_cr_offset = 0x100;

	if (re_init == TRUE) {
		/* step 0-0 */
		for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
			bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
			print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
			PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
			mask = (CR_CM_TOP_RST_MASK << CR_CM_TOP_RST_BITS);
			bbp_val &= (~mask);
			PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
			PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
			mask = (CR_CM_INTF_RST_MASK << CR_CM_INTF_RST_BITS);
			bbp_val &= (~mask);
			PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
		}

		/* step 0-1 */
		for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
			bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
			print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
			PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
			mask = CR_CM_LOAD_EN_MASK << CR_CM_LOAD_EN_BITS;
			bbp_val &= (~mask);
			PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
			PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
			mask = CR_CM_INTF_EN_MASK << CR_CM_INTF_EN_BITS;
			bbp_val &= (~mask);
			PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
		}
	}

	/* Step 1, start initialization */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_CM_TOP_RST_MASK << CR_CM_TOP_RST_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x1 << CR_CM_TOP_RST_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_CM_INTF_RST_MASK << CR_CM_INTF_RST_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x1 << CR_CM_INTF_RST_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 2 */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		/* AFE band, 2.4G or 5G */
		bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_AFE_BAND_MASK << CR_AFE_BAND_BITS;
		bbp_val &= (~mask);

		if (band == BAND_24G)
			bbp_val |= (0x0 << CR_AFE_BAND_BITS);
		else if (band == BAND_5G)
			bbp_val |= (0x1 << CR_AFE_BAND_BITS);

		/* Channel Rx DBM, -50dBm */
		mask = CR_CH_RX_DBM_MASK << CR_CH_RX_DBM_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x738 << CR_CH_RX_DBM_BITS);
		/* AFE AWGN Noise Enable */
		mask = CR_AFE_AWGN_NOISE_EN_MASK << CR_AFE_AWGN_NOISE_EN_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x0 << CR_AFE_AWGN_NOISE_EN_BITS);
		/* Channel type */
		mask = CR_CH_TYPE_MASK << CR_CH_TYPE_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x0 << CR_CH_TYPE_BITS);
		/* transpose mode enable */
		mask = CR_TRANSPOSE_MODE_EN_MASK << CR_TRANSPOSE_MODE_EN_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x0 << CR_TRANSPOSE_MODE_EN_BITS);
		/* Number of RX */
		mask = CR_N_RX_MASK << CR_N_RX_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x4 << CR_N_RX_BITS);
		/* Number of TX */
		mask = CR_N_TX_MASK << CR_N_TX_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x4 << CR_N_TX_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 3, Configure channel ID */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		UINT32 seed;

		seed = 1 << (cm_num * 8);
		bbp_cr = CR_CM_CH_SEED_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_CH_ID_MASK << CR_CH_ID_BITS;
		bbp_val &= (~mask);
		bbp_val |= (seed << CR_CH_ID_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 4, Configure AFE seed */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		UINT32 seed;

		seed = 1 << (cm_num * 8);
		bbp_cr = CR_CM_AFE_SEED_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_AFE_SEED_MASK << CR_AFE_SEED_BITS;
		bbp_val &= (~mask);
		bbp_val |= (seed << CR_AFE_SEED_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 11, Set Noise level */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		bbp_cr = CR_CM_DC_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_AFE_DC_NOISE_EN_MASK << CR_AFE_DC_NOISE_EN_BITS;
		bbp_val &= (~mask);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 13, take effect */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\tRead CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = (CR_CM_LOAD_EN_MASK << CR_CM_LOAD_EN_BITS) | (CR_CM_INTF_EN_MASK << CR_CM_INTF_EN_BITS);
		bbp_val &= (~mask);
		bbp_val |= (CR_CM_LOAD_EN_MASK << CR_CM_LOAD_EN_BITS) | (CR_CM_INTF_EN_MASK << CR_CM_INTF_EN_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\twrite CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 14, delay for a while */
	RtmpusecDelay(1);

	/* Step 15, pull LOAD_EN_BITS to low af */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = (CR_CM_LOAD_EN_MASK << CR_CM_LOAD_EN_BITS);
		bbp_val &= (~mask);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 16, delay for a while */
	RtmpusecDelay(100);
	/* final dump all configurations */
	{
	}
	return TRUE;
}

#define MAX_USER    4
#define MAX_CORR    4

#if 0
INT16 highcorr_channel_real[MAX_USER][MAX_CORR] = {
	{   -473,   926,    -284,   297 },    /* User0HCR */
	{   -425,   943,    -314,   176 },    /* User1HCR */
	{   -428,   998,    -225,   41  },    /* User2HCR */
	{   -275,   1023,   -154,   395 },    /* User3HCR */
};

INT16 lowcorr_channel_real[MAX_USER][MAX_CORR] = {
	{   -477,   933,    -286,   299     },    /* User0LCR */
	{   142,    185,    -159,   -463    },   /* User1LCR */
	{   131,    414,    207,    -1023   },  /* User2LCR */
	{   767,    516,    502,    446     },    /* User3LCR */
};

INT16 highcorr_channel_imag[MAX_USER][MAX_CORR] = {
	{   -313,   392,    -158,   0   },      /* User0HCI */
	{   -154,   402,    -377,   0   },      /* User1HCI */
	{   -349,   415,    -42,    0   },      /* User2HCI */
	{   -202,   417,    -104,   0   },      /* User3HCI */
};

INT16 lowcorr_channel_imag[MAX_USER][MAX_CORR] = {
	{   -315,   395,    -159,   0   },      /* User0LCI */
	{   620,    90,     -929,   0   },      /* User1LCI */
	{   -189,   141,    464,    0   },      /* User2LCI */
	{   421,    153,    207,    0   },      /* User3LCI */
};
#else
INT16 highcorr_channel_real[MAX_USER][MAX_CORR] = {
	{   -15136,     29632,      -9088,      9504    },      /* User0HCR */
	{   -13600,     30176,      -10048,     5632    },      /* User1HCR */
	{   -13696,     31936,      -7200,      1312    },      /* User2HCR */
	{   -8800,      32736,      -4928,      12640   },      /* User3HCR */
};

INT16 lowcorr_channel_real[MAX_USER][MAX_CORR] = {
	{   -15264,     29856,      -9152,      9568    },      /* User0LCR */
	{   4544,       5920,       -5088,      -14816  },      /* User1LCR */
	{   4192,       13248,      6624,       -32736  },      /* User2LCR */
	{   24544,      16512,      16064,      14272  },      /* User3LCR */
};

INT16 highcorr_channel_imag[MAX_USER][MAX_CORR] = {
	{   -10016,     12544,      -5056,      0       },      /* User0HCI */
	{   -4928,      12864,      -12064,     0       },      /* User1HCI */
	{   -11168,     13280,      -1344,      0       },      /* User2HCI */
	{   -6464,      13344,      -3328,      0       },      /* User3HCI */
};

INT16 lowcorr_channel_imag[MAX_USER][MAX_CORR] = {
	{   -10080,     12640,      -5088,      0       },      /* User0LCI */
	{   19840,      2880,       -29728,     0       },      /* User1LCI */
	{   -6048,      4512,       14848,      0       },      /* User2LCI */
	{   13472,      4896,       6624,       0       },      /* User3LCI */
};
#endif

#if 0
INT MT7663_MuChannelModelCfg(RTMP_ADAPTER *pAd, INT cm_id, UINT8 high_corr, BOOLEAN re_init, UCHAR band)
{
	UINT32 bbp_val, mask, bbp_cr, print_cr;
	UINT32 start_cm, end_cm, cm_num, cm_cr_offset;
	UINT8 corr = 0;
	BOOLEAN ap_mode = FALSE;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("%s(): Run in Palladium mode! Do Channel Model initialization....\n", __func__));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("\tcm_id=%d, re_init=%d\n", cm_id, re_init));
	ap_mode = (cm_id == 4) ? TRUE : FALSE;

	if (ap_mode) {
		start_cm = 0;
		end_cm = 3;
	} else {
		start_cm = cm_id;
		end_cm = cm_id;
	}

	cm_cr_offset = 0x100;

	if (re_init == TRUE) {
		/* step 0-0 */
		for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
			bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
			print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
			PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
			mask = (CR_CM_TOP_RST_MASK << CR_CM_TOP_RST_BITS);
			bbp_val &= (~mask);
			PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
			PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
			mask = (CR_CM_INTF_RST_MASK << CR_CM_INTF_RST_BITS);
			bbp_val &= (~mask);
			PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
		}

		/* step 0-1 */
		for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
			bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
			print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
			PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
			mask = CR_CM_LOAD_EN_MASK << CR_CM_LOAD_EN_BITS;
			bbp_val &= (~mask);
			PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
			PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
			mask = CR_CM_INTF_EN_MASK << CR_CM_INTF_EN_BITS;
			bbp_val &= (~mask);
			PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
		}
	}

	/* Step 1, start initialization */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_CM_TOP_RST_MASK << CR_CM_TOP_RST_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x1 << CR_CM_TOP_RST_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_CM_INTF_RST_MASK << CR_CM_INTF_RST_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x1 << CR_CM_INTF_RST_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 2 */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		/* AFE band, 2.4G or 5G */
		bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_AFE_BAND_MASK << CR_AFE_BAND_BITS;
		bbp_val &= (~mask);

		if (band == BAND_24G)
			bbp_val |= (0x0 << CR_AFE_BAND_BITS);
		else if (band == BAND_5G)
			bbp_val |= (0x1 << CR_AFE_BAND_BITS);

		/* Channel Rx DBM, -50dBm */
		mask = CR_CH_RX_DBM_MASK << CR_CH_RX_DBM_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x738 << CR_CH_RX_DBM_BITS);
		/* AFE AWGN Noise Enable */
		mask = CR_AFE_AWGN_NOISE_EN_MASK << CR_AFE_AWGN_NOISE_EN_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x0 << CR_AFE_AWGN_NOISE_EN_BITS);
		/* Channel type: Manual-Mode */
		mask = CR_CH_TYPE_MASK << CR_CH_TYPE_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x3F << CR_CH_TYPE_BITS);
		/* transpose mode enable */
		mask = CR_TRANSPOSE_MODE_EN_MASK << CR_TRANSPOSE_MODE_EN_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x0 << CR_TRANSPOSE_MODE_EN_BITS);
		/* Number of RX: 1 for AP, 4 for STA */
		mask = CR_N_RX_MASK << CR_N_RX_BITS;
		bbp_val &= (~mask);

		if (ap_mode)
			bbp_val |= (0x1 << CR_N_RX_BITS);
		else
			bbp_val |= (0x4 << CR_N_RX_BITS);

		/* Number of TX: 4 for AP, 1 for STA */
		mask = CR_N_TX_MASK << CR_N_TX_BITS;
		bbp_val &= (~mask);

		if (ap_mode)
			bbp_val |= (0x4 << CR_N_TX_BITS);
		else
			bbp_val |= (0x1 << CR_N_TX_BITS);

		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 2-1, Configure Rnd n Taps */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		bbp_cr = CR_CM_MAN_TAP_1_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		/* MAN rnd n taps, 1 */
		mask = CR_MAN_RND_N_TAP_MASK << CR_MAN_RND_N_TAP_BITS;
		bbp_val &= (~mask);
		bbp_val |= (0x1 << CR_MAN_RND_N_TAP_BITS);
	}

	/* Step 2-2, Configure MAN_profile1_mat */
	/* For High Correlation channel */
	if (high_corr == 1) {
		for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
			for (corr = 0; corr < 4; corr++) {
				bbp_cr = CR_CM_MAN_H00_CTRL + (cm_num * cm_cr_offset) + (corr * 4);
				print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
				PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
				MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
						 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
				mask = CR_MAN_RND_PROFILE1_RE_MASK << CR_MAN_RND_PROFILE1_RE_BITS;
				bbp_val &= (~mask);
				bbp_val |= (highcorr_channel_real[cm_num][corr] << CR_MAN_RND_PROFILE1_RE_BITS);
				mask = CR_MAN_RND_PROFILE1_IM_MASK << CR_MAN_RND_PROFILE1_IM_BITS;
				bbp_val &= (~mask);
				bbp_val |= (highcorr_channel_imag[cm_num][corr] << CR_MAN_RND_PROFILE1_IM_BITS);
			}
		}
	} else
		/* For Low Correlation channel */
	{
		for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
			for (corr = 0; corr < MAX_CORR; corr++) {
				bbp_cr = CR_CM_MAN_H00_CTRL + (cm_num * cm_cr_offset) + (corr * 4);
				print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
				PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
				MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
						 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
				mask = CR_MAN_RND_PROFILE1_RE_MASK << CR_MAN_RND_PROFILE1_RE_BITS;
				bbp_val &= (~mask);
				bbp_val |= (lowcorr_channel_real[cm_num][corr] << CR_MAN_RND_PROFILE1_RE_BITS);
				mask = CR_MAN_RND_PROFILE1_IM_MASK << CR_MAN_RND_PROFILE1_IM_BITS;
				bbp_val &= (~mask);
				bbp_val |= (lowcorr_channel_imag[cm_num][corr] << CR_MAN_RND_PROFILE1_IM_BITS);
			}
		}
	}

	/* Step 3, Configure channel ID */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		UINT32 seed;

		seed = 1 << (cm_num * 8);
		bbp_cr = CR_CM_CH_SEED_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_CH_ID_MASK << CR_CH_ID_BITS;
		bbp_val &= (~mask);
		bbp_val |= (seed << CR_CH_ID_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 4, Configure AFE seed */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		UINT32 seed;

		seed = 1 << (cm_num * 8);
		bbp_cr = CR_CM_AFE_SEED_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_AFE_SEED_MASK << CR_AFE_SEED_BITS;
		bbp_val &= (~mask);
		bbp_val |= (seed << CR_AFE_SEED_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 11, Set Noise level */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		bbp_cr = CR_CM_DC_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = CR_AFE_DC_NOISE_EN_MASK << CR_AFE_DC_NOISE_EN_BITS;
		bbp_val &= (~mask);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 13, take effect */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = (CR_CM_LOAD_EN_MASK << CR_CM_LOAD_EN_BITS) | (CR_CM_INTF_EN_MASK << CR_CM_INTF_EN_BITS);
		bbp_val &= (~mask);
		bbp_val |= (CR_CM_LOAD_EN_MASK << CR_CM_LOAD_EN_BITS) | (CR_CM_INTF_EN_MASK << CR_CM_INTF_EN_BITS);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	RtmpusecDelay(1);

	/* Step 15, pull LOAD_EN_BITS to low af */
	for (cm_num = start_cm; cm_num <= end_cm; cm_num++) {
		bbp_cr = CR_CM_TOP_CTRL + cm_num * cm_cr_offset;
		print_cr = (bbp_cr - WF_PHY_BASE) + 0x82070000;
		PHY_IO_READ32(pAd, bbp_cr, &bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\Read CR 0x%x = 0x%x\n", print_cr, bbp_val));
		mask = (CR_CM_LOAD_EN_MASK << CR_CM_LOAD_EN_BITS);
		bbp_val &= (~mask);
		PHY_IO_WRITE32(pAd, bbp_cr, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\write CR 0x%x = 0x%x\n", print_cr, bbp_val));
	}

	/* Step 14, delay for a while */
	RtmpusecDelay(100);
	return TRUE;
}
#endif


UINT32 bbp_performance_reg_pair[] = {
	/* CR */				/* mask */	/* bit */	/* 1R/2R */	/* 3R */		/* 4R */
	PHY_RXTD_58,		0x1ff,	9,		0x150,		0x14c,		0x14a,
	PHY_RXTD1_4,		0x7,	25,		0x0,		0x1,		0x0,
	PHY_RXTD1_1,		0x3f,	12,		0x13,		0x18,		0x12,
	PHY_LTFSYNC_6,		0x7,		0,		0x4,			0x3,			0x2,
	PHY_RXTD_44,		0x3f,	22,		0x17,		0x19,		0x17,
	PHY_RXTD_56,		0x3f,	6,		0x23,		0x26,		0x22,
	PHY_RXTD_CCKPD_3,	0x3f,	24,		0x8,			0x8,			0x8,
	PHY_RXTD_CCKPD_3,	0xf,		20,		0x8,			0x8,			0x8,
	PHY_RXTD_CCKPD_3,	0xf,		16,		0x8,			0x8,			0x8,
	PHY_RXTD_CCKPD_3,	0x3f,	10,		0xe,			0xd,			0xc,
	PHY_RXTD_CCKPD_3,	0x1f,	5,		0x10,		0x10,		0x10,
	PHY_RXTD_CCKPD_3,	0x1f,	0,		0x10,		0x10,		0x10,
	PHY_RXTD_CCKPD_4,	0x3f,	24,		0x1c,		0x14,		0x08,
	PHY_RXTD_CCKPD_4,	0x3f,	18,		0x1c,		0x1c,		0x1c,
	PHY_RXTD_CCKPD_4,	0x3f,	12,		0x3f,		0x3f,		0x3f,
	PHY_RXTD_CCKPD_4,	0x3f,	6,		0x1c,		0x1c,		0x1c,
	PHY_RXTD_CCKPD_4,	0x1f,	1,		0x10,		0x10,		0x10,
	PHY_RXTD_CCKPD_7,	0x3f,	1,		0x1c,		0x1c,		0x1c,
	PHY_RXTD1_1,		0x1f,	6,		0x21,		0x28,		0x29,
	PHY_RXTD1_1,		0x1f,	0,		0x21,		0x33,		0x35,
	PHY_RXTD1_0,		0x1f,	6,		0x23,		0x30,		0x31,
	PHY_RXTD1_0,		0x1f,	0,		0x23,		0x35,		0x39,
};


UINT32 bbp_workaround_reg_pair[] = {
	/* CR, mask, bit,	OFDM*/
	PHY_RXTD_BAND0_AGC_23_RX0,	0x3f,	14,	0x0c,
	PHY_RXTD_BAND0_AGC_23_RX1,	0x3f,	14,	0x0c,
	PHY_FSD_CTRL_1,					0x1,		0,	0x01,
	PHY_FSD_CTRL_1,					0x1,		1,	0x01,
	PHY_FSD_CTRL_1,					0x1,	15,	0x01,
	PHY_FSD_CTRL_1,					0x1,	23,	0x01,
	PHY_FSD_CTRL_1,					0x1,	31,	0x01,
	PHY_FSD_CTRL_1,					0x1f,	24,	0x1f,
	PHY_FSD_CTRL_1,					0x1f,	16,	0x1f,
	PHY_FSD_CTRL_1,					0x1f,	8,	0x1f,
	PHY_RXTD_CCKPD_4,				0x3f,	12,	0x0,
	PHY_RXTD_CCKPD_6,				0x3f,	12,	0x0,
	PHY_CTRL_TSSI_9,				0xffffffff,	0,	0x40800000,
	PHY_CTRL_WF1_TSSI_9,			0xffffffff,	0,	0x40800000,
	PHY_CTRL_WF2_TSSI_9,			0xffffffff,	0,	0x40800000,
	PHY_CTRL_WF3_TSSI_9,			0xffffffff,	0,	0x40800000,

	PHY_TX_BAND0_WF0_CR_TXFE_3,	0xf,	28,	0xf,
	PHY_TX_BAND0_WF1_CR_TXFE_3,	0xf,	28,	0xf,
	PHY_TX_BAND1_WF0_CR_TXFE_3,	0xf,	28,	0xf,
	PHY_TX_BAND1_WF1_CR_TXFE_3,	0xf,	28,	0xf,
	PHY_RXTD_43,					0x1,	31,	0x0,
};


UINT32 bbp_dot11v_setting[] = {
	/* CR */					/* Mask */	/* bit */	/* Value */
	PHY_RXTD_RXFE_01_B0,	0x1,		2,		0x1,
	PHY_RXTD_RXFE_01_B1,	0x1,		2,		0x1,
};


UINT32 bbp_txbf_setting[] = {
	/* CR */				/* Mask */	/* bit */ /* TxBF On*/		/* TxBF Off */
	PHY_PHYCK_CTRL,		0x7,	11,		0x7,				0x0,
	PHY_PHYCK_CTRL,		0x7,	27,		0x7,				0x0,
};
#endif /* PALLADIUM */


static VOID MT7663BBPInit(RTMP_ADAPTER *pAd)
{
	BOOLEAN isDBDC = FALSE, band_vld[2];
	INT idx, cbw[2] = {0};
	INT cent_ch[2] = {0}, prim_ch[2] = {0}, prim_ch_idx[2] = {0};
	INT band[2] = {0};
	INT txStream[2] = {0};
	UCHAR use_bands;

	band_vld[0] = TRUE;
	cbw[0] = RF_BW_20;
	cent_ch[0] = 1;
	prim_ch[0] = 1;
	band[0] = BAND_24G;
	txStream[0] = 2;
#ifdef DOT11_VHT_AC
	prim_ch_idx[0] = vht_prim_ch_idx(cent_ch[0], prim_ch[0], cbw[0]);
#endif /* DOT11_VHT_AC */

	if (isDBDC) {
		band_vld[1] = TRUE;
		band[1] = BAND_5G;
		cbw[1] = RF_BW_20;
		cent_ch[1] = 36;
		prim_ch[1] = 36;
#ifdef DOT11_VHT_AC
		prim_ch_idx[1] = vht_prim_ch_idx(cent_ch[1], prim_ch[1], cbw[1]);
#endif /* DOT11_VHT_AC */
		txStream[1] = 2;
		use_bands = 2;
	} else {
		band_vld[1] = FALSE;
		use_bands = 1;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("%s():BBP Initialization.....\n", __func__));

	for (idx = 0; idx < 2; idx++) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("\tBand %d: valid=%d, isDBDC=%d, Band=%d, CBW=%d, CentCh/PrimCh=%d/%d, prim_ch_idx=%d, txStream=%d\n",
				  idx, band_vld[idx], isDBDC, band[idx], cbw[idx], cent_ch[idx], prim_ch[idx],
				  prim_ch_idx[idx], txStream[idx]));
	}

#ifdef PALLADIUM

	if (pAd->fpga_ctl.run_palladium) {
		UINT32 bbp_reg, bbp_val, mask, bits, val;
		BOOLEAN bTxBF = TRUE, bDot11v = FALSE;
		/* UINT8 high_corr = 0; */
		/* INT cm_id = 0; */
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("%s(): Run in Palladium mode! Do BBP initialization....\n", __func__));
		/* PLL divider */
		PHY_IO_READ32(pAd, PHY_PHYSYS_CTRL, &bbp_val);
		bbp_val &= (~(0x3));
		PHY_IO_WRITE32(pAd, PHY_PHYSYS_CTRL, bbp_val);
		/* DBDC mode */
		PHY_IO_READ32(pAd, PHY_PHYSYS_CTRL, &bbp_val);

		if (isDBDC == TRUE)
			bbp_val |= (1 << 31);
		else
			bbp_val &= (~(1 << 31));

		PHY_IO_WRITE32(pAd, PHY_PHYSYS_CTRL, bbp_val);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("%s():isDBDC=%d, CBW[0]=%d,CBW[1]=%d\n", __func__, isDBDC, cbw[0], cbw[1]));

		/*
			[29:28]CR_BAND0_BAND: G band =0; A band=1;
			[27:24]CR_BAND0_CBW: BW20=0, BW40=1, BW80=2, BW160NC=7, BW160C=15;
			[22:20]CR_BAND0_PRI_CH: BW20=0, BW40=0/1, BW80=0/1/2/3, BW160NC/C=0/1/2/3/4/5/6/7

		*/
		for (idx = 0; idx < use_bands; idx++) {
			if (idx == 0)
				bbp_reg = PHY_BAND0_PHY_CTRL_0;
			else
				bbp_reg = PHY_BAND1_PHY_CTRL_0;

			/* band */
			PHY_IO_READ32(pAd, bbp_reg, &bbp_val);
			bbp_val &= (~(0x3 << 28));

			if (band[idx] == BAND_24G)
				bbp_val |= (0x0 << 28);
			else if (band[idx] == BAND_5G)
				bbp_val |= (0x1 << 28);

			PHY_IO_WRITE32(pAd, bbp_reg, bbp_val);
			/* CBW */
			PHY_IO_READ32(pAd, bbp_reg, &bbp_val);
			bbp_val &= (~(0xf << 24));

			switch (cbw[idx]) {
			case RF_BW_20:
				val = 0;
				break;

			case RF_BW_40:
				val = 1;
				break;

			case RF_BW_80:
				val = 2;
				break;

			case RF_BW_8080:
				val = 0x7;
				break;

			case RF_BW_160:
				val = 0xf;
				break;
			}

			bbp_val |= ((val & 0xf) << 24);
			PHY_IO_WRITE32(pAd, bbp_reg, bbp_val);
			/* Primary Channel */
			PHY_IO_READ32(pAd, bbp_reg, &bbp_val);
			bbp_val &= (~(0x7 << 24));
			bbp_val |= ((prim_ch_idx[idx] & 0x7) << 24);
			PHY_IO_WRITE32(pAd, bbp_reg, bbp_val);

			/*
				TX_FD1_ADDC
					Tx/Rx
					[30:30]
					[29:28]
			*/
			if (idx == 0) {
				PHY_IO_READ32(pAd, PHY_TXFD_1, &bbp_val);
				bbp_val &= (~(0xf << 28));
				bbp_val |= ((txStream[0] - 1) << 30);

				if (band_vld[1] == TRUE)
					bbp_val |= ((txStream[1] - 1) << 28);

				PHY_IO_WRITE32(pAd, PHY_TXFD_1, bbp_val);
			}

			/* CCK PD Enable */
			if (idx == 0)
				bbp_reg = PHY_RXTD_0;
			else
				bbp_reg = PHY_RXTD2_0;

			PHY_IO_READ32(pAd, bbp_reg, &bbp_val);
			bbp_val &= (~(0x1 << 21));

			if (band[idx] == BAND_24G)
				bbp_val |= (1 << 21);

			PHY_IO_WRITE32(pAd, bbp_reg, bbp_val);
		}

		/* Performance setting */
		for (idx = 0; idx < (sizeof(bbp_performance_reg_pair) / sizeof(UINT32)); idx += 6) {
			bbp_reg = bbp_performance_reg_pair[idx];
			bits = bbp_performance_reg_pair[idx + 2];
			mask = bbp_performance_reg_pair[idx + 1] << bits;
			PHY_IO_READ32(pAd, bbp_reg, &bbp_val);
			bbp_val &= (~mask);

			switch (txStream[0]) {
			case 1:
			case 2:
				bbp_val |= (bbp_performance_reg_pair[idx + 3] << bits);
				break;

			case 3:
				bbp_val |= (bbp_performance_reg_pair[idx + 4] << bits);
				break;

			case 4:
				bbp_val |= (bbp_performance_reg_pair[idx + 5] << bits);
				break;
			}

			PHY_IO_WRITE32(pAd, bbp_reg, bbp_val);
		}

		/* Work-around setting */
		for (idx = 0; idx < (sizeof(bbp_workaround_reg_pair) / sizeof(UINT32)); idx += 4) {
			bbp_reg = bbp_workaround_reg_pair[idx];
			bits = bbp_workaround_reg_pair[idx + 2];
			mask = bbp_workaround_reg_pair[idx + 1] << bits;
			PHY_IO_READ32(pAd, bbp_reg, &bbp_val);
			bbp_val &= (~mask);
			bbp_val |= (bbp_workaround_reg_pair[idx + 3] << bits);
			PHY_IO_WRITE32(pAd, bbp_reg, bbp_val);
		}

		/* 802.11 V setting if required */
		if (bDot11v == TRUE) {
			for (idx = 0; idx < (sizeof(bbp_dot11v_setting) / sizeof(UINT32)); idx += 4) {
				bbp_reg = bbp_dot11v_setting[idx];
				bits = bbp_dot11v_setting[idx + 2];
				mask = bbp_dot11v_setting[idx + 1] << bits;
				PHY_IO_READ32(pAd, bbp_reg, &bbp_val);
				bbp_val &= (~mask);
				bbp_val |= (bbp_dot11v_setting[idx + 3] << bits);
				PHY_IO_WRITE32(pAd, bbp_reg, bbp_val);
			}
		}

		/* TxBF setting if required */
		for (idx = 0; idx < (sizeof(bbp_txbf_setting) / sizeof(UINT32)); idx += 5) {
			bbp_reg = bbp_txbf_setting[idx];
			bits = bbp_txbf_setting[idx + 2];
			mask = bbp_txbf_setting[idx + 1] << bits;
			PHY_IO_READ32(pAd, bbp_reg, &bbp_val);
			bbp_val &= (~mask);

			if (bTxBF == TRUE)
				bbp_val |= (bbp_txbf_setting[idx + 3] << bits);
			else
				bbp_val |= (bbp_txbf_setting[idx + 4] << bits);

			PHY_IO_WRITE32(pAd, bbp_reg, bbp_val);
		}

#if 1
		MT7663_ChannelModelCfg(pAd, 0, 0, band[0]);
#endif
		/* MT7663_ChannelModelCfg(pAd, 0xff, 0, band[0]); */
		/* TODO: For MU-MIMO, Disable the line above. */
		/* MT7615_MuChannelModelCfg(pAd, cm_id, high_corr, re_init, band); */
		/* cm_id: speed bridge channel id for STA mode; reserved for AP mode */
		/* high_corr: 1 for high correlation channel model; 0 for low correlation channel model. */
		/* re_init: 1 for reinitialize; 0 for initialize. */
		/* band: 1 for 5 GHz; 2 for 2.4 GHz. */
		/* Enable below line with proper values. */
		/* RTMP_IO_READ32(pAd, (0x2708), &cm_id); */
		/* printk("channel id %x\n...\n",PHY_IO_READ32(pAd, (WF_PHY_BASE + 0x2708))); */
		/* cmd_id =4; */
#if 0
		RTMP_IO_READ32(pAd, 0x2708, &cm_id);
		high_corr = 0;
		MT7663_MuChannelModelCfg(pAd, cm_id, high_corr, 0, 1);
#endif
	}

#endif /* PALLADIUM */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s() todo\n", __func__));
}


static void mt7663_init_rf_cr(RTMP_ADAPTER *ad)
{
}


int mt7663_read_chl_pwr(RTMP_ADAPTER *pAd)
{
	return TRUE;
}


/* Read power per rate */
void mt7663_get_tx_pwr_per_rate(RTMP_ADAPTER *pAd)
{
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s() todo\n", __func__));
}


void mt7663_get_tx_pwr_info(RTMP_ADAPTER *pAd)
{
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s() todo\n", __func__));
}


static void mt7663_antenna_default_reset(
	struct _RTMP_ADAPTER *pAd,
	EEPROM_ANTENNA_STRUC *pAntenna)
{
	/* TODO: shiang-MT7615 */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s() todo\n", __func__));
	pAntenna->word = 0;
	pAd->RfIcType = RFIC_7663;
#ifndef TXBF_SUPPORT
	pAntenna->field.TxPath = 2;
	pAntenna->field.RxPath = 2;
#else
	pAntenna->field.TxPath = (pAd->EEPROMDefaultValue[EEPROM_NIC_CFG1_OFFSET] >> 4) & 0x0F;
	pAntenna->field.RxPath = pAd->EEPROMDefaultValue[EEPROM_NIC_CFG1_OFFSET] & 0x0F;
#endif /* TXBF_SUPPORT */
}


static VOID mt7663_fw_prepare(RTMP_ADAPTER *pAd)
{
	struct fwdl_ctrl *ctrl = &pAd->MCUCtrl.fwdl_ctrl;

#ifdef NEED_ROM_PATCH
	if (IS_MT7663_FW_VER_E1(pAd)) {
		ctrl->patch_profile[WM_CPU].source.header_ptr = mt7663_rom_patch_e1;
		ctrl->patch_profile[WM_CPU].source.header_len = sizeof(mt7663_rom_patch_e1);
		ctrl->patch_profile[WM_CPU].source.bin_name = MT7663_ROM_PATCH_BIN_FILE_NAME_E1;
	} else {
		/* Use E1 rom patch as default */
		ctrl->patch_profile[WM_CPU].source.header_ptr = mt7663_rom_patch_e1;
		ctrl->patch_profile[WM_CPU].source.header_len = sizeof(mt7663_rom_patch_e1);
		ctrl->patch_profile[WM_CPU].source.bin_name = MT7663_ROM_PATCH_BIN_FILE_NAME_E1;
	}
#endif /* NEED_ROM_PATCH */

	ctrl->fw_profile[WM_CPU].source.header_ptr = MT7663_FirmwareImage;
	ctrl->fw_profile[WM_CPU].source.header_len = sizeof(MT7663_FirmwareImage);
	ctrl->fw_profile[WM_CPU].source.bin_name = MT7663_BIN_FILE_NAME;
}

static VOID mt7663_fwdl_datapath_setup(RTMP_ADAPTER *pAd, BOOLEAN init)
{
	WPDMA_GLO_CFG_STRUC GloCfg;

	if (init == TRUE) {
		HIF_IO_READ32(pAd, MT_WPDMA_GLO_CFG, &GloCfg.word);
		GloCfg.MT7622_field.fw_ring_bp_tx_sch = 1;
		HIF_IO_WRITE32(pAd, MT_WPDMA_GLO_CFG, GloCfg.word);

		pAd->chipOps.pci_kick_out_cmd_msg = AndesMTPciKickOutCmdMsgFwDlRing;
	} else {
		pAd->chipOps.pci_kick_out_cmd_msg = AndesMTPciKickOutCmdMsg;

		HIF_IO_READ32(pAd, MT_WPDMA_GLO_CFG, &GloCfg.word);
		GloCfg.MT7622_field.fw_ring_bp_tx_sch = 0;
		HIF_IO_WRITE32(pAd, MT_WPDMA_GLO_CFG, GloCfg.word);
	}
}

#ifdef CONFIG_STA_SUPPORT
static VOID mt7663_init_dev_nick_name(RTMP_ADAPTER *ad)
{
	snprintf((RTMP_STRING *) ad->nickname, sizeof(ad->nickname), "mt7663_sta");
}
#endif /* CONFIG_STA_SUPPORT */


#ifdef TXBF_SUPPORT
void mt7663_setETxBFCap(
	IN  RTMP_ADAPTER      *pAd,
	IN  TXBF_STATUS_INFO * pTxBfInfo)
{
	HT_BF_CAP *pTxBFCap = pTxBfInfo->pHtTxBFCap;

	if (pTxBfInfo->cmmCfgETxBfEnCond > 0) {
		switch (pTxBfInfo->cmmCfgETxBfEnCond) {
		case SUBF_ALL:
		default:
			pTxBFCap->RxNDPCapable         = TRUE;
			pTxBFCap->TxNDPCapable         = (pTxBfInfo->ucRxPathNum > 1) ? TRUE : FALSE;
			pTxBFCap->ExpNoComSteerCapable = FALSE;
			pTxBFCap->ExpComSteerCapable   = TRUE;/* !pTxBfInfo->cmmCfgETxBfNoncompress; */
			pTxBFCap->ExpNoComBF           = 0; /* HT_ExBF_FB_CAP_IMMEDIATE; */
			pTxBFCap->ExpComBF             =
				HT_ExBF_FB_CAP_IMMEDIATE;/* pTxBfInfo->cmmCfgETxBfNoncompress? HT_ExBF_FB_CAP_NONE: HT_ExBF_FB_CAP_IMMEDIATE; */
			pTxBFCap->MinGrouping          = 3;
			pTxBFCap->NoComSteerBFAntSup   = 0;
			pTxBFCap->ComSteerBFAntSup     = 3;
			pTxBFCap->TxSoundCapable       = FALSE;  /* Support staggered sounding frames */
			pTxBFCap->ChanEstimation       = pTxBfInfo->ucRxPathNum - 1;
			break;

		case SUBF_BFER:
			pTxBFCap->RxNDPCapable         = FALSE;
			pTxBFCap->TxNDPCapable         = (pTxBfInfo->ucRxPathNum > 1) ? TRUE : FALSE;
			pTxBFCap->ExpNoComSteerCapable = FALSE;
			pTxBFCap->ExpComSteerCapable   = TRUE;/* !pTxBfInfo->cmmCfgETxBfNoncompress; */
			pTxBFCap->ExpNoComBF           = 0; /* HT_ExBF_FB_CAP_IMMEDIATE; */
			pTxBFCap->ExpComBF             =
				HT_ExBF_FB_CAP_IMMEDIATE;/* pTxBfInfo->cmmCfgETxBfNoncompress? HT_ExBF_FB_CAP_NONE: HT_ExBF_FB_CAP_IMMEDIATE; */
			pTxBFCap->MinGrouping          = 3;
			pTxBFCap->NoComSteerBFAntSup   = 0;
			pTxBFCap->ComSteerBFAntSup     = 3;
			pTxBFCap->TxSoundCapable       = FALSE;  /* Support staggered sounding frames */
			pTxBFCap->ChanEstimation       = pTxBfInfo->ucRxPathNum - 1;
			break;

		case SUBF_BFEE:
			pTxBFCap->RxNDPCapable         = TRUE;
			pTxBFCap->TxNDPCapable         = FALSE;
			pTxBFCap->ExpNoComSteerCapable = FALSE;
			pTxBFCap->ExpComSteerCapable   = TRUE;/* !pTxBfInfo->cmmCfgETxBfNoncompress; */
			pTxBFCap->ExpNoComBF           = 0; /* HT_ExBF_FB_CAP_IMMEDIATE; */
			pTxBFCap->ExpComBF             =
				HT_ExBF_FB_CAP_IMMEDIATE;/* pTxBfInfo->cmmCfgETxBfNoncompress? HT_ExBF_FB_CAP_NONE: HT_ExBF_FB_CAP_IMMEDIATE; */
			pTxBFCap->MinGrouping          = 3;
			pTxBFCap->NoComSteerBFAntSup   = 0;
			pTxBFCap->ComSteerBFAntSup     = 3;
			pTxBFCap->TxSoundCapable       = FALSE;  /* Support staggered sounding frames */
			pTxBFCap->ChanEstimation       = pTxBfInfo->ucRxPathNum - 1;
			break;
		}
	} else
		memset(pTxBFCap, 0, sizeof(*pTxBFCap));
}

#ifdef VHT_TXBF_SUPPORT
void mt7663_setVHTETxBFCap(
	IN  RTMP_ADAPTER *pAd,
	IN  TXBF_STATUS_INFO * pTxBfInfo)
{
	VHT_CAP_INFO *pTxBFCap = pTxBfInfo->pVhtTxBFCap;

	/*
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
		("%s: cmmCfgETxBfEnCond = %d\n", __FUNCTION__, (UCHAR)pTxBfInfo->cmmCfgETxBfEnCond));
	*/

	if (pTxBfInfo->cmmCfgETxBfEnCond > 0) {
		switch (pTxBfInfo->cmmCfgETxBfEnCond) {
		case SUBF_ALL:
		default:
			pTxBFCap->bfee_cap_su       = 1;
			pTxBFCap->bfer_cap_su       = (pTxBfInfo->ucTxPathNum > 1) ? 1 : 0;
#ifdef CFG_SUPPORT_MU_MIMO

			switch (pAd->CommonCfg.MUTxRxEnable) {
			case MUBF_OFF:
				pTxBFCap->bfee_cap_mu = 0;
				pTxBFCap->bfer_cap_mu = 0;
				break;

			case MUBF_BFER:
				pTxBFCap->bfee_cap_mu = 0;
				pTxBFCap->bfer_cap_mu = (pTxBfInfo->ucTxPathNum > 1) ? 1 : 0;
				break;

			case MUBF_BFEE:
				pTxBFCap->bfee_cap_mu = 1;
				pTxBFCap->bfer_cap_mu = 0;
				break;

			case MUBF_ALL:
				pTxBFCap->bfee_cap_mu = 1;
				pTxBFCap->bfer_cap_mu = (pTxBfInfo->ucTxPathNum > 1) ? 1 : 0;
				break;

			default:
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					("%s: set wrong parameters\n", __func__));
				break;
			}

#else
			pTxBFCap->bfee_cap_mu = 0;
			pTxBFCap->bfer_cap_mu = 0;
#endif /* CFG_SUPPORT_MU_MIMO */
			pTxBFCap->bfee_sts_cap      = 3;
			pTxBFCap->num_snd_dimension = pTxBfInfo->ucTxPathNum - 1;
			break;

		case SUBF_BFER:
			pTxBFCap->bfee_cap_su       = 0;
			pTxBFCap->bfer_cap_su       = (pTxBfInfo->ucTxPathNum > 1) ? 1 : 0;
#ifdef CFG_SUPPORT_MU_MIMO

			switch (pAd->CommonCfg.MUTxRxEnable) {
			case MUBF_OFF:
				pTxBFCap->bfee_cap_mu = 0;
				pTxBFCap->bfer_cap_mu = 0;
				break;

			case MUBF_BFER:
				pTxBFCap->bfee_cap_mu = 0;
				pTxBFCap->bfer_cap_mu = (pTxBfInfo->ucTxPathNum > 1) ? 1 : 0;
				break;

			case MUBF_BFEE:
				pTxBFCap->bfee_cap_mu = 0;
				pTxBFCap->bfer_cap_mu = 0;
				break;

			case MUBF_ALL:
				pTxBFCap->bfee_cap_mu = 0;
				pTxBFCap->bfer_cap_mu = (pTxBfInfo->ucTxPathNum > 1) ? 1 : 0;
				break;

			default:
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					("%s: set wrong parameters\n", __func__));
				break;
			}

#else
			pTxBFCap->bfee_cap_mu = 0;
			pTxBFCap->bfer_cap_mu = 0;
#endif /* CFG_SUPPORT_MU_MIMO */
			pTxBFCap->bfee_sts_cap      = 0;
			pTxBFCap->num_snd_dimension = pTxBfInfo->ucTxPathNum - 1;
			break;

		case SUBF_BFEE:
			pTxBFCap->bfee_cap_su       = 1;
			pTxBFCap->bfer_cap_su       = 0;
#ifdef CFG_SUPPORT_MU_MIMO

			switch (pAd->CommonCfg.MUTxRxEnable) {
			case MUBF_OFF:
				pTxBFCap->bfee_cap_mu = 0;
				pTxBFCap->bfer_cap_mu = 0;
				break;

			case MUBF_BFER:
				pTxBFCap->bfee_cap_mu = 0;
				pTxBFCap->bfer_cap_mu = 0;
				break;

			case MUBF_BFEE:
				pTxBFCap->bfee_cap_mu = 1;
				pTxBFCap->bfer_cap_mu = 0;
				break;

			case MUBF_ALL:
				pTxBFCap->bfee_cap_mu = 1;
				pTxBFCap->bfer_cap_mu = 0;
				break;

			default:
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					("%s: set wrong parameters\n", __func__));
				break;
			}

#else
			pTxBFCap->bfee_cap_mu = 0;
			pTxBFCap->bfer_cap_mu = 0;
#endif /* CFG_SUPPORT_MU_MIMO */
			pTxBFCap->bfee_sts_cap      = 3;
			pTxBFCap->num_snd_dimension = pTxBfInfo->ucTxPathNum - 1;
			break;
		}
	} else {
		pTxBFCap->num_snd_dimension = 0;
		pTxBFCap->bfee_cap_mu       = 0;
		pTxBFCap->bfee_cap_su       = 0;
		pTxBFCap->bfer_cap_mu       = 0;
		pTxBFCap->bfer_cap_su       = 0;
		pTxBFCap->bfee_sts_cap      = 0;
	}
}

#endif /* VHT_TXBF_SUPPORT */
#endif /* TXBF_SUPPORT */

static struct dly_ctl_cfg mt7663_rx_dly_ctl_ul_tbl[] = {
	{0, 0x811c},
	{300, 0xa01c},
	{500, 0xc01f},
};

static struct dly_ctl_cfg mt7663_rx_dly_ctl_dl_tbl[] = {
	{0, 0x811c},
};

static RTMP_CHIP_OP MT7663_ChipOp = {0};
static RTMP_CHIP_CAP MT7663_ChipCap = {0};


static VOID mt7663_chipCap_init(void)
{
	MT7663_ChipCap.TXWISize = sizeof(TMAC_TXD_L); /* 32 */
	MT7663_ChipCap.RXWISize = 28;
	MT7663_ChipCap.tx_hw_hdr_len = MT7663_ChipCap.TXWISize;/* + sizeof(CR4_TXP_MSDU_INFO); */
	MT7663_ChipCap.rx_hw_hdr_len = MT7663_ChipCap.RXWISize;
	MT7663_ChipCap.num_of_tx_ring = 12;
	MT7663_ChipCap.num_of_rx_ring = 2;
	MT7663_ChipCap.tx_ring_size = 512;
	MT7663_ChipCap.rx0_ring_size = 512;
	MT7663_ChipCap.rx1_ring_size = 512;
	MT7663_ChipCap.asic_caps = (fASIC_CAP_PMF_ENC | fASIC_CAP_MCS_LUT
				    | fASIC_CAP_CT | fASIC_CAP_HW_DAMSDU);
#ifdef G_BAND_256QAM
	MT7663_ChipCap.g_band_256_qam = TRUE;
#endif
#ifdef RX_CUT_THROUGH
	MT7663_ChipCap.asic_caps |= fASIC_CAP_BA_OFFLOAD;
#endif
#ifdef HDR_TRANS_TX_SUPPORT
	MT7663_ChipCap.asic_caps |= fASIC_CAP_TX_HDR_TRANS;
#endif
#ifdef HDR_TRANS_RX_SUPPORT
	MT7663_ChipCap.asic_caps |= fASIC_CAP_RX_HDR_TRANS;
#endif
#ifdef CONFIG_CSO_SUPPORT
	MT7663_ChipCap.asic_caps |= fASIC_CAP_CSO;
#endif
#ifdef RX_SCATTER
	MT7663_ChipCap.asic_caps |= fASIC_CAP_RX_DMA_SCATTER;
#endif

	MT7663_ChipCap.asic_caps |= fASIC_CAP_RX_DLY;

	MT7663_ChipCap.phy_caps = (fPHY_CAP_24G | fPHY_CAP_5G | \
							   fPHY_CAP_HT | fPHY_CAP_VHT | \
							   fPHY_CAP_TXBF | fPHY_CAP_LDPC | fPHY_CAP_MUMIMO | \
							   fPHY_CAP_BW40 | fPHY_CAP_BW80 | fPHY_CAP_BW160C | fPHY_CAP_BW160NC);

	MT7663_ChipCap.hw_ops_ver = HWCTRL_OP_TYPE_V2;
	MT7663_ChipCap.hif_type = HIF_MT;
	MT7663_ChipCap.mac_type = MAC_MT;
	MT7663_ChipCap.MCUType = ANDES;
	MT7663_ChipCap.rf_type = RF_MT;
	MT7663_ChipCap.pRFRegTable = NULL;
	MT7663_ChipCap.pBBPRegTable = NULL;
	MT7663_ChipCap.bbpRegTbSize = 0;
	MT7663_ChipCap.MaxNumOfRfId = MAX_RF_ID;
	MT7663_ChipCap.MaxNumOfBbpId = 200;
	MT7663_ChipCap.WtblHwNum = MT7663_MT_WTBL_SIZE;
	MT7663_ChipCap.FlgIsHwWapiSup = TRUE;
	MT7663_ChipCap.FlgIsHwAntennaDiversitySup = FALSE;
#ifdef STREAM_MODE_SUPPORT
	MT7663_ChipCap.FlgHwStreamMode = FALSE;
#endif
#ifdef TXBF_SUPPORT
	MT7663_ChipCap.FlgHwTxBfCap = TXBF_HW_CAP;
#endif
	MT7663_ChipCap.SnrFormula = SNR_FORMULA4;
	MT7663_ChipCap.max_nss = 4;
	/* todo Ellis */
#ifdef RTMP_EFUSE_SUPPORT
	MT7663_ChipCap.EFUSE_USAGE_MAP_START = 0x3c0;
	MT7663_ChipCap.EFUSE_USAGE_MAP_END = 0x3fb;
	MT7663_ChipCap.EFUSE_USAGE_MAP_SIZE = 60;
	MT7663_ChipCap.EFUSE_RESERVED_SIZE = 59;	/* Cal-Free is 22 free block */
#endif
	MT7663_ChipCap.EEPROM_DEFAULT_BIN = MT7663_E2PImage;
	MT7663_ChipCap.EEPROM_DEFAULT_BIN_SIZE = sizeof(MT7663_E2PImage);
	MT7663_ChipCap.EFUSE_BUFFER_CONTENT_SIZE = 0x378;
#ifdef CARRIER_DETECTION_SUPPORT
	MT7663_ChipCap.carrier_func = TONE_RADAR_V2;
#endif
#ifdef RTMP_MAC_PCI
	MT7663_ChipCap.WPDMABurstSIZE = 3;
#endif
#ifdef NEW_MBSSID_MODE
#ifdef ENHANCE_NEW_MBSSID_MODE
	MT7663_ChipCap.MBSSIDMode = MBSSID_MODE4;
#else
	MT7663_ChipCap.MBSSIDMode = MBSSID_MODE1;
#endif /* ENHANCE_NEW_MBSSID_MODE */
#else
	MT7663_ChipCap.MBSSIDMode = MBSSID_MODE0;
#endif /* NEW_MBSSID_MODE */
#ifdef DOT11W_PMF_SUPPORT
	/* sync with Ellis, wilsonl */
	MT7663_ChipCap.FlgPMFEncrtptMode = PMF_ENCRYPT_MODE_2;
#endif /* DOT11W_PMF_SUPPORT */
#ifdef CONFIG_ANDES_SUPPORT
#ifdef NEED_ROM_PATCH
	MT7663_ChipCap.need_load_patch = BIT(WM_CPU);
#else
	MT7663_ChipCap.need_load_patch = 0;
#endif
	MT7663_ChipCap.need_load_fw = BIT(WM_CPU);
	MT7663_ChipCap.load_patch_flow = PATCH_FLOW_V1;
	MT7663_ChipCap.load_fw_flow = FW_FLOW_V1; /*FW_FLOW_V2_COMPRESS_IMG;*/
	MT7663_ChipCap.patch_format = PATCH_FORMAT_V1;
	MT7663_ChipCap.fw_format = FW_FORMAT_V3;
	MT7663_ChipCap.load_patch_method = BIT(HEADER_METHOD);
	MT7663_ChipCap.load_fw_method = BIT(HEADER_METHOD);
	MT7663_ChipCap.rom_patch_offset = MT7663_ROM_PATCH_START_ADDRESS;
	MT7663_ChipCap.decompress_tmp_addr = 0x203b000UL;
#endif
#ifdef UNIFY_FW_CMD /* todo wilsonl */
	MT7663_ChipCap.cmd_header_len = sizeof(FW_TXD) + sizeof(TMAC_TXD_L);
#else
	MT7663_ChipCap.cmd_header_len = 12; /* sizeof(FW_TXD) */
#endif
	MT7663_ChipCap.cmd_padding_len = 0;
	MT7663_ChipCap.TxAggLimit = 64;
	MT7663_ChipCap.RxBAWinSize = 64;
	MT7663_ChipCap.ht_max_ampdu_len_exp = 3;
#ifdef DOT11_VHT_AC
	MT7663_ChipCap.max_mpdu_len = MPDU_7991_OCTETS;
	MT7663_ChipCap.vht_max_ampdu_len_exp = 7;
#endif /* DOT11_VHT_AC */
#ifdef RACTRL_FW_OFFLOAD_SUPPORT
	/* enabled later, wilsonl */
	MT7663_ChipCap.fgRateAdaptFWOffload = TRUE;
#endif /* RACTRL_FW_OFFLOAD_SUPPORT */
	MT7663_ChipCap.WmmHwNum = MT7663_MT_WMM_SIZE; /* for multi-wmm */
	MT7663_ChipCap.PDA_PORT = MT7663_PDA_PORT;
	MT7663_ChipCap.SupportAMSDU = TRUE;
	/* sync with Pat, wilsonl */
	MT7663_ChipCap.APPSMode = APPS_MODE2;
	MT7663_ChipCap.CtParseLen = MT7663_CT_PARSE_LEN;
	MT7663_ChipCap.qm = GENERIC_QM;
	MT7663_ChipCap.qm_tm = TASKLET_METHOD;
	MT7663_ChipCap.hif_tm = TASKLET_METHOD;
	MT7663_ChipCap.wmm_detect_method = WMM_DETECT_METHOD1;
	/* for interrupt enable mask */
	MT7663_ChipCap.int_enable_mask = MT_CoherentInt | MT_MacInt | MT_INT_RX_DLY |
					MT_INT_T3_DONE | MT_INT_T15_DONE | MT_FW_CLR_OWN_INT;

	MT7663_ChipCap.hif_pkt_type[HIF_TX_IDX0] = TX_DATA;
	MT7663_ChipCap.hif_pkt_type[HIF_TX_IDX1] = TX_DATA;
	MT7663_ChipCap.hif_pkt_type[HIF_TX_IDX2] = TX_DATA;
	MT7663_ChipCap.hif_pkt_type[HIF_TX_IDX3] = TX_FW_DL;
	MT7663_ChipCap.hif_pkt_type[HIF_TX_IDX4] = TX_DATA;
	MT7663_ChipCap.hif_pkt_type[HIF_TX_IDX5] = TX_ALTX;
	MT7663_ChipCap.hif_pkt_type[HIF_TX_IDX15] = TX_CMD;

#if defined(ERR_RECOVERY) || defined(CONFIG_FWOWN_SUPPORT)
	MT7663_ChipCap.int_enable_mask |= MT_McuCommand;
#endif /* ERR_RECOVERY || CONFIG_FWOWN_SUPPORT */
	MT7663_ChipCap.band_cnt = 1;
#ifdef HW_TX_AMSDU_SUPPORT
	MT7663_ChipCap.asic_caps |= fASIC_CAP_HW_TX_AMSDU;
#endif /* HW_TX_AMSDU_SUPPORT */
#ifdef INTERNAL_CAPTURE_SUPPORT
	MT7663_ChipCap.pICapDesc = MT7663_ICAP_DESC;
	MT7663_ChipCap.ICapBankNum = MT7663_ICapBankNum;
	MT7663_ChipCap.ICapADCIQCnt = MT7663_ICAP_FOUR_WAY_ADC_IQ_DATA_CNT;
	MT7663_ChipCap.ICapIQCIQCnt = MT7663_ICAP_FOUR_WAY_IQC_IQ_DATA_CNT;
	MT7663_ChipCap.ICapBankSmplCnt = MT7663_ICAP_BANK_SAMPLE_CNT;
#endif /* INTERNAL_CAPTURE_SUPPORT */
#ifdef WIFI_SPECTRUM_SUPPORT
	MT7663_ChipCap.pSpectrumDesc = MT7663_SPECTRUM_DESC;
	MT7663_ChipCap.SpectrumBankNum = MT7663_SpectrumBankNum;
#endif /* WIFI_SPECTRUM_SUPPORT */
	MT7663_ChipCap.txd_type = TXD_V2;
	MT7663_ChipCap.ba_range = mt7663_ba_range;
}


static VOID mt7663_chipOp_init(void)
{
	MT7663_ChipOp.AsicRfInit = mt7663_init_rf_cr;
	MT7663_ChipOp.AsicBbpInit = MT7663BBPInit;
	MT7663_ChipOp.AsicMacInit = mt7663_init_mac_cr;
	MT7663_ChipOp.AsicRfTurnOn = NULL;
	MT7663_ChipOp.AsicRfTurnOff = NULL;
	MT7663_ChipOp.AsicReverseRfFromSleepMode = NULL;
	MT7663_ChipOp.AsicHaltAction = NULL;
	/* Chip tuning */
	MT7663_ChipOp.RxSensitivityTuning = NULL;
	/* BBP adjust */
	MT7663_ChipOp.ChipBBPAdjust = mt7663_bbp_adjust;
	/* AGC */
	MT7663_ChipOp.ChipAGCInit = NULL;
#ifdef CONFIG_STA_SUPPORT
	MT7663_ChipOp.ChipAGCAdjust = NULL;
#endif
	MT7663_ChipOp.ChipSwitchChannel = mt7663_switch_channel;
#ifdef NEW_SET_RX_STREAM
	MT7663_ChipOp.ChipSetRxStream = mt7663_set_RxStream;
#endif
	MT7663_ChipOp.AsicAntennaDefaultReset = mt7663_antenna_default_reset;
#ifdef CONFIG_STA_SUPPORT
	MT7663_ChipOp.NetDevNickNameInit = mt7663_init_dev_nick_name;
#endif
#ifdef CAL_FREE_IC_SUPPORT
	/* do not need, turn off compile flag, wilsonl */
	MT7663_ChipOp.is_cal_free_ic = mt7663_is_cal_free_ic;
	MT7663_ChipOp.cal_free_data_get = mt7663_cal_free_data_get;
#endif /* CAL_FREE_IC_SUPPORT */
#ifdef CARRIER_DETECTION_SUPPORT
	MT7663_ChipOp.ToneRadarProgram = ToneRadarProgram_v2;
#endif
	MT7663_ChipOp.DisableTxRx = NULL; /* 302 */
#ifdef RTMP_PCI_SUPPORT
	/* sync with Pat, Hammin, wilsonl */
	/* MT7663_ChipOp.AsicRadioOn = RT28xxPciAsicRadioOn; */
	/* MT7663_ChipOp.AsicRadioOff = RT28xxPciAsicRadioOff; */
#endif
#ifdef MT_WOW_SUPPORT
	/* do not need, turn off compile flag, wilsonl */
	MT7663_ChipOp.AsicWOWEnable = MT76xxAndesWOWEnable;
	MT7663_ChipOp.AsicWOWDisable = MT76xxAndesWOWDisable;
	/* MT7663_ChipOp.AsicWOWInit = MT76xxAndesWOWInit, */
#endif /* MT_WOW_SUPPORT */
	MT7663_ChipOp.show_pwr_info = NULL;
	MT7663_ChipOp.bufferModeEfuseFill = mt7663_bufferModeEfuseFill;
	MT7663_ChipOp.MtCmdTx = MtCmdSendMsg;
	MT7663_ChipOp.prepare_fwdl_img = mt7663_fw_prepare;
	MT7663_ChipOp.fwdl_datapath_setup = mt7663_fwdl_datapath_setup;
#ifdef TXBF_SUPPORT
	MT7663_ChipOp.TxBFInit                 = mt_WrapTxBFInit;
	MT7663_ChipOp.ClientSupportsETxBF      = mt_WrapClientSupportsETxBF;
	MT7663_ChipOp.setETxBFCap              = mt7663_setETxBFCap;
	MT7663_ChipOp.BfStaRecUpdate           = mt_AsicBfStaRecUpdate;
	MT7663_ChipOp.BfStaRecRelease          = mt_AsicBfStaRecRelease;
	MT7663_ChipOp.BfPfmuMemAlloc           = CmdPfmuMemAlloc;
	MT7663_ChipOp.BfPfmuMemRelease         = CmdPfmuMemRelease;
	MT7663_ChipOp.TxBfTxApplyCtrl          = CmdTxBfTxApplyCtrl;
	MT7663_ChipOp.BfApClientCluster        = CmdTxBfApClientCluster;
	MT7663_ChipOp.BfHwEnStatusUpdate       = CmdTxBfHwEnableStatusUpdate;
#ifdef CONFIG_STA_SUPPORT
	MT7663_ChipOp.archSetAid               = MtAsicSetAid;
#endif /* CONFIG_STA_SUPPORT */
#ifdef VHT_TXBF_SUPPORT
	MT7663_ChipOp.ClientSupportsVhtETxBF     = mt_WrapClientSupportsVhtETxBF;
	MT7663_ChipOp.setVHTETxBFCap             = mt7663_setVHTETxBFCap;
#endif /* VHT_TXBF_SUPPORT */
#ifdef INTERNAL_CAPTURE_SUPPORT
	MT7663_ChipOp.ICapStart = MtCmdRfTestICapStart;
	MT7663_ChipOp.ICapStatus = MtCmdRfTestGen2ICapStatus;
	MT7663_ChipOp.ICapCmdRawDataProc = MtCmdRfTestICapRawDataProc;
	MT7663_ChipOp.ICapGetIQData = Get_RBIST_IQ_Data;
	MT7663_ChipOp.ICapEventRawDataHandler = ExtEventICap96BitRawDataHandler;
#endif /* INTERNAL_CAPTURE_SUPPORT */
#ifdef WIFI_SPECTRUM_SUPPORT
	MT7663_ChipOp.SpectrumStart = MtCmdWifiSpectrumStart;
	MT7663_ChipOp.SpectrumStatus = MtCmdWifiSpectrumGen2Status;
	MT7663_ChipOp.SpectrumCmdRawDataProc = MtCmdWifiSpectrumRawDataProc;
	MT7663_ChipOp.SpectrumEventRawDataHandler = ExtEventWifiSpectrumRawDataHandler;
#endif /* WIFI_SPECTRUM_SUPPORT */
#endif /* TXBF_SUPPORT */
	MT7663_ChipOp.dma_shdl_init = mt7663_dma_shdl_init;
#ifdef MT7663_FPGA
	MT7663_ChipOp.chk_hif_default_cr_setting = mt7663_chk_hif_default_cr_setting;
	MT7663_ChipOp.chk_top_default_cr_setting = mt7663_chk_top_default_cr_setting;
#endif
}


VOID mt7663_init(RTMP_ADAPTER *pAd)
{
	RTMP_CHIP_CAP *pChipCap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);
	struct _RTMP_CHIP_DBG *chip_dbg = hc_get_chip_dbg(pAd->hdev_ctrl);
	struct tr_delay_control *tr_delay_ctl = &pAd->tr_ctl.tr_delay_ctl;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
	mt7663_chipCap_init();
	mt7663_chipOp_init();
	NdisMoveMemory(pChipCap, &MT7663_ChipCap, sizeof(RTMP_CHIP_CAP));
	NdisMoveMemory(ops, &MT7663_ChipOp, sizeof(RTMP_CHIP_OP));
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
	mt7663AsicArchOpsInit(pAd);
#endif
	mt7663_chip_dbg_init(chip_dbg);
	mt_phy_probe(pAd);
	RTMP_DRS_ALG_INIT(pAd, RATE_ALG_AGBS);
	/* Following function configure beacon related parameters in pChipCap
	 * FlgIsSupSpecBcnBuf / BcnMaxHwNum / WcidHwRsvNum / BcnMaxHwSize / BcnBase[]
	 */
	/* sync with Cater, wilsonl */
	mt_chip_bcn_parameter_init(pAd);
	/* sync with Cater, wilsonl */
	pChipCap->OmacNums = 5;
	pChipCap->BssNums = 4;
	pChipCap->ExtMbssOmacStartIdx = 0x10;
	pChipCap->RepeaterStartIdx = 0x20;
#ifdef AIR_MONITOR
	pChipCap->MaxRepeaterNum = 16;
#else
	pChipCap->MaxRepeaterNum = 24;
#endif /* AIR_MONITOR */

#ifdef BCN_OFFLOAD_SUPPORT
	pChipCap->fgBcnOffloadSupport = TRUE;
	pChipCap->fgIsNeedPretbttIntEvent = FALSE;
#endif
	/* For calibration log buffer size limitation issue */
	pAd->fgQAtoolBatchDumpSupport = TRUE;
#ifdef RED_SUPPORT
	pAd->red_have_cr4 = FALSE;
#endif /* RED_SUPPORT */

	tr_delay_ctl->ul_rx_dly_ctl_tbl = mt7663_rx_dly_ctl_ul_tbl;
	tr_delay_ctl->ul_rx_dly_ctl_tbl_size = (sizeof(mt7663_rx_dly_ctl_ul_tbl) / sizeof(mt7663_rx_dly_ctl_ul_tbl[0]));
	tr_delay_ctl->dl_rx_dly_ctl_tbl = mt7663_rx_dly_ctl_dl_tbl;
	tr_delay_ctl->dl_rx_dly_ctl_tbl_size = (sizeof(mt7663_rx_dly_ctl_dl_tbl) / sizeof(mt7663_rx_dly_ctl_dl_tbl[0]));

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("<--%s()\n", __func__));
}

#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
INT mt7663AsicArchOpsInit(RTMP_ADAPTER *pAd)
{
	RTMP_ARCH_OP *arch_ops = &pAd->archOps;

	arch_ops->archGetCrcErrCnt = MtAsicGetCrcErrCnt;
	arch_ops->archGetCCACnt = MtAsicGetCCACnt;
	arch_ops->archGetChBusyCnt = MtAsicGetChBusyCnt;
#ifdef CONFIG_STA_SUPPORT
	arch_ops->archUpdateAutoFallBackTable = MtAsicUpdateAutoFallBackTable;
	arch_ops->archEnableIbssSync = NULL;/* MtAsicEnableBssSyncByDriver; */
#endif /* CONFIG_STA_SUPPORT */
	arch_ops->archSetAutoFallBack = MtAsicSetAutoFallBack;
	arch_ops->archAutoFallbackInit = MtAsicAutoFallbackInit;
	arch_ops->archUpdateProtect = MtAsicUpdateProtectByFw;
	arch_ops->archUpdateRtsThld = MtAsicUpdateRtsThldByFw;
	arch_ops->archSwitchChannel = MtAsicSwitchChannel;
	arch_ops->archSetRDG = NULL;
#ifdef ANT_DIVERSITY_SUPPORT
	arch_ops->archAntennaSelect = MtAsicAntennaSelect;
#endif /* ANT_DIVERSITY_SUPPORT */
	arch_ops->archResetBBPAgent = MtAsicResetBBPAgent;
	arch_ops->archSetDevMac = MtAsicSetDevMacByFw;
	arch_ops->archSetBssid = MtAsicSetBssidByFw;
	arch_ops->archSetStaRec = MtAsicSetStaRecByFw;
	arch_ops->archUpdateStaRecBa = MtAsicUpdateStaRecBaByFw;
	arch_ops->asic_rts_on_off = mt_asic_rts_on_off;
#ifdef CONFIG_AP_SUPPORT
	arch_ops->archSetMbssMode = MtAsicSetMbssMode;
	arch_ops->archSetMbssWdevIfAddr = MtAsicSetMbssWdevIfAddrGen2;
	arch_ops->archSetMbssHwCRSetting = MtDmacSetMbssHwCRSetting;
	arch_ops->archSetExtTTTTHwCRSetting = MtDmacSetExtTTTTHwCRSetting;
	arch_ops->archSetExtMbssEnableCR = MtDmacSetExtMbssEnableCR;
#endif /* CONFIG_AP_SUPPORT */
	arch_ops->archDelWcidTab = MtAsicDelWcidTabByFw;
	arch_ops->archAddRemoveKeyTab = MtAsicAddRemoveKeyTabByFw;
#ifdef BCN_OFFLOAD_SUPPORT
	/* sync with Carter, wilsonl */
	arch_ops->archEnableBeacon = NULL;
	arch_ops->archDisableBeacon = NULL;
	arch_ops->archUpdateBeacon = MtUpdateBcnAndTimToMcu;
#else
	arch_ops->archEnableBeacon = MtDmacAsicEnableBeacon;
	arch_ops->archDisableBeacon = MtDmacAsicDisableBeacon;
	arch_ops->archUpdateBeacon = MtUpdateBeaconToAsic;
#endif
#ifdef APCLI_SUPPORT
#ifdef MAC_REPEATER_SUPPORT
	arch_ops->archSetReptFuncEnable = MtAsicSetReptFuncEnableByFw;
	arch_ops->archInsertRepeaterEntry = MtAsicInsertRepeaterEntryByFw;
	arch_ops->archRemoveRepeaterEntry = MtAsicRemoveRepeaterEntryByFw;
	arch_ops->archInsertRepeaterRootEntry = MtAsicInsertRepeaterRootEntryByFw;
#endif /* MAC_REPEATER_SUPPORT */
#endif /* APCLI_SUPPORT */
	arch_ops->archSetPiggyBack = MtAsicSetPiggyBack;
	arch_ops->archSetPreTbtt = NULL;/* offload to BssInfoUpdateByFw */
	arch_ops->archSetGPTimer = MtAsicSetGPTimer;
	arch_ops->archSetChBusyStat = MtAsicSetChBusyStat;
	arch_ops->archGetTsfTime = MtAsicGetTsfTimeByFirmware;
	arch_ops->archDisableSync = NULL;/* MtAsicDisableSyncByDriver; */
	arch_ops->archSetSyncModeAndEnable = NULL;/* MtAsicEnableBssSyncByDriver; */
	arch_ops->archSetWmmParam = MtAsicSetWmmParam;
	arch_ops->archGetWmmParam = MtAsicGetWmmParam;
	arch_ops->archSetEdcaParm = MtAsicSetEdcaParm;
	arch_ops->archSetRetryLimit = MtAsicSetRetryLimit;
	arch_ops->archGetRetryLimit = MtAsicGetRetryLimit;
	arch_ops->archSetSlotTime = MtAsicSetSlotTime;
	arch_ops->archGetTxTsc = MtAsicGetTxTscByDriver;
	arch_ops->archAddSharedKeyEntry = MtAsicAddSharedKeyEntry;
	arch_ops->archRemoveSharedKeyEntry = MtAsicRemoveSharedKeyEntry;
	arch_ops->archAddPairwiseKeyEntry = MtAsicAddPairwiseKeyEntry;
	arch_ops->archSetBW = MtAsicSetBW;
	arch_ops->archSetCtrlCh = mt_mac_set_ctrlch;
	arch_ops->archWaitMacTxRxIdle = MtAsicWaitMacTxRxIdle;
#ifdef MAC_INIT_OFFLOAD
	arch_ops->archSetMacTxRx = MtAsicSetMacTxRxByFw;
	arch_ops->archSetMacMaxLen = NULL;
	arch_ops->archSetTxStream = NULL;
	arch_ops->archSetRxFilter = NULL;/* MtAsicSetRxFilter; */
#else
	arch_ops->archSetMacTxRx = MtAsicSetMacTxRx;
	arch_ops->archSetMacMaxLen = MtAsicSetMacMaxLen;
	arch_ops->archSetTxStream = MtAsicSetTxStream;
	arch_ops->archSetRxFilter = MtAsicSetRxFilter;
#endif /*MAC_INIT_OFFLOAD*/
	arch_ops->archSetWPDMA = MtAsicSetWPDMAWithSch;
	arch_ops->archWaitPDMAIdle = MtAsicWaitPDMAIdle;
	arch_ops->archCheckDMAIdle = MtAsicCheckDMAIdle;
	arch_ops->archResetWPDMA = MtAsicResetWPDMA;
	arch_ops->archSetMacWD = MtAsicSetMacWD;
#ifdef MAC_APCLI_SUPPORT
	arch_ops->archSetApCliBssid = MtAsicSetApCliBssid;
#endif /* MAC_APCLI_SUPPORT */
	arch_ops->archTOPInit = MtAsicTOPInit;
	arch_ops->archSetTmrCR = MtSetTmrCRByFw;
	arch_ops->archUpdateRxWCIDTable = MtAsicUpdateRxWCIDTableByFw;
#ifdef TXBF_SUPPORT
	arch_ops->archUpdateClientBfCap = mt_AsicClientBfCap;
#endif /* TXBF_SUPPORT */
	arch_ops->archUpdateBASession = MtAsicUpdateBASessionByFw;
	arch_ops->archGetTidSn = MtAsicGetTidSnByDriver;
	arch_ops->archSetSMPS = MtAsicSetSMPSByDriver;
#ifdef MT_PS
	/* turn off, wilsonl */
	arch_ops->archSetIgnorePsm = MtSetIgnorePsmByDriver;
#endif
	arch_ops->archRxHeaderTransCtl = MtAsicRxHeaderTransCtl;
	arch_ops->archRxHeaderTaranBLCtl = MtAsicRxHeaderTaranBLCtl;
	arch_ops->rx_pkt_process = mt_rx_pkt_process;
	arch_ops->archSetRxStream = NULL;/* MtAsicSetRxStream; */
#ifdef IGMP_SNOOP_SUPPORT
	arch_ops->archMcastEntryInsert = MulticastFilterTableInsertEntry;
	arch_ops->archMcastEntryDelete = MulticastFilterTableDeleteEntry;
#endif
	arch_ops->write_txp_info = mtd_write_txp_info_by_host_v2;
	arch_ops->write_tmac_info_fixed_rate = mtd_write_tmac_info_fixed_rate;
	arch_ops->write_tmac_info = mtd_write_tmac_info_by_host;
	arch_ops->write_tx_resource = mtd_pci_write_tx_resource;
	arch_ops->write_frag_tx_resource = mt_pci_write_frag_tx_resource;
	arch_ops->kickout_data_tx = pci_kickout_data_tx;
	arch_ops->get_pkt_from_rx_resource = mtd_pci_get_pkt_from_rx_resource;
	arch_ops->get_resource_idx = mtd_pci_get_resource_idx;
	arch_ops->get_tx_resource_free_num = pci_get_tx_resource_free_num;
	arch_ops->check_hw_resource = mtd_check_hw_resource;
	arch_ops->inc_resource_full_cnt = pci_inc_resource_full_cnt;
	arch_ops->get_resource_state = pci_get_resource_state;
	arch_ops->set_resource_state = pci_set_resource_state;
	arch_ops->check_resource_state = pci_check_resource_state;
	arch_ops->get_hif_buf = mt_pci_get_hif_buf;
	arch_ops->hw_tx = mtd_hw_tx;
	arch_ops->mlme_hw_tx = mtd_mlme_hw_tx;
#ifdef CONFIG_ATE
	arch_ops->ate_hw_tx = mtd_ate_hw_tx;
#endif
	arch_ops->rx_done_handle = mtd_rx_done_handle;
	arch_ops->cmd_dma_done_handle = mt_cmd_dma_done_handle;
	arch_ops->fwdl_dma_done_handle = mt_fwdl_dma_done_handle;
	arch_ops->tx_dma_done_handle = mtd_tx_dma_done_handle;
	arch_ops->hw_isr = mtd_isr;

	return TRUE;
}
#endif

