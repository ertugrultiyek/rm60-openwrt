/*
 * Copyright (C) 2004  Internet Systems Consortium, Inc. ("ISC")
 * Copyright (C) 1999-2001  Internet Software Consortium.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND ISC DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS.  IN NO EVENT SHALL ISC BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

/* $ISC-Id:lang.h,v 1.6.206.1 2004/03/06 08:14:42 marka Exp $ */
/* $Id: lang.h,v 1.2 2005/08/05 05:08:26 mcr Exp $ */

#ifndef ISC_LANG_H
#define ISC_LANG_H 1

#ifdef __cplusplus
#define ISC_LANG_BEGINDECLS	extern "C" {
#define ISC_LANG_ENDDECLS	}
#else
#define ISC_LANG_BEGINDECLS
#define ISC_LANG_ENDDECLS
#endif

#endif /* ISC_LANG_H */
