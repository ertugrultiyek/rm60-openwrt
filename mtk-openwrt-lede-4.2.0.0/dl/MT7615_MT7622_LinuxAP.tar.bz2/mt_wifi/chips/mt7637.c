/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	mt7637.c
*/
#ifdef COMPOS_TESTMODE_WIN
#include "config.h"
#else
#include "rt_config.h"
#endif
#include "mcu/mt7637_rom_patch.h"
#include "mcu/mt7637_rom_patch_e2.h"
#include "mcu/mt7637_rom_patch_e3.h"
#include "mcu/mt7637_firmware.h"
#include "eeprom/mt7637_e2p.h"

#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
#include "phy/wf_phy_back.h"
#endif


#if defined(COMPOS_TESTMODE_WIN)
static VOID mt7637_bbp_adjust(struct _RTMP_ADAPTER *pAd, UCHAR Channel)
{
}


static VOID mt7637_switch_channel(struct _RTMP_ADAPTER *pAd,  MT_SWITCH_CHANNEL_CFG SwChCfg)
{
	struct _ATE_CTRL *AteCtrl = &pAd->ATECtrl;

	SwChCfg.Bw = AteCtrl->BW;
	SwChCfg.CentralChannel = AteCtrl->Channel;
	SwChCfg.ControlChannel = AteCtrl->ControlChl;
	SwChCfg.TxStream = 0;
	SwChCfg.RxStream = 0;
	MtCmdChannelSwitch(pAd, SwChCfg);
}


static void mt7637_antenna_default_reset(
	struct _RTMP_ADAPTER *pAd,
	EEPROM_ANTENNA_STRUC *pAntenna)
{
}


static void ToneRadarProgram_v2(struct _RTMP_ADAPTER *pAd, ULONG threshold)
{
}


static void mtusb_cfg_read(struct _RTMP_ADAPTER *pAd, UINT32 *value)
{
}


static void mtusb_cfg_write(struct _RTMP_ADAPTER *pAd, UINT32 value)
{
}

static VOID mt7637_show_pwr_info(struct _RTMP_ADAPTER *pAd)
{
}

#else

static VOID mt7637_bbp_adjust(RTMP_ADAPTER *pAd, UCHAR Channel)
{
	/*do nothing, change to use radio_resource control*/
	/*here should do bbp setting only, bbp is full-offload to fw*/
}


static void mt7637_switch_channel(RTMP_ADAPTER *pAd, MT_SWITCH_CHANNEL_CFG SwChCfg)
{
#ifdef RTMP_MAC_USB
	UINT32 ret = 0;

	if (IS_USB_INF(pAd)) {
		RTMP_SEM_EVENT_WAIT(&pAd->hw_atomic, ret);

		if (ret != 0) {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("reg_atomic get failed(ret=%d)\n", ret));
			return;
		}
	}

#endif /* RTMP_MAC_USB */
	MtCmdChannelSwitch(pAd, SwChCfg);
	/* Channel latch */
	pAd->LatchRfRegs.Channel = SwChCfg.CentralChannel;
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd))
		RTMP_SEM_EVENT_UP(&pAd->hw_atomic);

#endif
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			("%s(): Switch to Ch#%d(%dT%dR)\n",
			__func__,
			SwChCfg.CentralChannel,
			pAd->Antenna.field.TxPath,
			pAd->Antenna.field.RxPath));
}


static VOID mt7637_show_pwr_info(RTMP_ADAPTER *pAd)
{
	struct MT_TX_PWR_CAP *cap = &pAd->chipCap.MTTxPwrCap;
	UINT32 value;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel info related to power\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));

	if (pAd->LatchRfRegs.Channel < 14) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("central channel = %d, low_mid_hi = %d\n", pAd->LatchRfRegs.Channel,
				 get_low_mid_hi_index(pAd->LatchRfRegs.Channel)));
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel power(unit: 0.5dbm)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_target_pwr_g_band = 0x%x\n", cap->tx_0_target_pwr_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_target_pwr_g_band = 0x%x\n", cap->tx_1_target_pwr_g_band));
	/* channel power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("channel power delta(unit: 0.5db)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x%x\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0x%x\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI]));
	/* bw power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("bw power delta(unit: 0.5db)\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("delta_tx_pwr_bw40_g_band = %d\n", cap->delta_tx_pwr_bw40_g_band));
	/* per-rate power delta */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("per-rate power delta\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_cck_1_2 = %d\n", cap->tx_pwr_cck_1_2));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_cck_5_11 = %d\n", cap->tx_pwr_cck_5_11));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_6_9 = %d\n", cap->tx_pwr_g_band_ofdm_6_9));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_12_18 = %d\n", cap->tx_pwr_g_band_ofdm_12_18));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_24_36 = %d\n", cap->tx_pwr_g_band_ofdm_24_36));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_48 = %d\n", cap->tx_pwr_g_band_ofdm_48));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_g_band_ofdm_54 = %d\n", cap->tx_pwr_g_band_ofdm_54));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_bpsk_mcs_32 = %d\n", cap->tx_pwr_ht_bpsk_mcs_32));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_bpsk_mcs_0_8 = %d\n", cap->tx_pwr_ht_bpsk_mcs_0_8));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_qpsk_mcs_1_2_9_10 = %d\n", cap->tx_pwr_ht_qpsk_mcs_1_2_9_10));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_16qam_mcs_3_4_11_12 = %d\n", cap->tx_pwr_ht_16qam_mcs_3_4_11_12));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_5_13 = %d\n", cap->tx_pwr_ht_64qam_mcs_5_13));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_6_14 = %d\n", cap->tx_pwr_ht_64qam_mcs_6_14));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_pwr_ht_64qam_mcs_7_15 = %d\n", cap->tx_pwr_ht_64qam_mcs_7_15));
	/* TMAC POWER INFO */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("per-rate power delta in MAC 0x60130020 ~ 0x60130030\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	RTMP_IO_READ32(pAd, TMAC_FP0R0, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R0 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R1, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R1 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R2, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R2 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R3, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R3 = 0x%x\n", value));
	RTMP_IO_READ32(pAd, TMAC_FP0R4, &value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TMAC_FP0R4 = 0x%x\n", value));
	/* TSSI info */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TSSI info\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("===================================\n"));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TSSI enable = %d\n", pAd->chipCap.tssi_enable));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_0_slope_g_band = 0x%x\n", cap->tssi_0_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_slope_g_band = 0x%x\n", cap->tssi_1_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_0_offset_g_band = 0x%x\n", cap->tssi_0_offset_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_offset_g_band = 0x%x\n", cap->tssi_1_offset_g_band));
}


static void mt7637_antenna_default_reset(
	struct _RTMP_ADAPTER *pAd,
	EEPROM_ANTENNA_STRUC *pAntenna)
{
#if defined(MT7637_FPGA)
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s() todo\n", __func__));
	pAntenna->word = 0;
	pAd->RfIcType = RFIC_7637;
	pAntenna->field.TxPath = 1;
	pAntenna->field.RxPath = 1;
	return;
#endif /* MT7637_FPGA */
	pAntenna->word = 0;
	pAd->RfIcType = RFIC_7637;
	pAntenna->field.TxPath = 1;
	pAntenna->field.RxPath = 1;
}


/* Read power per rate */
void mt7637_get_tx_pwr_per_rate(RTMP_ADAPTER *pAd)
{
	BOOLEAN is_empty = 0;
	UINT16 value = 0;
	struct MT_TX_PWR_CAP *cap = &pAd->chipCap.MTTxPwrCap;
	/* G Band tx power for CCK 1M/2M, 5.5M/11M */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_CCK_1_2M, value);

	if (is_empty) {
		cap->tx_pwr_cck_1_2 = 0;
		cap->tx_pwr_cck_5_11 = 0;
	} else {
		/* CCK 1M/2M */
		if (value & TX_PWR_CCK_1_2M_EN) {
			if (value & TX_PWR_CCK_1_2M_SIGN)
				cap->tx_pwr_cck_1_2 = (value & TX_PWR_CCK_1_2M_MASK);
			else
				cap->tx_pwr_cck_1_2 = -(value & TX_PWR_CCK_1_2M_MASK);
		} else
			cap->tx_pwr_cck_1_2 = 0;

		/* CCK 5.5M/11M */
		if (value & TX_PWR_CCK_5_11M_EN) {
			if (value & TX_PWR_CCK_5_11M_SIGN)
				cap->tx_pwr_cck_5_11 = ((value & TX_PWR_CCK_5_11M_MASK) >> 8);
			else
				cap->tx_pwr_cck_5_11 = -((value & TX_PWR_CCK_5_11M_MASK) >> 8);
		} else
			cap->tx_pwr_cck_5_11 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_cck_1_2 = %d\n", cap->tx_pwr_cck_1_2));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_cck_5_11 = %d\n", cap->tx_pwr_cck_5_11));
	/* G Band tx power for OFDM 6M/9M, 12M/18M, 24M/36M, 48M/54M */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_6_9M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_6_9 = 0;
		cap->tx_pwr_g_band_ofdm_12_18 = 0;
	} else {
		/* OFDM 6M/9M */
		if (value & TX_PWR_G_BAND_OFDM_6_9M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_6_9M_SIGN)
				cap->tx_pwr_g_band_ofdm_6_9 = (value & TX_PWR_G_BAND_OFDM_6_9M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_6_9 = -(value & TX_PWR_G_BAND_OFDM_6_9M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_6_9 = 0;

		/* OFDM 12M/18M */
		if (value & TX_PWR_G_BAND_OFDM_12_18M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_12_18M_SIGN)
				cap->tx_pwr_g_band_ofdm_12_18 = ((value & TX_PWR_G_BAND_OFDM_12_18M_MASK) >> 8);
			else
				cap->tx_pwr_g_band_ofdm_12_18 = -((value & TX_PWR_G_BAND_OFDM_12_18M_MASK) >> 8);
		} else
			cap->tx_pwr_g_band_ofdm_12_18 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_6_9 = %d\n", cap->tx_pwr_g_band_ofdm_6_9));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_12_18 = %d\n", cap->tx_pwr_g_band_ofdm_12_18));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_24_36M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_24_36 = 0;
		cap->tx_pwr_g_band_ofdm_48 = 0;
	} else {
		/* OFDM 24M/36M */
		if (value & TX_PWR_G_BAND_OFDM_24_36M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_24_36M_SIGN)
				cap->tx_pwr_g_band_ofdm_24_36 = (value & TX_PWR_G_BAND_OFDM_24_36M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_24_36 = -(value & TX_PWR_G_BAND_OFDM_24_36M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_24_36 = 0;

		/* OFDM 48M */
		if (value & TX_PWR_G_BAND_OFDM_48M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_48M_SIGN)
				cap->tx_pwr_g_band_ofdm_48 = ((value & TX_PWR_G_BAND_OFDM_48M_MASK) >> 8);
			else
				cap->tx_pwr_g_band_ofdm_48 = -((value & TX_PWR_G_BAND_OFDM_48M_MASK) >> 8);
		} else
			cap->tx_pwr_g_band_ofdm_48 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_24_36 = %d\n", cap->tx_pwr_g_band_ofdm_24_36));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_48 = %d\n", cap->tx_pwr_g_band_ofdm_48));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_G_BAND_OFDM_54M, value);

	if (is_empty) {
		cap->tx_pwr_g_band_ofdm_54 = 0;
		cap->tx_pwr_ht_bpsk_mcs_0_8 = 0;
	} else {
		/* OFDM 54M */
		if (value & TX_PWR_G_BAND_OFDM_54M_EN) {
			if (value & TX_PWR_G_BAND_OFDM_54M_SIGN)
				cap->tx_pwr_g_band_ofdm_54 = (value & TX_PWR_G_BAND_OFDM_54M_MASK);
			else
				cap->tx_pwr_g_band_ofdm_54 = -(value & TX_PWR_G_BAND_OFDM_54M_MASK);
		} else
			cap->tx_pwr_g_band_ofdm_54 = 0;

		/* HT MCS_0, MCS_8 */
		if (value & TX_PWR_HT_BPSK_MCS_0_8_EN) {
			if (value & TX_PWR_HT_BPSK_MCS_0_8_SIGN)
				cap->tx_pwr_ht_bpsk_mcs_0_8 = ((value & TX_PWR_HT_BPSK_MCS_0_8_MASK) >> 8);
			else
				cap->tx_pwr_ht_bpsk_mcs_0_8 = -((value & TX_PWR_HT_BPSK_MCS_0_8_MASK) >> 8);
		} else
			cap->tx_pwr_ht_bpsk_mcs_0_8 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_g_band_ofdm_54 = %d\n", cap->tx_pwr_g_band_ofdm_54));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_bpsk_mcs_0_8 = %d\n", cap->tx_pwr_ht_bpsk_mcs_0_8));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_BPSK_MCS_32, value);

	if (is_empty) {
		cap->tx_pwr_ht_bpsk_mcs_32 = 0;
		cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = 0;
	} else {
		/* HT MCS_0, MCS_8 */
		if (value & TX_PWR_HT_BPSK_MCS_32_EN) {
			if (value & TX_PWR_HT_BPSK_MCS_32_SIGN)
				cap->tx_pwr_ht_bpsk_mcs_32 = (value & TX_PWR_HT_BPSK_MCS_32_MASK);
			else
				cap->tx_pwr_ht_bpsk_mcs_32 = -(value & TX_PWR_HT_BPSK_MCS_32_MASK);
		} else
			cap->tx_pwr_ht_bpsk_mcs_32 = 0;

		/* HT MCS_1, MCS_2, MCS_9, MCS_10 */
		if (value & TX_PWR_HT_QPSK_MCS_1_2_9_10_EN) {
			if (value & TX_PWR_HT_QPSK_MCS_1_2_9_10_SIGN)
				cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = ((value & TX_PWR_HT_QPSK_MCS_1_2_9_10_MASK) >> 8);
			else
				cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = -((value & TX_PWR_HT_QPSK_MCS_1_2_9_10_MASK) >> 8);
		} else
			cap->tx_pwr_ht_qpsk_mcs_1_2_9_10 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_bpsk_mcs_32 = %d\n", cap->tx_pwr_ht_bpsk_mcs_32));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_qpsk_mcs_1_2_9_10 = %d\n", cap->tx_pwr_ht_qpsk_mcs_1_2_9_10));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_16QAM_MCS_3_4_11_12, value);

	if (is_empty) {
		cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = 0;
		cap->tx_pwr_ht_64qam_mcs_5_13 = 0;
	} else {
		/* HT MCS_3, MCS_4, MCS_11, MCS_12 */
		if (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_EN) {
			if (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_SIGN)
				cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = (value & TX_PWR_HT_16QAM_MCS_3_4_11_12_MASK);
			else
				cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = -(value & TX_PWR_HT_16QAM_MCS_3_4_11_12_MASK);
		} else
			cap->tx_pwr_ht_16qam_mcs_3_4_11_12 = 0;

		/* HT MCS_5, MCS_13 */
		if (value & TX_PWR_HT_64QAM_MCS_5_13_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_5_13_SIGN)
				cap->tx_pwr_ht_64qam_mcs_5_13 = ((value & TX_PWR_HT_64QAM_MCS_5_13_MASK) >> 8);
			else
				cap->tx_pwr_ht_64qam_mcs_5_13 = -((value & TX_PWR_HT_64QAM_MCS_5_13_MASK) >> 8);
		} else
			cap->tx_pwr_ht_64qam_mcs_5_13 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_16qam_mcs_3_4_11_12 = %d\n", cap->tx_pwr_ht_16qam_mcs_3_4_11_12));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_5_13 = %d\n", cap->tx_pwr_ht_64qam_mcs_5_13));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX_PWR_HT_64QAM_MCS_6_14, value);

	if (is_empty) {
		cap->tx_pwr_ht_64qam_mcs_6_14 = 0;
		cap->tx_pwr_ht_64qam_mcs_7_15 = 0;
	} else {
		/* HT MCS_6, MCS_14 */
		if (value & TX_PWR_HT_64QAM_MCS_6_14_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_6_14_SIGN)
				cap->tx_pwr_ht_64qam_mcs_6_14 = (value & TX_PWR_HT_64QAM_MCS_6_14_MASK);
			else
				cap->tx_pwr_ht_64qam_mcs_6_14 = -(value & TX_PWR_HT_64QAM_MCS_6_14_MASK);
		} else
			cap->tx_pwr_ht_64qam_mcs_6_14 = 0;

		/* HT MCS_7, MCS_15 */
		if (value & TX_PWR_HT_64QAM_MCS_7_15_EN) {
			if (value & TX_PWR_HT_64QAM_MCS_7_15_SIGN)
				cap->tx_pwr_ht_64qam_mcs_7_15 = ((value & TX_PWR_HT_64QAM_MCS_7_15_MASK) >> 8);
			else
				cap->tx_pwr_ht_64qam_mcs_7_15 = -((value & TX_PWR_HT_64QAM_MCS_7_15_MASK) >> 8);
		} else
			cap->tx_pwr_ht_64qam_mcs_7_15 = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_6_14 = %d\n", cap->tx_pwr_ht_64qam_mcs_6_14));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_pwr_ht_64qam_mcs_7_15 = %d\n", cap->tx_pwr_ht_64qam_mcs_7_15));
}


void mt7637_get_tx_pwr_info(RTMP_ADAPTER *pAd)
{
	bool is_empty = 0;
	UINT16 value = 0;
	struct MT_TX_PWR_CAP *cap = &pAd->chipCap.MTTxPwrCap;
	/* Read 20/40 BW delta */
	is_empty = RT28xx_EEPROM_READ16(pAd, G_BAND_20_40_BW_PWR_DELTA, value);

	if (is_empty)
		cap->delta_tx_pwr_bw40_g_band = 0x0;
	else {
		/* G Band */
		if (value & G_BAND_20_40_BW_PWR_DELTA_EN) {
			if (value & G_BAND_20_40_BW_PWR_DELTA_SIGN) {
				/* bit[0..5] tx power delta value */
				cap->delta_tx_pwr_bw40_g_band = (value & G_BAND_20_40_BW_PWR_DELTA_MASK);
			} else
				cap->delta_tx_pwr_bw40_g_band = -(value & G_BAND_20_40_BW_PWR_DELTA_MASK);
		} else
			cap->delta_tx_pwr_bw40_g_band = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("delta_tx_pwr_bw40_g_band = %d\n", cap->delta_tx_pwr_bw40_g_band));
	/* ///////////////// Tx0 ////////////////////////// */
	/* Read TSSI slope/offset for TSSI compensation */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_TSSI_SLOPE, value);
	cap->tssi_0_slope_g_band =
		(is_empty) ? TSSI_0_SLOPE_G_BAND_DEFAULT_VALUE : (value & TX0_G_BAND_TSSI_SLOPE_MASK);
	cap->tssi_0_offset_g_band =
		(is_empty) ? TSSI_0_OFFSET_G_BAND_DEFAULT_VALUE : ((value & TX0_G_BAND_TSSI_OFFSET_MASK) >> 8);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_slope_g_band = %d\n", cap->tssi_0_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_offset_g_band = %d\n", cap->tssi_0_offset_g_band));
	/* Read 54M target power */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_TARGET_PWR, value);
	cap->tx_0_target_pwr_g_band =
		(is_empty) ? TX_TARGET_PWR_DEFAULT_VALUE : (value & TX0_G_BAND_TARGET_PWR_MASK);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_0_target_pwr_g_band = %d\n", cap->tx_0_target_pwr_g_band));

	/* Read power offset (channel delta) */
	if (is_empty)
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x0;
	else {
		/* tx power offset LOW */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_LOW_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_LOW_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = ((value & TX0_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = -((value & TX0_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_LOW] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_LOW]));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX0_G_BAND_CHL_PWR_DELTA_MID, value);

	if (is_empty) {
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x0;
		cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x0;
	} else {
		/* tx power offset MID */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_MID_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_MID_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = (value & TX0_G_BAND_CHL_PWR_DELTA_MID_MASK);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = -(value & TX0_G_BAND_CHL_PWR_DELTA_MID_MASK);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID] = 0x0;

		/* tx power offset HIGH */
		if (value & TX0_G_BAND_CHL_PWR_DELTA_HI_EN) {
			if (value & TX0_G_BAND_CHL_PWR_DELTA_HI_SIGN)
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = ((value & TX0_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
			else
				cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = -((value & TX0_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
		} else
			cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI] = 0x0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_MID] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_0_chl_pwr_delta_g_band[G_BAND_HI] = %d\n", cap->tx_0_chl_pwr_delta_g_band[G_BAND_HI]));
	/* ///////////////// Tx1 ////////////////////////// */
	/* Read TSSI slope/offset for TSSI compensation */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_TSSI_SLOPE, value);
	cap->tssi_1_slope_g_band = (is_empty) ? TSSI_1_SLOPE_G_BAND_DEFAULT_VALUE : (value & TX1_G_BAND_TSSI_SLOPE_MASK);
	cap->tssi_1_offset_g_band = (is_empty) ? TSSI_1_OFFSET_G_BAND_DEFAULT_VALUE : ((value & TX1_G_BAND_TSSI_OFFSET_MASK) >> 8);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_1_slope_g_band = %d\n", cap->tssi_1_slope_g_band));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tssi_1_offset_g_band = %d\n", cap->tssi_1_offset_g_band));
	/* Read 54M target power */
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_TARGET_PWR, value);
	cap->tx_1_target_pwr_g_band = (is_empty) ? TX_TARGET_PWR_DEFAULT_VALUE : (value & TX1_G_BAND_TARGET_PWR_MASK);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tssi_1_target_pwr_g_band = %d\n", cap->tx_1_target_pwr_g_band));

	/* Read power offset (channel delta) */
	if (is_empty)
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] =  0;
	else {
		/* tx power offset LOW */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_LOW_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_LOW_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = ((value & TX1_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = -((value & TX1_G_BAND_CHL_PWR_DELTA_LOW_MASK) >> 8);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_LOW] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_LOW]));
	is_empty = RT28xx_EEPROM_READ16(pAd, TX1_G_BAND_CHL_PWR_DELTA_MID, value);

	if (is_empty) {
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0;
		cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0;
	} else {
		/* tx power offset MID */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_MID_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_MID_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = (value & TX1_G_BAND_CHL_PWR_DELTA_MID_MASK);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = -(value & TX1_G_BAND_CHL_PWR_DELTA_MID_MASK);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID] = 0;

		/* tx power offset HIGH */
		if (value & TX1_G_BAND_CHL_PWR_DELTA_HI_EN) {
			if (value & TX1_G_BAND_CHL_PWR_DELTA_HI_SIGN)
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = ((value & TX1_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
			else
				cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = -((value & TX1_G_BAND_CHL_PWR_DELTA_HI_MASK) >> 8);
		} else
			cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI] = 0;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_MID] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_MID]));
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("tx_1_chl_pwr_delta_g_band[G_BAND_HI] = %d\n", cap->tx_1_chl_pwr_delta_g_band[G_BAND_HI]));
}

static UINT8 mt7637_txpwr_chlist[] = {
	1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
	36, 38, 40, 44, 46, 48, 52, 54, 56, 60, 62, 64,
	100, 102, 104, 108, 110, 112, 116, 118, 120, 124, 126, 128, 132, 134, 136, 140,
	149, 151, 153, 157, 159, 161, 165, 167, 169, 171, 173,
#ifdef DOT11_VHT_AC
	42, 58, 106, 122, 155,
#endif
};

UINT32 mt7637_read_chl_pwr(RTMP_ADAPTER *ad)
{
	UINT32 i, choffset;
	/* Read Tx power value for all channels*/
	/* Value from 1 - 0x7f. Default value is 24.*/
	/* Power value : 2.4G 0x00 (0) ~ 0x1F (31)*/
	/*             : 5.5G 0xF9 (-7) ~ 0x0F (15)*/
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()--->\n", __func__));

	for (i = 0; i < sizeof(mt7637_txpwr_chlist); i++) {
		ad->TxPower[i].Channel = mt7637_txpwr_chlist[i];
		ad->TxPower[i].Power = TX_TARGET_PWR_DEFAULT_VALUE;
		ad->TxPower[i].Power2 = TX_TARGET_PWR_DEFAULT_VALUE;
	}

	/* 1. U-NII lower/middle band: 36, 38, 40; 44, 46, 48; 52, 54, 56; 60, 62, 64 (including central frequency in BW 40MHz)*/
	choffset = 14;
	ASSERT((ad->TxPower[choffset].Channel == 36));
	choffset = 14 + 12 + 16 + 11;
#ifdef DOT11_VHT_AC
	ASSERT((ad->TxPower[choffset].Channel == 42));
	/* TODO: Hanmin 7637, fix me for the TxPower setting code here! */
	/* For VHT80MHz, we need assign tx power for central channel 42, 58, 106, 122, and 155 */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s: Update Tx power control of the central channel (42, 58, 106, 122 and 155) for VHT BW80\n", __func__));
	os_move_mem(&ad->TxPower[53], &ad->TxPower[16], sizeof(CHANNEL_TX_POWER)); /* channel 42 = channel 40 */
	os_move_mem(&ad->TxPower[54], &ad->TxPower[22], sizeof(CHANNEL_TX_POWER)); /* channel 58 = channel 56 */
	os_move_mem(&ad->TxPower[55], &ad->TxPower[28], sizeof(CHANNEL_TX_POWER)); /* channel 106 = channel 104 */
	os_move_mem(&ad->TxPower[56], &ad->TxPower[34], sizeof(CHANNEL_TX_POWER)); /* channel 122 = channel 120 */
	os_move_mem(&ad->TxPower[57], &ad->TxPower[44], sizeof(CHANNEL_TX_POWER)); /* channel 155 = channel 153 */
	ad->TxPower[choffset].Channel = 42;
	ad->TxPower[choffset + 1].Channel = 58;
	ad->TxPower[choffset + 2].Channel = 106;
	ad->TxPower[choffset + 3].Channel = 122;
	ad->TxPower[choffset + 4].Channel = 155;
	choffset += 5;		/* the central channel of VHT80 */
	choffset = (MAX_NUM_OF_CHANNELS - 1);
#endif /* DOT11_VHT_AC */

	/* 4. Print and Debug*/
	for (i = 0; i < choffset; i++) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Channel=%d, Power[Tx0:%d, Tx1:%d]\n",
				 ad->TxPower[i].Channel, ad->TxPower[i].Power, ad->TxPower[i].Power2));
	}

	return TRUE;
}

#endif /* defined(COMPOS_TESTMODE_WIN) */

static inline VOID bufferModeFieldSet(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd, UINT16 addr)
{
	UINT32 i = pCmd->ucCount;

	pCmd->BinContent[i].u2Addr = cpu2le16(addr);
	pCmd->BinContent[i].ucValue = pAd->EEPROMImage[addr];
	pCmd->ucCount++;
}


static VOID mt7637_bufferModeEfuseFill(RTMP_ADAPTER *pAd, EXT_CMD_EFUSE_BUFFER_MODE_T *pCmd)
{
	UINT16 i = 0;

	pCmd->ucCount = 0;

	for (i = 0x2e; i <= 0x19d; i++)
		bufferModeFieldSet(pAd, pCmd, i);

	/*must minus last add*/
	pCmd->ucCount--;
}

#ifdef CAL_FREE_IC_SUPPORT
static UINT32 ICAL_INDIUM[] = {0x22, 0x24, 0x31, 0x3f, 0x40, 0x41, 0x42, 0x43, 0x53,
							   0x54, 0x55, 0x56, 0x57, 0x62, 0x63, 0x67, 0x68, 0x6c, 0x6d,
							   0x71, 0x72, 0x76, 0x77, 0x7b, 0x7c, 0x80, 0x81, 0x85, 0x86,
							   0xf7, 0x100, 0x135, 0x136, 0x138, 0x13d
							  };
static UINT32 ICAL_QFN[] = {0x22, 0x31, 0x53, 0x54, 0x55, 0x56, 0x57, 0x5c, 0x5d, 0x5e,
							0x5f, 0x62, 0x63, 0x67, 0x68, 0x6c, 0x6d, 0x71, 0x72, 0x76,
							0x77, 0x7b, 0x7c, 0x80, 0x81, 0x85, 0x86, 0xf4, 0xf7, 0x100,
							0x135, 0x136, 0x138, 0x139, 0x13a, 0x13b, 0x13d
						   };
static UINT32 ICAL_INDIUM_NUM = (sizeof(ICAL_INDIUM) / sizeof(UINT32));
static UINT32 ICAL_QFN_NUM = (sizeof(ICAL_QFN) / sizeof(UINT32));

static inline BOOLEAN check_valid(RTMP_ADAPTER *pAd, UINT16 Offset)
{
	UINT16 Value = 0;
	BOOLEAN NotValid;

	if ((Offset % 2) != 0) {
		NotValid = rtmp_ee_efuse_read16(pAd, Offset - 1, &Value);

		if (NotValid == FALSE)
			return TRUE;
	} else {
		NotValid = rtmp_ee_efuse_read16(pAd, Offset, &Value);

		if (NotValid == FALSE)
			return TRUE;
	}

	return FALSE;
}
static BOOLEAN mt7637_is_cal_free_ic(RTMP_ADAPTER *pAd)
{
	UINT32 Value;
	BOOLEAN BOND_PCIE_MODE;
	BOOLEAN BOND_USB_MODE;
	BOOLEAN BOND_SIP_MODE;

	HW_IO_READ32(pAd, STRAP_STA, &Value);
	BOND_PCIE_MODE = (Value & PCIE_MODE_MASK) >> PCIE_MODE_OFFSET;
	BOND_USB_MODE = (Value & USB_MODE_MASK) >> USB_MODE_OFFSET;
	BOND_SIP_MODE = (Value & SIP_MODE_MASK) >> SIP_MODE_OFFSET;

	if (BOND_SIP_MODE && BOND_USB_MODE && !BOND_PCIE_MODE) {
		/*Indium*/
		UINT32 i;

		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("IC is Indium\n"));

		for (i = 0; i < ICAL_INDIUM_NUM; i++)
			if (check_valid(pAd, ICAL_INDIUM[i]) == TRUE)
				return TRUE;
	} else {
		/*QFN(USB,PCIE,SDIO)*/
		UINT32 i;

		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("IC is QFN\n"));

		for (i = 0; i < ICAL_QFN_NUM; i++)
			if (check_valid(pAd, ICAL_QFN[i]) == TRUE)
				return TRUE;
	}

	return FALSE;
}

static inline VOID cal_free_data_get_from_addr(RTMP_ADAPTER *ad, UINT16 Offset)
{
	UINT16 value;
	BOOLEAN NotValid;

	if ((Offset % 2) != 0) {
		NotValid = rtmp_ee_efuse_read16(ad, Offset - 1, &value);

		if (NotValid == FALSE)
			ad->EEPROMImage[Offset] = (value >> 8) & 0xFF;
	} else {
		NotValid = rtmp_ee_efuse_read16(ad, Offset, &value);

		if (NotValid == FALSE)
			ad->EEPROMImage[Offset] =  value & 0xFF;
	}
}

static VOID mt7637_cal_free_data_get(RTMP_ADAPTER *ad)

{
	UINT32 Value;
	BOOLEAN BOND_PCIE_MODE;
	BOOLEAN BOND_USB_MODE;
	BOOLEAN BOND_SIP_MODE;

	HW_IO_READ32(ad, STRAP_STA, &Value);
	BOND_PCIE_MODE = (Value & PCIE_MODE_MASK) >> PCIE_MODE_OFFSET;
	BOND_USB_MODE = (Value & USB_MODE_MASK) >> USB_MODE_OFFSET;
	BOND_SIP_MODE = (Value & SIP_MODE_MASK) >> SIP_MODE_OFFSET;
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s\n", __func__));

	if (BOND_SIP_MODE && BOND_USB_MODE && !BOND_PCIE_MODE) {
		/*Indium*/
		UINT32 i;

		for (i = 0; i < ICAL_INDIUM_NUM; i++)
			cal_free_data_get_from_addr(ad, ICAL_INDIUM[i]);
	} else {
		/*QFN(USB,PCIE,SDIO)*/
		UINT32 i;

		for (i = 0; i < ICAL_QFN_NUM; i++)
			cal_free_data_get_from_addr(ad, ICAL_QFN[i]);
	}
}
#endif /* CAL_FREE_IC_SUPPORT */


#ifdef CONFIG_STA_SUPPORT
static VOID mt7637_init_dev_nick_name(RTMP_ADAPTER *ad)
{
#ifdef RTMP_MAC_USB

	if (IS_MT7637(ad))
		snprintf((RTMP_STRING *) ad->nickname, sizeof(ad->nickname), "mt7637u_sta");

#endif
#ifdef RTMP_MAC_SDIO

	if (IS_MT7637(ad))
		snprintf((RTMP_STRING *) ad->nickname, sizeof(ad->nickname), "mt7637s_sta");

#endif
#ifdef RTMP_MAC_PCI

	if (IS_MT7637(ad))
		snprintf((RTMP_STRING *) ad->nickname, sizeof(ad->nickname), "mt7637e_sta");

#endif
}
#endif /* CONFIG_STA_SUPPORT */


static VOID mt7637_init_mac_cr(RTMP_ADAPTER *pAd)
{
#ifndef MAC_INIT_OFFLOAD
	UINT32 mac_val;
#endif
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
#ifndef MAC_INIT_OFFLOAD
#ifdef MT7637_FPGA
	/* enable MAC2MAC mode */
	RTMP_IO_READ32(pAd, RMAC_MISC, &mac_val);
	mac_val |= BIT18;
	RTMP_IO_WRITE32(pAd, RMAC_MISC, mac_val);
	/*
	sync. MT7628.c
	WHQA_00016749, there are a lots of Tx retry in FPGA.
	per Jacky's comment, enlarge the timeout value of waiting ack.
	real chip shall not have the symptom.
	*/
	mac_val = 0x00d700d7;
	RTMP_IO_WRITE32(pAd, TMAC_CDTR, mac_val);
	mac_val = 0x00d700d7;
	RTMP_IO_WRITE32(pAd, TMAC_ODTR, mac_val);
	/* +++work-around for RTS/CTS bandwidth signaling failed issue in FPGA mode */
	RTMP_IO_READ32(pAd, TMAC_TCR, &mac_val);
	mac_val &= ~((1 << 12) | (1 << 13) | (1 << 14));
	RTMP_IO_WRITE32(pAd, TMAC_TCR, mac_val);
	RTMP_IO_READ32(pAd, AGG_PCR1, &mac_val);
	mac_val = 0xfe0fffff;
	RTMP_IO_WRITE32(pAd, AGG_PCR1, mac_val);
	/* ---work-around for RTS/CTS bandwidth signaling failed issue in FPGA mode */
	/*  */
#endif /* MT7603_FPGA */
	/* Disable 802.11 to 802.3 Hdr tranlation */
	RTMP_IO_READ32(pAd, DMA_DCR0, &mac_val);
	mac_val &= ~BIT19;
	RTMP_IO_WRITE32(pAd, DMA_DCR0, mac_val);

	/* ECO solution */
	/* WHQA_00018345: MAC TX sequence number skip issue */
	if (MTK_REV_GTE(pAd, MT76x6, MT76x6E2)) {
		mac_val = 0;
		RTMP_IO_READ32(pAd, AGG_SCR, &mac_val);
		mac_val |= BIT4;
		RTMP_IO_WRITE32(pAd, AGG_SCR, mac_val);
	}

	/* TxS Setting */
	MtAsicSetTxSClassifyFilter(pAd, TXS2HOST, TXS2H_QID1, TXS2HOST_AGGNUMS, 0x00, 0);
#else
#endif /*MAC_INIT_OFFLOAD*/
}

static RTMP_CHIP_CAP MT7637_ChipCap;
static RTMP_CHIP_OP MT7637_ChipOp;

static void mt7637_fw_prepare(RTMP_ADAPTER *pAd)
{
	RTMP_CHIP_CAP *pChipCap = &pAd->chipCap;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(FW(%x), HW(%x), CHIPID(%x))\n",
			 __func__,
			 pAd->FWVersion,
			 pAd->HWVersion,
			 pAd->ChipID));
#ifdef COMPOS_WIN
	/* TODO: BJBJ */
#else

	if (IS_MT7637_FW_VER_E1(pAd)) {
		/* ROM Patch*/
		pChipCap->rom_patch_header_image = mt7637_rom_patch;
		pChipCap->rom_patch_bin_file_name = MT7637_ROM_PATCH_BIN_FILE_NAME;
		pChipCap->rom_patch_len = sizeof(mt7637_rom_patch);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(%d)::(1), pChipCap->rom_patch_len(%d)\n", __func__, __LINE__, pChipCap->rom_patch_len));
	} else if (IS_MT7637_FW_VER_E2(pAd)) {
		/* ROM Patch*/
		pChipCap->rom_patch_header_image = mt7637_rom_patch_e2;
		pChipCap->rom_patch_bin_file_name = MT7637_ROM_PATCH_BIN_FILE_NAME_E2;
		pChipCap->rom_patch_len = sizeof(mt7637_rom_patch_e2);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(%d)::(2), pChipCap->rom_patch_len(%d)\n", __func__, __LINE__, pChipCap->rom_patch_len));
	} else {
		/* Use E1 rom patch as default */
		/* ROM Patch*/
		pChipCap->rom_patch_header_image = mt7637_rom_patch;
		pChipCap->rom_patch_bin_file_name = MT7637_ROM_PATCH_BIN_FILE_NAME;
		pChipCap->rom_patch_len = sizeof(mt7637_rom_patch);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(%d)::(3), pChipCap->rom_patch_len(%d)\n", __func__, __LINE__, pChipCap->rom_patch_len));
	}

	/* RAM Code */
	pChipCap->fw_header_image = MT7637_FirmwareImage;
	pChipCap->fw_bin_file_name = MT7637_FW_BIN_FILE_NAME;
	pChipCap->fw_len = sizeof(MT7637_FirmwareImage);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(%d)::(1), pChipCap->fw_len(%d)\n", __func__, __LINE__, pChipCap->fw_len));
#endif
}


#ifdef TXBF_SUPPORT
void mt7637_setETxBFCap(
	IN  RTMP_ADAPTER      *pAd,
	IN  TXBF_STATUS_INFO * pTxBfInfo)
{
	HT_BF_CAP *pTxBFCap = pTxBfInfo->pHtTxBFCap;

	if (pTxBfInfo->cmmCfgETxBfIncapable)
		memset(pTxBFCap, 0, sizeof(*pTxBFCap));
	else {
		pTxBFCap->TxNDPCapable         = FALSE;
		pTxBFCap->ExpComSteerCapable   = FALSE;
		pTxBFCap->RxNDPCapable         = TRUE;
		pTxBFCap->ExpNoComSteerCapable = FALSE;
		pTxBFCap->ExpNoComBF           = 0; /* MT7636 not support // HT_ExBF_FB_CAP_IMMEDIATE; */
		pTxBFCap->ExpComBF             = HT_ExBF_FB_CAP_IMMEDIATE;/* pTxBfInfo->cmmCfgETxBfNoncompress? HT_ExBF_FB_CAP_NONE: HT_ExBF_FB_CAP_IMMEDIATE; */
		pTxBFCap->MinGrouping          = 3;
		pTxBFCap->NoComSteerBFAntSup   = 0;
		pTxBFCap->ComSteerBFAntSup     = 3;
		pTxBFCap->TxSoundCapable       = FALSE;  /* Support staggered sounding frames */
		pTxBFCap->ChanEstimation       = 3;    /* pTxBfInfo->ucRxPathNum-1; */
	}
}


#ifdef VHT_TXBF_SUPPORT
void mt7637_setVHTETxBFCap(
	IN  RTMP_ADAPTER *pAd,
	IN  TXBF_STATUS_INFO * pTxBfInfo)
{
	VHT_CAP_INFO *pTxBFCap = pTxBfInfo->pVhtTxBFCap;

	if (pTxBfInfo->cmmCfgETxBfIncapable) {
		pTxBFCap->num_snd_dimension = 0;
		pTxBFCap->bfee_cap_mu = 0;
		pTxBFCap->bfee_cap_su = 0;
		pTxBFCap->bfer_cap_mu = 0;
		pTxBFCap->bfer_cap_su = 0;
		pTxBFCap->bfee_sts_cap = 0;
	} else {
		pTxBFCap->bfee_cap_su = 1;
		pTxBFCap->bfer_cap_su = 0;
		pTxBFCap->bfee_cap_mu = 1;
		pTxBFCap->bfer_cap_mu = 0;
		pTxBFCap->num_snd_dimension = 0;
		pTxBFCap->bfee_sts_cap = 3;
	}
}
#endif /* VHT_TXBF_SUPPORT */
#endif /* TXBF_SUPPORT */

static VOID mt7637_chipCap_init(RTMP_ADAPTER *pAd)
{
	os_zero_mem(&MT7637_ChipCap, sizeof(RTMP_CHIP_CAP));
	MT7637_ChipCap.max_nss = 1;
#ifdef DOT11_VHT_AC
	MT7637_ChipCap.max_vht_mcs = VHT_MCS_CAP_9;
	MT7637_ChipCap.ac_off_mode = 0;
#endif /*DOT11_VHT_AC*/
	MT7637_ChipCap.TXWISize = sizeof(TMAC_TXD_L); /* 32 */
	MT7637_ChipCap.RXWISize = 28;
	MT7637_ChipCap.WtblHwNum = MT7637_MT_WTBL_SIZE;
	MT7637_ChipCap.WtblPseAddr = MT7637_PSE_WTBL_2_ADDR;
#ifdef RTMP_MAC_PCI

	if (MTK_REV_GTE(pAd, MT7637, MT7637E2))
		MT7637_ChipCap.WPDMABurstSIZE = 3;
	else
		MT7637_ChipCap.WPDMABurstSIZE = 2;

#endif
	MT7637_ChipCap.SnrFormula = SNR_FORMULA4;
	MT7637_ChipCap.FlgIsHwWapiSup = TRUE;
	MT7637_ChipCap.FlgIsHwAntennaDiversitySup = FALSE;
#ifdef STREAM_MODE_SUPPORT
	MT7637_ChipCap.FlgHwStreamMode = FALSE;
#endif
#ifdef TXBF_SUPPORT
	MT7637_ChipCap.FlgHwTxBfCap     = TRUE;
	MT7637_ChipCap.FlgITxBfBinWrite = FALSE;
#endif
	MT7637_ChipCap.asic_caps = (fASIC_CAP_PMF_ENC | fASIC_CAP_MCS_LUT);
	MT7637_ChipCap.phy_caps = (fPHY_CAP_24G | fPHY_CAP_5G | fPHY_CAP_HT | fPHY_CAP_LDPC | fPHY_CAP_VHT);
	MT7637_ChipCap.MaxNumOfRfId = MAX_RF_ID;
	MT7637_ChipCap.pRFRegTable = NULL;
	MT7637_ChipCap.MaxNumOfBbpId = 200;
	MT7637_ChipCap.pBBPRegTable = NULL;
	MT7637_ChipCap.bbpRegTbSize = 0;
#ifdef NEW_MBSSID_MODE
#ifdef ENHANCE_NEW_MBSSID_MODE
	MT7637_ChipCap.MBSSIDMode = MBSSID_MODE4;
#else
	MT7637_ChipCap.MBSSIDMode = MBSSID_MODE1;
#endif /* ENHANCE_NEW_MBSSID_MODE */
#else
	MT7637_ChipCap.MBSSIDMode = MBSSID_MODE0;
#endif /* NEW_MBSSID_MODE */
#ifdef RTMP_EFUSE_SUPPORT
	MT7637_ChipCap.EFUSE_USAGE_MAP_START = 0x1e0;
	MT7637_ChipCap.EFUSE_USAGE_MAP_END = 0x1fc;
	MT7637_ChipCap.EFUSE_USAGE_MAP_SIZE = 29;
	MT7637_ChipCap.EFUSE_RESERVED_SIZE = 22;	/* Cal-Free is 22 free block */
#endif
	MT7637_ChipCap.EEPROM_DEFAULT_BIN = MT7637_E2PImage;
	MT7637_ChipCap.EEPROM_DEFAULT_BIN_SIZE = sizeof(MT7637_E2PImage);
	MT7637_ChipCap.EFUSE_BUFFER_CONTENT_SIZE = 0x170;
#ifdef CONFIG_ANDES_SUPPORT
	MT7637_ChipCap.CmdRspRxRing = RX_RING1;
	MT7637_ChipCap.need_load_fw = TRUE;
	MT7637_ChipCap.DownLoadType = DownLoadTypeB;
#if defined(WCX_SUPPORT) || defined(COMPOS_TESTMODE_WIN)
	MT7637_ChipCap.load_code_method = BIN_FILE_METHOD;
#else
	/*MT7637_ChipCap.load_code_method = BIN_FILE_METHOD;*/
	MT7637_ChipCap.load_code_method = HEADER_METHOD;
#endif /* WCX_SUPPORT */
	MT7637_ChipCap.rom_patch_header_image = mt7637_rom_patch;
	MT7637_ChipCap.rom_patch_bin_file_name = MT7637_ROM_PATCH_BIN_FILE_NAME;
	MT7637_ChipCap.rom_patch_len = sizeof(mt7637_rom_patch);
	MT7637_ChipCap.need_load_rom_patch = TRUE;
	MT7637_ChipCap.ram_code_protect = FALSE;
	MT7637_ChipCap.rom_code_protect = TRUE;
	MT7637_ChipCap.ilm_offset = 0x80000;
	MT7637_ChipCap.dlm_offset = 0x110000;
	MT7637_ChipCap.rom_patch_offset = MT7637_ROM_PATCH_START_ADDRESS;
#endif
	MT7637_ChipCap.MCUType = ANDES;
	MT7637_ChipCap.cmd_header_len = ROM_CODE_CMD_HEADER_LEN;
#ifdef RTMP_PCI_SUPPORT
	MT7637_ChipCap.cmd_padding_len = 0;
#endif
#ifdef RTMP_SDIO_SUPPORT
	MT7637_ChipCap.cmd_padding_len = 4;
#endif
#ifdef RTMP_USB_SUPPORT
	MT7637_ChipCap.cmd_padding_len = 4;
	MT7637_ChipCap.CommandBulkOutAddr = 0x8;
	MT7637_ChipCap.WMM0ACBulkOutAddr[0] = 0x5;
	MT7637_ChipCap.WMM0ACBulkOutAddr[1] = 0x4;
	MT7637_ChipCap.WMM0ACBulkOutAddr[2] = 0x6;
	MT7637_ChipCap.WMM0ACBulkOutAddr[3] = 0x7;
	MT7637_ChipCap.WMM1ACBulkOutAddr	= 0x9;
	MT7637_ChipCap.DataBulkInAddr = 0x84;
	MT7637_ChipCap.CommandRspBulkInAddr = 0x85;
#endif
	MT7637_ChipCap.fw_header_image = MT7637_FirmwareImage;
	/* MT7637_ChipCap.fw_header_image = FW7637TEST; */
	MT7637_ChipCap.fw_bin_file_name = MT7637_FW_BIN_FILE_NAME;
	MT7637_ChipCap.fw_len = sizeof(MT7637_FirmwareImage);
	/* MT7637_ChipCap.fw_len = sizeof(FW7637TEST); */
#ifdef CARRIER_DETECTION_SUPPORT
	MT7637_ChipCap.carrier_func = TONE_RADAR_V2;
#endif
#ifdef CONFIG_WIFI_TEST
	MT7637_ChipCap.MemMapStart = 0x0000;
	MT7637_ChipCap.MemMapEnd = 0xffff;
	MT7637_ChipCap.MacMemMapOffset = 0x1000;
	MT7637_ChipCap.MacStart = 0x0000;
	MT7637_ChipCap.MacEnd = 0x0600;
	MT7637_ChipCap.BBPMemMapOffset = 0x2000;
	MT7637_ChipCap.BBPStart = 0x0000;
	MT7637_ChipCap.BBPEnd = 0x0f00;
	MT7637_ChipCap.RFIndexNum = 0;
	MT7637_ChipCap.RFIndexOffset = 0;
	MT7637_ChipCap.E2PStart = 0x0000;
	MT7637_ChipCap.E2PEnd = 0x00fe;
#endif /* CONFIG_WIFI_TEST */
	MT7637_ChipCap.hif_type = HIF_MT;
	MT7637_ChipCap.rf_type = RF_MT;
	MT7637_ChipCap.TxAggLimit = 64;
	MT7637_ChipCap.RxBAWinSize = 64;
#ifdef COEX_SUPPORT
	MT7637_ChipCap.TxBAWinSize = 64;
#endif /* COEX_SUPPORT */
#ifdef RTMP_USB_SUPPORT
	MT7637_ChipCap.UsbAggBufSize = 0x8000; /* 32KB */
#endif
	MT7637_ChipCap.AMPDUFactor = 7;
#ifdef DOT11_VHT_AC
	MT7637_ChipCap.MaxMPDULength = MPDU_7991_OCTETS;
	MT7637_ChipCap.MaxAMPDULengthExp = 7;
#endif /* DOT11_VHT_AC */
	MT7637_ChipCap.default_txop = 0x20;
	MT7637_ChipCap.CurrentTxOP = 0x0;
#ifdef RACTRL_FW_OFFLOAD_SUPPORT
	MT7637_ChipCap.fgRateAdaptFWOffload = TRUE;
#endif /* RACTRL_FW_OFFLOAD_SUPPORT */
	MT7637_ChipCap.WmmHwNum = MT7637_MT_WMM_SIZE;
	MT7637_ChipCap.PDA_PORT = MT7637_PDA_PORT;
	MT7637_ChipCap.SupportAMSDU = FALSE;
#if !defined(COMPOS_TESTMODE_WIN)
	MT7637_ChipCap.qm = GENERIC_QM;
#endif
	MT7637_ChipCap.tm = TASKLET_METHOD;
	MT7637_ChipCap.wmm_detect_method = WMM_DETECT_METHOD1;
	/* for interrupt enable mask */
	MT7637_ChipCap.int_enable_mask = ((MT_DELAYINTMASK) | (MT_RxINT | MT_INT_T0_DONE | 
						MT_INT_T1_DONE | MT_INT_T2_DONE | 
						MT_INT_T3_DONE | MT_TxMgmtInt) | MT_INT_BMC_DLY);
#if (CFG_CPU_LOADING_RXRING_DLY == 1)
	MT7637_ChipCap.int_enable_mask &= ~(MT_INT_RX_DATA | MT_INT_RX_CMD);
	MT7637_ChipCap.int_enable_mask |= MT_INT_RX_DLY;
#endif
#if (CFG_CPU_LOADING_DISABLE_TXDONE0 == 1)
	MT7637_ChipCap.int_enable_mask &= ~MT_INT_AC0_DLY;
#endif
}


static VOID mt7637_chipOp_init(VOID)
{
	os_zero_mem(&MT7637_ChipOp, sizeof(RTMP_CHIP_OP));
	MT7637_ChipOp.ChipBBPAdjust = mt7637_bbp_adjust;
	MT7637_ChipOp.ChipSwitchChannel = mt7637_switch_channel;
	MT7637_ChipOp.AsicMacInit = mt7637_init_mac_cr;
	MT7637_ChipOp.AsicAntennaDefaultReset = mt7637_antenna_default_reset;
	MT7637_ChipOp.ChipAGCInit = NULL;
#ifdef CONFIG_STA_SUPPORT
	MT7637_ChipOp.ChipAGCAdjust = NULL;
#endif
	MT7637_ChipOp.AsicRfTurnOn = NULL;
	MT7637_ChipOp.AsicHaltAction = NULL;
	MT7637_ChipOp.AsicRfTurnOff = NULL;
	MT7637_ChipOp.AsicReverseRfFromSleepMode = NULL;
#ifdef CONFIG_STA_SUPPORT
	MT7637_ChipOp.NetDevNickNameInit = mt7637_init_dev_nick_name;
#endif
#ifdef CARRIER_DETECTION_SUPPORT
	MT7637_ChipOp.ToneRadarProgram = ToneRadarProgram_v2;
#endif
	MT7637_ChipOp.RxSensitivityTuning = NULL;
	MT7637_ChipOp.DisableTxRx = NULL;
#ifdef RTMP_USB_SUPPORT
	MT7637_ChipOp.AsicRadioOn = NULL;
	MT7637_ChipOp.AsicRadioOff = NULL;
	MT7637_ChipOp.usb_cfg_read = mtusb_cfg_read;
	MT7637_ChipOp.usb_cfg_write = mtusb_cfg_write;
#endif
#ifdef RTMP_PCI_SUPPORT
	/* MT7637_ChipOp.AsicRadioOn = RT28xxPciAsicRadioOn; */
	/* MT7637_ChipOp.AsicRadioOff = RT28xxPciAsicRadioOff; */
#endif
	MT7637_ChipOp.show_pwr_info = mt7637_show_pwr_info;
	MT7637_ChipOp.bufferModeEfuseFill = mt7637_bufferModeEfuseFill;
#ifdef CAL_FREE_IC_SUPPORT
	MT7637_ChipOp.is_cal_free_ic = mt7637_is_cal_free_ic;
	MT7637_ChipOp.cal_free_data_get = mt7637_cal_free_data_get;
#endif /* CAL_FREE_IC_SUPPORT */
#ifdef MT_WOW_SUPPORT
	MT7637_ChipOp.AsicWOWEnable = MT76xxAndesWOWEnable;
	MT7637_ChipOp.AsicWOWDisable = MT76xxAndesWOWDisable;
	/* MT7637_ChipOp.AsicWOWInit = MT76xxAndesWOWInit, */
#endif /* MT_WOW_SUPPORT */
	MT7637_ChipOp.MtCmdTx = MtCmdSendMsg;
	MT7637_ChipOp.fw_prepare = mt7637_fw_prepare;
#ifdef TXBF_SUPPORT
	MT7637_ChipOp.setETxBFCap    = mt7637_setETxBFCap;
#ifdef VHT_TXBF_SUPPORT
	MT7637_ChipOp.setVHTETxBFCap = mt7637_setVHTETxBFCap;
#endif /* VHT_TXBF_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
	MT7637_ChipOp.archSetAid     = MtAsicSetAid;
#endif /* CONFIG_STA_SUPPORT */
#endif /* TXBF_SUPPORT */
}

#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
static INT Mt7637AsicArchOpsInit(RTMP_ADAPTER *pAd)
{
	RTMP_ARCH_OP *arch_ops = &pAd->archOps;

	arch_ops->archSetDevMac = MtAsicSetDevMacByFw;
	arch_ops->archSetBssid = MtAsicSetBssidByFw;
	arch_ops->archSetStaRec = MtAsicSetStaRecByFw;
#ifdef BCN_OFFLOAD_SUPPORT
	arch_ops->archEnableBeacon = NULL;
	arch_ops->archDisableBeacon = NULL;
	arch_ops->archUpdateBeacon = MtUpdateBcnAndTimToMcu;
#else
	arch_ops->archDisableBeacon = MtSmacAsicDisableBeacon;
	arch_ops->archEnableBeacon = MtSmacAsicEnableBeacon;
	arch_ops->archUpdateBeacon = MtUpdateBeaconToAsic;
#endif
#ifdef CONFIG_AP_SUPPORT
	arch_ops->archSetMbssWdevIfAddr = MtAsicSetMbssWdevIfAddrGen2;
	arch_ops->archSetMbssHwCRSetting = MtSmacSetMbssHwCRSetting;
	arch_ops->archSetExtTTTTHwCRSetting = MtSmacSetExtTTTTHwCRSetting;
	arch_ops->archSetExtMbssEnableCR = MtSmacSetExtMbssEnableCR;
#endif /* CONFIG_AP_SUPPORT */
	arch_ops->archGetTsfTime = MtAsicGetTsfTimeByDriver;/* TODO: Carter, check this. */
	arch_ops->archSetPreTbtt = MtAsicSetPreTbtt;
	arch_ops->archUpdateProtect = MtAsicUpdateProtect;
	arch_ops->archSetRDG = NULL;
#ifdef APCLI_SUPPORT
#ifdef MAC_REPEATER_SUPPORT
	arch_ops->archSetReptFuncEnable = MtAsicSetReptFuncEnableByFw;
	arch_ops->archInsertRepeaterEntry = MtAsicInsertRepeaterEntryByFw;
	arch_ops->archRemoveRepeaterEntry = MtAsicRemoveRepeaterEntryByFw;
	arch_ops->archInsertRepeaterRootEntry = MtAsicInsertRepeaterRootEntryByFw;
#endif /* MAC_REPEATER_SUPPORT */
#endif /* APCLI_SUPPORT */
	arch_ops->archDisableSync = NULL;/* MtAsicDisableSyncByDriver; */
	arch_ops->archSetSyncModeAndEnable = NULL;/* MtAsicEnableBssSyncByDriver; */
#ifdef CONFIG_STA_SUPPORT
	arch_ops->archEnableIbssSync = NULL;/* MtAsicEnableBssSyncByDriver; */
#endif
#ifdef CONFIG_AP_SUPPORT
	arch_ops->archGetTxTsc = MtAsicGetTxTscByDriver;
#endif /* CONFIG_AP_SUPPORT */
	arch_ops->archDelWcidTab = MtAsicDelWcidTabByFw;
	arch_ops->archAddRemoveKeyTab = MtAsicAddRemoveKeyTabByFw;
	arch_ops->archUpdateRxWCIDTable = MtAsicUpdateRxWCIDTableByFw;
	arch_ops->archUpdateBASession = MtAsicUpdateBASessionByFw;
	arch_ops->archSetSMPS = MtAsicSetSMPSByDriver;
#ifdef MT_PS
	arch_ops->archSetIgnorePsm = MtSetIgnorePsmByDriver;
#endif
	arch_ops->rx_pkt_process = mt_rx_pkt_process;
#ifdef MAC_INIT_OFFLOAD
	arch_ops->archSetMacTxRx = MtAsicSetMacTxRxByFw;
#else
	arch_ops->archSetMacTxRx = MtAsicSetMacTxRx;
#endif /*MAC_INIT_OFFLOAD*/
#ifdef MAC_INIT_OFFLOAD
	arch_ops->archSetMacMaxLen = NULL;
#else
	arch_ops->archSetMacMaxLen = MtAsicSetMacMaxLen;
#endif
#ifdef MAC_INIT_OFFLOAD
	arch_ops->archSetTxStream = NULL;
#else
	arch_ops->archSetTxStream = MtAsicSetTxStream;
#endif
#ifdef MAC_INIT_OFFLOAD
	arch_ops->archSetRxStream = NULL;
#else
	arch_ops->archSetRxStream = MtAsicSetRxStream;
#endif
#ifdef MAC_INIT_OFFLOAD
	arch_ops->archSetRxFilter = NULL;/* MtAsicSetRxFilter; */
#else
	arch_ops->archSetRxFilter = MtAsicSetRxFilter;
#endif
#ifdef IGMP_SNOOP_SUPPORT
	arch_ops->archMcastEntryInsert = MulticastFilterTableInsertEntry;
	arch_ops->archMcastEntryDelete = MulticastFilterTableDeleteEntry;
#endif
	arch_ops->write_tmac_info_fixed_rate = mt_write_tmac_info_fixed_rate;
	arch_ops->write_tmac_info = mt_write_tmac_info;
#if !defined(COMPOS_TESTMODE_WIN)
	arch_ops->hw_tx = mt_hw_tx;
	arch_ops->mlme_hw_tx = mt_mlme_hw_tx;
#endif
#ifdef RTMP_PCI_SUPPORT

	if (IS_PCIE_INF(pAd)) {
		arch_ops->write_tx_resource = mt_pci_write_tx_resource;
		arch_ops->write_multi_tx_resource = mt_pci_write_multi_tx_resource;
		arch_ops->write_final_tx_resource = mt_pci_write_final_tx_resource;
		arch_ops->kickout_data_tx = pci_kickout_data_tx;
		arch_ops->get_pkt_from_rx_resource = pci_get_pkt_from_rx_resource;
		arch_ops->get_tx_resource_free_num = pci_get_tx_resource_free_num;
	}

#endif
#ifdef RTMP_USB_SUPPORT

	if (IS_USB_INF(pAd)) {
		arch_ops->write_tx_resource = usb_write_tx_resource;
		arch_ops->write_multi_tx_resource = usb_write_multi_tx_resource;
		arch_ops->write_final_tx_resource = mt_usb_write_final_tx_resource;
		arch_ops->kickout_data_tx = usb_kickout_data_tx;
		arch_ops->get_pkt_from_rx_resource = usb_get_pkt_from_rx_resource;
		arch_ops->get_tx_resource_free_num = usb_get_tx_resource_free_num;
	}

#endif
	arch_ops->rx_done_handle = rtmp_rx_done_handle;
	return TRUE;
}
#endif

VOID mt7637_init(RTMP_ADAPTER *pAd)
{
	RTMP_CHIP_CAP *pChipCap = &pAd->chipCap;

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s()-->\n", __func__));
	mt7637_chipCap_init(pAd);
	mt7637_chipOp_init();
	memcpy(&pAd->chipCap, &MT7637_ChipCap, sizeof(RTMP_CHIP_CAP));
	memcpy(&pAd->chipOps, &MT7637_ChipOp, sizeof(RTMP_CHIP_OP));
	pAd->chipCap.hif_type = HIF_MT;
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
#else
	Mt7637AsicArchOpsInit(pAd);
#endif
	pAd->chipCap.mac_type = MAC_MT;
#if defined(COMPOS_TESTMODE_WIN)
#else
	mt_phy_probe(pAd);
#endif
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(FW(%x), HW(%x), CHIPID(%x))\n",
			 __func__,
			 pAd->FWVersion,
			 pAd->HWVersion,
			 pAd->ChipID));
#ifdef RTMP_MAC_PCI

	if (IS_PCI_INF(pAd)) {
		pChipCap->tx_hw_hdr_len = pChipCap->TXWISize;
		pChipCap->rx_hw_hdr_len = pChipCap->RXWISize;
	}

#endif /* RTMP_MAC_PCI */
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd)) {
		pChipCap->tx_hw_hdr_len = pChipCap->TXWISize;
		pChipCap->rx_hw_hdr_len = pChipCap->RXWISize;
	}

#endif /* RTMP_MAC_USB */
#ifdef RTMP_MAC_SDIO

	if (IS_SDIO_INF(pAd)) {
		pChipCap->tx_hw_hdr_len = pChipCap->TXWISize;
		pChipCap->rx_hw_hdr_len = pChipCap->RXWISize;
	}

#endif /* RTMP_MAC_PCI */
#ifdef CONFIG_CSO_SUPPORT
	pChipCap->asic_caps |= fASIC_CAP_CSO;
#endif
#if !defined(COMPOS_TESTMODE_WIN)
#ifdef RATE_ADAPT_AGBS_SUPPORT
	RTMP_DRS_ALG_INIT(pAd, RATE_ALG_AGBS);
#else
	RTMP_DRS_ALG_INIT(pAd, RATE_ALG_GRP);
#endif /* RATE_ADAPT_AGBS_SUPPORT */
#endif
	/*
		Following function configure beacon related parameters
		in pChipCap
			FlgIsSupSpecBcnBuf / BcnMaxHwNum /
			WcidHwRsvNum / BcnMaxHwSize / BcnBase[]
	*/
#if defined(COMPOS_WIN) || defined(COMPOS_TESTMODE_WIN)
	/* TODO: BJBJ */
#else
	mt_bcn_buf_init(pAd);
#endif
#ifdef DOT11W_PMF_SUPPORT
	pChipCap->FlgPMFEncrtptMode = PMF_ENCRYPT_MODE_2;
#endif /* DOT11W_PMF_SUPPORT */
	pChipCap->OmacNums = 5;
	pChipCap->BssNums = 4;
	pChipCap->ExtMbssOmacStartIdx = 0x10;
	pChipCap->RepeaterStartIdx = 0x20;
	pChipCap->MaxRepeaterNum = 16;
#ifdef BCN_OFFLOAD_SUPPORT
	pChipCap->fgBcnOffloadSupport = TRUE;
	pChipCap->fgIsNeedPretbttIntEvent = TRUE;
#endif
#ifdef DOT11_VHT_AC
	pChipCap->ac_off_mode = 0;
#endif /* DOT11_VHT_AC */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("<--%s()\n", __func__));
}

