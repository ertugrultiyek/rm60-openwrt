/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	andes_core.c
*/
#include "rt_config.h"

struct cmd_msg *AndesAllocCmdMsg(RTMP_ADAPTER *ad, unsigned int length)
{
	struct cmd_msg *msg = NULL;
	RTMP_CHIP_CAP *cap = &ad->chipCap;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;
	PNDIS_PACKET net_pkt = NULL;
#ifdef RTMP_USB_SUPPORT
	PURB urb = NULL;
#endif
	INT32 AllocateSize = cap->cmd_header_len + length + cap->cmd_padding_len;
#ifdef RTMP_SDIO_SUPPORT

	if (AllocateSize >= ad->BlockSize)
		AllocateSize = (AllocateSize + ((-AllocateSize) & (ad->BlockSize - 1)));

#endif
	net_pkt = RTMP_AllocateFragPacketBuffer(ad, AllocateSize);

	if (!net_pkt) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("can not allocate net_pkt\n"));
		goto error0;
	}

	OS_PKT_RESERVE(net_pkt, cap->cmd_header_len);
	os_alloc_mem(NULL, (PUCHAR *)&msg, sizeof(*msg));

	if (!msg) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("can not allocate cmd msg\n"));
		goto error1;
	}

	CMD_MSG_CB(net_pkt)->msg = msg;
	os_zero_mem(msg, sizeof(*msg));
#ifdef RTMP_USB_SUPPORT
	urb = RTUSB_ALLOC_URB(0);

	if (!urb) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("can not allocate urb\n"));
		goto error2;
	}

	msg->urb = urb;
#ifdef USB_IOT_WORKAROUND2
	os_alloc_mem(NULL, (PUCHAR *) &(msg->usb_iot_w2_buf),
				 AllocateSize + W2_IOT_MAX_PADDING_SIZE);

	if (!(msg->usb_iot_w2_buf)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR,
				 ("can not allocate urb\n"));
		goto error2;
	}

#endif
#endif
	msg->priv = (void *)ad;
	msg->net_pkt = net_pkt;
	ctl->alloc_cmd_msg++;
	return msg;
#ifdef RTMP_USB_SUPPORT
error2:
#ifdef USB_IOT_WORKAROUND2

	if (urb)
		RTUSB_FREE_URB(urb);

#endif
#endif

	if (msg)
		os_free_mem(msg);

error1:
	RTMPFreeNdisPacket(ad, net_pkt);
error0:
	return NULL;
}

VOID AndesInitCmdMsg(struct cmd_msg *msg, CMD_ATTRIBUTE attr)
{
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_INFO,
			 ("%s:: mcu_dest(%d), cmd_type(0x%x), ExtCmdType(0x%x)\n",
			  __func__, attr.mcu_dest, attr.type, attr.ext_type));
	SET_CMD_MSG_PORT_QUEUE_ID(msg, GetRealPortQueueID(msg, attr.type));
	SET_CMD_MSG_MCU_DEST(msg, attr.mcu_dest);
	SET_CMD_MSG_TYPE(msg, attr.type);
	SET_CMD_MSG_CTRL_FLAGS(msg, attr.ctrl.flags);
	SET_CMD_MSG_EXT_TYPE(msg, attr.ext_type);
	SET_CMD_MSG_CTRL_RSP_WAIT_MS_TIME(msg, attr.ctrl.wait_ms_time);

	if (IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg))
		RTMP_OS_INIT_COMPLETION(&msg->ack_done);

#ifdef RTMP_USB_SUPPORT

	if (IS_CMD_MSG_NEED_RETRY_FLAG_SET(msg))
		SET_CMD_MSG_RETRY_TIMES(msg, CMD_MSG_RETRANSMIT_TIMES);

#else
	SET_CMD_MSG_RETRY_TIMES(msg, 0);
#endif
	SET_CMD_MSG_CTRL_RSP_EXPECT_SIZE(msg, attr.ctrl.expect_size);
	SET_CMD_MSG_RSP_WB_BUF_IN_CALBK(msg, attr.rsp.wb_buf_in_calbk);
	SET_CMD_MSG_RSP_HANDLER(msg, attr.rsp.handler);
#ifdef RTMP_SDIO_SUPPORT
	RTMP_OS_INIT_COMPLETION(&msg->tx_sdio_done);
#endif
}

VOID AndesAppendCmdMsg(struct cmd_msg *msg, char *data, unsigned int len)
{
	PNDIS_PACKET net_pkt;

	if (!msg)
		return;

	net_pkt = msg->net_pkt;

	if (data)
		memcpy(OS_PKT_TAIL_BUF_EXTEND(net_pkt, len), data, len);
}


VOID AndesAppendHeadCmdMsg(struct cmd_msg *msg, char *data, unsigned int len)
{
	PNDIS_PACKET net_pkt = msg->net_pkt;

	if (data)
		memcpy(OS_PKT_HEAD_BUF_EXTEND(net_pkt, len), data, len);
}

VOID AndesFreeCmdMsg(struct cmd_msg *msg)
{
	RTMP_ADAPTER *ad = NULL;
	ULONG flags = 0;
	struct MCU_CTRL *ctl = NULL;

	if (!msg)
		return;

	ad = (RTMP_ADAPTER *)(msg->priv);

	if (!ad) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s: pAd is null\n", __func__));
		goto free_memory;
	}

	ctl = &ad->MCUCtrl;

	if (!ctl) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s: MCUCtrl is null\n", __func__));
		goto free_memory;
	}

	if (IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg))
		RTMP_OS_EXIT_COMPLETION(&msg->ack_done);

#ifdef RTMP_SDIO_SUPPORT
	RTMP_OS_EXIT_COMPLETION(&msg->tx_sdio_done);
#endif
	OS_SPIN_LOCK_IRQSAVE(&ctl->msg_lock, &flags);
	ctl->free_cmd_msg++;
	OS_SPIN_UNLOCK_IRQRESTORE(&ctl->msg_lock, &flags);
free_memory:
#ifdef RTMP_USB_SUPPORT

	if (msg->urb)
		RTUSB_FREE_URB(msg->urb);

#ifdef USB_IOT_WORKAROUND2

	if (msg->usb_iot_w2_buf)
		os_free_mem(msg->usb_iot_w2_buf);

#endif
#endif
#if defined(RTMP_USB_SUPPORT) || defined(RTMP_SDIO_SUPPORT)

	if (ad && msg->net_pkt)
		RTMPFreeNdisPacket(ad, msg->net_pkt);

#endif
	os_free_mem(msg);
}

VOID AndesForceFreeCmdMsg(struct cmd_msg *msg)
{
	RTMP_ADAPTER *ad = NULL;
	struct MCU_CTRL *ctl = NULL;
	ULONG flags = 0;

	if (!msg)
		return;

	ad = (RTMP_ADAPTER *)(msg->priv);

	if (!ad) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s: pAd is null\n", __func__));
		goto free_memory;
	}

	ctl = &ad->MCUCtrl;

	if (!ctl) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s: MCUCtrl is null\n", __func__));
		goto free_memory;
	}

	if (IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg))
		RTMP_OS_EXIT_COMPLETION(&msg->ack_done);

#ifdef RTMP_SDIO_SUPPORT
	RTMP_OS_EXIT_COMPLETION(&msg->tx_sdio_done);
#endif
#ifdef RTMP_USB_SUPPORT

	if (msg->urb)
		RTUSB_FREE_URB(msg->urb);

#endif
	OS_SPIN_LOCK_IRQSAVE(&ctl->msg_lock, &flags);
	ctl->free_cmd_msg++;
	OS_SPIN_UNLOCK_IRQRESTORE(&ctl->msg_lock, &flags);
free_memory:

	if (ad && msg->net_pkt)
		RTMPFreeNdisPacket(ad, msg->net_pkt);

	os_free_mem(msg);
}


BOOLEAN IsInbandCmdProcessing(RTMP_ADAPTER *ad)
{
	BOOLEAN ret = 0;
	return ret;
}


UCHAR GetCmdRspNum(RTMP_ADAPTER *ad)
{
	UCHAR Num = 0;
	return Num;
}


VOID AndesIncErrorCount(struct MCU_CTRL *ctl, enum cmd_msg_error_type type)
{
	if (OS_TEST_BIT(MCU_INIT, &ctl->flags)) {
		switch (type) {
		case error_tx_kickout_fail:
			ctl->tx_kickout_fail_count++;
			break;

		case error_tx_timeout_fail:
			ctl->tx_timeout_fail_count++;
			break;

		case error_rx_receive_fail:
			ctl->rx_receive_fail_count++;
			break;

		default:
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s:unknown cmd_msg_error_type(%d)\n",
					  __func__, type));
		}
	}
}


static NDIS_SPIN_LOCK *AndesGetSpinLock(struct MCU_CTRL *ctl, DL_LIST *list)
{
	NDIS_SPIN_LOCK *lock = NULL;

	if (list == &ctl->txq)
		lock = &ctl->txq_lock;
	else if (list == &ctl->rxq)
		lock = &ctl->rxq_lock;
	else if (list == &ctl->ackq)
		lock = &ctl->ackq_lock;
	else if (list == &ctl->kickq)
		lock = &ctl->kickq_lock;
	else if (list == &ctl->tx_doneq)
		lock = &ctl->tx_doneq_lock;
	else if (list == &ctl->rx_doneq)
		lock = &ctl->rx_doneq_lock;

#ifdef RTMP_SDIO_SUPPORT
	else if (list == &ctl->txq_sdio)
		lock = &ctl->txq_sdio_lock;

#endif
	else {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("list pointer = %p\n", list));
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("txq = %p, rxq = %p, ackq = %p, kickq = %p, tx_doneq = %p, rx_doneq = %p\n",
				  &ctl->txq, &ctl->rxq, &ctl->ackq, &ctl->kickq,
				  &ctl->tx_doneq, &ctl->rx_doneq));
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s:illegal list\n", __func__));
	}

	return lock;
}


static inline UCHAR AndesGetCmdMsgSeq(RTMP_ADAPTER *ad)
{
	struct MCU_CTRL *ctl = &ad->MCUCtrl;
	struct cmd_msg *msg;
	unsigned long flags;

	RTMP_SPIN_LOCK_IRQSAVE(&ctl->ackq_lock, &flags);
get_seq:
	ctl->cmd_seq >= 0xf ? ctl->cmd_seq = 1 : ctl->cmd_seq++;
	DlListForEach(msg, &ctl->ackq, struct cmd_msg, list) {
		if (msg->seq == ctl->cmd_seq) {
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("command(seq: %d) is still running\n", ctl->cmd_seq));
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("command response nums = %d\n", GetCmdRspNum(ad)));
			goto get_seq;
		}
	}
	RTMP_SPIN_UNLOCK_IRQRESTORE(&ctl->ackq_lock, &flags);
	return ctl->cmd_seq;
}


static VOID _AndesQueueTailCmdMsg(DL_LIST *list, struct cmd_msg *msg, enum cmd_msg_state state)
{
	msg->state = state;
	DlListAddTail(list, &msg->list);
}


VOID AndesQueueTailCmdMsg(DL_LIST *list, struct cmd_msg *msg, enum cmd_msg_state state)
{
	unsigned long flags;
	NDIS_SPIN_LOCK *lock;
	RTMP_ADAPTER *ad = (RTMP_ADAPTER *)msg->priv;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	lock = AndesGetSpinLock(ctl, list);

	if (lock) {
		RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
		_AndesQueueTailCmdMsg(list, msg, state);
		RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);
	}
}


static VOID _AndesQueueHeadCmdMsg(DL_LIST *list, struct cmd_msg *msg, enum cmd_msg_state state)
{
	msg->state = state;
	DlListAdd(list, &msg->list);
}


VOID AndesQueueHeadCmdMsg(DL_LIST *list, struct cmd_msg *msg, enum cmd_msg_state state)
{
	unsigned long flags;
	NDIS_SPIN_LOCK *lock;
	RTMP_ADAPTER *ad = (RTMP_ADAPTER *)msg->priv;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	lock = AndesGetSpinLock(ctl, list);

	if (lock) {
		RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
		_AndesQueueHeadCmdMsg(list, msg, state);
		RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);
	}
}

UINT32 AndesQueueLen(struct MCU_CTRL *ctl, DL_LIST *list)
{
	UINT32 qlen = 0;
	unsigned long flags;
	NDIS_SPIN_LOCK *lock;

	lock = AndesGetSpinLock(ctl, list);

	if (lock) {
		RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
		qlen = DlListLen(list);
		RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);
	}

	return qlen;
}

/*AndesQueueEmpty is uselsess, disable it*/
#if 0
static INT32 AndesQueueEmpty(struct MCU_CTRL *ctl, DL_LIST *list)
{
	unsigned long flags;
	int is_empty;
	NDIS_SPIN_LOCK *lock;

	lock = AndesGetSpinLock(ctl, list);
	RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
	is_empty = DlListEmpty(list);
	RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);
	return is_empty;
}
#endif

static VOID AndesQueueInit(struct MCU_CTRL *ctl, DL_LIST *list)
{
	unsigned long flags;
	NDIS_SPIN_LOCK *lock;

	lock = AndesGetSpinLock(ctl, list);

	if (lock) {
		RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
		DlListInit(list);
		RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);
	}
}


VOID _AndesUnlinkCmdMsg(struct cmd_msg *msg, DL_LIST *list)
{
	if (!msg)
		return;

	DlListDel(&msg->list);
}


VOID AndesUnlinkCmdMsg(struct cmd_msg *msg, DL_LIST *list)
{
	unsigned long flags;
	NDIS_SPIN_LOCK *lock;
	RTMP_ADAPTER *ad = (RTMP_ADAPTER *)msg->priv;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	lock = AndesGetSpinLock(ctl, list);

	if (lock) {
		RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
		_AndesUnlinkCmdMsg(msg, list);
		RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);
	}
}


static struct cmd_msg *_AndesDequeueCmdMsg(DL_LIST *list)
{
	struct cmd_msg *msg;

	msg = DlListFirst(list, struct cmd_msg, list);
	_AndesUnlinkCmdMsg(msg, list);
	return msg;
}


struct cmd_msg *AndesDequeueCmdMsg(struct MCU_CTRL *ctl, DL_LIST *list)
{
	unsigned long flags;
	struct cmd_msg *msg = NULL;
	NDIS_SPIN_LOCK *lock;

	lock = AndesGetSpinLock(ctl, list);

	if (lock) {
		RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
		msg = _AndesDequeueCmdMsg(list);
		RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);
	}

	return msg;
}


#ifdef RTMP_SDIO_SUPPORT
VOID SdioKickOutCmdMsgComplete(struct cmd_msg *msg)
{
	RTMP_ADAPTER *pAd = (RTMP_ADAPTER *)msg->priv;
	struct MCU_CTRL *ctl = &pAd->MCUCtrl;

	if (!OS_TEST_BIT(MCU_INIT, &ctl->flags))
		return;

	if (!IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg)) {
		AndesUnlinkCmdMsg(msg, &ctl->kickq);
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_INFO,
				 ("%s: msg state = %d\n", __func__, msg->state));
		AndesQueueTailCmdMsg(&ctl->tx_doneq, msg, tx_done);
	} else
		msg->state = wait_ack;

	AndesBhSchedule(pAd);
}
#endif

#ifdef RTMP_PCI_SUPPORT
VOID PciKickOutCmdMsgComplete(PNDIS_PACKET net_pkt)
{
	struct cmd_msg *msg = CMD_MSG_CB(net_pkt)->msg;
	RTMP_ADAPTER *ad = (RTMP_ADAPTER *)msg->priv;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	if (!OS_TEST_BIT(MCU_INIT, &ctl->flags))
		return;

	if (!IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg)) {
		AndesUnlinkCmdMsg(msg, &ctl->kickq);
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_INFO,
				 ("%s: msg state = %d\n", __func__, msg->state));
		AndesQueueTailCmdMsg(&ctl->tx_doneq, msg, tx_done);
	} else  {
		if (msg->state != tx_done)
			msg->state = wait_ack;
	}

	AndesBhSchedule(ad);
}
#endif /* RTMP_PCI_SUPPORT */


#ifdef RTMP_USB_SUPPORT
static VOID UsbRxCmdMsgComplete(PURB urb)
{
	PNDIS_PACKET net_pkt = (PNDIS_PACKET)RTMP_OS_USB_CONTEXT_GET(urb);
	struct cmd_msg *msg = CMD_MSG_CB(net_pkt)->msg;
	RTMP_ADAPTER *ad = (RTMP_ADAPTER *)msg->priv;
	POS_COOKIE pObj = (POS_COOKIE)ad->OS_Cookie;
	RTMP_CHIP_CAP *pChipCap = &ad->chipCap;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;
	enum cmd_msg_state state;
	unsigned long flags;
	int ret = 0;

	AndesUnlinkCmdMsg(msg, &ctl->rxq);
	OS_PKT_TAIL_BUF_EXTEND(net_pkt, RTMP_USB_URB_LEN_GET(urb));

	if (RTMP_USB_URB_STATUS_GET(urb) == 0)
		state = rx_done;
	else {
		state = rx_receive_fail;
		AndesIncErrorCount(ctl, error_rx_receive_fail);
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("receive cmd msg fail(%d)\n", RTMP_USB_URB_STATUS_GET(urb)));
	}

	RTMP_SPIN_LOCK_IRQSAVE(&ctl->rx_doneq_lock, &flags);
	_AndesQueueTailCmdMsg(&ctl->rx_doneq, msg, state);
	RTMP_SPIN_UNLOCK_IRQRESTORE(&ctl->rx_doneq_lock, &flags);

	if (OS_TEST_BIT(MCU_INIT, &ctl->flags)) {
		msg = AndesAllocCmdMsg(ad, 512);

		if (!msg)
			return;

		net_pkt = msg->net_pkt;
		RTUSB_FILL_BULK_URB(msg->urb, pObj->pUsb_Dev,
							usb_rcvbulkpipe(pObj->pUsb_Dev, pChipCap->CommandRspBulkInAddr),
							GET_OS_PKT_DATAPTR(net_pkt), 512, UsbRxCmdMsgComplete, net_pkt);
		AndesQueueTailCmdMsg(&ctl->rxq, msg, rx_start);
		ret = RTUSB_SUBMIT_URB(msg->urb);

		if (ret) {
			AndesUnlinkCmdMsg(msg, &ctl->rxq);
			AndesIncErrorCount(ctl, error_rx_receive_fail);
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s:submit urb fail(%d)\n", __func__, ret));
			AndesQueueTailCmdMsg(&ctl->rx_doneq, msg, rx_receive_fail);
		}
	}

	AndesBhSchedule(ad);
}


INT32 UsbRxCmdMsgSubmit(RTMP_ADAPTER *ad)
{
	RTMP_CHIP_CAP *pChipCap = &ad->chipCap;
	POS_COOKIE pObj = (POS_COOKIE)ad->OS_Cookie;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;
	struct cmd_msg *msg = NULL;
	PNDIS_PACKET net_pkt = NULL;
	int ret = 0;

	if (!OS_TEST_BIT(MCU_INIT, &ctl->flags))
		return ret;

	msg =  AndesAllocCmdMsg(ad, 512);

	if (!msg) {
		ret = NDIS_STATUS_RESOURCES;
		return ret;
	}

	net_pkt = msg->net_pkt;
	RTUSB_FILL_BULK_URB(msg->urb, pObj->pUsb_Dev,
						usb_rcvbulkpipe(pObj->pUsb_Dev, pChipCap->CommandRspBulkInAddr),
						GET_OS_PKT_DATAPTR(net_pkt), 512, UsbRxCmdMsgComplete, net_pkt);
	AndesQueueTailCmdMsg(&ctl->rxq, msg, rx_start);
	ret = RTUSB_SUBMIT_URB(msg->urb);

	if (ret) {
		AndesUnlinkCmdMsg(msg, &ctl->rxq);
		AndesIncErrorCount(ctl, error_rx_receive_fail);
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s:submit urb fail(%d)\n", __func__, ret));
		AndesQueueTailCmdMsg(&ctl->rx_doneq, msg, rx_receive_fail);
	}

	return ret;
}


INT32 UsbRxCmdMsgsReceive(RTMP_ADAPTER *ad)
{
	int ret = 0;
	int i;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	for (i = 0; (i < 1) && (AndesQueueLen(ctl, &ctl->rxq) < 1); i++) {
		ret = UsbRxCmdMsgSubmit(ad);

		if (ret)
			break;
	}

	return ret;
}


VOID UsbKickOutCmdMsgComplete(PURB urb)
{
	PNDIS_PACKET net_pkt = (PNDIS_PACKET)RTMP_OS_USB_CONTEXT_GET(urb);
	struct cmd_msg *msg = CMD_MSG_CB(net_pkt)->msg;
	RTMP_ADAPTER *ad = (RTMP_ADAPTER *)msg->priv;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	if (!OS_TEST_BIT(MCU_INIT, &ctl->flags))
		return;

	if (RTMP_USB_URB_STATUS_GET(urb) == 0) {
		if (!IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg)) {
			AndesUnlinkCmdMsg(msg, &ctl->kickq);
			AndesQueueTailCmdMsg(&ctl->tx_doneq, msg, tx_done);
		} else
			msg->state = wait_ack;
	} else  {
		if (!IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg)) {
			AndesUnlinkCmdMsg(msg, &ctl->kickq);
			AndesQueueTailCmdMsg(&ctl->tx_doneq, msg, tx_kickout_fail);
			AndesIncErrorCount(ctl, error_tx_kickout_fail);
		} else {
			AndesUnlinkCmdMsg(msg, &ctl->ackq);
			msg->state = tx_kickout_fail;
			AndesIncErrorCount(ctl, error_tx_kickout_fail);
			RTMP_OS_COMPLETE(&msg->ack_done);
		}

		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("kick out cmd msg fail(%d)\n", RTMP_USB_URB_STATUS_GET(urb)));
	}

	AndesBhSchedule(ad);
}
#endif


VOID AndesRxProcessCmdMsg(RTMP_ADAPTER *ad, struct cmd_msg *rx_msg)
{
	RX_BLK RxBlk;
#ifdef MT_MAC

	if (ad->chipCap.hif_type == HIF_MT)
		mt_rx_pkt_process(ad, &RxBlk, rx_msg->net_pkt);

#endif /* MT_MAC */
}


VOID AndesCmdMsgBh(unsigned long param)
{
	RTMP_ADAPTER *ad = (RTMP_ADAPTER *)param;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;
	struct cmd_msg *msg = NULL;

	while ((msg = AndesDequeueCmdMsg(ctl, &ctl->rx_doneq))) {
		switch (msg->state) {
		case rx_done:
			AndesRxProcessCmdMsg(ad, msg);
			AndesFreeCmdMsg(msg);
			break;

		case rx_receive_fail:
			AndesFreeCmdMsg(msg);
			break;

		default:
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("unknow msg state(%d)\n", msg->state));
			AndesFreeCmdMsg(msg);
			break;
		}
	}

	while ((msg = AndesDequeueCmdMsg(ctl, &ctl->tx_doneq))) {
		switch (msg->state) {
		case tx_done:
		case tx_kickout_fail:
		case tx_timeout_fail:
			AndesFreeCmdMsg(msg);
			break;

		default:
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("unknow msg state(%d)\n", msg->state));
			AndesFreeCmdMsg(msg);
			break;
		}
	}

	if (OS_TEST_BIT(MCU_INIT, &ctl->flags)) {
		AndesBhSchedule(ad);
#ifdef RTMP_USB_SUPPORT
		UsbRxCmdMsgsReceive(ad);
#endif
	}
}


#ifdef RTMP_USB_SUPPORT
VOID AndesUsbUnlinkUrb(RTMP_ADAPTER *ad, DL_LIST *list)
{
	unsigned long flags;
	struct cmd_msg *msg, *msg_tmp;
	NDIS_SPIN_LOCK *lock;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	lock = AndesGetSpinLock(ctl, list);
	RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
	DlListForEachSafe(msg, msg_tmp, list, struct cmd_msg, list) {
		RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);

		if ((msg->state == wait_cmd_out_and_ack)        ||
			(msg->state == wait_cmd_out)            ||
			(msg->state == tx_start)                ||
			(msg->state == rx_start)                ||
			(msg->state == tx_retransmit))
			RTUSB_UNLINK_URB(msg->urb);

		RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
	}
	RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);
}
#endif


VOID AndesBhSchedule(RTMP_ADAPTER *ad)
{
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	if (!OS_TEST_BIT(MCU_INIT, &ctl->flags))
		return;

	if (((AndesQueueLen(ctl, &ctl->rx_doneq) > 0)
		 || (AndesQueueLen(ctl, &ctl->tx_doneq) > 0))
		&& OS_TEST_BIT(MCU_INIT, &ctl->flags)) {
#ifndef WORKQUEUE_BH
		RTMP_NET_TASK_DATA_ASSIGN(&ctl->cmd_msg_task, (unsigned long)(ad));
		RTMP_OS_TASKLET_SCHE(&ctl->cmd_msg_task);
#else
		tasklet_hi_schedule(&ctl->cmd_msg_task);
#endif
	}
}


VOID AndesCleanupCmdMsg(RTMP_ADAPTER *ad, DL_LIST *list)
{
	unsigned long flags;
	struct cmd_msg *msg, *msg_tmp;
	NDIS_SPIN_LOCK *lock;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	lock = AndesGetSpinLock(ctl, list);
	if (lock)
		RTMP_SPIN_LOCK_IRQSAVE(lock, &flags);
	DlListForEachSafe(msg, msg_tmp, list, struct cmd_msg, list) {
		_AndesUnlinkCmdMsg(msg, list);

		/*If need wait, clean up need to trigger complete for andes send cmd to free msg*/
		if (IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg))
			RTMP_OS_EXIT_COMPLETION(&msg->ack_done);
		else
			AndesFreeCmdMsg(msg);
	}
	DlListInit(list);
	if (lock)
		RTMP_SPIN_UNLOCK_IRQRESTORE(lock, &flags);
}


#if defined(RTMP_PCI_SUPPORT) || defined(RTMP_RBUS_SUPPORT)
static VOID AndesCtrlPciInit(RTMP_ADAPTER *ad)
{
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	RTMP_CLEAR_FLAG(ad, fRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD);
	ctl->cmd_seq = 0;
#ifndef WORKQUEUE_BH
	RTMP_OS_TASKLET_INIT(ad, &ctl->cmd_msg_task, AndesCmdMsgBh, (unsigned long)ad);
#else
	tasklet_init(&ctl->cmd_msg_task, AndesCmdMsgBh, (unsigned long)ad);
#endif
	NdisAllocateSpinLock(ad, &ctl->txq_lock);
	AndesQueueInit(ctl, &ctl->txq);
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("ctl->txq = %p\n", &ctl->txq));
	NdisAllocateSpinLock(ad, &ctl->rxq_lock);
	AndesQueueInit(ctl, &ctl->rxq);
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("ctl->rxq = %p\n", &ctl->rxq));
	NdisAllocateSpinLock(ad, &ctl->ackq_lock);
	AndesQueueInit(ctl, &ctl->ackq);
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("ctl->ackq = %p\n", &ctl->ackq));
	NdisAllocateSpinLock(ad, &ctl->kickq_lock);
	AndesQueueInit(ctl, &ctl->kickq);
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("ctl->kickq = %p\n", &ctl->kickq));
	NdisAllocateSpinLock(ad, &ctl->tx_doneq_lock);
	AndesQueueInit(ctl, &ctl->tx_doneq);
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("ctl->tx_doneq = %p\n", &ctl->tx_doneq));
	NdisAllocateSpinLock(ad, &ctl->rx_doneq_lock);
	AndesQueueInit(ctl, &ctl->rx_doneq);
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("ctl->rx_doneq = %p\n", &ctl->rx_doneq));
	ctl->tx_kickout_fail_count = 0;
	ctl->tx_timeout_fail_count = 0;
	ctl->rx_receive_fail_count = 0;
	ctl->alloc_cmd_msg = 0;
	ctl->free_cmd_msg = 0;
	OS_SET_BIT(MCU_INIT, &ctl->flags);
	ctl->ad = ad;
}
#endif


#ifdef RTMP_USB_SUPPORT
static VOID AndesCtrlUsbInit(RTMP_ADAPTER *ad)
{
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	RTMP_CLEAR_FLAG(ad, fRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD);
	ctl->cmd_seq = 0;
	RTMP_OS_TASKLET_INIT(ad, &ctl->cmd_msg_task, AndesCmdMsgBh, (unsigned long)ad);
	NdisAllocateSpinLock(ad, &ctl->txq_lock);
	AndesQueueInit(ctl, &ctl->txq);
	NdisAllocateSpinLock(ad, &ctl->rxq_lock);
	AndesQueueInit(ctl, &ctl->rxq);
	NdisAllocateSpinLock(ad, &ctl->ackq_lock);
	AndesQueueInit(ctl, &ctl->ackq);
	NdisAllocateSpinLock(ad, &ctl->kickq_lock);
	AndesQueueInit(ctl, &ctl->kickq);
	NdisAllocateSpinLock(ad, &ctl->tx_doneq_lock);
	AndesQueueInit(ctl, &ctl->tx_doneq);
	NdisAllocateSpinLock(ad, &ctl->rx_doneq_lock);
	AndesQueueInit(ctl, &ctl->rx_doneq);
	ctl->tx_kickout_fail_count = 0;
	ctl->tx_timeout_fail_count = 0;
	ctl->rx_receive_fail_count = 0;
	ctl->alloc_cmd_msg = 0;
	ctl->free_cmd_msg = 0;
	ctl->ad = ad;
	OS_SET_BIT(MCU_INIT, &ctl->flags);
	UsbRxCmdMsgsReceive(ad);
}
#endif


#ifdef RTMP_SDIO_SUPPORT
static VOID AndesCtrlSdioInit(RTMP_ADAPTER *pAd)
{
	struct MCU_CTRL *ctl = &pAd->MCUCtrl;

	RTMP_CLEAR_FLAG(pAd, fRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD);
	ctl->cmd_seq = 0;
	RTMP_OS_TASKLET_INIT(pAd, &ctl->cmd_msg_task, AndesCmdMsgBh, (unsigned long)pAd);
	NdisAllocateSpinLock(pAd, &ctl->txq_lock);
	AndesQueueInit(ctl, &ctl->txq);
	NdisAllocateSpinLock(pAd, &ctl->rxq_lock);
	AndesQueueInit(ctl, &ctl->rxq);
	NdisAllocateSpinLock(pAd, &ctl->ackq_lock);
	AndesQueueInit(ctl, &ctl->ackq);
	NdisAllocateSpinLock(pAd, &ctl->kickq_lock);
	AndesQueueInit(ctl, &ctl->kickq);
	NdisAllocateSpinLock(pAd, &ctl->tx_doneq_lock);
	AndesQueueInit(ctl, &ctl->tx_doneq);
	NdisAllocateSpinLock(pAd, &ctl->rx_doneq_lock);
	AndesQueueInit(ctl, &ctl->rx_doneq);
	NdisAllocateSpinLock(pAd, &ctl->txq_sdio_lock);
	AndesQueueInit(ctl, &ctl->txq_sdio);
	ctl->tx_kickout_fail_count = 0;
	ctl->tx_timeout_fail_count = 0;
	ctl->rx_receive_fail_count = 0;
	ctl->alloc_cmd_msg = 0;
	ctl->free_cmd_msg = 0;
	ctl->ad = pAd;
	OS_SET_BIT(MCU_INIT, &ctl->flags);
}
#endif


VOID AndesCtrlInit(RTMP_ADAPTER *pAd)
{
	struct MCU_CTRL *ctl = &pAd->MCUCtrl;

	if (!OS_TEST_BIT(MCU_INIT, &ctl->flags)) {
#ifdef RTMP_MAC_PCI

		if (IS_PCI_INF(pAd) || IS_RBUS_INF(pAd))
			AndesCtrlPciInit(pAd);

#endif
#ifdef RTMP_USB_SUPPORT

		if (IS_USB_INF(pAd))
			AndesCtrlUsbInit(pAd);

#endif
#ifdef RTMP_SDIO_SUPPORT

		if (IS_SDIO_INF(pAd))
			AndesCtrlSdioInit(pAd);

#endif
	}

	ctl->power_on = FALSE;
	ctl->dpd_on = FALSE;
	ctl->RxStream0 = 0;
	ctl->RxStream1 = 0;
	NdisAllocateSpinLock(pAd, &ctl->msg_lock);
}


#ifdef RTMP_USB_SUPPORT
static VOID AndesCtrlUsbExit(RTMP_ADAPTER *ad)
{
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	RTMP_CLEAR_FLAG(ad, fRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD);
	OS_CLEAR_BIT(MCU_INIT, &ctl->flags);
	AndesUsbUnlinkUrb(ad, &ctl->txq);
	AndesUsbUnlinkUrb(ad, &ctl->kickq);
	AndesUsbUnlinkUrb(ad, &ctl->ackq);
	AndesUsbUnlinkUrb(ad, &ctl->rxq);
	RTMP_OS_TASKLET_KILL(&ctl->cmd_msg_task);
	AndesCleanupCmdMsg(ad, &ctl->txq);
	NdisFreeSpinLock(&ctl->txq_lock);
	AndesCleanupCmdMsg(ad, &ctl->ackq);
	NdisFreeSpinLock(&ctl->ackq_lock);
	AndesCleanupCmdMsg(ad, &ctl->rxq);
	NdisFreeSpinLock(&ctl->rxq_lock);
	AndesCleanupCmdMsg(ad, &ctl->kickq);
	NdisFreeSpinLock(&ctl->kickq_lock);
	AndesCleanupCmdMsg(ad, &ctl->tx_doneq);
	NdisFreeSpinLock(&ctl->tx_doneq_lock);
	AndesCleanupCmdMsg(ad, &ctl->rx_doneq);
	NdisFreeSpinLock(&ctl->rx_doneq_lock);
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_kickout_fail_count = %ld\n", ctl->tx_kickout_fail_count));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_timeout_fail_count = %ld\n", ctl->tx_timeout_fail_count));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("rx_receive_fail_count = %ld\n", ctl->rx_receive_fail_count));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("alloc_cmd_msg = %ld\n", ctl->alloc_cmd_msg));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("free_cmd_msg = %ld\n", ctl->free_cmd_msg));
}
#endif


#ifdef RTMP_PCI_SUPPORT
static VOID AndesCtrlPciExit(RTMP_ADAPTER *ad)
{
	struct MCU_CTRL *ctl = &ad->MCUCtrl;

	RTMP_CLEAR_FLAG(ad, fRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD);
	/*clear andes queue by tasklet*/
	AndesBhSchedule(ad);
	OS_CLEAR_BIT(MCU_INIT, &ctl->flags);
	RTMP_OS_TASKLET_KILL(&ctl->cmd_msg_task);
	AndesCleanupCmdMsg(ad, &ctl->txq);
	NdisFreeSpinLock(&ctl->txq_lock);
	AndesCleanupCmdMsg(ad, &ctl->ackq);
	NdisFreeSpinLock(&ctl->ackq_lock);
	AndesCleanupCmdMsg(ad, &ctl->rxq);
	NdisFreeSpinLock(&ctl->rxq_lock);
	AndesCleanupCmdMsg(ad, &ctl->kickq);
	NdisFreeSpinLock(&ctl->kickq_lock);
	AndesCleanupCmdMsg(ad, &ctl->tx_doneq);
	NdisFreeSpinLock(&ctl->tx_doneq_lock);
	AndesCleanupCmdMsg(ad, &ctl->rx_doneq);
	NdisFreeSpinLock(&ctl->rx_doneq_lock);
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_kickout_fail_count = %ld\n", ctl->tx_kickout_fail_count));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_timeout_fail_count = %ld\n", ctl->tx_timeout_fail_count));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("rx_receive_fail_count = %ld\n", ctl->rx_receive_fail_count));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("alloc_cmd_msg = %ld\n", ctl->alloc_cmd_msg));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("free_cmd_msg = %ld\n", ctl->free_cmd_msg));
}
#endif


#ifdef RTMP_SDIO_SUPPORT
static VOID AndesCtrlSdioExit(RTMP_ADAPTER *pAd)
{
	struct MCU_CTRL *ctl = &pAd->MCUCtrl;

	RTMP_CLEAR_FLAG(pAd, fRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD);
	OS_CLEAR_BIT(MCU_INIT, &ctl->flags);
	RTMP_OS_TASKLET_KILL(&ctl->cmd_msg_task);
	AndesCleanupCmdMsg(pAd, &ctl->txq);
	NdisFreeSpinLock(&ctl->txq_lock);
	AndesCleanupCmdMsg(pAd, &ctl->ackq);
	NdisFreeSpinLock(&ctl->ackq_lock);
	AndesCleanupCmdMsg(pAd, &ctl->rxq);
	NdisFreeSpinLock(&ctl->rxq_lock);
	AndesCleanupCmdMsg(pAd, &ctl->kickq);
	NdisFreeSpinLock(&ctl->kickq_lock);
	AndesCleanupCmdMsg(pAd, &ctl->tx_doneq);
	NdisFreeSpinLock(&ctl->tx_doneq_lock);
	AndesCleanupCmdMsg(pAd, &ctl->rx_doneq);
	NdisFreeSpinLock(&ctl->rx_doneq_lock);
	AndesCleanupCmdMsg(pAd, &ctl->txq_sdio);
	NdisFreeSpinLock(&ctl->txq_sdio_lock);
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_kickout_fail_count = %ld\n", ctl->tx_kickout_fail_count));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("tx_timeout_fail_count = %ld\n", ctl->tx_timeout_fail_count));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("rx_receive_fail_count = %ld\n", ctl->rx_receive_fail_count));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("alloc_cmd_msg = %ld\n", ctl->alloc_cmd_msg));
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("free_cmd_msg = %ld\n", ctl->free_cmd_msg));
}
#endif

VOID AndesCtrlExit(RTMP_ADAPTER *pAd)
{
	struct MCU_CTRL *ctl = &pAd->MCUCtrl;

	if (OS_TEST_BIT(MCU_INIT, &ctl->flags)) {
#ifdef RTMP_PCI_SUPPORT

		if (IS_PCI_INF(pAd))
			AndesCtrlPciExit(pAd);

#endif
#ifdef RTMP_USB_SUPPORT
		AndesCtrlUsbExit(pAd);
#endif
#ifdef RTMP_SDIO_SUPPORT
		AndesCtrlSdioExit(pAd);
#endif
	}

	ctl->power_on = FALSE;
	ctl->dpd_on = FALSE;
}


static INT32 AndesDequeueAndKickOutCmdMsgs(RTMP_ADAPTER *ad)
{
	struct cmd_msg *msg = NULL;
	VOID *net_pkt = NULL;
	struct MCU_CTRL *ctl = &ad->MCUCtrl;
	int ret = NDIS_STATUS_SUCCESS;

	while ((msg = AndesDequeueCmdMsg(ctl, &ctl->txq)) != NULL) {
		if (!RTMP_TEST_FLAG(ad, fRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD)     ||
			RTMP_TEST_FLAG(ad, fRTMP_ADAPTER_NIC_NOT_EXIST)         ||
			RTMP_TEST_FLAG(ad, fRTMP_ADAPTER_SUSPEND)) {
			if (!IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg))
				AndesForceFreeCmdMsg(msg);

			continue;
		}

		net_pkt = (VOID *)msg->net_pkt;

		if (msg->state != tx_retransmit) {
			if (IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg))
				msg->seq = AndesGetCmdMsgSeq(ad);
			else
				msg->seq = 0;

			if (ad->chipOps.andes_fill_cmd_header != NULL)
				ad->chipOps.andes_fill_cmd_header(msg, net_pkt);
		}

#ifdef RTMP_USB_SUPPORT

		if (ad->chipOps.usb_kick_out_cmd_msg != NULL)
			ret = ad->chipOps.usb_kick_out_cmd_msg(ad, msg);

#endif
#if defined(RTMP_PCI_SUPPORT) || defined(RTMP_RBUS_SUPPORT)

		if (ad->chipOps.pci_kick_out_cmd_msg != NULL)
			ret = ad->chipOps.pci_kick_out_cmd_msg(ad, msg);

#endif
#ifdef RTMP_SDIO_SUPPORT

		if (ad->chipOps.sdio_kick_out_cmd_msg != NULL)
			ret = ad->chipOps.sdio_kick_out_cmd_msg(ad, msg);

#endif

		if (ret) {
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("kick out msg fail\n"));

			if (ret == NDIS_STATUS_FAILURE)
				AndesForceFreeCmdMsg(msg);

			break;
		}
	}

	AndesBhSchedule(ad);
	return ret;
}


#ifdef RTMP_SDIO_SUPPORT
INT32 AndesWaitForSdioCompleteTimeout(struct cmd_msg *msg, long timeout)
{
	int ret = 0;
	unsigned long expire = timeout ?
						   RTMPMsecsToJiffies(timeout) : RTMPMsecsToJiffies(CMD_MSG_TIMEOUT);
	ret = RTMP_OS_WAIT_FOR_COMPLETION_TIMEOUT(&msg->tx_sdio_done, expire);
	return ret;
}
#endif

static INT32 AndesWaitForCompleteTimeout(struct cmd_msg *msg, ULONG timeout)
{
	int ret = 0;
	ULONG expire = timeout ?
				   RTMPMsecsToJiffies(timeout) : RTMPMsecsToJiffies(CMD_MSG_TIMEOUT);
	ret = RTMP_OS_WAIT_FOR_COMPLETION_TIMEOUT(&msg->ack_done, expire);
	return ret;
}


INT32 AndesSendCmdMsg(PRTMP_ADAPTER ad, struct cmd_msg *msg)
{
	struct MCU_CTRL *ctl = &ad->MCUCtrl;
	BOOLEAN is_cmd_need_wait = IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg);
	int ret = NDIS_STATUS_SUCCESS;

	if (in_interrupt() && IS_CMD_MSG_NEED_SYNC_WITH_FW_FLAG_SET(msg)) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("BUG: %s is called from invalid context\n",
				  __func__));
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s: Command type = %x, Extension command type = %x\n",
				  __func__, msg->attr.type, msg->attr.ext_type));
		AndesForceFreeCmdMsg(msg);
		return NDIS_STATUS_FAILURE;
	}

	if (!RTMP_TEST_FLAG(ad, fRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD)     ||
		RTMP_TEST_FLAG(ad, fRTMP_ADAPTER_NIC_NOT_EXIST)         ||
		RTMP_TEST_FLAG(ad, fRTMP_ADAPTER_SUSPEND)) {
		if (!RTMP_TEST_FLAG(ad, fRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD)) {
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s: Could not send in band command due to diablefRTMP_ADAPTER_MCU_SEND_IN_BAND_CMD\n",
					  __func__));
		} else if (RTMP_TEST_FLAG(ad, fRTMP_ADAPTER_NIC_NOT_EXIST)) {
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s: Could not send in band command due to fRTMP_ADAPTER_NIC_NOT_EXIST\n",
					  __func__));
		} else if (RTMP_TEST_FLAG(ad, fRTMP_ADAPTER_SUSPEND)) {
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s: Could not send in band command due to fRTMP_ADAPTER_SUSPEND\n",
					  __func__));
		}

		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s: Command type = %x, Extension command type = %x\n",
				  __func__, msg->attr.type, msg->attr.ext_type));

		AndesForceFreeCmdMsg(msg);
		return NDIS_STATUS_FAILURE;
	}

	AndesQueueTailCmdMsg(&ctl->txq, msg, tx_start);
retransmit:

	if (AndesDequeueAndKickOutCmdMsgs(ad) != NDIS_STATUS_SUCCESS)
		goto bailout;

	/* Wait for response */
	if (is_cmd_need_wait) {
		enum cmd_msg_state state = 0;
		BOOLEAN IsComplete;

		IsComplete = AndesWaitForCompleteTimeout(msg, msg->attr.ctrl.wait_ms_time);

		if (!OS_TEST_BIT(MCU_INIT, &ctl->flags)) {
			/*If need wait, clean up will trigger complete for here to free msg*/
			AndesFreeCmdMsg(msg);
			goto bailout;
		}

		if (!IsComplete) {
			ret = NDIS_STATUS_FAILURE;
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("FWCmdTimeout: command (%x), ext_cmd_type (%x), seq(%d), timeout(%dms)\n",
					  msg->attr.type, msg->attr.ext_type,
					  msg->seq,
					  (msg->attr.ctrl.wait_ms_time == 0) ?
					  CMD_MSG_TIMEOUT : msg->attr.ctrl.wait_ms_time));
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("pAd->Flags  = 0x%.8lx\n", ad->Flags));
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("txq qlen = %d\n", AndesQueueLen(ctl, &ctl->txq)));
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("rxq qlen = %d\n", AndesQueueLen(ctl, &ctl->rxq)));
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("kickq qlen = %d\n", AndesQueueLen(ctl, &ctl->kickq)));
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("ackq qlen = %d\n", AndesQueueLen(ctl, &ctl->ackq)));
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("tx_doneq.qlen = %d\n", AndesQueueLen(ctl, &ctl->tx_doneq)));
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("rx_done qlen = %d\n", AndesQueueLen(ctl, &ctl->rx_doneq)));
#ifdef RTMP_SDIO_SUPPORT
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("txq_sdio qlen = %d\n", AndesQueueLen(ctl, &ctl->txq_sdio)));
#endif

			if (msg->state == wait_cmd_out_and_ack) {
#ifdef RTMP_USB_SUPPORT
				RTUSB_UNLINK_URB(msg->urb);
#else
#ifdef RTMP_SDIO_SUPPORT

				/*
				   A. For SDIO case , msg may be in
					(1) tx_sdioq due to no TC resource (disabled, hard to prevent)
					(2) in ackq due to f/w has no response
				   B. We need to trieve either from the two sources and queue into
					  tx_donq evetually for tasklet to free
				*/
				/* if (AndesQueueLen(ctl, &ctl->txq_sdio) > 0) { */
				/* AndesUnlinkCmdMsg(msg, &ctl->txq_sdio); */
				/* } else */
				if (AndesQueueLen(ctl, &ctl->ackq) > 0)
					AndesUnlinkCmdMsg(msg, &ctl->ackq);

#else
				AndesUnlinkCmdMsg(msg, &ctl->ackq);
#endif
#endif
			} else if (msg->state == wait_ack)
				AndesUnlinkCmdMsg(msg, &ctl->ackq);

			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s: msg state = %d\n", __func__, msg->state));
			AndesIncErrorCount(ctl, error_tx_timeout_fail);
			state = tx_timeout_fail;

			if (msg->retry_times > 0)
				msg->retry_times--;

#ifdef MT_PS
			else {
				/* timeout process */
				if ((msg->attr.type == EXT_CID) &&
					(msg->attr.ext_type == EXT_CMD_PS_RETRIEVE_START))
					MtPsSendToken(ad, msg->wcid);

				if ((msg->attr.type == EXT_CID) &&
					(msg->attr.ext_type == EXT_CMD_PWR_SAVING))
					CmdPsClearReq(ad, msg->wcid, TRUE);
			}

#endif /* MT_PS */
			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("msg->retry_times = %d\n", msg->retry_times));
			ASSERT(FALSE);
		} else {
			if (msg->state == tx_kickout_fail) {
				state = tx_kickout_fail;
				msg->retry_times--;
			} else {
				if (msg->state == wait_cmd_out_and_ack) {
#ifndef RTMP_USB_SUPPORT
					AndesUnlinkCmdMsg(msg, &ctl->ackq);
#else    /* RTMP_USB_SUPPORT */
					RTUSB_UNLINK_URB(msg->urb);
#endif  /* !RTMP_USB_SUPPORT */
				} else if (msg->state == wait_ack)
					AndesUnlinkCmdMsg(msg, &ctl->ackq);

				state = tx_done;
				msg->retry_times = 0;
			}
		}

		if (is_cmd_need_wait && (msg->retry_times > 0)) {
			RTMP_OS_EXIT_COMPLETION(&msg->ack_done);
			RTMP_OS_INIT_COMPLETION(&msg->ack_done);
			state = tx_retransmit;
			AndesQueueHeadCmdMsg(&ctl->txq, msg, state);
			goto retransmit;
		} else {
			if (msg->attr.ext_type == EXT_CMD_STAREC_UPDATE) {
				/* Only StaRec update command read FW's response to minimize the impact.
				 FW's response will become the final return value.
				*/
				ret = msg->cmd_return_status;
			}

			MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_INFO,
					 ("%s: msg state = %d\n", __func__, state));
			/* msg will be free after enqueuing to tx_doneq. So msg is not able to pass FW's response to caller. */
			AndesQueueTailCmdMsg(&ctl->tx_doneq, msg, state);
		}
	}

bailout:
	return ret;
}

INT32 MtCmdSendMsg(PRTMP_ADAPTER ad, struct cmd_msg *msg)
{
	INT32 ret = 0;

	ret = AndesSendCmdMsg(ad, msg);
	return ret;
}

