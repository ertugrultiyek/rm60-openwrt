/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology	5th	Rd.
 * Science-based Industrial	Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2009, Ralink Technology, Inc.
 *
 * All rights reserved.	Ralink's source	code is	an unpublished work	and	the
 * use of a	copyright notice does not imply	otherwise. This	source code
 * contains	confidential trade secret material of Ralink Tech. Any attemp
 * or participation	in deciphering,	decoding, reverse engineering or in	any
 * way altering	the	source code	is stricitly prohibited, unless	the	prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	rtusb_io.h

	Abstract:

	Revision History:
	Who			When	    What
	--------	----------  ----------------------------------------------
	Name		Date	    Modification logs
*/

#ifndef __RTUSB_IO_H__
#define __RTUSB_IO_H__

#include "security/wpa_cmm.h"
#include "rtmp_type.h"


void usb_cfg_read_v1(struct _RTMP_ADAPTER *ad, UINT32 *value);
void usb_cfg_write_v1(struct _RTMP_ADAPTER *ad, UINT32 value);
void usb_cfg_read_v2(struct _RTMP_ADAPTER *ad, UINT32 *value);
void usb_cfg_write_v2(struct _RTMP_ADAPTER *ad, UINT32 value);
void usb_cfg_read_v3(struct _RTMP_ADAPTER *ad, UINT32 *value);
void usb_cfg_write_v3(struct _RTMP_ADAPTER *ad, UINT32 value);
void mtusb_cfg_read(struct _RTMP_ADAPTER *ad, UINT32 *value);
void mtusb_cfg_write(struct _RTMP_ADAPTER *ad, UINT32 value);
int write_reg(struct _RTMP_ADAPTER *ad, UINT32 base, UINT16 offset, UINT32 val);
int read_reg(struct _RTMP_ADAPTER *ad, UINT32 base, UINT16 offset, UINT32 *value);

#endif /* __RTUSB_IO_H__ */
