/***************************************************************************
 * MediaTek Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 1997-2012, MediaTek, Inc.
 *
 * All rights reserved. MediaTek source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek Technology, Inc. is obtained.
 ***************************************************************************

*/

#ifndef __QM_H__
#define __QM_H__

#define MCAST_WCID_TO_REMOVE 0

enum queue_mm {
	GENERIC_QM,
	FAST_PATH_QM,
};

/**
 * @init: qm resource initialization
 * @exit: qm resource exit
 * @enq_mgmt_pkt: en-queue packet to management queue operation
 * @enq_data_pkt: en-queue packet to data queue operation
 * @schedule_tx_que: schedule job that may use thread, worker, or tasklet to dequeue tx queue and service packet
 * @sta_clean_queue: cleanup resource inside queue per station
 * @sta_dump_queue: dump resource inside queue per station per queue index
 */

struct qm_ops {
	/* INIT/EXIT */
	INT (*init)(struct _RTMP_ADAPTER *pAd);
	INT (*exit)(struct _RTMP_ADAPTER *pAd);
	INT (*sta_clean_queue)(struct _RTMP_ADAPTER *pAd, UCHAR wcid);
	VOID (*sta_dump_queue)(struct _RTMP_ADAPTER *pAd, UCHAR wcid, UCHAR q_idx);
	INT (*bss_clean_queue)(struct _RTMP_ADAPTER *ad, struct wifi_dev *wdev);

	/* TX */
	INT (*enq_mgmtq_pkt)(struct _RTMP_ADAPTER *pAd, struct wifi_dev *wdev, PNDIS_PACKET pkt) ____cacheline_aligned;
	INT (*enq_dataq_pkt)(struct _RTMP_ADAPTER *pAd, struct wifi_dev *wdev, PNDIS_PACKET pkt, UCHAR q_idx);
	INT (*schedule_tx_que)(struct _RTMP_ADAPTER *pAd);
} ____cacheline_aligned;

#define MGMT_QUE_MAX_NUMS 1024
#define DATA_QUE_MAX_NUMS 7168

enum pkt_tx_status {
	PKT_SUCCESS = 0,
	INVALID_PKT_LEN = 1,
	INVALID_TR_WCID = 2,
	INVALID_TR_ENTRY = 3,
	INVALID_WDEV = 4,
	INVALID_ETH_TYPE = 5,
	DROP_PORT_SECURE = 6,
	DROP_PSQ_FULL = 7,
	DROP_TXQ_FULL = 8,
	DROP_TX_JAM = 9,
	DROP_TXQ_ENQ_FAIL = 10,
};

struct reason_id_str {
	INT id;
	RTMP_STRING *code_str;
};

#define InitializeQueueHeader(QueueHeader)              \
	{                                                       \
		(QueueHeader)->Head = (QueueHeader)->Tail = NULL;   \
		(QueueHeader)->Number = 0;                          \
	}

#define RemoveHeadQueue(QueueHeader)                \
	(QueueHeader)->Head;                                \
	{                                                   \
		PQUEUE_ENTRY pNext;                             \
		if ((QueueHeader)->Head != NULL) {				\
			pNext = (QueueHeader)->Head->Next;          \
			(QueueHeader)->Head->Next = NULL;		\
			(QueueHeader)->Head = pNext;                \
			if (pNext == NULL)                          \
				(QueueHeader)->Tail = NULL;             \
			(QueueHeader)->Number--;                    \
		}												\
	}

#define RemoveTailQueue(QueueHeader)       \
	(QueueHeader)->Tail;                       \
	{                                          \
		PQUEUE_ENTRY pNext;                     \
		if ((QueueHeader)->Head != NULL) {			 \
			pNext = (QueueHeader)->Head;         \
			if (pNext->Next == NULL) {           \
				(QueueHeader)->Head = NULL;       \
				(QueueHeader)->Tail = NULL;       \
			} else {                             \
				while (pNext->Next != (QueueHeader)->Tail) { \
					pNext = pNext->Next;           \
				}                                 \
				(QueueHeader)->Tail = pNext;      \
				pNext->Next = NULL;               \
			}                                    \
			(QueueHeader)->Number--;              \
		}                                        \
	}


#define InsertHeadQueue(QueueHeader, QueueEntry)            \
	{                                                           \
		((PQUEUE_ENTRY)QueueEntry)->Next = (QueueHeader)->Head; \
		(QueueHeader)->Head = (PQUEUE_ENTRY)(QueueEntry);       \
		if ((QueueHeader)->Tail == NULL)                        \
			(QueueHeader)->Tail = (PQUEUE_ENTRY)(QueueEntry);   \
		(QueueHeader)->Number++;                                \
	}

#define InsertTailQueue(QueueHeader, QueueEntry)				\
	{                                                               \
		((PQUEUE_ENTRY)QueueEntry)->Next = NULL;                    \
		if ((QueueHeader)->Tail)                                    \
			(QueueHeader)->Tail->Next = (PQUEUE_ENTRY)(QueueEntry); \
		else                                                        \
			(QueueHeader)->Head = (PQUEUE_ENTRY)(QueueEntry);       \
		(QueueHeader)->Tail = (PQUEUE_ENTRY)(QueueEntry);           \
		(QueueHeader)->Number++;                                    \
	}

#define InsertTailQueueAc(pAd, pEntry, QueueHeader, QueueEntry)			\
	{																		\
		((PQUEUE_ENTRY)QueueEntry)->Next = NULL;							\
		if ((QueueHeader)->Tail)											\
			(QueueHeader)->Tail->Next = (PQUEUE_ENTRY)(QueueEntry);			\
		else																\
			(QueueHeader)->Head = (PQUEUE_ENTRY)(QueueEntry);				\
		(QueueHeader)->Tail = (PQUEUE_ENTRY)(QueueEntry);					\
		(QueueHeader)->Number++;											\
	}

#ifdef WMM_ACM_SUPPORT

#undef InsertTailQueueAc

#ifdef RELEASE_EXCLUDE
/*
	From Hamilton, Mark [Mark.Hamilton@Polycom.com], he says that
	The point of admission control is that the AP is "guaranteeing" that the
	stream will be given the time it requested, if it tries to use it - at
	least in the sense of that stream being protected from unadmitted and
	other admitted streams.  (That is, other forces, like medium contention
	problems, retry rates, interference, overlapping BSS, etc. can all cause
	a stream to not get its allocated bandwidth.  But, to fail to get its
	allocation simply because the AP over-allocated is not correct behavior.)
*/
#endif /* RELEASE_EXCLUDE */

/* we need to check if the packet can be put to the queue based on ACM */
#error "shiang-usw, Fix me because pEntry is not revise yet!!"
#define InsertTailQueueAc(pAd, pEntry, QueueHeader, QueueEntry)				\
	{																			\
		PQUEUE_HEADER __QueueHeaderNew;											\
		ACM_FUNC_STATUS __Status = ACM_RTN_NO_ACM;								\
		UINT32 __QueueType;														\
		BOOLEAN __FlgIsPktFreed = FALSE;										\
		\
		ACMR_PKT_MARK_MIN_PHY_MODE(QUEUE_ENTRY_TO_PACKET(QueueEntry), ACMR_PHY_NONE);\
		RTMP_SET_PACKET_TX_TIME(QUEUE_ENTRY_TO_PACKET(QueueEntry), 0);			\
		if (ACMP_IsNeedToDoAcm(pAd, pEntry, RTMP_GET_PACKET_UP(QUEUE_ENTRY_TO_PACKET(QueueEntry))) == TRUE) {	\
			ACMR_PKT_QOS_TYPE_SET(QUEUE_ENTRY_TO_PACKET(QueueEntry), 0);	\
			__Status = ACMP_DataPacketQueue(pAd, pEntry, QUEUE_ENTRY_TO_PACKET(QueueEntry), 0, &__QueueType);	\
			\
			if ((__Status == ACM_RTN_FAIL) ||								\
				((__Status == ACM_RTN_OK) &&								\
				 (pAd->TxSwQueue[__QueueType].Number >= pAd->TxSwQMaxLen))) {				\
				__FlgIsPktFreed = TRUE;									\
				\
				if ((__Status == ACM_RTN_OK) &&								\
					(__QueueType == ACMR_QID_AC_BE)	&&						\
					(ACMP_BE_QueueFullHandle(pAd, pEntry, QUEUE_ENTRY_TO_PACKET(QueueEntry)) == ACM_RTN_OK))	\
						__FlgIsPktFreed = FALSE;								\
				if (__FlgIsPktFreed == TRUE)									\
					RELEASE_NDIS_PACKET(pAd, QUEUE_ENTRY_TO_PACKET(QueueEntry), NDIS_STATUS_FAILURE);	\
			}													\
		}														\
		if (__FlgIsPktFreed == FALSE) {											\
			if (__Status == ACM_RTN_NO_ACM)										\
				__QueueHeaderNew = QueueHeader;									\
			else													\
				__QueueHeaderNew = &pAd->TxSwQueue[__QueueType];						\
			((PQUEUE_ENTRY)QueueEntry)->Next = NULL;								\
			if ((__QueueHeaderNew)->Tail)										\
				(__QueueHeaderNew)->Tail->Next = (PQUEUE_ENTRY)(QueueEntry);					\
			else													\
				(__QueueHeaderNew)->Head = (PQUEUE_ENTRY)(QueueEntry);						\
			(__QueueHeaderNew)->Tail = (PQUEUE_ENTRY)(QueueEntry);							\
			(__QueueHeaderNew)->Number++;										\
		}														\
	}
#endif /* WMM_ACM_SUPPORT */

#define DEQUEUE_LOCK(lock, bIntContext, IrqFlags)				\
	do {													\
		if (bIntContext == FALSE)						\
			RTMP_IRQ_LOCK((lock), IrqFlags);		\
	} while (0)

#define DEQUEUE_UNLOCK(lock, bIntContext, IrqFlags)				\
	do {													\
		if (bIntContext == FALSE)						\
			RTMP_IRQ_UNLOCK((lock), IrqFlags);	\
	} while (0)


VOID ge_tx_pkt_deq_func(struct _RTMP_ADAPTER *pAd);
VOID RTMPDeQueuePacket(struct _RTMP_ADAPTER *pAd, BOOLEAN bIntContext, UCHAR QueIdx, INT wcid, INT Max_Tx_Packets);
INT ge_enq_req(struct _RTMP_ADAPTER *pAd, PNDIS_PACKET pkt, UCHAR qidx, STA_TR_ENTRY *tr_entry, QUEUE_HEADER *pPktQueue);
VOID ge_tx_swq_dump(struct _RTMP_ADAPTER *pAd, INT qidx);
INT qm_init(struct _RTMP_ADAPTER *pAd);
INT qm_exit(struct _RTMP_ADAPTER *pAd);
VOID qm_leave_queue_pkt(struct wifi_dev *wdev, struct _QUEUE_HEADER *queue, NDIS_SPIN_LOCK *lock);

#endif
