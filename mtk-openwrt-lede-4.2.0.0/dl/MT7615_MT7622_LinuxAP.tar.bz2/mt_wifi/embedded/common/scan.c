/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2004, Ralink Technology, Inc.
 *
 * All rights reserved. Ralink's source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of Ralink Tech. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:

	Abstract:

	Revision History:
	Who		When			What
	--------	----------		----------------------------------------------
*/

#include "rt_config.h"

#ifdef SCAN_SUPPORT


INT scan_ch_restore(RTMP_ADAPTER *pAd, UCHAR OpMode, struct wifi_dev *pwdev)
{
#ifdef CONFIG_STA_SUPPORT
	USHORT Status;
#endif /* CONFIG_STA_SUPPORT */
	INT bw, ch;
	struct wifi_dev *wdev = pwdev;
#ifdef APCLI_SUPPORT
#ifdef APCLI_CERT_SUPPORT
	UCHAR  ScanType = pAd->ScanCtrl.ScanType;
#endif /*APCLI_CERT_SUPPORT*/
#endif /*APCLI_SUPPORT*/
#ifdef CONFIG_MULTI_CHANNEL
#if defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT)
	BSS_STRUCT *pMbss = &pAd->ApCfg.MBSSID[CFG_GO_BSSID_IDX];
	PAPCLI_STRUCT pApCliEntry = pApCliEntry = &pAd->ApCfg.ApCliTab[MAIN_MBSSID];
	struct wifi_dev *p2p_wdev = &pMbss->wdev;

	if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd))
		p2p_wdev = &pMbss->wdev;
	else if (RTMP_CFG80211_VIF_P2P_CLI_ON(pAd))
		p2p_wdev = &pApCliEntry->wdev;

#endif /* defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT) */
#endif /* CONFIG_MULTI_CHANNEL */
#ifdef CONFIG_AP_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
		if (!wdev)
			wdev = &pAd->ApCfg.MBSSID[MAIN_MBSSID].wdev;
	}
#endif /*CONFIG_STA_SUPPORT*/
	ch = wlan_operate_get_cen_ch_1(wdev);
	bw = wlan_operate_get_bw(wdev);

#ifdef WH_EZ_SETUP
	if (IS_EZ_SETUP_ENABLED(wdev) && pAd->ApCfg.ScanReqwdev->ez_security.scan_one_channel) {
		EZ_DEBUG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
			("AP SYNC %s() - Only scan ch.%d and keep original BW setting.\n", 
			__FUNCTION__, pAd->ScanCtrl.Channel));
#ifndef EZ_NETWORK_MERGE_SUPPORT	
		pAd->ApCfg.ScanReqwdev->ez_security.scan_one_channel = FALSE;
#endif
	}
#endif /* WH_EZ_SETUP */
#ifdef CONFIG_STA_SUPPORT

	if (OpMode == OPMODE_STA) {
		/*check if wdev is mix mode and channel will go to other band, switch wdev to difference band*/
		HcCrossChannelCheck(pAd,  &pAd->StaCfg[0].wdev, ch);
	}

#endif /*CONFIG_STA_SUPPORT*/
#ifdef CONFIG_MULTI_CHANNEL
#if defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT)

	if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd) && (ch != p2p_wdev->channel) && (p2p_wdev->CentralChannel != 0))
		bw = wlan_operate_get_ht_bw(p2p_wdev);
	else if (RTMP_CFG80211_VIF_P2P_CLI_ON(pAd) && (ch != p2p_wdev->channel) && (p2p_wdev->CentralChannel != 0))
		bw = wlan_operate_get_ht_bw(p2p_wdev);

#endif /* defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT) */
#endif /* CONFIG_MULTI_CHANNEL */
#ifdef CONFIG_MULTI_CHANNEL
#if defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT)
	MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("scan ch restore   ch %d  p2p_wdev->CentralChannel%d\n", ch, p2p_wdev->CentralChannel));

	/*If GO start, we need to change to GO Channel*/
	if ((ch != p2p_wdev->CentralChannel) && (p2p_wdev->CentralChannel != 0))
		ch = p2p_wdev->CentralChannel;

#endif /* defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT) */
#endif /* CONFIG_MULTI_CHANNEL */
	ch = wlan_operate_get_prim_ch(wdev);
	ASSERT((ch != 0));
	/*restore to original channel*/
	wlan_operate_set_prim_ch(wdev, ch);
	ch = wlan_operate_get_cen_ch_1(wdev);
	bw = wlan_operate_get_bw(wdev);
	MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s,central ch=%d,bw=%d\n\r", __func__, ch, bw));
	MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SYNC - End of SCAN, restore to %dMHz channel %d, Total BSS[%02d]\n",
			 bw, ch, pAd->ScanTab.BssNr));
#ifdef CONFIG_STA_SUPPORT

	if (OpMode == OPMODE_STA) {
		PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
		ASSERT(pStaCfg);

		if (!pStaCfg)
			return FALSE;

		/*
		If all peer Ad-hoc clients leave, driver would do LinkDown and LinkUp.
		In LinkUp, pStaCfg->Ssid would copy SSID from MlmeAux.
		To prevent SSID is zero or wrong in Beacon, need to recover MlmeAux.SSID here.
		*/
		if (ADHOC_ON(pAd)) {
			NdisZeroMemory(pStaCfg->MlmeAux.Ssid, MAX_LEN_OF_SSID);
			pStaCfg->MlmeAux.SsidLen = pStaCfg->SsidLen;
			NdisMoveMemory(pStaCfg->MlmeAux.Ssid, pStaCfg->Ssid, pStaCfg->SsidLen);
		}

		/*
		To prevent data lost.
		Send an NULL data with turned PSM bit on to current associated AP before SCAN progress.
		Now, we need to send an NULL data with turned PSM bit off to AP, when scan progress done
		*/
		if (STA_STATUS_TEST_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED) && (INFRA_ON(pStaCfg))) {
			RTMPSendNullFrame(pAd,
							  pStaCfg,
							  pAd->CommonCfg.TxRate,
							  (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_WMM_INUSED) ? TRUE : FALSE),
							  pAd->CommonCfg.bAPSDForcePowerSave ? PWR_SAVE : pStaCfg->PwrMgmt.Psm);
			MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s -- Send null frame\n", __func__));
		}

#ifdef RT_CFG80211_P2P_CONCURRENT_DEVICE

		if (pAd->ApCfg.ApCliTab[MAIN_MBSSID].Valid && RTMP_CFG80211_VIF_P2P_CLI_ON(pAd)) {
			MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("CFG80211_NULL: PWR_ACTIVE SCAN_END\n"));
			RT_CFG80211_P2P_CLI_SEND_NULL_FRAME(pAd, PWR_ACTIVE);
		}

#endif /* RT_CFG80211_P2P_CONCURRENT_DEVICE */
		/* keep the latest scan channel, could be 0 for scan complete, or other channel*/
		pStaCfg->LastScanChannel = pAd->ScanCtrl.Channel;
		pStaCfg->ScanChannelCnt = 0;

		/* Suspend scanning and Resume TxData for Fast Scanning*/
		if ((pAd->ScanCtrl.Channel != 0) &&
			(pStaCfg->bImprovedScan)) {	/* it is scan pending*/
			pStaCfg->SyncMachine.CurrState = SCAN_PENDING;
			Status = MLME_SUCCESS;
			MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("bFastRoamingScan ~~~ Get back to send data ~~~\n"));
#ifdef CONFIG_MULTI_CHANNEL
			{
				MLME_SCAN_REQ_STRUCT       ScanReq;
				pStaCfg->LastScanTime = pAd->Mlme.Now32;
				ScanParmFill(pAd, &ScanReq, pAd->MlmeAux.Ssid, pAd->MlmeAux.SsidLen, BSS_ANY, SCAN_ACTIVE);
				MlmeEnqueueWithWdev(pAd, SYNC_STATE_MACHINE, MT2_MLME_SCAN_REQ, sizeof(MLME_SCAN_REQ_STRUCT), &ScanReq, 0, &pStaCfg->wdev);
				MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("bImprovedScan ............. Resume for bImprovedScan, SCAN_PENDING ..............\n"));
				RTMP_MLME_HANDLER(pAd);
			}
#endif /* CONFIG_MULTI_CHANNEL */
		} else {
			pStaCfg->BssNr = pAd->ScanTab.BssNr;
			pStaCfg->bImprovedScan = FALSE;
			pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
			Status = MLME_SUCCESS;
			MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_SCAN_CONF, 2, &Status, 0, &pStaCfg->wdev);
			RTMP_MLME_HANDLER(pAd);
		}
	}

#endif /* CONFIG_STA_SUPPORT */
#ifdef CONFIG_AP_SUPPORT

	if (OpMode == OPMODE_AP) {
		INT BssIdx;
		INT MaxNumBss = pAd->ApCfg.BssidNum;
#ifdef P2P_APCLI_SUPPORT

		/* P2P CLIENT in WSC Scan or Re-Connect scanning. */
		if (P2P_CLI_ON(pAd) && (ApScanRunning(pAd) == TRUE)) {
			/*MlmeEnqueue(pAd, APCLI_CTRL_STATE_MACHINE, APCLI_CTRL_JOIN_REQ_TIMEOUT, 0, NULL, 0);*/
			MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s::  Scan Done! reset APCLI CTRL State Machine!\n", __func__));
			pAd->ApCfg.ApCliTab[0].CtrlCurrState = APCLI_CTRL_DISCONNECTED;
		}

#endif /* P2P_APCLI_SUPPORT */
#ifdef APCLI_SUPPORT
		if (wdev && wdev->wdev_type == WDEV_TYPE_APCLI) {
#ifdef APCLI_AUTO_CONNECT_SUPPORT
			if (pAd->ApCfg.ApCliAutoConnectRunning[wdev->func_idx] == TRUE &&
				pAd->ScanCtrl.PartialScan.bScanning == FALSE) {
				if (!ApCliAutoConnectExec(pAd, wdev))
					MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
						("Error in  %s\n", __func__));
			}
#endif /* APCLI_AUTO_CONNECT_SUPPORT */
			pAd->ApCfg.bPartialScanning[wdev->func_idx] = FALSE;
		}
#endif /* APCLI_SUPPORT */
		pAd->Mlme.ApSyncMachine.CurrState = AP_SYNC_IDLE;


		/* iwpriv set auto channel selection*/
		/* scanned all channels*/
		if (pAd->ApCfg.bAutoChannelAtBootup == TRUE) {
			UCHAR RfIC = wmode_2_rfic(wdev->PhyMode);
			wdev->channel = SelectBestChannel(pAd, pAd->ApCfg.AutoChannelAlg);
			pAd->ApCfg.bAutoChannelAtBootup = FALSE;
			APStopByRf(pAd, RfIC);
			APStartUpByRf(pAd, RfIC);
		}

		if (((wdev->channel > 14) &&
			 (pAd->CommonCfg.bIEEE80211H == TRUE) &&
			 RadarChannelCheck(pAd, wdev->channel)) &&
			pAd->Dot11_H.RDMode != RD_SWITCHING_MODE) {
			if (pAd->Dot11_H.InServiceMonitorCount) {
				pAd->Dot11_H.RDMode = RD_NORMAL_MODE;
				AsicSetSyncModeAndEnable(pAd, pAd->CommonCfg.BeaconPeriod, HW_BSSID_0, OPMODE_AP);

				/* Enable beacon tx for all BSS */
				for (BssIdx = 0; BssIdx < MaxNumBss; BssIdx++) {
					wdev = &pAd->ApCfg.MBSSID[BssIdx].wdev;

					if (wdev->bAllowBeaconing)
						UpdateBeaconHandler(pAd, wdev, BCN_UPDATE_ENABLE_TX);
				}
			} else
				pAd->Dot11_H.RDMode = RD_SILENCE_MODE;
		} else {
			AsicSetSyncModeAndEnable(pAd, pAd->CommonCfg.BeaconPeriod, HW_BSSID_0, OPMODE_AP);

			/* Enable beacon tx for all BSS */
			for (BssIdx = 0; BssIdx < MaxNumBss; BssIdx++) {
				wdev = &pAd->ApCfg.MBSSID[BssIdx].wdev;

				if (wdev->bAllowBeaconing)
					UpdateBeaconHandler(pAd, wdev, BCN_UPDATE_ENABLE_TX);
			}
		}

#ifdef APCLI_SUPPORT
#ifdef WSC_AP_SUPPORT
		if (wdev &&
			(wdev->wdev_type == WDEV_TYPE_APCLI) &&
			(wdev->func_idx < MAX_APCLI_NUM)) {
			WSC_CTRL *pWpsCtrlTemp = &pAd->ApCfg.ApCliTab[wdev->func_idx].WscControl;

			if ((pWpsCtrlTemp->WscConfMode != WSC_DISABLE) &&
				(pWpsCtrlTemp->bWscTrigger == TRUE) &&
				(pWpsCtrlTemp->WscMode == WSC_PBC_MODE)) {
				if (pWpsCtrlTemp->WscApCliScanMode == TRIGGER_PARTIAL_SCAN) {
					if ((pAd->ScanCtrl.PartialScan.bScanning == FALSE) &&
						(pAd->ScanCtrl.PartialScan.LastScanChannel == 0)) {
						MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							("[%s] %s AP-Client WPS Partial Scan done!!!\n",
							__func__, (ch > 14 ? "5G" : "2G")));

#ifdef CON_WPS
						if (pWpsCtrlTemp->conWscStatus != CON_WPS_STATUS_DISABLED) {
							MlmeEnqueue(pAd, AP_SYNC_STATE_MACHINE,
								 APMT2_MLME_SCAN_COMPLETE, 0, NULL, wdev->func_idx);
							RTMP_MLME_HANDLER(pAd);
						} else
#endif /* CON_WPS */
						{
							if (!pWpsCtrlTemp->WscPBCTimerRunning) {
								RTMPSetTimer(&pWpsCtrlTemp->WscPBCTimer, 1000);
								pWpsCtrlTemp->WscPBCTimerRunning = TRUE;
							}
						}
					}
				}
#ifdef CON_WPS
				else {
					if (pWpsCtrlTemp->conWscStatus != CON_WPS_STATUS_DISABLED) {
						MlmeEnqueue(pAd, AP_SYNC_STATE_MACHINE, APMT2_MLME_SCAN_COMPLETE, 0,
								NULL, wdev->func_idx);
						RTMP_MLME_HANDLER(pAd);
					}
				}
#endif /* CON_WPS*/
			}
		}
#endif /* WSC_AP_SUPPORT */
#endif /* APCLI_SUPPORT */
	}

#ifdef APCLI_SUPPORT
#ifdef APCLI_CERT_SUPPORT
#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
	{
		UCHAR apcli2Gidx = 0;
#ifdef DBDC_MODE
		if (pAd->CommonCfg.dbdc_mode)
			apcli2Gidx = 1;
#endif
		if ((pAd->bApCliCertTest == TRUE) && APCLI_IF_UP_CHECK(pAd, apcli2Gidx) && (ScanType == SCAN_2040_BSS_COEXIST)) {
			UCHAR Status = 1;

			MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("@(%s)  Scan Done ScanType=%d\n", __func__, ScanType));
			MlmeEnqueue(pAd, APCLI_CTRL_STATE_MACHINE, APCLI_CTRL_SCAN_DONE, 2, &Status, apcli2Gidx);
		}
	}
#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
#endif /* APCLI_CERT_SUPPORT */
#endif /* APCLI_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */
#ifdef MESH_SUPPORT
	MlmeEnqueue(pAd, MESH_CTRL_STATE_MACHINE, APMT2_MLME_SCAN_FINISH, 0, NULL, 0);
#endif /* MESH_SUPPORT */
	return TRUE;
}


#if 0
static INT scan_type_chk(RTMP_ADAPTER *pAd, UCHAR OpMode, UCHAR sc_type)
{
	return TRUE;
}
#endif

static INT scan_active(RTMP_ADAPTER *pAd, UCHAR OpMode, UCHAR ScanType, struct wifi_dev *wdev)
{
	UCHAR *frm_buf = NULL;
	HEADER_802_11 Hdr80211;
	ULONG FrameLen = 0;
	UCHAR SsidLen = 0;
#ifdef CON_WPS
	PWSC_CTRL pWscControl = NULL;
#endif /*CON_WPS*/
#ifdef CONFIG_STA_SUPPORT
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return FALSE;

#endif /* CONFIG_STA_SUPPORT */

	if (MlmeAllocateMemory(pAd, &frm_buf) != NDIS_STATUS_SUCCESS) {
		MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():allocate memory fail\n", __func__));
#ifdef CONFIG_STA_SUPPORT

		if (OpMode == OPMODE_STA) {
			pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
			Status = MLME_FAIL_NO_RESOURCE;
			MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_SCAN_CONF, 2, &Status, 0, wdev);
		}

#endif /* CONFIG_STA_SUPPORT */
#ifdef CONFIG_AP_SUPPORT

		if (OpMode == OPMODE_AP)
			pAd->Mlme.ApSyncMachine.CurrState = AP_SYNC_IDLE;

#endif /* CONFIG_AP_SUPPORT */
		return FALSE;
	}

#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3

	if (ScanType == SCAN_2040_BSS_COEXIST)
		MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("SYNC - SCAN_2040_BSS_COEXIST !! Prepare to send Probe Request\n"));

#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
	/* There is no need to send broadcast probe request if active scan is in effect.*/
	SsidLen = 0;

	if ((ScanType == SCAN_ACTIVE) || (ScanType == FAST_SCAN_ACTIVE)
#ifdef WSC_STA_SUPPORT
		|| ((ScanType == SCAN_WSC_ACTIVE) && (OpMode == OPMODE_STA))
#endif /* WSC_STA_SUPPORT */
#ifdef RT_CFG80211_P2P_SUPPORT
		|| (ScanType == SCAN_P2P)
#endif /* RT_CFG80211_P2P_SUPPORT */
	   )
		SsidLen = pAd->ScanCtrl.SsidLen;

#ifdef P2P_SUPPORT

	if ((pAd->ScanCtrl.ScanType == SCAN_P2P) || (pAd->ScanCtrl.ScanType == SCAN_P2P_SEARCH)
#ifdef P2P_APCLI_SUPPORT
		|| ((pAd->ScanCtrl.ScanType == SCAN_WSC_ACTIVE) && (OpMode == OPMODE_AP) && (P2P_CLI_ON(pAd)))
#endif /* P2P_APCLI_SUPPORT */
	   ) {
		PRT_P2P_CONFIG pP2PCtrl = &pAd->P2pCfg;
		UCHAR		SupRate[MAX_LEN_OF_SUPPORTED_RATES];
		UCHAR		SupRateLen = 0;
		SsidLen = WILDP2PSSIDLEN; /* Use Wildword SSID */
		SupRate[0]	= 0x8C;    /* 6 mbps, in units of 0.5 Mbps, basic rate */
		SupRate[1]	= 0x12;    /* 9 mbps, in units of 0.5 Mbps */
		SupRate[2]	= 0x98;    /* 12 mbps, in units of 0.5 Mbps, basic rate */
		SupRate[3]	= 0x24;    /* 18 mbps, in units of 0.5 Mbps */
		SupRate[4]	= 0xb0;    /* 24 mbps, in units of 0.5 Mbps, basic rate */
		SupRate[5]	= 0x48;    /* 36 mbps, in units of 0.5 Mbps */
		SupRate[6]	= 0x60;    /* 48 mbps, in units of 0.5 Mbps */
		SupRate[7]	= 0x6c;    /* 54 mbps, in units of 0.5 Mbps */
		SupRateLen	= 8;
		/* P2P scan must use P2P mac address. */
		MgtMacHeaderInit(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, BROADCAST_ADDR,
						 pP2PCtrl->CurrentAddress,
						 BROADCAST_ADDR);
		MakeOutgoingFrame(frm_buf,				&FrameLen,
						  sizeof(HEADER_802_11),	&Hdr80211,
						  1,						&SsidIe,
						  1,						&SsidLen,
						  SsidLen,					&WILDP2PSSID[0],
						  1,						&SupRateIe,
						  1,						&SupRateLen,
						  SupRateLen,			SupRate,
						  END_OF_ARGS);
	} else
#endif /* P2P_SUPPORT */
#ifdef RT_CFG80211_P2P_SUPPORT
		if (ScanType == SCAN_P2P) {
			MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): this is a p2p scan from cfg80211 layer\n", __func__));
			MgtMacHeaderInit(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, BROADCAST_ADDR,
							 pAd->CurrentAddress, BROADCAST_ADDR);
			MakeOutgoingFrame(frm_buf,               &FrameLen,
							  sizeof(HEADER_802_11),    &Hdr80211,
							  1,                        &SsidIe,
							  1,                        &SsidLen,
							  SsidLen,                  pAd->ScanCtrl.Ssid,
							  1,                        &SupRateIe,
							  1,                        &pAd->cfg80211_ctrl.P2pSupRateLen,
							  pAd->cfg80211_ctrl.P2pSupRateLen,  pAd->cfg80211_ctrl.P2pSupRate,
							  END_OF_ARGS);
		} else
#endif /* RT_CFG80211_P2P_SUPPORT */
		{
#ifdef CONFIG_AP_SUPPORT

			/*IF_DEV_CONFIG_OPMODE_ON_AP(pAd) */
			if (OpMode == OPMODE_AP) {
				UCHAR *src_mac_addr = NULL;
#ifdef APCLI_SUPPORT
#ifdef WSC_INCLUDED

				if (ScanType == SCAN_WSC_ACTIVE)
					src_mac_addr = &pAd->ApCfg.ApCliTab[wdev->func_idx].wdev.if_addr[0];
				else
#endif
#endif
				{/* search the first ap interface which use the same band */
					INT IdBss = 0;

					for (IdBss = 0; IdBss < pAd->ApCfg.BssidNum; IdBss++) {
						if (pAd->ApCfg.MBSSID[IdBss].wdev.DevInfo.Active) {
							if (HcGetBandByWdev(&pAd->ApCfg.MBSSID[IdBss].wdev) == HcGetBandByWdev(wdev))
								break;
						}
					}

					src_mac_addr = &pAd->ApCfg.MBSSID[IdBss].wdev.bssid[0];
				}

				MgtMacHeaderInitExt(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, BROADCAST_ADDR,
									src_mac_addr,
									BROADCAST_ADDR);
			}

#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT

			/*IF_DEV_CONFIG_OPMODE_ON_STA(pAd) */
			if (OpMode == OPMODE_STA) {
				MgtMacHeaderInit(pAd, &Hdr80211, SUBTYPE_PROBE_REQ, 0, BROADCAST_ADDR,
								 wdev->if_addr,
								 BROADCAST_ADDR);
			}

#endif /* CONFIG_STA_SUPPORT */
			MakeOutgoingFrame(frm_buf,               &FrameLen,
							  sizeof(HEADER_802_11),    &Hdr80211,
							  1,                        &SsidIe,
							  1,                        &SsidLen,
							  SsidLen,			        pAd->ScanCtrl.Ssid,
							  1,                        &SupRateIe,
							  1,                        &wdev->rate.SupRateLen,
							  wdev->rate.SupRateLen,  wdev->rate.SupRate,
							  END_OF_ARGS);

			if (wdev->rate.ExtRateLen) {
				ULONG Tmp;
				MakeOutgoingFrame(frm_buf + FrameLen,            &Tmp,
								  1,                                &ExtRateIe,
								  1,                                &wdev->rate.ExtRateLen,
								  wdev->rate.ExtRateLen,          wdev->rate.ExtRate,
								  END_OF_ARGS);
				FrameLen += Tmp;
			}
		}

#ifdef DOT11_N_SUPPORT

	if (WMODE_CAP_N(wdev->PhyMode)) {
		ULONG	Tmp;
		UCHAR	HtLen;
#ifdef RT_BIG_ENDIAN
		HT_CAPABILITY_IE HtCapabilityTmp;
#endif
#ifdef DOT11_VHT_AC
		struct _build_ie_info vht_ie_info;
#endif /* DOT11_VHT_AC */
#ifdef CONFIG_STA_SUPPORT

		if ((pAd->bBroadComHT == TRUE) && (OpMode == OPMODE_STA)) {
			UCHAR BROADCOM[4] = {0x0, 0x90, 0x4c, 0x33};
			HtLen = pStaCfg->MlmeAux.HtCapabilityLen + 4;
#ifdef RT_BIG_ENDIAN
			NdisMoveMemory(&HtCapabilityTmp, &pStaCfg->MlmeAux.HtCapability, SIZE_HT_CAP_IE);
			*(USHORT *)(&HtCapabilityTmp.HtCapInfo) = SWAP16(*(USHORT *)(&HtCapabilityTmp.HtCapInfo));
#ifdef UNALIGNMENT_SUPPORT
			{
				EXT_HT_CAP_INFO extHtCapInfo;
				NdisMoveMemory((PUCHAR)(&extHtCapInfo), (PUCHAR)(&HtCapabilityTmp.ExtHtCapInfo), sizeof(EXT_HT_CAP_INFO));
				*(USHORT *)(&extHtCapInfo) = cpu2le16(*(USHORT *)(&extHtCapInfo));
				NdisMoveMemory((PUCHAR)(&HtCapabilityTmp.ExtHtCapInfo), (PUCHAR)(&extHtCapInfo), sizeof(EXT_HT_CAP_INFO));
			}
#else
			*(USHORT *)(&HtCapabilityTmp.ExtHtCapInfo) = cpu2le16(*(USHORT *)(&HtCapabilityTmp.ExtHtCapInfo));
#endif /* UNALIGNMENT_SUPPORT */
			MakeOutgoingFrame(frm_buf + FrameLen,          &Tmp,
							  1,                                &WpaIe,
							  1,                                &HtLen,
							  4,                                &BROADCOM[0],
							  pStaCfg->MlmeAux.HtCapabilityLen,     &HtCapabilityTmp,
							  END_OF_ARGS);
#else
			MakeOutgoingFrame(frm_buf + FrameLen,          &Tmp,
							  1,                                &WpaIe,
							  1,                                &HtLen,
							  4,                                &BROADCOM[0],
							  pStaCfg->MlmeAux.HtCapabilityLen,     &pStaCfg->MlmeAux.HtCapability,
							  END_OF_ARGS);
#endif /* RT_BIG_ENDIAN */
		} else
#endif /* CONFIG_STA_SUPPORT */
		{
			HtLen = sizeof(HT_CAPABILITY_IE);
#ifdef RT_BIG_ENDIAN
			NdisMoveMemory(&HtCapabilityTmp, &pAd->CommonCfg.HtCapability, SIZE_HT_CAP_IE);
			*(USHORT *)(&HtCapabilityTmp.HtCapInfo) = SWAP16(*(USHORT *)(&HtCapabilityTmp.HtCapInfo));
#ifdef UNALIGNMENT_SUPPORT
			{
				EXT_HT_CAP_INFO extHtCapInfo;
				NdisMoveMemory((PUCHAR)(&extHtCapInfo), (PUCHAR)(&HtCapabilityTmp.ExtHtCapInfo), sizeof(EXT_HT_CAP_INFO));
				*(USHORT *)(&extHtCapInfo) = cpu2le16(*(USHORT *)(&extHtCapInfo));
				NdisMoveMemory((PUCHAR)(&HtCapabilityTmp.ExtHtCapInfo), (PUCHAR)(&extHtCapInfo), sizeof(EXT_HT_CAP_INFO));
			}
#else
			*(USHORT *)(&HtCapabilityTmp.ExtHtCapInfo) = cpu2le16(*(USHORT *)(&HtCapabilityTmp.ExtHtCapInfo));
#endif /* UNALIGNMENT_SUPPORT */
			MakeOutgoingFrame(frm_buf + FrameLen,          &Tmp,
							  1,                                &HtCapIe,
							  1,                                &HtLen,
							  HtLen,                            &HtCapabilityTmp,
							  END_OF_ARGS);
#else
			MakeOutgoingFrame(frm_buf + FrameLen,          &Tmp,
							  1,                                &HtCapIe,
							  1,                                &HtLen,
							  HtLen,                            &pAd->CommonCfg.HtCapability,
							  END_OF_ARGS);
#endif /* RT_BIG_ENDIAN */
		}

		FrameLen += Tmp;
#ifdef DOT11N_DRAFT3

		if ((pAd->ScanCtrl.Channel <= 14) && (pAd->CommonCfg.bBssCoexEnable == TRUE)) {
			ULONG Tmp;
			HtLen = 1;
			MakeOutgoingFrame(frm_buf + FrameLen,            &Tmp,
							  1,					&ExtHtCapIe,
							  1,					&HtLen,
							  1,			&pAd->CommonCfg.BSSCoexist2040.word,
							  END_OF_ARGS);
			FrameLen += Tmp;
		}

#endif /* DOT11N_DRAFT3 */
#ifdef APCLI_SUPPORT
#ifdef WSC_INCLUDED

		if ((ScanType == SCAN_WSC_ACTIVE) && (OpMode == OPMODE_AP)) {
			BOOLEAN bHasWscIe = FALSE;

			/*
				Append WSC information in probe request if WSC state is running
			*/
			if (pAd->ApCfg.ApCliTab[wdev->func_idx].wdev.WscControl.bWscTrigger)
				bHasWscIe = TRUE;

#ifdef WSC_V2_SUPPORT
			else if (pAd->ApCfg.ApCliTab[wdev->func_idx].wdev.WscControl.WscV2Info.bEnableWpsV2)
				bHasWscIe = TRUE;

#endif /* WSC_V2_SUPPORT */

			if (bHasWscIe) {
				UCHAR		*pWscBuf = NULL, WscIeLen = 0;
				ULONG		WscTmpLen = 0;
				os_alloc_mem(NULL, (UCHAR **)&pWscBuf, 512);

				if (pWscBuf != NULL) {
					NdisZeroMemory(pWscBuf, 512);
#ifdef CON_WPS
					MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("[scan_active: %d] ConWpsApCliMode = %d\n",
							 __LINE__, pAd->ApCfg.ConWpsApCliMode));
					pWscControl = &pAd->ApCfg.ApCliTab[wdev->func_idx].wdev.WscControl;

					if (pWscControl->conWscStatus == CON_WPS_STATUS_DISABLED ||
						pAd->ApCfg.ConWpsApCliMode != CON_WPS_APCLI_BAND_AUTO)
#endif /*CON_WPS*/
					{
						WscBuildProbeReqIE(pAd, STA_MODE, wdev->func_idx, wdev, pWscBuf, &WscIeLen);
					}

					MakeOutgoingFrame(frm_buf + FrameLen,              &WscTmpLen,
									  WscIeLen,                             pWscBuf,
									  END_OF_ARGS);
					FrameLen += WscTmpLen;
					os_free_mem(pWscBuf);
				} else
					MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s:: WscBuf Allocate failed!\n", __func__));
			}
		}

#endif /* WSC_INCLUDED */
#endif /* APCLI_SUPPORT */
#ifdef DOT11_VHT_AC
		vht_ie_info.frame_buf = (UCHAR *)(frm_buf + FrameLen);
		vht_ie_info.frame_subtype = SUBTYPE_PROBE_REQ;
		vht_ie_info.channel = pAd->ScanCtrl.Channel;
		vht_ie_info.phy_mode = wdev->PhyMode;
		vht_ie_info.wdev = wdev;
		FrameLen += build_vht_ies(pAd, &vht_ie_info);
#endif /* DOT11_VHT_AC */
	}

#endif /* DOT11_N_SUPPORT */
#ifdef WSC_STA_SUPPORT

	if (OpMode == OPMODE_STA) {
		BOOLEAN bHasWscIe = FALSE;

		/*
			Append WSC information in probe request if WSC state is running
		*/
		if ((wdev->WscControl.WscEnProbeReqIE) &&
			(wdev->WscControl.WscConfMode != WSC_DISABLE) &&
			(wdev->WscControl.bWscTrigger == TRUE))
			bHasWscIe = TRUE;

#ifdef WSC_V2_SUPPORT
		else if ((wdev->WscControl.WscEnProbeReqIE) &&
				 (wdev->WscControl.WscV2Info.bEnableWpsV2))
			bHasWscIe = TRUE;

#endif /* WSC_V2_SUPPORT */
#ifdef P2P_SUPPORT

		/*
			P2pMakeProbeReqIE will build WSC IE for P2P,
			it is not good to append normal WSC IE into P2P probe request frame here.
		*/
		if ((pAd->ScanCtrl.ScanType == SCAN_P2P) || (pAd->ScanCtrl.ScanType == SCAN_P2P_SEARCH) ||
			((pAd->ScanCtrl.ScanType == SCAN_WSC_ACTIVE) && (OpMode == OPMODE_AP) && (P2P_CLI_ON(pAd))))
			bHasWscIe = FALSE;

#endif /* P2P_SUPPORT */

		if (bHasWscIe) {
			UCHAR *pWscBuf = NULL, WscIeLen = 0;
			ULONG WscTmpLen = 0;
			os_alloc_mem(NULL, (UCHAR **)&pWscBuf, 512);

			if (pWscBuf != NULL) {
				NdisZeroMemory(pWscBuf, 512);
				WscBuildProbeReqIE(pAd, STA_MODE, 0, wdev, pWscBuf, &WscIeLen);
				MakeOutgoingFrame(frm_buf + FrameLen,              &WscTmpLen,
								  WscIeLen,                             pWscBuf,
								  END_OF_ARGS);
				FrameLen += WscTmpLen;
				os_free_mem(pWscBuf);
			} else
				MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s:: WscBuf Allocate failed!\n", __func__));
		}
	}

#ifdef WAC_SUPPORT
	WAC_AddDevAdvAttrIE(pAd, BSS0, frm_buf, &FrameLen);
#endif /* WAC_SUPPORT */
#endif /* WSC_STA_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
#ifdef WPA_SUPPLICANT_SUPPORT

	if ((OpMode == OPMODE_STA) &&
		(pAd->StaCfg[0].wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) &&
		(pAd->StaCfg[0].wpa_supplicant_info.WpsProbeReqIeLen != 0)) {
		ULONG		WpsTmpLen = 0;
		MakeOutgoingFrame(frm_buf + FrameLen,              &WpsTmpLen,
						  pAd->StaCfg[0].wpa_supplicant_info.WpsProbeReqIeLen,
						  pAd->StaCfg[0].wpa_supplicant_info.pWpsProbeReqIe,
						  END_OF_ARGS);
		FrameLen += WpsTmpLen;
	}

#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef RT_CFG80211_SUPPORT

	if ((OpMode == OPMODE_STA) &&
		(pAd->StaCfg[0].wpa_supplicant_info.WpaSupplicantUP != WPA_SUPPLICANT_DISABLE) &&
		CFG80211DRV_OpsScanRunning(pAd)) {
		ULONG		ExtraIeTmpLen = 0;
		MakeOutgoingFrame(frm_buf + FrameLen,              &ExtraIeTmpLen,
						  pAd->cfg80211_ctrl.ExtraIeLen,	pAd->cfg80211_ctrl.pExtraIe,
						  END_OF_ARGS);
		FrameLen += ExtraIeTmpLen;
	}

#endif /* RT_CFG80211_SUPPORT */
#endif /*CONFIG_STA_SUPPORT*/
#ifdef P2P_SUPPORT

	if ((pAd->ScanCtrl.ScanType == SCAN_P2P) || (pAd->ScanCtrl.ScanType == SCAN_P2P_SEARCH)
#ifdef P2P_APCLI_SUPPORT
		|| ((pAd->ScanCtrl.ScanType == SCAN_WSC_ACTIVE) && (OpMode == OPMODE_AP) && (P2P_CLI_ON(pAd)))
#endif /* P2P_APCLI_SUPPORT */
	   ) {
		ULONG P2PIeLen;
		UCHAR tmp_len;
		PUCHAR ptr;
		ptr = frm_buf + FrameLen;
		P2pMakeProbeReqIE(pAd, ptr, &tmp_len);
		FrameLen += tmp_len;
		/* Put P2P IE to the last. */
		ptr = frm_buf + FrameLen;
		P2pMakeP2pIE(pAd, SUBTYPE_PROBE_REQ, ptr, &P2PIeLen);
		FrameLen += P2PIeLen;
#ifdef WFD_SUPPORT
		ptr = frm_buf + FrameLen;
		WfdMakeWfdIE(pAd, SUBTYPE_PROBE_REQ, ptr, &P2PIeLen);
		FrameLen += P2PIeLen;
#endif /* WFD_SUPPORT */
	}

#ifdef WFA_WFD_SUPPORT

	if (pAd->P2pCfg.bWIDI) {
		if (pAd->pWfdIeInProbeReq && (pAd->WfdIeInProbeReqLen != 0)) {
			ULONG WfdIeTmpLen = 0;
			MakeOutgoingFrame(frm_buf + FrameLen,	&WfdIeTmpLen,
							  pAd->WfdIeInProbeReqLen,	pAd->pWfdIeInProbeReq,
							  END_OF_ARGS);
			FrameLen += WfdIeTmpLen;
		}
	}

#endif /* WFA_WFD_SUPPORT */
#endif /* P2P_SUPPORT */
	MiniportMMRequest(pAd, 0, frm_buf, FrameLen);
#ifdef MT_MAC_BTCOEX

	if (pAd->BtCoexMode == MT7636_COEX_MODE_TDD)
		MiniportMMRequest(pAd, 0, frm_buf, FrameLen);

#endif
#ifdef CONFIG_STA_SUPPORT

	if (OpMode == OPMODE_STA) {
		/*
			To prevent data lost.
			Send an NULL data with turned PSM bit on to current associated AP when SCAN in the channel where
			associated AP located.
		*/
		if (STA_STATUS_TEST_FLAG(pStaCfg, fSTA_STATUS_MEDIA_STATE_CONNECTED) &&
			(INFRA_ON(&pAd->StaCfg[0])) &&
			(pAd->StaCfg[0].wdev.channel == pAd->ScanCtrl.Channel)) {
			RTMPSendNullFrame(pAd,
							  pStaCfg,
							  pAd->CommonCfg.TxRate,
							  (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_WMM_INUSED) ? TRUE : FALSE),
							  PWR_SAVE);
			MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():Send PWA NullData frame to notify the associated AP!\n", __func__));
		}
	}

#endif /* CONFIG_STA_SUPPORT */
	MlmeFreeMemory(frm_buf);
	return TRUE;
}

#ifdef APCLI_SUPPORT
static void FireExtraProbeReq(RTMP_ADAPTER *pAd, UCHAR OpMode, UCHAR ScanType,
							  struct wifi_dev *wdev,  UCHAR *desSsid, UCHAR desSsidLen)
{
	UCHAR backSsid[MAX_LEN_OF_SSID];
	UCHAR backSsidLen = 0;
	NdisZeroMemory(backSsid, MAX_LEN_OF_SSID);
	/* 1. backup the original MlmeAux */
	backSsidLen = pAd->ScanCtrl.SsidLen;
	NdisCopyMemory(backSsid, pAd->ScanCtrl.Ssid, backSsidLen);
	/* 2. fill the desried ssid into SM */
	pAd->ScanCtrl.SsidLen = desSsidLen;
	NdisCopyMemory(pAd->ScanCtrl.Ssid, desSsid, desSsidLen);
	/* 3. scan action */
	scan_active(pAd, OpMode, ScanType, wdev);
	/* 4. restore to ScanCtrl */
	pAd->ScanCtrl.SsidLen  = backSsidLen;
	NdisCopyMemory(pAd->ScanCtrl.Ssid, backSsid, backSsidLen);
}
#endif /* APCLI_SUPPORT */
/*
	==========================================================================
	Description:
		Scan next channel
	==========================================================================
 */
VOID ScanNextChannel(RTMP_ADAPTER *pAd, UCHAR OpMode, struct wifi_dev *pwdev)
{
	UCHAR ScanType = SCAN_TYPE_MAX;
	UINT ScanTimeIn5gChannel = SHORT_CHANNEL_TIME;
	BOOLEAN ScanPending = FALSE;
	RALINK_TIMER_STRUCT *sc_timer = NULL;
	UINT stay_time = 0;
#ifdef WIDI_SUPPORT
	static int count;
#endif /* WIDI_SUPPORT */
	struct wifi_dev *wdev = pwdev;
#ifdef WH_EZ_SETUP
	CHAR apcli_idx;
	MAC_TABLE_ENTRY *pMacEntry;
#endif
	/* TODO: Star, fix me when Scan is prepare to modify */
#ifdef CONFIG_STA_SUPPORT
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#endif
	/* TODO: Star, fix me when Scan is prepare to modify */
#ifdef CONFIG_AP_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
		if (wdev == NULL)
			wdev = &pAd->ApCfg.MBSSID[MAIN_MBSSID].wdev;
	}
#endif

#ifdef WH_EZ_SETUP
#ifdef CONFIG_AP_SUPPORT
#ifdef APCLI_SUPPORT
	apcli_idx = wdev->func_idx;
	pMacEntry = MacTableLookup(pAd, pAd->ApCfg.ApCliTab[apcli_idx].wdev.bssid);
#endif
#endif
#endif

#ifdef CONFIG_ATE

	/* Nothing to do in ATE mode. */
	if (ATE_ON(pAd))
		return;

#endif /* CONFIG_ATE */
#ifdef WIDI_SUPPORT
#ifdef CONFIG_STA_SUPPORT

	if ((pStaCfg->bWIDI && (pAd->StaCfg[0].bSendingProbe == TRUE))
#ifdef P2P_SUPPORT
		|| (pAd->P2pCfg.bWIDI && (pAd->gP2pSendingProbeResponse == 1))
#endif /* P2P_SUPPORT */
	   ) {
		RTMPSetTimer(&pStaCfg->MlmeAux.ScanTimer, MAX_CHANNEL_TIME);
		return;
	}

#endif /* CONFIG_STA_SUPPORT */
#endif /* WIDI_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		if (MONITOR_ON(pAd))
			return;
	}
#ifdef HE_SUPPORT
#define IMPROVED_SCAN_CHANNEL_COUNT     3
#else /* !HE_SUPPORT */
#define IMPROVED_SCAN_CHANNEL_COUNT     7
#endif /* HE_SUPPORT */
	ScanPending = ((pAd->StaCfg[0].bImprovedScan) && (pAd->StaCfg[0].ScanChannelCnt >= IMPROVED_SCAN_CHANNEL_COUNT));
#endif /* CONFIG_STA_SUPPORT */
#ifdef CONFIG_AP_SUPPORT

	if (OpMode == OPMODE_AP)
		ScanType = pAd->ScanCtrl.ScanType;

#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT

	if (OpMode == OPMODE_STA)
		ScanType = pStaCfg->MlmeAux.ScanType;

#endif /* CONFIG_STA_SUPPORT */

	if (ScanType == SCAN_TYPE_MAX) {
#ifdef WH_EZ_SETUP
		if((pAd->ApCfg.ApCliTab[apcli_idx].wdev.enable_easy_setup == TRUE)
			&& (pAd->Mlme.ApSyncMachine.CurrState == AP_SCAN_LISTEN)) 
			pAd->Mlme.ApSyncMachine.CurrState = AP_SYNC_IDLE;
#endif
		MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s():Incorrect ScanType!\n", __func__));
		return;
	}

#ifdef CONFIG_STA_SUPPORT
#ifdef RT_CFG80211_SUPPORT

	/* Since the Channel List is from Upper layer */
	if (CFG80211DRV_OpsScanRunning(pAd) && !ScanPending)
		pAd->ScanCtrl.Channel = CFG80211DRV_OpsScanGetNextChannel(pAd);

#endif /* RT_CFG80211_SUPPORT */

	/* Finish scan task when triggers radio off */
	if (IsHcRadioCurStatOffByWdev(wdev))
		pAd->ScanCtrl.Channel = 0;

#endif /* CONFIG_STA_SUPPORT */

	if ((pAd->ScanCtrl.Channel == 0) || ScanPending) {
#ifdef WIDI_SUPPORT
		count++;

		if (count > 10) {
			count = 0;

			if (ScanType != SCAN_PASSIVE)
				MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Driver is Alive; ScanType %d\n", ScanType));
		}

#endif /* WIDI_SUPPORT */
#ifdef RT_CFG80211_SUPPORT
		//pAd->cfg80211_ctrl.Cfg80211CurChanIndex--;
#endif /* RT_CFG80211_SUPPORT */
		scan_ch_restore(pAd, OpMode, wdev);

#ifdef WH_EZ_SETUP
#ifdef CONFIG_AP_SUPPORT
#ifdef APCLI_SUPPORT
		if(pMacEntry && pAd->ApCfg.ApCliTab[apcli_idx].Valid 
			&& (pAd->ApCfg.ApCliTab[apcli_idx].wdev.enable_easy_setup == TRUE))
		{
			ApCliRTMPSendNullFrame(pAd,pMacEntry->CurrTxRate, FALSE, pMacEntry, PWR_ACTIVE);
		}
		if (pAd->ApCfg.ApCliTab[apcli_idx].wdev.enable_easy_setup == TRUE && wdev->ez_security.ez_scan == TRUE)
		{
			wdev->ez_security.ez_scan = FALSE;
			EZ_DEBUG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Start Join For  wdev-> type = %d wdev = %d\n", wdev->wdev_type,wdev->wdev_idx));
			ApCliIfUp(pAd);
				
		}
#endif	//APCLI_SUPPORT
#endif	//CONFIG_AP_SUPPORT
#endif	// WH_EZ_SETUP

	}

#ifdef RTMP_MAC_USB
#ifdef CONFIG_STA_SUPPORT
	else if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_NIC_NOT_EXIST) &&
			 (OpMode == OPMODE_STA)) {
		pStaCfg->SyncMachine.CurrState = SYNC_IDLE;
		MlmeCntlConfirm(&pStaCfg->wdev, MT2_SCAN_CONF, MLME_FAIL_NO_RESOURCE);
	}

#endif /* CONFIG_STA_SUPPORT */
#endif /* RTMP_MAC_USB */
	else {
#ifdef CONFIG_STA_SUPPORT

		if (OpMode == OPMODE_STA) {
			/* BBP and RF are not accessible in PS mode, we has to wake them up first*/
			if (pStaCfg->PwrMgmt.bDoze)
				RTMP_FORCE_WAKEUP(pAd, pStaCfg);

			/* leave PSM during scanning. otherwise we may lost ProbeRsp & BEACON*/
			if (pStaCfg->PwrMgmt.Psm == PWR_SAVE)
				RTMP_SET_PSM_BIT(pAd, pStaCfg, PWR_ACTIVE);

			/*check if wdev is mix mode and channel will go to other band, switch wdev to difference band*/
			HcCrossChannelCheck(pAd,  &pAd->StaCfg[0].wdev, pAd->ScanCtrl.Channel);
		}

#endif /* CONFIG_STA_SUPPORT */
#ifdef WH_EZ_SETUP
		if (IS_EZ_SETUP_ENABLED(pAd->ApCfg.ScanReqwdev) && pAd->ApCfg.ScanReqwdev->ez_security.scan_one_channel) {
			EZ_DEBUG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_TRACE, 
				("AP SYNC %s() - Only scan ch.%d and keep original channel setting.\n", 
				__FUNCTION__, pAd->ScanCtrl.Channel));
		}
		else
#endif /* WH_EZ_SETUP */
		{
			wlan_operate_scan(wdev, pAd->ScanCtrl.Channel);
		}
		{
			BOOLEAN bScanPassive = FALSE;

			if (pAd->ScanCtrl.Channel > 14) {
#ifdef DPA_T
				/* All 5G channel, No matter DFS/80211H setting is y or n */
				bScanPassive = TRUE;
#else /* DPA_T */

				if ((pAd->CommonCfg.bIEEE80211H == 1)
					&& RadarChannelCheck(pAd, pAd->ScanCtrl.Channel))
					bScanPassive = TRUE;

#endif /* !DPA_T */
			}

#ifdef CARRIER_DETECTION_SUPPORT

			if (pAd->CommonCfg.CarrierDetect.Enable == TRUE)
				bScanPassive = TRUE;

#endif /* CARRIER_DETECTION_SUPPORT */

			if (bScanPassive) {
				ScanType = SCAN_PASSIVE;
				ScanTimeIn5gChannel = MIN_CHANNEL_TIME;
			}
		}

		/* Check if channel if passive scan under current regulatory domain */
		if (CHAN_PropertyCheck(pAd, pAd->ScanCtrl.Channel, CHANNEL_PASSIVE_SCAN) == TRUE)
			ScanType = SCAN_PASSIVE;

#if defined(DPA_T) || defined(WIFI_REGION32_HIDDEN_SSID_SUPPORT)

		/* Ch 12~14 is passive scan, No matter DFS and 80211H setting is y or n */
		if ((pAd->ScanCtrl.Channel >= 12) && (pAd->ScanCtrl.Channel <= 14))
			ScanType = SCAN_PASSIVE;

#endif /* DPA_T */
#ifdef CONFIG_AP_SUPPORT

		if (OpMode == OPMODE_AP)
			sc_timer = &pAd->ScanCtrl.APScanTimer;

#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT

		if (OpMode == OPMODE_STA)
			sc_timer = &pStaCfg->MlmeAux.ScanTimer;

#endif /* CONFIG_STA_SUPPORT */

		if (!sc_timer) {
#ifdef WH_EZ_SETUP
			if((pAd->ApCfg.ApCliTab[apcli_idx].wdev.enable_easy_setup == TRUE)
				&& (pAd->Mlme.ApSyncMachine.CurrState == AP_SCAN_LISTEN)) 
				pAd->Mlme.ApSyncMachine.CurrState = AP_SYNC_IDLE;
#endif			
			MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s():ScanTimer not assigned!\n", __func__));
			return;
		}

		/* We need to shorten active scan time in order for WZC connect issue */
		/* Chnage the channel scan time for CISCO stuff based on its IAPP announcement */
		if (ScanType == FAST_SCAN_ACTIVE)
			stay_time = FAST_ACTIVE_SCAN_TIME;
		else { /* must be SCAN_PASSIVE or SCAN_ACTIVE*/
#ifdef CONFIG_STA_SUPPORT
			pAd->StaCfg[0].ScanChannelCnt++;
#endif /* CONFIG_STA_SUPPORT */
#ifdef CONFIG_AP_SUPPORT

			if ((OpMode == OPMODE_AP) && (pAd->ApCfg.bAutoChannelAtBootup))
				stay_time = AUTO_CHANNEL_SEL_TIMEOUT;
			else
#endif /* CONFIG_AP_SUPPORT */
				if (WMODE_CAP_2G(wdev->PhyMode) &&
					WMODE_CAP_5G(wdev->PhyMode)) {
					if (pAd->ScanCtrl.Channel > 14)
						stay_time = ScanTimeIn5gChannel;
					else
						stay_time = MIN_CHANNEL_TIME;

#ifdef WH_EZ_SETUP
					if ((IS_EZ_SETUP_ENABLED(wdev)) && ScanType != SCAN_PASSIVE)
						stay_time = FAST_ACTIVE_SCAN_TIME;
#endif
				} else {
#if defined (EZ_NETWORK_MERGE_SUPPORT) && defined (WH_EZ_SETUP)
					if (IS_EZ_SETUP_ENABLED(wdev))
					{
						if (ScanType != SCAN_PASSIVE)
							stay_time = FAST_ACTIVE_SCAN_TIME;
						else
							stay_time = MIN_CHANNEL_TIME;
					}
					else
#endif
						stay_time = MAX_CHANNEL_TIME;
				}
		}

#ifdef CONFIG_STA_SUPPORT
#ifdef RT_CFG80211_SUPPORT
#ifdef RT_CFG80211_P2P_CONCURRENT_DEVICE
#ifdef CONFIG_MULTI_CHANNEL

		if (RTMP_CFG80211_VIF_P2P_GO_ON(pAd))
			stay_time = FAST_ACTIVE_SCAN_TIME;

#endif /* CONFIG_MULTI_CHANNEL */
#endif /* RT_CFG80211_P2P_CONCURRENT_DEVICE */

		/* CFG_TODO: for testing. */
		/* Since the Channel List is from Upper layer */
		if (CFG80211DRV_OpsScanRunning(pAd) &&
			(pAd->cfg80211_ctrl.Cfg80211ChanListLen == 1))
			stay_time = 500;

#endif /* RT_CFG80211_SUPPORT */
#endif /* CONFIG_STA_SUPPORT */
		RTMPSetTimer(sc_timer, stay_time);

		if (SCAN_MODE_ACT(ScanType)) {
#ifdef APCLI_SUPPORT
#ifdef WH_EZ_SETUP
            PAPCLI_STRUCT pApCliEntry = NULL;
            UINT index = 0;
#endif
#endif
			if (scan_active(pAd, OpMode, ScanType, wdev) == FALSE){
#ifdef WH_EZ_SETUP
				if((pAd->ApCfg.ApCliTab[apcli_idx].wdev.enable_easy_setup == TRUE)
					&& (pAd->Mlme.ApSyncMachine.CurrState == AP_SCAN_LISTEN)) 
					pAd->Mlme.ApSyncMachine.CurrState = AP_SYNC_IDLE;
#endif
				return;
			}

#ifdef APCLI_SUPPORT
#ifdef WH_EZ_SETUP
			if (IS_EZ_SETUP_ENABLED(wdev)) {
                for(index = 0; index < MAX_APCLI_NUM; index++)
                {
                    pApCliEntry = &pAd->ApCfg.ApCliTab[index];
                    if(pApCliEntry->CfgHideSsidLen > 0){
                        FireExtraProbeReq(pAd,  OpMode, ScanType, wdev,
                            pApCliEntry->CfgHideSsid, pApCliEntry->CfgHideSsidLen);
                    }
                }
			}
#endif
#endif

#if 0 /* def CONFIG_STA_SUPPORT */

			/* Active scan with specific SSID to find hidden AP. */
			if ((wdev->wdev_type == WDEV_TYPE_STA) && (pAd->ScanCtrl.SsidLen > 0)) {
				/* Enhance Connectivity when Hidden Ssid Scanning */
				FireExtraProbeReq(pAd,  OpMode, ScanType, wdev, "", 0);
			} else
#endif /* CONFIG_STA_SUPPORT */
			{
#ifdef APCLI_SUPPORT
				PAPCLI_STRUCT pApCliEntry = NULL;
				UINT index = 0;
				BOOLEAN needUnicastScan = FALSE;
#ifdef APCLI_AUTO_CONNECT_SUPPORT
				needUnicastScan = pAd->ApCfg.ApCliAutoConnectRunning[wdev->func_idx];
#endif /* APCLI_AUTO_CONNECT_SUPPORT */
#ifdef AP_PARTIAL_SCAN_SUPPORT
				needUnicastScan |= pAd->ApCfg.bPartialScanning;
#endif /* AP_PARTIAL_SCAN_SUPPORT */

				for (index = 0; index < MAX_APCLI_NUM; index++) {
					pApCliEntry = &pAd->ApCfg.ApCliTab[index];

					if (needUnicastScan && pApCliEntry->CfgSsidLen > 0) {
						FireExtraProbeReq(pAd,  OpMode, ScanType, wdev,
										  pApCliEntry->CfgSsid, pApCliEntry->CfgSsidLen);
					}
				}

#endif /* APCLI_SUPPORT */
			}

#ifdef CONFIG_STA_SUPPORT

			/*
				Active scan with specific SSID to find hidden AP.
			*/
			if ((ScanType == SCAN_ACTIVE) &&
				(pAd->ScanCtrl.SsidLen > 0)) {
				/* Enhance Connectivity for Hidden Ssid Scanning */
				CHAR desiredSsid[MAX_LEN_OF_SSID], backSsid[MAX_LEN_OF_SSID];
				UCHAR desiredSsidLen, backSsidLen;
				/* For Boardcast SSID ProbeReq */
				desiredSsidLen =  0;
				NdisZeroMemory(desiredSsid, MAX_LEN_OF_SSID);
				/* 1. backup the original MlmeAux */
				backSsidLen = pAd->ScanCtrl.SsidLen;
				NdisCopyMemory(backSsid, pAd->ScanCtrl.Ssid, backSsidLen);
				/* 2. fill the desried ssid into SM */
				pAd->ScanCtrl.SsidLen = desiredSsidLen;
				NdisCopyMemory(pAd->ScanCtrl.Ssid, desiredSsid, desiredSsidLen);
				/* 3. scan action */
				scan_active(pAd, OpMode, ScanType, wdev);
				/* 4. restore to ScanCtrl */
				pAd->ScanCtrl.SsidLen  = backSsidLen;
				NdisCopyMemory(pAd->ScanCtrl.Ssid, backSsid, backSsidLen);
			}

#endif /* CONFIG_STA_SUPPORT */
		}

		/* For SCAN_CISCO_PASSIVE, do nothing and silently wait for beacon or other probe reponse*/
#ifdef CONFIG_STA_SUPPORT

		if (OpMode == OPMODE_STA)
			pStaCfg->SyncMachine.CurrState = SCAN_LISTEN;

#endif /* CONFIG_STA_SUPPORT */
#ifdef CONFIG_AP_SUPPORT

		if (OpMode == OPMODE_AP)
			pAd->Mlme.ApSyncMachine.CurrState = AP_SCAN_LISTEN;

#endif /* CONFIG_AP_SUPPORT */
	}
}


BOOLEAN ScanRunning(RTMP_ADAPTER *pAd)
{
	BOOLEAN	rv = FALSE;
#ifdef CONFIG_STA_SUPPORT
#ifdef P2P_SUPPORT
	rv = ((pAd->Mlme.ApSyncMachine.CurrState == AP_SCAN_LISTEN) ? TRUE : FALSE);

	if (rv == FALSE) {
		if ((pAd->Mlme.SyncMachine.CurrState == SCAN_LISTEN) || (pAd->Mlme.SyncMachine.CurrState == SCAN_PENDING))
			rv = TRUE;
	}

#else
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		/* TODO: Pat: */
		if ((pAd->StaCfg[0].SyncMachine.CurrState == SCAN_LISTEN) || (pAd->StaCfg[0].SyncMachine.CurrState == SCAN_PENDING))
			rv = TRUE;
	}
#endif /* P2P_SUPPORT */
#endif /* CONFIG_STA_SUPPORT */
#ifdef CONFIG_AP_SUPPORT
#ifdef AP_SCAN_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd)
	rv = ((pAd->Mlme.ApSyncMachine.CurrState == AP_SCAN_LISTEN) ? TRUE : FALSE);
#endif /* AP_SCAN_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */
	return rv;
}


/*
	==========================================================================
	Description:

	Return:
		scan_channel - channel to scan.
	Note:
		return 0 if no more next channel
	==========================================================================
 */
UCHAR FindScanChannel(
	RTMP_ADAPTER *pAd,
	UINT8 LastScanChannel)
{
	UCHAR scan_channel = 0;
#if 0

	if (ScanRunning(pAd) == FALSE)
		return 0;

#endif

	if (pAd->ScanCtrl.PartialScan.bScanning == TRUE) {
		scan_channel = FindPartialScanChannel(pAd);
		return scan_channel;
	}

	if (LastScanChannel == 0)
		scan_channel = FirstChannel(pAd);
	else
		scan_channel = NextChannel(pAd, LastScanChannel);

	return scan_channel;
}


/*
	==========================================================================
	Description:

	Return:
		scan_channel - channel to scan.
	Note:
		return 0 if no more next channel
	==========================================================================
 */
UCHAR FindPartialScanChannel(RTMP_ADAPTER *pAd)
{
	UCHAR scan_channel = 0;
	PARTIAL_SCAN *PartialScanCtrl = &pAd->ScanCtrl.PartialScan;
#if 0
	MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			 ("%s, %u, scan_channel = %u, NumOfChannels = %u, LastScanChannel = %u, bScanning = %u\n",
			  __func__, __LINE__,
			  scan_channel,
			  PartialScanCtrl->NumOfChannels,
			  PartialScanCtrl->LastScanChannel,
			  PartialScanCtrl->bScanning));
#endif

	if (PartialScanCtrl->NumOfChannels > 0) {
		PartialScanCtrl->NumOfChannels--;

		if (PartialScanCtrl->LastScanChannel == 0)
			scan_channel = FirstChannel(pAd);
		else
			scan_channel = NextChannel(pAd, PartialScanCtrl->LastScanChannel);

		/* update last scanned channel */
		PartialScanCtrl->LastScanChannel = scan_channel;

		if (scan_channel == 0) {
			PartialScanCtrl->BreakTime = 0;
			PartialScanCtrl->bScanning = FALSE;
			PartialScanCtrl->pwdev = NULL;
			PartialScanCtrl->NumOfChannels = DEFLAUT_PARTIAL_SCAN_CH_NUM;
		}
	} else {
		/* Pending for next partial scan */
		scan_channel = 0;
		PartialScanCtrl->NumOfChannels = DEFLAUT_PARTIAL_SCAN_CH_NUM;
	}

#ifdef WH_EZ_SETUP
	if(IS_ADPTR_EZ_SETUP_ENABLED(pAd)){
		EZ_DEBUG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			("%s, %u, scan_channel = %u,\n", __func__, __LINE__, scan_channel));
	} else
#endif // WH_EZ_SETUP
	{
#if 1
	MTWF_LOG(DBG_CAT_PROTO, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("%s, %u, scan_channel = %u, NumOfChannels = %u, LastScanChannel = %u, bScanning = %u\n",
			  __func__, __LINE__,
			  scan_channel,
			  PartialScanCtrl->NumOfChannels,
			  PartialScanCtrl->LastScanChannel,
			  PartialScanCtrl->bScanning));
#endif
	}
	return scan_channel;
}


INT PartialScanInit(RTMP_ADAPTER *pAd)
{
	PARTIAL_SCAN *PartialScanCtrl = &pAd->ScanCtrl.PartialScan;
	PartialScanCtrl->bScanning = FALSE;
	PartialScanCtrl->NumOfChannels = DEFLAUT_PARTIAL_SCAN_CH_NUM;
	PartialScanCtrl->LastScanChannel = 0;
	PartialScanCtrl->BreakTime = 0;
#ifdef WH_EZ_SETUP
	PartialScanCtrl->bPartialScanAllowed = FALSE;
#endif

	return 0;
}

#if defined(CONFIG_STA_SUPPORT) || defined(APCLI_SUPPORT)
/*
	==========================================================================
	Description:

	IRQL = DISPATCH_LEVEL

	==========================================================================
*/
VOID ScanParmFill(
	IN RTMP_ADAPTER *pAd,
	IN OUT MLME_SCAN_REQ_STRUCT *ScanReq,
	IN RTMP_STRING Ssid[],
	IN UCHAR SsidLen,
	IN UCHAR BssType,
	IN UCHAR ScanType)
{
	NdisZeroMemory(ScanReq->Ssid, MAX_LEN_OF_SSID);
	ScanReq->SsidLen = (SsidLen > MAX_LEN_OF_SSID) ? MAX_LEN_OF_SSID : SsidLen;
	NdisMoveMemory(ScanReq->Ssid, Ssid, ScanReq->SsidLen);
	ScanReq->BssType = BssType;
	ScanReq->ScanType = ScanType;
}
#endif /* defined(CONFIG_STA_SUPPORT) || defined(APCLI_SUPPORT) */
#endif /* SCAN_SUPPORT */

