/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	mtusb_io.c
*/
#include	"rt_config.h"

#define MAX_VENDOR_REQ_RETRY_COUNT  10

/*
	========================================================================

	Routine Description: NIC initialization complete

	Arguments:

	Return Value:

	IRQL =

	Note:

	========================================================================
*/
void mtusb_cfg_read(RTMP_ADAPTER *ad, UINT32 *value)
{
	RTUSB_VendorRequest(ad, (USBD_TRANSFER_DIRECTION_IN |
							 USBD_SHORT_TRANSFER_OK),
						DEVICE_VENDOR_REQUEST_IN,
						0x63, (0x50029018 & 0xffff0000) >> 16,
						(0x50029018 & 0x0000ffff), value, 4);
}

void mtusb_cfg_write(RTMP_ADAPTER *ad, UINT32 value)
{
	RTUSB_VendorRequest(
		ad,
		USBD_TRANSFER_DIRECTION_OUT,
		DEVICE_VENDOR_REQUEST_OUT,
		0x66,
		(0x50029018 & 0xffff0000) >> 16,
		(0x50029018 & 0x0000ffff),
		&value,
		4);
}


NTSTATUS RTUSBVenderReset(RTMP_ADAPTER *pAd)
{
	NTSTATUS Status;
	MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("-->RTUSBVenderReset\n"));
	Status = RTUSB_VendorRequest(
				 pAd,
				 USBD_TRANSFER_DIRECTION_OUT,
				 DEVICE_VENDOR_REQUEST_OUT,
				 0x01,
				 0x1,
				 0,
				 NULL,
				 0);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("<--RTUSBVenderReset\n"));
	return Status;
}


static NTSTATUS mtusb_multiwrite(RTMP_ADAPTER *pAd,
								 IN UINT32 Offset,
								 IN UCHAR * buf,
								 IN USHORT len,
								 IN USHORT batchLen)
{
	NTSTATUS Status = STATUS_SUCCESS;
	UINT32 index = Offset, actLen = batchLen, leftLen = len;
	UCHAR *pSrc = buf;

	do {
		actLen = (actLen > batchLen ? batchLen : actLen);
		Status = RTUSB_VendorRequest(
					 pAd,
					 USBD_TRANSFER_DIRECTION_OUT,
					 DEVICE_VENDOR_REQUEST_OUT,
					 0x66,
					 (index & 0xffff0000) >> 16,
					 (index & 0x0000ffff),
					 pSrc,
					 actLen);

		if (Status != STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("VendrCmdMultiWrite_nBytes failed!\n"));
			break;
		}

		index += actLen;
		leftLen -= actLen;
		pSrc = pSrc + actLen;
	} while (leftLen > 0);

	return Status;
}


static NTSTATUS mtusb_multiread(RTMP_ADAPTER *pAd, UINT32 addr, UCHAR *buf, UINT32 len)
{
	NTSTATUS Status;
	Status =  RTUSB_VendorRequest(pAd, (USBD_TRANSFER_DIRECTION_IN |
										USBD_SHORT_TRANSFER_OK),
								  DEVICE_VENDOR_REQUEST_IN,
								  0x63, (addr & 0xffff0000) >> 16,
								  (addr & 0x0000ffff), buf, len);
	return Status;
}


NTSTATUS mtusb_read_reg(RTMP_ADAPTER *pAd, UINT32 addr, UINT32 *value)
{
	NTSTATUS Status = 0;
	UINT32 localVal;
	UINT32 global_addr = mt_physical_addr_map(pAd, addr);

	if ((addr >= WISR0) && (addr <= HWIER4)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("\n*******************************************************\n"));
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("*******************************************************\n"));
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("%s:: USB doesn't support this CR,\naddr(0x%8x), global_addr(0x%8x), please check logic\n", __func__, addr, global_addr));
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("*******************************************************\n"));
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("*******************************************************\n\n"));
		return Status;
	}

#if 1
#if defined(CONFIG_STA_SUPPORT) && (defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT))

	/* TODO::Hanmin::fix me for multi-STAs */
	if (pAd->StaCfg[0].PwrMgmt.bDoze) {
		if (pAd->StaCfg[0].CountDowntoPsm == 0)
			pAd->StaCfg[0].CountDowntoPsm = STAY_2_SECONDS_AWAKE;

		AsicWakeup(pAd, TRUE, &pAd->StaCfg[0]);
	}

#endif /* CONFIG_STA_SUPPORT && (STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_1_SUPPORT) */
#else
#if defined(MT7603)  || defined(MT7636) || defined(MT7637)

	if ((global_addr >= 0x60000000) && (global_addr <= 0x604001ff) && OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_DOZE)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("%s:: H/W is in fOP_STATUS_DOZE and access WF_MAC CR, addr(0x%8x), global_addr(0x%8x). Error\n", __func__, addr, global_addr));
		return Status;
	}

#endif /*7603/7636*/
#endif
	Status = mtusb_multiread(pAd, global_addr, (UCHAR *)&localVal, 4);
	*value = le2cpu32(localVal);

	if (Status != 0) {
		*value = 0xffffffff;
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("%s::addr(0x%8x), global_addr(0x%8x), read this address error\n", __func__, addr, global_addr));
	}

	return Status;
}

NTSTATUS mtusb_write_reg(RTMP_ADAPTER *pAd, UINT32 addr, UINT32 value)
{
	NTSTATUS Status = 0;
	UINT32 global_addr = mt_physical_addr_map(pAd, addr);

	if ((addr >= WISR0) && (addr <= HWIER4)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("\n*******************************************************\n"));
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("*******************************************************\n"));
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("%s:: USB doesn't support this CR,\naddr(0x%8x), global_addr(0x%8x), please check logic\n", __func__, addr, global_addr));
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("*******************************************************\n"));
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("*******************************************************\n\n"));
		return Status;
	}

#if 1
#if defined(CONFIG_STA_SUPPORT) && (defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT))

	if (pAd->StaCfg[0].PwrMgmt.bDoze) {
		if (pAd->StaCfg[0].CountDowntoPsm == 0)
			pAd->StaCfg[0].CountDowntoPsm = STAY_2_SECONDS_AWAKE;

		AsicWakeup(pAd, TRUE, &pAd->StaCfg[0]);
	}

#endif /* CONFIG_STA_SUPPORT && (STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_1_SUPPORT) */
#else
#if defined(MT7603)  || defined(MT7636) || defined(MT7637)

	if ((global_addr >= 0x60000000) && (global_addr <= 0x604001ff) && OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_DOZE)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_ERROR, ("%s:: H/W is in fOP_STATUS_DOZE and access WF_MAC CR, addr(0x%8x), global_addr(0x%8x). Error\n", __func__, addr, global_addr));
		return Status;
	}

#endif /*7603/7636*/
#endif
	Status = mtusb_multiwrite(pAd, global_addr, (UCHAR *)&value, 4, 4);
	return Status;
}

NTSTATUS RTUSBMultiWrite(
	IN RTMP_ADAPTER *pAd,
	IN USHORT Offset,
	IN UCHAR *pData,
	IN USHORT length,
	IN BOOLEAN bWriteHigh)
{
	return NDIS_STATUS_FAILURE;
}

NTSTATUS RTUSBMultiWrite_OneByte(RTMP_ADAPTER *pAd, USHORT Offset, UCHAR *pData)
{
	return NDIS_STATUS_FAILURE;
}

NTSTATUS RTUSBMultiWrite_nBytes(
	IN RTMP_ADAPTER *pAd,
	IN USHORT Offset,
	IN UCHAR *buf,
	IN USHORT len,
	IN USHORT batchLen)
{
	return NDIS_STATUS_FAILURE;
}

NTSTATUS RTUSBWriteMACRegister(
	IN RTMP_ADAPTER *pAd,
	IN USHORT Offset,
	IN UINT32 Value,
	IN BOOLEAN bWriteHigh)
{
	return mtusb_multiwrite(pAd, Offset, (UCHAR *)&Value, 4, 4);
}

