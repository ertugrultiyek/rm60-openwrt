/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology	5th	Rd.
 * Science-based Industrial	Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2006, Ralink Technology, Inc.
 *
 * All rights reserved.	Ralink's source	code is	an unpublished work	and	the
 * use of a	copyright notice does not imply	otherwise. This	source code
 * contains	confidential trade secret material of Ralink Tech. Any attemp
 * or participation	in deciphering,	decoding, reverse engineering or in	any
 * way altering	the	source code	is stricitly prohibited, unless	the	prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	ra_ac_q_mgmt.c
*/

#include "rt_config.h"
#include "mcu/mt_cmd.h"

#ifdef RED_SUPPORT

#if 0
UINT_32 g_au4RedAcLimit[WMM_NUM_OF_AC] = { 3072, 3072, 3072, 3072 };

UINT_16 g_au2RedClassLimit[TX_RED_CLASS_NUM] = { 2048, 2048, 1024, 1024, 1024, 512, 512, 128 };

/*----------------------------------------------------------------------------*/
/*!
* \brief Record used TXD count of a STA and compare it with quota to
*        decide if this packet should be dropped
*
* \param[in]
*
* \return none
*/
/*----------------------------------------------------------------------------*/
BOOLEAN
RedDropMsdu(P_STA_RECORD_T prStaRec, UINT_8 ucAcQue, UINT_16 u2MsduToken)
{
#if (CFG_ESTIMATION_RED_CPU_UTILIZATION == 1)
	{
		/* BOOLEAN fgIsDrop; */
		UINT_32 avg_fix = RedDummyRedQueueLen(PktCtrlGetGlobalMsduCntPerAc[ucAcQue]);
		/* fgIsDrop = RedDummyRedCalculateP(avg_fix); */
		RedDummyRedCalculateP(avg_fix);

		/* return fgIsDrop; */
		return FALSE;
	}
#else

	if (u2MsduToken >= TX_TOKEN_MAX_NUM ||
		PktCtrlGetStaTotalMsduCnt((UINT32) prStaRec->ucIndex) >=
		g_au2RedClassLimit[prStaRec->ucRedLimitIdx] ||
		PktCtrlGetGlobalMsduCntPerAc((UINT_32) ucAcQue) >=
		g_au4RedAcLimit[ucAcQue]) {
		/* To do: develop dynamic threshold per STA and AC */
		/* return TRUE; */
	}

	return FALSE;
#endif
}

#if (CFG_ESTIMATION_RED_CPU_UTILIZATION == 1)
UINT_32 RedDummyRedQueueLen(UINT_32 u4QueueLen)
{
	UINT_32 avg_fix = 0;
	/*  UINT_32 qlen_fix = 0; */
	UINT_32 Wlog = 0;
	UINT_32 q = u4QueueLen;
	UINT_32 avg = 0;

	avg_fix += (q - (avg_fix >> Wlog));
	avg_fix = avg << Wlog;
	return avg_fix;
}

BOOLEAN RedDummyRedCalculateP(UINT_32 avg)
{
	UINT_32 min = 0, max = 0;
	UINT_32 B = 0, C = 0, D = 0;
	/* static INT_32 count = 0; */
	INT_32 count = -1;
	UINT_32 R = 0, R1 = 0;
	BOOLEAN fgIsDrop = FALSE;

	/* drop probability calculation. */

	if (min < avg) {
		count++;

		if (count == 0) {
			R = Math_Rand();
			R1 = R * B;
		} else if (avg > max) {
			if (R <= count * (C * avg + D)) {
				/* Drop packet. */
				fgIsDrop = TRUE;
				count = -1;
			}
		} else if (R1 <= count * (avg - min)) {
			if (R <= count * (C * avg + D)) {
				fgIsDrop = TRUE;
				/* Drop packet. */
				count = -1;
			}
		}
	} else
		count = -1;

	return fgIsDrop;
}
#endif /* CFG_ESTIMATION_RED_CPU_UTILIZATION == 1 */

#if (CFG_RED_TRUN_ON_RANDOM_DROP == 1)

UINT_8 CalActiveSta(UINT_8 ac)
{
	P_RED_AC_ElEMENT_T prAcElm = &g_arRedSta[0].arRedElm[ac];
	P_RED_STA_T prRedSta = &g_arRedSta[0];
	INT i;
	UINT_8 ucActiveSta = 0;

	for (i = 0; i < RED_STA_REC_NUM; i++) {
		if (prAcElm->u4AvgLen > prRedSta->i4qthMin)
			ucActiveSta++;

		prRedSta++;
		prAcElm = &prRedSta->arRedElm[ac];
	}

	return ucActiveSta;
}

bool PerRAACTailDrop(P_STA_RECORD_T prStaRec, UINT_8 ac)
{
	P_RED_AC_ElEMENT_T prAcElm =
		&g_arRedSta[prStaRec->ucIndex].arRedElm[ac];
	UINT_8 ucActiveSta = CalActiveSta(ac);
	UINT_16 u2DropThreshold;

	if (ucActiveSta == 0)
		return FALSE;
	else {
		u2DropThreshold =
			(TX_TOKEN_MAX_NUM - RA_AC_FREE_FOR_ALL) / ucActiveSta;

		if (prAcElm->u4AvgLen / QLEN_SCALED > u2DropThreshold) {
			prAcElm->u2DropTailCnt++;
			return TRUE;
		} else
			return FALSE;
	}
}

bool RedCalPktMarkingProb(P_STA_RECORD_T prStaRec, UINT8 ac)
{
	/* calculate drop probability based on new average queue length */
	int Pa, Pb;
	P_RED_AC_ElEMENT_T prAcElm =
		&g_arRedSta[prStaRec->ucIndex].arRedElm[ac];
	INT32 u2qCount = prAcElm->u2qCount;
	INT32 u2qRan = prAcElm->u2qRan;
	/* Pb = (qAvgLen - qthMin)/(qthMax - qthMin);  */
	Pb = RedCalProbB(prStaRec->ucIndex, ac);

	if (Pb < 0)
		Pb = 0;

	if (Pb > PROB_SCALED)
		Pb = PROB_SCALED;

	/* modify Pb to be uniform distribution, Pa = Pb/(1-count*Pb), approximate method 2 */
	if (u2qCount > 1) {
		Pa = u2qCount * Pb;

		if (Pa < PROB_SCALED)
			Pa = 0;
		else if (Pa < 2 * PROB_SCALED)
			Pa -= PROB_SCALED;
		else
			Pa = PROB_SCALED;

		if (Pa >= u2qRan)
			return true;
	} else if (u2qCount == 1) {
		/* avg_Len just cross queue threshold min */
		prAcElm->u2qRan = (Math_Rand() % PROB_SCALED);
	}

	return false;
}

INT32 RedCalProbB(UINT8 ucWlanIdx, UINT8 ac)
{
	P_RED_AC_ElEMENT_T prAcElm = &g_arRedSta[ucWlanIdx].arRedElm[ac];
	P_RED_STA_T prRedSta = &g_arRedSta[ucWlanIdx];
	INT32 i4VarA, i4VarB, Pb;
	INT32 i4qthMin = prRedSta->i4qthMin;
	INT32 i4qthMax = prRedSta->ucMultiplyNum * prRedSta->i4qthMin / 10;
	INT32 th_diff = (i4qthMax - i4qthMin) >> QLEN_SCALED_BIT;

	if (th_diff == 0)
		th_diff = 1;

	/* Pb = maxProb * (qAvgLen - qthMin)/(qthMax - qthMin); */
	i4VarA = QLEN_SCALED / th_diff;
	i4VarB = -1 * i4qthMin / th_diff;
	Pb = ((INT64) i4VarA * prAcElm->u4AvgLen >> QLEN_SCALED_BIT) +
		 (INT64) i4VarB;
	return Pb;
}

VOID RedCalIGMPCount(P_STA_RECORD_T prStaRec)
{
	g_arRedSta[prStaRec->ucIndex].u4IGMPCnt++;
}

UINT32 RedCalAvgQueueLen(P_STA_RECORD_T prStaRec, UINT8 ac, UINT32 u4AvgLen)
{
	/* P_RED_STA_T prRedSta = &g_arRedSta[prStaRec->ucIndex]; */
	P_RED_AC_ElEMENT_T prAcElm =
		&g_arRedSta[prStaRec->ucIndex].arRedElm[ac];
	INT_8 wLogBit = prAcElm->iWlogBit;
	UINT16 qLen;

	qLen =
		UmacInfoWrapQueuePacketNumber(UMAC_PLE_CFG_POOL_INDEX,
									  ENUM_LMAC_PORT_2, ac,
									  prStaRec->ucIndex);

	if (qLen == 0) {
		u4AvgLen = 0;

		if (prAcElm->ucqEmptyCnt < 255)
			prAcElm->ucqEmptyCnt++;
	} else {
		u4AvgLen +=
			((qLen << (QLEN_SCALED_BIT - wLogBit)) -
			 (u4AvgLen >> wLogBit));
	}

	return u4AvgLen;
}

VOID UpdateWlogBit(UINT8 ucWlanIdx, UINT32 u4Mpdutime)
{
	/* P_RED_STA_T prRedSta = &g_arRedSta[ucWlanIdx]; */
	P_RED_AC_ElEMENT_T prAcElm = &g_arRedSta[ucWlanIdx].arRedElm[0];
	UINT8 i;

	prAcElm->iWlogBit = (WSCALING_BIT - uint32_log2(u4Mpdutime));

	for (i = 0; i < NUM_OF_WMM_AC; i++) {
		if (prAcElm->ucShiftBit > 0)
			prAcElm->iWlogBit = 4;

		prAcElm++;
	}
}

int uint32_log2(UINT32 n)
{
#define S(k)

	if (n >= ((UINT32) 1 << k)) {
		i += k;
		n >>= k;
	}

	int i = -(n == 0);

	S(16);
	S(8);
	S(4);
	S(2);
	S(1);
	return i;
#undef S
}

#endif /* CFG_RED_TRUN_ON_RANDOM_DROP == 1 */
#endif
VOID RedInit(PRTMP_ADAPTER pAd)
{
	int i, j;
	P_RED_STA_T prRedSta = &pAd->red_sta[0];
	P_RED_AC_ElEMENT_T prAcElm = NULL;

	if (pAd->red_en) {
		/* Send cmd to enable N9 MPDU timer */
		MtCmdSetRedEnable(pAd, HOST2N9, pAd->red_en);

		/* For 7615 (CR4 offload)*/
		if (pAd->red_have_cr4) {
			MtCmdSetRedEnable(pAd, HOST2CR4, pAd->red_en);
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s: set CR4/N9 RED Enable to %d.\n", __func__, pAd->red_en));
		} else {
			/*For 7622 (No CR4), need to initial the parameter on driver */
			for (i = 0; i < RED_STA_REC_NUM; i++) {
				prRedSta->i4MpduTime = RED_MPDU_TIME_INIT;	/*us */
				prRedSta->u4Dropth = RED_HT_BW40_DEFAULT_THRESHOLD * QLEN_SCALED;
				prRedSta->ucMultiplyNum = RED_MULTIPLE_NUM_DEFAULT;
				prRedSta->u2DriverFRCnt = 0;
				prAcElm = &prRedSta->arRedElm[0];

				for (j = WMM_AC_BK; j < WMM_NUM_OF_AC; j++) {
					prAcElm->u2DropCnt = 0;
					prAcElm->u2EnqueueCnt = 0;
					prAcElm->u2qEmptyCnt = 0;
					prAcElm->ucShiftBit = 0;
					prAcElm->ucGBCnt = 0;
					prAcElm++;
				}

				prRedSta++;
			}

			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s: set Driver/N9 RED Enable to %d.\n", __func__, pAd->red_en));
		}

		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: RED Initiailize Done.\n", __func__));
	}
}

VOID RedResetSta(UINT8 ucWlanIdx, UINT_8 ucMode, UINT_8 ucBW, RTMP_ADAPTER *pAd)
{
	P_RED_STA_T prRedSta = &pAd->red_sta[ucWlanIdx];
	/*P_STA_RECORD_T prStaRec = &g_arStaRec[ucWlanIdx];*/
	PMAC_TABLE_ENTRY pEntry = &pAd->MacTab.Content[ucWlanIdx];
	P_RED_AC_ElEMENT_T prAcElm = &pAd->red_sta[ucWlanIdx].arRedElm[0];
	UINT8 i;

	if (pEntry->TXBAbitmap != 0) {
		/*HT*/
		if (ucMode == MODE_HTMIX) {
			if (ucBW == BW_20)
				prRedSta->u4Dropth = RED_HT_BW20_DEFAULT_THRESHOLD * QLEN_SCALED;

			if (ucBW == BW_40)
				prRedSta->u4Dropth = RED_HT_BW40_DEFAULT_THRESHOLD * QLEN_SCALED;
		}

		/*VHT*/
		if (ucMode == MODE_VHT) {
			if (ucBW == BW_20)
				prRedSta->u4Dropth = RED_VHT_BW20_DEFAULT_THRESHOLD * QLEN_SCALED;

			if (ucBW == BW_40)
				prRedSta->u4Dropth = RED_VHT_BW40_DEFAULT_THRESHOLD * QLEN_SCALED;

			if (ucBW >= BW_80)
				prRedSta->u4Dropth = RED_VHT_BW80_DEFAULT_THRESHOLD * QLEN_SCALED;
		}
	} else {
		/*Legacy */
		prRedSta->u4Dropth = RED_LEGACY_DEFAULT_THRESHOLD * QLEN_SCALED;
	}

	for (i = WMM_AC_BK; i < WMM_NUM_OF_AC; i++) {
		prAcElm->u2qEmptyCnt = 0;
		prAcElm->ucShiftBit = 0;
		prAcElm->u2DropCnt = 0;
		prAcElm->ucGBCnt = 0;
		prAcElm++;
	}
}

VOID RedBadNode(UINT8 ucWlanIdx, UINT8 ATC_WATF_Enable, RTMP_ADAPTER *pAd)
{
	P_RED_AC_ElEMENT_T prAcElm = &pAd->red_sta[ucWlanIdx].arRedElm[0];
	P_RED_STA_T prRedSta = &pAd->red_sta[ucWlanIdx];
	PMAC_TABLE_ENTRY pEntry = &pAd->MacTab.Content[ucWlanIdx];
	UINT8 i;
	UINT8 ucGoodNodeCnt = 0;
	UINT8 ucBadNodeCnt = 0;
	UINT8 ucIsBadNode = FALSE;
	UINT8 ucIsSetDefault = FALSE;

	for (i = WMM_AC_BK; i < WMM_NUM_OF_AC; i++) {
		ucBadNodeCnt = (prAcElm->ucGBCnt & RED_BAD_NODE_CNT_MASK);
		ucGoodNodeCnt = (prAcElm->ucGBCnt & RED_GOOD_NODE_CNT_MASK) >> RED_GOOD_NODE_CNT_SHIFT_BIT;
		ucIsBadNode = (prAcElm->ucGBCnt & RED_IS_BAD_NODE_MASK) >> RED_IS_BAD_NODE_SHIFT_BIT;

		/* Check Is Bad Node or not */
		if (prAcElm->u2EnqueueCnt >= (prRedSta->u4Dropth >> prAcElm->ucShiftBit)) {

		/* Drop packet immediately if ATC for WATF enable to prevent slow client occupy much PLE buffer.*/
			if (ATC_WATF_Enable)
				ucBadNodeCnt = RED_MAX_BAD_NODE_CNT;
			else
				ucBadNodeCnt++;

			ucGoodNodeCnt = 0;
		} else {
			/* Good Node */
			ucGoodNodeCnt++;
			ucBadNodeCnt = 0;
		}

		if ((prAcElm->ucShiftBit > 0) &&
			(prRedSta->u4Dropth >> prAcElm->ucShiftBit) <= (RED_BAD_NODE_DROP_THRESHOLD * QLEN_SCALED)) {
			if (pEntry->TXBAbitmap != 0)
				/*HT and VHT */
				prRedSta->u4Dropth = (RED_BAD_NODE_DROP_THRESHOLD * QLEN_SCALED) << prAcElm->ucShiftBit;
			else
				/*Legacy */
				prRedSta->u4Dropth = (RED_BAD_NODE_LEGACY_DEFAULT_THRESHOLD * QLEN_SCALED) << prAcElm->ucShiftBit;

			ucIsSetDefault = TRUE;
		}

		if (ucBadNodeCnt >= RED_MAX_BAD_NODE_CNT) {
			ucBadNodeCnt = 0;
			ucIsBadNode = TRUE;

			if (ATC_WATF_Enable && !ucIsSetDefault)
				prAcElm->ucShiftBit++;
		}

		if (ucGoodNodeCnt >= RED_MAX_GOOD_NODE_CNT) {
			ucGoodNodeCnt = 0;

			if (prAcElm->ucShiftBit > 0)
				prAcElm->ucShiftBit--;
			else	/*ucShiftBit == 0 */
				ucIsBadNode = FALSE;
		}

/*
ucGBCnt
 ----------------------------------------------------
Bits |       7          |       6|      5|      4       |       3|      2|      1|      0       |
      |IsBadNode   |GoodNodeCnt                |       BadNodeCnt                    |
----------------------------------------------------
*/
		prAcElm->ucGBCnt = ((ucIsBadNode << RED_IS_BAD_NODE_SHIFT_BIT) |
							(ucGoodNodeCnt << RED_GOOD_NODE_CNT_SHIFT_BIT) |
							(ucBadNodeCnt));
		prAcElm++;
	}
}

bool RedMarkPktDrop(UINT8 ucWlanIdx, UINT8 ucQidx, PRTMP_ADAPTER pAd)
{
	UINT8 ucAC = (ucQidx % WMM_NUM_OF_AC);
	P_RED_AC_ElEMENT_T prAcElm = &pAd->red_sta[ucWlanIdx].arRedElm[ucAC];
	P_RED_STA_T prRedSta = &pAd->red_sta[ucWlanIdx];
	UINT8 IsBadNode;

	/* If WlanIdx is invaild, then drop this packet */
	if (ucWlanIdx > MAX_LEN_OF_MAC_TABLE)
		return TRUE;

	/*
	   In following condition, we don't drop traffic :
	   1. RED Disable
	   2. For WMM detection and number of InUseSta is less than 2.
	   3. Only one station is connect.
	 */
	if ((pAd->red_en == FALSE)
		|| ((pAd->is_on) && (pAd->red_in_use_sta <= 2))
		|| (pAd->red_in_use_sta <= 1)) {
		/*Set IsBadNode(bit 7) to FALSE */
		prRedSta->arRedElm[0].ucGBCnt &= 0x7F;
		prRedSta->arRedElm[1].ucGBCnt &= 0x7F;
		prRedSta->arRedElm[2].ucGBCnt &= 0x7F;
		prRedSta->arRedElm[3].ucGBCnt &= 0x7F;
	}

	IsBadNode = (prAcElm->ucGBCnt & RED_IS_BAD_NODE_MASK) >> RED_IS_BAD_NODE_SHIFT_BIT;

	if (prAcElm->u2EnqueueCnt == 0)
		prAcElm->u2qEmptyCnt++;

	if (IsBadNode) {
		/* Drop packet if qlen over Drop_threshold */
		if (prAcElm->u2EnqueueCnt >= (prRedSta->u4Dropth >> prAcElm->ucShiftBit)) {
			prAcElm->u2DropCnt++;
			return TRUE;
		}
	}

	prAcElm->u2EnqueueCnt++;

	return FALSE;
}

VOID RedRecordCP(UINT8 ucWlanIdx, PRTMP_ADAPTER pAd)
{
	UINT8 ucAC = pAd->cp_support;
	P_RED_AC_ElEMENT_T prAcElm = &pAd->red_sta[ucWlanIdx].arRedElm[ucAC];

	prAcElm = &pAd->red_sta[ucWlanIdx].arRedElm[ucAC];
	prAcElm->u2EnqueueCnt++;
}



VOID RedEnqueueFail(UINT8 ucWlanIdx, UINT8 ucQidx, PRTMP_ADAPTER pAd)
{
	UINT8 ucAC = (ucQidx % WMM_NUM_OF_AC);
	P_RED_AC_ElEMENT_T prAcElm = &pAd->red_sta[ucWlanIdx].arRedElm[ucAC];

	if (prAcElm->u2EnqueueCnt > 0)
		prAcElm->u2EnqueueCnt--;
}


VOID UpdateThreshold(UINT8 ucWlanIdx, RTMP_ADAPTER *pAd)
{
	P_RED_STA_T prRedSta = &pAd->red_sta[ucWlanIdx];
	UINT16 u2Dropth = 0;

	if (prRedSta->i4MpduTime == 0)
		prRedSta->i4MpduTime = 1;

	u2Dropth = pAd->red_targetdelay / prRedSta->i4MpduTime;

	if (u2Dropth <= RED_DROP_TH_LOWER_BOUND)
		u2Dropth = RED_DROP_TH_LOWER_BOUND;
	else if (u2Dropth >= RED_DROP_TH_UPPER_BOUND)
		u2Dropth = RED_DROP_TH_UPPER_BOUND;

	prRedSta->u4Dropth = (u2Dropth * prRedSta->ucMultiplyNum * QLEN_SCALED / 10);
}

VOID UpdateAirtimeRatio(UINT8 ucWlanIdx, UINT8 ucAirtimeRatio, UINT8 ATC_WATF_Enable, RTMP_ADAPTER *pAd)
{
	P_RED_STA_T prRedSta = &pAd->red_sta[ucWlanIdx];
	UINT8 ucNum;
	UINT8 ucIndex;

	if (ATC_WATF_Enable
		&& (prRedSta->u4Dropth >= RED_BAD_NODE_DROP_THRESHOLD * QLEN_SCALED)) {
		ucIndex = ucAirtimeRatio / 10;
		ucNum = ucIndex * 15 / 10;
	} else
		ucNum = 15;

	prRedSta->ucMultiplyNum = 15 + ucNum;
}

VOID UpdateTargetDelay(UINT8 ATC_WATF_Enable, RTMP_ADAPTER *pAd)
{
	if (ATC_WATF_Enable)
		pAd->red_targetdelay = pAd->red_atm_on_targetdelay;
	else
		pAd->red_targetdelay = pAd->red_atm_off_targetdelay;
}
#if 0

VOID RedUpdatePBC(P_WIFI_CMD_T prWiFiCmd)
{
	P_CMD_PKT_BUDGET_CTRL_T prCmdPbcUpdate = (P_CMD_PKT_BUDGET_CTRL_T) prWiFiCmd->aucBuffer;
	P_CMD_PKT_BUDGET_CTRL_ENTRY_T prCtlEnt = NULL;
	UINT8 ucQueIdx;
	UINT8 ucWMMdetectCnt = 0;

	for (ucQueIdx = WMM_AC_BK; ucQueIdx <= WMM_NUM_OF_AC; ucQueIdx++) {
		prCtlEnt = &prCmdPbcUpdate->aacQue[ucQueIdx];

		if (prCtlEnt->upper_bound != PBC_BOUNDARY_RESET_TO_DEFAULT)
			ucWMMdetectCnt++;
	}

	if (ucWMMdetectCnt == ucQueIdx) {
		g_fgWMMdetect = TRUE;
		DBGPRINT(("\x1b[31m%s: WMM is detected !!\x1b[m", __func__));
	} else {
		g_fgWMMdetect = FALSE;
		DBGPRINT(("\x1b[32m%s: WMM is not detected !!\x1b[m", __func__));
	}
}
#endif
VOID appShowRedDebugMessage(RTMP_ADAPTER *pAd)
{
	UINT_8 uRedStaNum, i, j;
	P_RED_STA_T prRedSta;
	P_RED_AC_ElEMENT_T prAcElm;
	/* Show Debug Message by cmd */
	uRedStaNum = pAd->red_sta_num;
	prRedSta = &pAd->red_sta[1];

	for (i = 1; i <= uRedStaNum; i++) {
		prAcElm = &prRedSta->arRedElm[WMM_AC_BK];

		for (j = WMM_AC_BK; j <= WMM_AC_VO; j++) {
			/*Only if EnqueueCnt >0 or DropCnt >0, show this AC's message */
			if ((prAcElm->u2EnqueueCnt > 0) || (prAcElm->u2DropCnt > 0)) {
				MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_OFF,
					 ("STA %d, AC %d, Len %d, Thres %d, Drop %d, ShiftBit %d, qEmpty %d, ATRatio %d, G/Bcnt %d/%d, IsBad %d, mpdu %d\n",
					  (i),
					  (j),
					  (prAcElm->u2EnqueueCnt),
					  (prRedSta->u4Dropth / QLEN_SCALED) >> prAcElm->ucShiftBit,
					  (prAcElm->u2DropCnt),
					  (prAcElm->ucShiftBit),
					  (prAcElm->u2qEmptyCnt),
					  (prRedSta->ucMultiplyNum),
					  (prAcElm->ucGBCnt & RED_GOOD_NODE_CNT_MASK) >> 4,
					  (prAcElm->ucGBCnt & RED_BAD_NODE_CNT_MASK),
					  (prAcElm->ucGBCnt & RED_IS_BAD_NODE_MASK) >> 7,
					  (prRedSta->i4MpduTime)
					 ));
				prAcElm->u2DropCnt = 0;
				prAcElm->u2qEmptyCnt = 0;
			}
			prAcElm++;
		}

		prRedSta++;
	}
}

VOID RedSetTargetDelay(INT16 i2TarDelay, PRTMP_ADAPTER pAd)
{
	UINT8 fgATCEnable = pAd->vow_cfg.en_bw_ctrl;
	UINT8 fgATFEnable = pAd->vow_cfg.en_airtime_fairness;
	UINT8 fgWATFEnable = pAd->vow_watf_en;
	UINT8 fgATCorWATFEnable = fgATCEnable || (fgATFEnable && fgWATFEnable);

	if (fgATCorWATFEnable)
		pAd->red_atm_on_targetdelay = i2TarDelay;
	else
		pAd->red_atm_off_targetdelay = i2TarDelay;
}

#if 0
VOID RedRecordForceRateFromDriver(UINT8 ucWcid, BOOLEAN fgIsForceRate)
{
	P_RED_STA_T prRedSta = RedGetStaByID(ucWcid);

	if (fgIsForceRate)
		prRedSta->u2DriverFRCnt++;
}
#endif
VOID RedCalForceRateRatio(UINT8 ucWcid, UINT16 u2N9ARCnt, UINT16 u2N9FRCnt, RTMP_ADAPTER *pAd)
{
	P_RED_STA_T prRedSta = &pAd->red_sta[ucWcid];
	P_RED_AC_ElEMENT_T prAcElm = &prRedSta->arRedElm[0];
	UINT16 u2TxTotalCnt = 0;
	UINT8 ucRatio = 0;
	UINT8 ucIsBadNode = FALSE;
	UINT8 i;

	for (i = WMM_AC_BK; i < WMM_NUM_OF_AC; i++) {
		ucIsBadNode |= (prAcElm->ucGBCnt & RED_IS_BAD_NODE_MASK) >> RED_IS_BAD_NODE_SHIFT_BIT;
		prAcElm++;
	}

	if (ucIsBadNode == FALSE) {
		/* TotalCnt = AutoRateCnt(N9) + ForceRateCnt(N9) +  ForceRateCnt(Driver) */
		u2TxTotalCnt = u2N9ARCnt + u2N9FRCnt + prRedSta->u2DriverFRCnt;
		/* Ratio = [ForceRateCnt(N9) +  ForceRateCnt(Driver)]/TotalCnt */
		ucRatio = (u2N9FRCnt + prRedSta->u2DriverFRCnt) * 100 / u2TxTotalCnt;

		if (ucRatio >= FORCE_RATIO_THRESHOLD)
			prRedSta->i4MpduTime = -1;
	}

	prRedSta->u2DriverFRCnt = 0;
}

VOID RedTxFreeEventNotifyHandler(UINT32 *dataPtr, UINT8 ucMsduIdCnt, UINT8 version, RTMP_ADAPTER *pAd)
{
	/* Parsing WlanIdx & AC from TX Done Event DW2 */
	UINT32 u4currentDW = *(UINT32 *)(dataPtr + 2);
	P_RED_AC_ElEMENT_T prAcElm;
	UINT8 ucWlanIdx, ucAC, ucIndex, ucQidx;

	for (ucIndex = 1; ucIndex <= ucMsduIdCnt; ucIndex++) {
		ucWlanIdx = ((u4currentDW & TX_DONE_EVENT_WLAN_ID_MASK) >> TX_DONE_EVENT_WLAN_ID_SHIFT_BIT);
		ucQidx = ((u4currentDW & TX_DONE_EVENT_Q_IDX_MASK) >> TX_DONE_EVENT_Q_IDX_SHIFT_BIT);

		if ((ucQidx >= TX_Q_AC0) && (ucQidx <= TX_Q_AC33))
			ucAC = (ucQidx % WMM_NUM_OF_AC);
		else
			continue;

		prAcElm = &pAd->red_sta[ucWlanIdx].arRedElm[ucAC];

		if (prAcElm->u2EnqueueCnt > 0)
			prAcElm->u2EnqueueCnt--;

		u4currentDW = *(UINT32 *)(dataPtr + 2 + ucIndex);
	}
}


/* Command */

INT set_red_enable(PRTMP_ADAPTER pAd, RTMP_STRING *arg)
{
	UINT32 en, rv;

	if (arg) {
		rv = sscanf(arg, "%d", &en);

		if ((rv > 0) && (en <= 1)) {
			pAd->red_en = en;
			/* to CR4 & N9 */
			MtCmdSetRedEnable(pAd, HOST2N9, pAd->red_en);

			if (pAd->red_have_cr4) {
				MtCmdSetRedEnable(pAd, HOST2CR4, pAd->red_en);
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
						 ("%s: set CR4/N9 RED Enable to %d.\n", __func__, pAd->red_en));
			} else {
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
						 ("%s: set Driver/N9 RED Enable to %d.\n", __func__, pAd->red_en));
			}
		} else
			return FALSE;
	} else
		return FALSE;

	return TRUE;
}

INT set_red_target_delay(PRTMP_ADAPTER pAd, RTMP_STRING *arg)
{
	UINT32 rv, tarDelay;

	if (arg) {
		rv = sscanf(arg, "%d", &tarDelay);

		if ((rv > 0) && (tarDelay >= 1) && (tarDelay <= 32767)) {
			if (pAd->red_have_cr4) {
				MtCmdSetRedTargetDelay(pAd, HOST2CR4, tarDelay);
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
						 ("%s: set CR4 RED TARGET_DELAY to %d.\n", __func__, tarDelay));
			} else {
				RedSetTargetDelay(tarDelay, pAd);
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
						 ("%s: set Driver RED TARGET_DELAY to %d.\n", __func__, tarDelay));
			}
		} else
			return FALSE;
	} else
		return FALSE;

	return TRUE;
}

INT set_red_show_sta(PRTMP_ADAPTER pAd,	RTMP_STRING *arg)
{
	UINT32 sta, rv;

	if (arg) {
		rv = sscanf(arg, "%d", &sta);

		if ((rv > 0) && (sta <= 127)) {
			if (pAd->red_have_cr4) {
				MtCmdSetRedShowSta(pAd, HOST2CR4, sta);
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
						 ("%s: set CR4 RED show sta to %d.\n", __func__, sta));
			} else {
				pAd->red_sta_num = sta;
				MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
						 ("%s: set Driver RED show sta to %d.\n", __func__, sta));
			}
		} else
			return FALSE;
	} else
		return FALSE;

	return TRUE;
}

INT set_red_debug_enable(PRTMP_ADAPTER pAd, RTMP_STRING *arg)
{
	UINT32 en, rv;

	if (arg) {
		rv = sscanf(arg, "%d", &en);

		if ((pAd->red_have_cr4 == FALSE) && (rv > 0) && (en <= 1)) {
			pAd->red_debug_en = en;
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s: set RED Debug Message Enable to %d.\n", __func__, pAd->red_debug_en));
		} else
			return FALSE;
	} else
		return FALSE;

	return TRUE;
}


INT show_red_info(PRTMP_ADAPTER pAd, RTMP_STRING *arg)
{
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			 ("======== RED(per-STA Tail Drop) Information ========\n"));
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			 ("RED Enbale: %d\n", pAd->red_en));

	if (pAd->red_have_cr4 == FALSE) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("RED Target Delay: %d(us)\n", pAd->red_targetdelay));
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("RED Monitor STA: %d\n", pAd->red_sta_num));
	}

	return TRUE;
}

#endif /* RED_SUPPORT */

