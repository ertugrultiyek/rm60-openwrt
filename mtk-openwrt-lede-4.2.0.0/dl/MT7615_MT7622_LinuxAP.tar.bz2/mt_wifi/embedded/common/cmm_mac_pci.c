/****************************************************************************
 * Ralink Tech Inc.
 * Taiwan, R.O.C.
 *
 * (c) Copyright 2002, Ralink Technology, Inc.
 *
 * All rights reserved. Ralink's source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of Ralink Tech. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************/



#ifdef RTMP_MAC_PCI
#include	"rt_config.h"


static INT desc_ring_alloc(RTMP_ADAPTER *pAd, RTMP_DMABUF *pDescRing, INT size)
{
	VOID *pdev = ((POS_COOKIE)(pAd->OS_Cookie))->pDev;

	pDescRing->AllocSize = size;
	RtmpAllocDescBuf(pdev,
					 0,
					 pDescRing->AllocSize,
					 FALSE,
					 &pDescRing->AllocVa,
					 &pDescRing->AllocPa);

	if (pDescRing->AllocVa == NULL) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_ERROR, ("Failed to allocate a big buffer\n"));
		return ERRLOG_OUT_OF_SHARED_MEMORY;
	}

	/* Zero init this memory block*/
	NdisZeroMemory(pDescRing->AllocVa, size);
	return 0;
}

NDIS_STATUS alloc_chip_cap_dep_data_pci(RTMP_ADAPTER *pAd)
{
	UINT8 num_of_tx_ring = GET_NUM_OF_TX_RING(pAd->chipCap);
	UINT8 num_of_rx_ring = GET_NUM_OF_RX_RING(pAd->chipCap);
	INT index;
	RTMP_DMABUF *pTxBufSpace = NULL;
	RTMP_DMABUF *pTxDescRing = NULL;
	RTMP_TX_RING *pTxRing = NULL;
	RTMP_DMABUF *pRxDescRing = NULL;
	RTMP_RX_RING *pRxRing = NULL;
	NDIS_SPIN_LOCK *pTxRingLock = NULL;
	NDIS_SPIN_LOCK *pRxRingLock = NULL;
	
	/* allocate pci hif data structure which depends on ChipCap */
	os_alloc_mem(pAd, (UCHAR **)&pTxBufSpace, (num_of_tx_ring)*sizeof(RTMP_DMABUF));

	if (pTxBufSpace == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pTxBufSpace, (num_of_tx_ring)*sizeof(RTMP_DMABUF));
	pAd->PciHif.TxBufSpace = pTxBufSpace;
	
	os_alloc_mem(pAd, (UCHAR **)&pTxDescRing, (num_of_tx_ring)*sizeof(RTMP_DMABUF));

	if (pTxDescRing == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pTxDescRing, (num_of_tx_ring)*sizeof(RTMP_DMABUF));
	pAd->PciHif.TxDescRing = pTxDescRing;
	
	os_alloc_mem(pAd, (UCHAR **)&pTxRing, (num_of_tx_ring)*sizeof(RTMP_TX_RING));

	if (pTxRing == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pTxRing, (num_of_tx_ring)*sizeof(RTMP_TX_RING));
	pAd->PciHif.TxRing = pTxRing;
	
	os_alloc_mem(pAd, (UCHAR **)&pRxDescRing, (num_of_rx_ring)*sizeof(RTMP_DMABUF));

	if (pRxDescRing == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pRxDescRing, (num_of_rx_ring)*sizeof(RTMP_DMABUF));
	pAd->PciHif.RxDescRing = pRxDescRing;
	
	os_alloc_mem(pAd, (UCHAR **)&pRxRing, (num_of_rx_ring)*sizeof(RTMP_RX_RING));

	if (pRxRing == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pRxRing, (num_of_rx_ring)*sizeof(RTMP_RX_RING));
	pAd->PciHif.RxRing = pRxRing;
	
	os_alloc_mem(pAd, (UCHAR **)&pTxRingLock, (num_of_tx_ring)*sizeof(NDIS_SPIN_LOCK));

	if (pTxRingLock == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pTxRingLock, (num_of_tx_ring)*sizeof(NDIS_SPIN_LOCK));
	pAd->PciHif.TxRingLock = pTxRingLock;
	
	os_alloc_mem(pAd, (UCHAR **)&pRxRingLock, (num_of_rx_ring)*sizeof(NDIS_SPIN_LOCK));

	if (pRxRingLock == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pRxRingLock, (num_of_rx_ring)*sizeof(NDIS_SPIN_LOCK));
	pAd->PciHif.RxRingLock = pRxRingLock;

	/* spinlock is allocated after data structure is ready */
	for (index = 0; index < num_of_tx_ring; index++)
		NdisAllocateSpinLock(pAd, &pAd->PciHif.TxRingLock[index]);

	for (index = 0; index < num_of_rx_ring; index++)
		NdisAllocateSpinLock(pAd, &pAd->PciHif.RxRingLock[index]);

	return NDIS_STATUS_SUCCESS;
}

VOID free_chip_cap_dep_data_pci(RTMP_ADAPTER *pAd)
{
	UINT8 num_of_tx_ring = GET_NUM_OF_TX_RING(pAd->chipCap);
	UINT8 num_of_rx_ring = GET_NUM_OF_RX_RING(pAd->chipCap);
	INT index;

	/* free pci hif data structure which depends on ChipCap */

	/* spinlock must be freed before its data structure is freed */
	for (index = 0; index < num_of_tx_ring; index++)
		NdisFreeSpinLock(&pAd->PciHif.TxRingLock[index]);

	for (index = 0; index < num_of_rx_ring; index++)
		NdisFreeSpinLock(&pAd->PciHif.RxRingLock[index]);

	os_free_mem(pAd->PciHif.TxBufSpace);
	os_free_mem(pAd->PciHif.TxDescRing);
	os_free_mem(pAd->PciHif.TxRing);
	os_free_mem(pAd->PciHif.RxDescRing);
	os_free_mem(pAd->PciHif.RxRing);
	os_free_mem(pAd->PciHif.TxRingLock);
	os_free_mem(pAd->PciHif.RxRingLock);
}


#ifdef RESOURCE_PRE_ALLOC
static INT desc_ring_free(RTMP_ADAPTER *pAd, RTMP_DMABUF *pDescRing)
{
	if (pDescRing->AllocVa) {
		RtmpFreeDescBuf(((POS_COOKIE)(pAd->OS_Cookie))->pDev,
						pDescRing->AllocSize,
						pDescRing->AllocVa,
						pDescRing->AllocPa);
	}

	NdisZeroMemory(pDescRing, sizeof(RTMP_DMABUF));
	return TRUE;
}


VOID RTMPResetTxRxRingMemory(RTMP_ADAPTER *pAd)
{
	int index, j;
	RTMP_TX_RING *pTxRing;
	TXD_STRUC *pTxD;
	RTMP_DMACB *dma_cb;
#ifdef RT_BIG_ENDIAN
	TXD_STRUC *pDestTxD;
	UCHAR tx_hw_info[TXD_SIZE];
#endif /* RT_BIG_ENDIAN */
	PNDIS_PACKET pPacket;

	/* Free Tx Ring Packet*/
	for (index = 0; index < GET_NUM_OF_TX_RING(pAd->chipCap); index++) {
		pTxRing = &pAd->PciHif.TxRing[index];

		for (j = 0; j < TX_RING_SIZE; j++) {
			dma_cb = &pTxRing->Cell[j];
#ifdef RT_BIG_ENDIAN
			pDestTxD = (TXD_STRUC *)(dma_cb->AllocVa);
			NdisMoveMemory(&tx_hw_info[0], (UCHAR *)pDestTxD, TXD_SIZE);
			pTxD = (TXD_STRUC *)&tx_hw_info[0];
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#else
			pTxD = (TXD_STRUC *) (dma_cb->AllocVa);
#endif /* RT_BIG_ENDIAN */

			if (dma_cb->DmaBuf.AllocSize > 0)
				PCI_UNMAP_SINGLE(pAd, dma_cb->DmaBuf.AllocPa, dma_cb->DmaBuf.AllocSize, RTMP_PCI_DMA_TODEVICE);

			pPacket = dma_cb->pNdisPacket;

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, dma_cb->PacketPa, GET_OS_PKT_LEN(pPacket), RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_SUCCESS);
			}

			/*Always assign pNdisPacket as NULL after clear*/
			dma_cb->pNdisPacket = NULL;
			pPacket = dma_cb->pNextNdisPacket;

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr1, pTxD->SDLen1, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_SUCCESS);
			}

			/*Always assign pNextNdisPacket as NULL after clear*/
			dma_cb->pNextNdisPacket = NULL;
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
			WriteBackToDescriptor((PUCHAR)pDestTxD, (PUCHAR)pTxD, FALSE, TYPE_TXD);
#endif /* RT_BIG_ENDIAN */
		}
	}

	{
		RTMP_CTRL_RING *pCtrlRing = &pAd->PciHif.CtrlRing;

		HIF_IO_READ32(pAd, pCtrlRing->hw_didx_addr, &pCtrlRing->TxDmaIdx);

		while (pCtrlRing->TxSwFreeIdx != pCtrlRing->TxCpuIdx) {
			if (pCtrlRing->TxSwFreeIdx >= CTL_RING_SIZE) {
				/*should not happen*/
				MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("--> TxSwFreeIdx is out of range! %d\n", pCtrlRing->TxSwFreeIdx));
				break;
			}

#ifdef RT_BIG_ENDIAN
			pDestTxD = (TXD_STRUC *) (pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].AllocVa);
			NdisMoveMemory(&tx_hw_info[0], (UCHAR *)pDestTxD, TXD_SIZE);
			pTxD = (TXD_STRUC *)&tx_hw_info[0];
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#else
			pTxD = (TXD_STRUC *) (pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].AllocVa);
#endif
			pTxD->DMADONE = 0;
			pPacket = pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].pNdisPacket;

			if (pPacket == NULL) {
				INC_RING_INDEX(pCtrlRing->TxSwFreeIdx, CTL_RING_SIZE);
				continue;
			}

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr0, pTxD->SDLen0, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_SUCCESS);
			}

			pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].pNdisPacket = NULL;
			pPacket = pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].pNextNdisPacket;

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr1, pTxD->SDLen1, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_SUCCESS);
			}

			pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].pNextNdisPacket = NULL;
			INC_RING_INDEX(pCtrlRing->TxSwFreeIdx, CTL_RING_SIZE);
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
			WriteBackToDescriptor((PUCHAR)pDestTxD, (PUCHAR)pTxD, TRUE, TYPE_TXD);
#endif
		}
	}

	for (index = 0; index < GET_NUM_OF_RX_RING(pAd->chipCap); index++) {
		UINT16 RxRingSize;
#ifdef CONFIG_WIFI_BUILD_SKB
		UINT skb_data_size = 0;
#endif

		if (index == 0)
			RxRingSize = RX_RING_SIZE;
		else
			RxRingSize = RX1_RING_SIZE;

		for (j = RxRingSize - 1; j >= 0; j--) {
			dma_cb = &pAd->PciHif.RxRing[index].Cell[j];

			if ((dma_cb->DmaBuf.AllocVa) && (dma_cb->pNdisPacket)) {
				PCI_UNMAP_SINGLE(pAd, dma_cb->DmaBuf.AllocPa, dma_cb->DmaBuf.AllocSize, RTMP_PCI_DMA_FROMDEVICE);
#ifdef CONFIG_WIFI_BUILD_SKB
				skb_data_size = SKB_DATA_ALIGN(SKB_BUF_HEADROOM_RSV + dma_cb->DmaBuf.AllocSize) +
						SKB_DATA_ALIGN(SKB_BUF_TAILROOM_RSV);

				if (skb_data_size <= PAGE_SIZE) {
					DEV_FREE_FRAG_BUF(dma_cb->pNdisPacket);
				} else {
					os_free_mem(dma_cb->pNdisPacket);
				}
#else /* CONFIG_WIFI_BUILD_SKB */
				RELEASE_NDIS_PACKET(pAd,
						dma_cb->pNdisPacket,
						NDIS_STATUS_SUCCESS);
#endif /* CONFIG_WIFI_BUILD_SKB */
			}
		}

		NdisZeroMemory(pAd->PciHif.RxRing[index].Cell, RxRingSize * sizeof(RTMP_DMACB));
	}

#ifdef CUT_THROUGH
	if (pAd->PktTokenCb)
		cut_through_deinit((PKT_TOKEN_CB **)&pAd->PktTokenCb);

#endif /* CUT_THROUGH */

	if (pAd->FragFrame.pFragPacket) {
		RELEASE_NDIS_PACKET(pAd, pAd->FragFrame.pFragPacket, NDIS_STATUS_SUCCESS);
		pAd->FragFrame.pFragPacket = NULL;
	}

	NdisFreeSpinLock(&pAd->CmdQLock);
}

VOID RTMPFreeTxRxRingMemory(RTMP_ADAPTER *pAd)
{
	INT num;
	VOID *pdev = ((POS_COOKIE)(pAd->OS_Cookie))->pDev;

	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("--> RTMPFreeTxRxRingMemory\n"));

	for (num = 0; num < GET_NUM_OF_RX_RING(pAd->chipCap); num++)
		desc_ring_free(pAd, &pAd->PciHif.RxDescRing[num]);

	desc_ring_free(pAd, &pAd->PciHif.CtrlDescRing);
	desc_ring_free(pAd, &pAd->PciHif.FwDwloRing.DescRing);

	/* Free 1st TxBufSpace and TxDesc buffer*/
	for (num = 0; num < GET_NUM_OF_TX_RING(pAd->chipCap); num++) {
		if (pAd->PciHif.TxBufSpace[num].AllocVa) {
			RTMP_FreeFirstTxBuffer(pdev,
						pAd->PciHif.TxBufSpace[num].AllocSize,
						FALSE, pAd->PciHif.TxBufSpace[num].AllocVa,
						pAd->PciHif.TxBufSpace[num].AllocPa);
		}

		NdisZeroMemory(&pAd->PciHif.TxBufSpace[num], sizeof(RTMP_DMABUF));
		desc_ring_free(pAd, &pAd->PciHif.TxDescRing[num]);
	}

#ifdef CUT_THROUGH
	if (pAd->PktTokenCb)
		cut_through_deinit((PKT_TOKEN_CB **)&pAd->PktTokenCb);
#endif /* CUT_THROUGH */
	
	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("<-- RTMPFreeTxRxRingMemory\n"));
}


NDIS_STATUS RTMPInitTxRxRingMemory(RTMP_ADAPTER *pAd)
{
	INT num, index;
	ULONG RingBasePaHigh, RingBasePaLow;
	VOID *RingBaseVa;
	RTMP_TX_RING *pTxRing;
	RTMP_RX_RING *pRxRing;
	RTMP_DMABUF *pDmaBuf, *pDescRing;
	RTMP_DMACB *dma_cb;
	PNDIS_PACKET pPacket;
	TXD_STRUC *pTxD;
	RXD_STRUC *pRxD;
	ULONG ErrorValue = 0;
	NDIS_STATUS Status = NDIS_STATUS_SUCCESS;

	/* Initialize All Tx Ring Descriptors and associated buffer memory*/
	for (num = 0; num < GET_NUM_OF_TX_RING(pAd->chipCap); num++) {
		VOID *BufBaseVa;
		/* memory zero the  Tx ring descriptor's memory */
		pDescRing = &pAd->PciHif.TxDescRing[num];
		NdisZeroMemory(pDescRing->AllocVa, pDescRing->AllocSize);
		/* Save PA & VA for further operation*/
		RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pDescRing->AllocPa);
		RingBasePaLow = RTMP_GetPhysicalAddressLow(pDescRing->AllocPa);
		RingBaseVa = pDescRing->AllocVa;
		/* Zero init all 1st TXBuf's memory for this TxRing*/
		NdisZeroMemory(pAd->PciHif.TxBufSpace[num].AllocVa, pAd->PciHif.TxBufSpace[num].AllocSize);
		
		/* Save PA & VA for further operation */
		BufBaseVa = pAd->PciHif.TxBufSpace[num].AllocVa;
		
		/* linking Tx Ring Descriptor and associated buffer memory */
		pTxRing = &pAd->PciHif.TxRing[num];

		for (index = 0; index < TX_RING_SIZE; index++) {
			dma_cb = &pTxRing->Cell[index];
			dma_cb->pNdisPacket = NULL;
			dma_cb->pNextNdisPacket = NULL;
			/* Init Tx Ring Size, Va, Pa variables*/
			dma_cb->AllocSize = TXD_SIZE;
			dma_cb->AllocVa = RingBaseVa;
			RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
			RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
			/* Setup Tx Buffer size & address. only 802.11 header will store in this space */
			pDmaBuf = &dma_cb->DmaBuf;
			pDmaBuf->AllocSize = TX_DMA_1ST_BUFFER_SIZE;
			pDmaBuf->AllocVa = BufBaseVa;
			/* link the pre-allocated TxBuf to TXD */
			pTxD = (TXD_STRUC *)dma_cb->AllocVa;
#if (CFG_CPU_LOADING_DMADONE == 1)
			pTxD->DMADONE = 0;
#else
			/* advance to next ring descriptor address */
			pTxD->DMADONE = 1;
#endif
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#endif
			/* flush dcache if no consistent memory is supported */
			RTMP_DCACHE_FLUSH(pTxD, dma_cb->AllocSize);
			RingBasePaLow += TXD_SIZE;
			RingBaseVa = (PUCHAR)RingBaseVa + TXD_SIZE;
			/* advance to next TxBuf address */
			BufBaseVa = (PUCHAR)BufBaseVa + TX_DMA_1ST_BUFFER_SIZE;
		}

		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("TxRing[%d]: total %d entry initialized\n", num, index));
	}

	/* Initialize CTRL Ring and associated buffer memory */
	pDescRing = &pAd->PciHif.CtrlDescRing;
	RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pDescRing->AllocPa);
	RingBasePaLow = RTMP_GetPhysicalAddressLow(pDescRing->AllocPa);
	RingBaseVa = pDescRing->AllocVa;
	NdisZeroMemory(pDescRing->AllocVa, pDescRing->AllocSize);

	for (index = 0; index < CTL_RING_SIZE; index++) {
		dma_cb = &pAd->PciHif.CtrlRing.Cell[index];
		dma_cb->pNdisPacket = NULL;
		dma_cb->pNextNdisPacket = NULL;
		/* Init Ctrl Ring Size, Va, Pa variables */
		dma_cb->AllocSize = TXD_SIZE;
		dma_cb->AllocVa = RingBaseVa;
		RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
		RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
		/* Offset to next ring descriptor address */
		RingBasePaLow += TXD_SIZE;
		RingBaseVa = (PUCHAR) RingBaseVa + TXD_SIZE;
		/* link the pre-allocated TxBuf to TXD */
		pTxD = (TXD_STRUC *)dma_cb->AllocVa;
		pTxD->DMADONE = 1;
#ifdef RT_BIG_ENDIAN
		RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#endif
		/* flush dcache if no consistent memory is supported */
		RTMP_DCACHE_FLUSH(pTxD, dma_cb->AllocSize);
		/* no pre-allocated buffer required in CtrlRing for scatter-gather case */
	}

	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("CtrlRing: total %d entry initialized\n", index));
		
	/* Initialize firmware download Ring */
	pDescRing = &pAd->PciHif.FwDwloRing.DescRing;
	RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pDescRing->AllocPa);
	RingBasePaLow = RTMP_GetPhysicalAddressLow(pDescRing->AllocPa);
	RingBaseVa = pDescRing->AllocVa;
	NdisZeroMemory(pDescRing->AllocVa, pDescRing->AllocSize);

	for (index = 0; index < CTL_RING_SIZE; index++) {
		dma_cb = &pAd->PciHif.FwDwloRing.Cell[index];
		dma_cb->pNdisPacket = NULL;
		dma_cb->pNextNdisPacket = NULL;
		
		/* Init firmware download ring Size, Va, Pa variables */
		dma_cb->AllocSize = TXD_SIZE;
		dma_cb->AllocVa = RingBaseVa;
		RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
		RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
		/* Offset to next ring descriptor address */
		RingBasePaLow += TXD_SIZE;
		RingBaseVa = (PUCHAR)RingBaseVa + TXD_SIZE;
		/* link the pre-allocated TxBuf to TXD */
		pTxD = (TXD_STRUC *)dma_cb->AllocVa;
		pTxD->DMADONE = 1;
#ifdef RT_BIG_ENDIAN
		RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#endif
		/* flush dcache if no consistent memory is supported */
		RTMP_DCACHE_FLUSH(pTxD, dma_cb->AllocSize);
		/* no pre-allocated buffer required in FwDwloRing for scatter-gather case */
	}

	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("FwDwloRing: total %d entry initialized\n", index));

#ifdef CUT_THROUGH
	if (!pAd->PktTokenCb)
		cut_through_init(&pAd->PktTokenCb, pAd);
#endif /* CUT_THROUGH */

	/* Initialize Rx Ring and associated buffer memory */
	for (num = 0; num < GET_NUM_OF_RX_RING(pAd->chipCap); num++) {
		UINT16 RxRingSize;
		UINT16 RxBufferSize;

		pDescRing = &pAd->PciHif.RxDescRing[num];
		pRxRing = &pAd->PciHif.RxRing[num];
		NdisZeroMemory(pDescRing->AllocVa, pDescRing->AllocSize);
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF,  ("RX[%d] DESC %p size = %lu\n",
				 num, pDescRing->AllocVa, pDescRing->AllocSize));
		/* Save PA & VA for further operation */
		RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pDescRing->AllocPa);
		RingBasePaLow = RTMP_GetPhysicalAddressLow(pDescRing->AllocPa);
		RingBaseVa = pDescRing->AllocVa;

		if (num == 0) {
			RxRingSize = RX_RING_SIZE;
			RxBufferSize = RX_BUFFER_AGGRESIZE;
		} else {
			RxRingSize = RX1_RING_SIZE;
			RxBufferSize = RX1_BUFFER_SIZE;
		}

		/* Linking Rx Ring and associated buffer memory */
		for (index = 0; index < RxRingSize; index++) {
			dma_cb = &pRxRing->Cell[index];
			/* Init RX Ring Size, Va, Pa variables*/
			dma_cb->AllocSize = RXD_SIZE;
			dma_cb->AllocVa = RingBaseVa;
			RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
			RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
			/* Offset to next ring descriptor address */
			RingBasePaLow += RXD_SIZE;
			RingBaseVa = (PUCHAR)RingBaseVa + RXD_SIZE;
			/* Setup Rx associated Buffer size & allocate share memory */
			pDmaBuf = &dma_cb->DmaBuf;
#ifdef CUT_THROUGH

			if (CUT_THROUGH_RX_ENABL(pAd->PktTokenCb))
				pDmaBuf->AllocSize = RxBufferSize + sizeof(RX_BLK);
			else
#endif /* CUT_THROUGH */
				pDmaBuf->AllocSize = RxBufferSize;

			pPacket = RTMP_AllocateRxPacketBuffer(
				  pAd,
				  ((POS_COOKIE)(pAd->OS_Cookie))->pDev,
				  pDmaBuf->AllocSize,
				  FALSE,
				  &pDmaBuf->AllocVa,
				  &pDmaBuf->AllocPa);
			/* keep allocated rx packet */
			dma_cb->pNdisPacket = pPacket;

			/* Error handling*/
			if (pDmaBuf->AllocVa == NULL) {
				ErrorValue = ERRLOG_OUT_OF_SHARED_MEMORY;
				MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_ERROR, ("Failed to allocate RxRing's 1st buffer\n"));
				Status = NDIS_STATUS_RESOURCES;
				break;
			}

#ifdef CUT_THROUGH

			if (CUT_THROUGH_RX_ENABL(pAd->PktTokenCb) && (num == 0)) {
				pDmaBuf->AllocVa += sizeof(RX_BLK);
				pDmaBuf->AllocPa += sizeof(RX_BLK);
				OS_PKT_RESERVE(pPacket, sizeof(RX_BLK));
			}

			/* Only Rx Ring 0 need token! */
			if (CUT_THROUGH_RX_ENABL(pAd->PktTokenCb) && (num == 0))
				dma_cb->token_id = cut_through_rx_enq(pAd->PktTokenCb, pPacket, TOKEN_RX);

#endif /* CUT_THROUGH */
			/* Write RxD buffer address & allocated buffer length */
			pRxD = (RXD_STRUC *)dma_cb->AllocVa;
			pRxD->SDP0 = RTMP_GetPhysicalAddressLow(pDmaBuf->AllocPa);
			pRxD->DDONE = 0;
			pRxD->SDL0 = RxBufferSize;
#ifdef CUT_THROUGH

			if (CUT_THROUGH_RX_ENABL(pAd->PktTokenCb) && (num == 0))
				pRxD->SDP1 = cpu2le32((((UINT32)dma_cb->token_id) & 0x0000ffff));

#endif /* CUT_THROUGH */
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pRxD, TYPE_RXD);
#endif
			/* flush dcache if no consistent memory is supported */
			RTMP_DCACHE_FLUSH(pRxD, dma_cb->AllocSize);
		}
	}

	NdisZeroMemory(&pAd->FragFrame, sizeof(FRAGMENT_FRAME));
	pAd->FragFrame.pFragPacket = RTMP_AllocateFragPacketBuffer(pAd, RX_BUFFER_NORMSIZE);

	if (pAd->FragFrame.pFragPacket == NULL)
		Status = NDIS_STATUS_RESOURCES;

	for (index = 0; index < GET_NUM_OF_TX_RING(pAd->chipCap); index++) {
		/* Init TX rings index pointer */
		pAd->PciHif.TxRing[index].TxSwFreeIdx = 0;
		pAd->PciHif.TxRing[index].TxCpuIdx = 0;
	}

	/* Init RX Ring index pointer */
	for (index = 0; index < GET_NUM_OF_RX_RING(pAd->chipCap); index++) {
		UINT16 RxRingSize;
		UINT16 RxBufferSize;
		UINT16 max_rx_process_cnt;

		if (index == HIF_RX_IDX0) {
			RxRingSize = RX_RING_SIZE;
			RxBufferSize = RX_BUFFER_AGGRESIZE;
			max_rx_process_cnt = MAX_RX_PROCESS_CNT;
		} else {
			RxRingSize = RX1_RING_SIZE;
			RxBufferSize = RX1_BUFFER_SIZE;
			max_rx_process_cnt = MAX_RX1_PROCESS_CNT;
		}

		pAd->PciHif.RxRing[index].RxSwReadIdx = 0;
		pAd->PciHif.RxRing[index].RxCpuIdx = RxRingSize - 1;
		pAd->PciHif.RxRing[index].RxRingSize = RxRingSize;
		pAd->PciHif.RxRing[index].RxBufferSize = RxBufferSize;
		pAd->PciHif.RxRing[index].max_rx_process_cnt = max_rx_process_cnt;
	}

#ifdef CONFIG_ANDES_SUPPORT
	/* init CTRL ring index pointer */
	pAd->PciHif.CtrlRing.TxSwFreeIdx = 0;
	pAd->PciHif.CtrlRing.TxCpuIdx = 0;
#endif /* CONFIG_ANDES_SUPPORT */
	pAd->PrivateInfo.TxRingFullCnt = 0;
	return Status;
}

NDIS_STATUS RTMPAllocTxRxRingMemory(RTMP_ADAPTER *pAd)
{
	NDIS_STATUS Status = NDIS_STATUS_SUCCESS;
	INT num;
	ULONG ErrorValue = 0;
	VOID *pdev = ((POS_COOKIE)(pAd->OS_Cookie))->pDev;

	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("-->RTMPAllocTxRxRingMemory\n"));

	do {
		for (num = 0; num < GET_NUM_OF_TX_RING(pAd->chipCap); num++) {
			/* Allocate Tx ring descriptor's memory (5 TX rings = 4 ACs + 1 HCCA)*/
			desc_ring_alloc(pAd, &pAd->PciHif.TxDescRing[num], TX_RING_SIZE * TXD_SIZE);

			if (pAd->PciHif.TxDescRing[num].AllocVa == NULL) {
				Status = NDIS_STATUS_RESOURCES;
				break;
			}

			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("TxRing[%d]: total %d bytes allocated\n",
					 num, (INT)pAd->PciHif.TxDescRing[num].AllocSize));
			/* Allocate all 1st TXBuf's memory for this TxRing */
			pAd->PciHif.TxBufSpace[num].AllocSize = TX_RING_SIZE * TX_DMA_1ST_BUFFER_SIZE;
			RTMP_AllocateFirstTxBuffer(
				pdev,
				num,
				pAd->PciHif.TxBufSpace[num].AllocSize,
				FALSE,
				&pAd->PciHif.TxBufSpace[num].AllocVa,
				&pAd->PciHif.TxBufSpace[num].AllocPa);

			if (pAd->PciHif.TxBufSpace[num].AllocVa == NULL) {
				ErrorValue = ERRLOG_OUT_OF_SHARED_MEMORY;
				MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_ERROR, ("Failed to allocate a big buffer\n"));
				Status = NDIS_STATUS_RESOURCES;
				break;
			}
		}

		if (Status == NDIS_STATUS_RESOURCES)
			break;

		/* Alloc CTRL ring desc buffer except Tx ring allocated eariler */
		desc_ring_alloc(pAd, &pAd->PciHif.CtrlDescRing, CTL_RING_SIZE * TXD_SIZE);

		if (pAd->PciHif.CtrlDescRing.AllocVa == NULL) {
			Status = NDIS_STATUS_RESOURCES;
			break;
		}

		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE,
				 ("CTRL Ring: total %d bytes allocated\n",
				  (INT)pAd->PciHif.CtrlDescRing.AllocSize));
			
		/* Alloc firmware download ring desc buffer except Tx ring allocated eariler */
		desc_ring_alloc(pAd, &pAd->PciHif.FwDwloRing.DescRing, pAd->PciHif.FwDwloRing.ring_size * TXD_SIZE);

		if (pAd->PciHif.FwDwloRing.DescRing.AllocVa == NULL) {
			Status = NDIS_STATUS_RESOURCES;
			break;
		}

		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE,
				("FwDwlo Ring: total %d bytes allocated\n",
				(INT)pAd->PciHif.FwDwloRing.DescRing.AllocSize));

#ifdef CUT_THROUGH
		cut_through_init(&pAd->PktTokenCb, pAd);
#endif /* CUT_THROUGH */

		/* Alloc RX ring desc memory except Tx ring allocated eariler */
		for (num = 0; num < GET_NUM_OF_RX_RING(pAd->chipCap); num++) {
			UINT16 RxRingSize;

			if (num == 0)
				RxRingSize = RX_RING_SIZE;
			else
				RxRingSize = RX1_RING_SIZE;

			desc_ring_alloc(pAd, &pAd->PciHif.RxDescRing[num],
							RxRingSize * RXD_SIZE);

			if (pAd->PciHif.RxDescRing[num].AllocVa == NULL) {
				Status = NDIS_STATUS_RESOURCES;
				break;
			}

			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("Rx[%d] Ring: total %d bytes allocated\n",
					 num, (INT)pAd->PciHif.RxDescRing[num].AllocSize));
		}
	} while (FALSE);

	if (Status != NDIS_STATUS_SUCCESS) {
		/* Log error inforamtion*/
		NdisWriteErrorLogEntry(
			pAd->AdapterHandle,
			NDIS_ERROR_CODE_OUT_OF_RESOURCES,
			1,
			ErrorValue);
	}

	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF,
			 ("<-- RTMPAllocTxRxRingMemory, Status=%x\n", Status));
	return Status;
}

#else
/*
	========================================================================

	Routine Description:
		Allocate DMA memory blocks for send, receive

	Arguments:
		Adapter		Pointer to our adapter

	Return Value:
		NDIS_STATUS_SUCCESS
		NDIS_STATUS_FAILURE
		NDIS_STATUS_RESOURCES

	IRQL = PASSIVE_LEVEL

	Note:

	========================================================================
*/
NDIS_STATUS	RTMPAllocTxRxRingMemory(RTMP_ADAPTER *pAd)
{
	NDIS_STATUS Status = NDIS_STATUS_SUCCESS;
	ULONG RingBasePaHigh, RingBasePaLow;
	PVOID RingBaseVa;
	INT index, num;
	TXD_STRUC *pTxD;
	RXD_STRUC *pRxD;
	ULONG ErrorValue = 0;
	RTMP_TX_RING *pTxRing;
	RTMP_DMABUF *pDmaBuf;
	RTMP_DMACB *dma_cb;
	PNDIS_PACKET pPacket;

	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("--> RTMPAllocTxRxRingMemory\n"));
	/* Init the CmdQ and CmdQLock*/
	NdisAllocateSpinLock(pAd, &pAd->CmdQLock);
#if 0 /* Move to RtmpMgmtTaskInit in rt_rbus_pci_drv.c */
	NdisAcquireSpinLock(&pAd->CmdQLock);
	RTInitializeCmdQ(&pAd->CmdQ);
	NdisReleaseSpinLock(&pAd->CmdQLock);
#endif

	do {
		/*
			Allocate all ring descriptors, include TxD, RxD, MgmtD.
			Although each size is different, to prevent cacheline and alignment
			issue, I intentional set them all to 64 bytes
		*/
		for (num = 0; num < GET_NUM_OF_TX_RING(pAd->chipCap); num++) {
			ULONG  BufBasePaHigh;
			ULONG  BufBasePaLow;
			PVOID  BufBaseVa;
			/*
				Allocate Tx ring descriptor's memory (5 TX rings = 4 ACs + 1 HCCA)
			*/
			desc_ring_alloc(pAd, &pAd->PciHif.TxDescRing[num], TX_RING_SIZE * TXD_SIZE);

			if (pAd->PciHif.TxDescRing[num].AllocVa == NULL) {
				Status = NDIS_STATUS_RESOURCES;
				break;
			}

			pDmaBuf = &pAd->PciHif.TxDescRing[num];
			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("TxDescRing[%p]: total %d bytes allocated\n",
					 pDmaBuf->AllocVa, (INT)pDmaBuf->AllocSize));
			/* Save PA & VA for further operation*/
			RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pDmaBuf->AllocPa);
			RingBasePaLow = RTMP_GetPhysicalAddressLow(pDmaBuf->AllocPa);
			RingBaseVa = pDmaBuf->AllocVa;
			/*
				Allocate all 1st TXBuf's memory for this TxRing
			*/
			pAd->PciHif.TxBufSpace[num].AllocSize = TX_RING_SIZE * TX_DMA_1ST_BUFFER_SIZE;
			RTMP_AllocateFirstTxBuffer(
				((POS_COOKIE)(pAd->OS_Cookie))->pDev,
				num,
				pAd->PciHif.TxBufSpace[num].AllocSize,
				FALSE,
				&pAd->PciHif.TxBufSpace[num].AllocVa,
				&pAd->PciHif.TxBufSpace[num].AllocPa);

			if (pAd->PciHif.TxBufSpace[num].AllocVa == NULL) {
				ErrorValue = ERRLOG_OUT_OF_SHARED_MEMORY;
				MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_ERROR, ("Failed to allocate a big buffer\n"));
				Status = NDIS_STATUS_RESOURCES;
				break;
			}

			/* Zero init this memory block*/
			NdisZeroMemory(pAd->PciHif.TxBufSpace[num].AllocVa, pAd->PciHif.TxBufSpace[num].AllocSize);
			/* Save PA & VA for further operation*/
			BufBasePaHigh = RTMP_GetPhysicalAddressHigh(pAd->PciHif.TxBufSpace[num].AllocPa);
			BufBasePaLow = RTMP_GetPhysicalAddressLow(pAd->PciHif.TxBufSpace[num].AllocPa);
			BufBaseVa = pAd->PciHif.TxBufSpace[num].AllocVa;
			/*
				Initialize Tx Ring Descriptor and associated buffer memory
			*/
			pTxRing = &pAd->PciHif.TxRing[num];

			for (index = 0; index < TX_RING_SIZE; index++) {
				dma_cb = &pTxRing->Cell[index];
				dma_cb->pNdisPacket = NULL;
				dma_cb->pNextNdisPacket = NULL;
				/* Init Tx Ring Size, Va, Pa variables */
				dma_cb->AllocSize = TXD_SIZE;
				dma_cb->AllocVa = RingBaseVa;
				RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
				RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
				/* Setup Tx Buffer size & address. only 802.11 header will store in this space*/
				pDmaBuf = &dma_cb->DmaBuf;
				pDmaBuf->AllocSize = TX_DMA_1ST_BUFFER_SIZE;
				pDmaBuf->AllocVa = BufBaseVa;
				RTMP_SetPhysicalAddressHigh(pDmaBuf->AllocPa, BufBasePaHigh);
				RTMP_SetPhysicalAddressLow(pDmaBuf->AllocPa, BufBasePaLow);
				/* link the pre-allocated TxBuf to TXD */
				pTxD = (TXD_STRUC *)dma_cb->AllocVa;
				pTxD->SDPtr0 = BufBasePaLow;
#if (CFG_CPU_LOADING_DMADONE == 1)
				pTxD->DMADONE = 0;
#else
				/* advance to next ring descriptor address */
				pTxD->DMADONE = 1;
#endif
#ifdef RT_BIG_ENDIAN
				RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#endif
				/* flush dcache if no consistent memory is supported */
				RTMP_DCACHE_FLUSH(pTxD, dma_cb->AllocSize);
				RingBasePaLow += TXD_SIZE;
				RingBaseVa = (PUCHAR) RingBaseVa + TXD_SIZE;
				/* advance to next TxBuf address */
				BufBasePaLow += TX_DMA_1ST_BUFFER_SIZE;
				BufBaseVa = (PUCHAR) BufBaseVa + TX_DMA_1ST_BUFFER_SIZE;
			}

			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("TxRing[%d]: total %d entry allocated\n", num, index));
		}

		if (Status == NDIS_STATUS_RESOURCES)
			break;

		/*
			Allocate MGMT ring descriptor's memory except Tx ring which allocated eariler
		*/
		desc_ring_alloc(pAd, &pAd->PciHif.MgmtDescRing, MGMT_RING_SIZE * TXD_SIZE);

		if (pAd->PciHif.MgmtDescRing.AllocVa == NULL) {
			Status = NDIS_STATUS_RESOURCES;
			break;
		}

		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("MgmtDescRing[%p]: total %d bytes allocated\n",
				 pAd->PciHif.MgmtDescRing.AllocVa, (INT)pAd->PciHif.MgmtDescRing.AllocSize));
		/* Save PA & VA for further operation*/
		RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pAd->PciHif.MgmtDescRing.AllocPa);
		RingBasePaLow = RTMP_GetPhysicalAddressLow(pAd->PciHif.MgmtDescRing.AllocPa);
		RingBaseVa = pAd->PciHif.MgmtDescRing.AllocVa;

		/*
			Initialize MGMT Ring and associated buffer memory
		*/
		for (index = 0; index < MGMT_RING_SIZE; index++) {
			dma_cb = &pAd->PciHif.MgmtRing.Cell[index];
			dma_cb->pNdisPacket = NULL;
			dma_cb->pNextNdisPacket = NULL;
			/* Init MGMT Ring Size, Va, Pa variables*/
			dma_cb->AllocSize = TXD_SIZE;
			dma_cb->AllocVa = RingBaseVa;
			RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
			RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
			/* Offset to next ring descriptor address*/
			RingBasePaLow += TXD_SIZE;
			RingBaseVa = (PUCHAR)RingBaseVa + TXD_SIZE;
			/* link the pre-allocated TxBuf to TXD*/
			pTxD = (TXD_STRUC *)dma_cb->AllocVa;
			pTxD->DMADONE = 1;
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#endif
			/* flush dcache if no consistent memory is supported */
			RTMP_DCACHE_FLUSH(pTxD, dma_cb->AllocSize);
			/* no pre-allocated buffer required in MgmtRing for scatter-gather case*/
		}

		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("MGMT Ring: total %d entry allocated\n", index));
#ifdef CONFIG_ANDES_SUPPORT
		/*
			Allocate CTRL ring descriptor's memory except Tx ring which allocated eariler
		*/
		desc_ring_alloc(pAd, &pAd->PciHif.CtrlDescRing, CTL_RING_SIZE * TXD_SIZE);

		if (pAd->PciHif.CtrlDescRing.AllocVa == NULL) {
			Status = NDIS_STATUS_RESOURCES;
			break;
		}

		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("CtrlDescRing[%p]: total %d bytes allocated\n",
				 pAd->PciHif.CtrlDescRing.AllocVa, (INT)pAd->PciHif.CtrlDescRing.AllocSize));
		/* Save PA & VA for further operation*/
		RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pAd->PciHif.CtrlDescRing.AllocPa);
		RingBasePaLow = RTMP_GetPhysicalAddressLow(pAd->PciHif.CtrlDescRing.AllocPa);
		RingBaseVa = pAd->PciHif.CtrlDescRing.AllocVa;

		/*
			Initialize CTRL Ring and associated buffer memory
		*/
		for (index = 0; index < CTL_RING_SIZE; index++) {
			dma_cb = &pAd->PciHif.CtrlRing.Cell[index];
			dma_cb->pNdisPacket = NULL;
			dma_cb->pNextNdisPacket = NULL;
			/* Init CTRL Ring Size, Va, Pa variables*/
			dma_cb->AllocSize = TXD_SIZE;
			dma_cb->AllocVa = RingBaseVa;
			RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
			RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
			/* Offset to next ring descriptor address*/
			RingBasePaLow += TXD_SIZE;
			RingBaseVa = (PUCHAR) RingBaseVa + TXD_SIZE;
			/* link the pre-allocated TxBuf to TXD*/
			pTxD = (TXD_STRUC *)dma_cb->AllocVa;
			pTxD->DMADONE = 1;
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#endif
			/* flush dcache if no consistent memory is supported */
			RTMP_DCACHE_FLUSH(pTxD, dma_cb->AllocSize);
			/* no pre-allocated buffer required in CtrlRing for scatter-gather case*/
		}

		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("CTRL Ring: total %d entry allocated\n", index));
#if defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663)

		if (IS_MT7615(pAd) || IS_MT7622(pAd) || IS_P18(pAd) || IS_MT7663(pAd)) {
			/*
				Allocate firmware download ring descriptor's memory except Tx ring which allocated eariler
			*/
			desc_ring_alloc(pAd, &pAd->PciHif.FwDwloRing.DescRing, pAd->PciHif.FwDwloRing.ring_size * TXD_SIZE);

			if (pAd->PciHif.FwDwloRing.DescRing.AllocVa == NULL) {
				Status = NDIS_STATUS_RESOURCES;
				break;
			}

			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("FwDwloRing.DescRing[%p]: total %d bytes allocated\n",
					 pAd->PciHif.FwDwloRing.DescRing.AllocVa, (INT)pAd->PciHif.FwDwloRing.DescRing.AllocSize));
			/* Save PA & VA for further operation*/
			RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pAd->PciHif.FwDwloRing.DescRing.AllocPa);
			RingBasePaLow = RTMP_GetPhysicalAddressLow(pAd->PciHif.FwDwloRing.DescRing.AllocPa);
			RingBaseVa = pAd->PciHif.FwDwloRing.DescRing.AllocVa;

			/*
				Initialize firmware download ring and associated buffer memory
			*/
			for (index = 0; index < CTL_RING_SIZE; index++) {
				dma_cb = &pAd->PciHif.FwDwloRing.Cell[index];
				dma_cb->pNdisPacket = NULL;
				dma_cb->pNextNdisPacket = NULL;
				/* Init firmware download Ring Size, Va, Pa variables*/
				dma_cb->AllocSize = TXD_SIZE;
				dma_cb->AllocVa = RingBaseVa;
				RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
				RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
				/* Offset to next ring descriptor address*/
				RingBasePaLow += TXD_SIZE;
				RingBaseVa = (PUCHAR) RingBaseVa + TXD_SIZE;
				/* link the pre-allocated TxBuf to TXD*/
				pTxD = (TXD_STRUC *)dma_cb->AllocVa;
				pTxD->DMADONE = 1;
#ifdef RT_BIG_ENDIAN
				RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#endif
				/* flush dcache if no consistent memory is supported */
				RTMP_DCACHE_FLUSH(pTxD, dma_cb->AllocSize);
				/* no pre-allocated buffer required in CtrlRing for scatter-gather case*/
			}

			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("FwDwlo Ring: total %d entry allocated\n", index));
		}

#endif /* defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663) */
#endif /* CONFIG_ANDES_SUPPORT */
#ifdef MT_MAC
#if defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663)

		if (IS_MT7615(pAd) || IS_MT7622(pAd) || IS_P18(pAd) || IS_MT7663(pAd)) {
			/* TODO: shiang-MT7615, we don't need bcn ring now! */
		} else
#endif /* defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663) */
			if (1/* pAd->chipCap.hif_type == HIF_MT */) {
				/* Allocate Beacon ring descriptor's memory */
				ULONG  BufBasePaHigh;
				ULONG  BufBasePaLow;
				PVOID  BufBaseVa;

				desc_ring_alloc(pAd, &pAd->PciHif.BcnDescRing, BCN_RING_SIZE * TXD_SIZE);

				if (pAd->PciHif.BcnDescRing.AllocVa == NULL) {
					Status = NDIS_STATUS_RESOURCES;
					break;
				}

				MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("BcnDescRing[%p]: total %d bytes allocated\n",
						 pAd->PciHif.BcnDescRing.AllocVa, (INT)pAd->PciHif.BcnDescRing.AllocSize));
				/* Save PA & VA for further operation*/
				RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pAd->PciHif.BcnDescRing.AllocPa);
				RingBasePaLow = RTMP_GetPhysicalAddressLow(pAd->PciHif.BcnDescRing.AllocPa);
				RingBaseVa = pAd->PciHif.BcnDescRing.AllocVa;

				/* Initialize Beacon Ring and associated buffer memory */
				for (index = 0; index < BCN_RING_SIZE; index++) {
					dma_cb = &pAd->PciHif.BcnRing.Cell[index];
					dma_cb->pNdisPacket = NULL;
					dma_cb->pNextNdisPacket = NULL;
					/* Init CTRL Ring Size, Va, Pa variables*/
					dma_cb->AllocSize = TXD_SIZE;
					dma_cb->AllocVa = RingBaseVa;
					RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
					RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
					/* Offset to next ring descriptor address*/
					RingBasePaLow += TXD_SIZE;
					RingBaseVa = (PUCHAR) RingBaseVa + TXD_SIZE;
					/* link the pre-allocated TxBuf to TXD*/
					pTxD = (TXD_STRUC *)dma_cb->AllocVa;
					pTxD->DMADONE = 1;
#ifdef RT_BIG_ENDIAN
					RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#endif
					/* flush dcache if no consistent memory is supported */
					RTMP_DCACHE_FLUSH(pTxD, dma_cb->AllocSize);
					/* no pre-allocated buffer required in CtrlRing for scatter-gather case*/
				}

				MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("Bcn Ring: total %d entry allocated\n", index));
				/*
					Allocate Tx ring descriptor's memory (BMC)
				*/
				desc_ring_alloc(pAd, &pAd->PciHif.TxBmcDescRing, TX_RING_SIZE * TXD_SIZE);

				if (pAd->PciHif.TxBmcDescRing.AllocVa == NULL) {
					Status = NDIS_STATUS_RESOURCES;
					break;
				}

				pDmaBuf = &pAd->PciHif.TxBmcDescRing;
				MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("TxBmcDescRing[%p]: total %d bytes allocated\n",
						 pDmaBuf->AllocVa, (INT)pDmaBuf->AllocSize));
				/* Save PA & VA for further operation*/
				RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pDmaBuf->AllocPa);
				RingBasePaLow = RTMP_GetPhysicalAddressLow(pDmaBuf->AllocPa);
				RingBaseVa = pDmaBuf->AllocVa;
				/*
					Allocate all 1st TXBuf's memory for this TxRing
				*/
				pAd->PciHif.TxBmcBufSpace.AllocSize = TX_RING_SIZE * TX_DMA_1ST_BUFFER_SIZE;
				RTMP_AllocateFirstTxBuffer(
					((POS_COOKIE)(pAd->OS_Cookie))->pDev,
					0,
					pAd->PciHif.TxBmcBufSpace.AllocSize,
					FALSE,
					&pAd->PciHif.TxBmcBufSpace.AllocVa,
					&pAd->PciHif.TxBmcBufSpace.AllocPa);

				if (pAd->PciHif.TxBmcBufSpace.AllocVa == NULL) {
					ErrorValue = ERRLOG_OUT_OF_SHARED_MEMORY;
					MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_ERROR, ("Failed to allocate a big buffer\n"));
					Status = NDIS_STATUS_RESOURCES;
					break;
				}

				/* Zero init this memory block*/
				NdisZeroMemory(pAd->PciHif.TxBmcBufSpace.AllocVa, pAd->PciHif.TxBmcBufSpace.AllocSize);
				/* Save PA & VA for further operation*/
				BufBasePaHigh = RTMP_GetPhysicalAddressHigh(pAd->PciHif.TxBmcBufSpace.AllocPa);
				BufBasePaLow = RTMP_GetPhysicalAddressLow(pAd->PciHif.TxBmcBufSpace.AllocPa);
				BufBaseVa = pAd->PciHif.TxBmcBufSpace.AllocVa;
				/*
					Initialize Tx Ring Descriptor and associated buffer memory
				*/
				pTxRing = &pAd->PciHif.TxBmcRing;

				for (index = 0; index < TX_RING_SIZE; index++) {
					dma_cb = &pTxRing->Cell[index];
					dma_cb->pNdisPacket = NULL;
					dma_cb->pNextNdisPacket = NULL;
					/* Init Tx Ring Size, Va, Pa variables */
					dma_cb->AllocSize = TXD_SIZE;
					dma_cb->AllocVa = RingBaseVa;
					RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
					RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
					/* Setup Tx Buffer size & address. only 802.11 header will store in this space*/
					pDmaBuf = &dma_cb->DmaBuf;
					pDmaBuf->AllocSize = TX_DMA_1ST_BUFFER_SIZE;
					pDmaBuf->AllocVa = BufBaseVa;
					RTMP_SetPhysicalAddressHigh(pDmaBuf->AllocPa, BufBasePaHigh);
					RTMP_SetPhysicalAddressLow(pDmaBuf->AllocPa, BufBasePaLow);
					/* link the pre-allocated TxBuf to TXD */
					pTxD = (TXD_STRUC *)dma_cb->AllocVa;
					pTxD->SDPtr0 = BufBasePaLow;
#if (CFG_CPU_LOADING_DMADONE == 1)
					pTxD->DMADONE = 0;
#else
					/* advance to next ring descriptor address */
					pTxD->DMADONE = 1;
#endif
#ifdef RT_BIG_ENDIAN
					RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#endif
					/* flush dcache if no consistent memory is supported */
					RTMP_DCACHE_FLUSH(pTxD, dma_cb->AllocSize);
					RingBasePaLow += TXD_SIZE;
					RingBaseVa = (PUCHAR) RingBaseVa + TXD_SIZE;
					/* advance to next TxBuf address */
					BufBasePaLow += TX_DMA_1ST_BUFFER_SIZE;
					BufBaseVa = (PUCHAR) BufBaseVa + TX_DMA_1ST_BUFFER_SIZE;
				}

				if (Status == NDIS_STATUS_RESOURCES)
					break;
			}

#ifdef CUT_THROUGH
		cut_through_init(&pAd->PktTokenCb, pAd);
#endif /* CUT_THROUGH */
#endif /* MT_MAC */

		for (num = 0; num < GET_NUM_OF_RX_RING(pAd->chipCap); num++) {
			UINT16 RxRingSize;
			UINT16 RxBufferSize;

			if (num == 0) {
				RxRingSize = RX_RING_SIZE;
				RxBufferSize = RX_BUFFER_AGGRESIZE;
			} else {
				RxRingSize = RX1_RING_SIZE;
				RxBufferSize = RX1_BUFFER_SIZE;
			}

			/* Alloc RxRingDesc memory except Tx ring allocated eariler */
			desc_ring_alloc(pAd, &pAd->PciHif.RxDescRing[num], RxRingSize * RXD_SIZE);

			if (pAd->PciHif.RxDescRing[num].AllocVa == NULL) {
				Status = NDIS_STATUS_RESOURCES;
				break;
			}

			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("RxDescRing[%p]: total %d bytes allocated\n",
					 pAd->PciHif.RxDescRing[num].AllocVa, (INT)pAd->PciHif.RxDescRing[num].AllocSize));
			/* Initialize Rx Ring and associated buffer memory */
			RingBasePaHigh = RTMP_GetPhysicalAddressHigh(pAd->PciHif.RxDescRing[num].AllocPa);
			RingBasePaLow = RTMP_GetPhysicalAddressLow(pAd->PciHif.RxDescRing[num].AllocPa);
			RingBaseVa = pAd->PciHif.RxDescRing[num].AllocVa;

			for (index = 0; index < RxRingSize; index++) {
				dma_cb = &pAd->PciHif.RxRing[num].Cell[index];
				/* Init RX Ring Size, Va, Pa variables*/
				dma_cb->AllocSize = RXD_SIZE;
				dma_cb->AllocVa = RingBaseVa;
				RTMP_SetPhysicalAddressHigh(dma_cb->AllocPa, RingBasePaHigh);
				RTMP_SetPhysicalAddressLow(dma_cb->AllocPa, RingBasePaLow);
				/* Offset to next ring descriptor address */
				RingBasePaLow += RXD_SIZE;
				RingBaseVa = (PUCHAR) RingBaseVa + RXD_SIZE;
				/* Setup Rx associated Buffer size & allocate share memory*/
				pDmaBuf = &dma_cb->DmaBuf;
#ifdef CUT_THROUGH

				if (CUT_THROUGH_RX_ENABL(pAd->PktTokenCb))
					pDmaBuf->AllocSize = RxBufferSize + sizeof(RX_BLK);
				else
#endif /* CUT_THROUGH */
					pDmaBuf->AllocSize = RxBufferSize;

				pPacket = RTMP_AllocateRxPacketBuffer(
					pAd,
					((POS_COOKIE)(pAd->OS_Cookie))->pDev,
					pDmaBuf->AllocSize,
					FALSE,
					&pDmaBuf->AllocVa,
					&pDmaBuf->AllocPa);
				/* keep allocated rx packet */
				dma_cb->pNdisPacket = pPacket;

				if (pDmaBuf->AllocVa == NULL) {
					ErrorValue = ERRLOG_OUT_OF_SHARED_MEMORY;
					MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_ERROR, ("Failed to allocate RxRing's 1st buffer\n"));
					Status = NDIS_STATUS_RESOURCES;
					break;
				}

				/* Zero init this memory block*/
				NdisZeroMemory(pDmaBuf->AllocVa, pDmaBuf->AllocSize);
#ifdef CUT_THROUGH

				if (CUT_THROUGH_RX_ENABL(pAd->PktTokenCb) && (num == 0)) {
					pDmaBuf->AllocVa += sizeof(RX_BLK);
					pDmaBuf->AllocPa += sizeof(RX_BLK);
					OS_PKT_RESERVE(pPacket, sizeof(RX_BLK));
				}

				if (CUT_THROUGH_RX_ENABL(pAd->PktTokenCb) && (num == 0))
					dma_cb->token_id = cut_through_rx_enq(pAd->PktTokenCb, pPacket, TOKEN_RX);

#endif /* CUT_THROUGH */
				/* Write RxD buffer address & allocated buffer length*/
				pRxD = (RXD_STRUC *)dma_cb->AllocVa;
				pRxD->SDP0 = RTMP_GetPhysicalAddressLow(pDmaBuf->AllocPa);
				pRxD->SDL0 = RxBufferSize;
				pRxD->DDONE = 0;
#ifdef CUT_THROUGH

				if (CUT_THROUGH_RX_ENABL(pAd->PktTokenCb) && (num == 0))
					pRxD->SDP1 = cpu2le32((((UINT32)dma_cb->token_id) & 0x0000ffff));

#endif /* CUT_THROUGH */
#ifdef RT_BIG_ENDIAN
				RTMPDescriptorEndianChange((PUCHAR)pRxD, TYPE_RXD);
#endif
				/* flush dcache if no consistent memory is supported */
				RTMP_DCACHE_FLUSH(pRxD, dma_cb->AllocSize);
			}

			MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("Rx[%d] Ring: total %d entry allocated\n", num, index));
		}
	}	while (FALSE);

	NdisZeroMemory(&pAd->FragFrame, sizeof(FRAGMENT_FRAME));
	pAd->FragFrame.pFragPacket = RTMP_AllocateFragPacketBuffer(pAd, RX_BUFFER_NORMSIZE);

	if (pAd->FragFrame.pFragPacket == NULL)
		Status = NDIS_STATUS_RESOURCES;

	if (Status != NDIS_STATUS_SUCCESS) {
		/* Log error inforamtion*/
		NdisWriteErrorLogEntry(
			pAd->AdapterHandle,
			NDIS_ERROR_CODE_OUT_OF_RESOURCES,
			1,
			ErrorValue);
	}

	/*
		Initialize all transmit related software queues
	*/

	for (index = 0; index < GET_NUM_OF_TX_RING(pAd->chipCap); index++) {
		pAd->PciHif.TxRing[index].TxSwFreeIdx = 0;
		pAd->PciHif.TxRing[index].TxCpuIdx = 0;
	}

	/* init MGMT ring index pointer*/
	pAd->PciHif.MgmtRing.TxSwFreeIdx = 0;
	pAd->PciHif.MgmtRing.TxCpuIdx = 0;
#ifdef CONFIG_ANDES_SUPPORT
	/* init CTRL ring index pointer*/
	pAd->PciHif.CtrlRing.TxSwFreeIdx = 0;
	pAd->PciHif.CtrlRing.TxCpuIdx = 0;
#endif /* CONFIG_ANDES_SUPPORT */

	/* Init RX Ring index pointer*/
	for (index = 0; index < GET_NUM_OF_RX_RING(pAd->chipCap); index++) {
		UINT16 RxRingSize;
		UINT16 RxBufferSize;
		UINT16 max_rx_process_cnt;

		if (index == HIF_RX_IDX0) {
			RxRingSize = RX_RING_SIZE;
			RxBufferSize = RX_BUFFER_AGGRESIZE;
			max_rx_process_cnt = MAX_RX_PROCESS_CNT;
		} else {
			RxRingSize = RX1_RING_SIZE;
			RxBufferSize = RX1_BUFFER_SIZE;
			max_rx_process_cnt = MAX_RX1_PROCESS_CNT;
		}

		pAd->PciHif.RxRing[index].RxSwReadIdx = 0;
		pAd->PciHif.RxRing[index].RxCpuIdx = RxRingSize - 1;
		pAd->PciHif.RxRing[index].RxRingSize = RxRingSize;
		pAd->PciHif.RxRing[index].RxBufferSize = RxBufferSize;
		pAd->PciHif.RxRing[index].max_rx_process_cnt = max_rx_process_cnt;
	}

	pAd->PrivateInfo.TxRingFullCnt = 0;
	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("<-- RTMPAllocTxRxRingMemory, Status=%x\n", Status));
	return Status;
}


VOID RTMPFreeTxRxRingMemory(RTMP_ADAPTER *pAd)
{
	int index, num, j;
	RTMP_TX_RING *pTxRing;
	TXD_STRUC *pTxD;
	RTMP_DMACB *dma_cb;
#ifdef RT_BIG_ENDIAN
	TXD_STRUC *pDestTxD;
	UCHAR tx_hw_info[TXD_SIZE];
#endif /* RT_BIG_ENDIAN */
	PNDIS_PACKET pPacket;

	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("--> RTMPFreeTxRxRingMemory\n"));

	/* Free Tx Ring Packet*/
	for (index = 0; index < GET_NUM_OF_TX_RING(pAd->chipCap); index++) {
		pTxRing = &pAd->PciHif.TxRing[index];

		for (j = 0; j < TX_RING_SIZE; j++) {
			dma_cb = &pTxRing->Cell[j];
#ifdef RT_BIG_ENDIAN
			pDestTxD  = (TXD_STRUC *)(dma_cb->AllocVa);
			NdisMoveMemory(&tx_hw_info[0], (UCHAR *)pDestTxD, TXD_SIZE);
			pTxD = (TXD_STRUC *)&tx_hw_info[0];
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#else
			pTxD = (TXD_STRUC *)(dma_cb->AllocVa);
#endif /* RT_BIG_ENDIAN */
			
			
			if (dma_cb->DmaBuf.AllocSize > 0)
				PCI_UNMAP_SINGLE(pAd, dma_cb->DmaBuf.AllocPa, dma_cb->DmaBuf.AllocSize, RTMP_PCI_DMA_TODEVICE);
			
			pPacket = dma_cb->pNdisPacket;

			if (pPacket) {
#ifdef CUT_THROUGH
				UINT8 Type;

				if (CUT_THROUGH_TX_ENABL(pAd->PktTokenCb))
					cut_through_tx_deq(pAd->PktTokenCb, dma_cb->token_id, &Type);

#endif /* CUT_THROUGH */
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_SUCCESS);
			}

			/*Always assign pNdisPacket as NULL after clear*/
			dma_cb->pNdisPacket = NULL;
			pPacket = dma_cb->pNextNdisPacket;

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr1, pTxD->SDLen1, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_SUCCESS);
			}

			/*Always assign pNextNdisPacket as NULL after clear*/
			dma_cb->pNextNdisPacket = NULL;
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
			WriteBackToDescriptor((PUCHAR)pDestTxD, (PUCHAR)pTxD, FALSE, TYPE_TXD);
#endif /* RT_BIG_ENDIAN */
		}
	}

	{
		RTMP_CTRL_RING *pCtrlRing = &pAd->PciHif.CtrlRing;

		NdisAcquireSpinLock(&pAd->PciHif.CtrlRingLock);
		HIF_IO_READ32(pAd, pCtrlRing->hw_didx_addr, &pCtrlRing->TxDmaIdx);

		while (pCtrlRing->TxSwFreeIdx != pCtrlRing->TxDmaIdx) {
#ifdef RT_BIG_ENDIAN
			pDestTxD = (TXD_STRUC *) (pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].AllocVa);
			NdisMoveMemory(&tx_hw_info[0], (UCHAR *)pDestTxD, TXD_SIZE);
			pTxD = (TXD_STRUC *)&tx_hw_info[0];
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#else
			pTxD = (TXD_STRUC *) (pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].AllocVa);
#endif
			pTxD->DMADONE = 0;
			pPacket = pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].pNdisPacket;

			if (pPacket == NULL) {
				INC_RING_INDEX(pCtrlRing->TxSwFreeIdx, CTL_RING_SIZE);
				continue;
			}

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr0, pTxD->SDLen0, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_SUCCESS);
			}

			pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].pNdisPacket = NULL;
			pPacket = pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].pNextNdisPacket;

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr1, pTxD->SDLen1, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_SUCCESS);
			}

			pCtrlRing->Cell[pCtrlRing->TxSwFreeIdx].pNextNdisPacket = NULL;
			INC_RING_INDEX(pCtrlRing->TxSwFreeIdx, CTL_RING_SIZE);
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
			WriteBackToDescriptor((PUCHAR)pDestTxD, (PUCHAR)pTxD, TRUE, TYPE_TXD);
#endif
		}

		NdisReleaseSpinLock(&pAd->PciHif.CtrlRingLock);
	}

	for (j = 0; j < GET_NUM_OF_RX_RING(pAd->chipCap); j++) {
		UINT16 RxRingSize;
		UINT skb_data_size = 0;
		if (j == 0)
			RxRingSize = RX_RING_SIZE;
		else
			RxRingSize = RX1_RING_SIZE;

		for (index = RxRingSize - 1; index >= 0; index--) {
			dma_cb = &pAd->PciHif.RxRing[j].Cell[index];

			if ((dma_cb->DmaBuf.AllocVa) && (dma_cb->pNdisPacket)) {
#ifdef CUT_THROUGH
				UINT8 Type;

				if (CUT_THROUGH_RX_ENABL(pAd->PktTokenCb) && (j == 0))
					cut_through_rx_deq(pAd->PktTokenCb, dma_cb->token_id, &Type);

#endif /* CUT_THROUGH */
				PCI_UNMAP_SINGLE(pAd, dma_cb->DmaBuf.AllocPa,
								 dma_cb->DmaBuf.AllocSize,
								 RTMP_PCI_DMA_FROMDEVICE);
#ifdef CONFIG_WIFI_BUILD_SKB
				skb_data_size = SKB_DATA_ALIGN(SKB_BUF_HEADROOM_RSV + dma_cb->DmaBuf.AllocSize) +
						SKB_DATA_ALIGN(SKB_BUF_TAILROOM_RSV);

				if (skb_data_size <= PAGE_SIZE) {
					DEV_FREE_FRAG_BUF(dma_cb->pNdisPacket);
				} else {
					os_free_mem(dma_cb->pNdisPacket);
				}

#else  /* CONFIG_WIFI_BUILD_SKB */
				RELEASE_NDIS_PACKET(pAd, dma_cb->pNdisPacket,
						NDIS_STATUS_SUCCESS);
#endif /* CONFIG_WIFI_BUILD_SKB */
			}
		}

		NdisZeroMemory(pAd->PciHif.RxRing[j].Cell, RxRingSize * sizeof(RTMP_DMACB));

		if (pAd->PciHif.RxDescRing[j].AllocVa)
			RtmpFreeDescBuf(((POS_COOKIE)(pAd->OS_Cookie))->pDev,
							pAd->PciHif.RxDescRing[j].AllocSize,
							pAd->PciHif.RxDescRing[j].AllocVa,
							pAd->PciHif.RxDescRing[j].AllocPa);

		NdisZeroMemory(&pAd->PciHif.RxDescRing[j], sizeof(RTMP_DMABUF));
	}

#ifdef CUT_THROUGH
	cut_through_deinit((PKT_TOKEN_CB **)&pAd->PktTokenCb);
#endif /* CUT_THROUGH */

	if (pAd->PciHif.MgmtDescRing.AllocVa)
		RtmpFreeDescBuf(((POS_COOKIE)(pAd->OS_Cookie))->pDev, pAd->PciHif.MgmtDescRing.AllocSize, pAd->PciHif.MgmtDescRing.AllocVa, pAd->PciHif.MgmtDescRing.AllocPa);

	NdisZeroMemory(&pAd->PciHif.MgmtDescRing, sizeof(RTMP_DMABUF));

	if (pAd->PciHif.CtrlDescRing.AllocVa) {
		RtmpFreeDescBuf(((POS_COOKIE)(pAd->OS_Cookie))->pDev,
						pAd->PciHif.CtrlDescRing.AllocSize, pAd->PciHif.CtrlDescRing.AllocVa,
						pAd->PciHif.CtrlDescRing.AllocPa);
	}

	NdisZeroMemory(&pAd->PciHif.CtrlDescRing, sizeof(RTMP_DMABUF));

	if (pAd->PciHif.FwDwloRing.DescRing.AllocVa) {
		RtmpFreeDescBuf(((POS_COOKIE)(pAd->OS_Cookie))->pDev, pAd->PciHif.FwDwloRing.DescRing.AllocSize,
						pAd->PciHif.FwDwloRing.DescRing.AllocVa, pAd->PciHif.FwDwloRing.DescRing.AllocPa);
	}

	NdisZeroMemory(&pAd->PciHif.FwDwloRing.DescRing, sizeof(RTMP_DMABUF));

	for (num = 0; num < GET_NUM_OF_TX_RING(pAd->chipCap); num++) {
		if (pAd->PciHif.TxBufSpace[num].AllocVa)
			RTMP_FreeFirstTxBuffer(((POS_COOKIE)(pAd->OS_Cookie))->pDev, pAd->PciHif.TxBufSpace[num].AllocSize, FALSE, pAd->PciHif.TxBufSpace[num].AllocVa, pAd->PciHif.TxBufSpace[num].AllocPa);

		NdisZeroMemory(&pAd->PciHif.TxBufSpace[num], sizeof(RTMP_DMABUF));

		if (pAd->PciHif.TxDescRing[num].AllocVa)
			RtmpFreeDescBuf(((POS_COOKIE)(pAd->OS_Cookie))->pDev, pAd->PciHif.TxDescRing[num].AllocSize, pAd->PciHif.TxDescRing[num].AllocVa, pAd->PciHif.TxDescRing[num].AllocPa);

		NdisZeroMemory(&pAd->PciHif.TxDescRing[num], sizeof(RTMP_DMABUF));
	}

	if (pAd->FragFrame.pFragPacket) {
		RELEASE_NDIS_PACKET(pAd, pAd->FragFrame.pFragPacket, NDIS_STATUS_SUCCESS);
		pAd->FragFrame.pFragPacket = NULL;
	}

	NdisFreeSpinLock(&pAd->CmdQLock);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("<-- RTMPFreeTxRxRingMemory\n"));
}

#endif /* RESOURCE_PRE_ALLOC */


VOID AsicInitTxRxRing(RTMP_ADAPTER *pAd)
{
#ifdef MT_MAC

	if (pAd->chipCap.hif_type == HIF_MT)
		mt_asic_init_txrx_ring(pAd);

#endif /* MT_MAC */
}


/*
	========================================================================

	Routine Description:
		Reset NIC Asics. Call after rest DMA. So reset TX_CTX_IDX to zero.

	Arguments:
		Adapter						Pointer to our adapter

	Return Value:
		None

	IRQL = PASSIVE_LEVEL
	IRQL = DISPATCH_LEVEL

	Note:
		Reset NIC to initial state AS IS system boot up time.

	========================================================================
*/
VOID RTMPRingCleanUp(RTMP_ADAPTER *pAd, UCHAR RingType)
{
	TXD_STRUC *pTxD;
	RXD_STRUC *pRxD;
#ifdef RT_BIG_ENDIAN
	TXD_STRUC *pDestTxD, TxD;
	RXD_STRUC *pDestRxD, RxD;
#endif /* RT_BIG_ENDIAN */
	PNDIS_PACKET pPacket;
	RTMP_TX_RING *pTxRing;
	ULONG IrqFlags;
	int i, ring_id;
	NDIS_SPIN_LOCK *lock;
	/*
		We have to clean all descriptors in case some error happened with reset
	*/
	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("RTMPRingCleanUp(RingIdx=%d, Pending-NDIS=%ld)\n", RingType, pAd->RalinkCounters.PendingNdisPacketCount));

	switch (RingType) {
	case QID_AC_BK:
	case QID_AC_BE:
	case QID_AC_VI:
	case QID_AC_VO:
	case QID_HCCA:
		if (GET_NUM_OF_TX_RING(pAd->chipCap) <= RingType)
			break;

		pTxRing = &pAd->PciHif.TxRing[RingType];
		lock = &pAd->PciHif.TxRingLock[RingType];
		RTMP_IRQ_LOCK(lock, IrqFlags);

		for (i = 0; i < TX_RING_SIZE; i++) { /* We have to scan all TX ring*/
			pTxD  = (TXD_STRUC *)pTxRing->Cell[i].AllocVa;
			pPacket = (PNDIS_PACKET) pTxRing->Cell[i].pNdisPacket;

			/* release scatter-and-gather NDIS_PACKET*/
			if (pPacket) {
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
				pTxRing->Cell[i].pNdisPacket = NULL;
			}

			pPacket = (PNDIS_PACKET) pTxRing->Cell[i].pNextNdisPacket;

			/* release scatter-and-gather NDIS_PACKET*/
			if (pPacket) {
#if defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663)

				if (IS_MT7615(pAd) || IS_MT7622(pAd) || IS_P18(pAd) || IS_MT7663(pAd)) {
					MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF,
							 ("%s():ERR!!7615 shall not has one TxD with 2 pkt buffer!\n",
							  __func__));
				}

#endif /* defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663) */
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
				pTxRing->Cell[i].pNextNdisPacket = NULL;
			}
		}

		HIF_IO_READ32(pAd, pTxRing->hw_didx_addr, &pTxRing->TxDmaIdx);
		pTxRing->TxSwFreeIdx = pTxRing->TxDmaIdx;
		pTxRing->TxCpuIdx = pTxRing->TxDmaIdx;
		HIF_IO_WRITE32(pAd, pTxRing->hw_cidx_addr, pTxRing->TxCpuIdx);
		RTMP_IRQ_UNLOCK(lock, IrqFlags);
		/* TODO: need to check */
		/* rtmp_tx_swq_exit(pAd, WCID_ALL); */
		break;

	case QID_MGMT:
		RTMP_IRQ_LOCK(&pAd->PciHif.MgmtRingLock, IrqFlags);

		for (i = 0; i < MGMT_RING_SIZE; i++) {
#ifdef RT_BIG_ENDIAN
			pDestTxD  = (TXD_STRUC *) pAd->PciHif.MgmtRing.Cell[i].AllocVa;
			TxD = *pDestTxD;
			pTxD = &TxD;
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#else
			pTxD  = (TXD_STRUC *) pAd->PciHif.MgmtRing.Cell[i].AllocVa;
#endif /* RT_BIG_ENDIAN */
			pPacket = (PNDIS_PACKET) pAd->PciHif.MgmtRing.Cell[i].pNdisPacket;

			/* rlease scatter-and-gather NDIS_PACKET*/
			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr0, pTxD->SDLen0, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
			}

			pAd->PciHif.MgmtRing.Cell[i].pNdisPacket = NULL;
			pPacket = (PNDIS_PACKET)pAd->PciHif.MgmtRing.Cell[i].pNextNdisPacket;

			/* release scatter-and-gather NDIS_PACKET*/
			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr1, pTxD->SDLen1, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
			}

			pAd->PciHif.MgmtRing.Cell[i].pNextNdisPacket = NULL;
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
			WriteBackToDescriptor((PUCHAR)pDestTxD, (PUCHAR)pTxD, FALSE, TYPE_TXD);
#endif /* RT_BIG_ENDIAN */
		}

		HIF_IO_READ32(pAd, pAd->PciHif.MgmtRing.hw_didx_addr, &pAd->PciHif.MgmtRing.TxDmaIdx);
		pAd->PciHif.MgmtRing.TxSwFreeIdx = pAd->PciHif.MgmtRing.TxDmaIdx;
		pAd->PciHif.MgmtRing.TxCpuIdx = pAd->PciHif.MgmtRing.TxDmaIdx;
		HIF_IO_WRITE32(pAd, pAd->PciHif.MgmtRing.hw_cidx_addr, pAd->PciHif.MgmtRing.TxCpuIdx);
		RTMP_IRQ_UNLOCK(&pAd->PciHif.MgmtRingLock, IrqFlags);
		pAd->RalinkCounters.MgmtRingFullCount = 0;
		break;

	case QID_RX:
		for (ring_id = 0; ring_id < GET_NUM_OF_RX_RING(pAd->chipCap); ring_id++) {
			RTMP_RX_RING *pRxRing;
			UINT16 RxRingSize;
			UINT16 RxBufferSize;

			pRxRing = &pAd->PciHif.RxRing[ring_id];
			lock = &pAd->PciHif.RxRingLock[ring_id];

			if (ring_id == 0) {
				RxRingSize = RX_RING_SIZE;
				RxBufferSize = RX_BUFFER_AGGRESIZE;
			} else {
				RxRingSize = RX1_RING_SIZE;
				RxBufferSize = RX1_BUFFER_SIZE;
			}

			RTMP_IRQ_LOCK(lock, IrqFlags);

			for (i = 0; i < RxRingSize; i++) {
#ifdef RT_BIG_ENDIAN
				pDestRxD = (RXD_STRUC *)pRxRing->Cell[i].AllocVa;
				RxD = *pDestRxD;
				pRxD = &RxD;
				RTMPDescriptorEndianChange((PUCHAR)pRxD, TYPE_RXD);
#else
				/* Point to Rx indexed rx ring descriptor*/
				pRxD  = (RXD_STRUC *)pRxRing->Cell[i].AllocVa;
#endif /* RT_BIG_ENDIAN */
				pRxD->DDONE = 0;
				pRxD->SDL0 = RxBufferSize;
#ifdef RT_BIG_ENDIAN
				RTMPDescriptorEndianChange((PUCHAR)pRxD, TYPE_RXD);
				WriteBackToDescriptor((PUCHAR)pDestRxD, (PUCHAR)pRxD, FALSE, TYPE_RXD);
#endif /* RT_BIG_ENDIAN */
			}

			HIF_IO_READ32(pAd, pRxRing->hw_didx_addr, &pRxRing->RxDmaIdx);
			pRxRing->RxSwReadIdx = pRxRing->RxDmaIdx;
			pRxRing->RxCpuIdx = ((pRxRing->RxDmaIdx == 0) ? (RxRingSize - 1) : (pRxRing->RxDmaIdx - 1));
			HIF_IO_WRITE32(pAd, pRxRing->hw_cidx_addr, pRxRing->RxCpuIdx);
			RTMP_IRQ_UNLOCK(lock, IrqFlags);
		}

		break;
#ifdef CONFIG_ANDES_SUPPORT

	case QID_CTRL:
		RTMP_IRQ_LOCK(&pAd->PciHif.CtrlRingLock, IrqFlags);

		for (i = 0; i < CTL_RING_SIZE; i++) {
#ifdef RT_BIG_ENDIAN
			pDestTxD  = (TXD_STRUC *) pAd->CtrlRing.Cell[i].AllocVa;
			TxD = *pDestTxD;
			pTxD = &TxD;
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#else
			pTxD  = (TXD_STRUC *) pAd->PciHif.CtrlRing.Cell[i].AllocVa;
#endif /* RT_BIG_ENDIAN */
			pPacket = (PNDIS_PACKET) pAd->PciHif.CtrlRing.Cell[i].pNdisPacket;

			/* rlease scatter-and-gather NDIS_PACKET*/
			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr0, pTxD->SDLen0, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
			}

			pAd->PciHif.CtrlRing.Cell[i].pNdisPacket = NULL;
			pPacket = (PNDIS_PACKET) pAd->PciHif.CtrlRing.Cell[i].pNextNdisPacket;

			/* release scatter-and-gather NDIS_PACKET*/
			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr1, pTxD->SDLen1, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
			}

			pAd->PciHif.CtrlRing.Cell[i].pNextNdisPacket = NULL;
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
			WriteBackToDescriptor((PUCHAR)pDestTxD, (PUCHAR)pTxD, FALSE, TYPE_TXD);
#endif /* RT_BIG_ENDIAN */
		}

		HIF_IO_READ32(pAd, pAd->PciHif.CtrlRing.hw_didx_addr, &pAd->PciHif.CtrlRing.TxDmaIdx);
		pAd->PciHif.CtrlRing.TxSwFreeIdx = pAd->PciHif.CtrlRing.TxDmaIdx;
		pAd->PciHif.CtrlRing.TxCpuIdx = pAd->PciHif.CtrlRing.TxDmaIdx;
		HIF_IO_WRITE32(pAd, pAd->PciHif.CtrlRing.hw_cidx_addr, pAd->PciHif.CtrlRing.TxCpuIdx);
		RTMP_IRQ_UNLOCK(&pAd->PciHif.CtrlRingLock, IrqFlags);
		break;
#endif /* CONFIG_ANDES_SUPPORT */
#ifdef MT_MAC

	case QID_BCN:
#if defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663)
		if (IS_MT7615(pAd) || IS_MT7622(pAd) || IS_P18(pAd) || IS_MT7663(pAd)) {
			/* TODO: shiang-MT7615, we don't need bcn ring now! */
			break;
		}

#endif /* defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663) */
		RTMP_IRQ_LOCK(&pAd->PciHif.BcnRingLock, IrqFlags);

		for (i = 0; i < BCN_RING_SIZE; i++) {
#ifdef RT_BIG_ENDIAN
			pDestTxD  = (TXD_STRUC *)pAd->PciHif.BcnRing.Cell[i].AllocVa;
			TxD = *pDestTxD;
			pTxD = &TxD;
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#else
			pTxD  = (TXD_STRUC *) pAd->PciHif.BcnRing.Cell[i].AllocVa;
#endif /* RT_BIG_ENDIAN */
			pPacket = (PNDIS_PACKET) pAd->PciHif.BcnRing.Cell[i].pNdisPacket;

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr0, pTxD->SDLen0, RTMP_PCI_DMA_TODEVICE);
				/* RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE); */
			}

			pAd->PciHif.BcnRing.Cell[i].pNdisPacket = NULL;
			pPacket = (PNDIS_PACKET)pAd->PciHif.BcnRing.Cell[i].pNextNdisPacket;

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr1, pTxD->SDLen1, RTMP_PCI_DMA_TODEVICE);
				/* RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE); */
			}

			pAd->PciHif.BcnRing.Cell[i].pNextNdisPacket = NULL;
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
			WriteBackToDescriptor((PUCHAR)pDestTxD, (PUCHAR)pTxD, FALSE, TYPE_TXD);
#endif /* RT_BIG_ENDIAN */
		}

		HIF_IO_READ32(pAd, pAd->PciHif.BcnRing.hw_didx_addr, &pAd->PciHif.BcnRing.TxDmaIdx);
		pAd->PciHif.BcnRing.TxSwFreeIdx = pAd->PciHif.BcnRing.TxDmaIdx;
		pAd->PciHif.BcnRing.TxCpuIdx = pAd->PciHif.BcnRing.TxDmaIdx;
		HIF_IO_WRITE32(pAd, pAd->PciHif.BcnRing.hw_cidx_addr, pAd->PciHif.BcnRing.TxCpuIdx);
		RTMP_IRQ_UNLOCK(&pAd->PciHif.BcnRingLock, IrqFlags);
		break;

	case QID_BMC:
		RTMP_IRQ_LOCK(&pAd->PciHif.TxBmcRingLock, IrqFlags);

		for (i = 0; i < TX_RING_SIZE; i++) {
#ifdef RT_BIG_ENDIAN
			pDestTxD  = (TXD_STRUC *)pAd->PciHif.TxBmcRing.Cell[i].AllocVa;
			TxD = *pDestTxD;
			pTxD = &TxD;
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
#else
			pTxD  = (TXD_STRUC *) pAd->PciHif.TxBmcRing.Cell[i].AllocVa;
#endif /* RT_BIG_ENDIAN */
			pPacket = (PNDIS_PACKET)pAd->PciHif.TxBmcRing.Cell[i].pNdisPacket;

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr0, pTxD->SDLen0, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
			}

			pAd->PciHif.TxBmcRing.Cell[i].pNdisPacket = NULL;
			pPacket = (PNDIS_PACKET) pAd->PciHif.TxBmcRing.Cell[i].pNextNdisPacket;

			if (pPacket) {
				PCI_UNMAP_SINGLE(pAd, pTxD->SDPtr1, pTxD->SDLen1, RTMP_PCI_DMA_TODEVICE);
				RELEASE_NDIS_PACKET(pAd, pPacket, NDIS_STATUS_FAILURE);
			}

			pAd->PciHif.TxBmcRing.Cell[i].pNextNdisPacket = NULL;
#ifdef RT_BIG_ENDIAN
			RTMPDescriptorEndianChange((PUCHAR)pTxD, TYPE_TXD);
			WriteBackToDescriptor((PUCHAR)pDestTxD, (PUCHAR)pTxD, FALSE, TYPE_TXD);
#endif /* RT_BIG_ENDIAN */
		}

		HIF_IO_READ32(pAd, pAd->PciHif.TxBmcRing.hw_didx_addr, &pAd->PciHif.TxBmcRing.TxDmaIdx);
		pAd->PciHif.TxBmcRing.TxSwFreeIdx = pAd->PciHif.TxBmcRing.TxDmaIdx;
		pAd->PciHif.TxBmcRing.TxCpuIdx = pAd->PciHif.TxBmcRing.TxDmaIdx;
		HIF_IO_WRITE32(pAd, pAd->PciHif.TxBmcRing.hw_cidx_addr, pAd->PciHif.TxBmcRing.TxCpuIdx);
		RTMP_IRQ_UNLOCK(&pAd->PciHif.TxBmcRingLock, IrqFlags);
		break;
#endif /* MT_MAC */

	default:
		break;
	}
}


VOID DumpPseInfo(RTMP_ADAPTER *pAd)
{
	UINT32 RemapBase, RemapOffset;
	UINT32 Value;
	UINT32 RestoreValue;
	UINT32 Index;

	RTMP_IO_READ32(pAd, MCU_PCIE_REMAP_2, &RestoreValue);

	/* PSE Infomation */
	for (Index = 0; Index < 30720; Index++) {
		RemapBase = GET_REMAP_2_BASE(0xa5000000 + Index * 4) << 19;
		RemapOffset = GET_REMAP_2_OFFSET(0xa5000000 + Index * 4);
		RTMP_IO_WRITE32(pAd, MCU_PCIE_REMAP_2, RemapBase);
		RTMP_IO_READ32(pAd, 0x80000 + RemapOffset, &Value);
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("Offset[0x%x] = 0x%x\n", 0xa5000000 + Index * 4, Value));
	}

	/* Frame linker */
	for (Index  = 0; Index < 1280; Index++) {
		RemapBase = GET_REMAP_2_BASE(0xa00001b0) << 19;
		RemapOffset = GET_REMAP_2_OFFSET(0xa00001b0);
		RTMP_IO_WRITE32(pAd, MCU_PCIE_REMAP_2, RemapBase);
		RTMP_IO_READ32(pAd, 0x80000 + RemapOffset, &Value);
		Value &= ~0xfff;
		Value |= (Index & 0xfff);
		RTMP_IO_WRITE32(pAd, 0x80000 + RemapOffset, Value);
		RemapBase = GET_REMAP_2_BASE(0xa00001b4) << 19;
		RemapOffset = GET_REMAP_2_OFFSET(0xa00001b4);
		RTMP_IO_WRITE32(pAd, MCU_PCIE_REMAP_2, RemapBase);
		RTMP_IO_READ32(pAd, 0x80000 + RemapOffset, &Value);
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("Frame Linker(0x%x) = 0x%x\n", Index, Value));
	}

	/* Page linker */
	for (Index = 0; Index < 1280; Index++) {
		RemapBase = GET_REMAP_2_BASE(0xa00001b8) << 19;
		RemapOffset = GET_REMAP_2_OFFSET(0xa00001b8);
		RTMP_IO_WRITE32(pAd, MCU_PCIE_REMAP_2, RemapBase);
		RTMP_IO_READ32(pAd, 0x80000 + RemapOffset, &Value);
		Value &= ~(0xfff << 16);
		Value |= ((Index & 0xfff) << 16);
		RTMP_IO_WRITE32(pAd, 0x80000 + RemapOffset, Value);
		RemapBase = GET_REMAP_2_BASE(0xa00001b8) << 19;
		RemapOffset = GET_REMAP_2_OFFSET(0xa00001b8);
		RTMP_IO_WRITE32(pAd, MCU_PCIE_REMAP_2, RemapBase);
		RTMP_IO_READ32(pAd, 0x80000 + RemapOffset, &Value);
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("Page Linker(0x%x) = 0x%x\n", Index, (Value & 0xfff)));
	}

	RTMP_IO_WRITE32(pAd, MCU_PCIE_REMAP_2, RestoreValue);
}



/***************************************************************************
  *
  *	register related procedures.
  *
  **************************************************************************/
/*
========================================================================
Routine Description:
    Disable DMA.

Arguments:
	*pAd				the raxx interface data pointer

Return Value:
	None

Note:
========================================================================
*/
VOID RT28XXDMADisable(RTMP_ADAPTER *pAd)
{
	AsicSetWPDMA(pAd, PDMA_TX_RX, FALSE);
}


/*
========================================================================
Routine Description:
    Enable DMA.

Arguments:
	*pAd				the raxx interface data pointer

Return Value:
	None

Note:
========================================================================
*/
VOID RT28XXDMAEnable(RTMP_ADAPTER *pAd)
{
	AsicWaitPDMAIdle(pAd, 200, 1000);
	RtmpusecDelay(50);
	AsicSetWPDMA(pAd, PDMA_TX_RX, TRUE);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("<== %s(): WPDMABurstSIZE = %d\n", __func__, pAd->chipCap.WPDMABurstSIZE));
}

VOID RT28XXDMAReset(RTMP_ADAPTER *pAd)
{
	/* disable WPDMA Tx/Rx */
	AsicSetWPDMA(pAd, PDMA_TX_RX, FALSE);

	/* wait WPDMA idle then reset*/
	if (AsicWaitPDMAIdle(pAd, 200, 1000)) {
		AsicResetWPDMA(pAd);
	} else {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("<== %s(): WPDMA reset fail! \n", __func__));
	}
}

#ifdef MT_MAC
VOID MtUpdateBeaconToAsic(
	IN RTMP_ADAPTER     *pAd,
	IN VOID             *wdev_void,
	IN UINT16           FrameLen,
	IN UCHAR            UpdatePktType)
{
	struct wifi_dev *wdev = (struct wifi_dev *)wdev_void;
	BCN_BUF_STRUC *bcn_buf = NULL;
	UCHAR *buf;
	INT len;
	PNDIS_PACKET pkt = NULL;
#if defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663)
	PNDIS_PACKET bcn_pkt = NULL;
#endif
	UINT32 WdevIdx = 0;
#if defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663)
	UCHAR qIdx = 0;
	NDIS_STATUS Status;
#endif /* defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663) */
	ASSERT(wdev != NULL);

	if (!wdev) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_ERROR, ("%s(): wdev is NULL!\n", __func__));
		return;
	}

	bcn_buf = &wdev->bcn_buf;
	WdevIdx = wdev->wdev_idx;

	if (!bcn_buf) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_ERROR, ("%s(): bcn_buf is NULL!\n", __func__));
		return;
	}

	if (bcn_buf->BeaconPkt) {
#if defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663)

		if (IS_MT7615(pAd) || IS_MT7622(pAd) || IS_P18(pAd) || IS_MT7663(pAd)) {
			Status = RTMPAllocateNdisPacket(pAd, &bcn_pkt, NULL, 0,
											GET_OS_PKT_DATAPTR(bcn_buf->BeaconPkt),
											(UINT)(FrameLen + pAd->chipCap.tx_hw_hdr_len));

			if (Status != NDIS_STATUS_SUCCESS) {
				printk("%s():Cannot alloc bcn pkt buf!\n", __func__);
				return;
			}

			pkt = bcn_pkt;
		} else
#endif /* defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663) */
		{
			pkt = bcn_buf->BeaconPkt;
		}

		buf = (UCHAR *)GET_OS_PKT_DATAPTR(pkt);
		len = FrameLen + pAd->chipCap.tx_hw_hdr_len;
		SET_OS_PKT_LEN(pkt, len);
#ifdef RT_BIG_ENDIAN
		MTMacInfoEndianChange(pAd, buf, TYPE_TMACINFO, sizeof(TMAC_TXD_L));
#endif /* RT_BIG_ENDIAN */
		RTMP_SET_PACKET_WDEV(pkt, WdevIdx);
#if defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663)

		if (IS_MT7615(pAd) || IS_MT7622(pAd) || IS_P18(pAd) || IS_MT7663(pAd)) {
			qIdx = HcGetBcnQueueIdx(pAd, wdev);
			RTMP_SET_PACKET_TYPE(pkt, TX_MGMT);
			send_mlme_pkt(pAd, pkt, wdev, qIdx, FALSE);
		}

#else
		{
			send_mlme_pkt(pAd, pkt, wdev, Q_IDX_BCN, FALSE);
			bcn_buf->bcn_state = BCN_TX_WRITE_TO_DMA;
		}
#endif /* defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663) */
	} else
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_ERROR, ("%s(): BeaconPkt is NULL!\n", __func__));
}
#endif /* MT_MAC */

#ifdef CONFIG_STA_SUPPORT
VOID RT28xxPciStaAsicWakeup(RTMP_ADAPTER *pAd, BOOLEAN bFromTx, PSTA_ADMIN_CONFIG pStaCfg)
{
#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	ASSERT(pStaCfg);

	if (pStaCfg)
		RTMPOffloadPm(pAd, pStaCfg, PM4, EXIT_PM_STATE);

#else

	if (!pStaCfg->PwrMgmt.bDoze)
		return;

	if (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_WAKEUP_NOW)) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("waking up now!\n"));
		return;
	}

	OPSTATUS_SET_FLAG(pAd, fOP_STATUS_WAKEUP_NOW);

	/* TODO: shiang-7603 */
	if (pAd->chipCap.hif_type == HIF_MT) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("%s(%d): Not support for HIF_MT yet!\n",
				 __func__, __LINE__));
		return;
	}

	pStaCfg->PwrMgmt.bDoze = FALSE;
	OPSTATUS_CLEAR_FLAG(pAd, fOP_STATUS_WAKEUP_NOW);
	MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_TRACE, ("<=======RT28xxPciStaAsicWakeup\n"));
#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */
}


VOID RT28xxPciStaAsicSleepAutoWakeup(
	RTMP_ADAPTER *pAd,
	PSTA_ADMIN_CONFIG pStaCfg)
{
#if defined(STA_LP_PHASE_1_SUPPORT) || defined(STA_LP_PHASE_2_SUPPORT)
	ASSERT(pStaCfg);

	if (pStaCfg)
		RTMPOffloadPm(pAd, pStaCfg, PM4, ENTER_PM_STATE);

#else

	if (pAd->StaCfg[0].bRadio == FALSE) {
		pStaCfg->PwrMgmt.bDoze = FALSE;
		return;
	}

	/* TODO: shiang-7603 */
	if (pAd->chipCap.hif_type == HIF_MT) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("%s(%d): Not support for HIF_MT yet!\n",
				 __func__, __LINE__));
		return;
	}

#endif /* STA_LP_PHASE_1_SUPPORT || STA_LP_PHASE_2_SUPPORT */
}


#endif /* CONFIG_STA_SUPPORT */


/*
	==========================================================================
	Description:
		This routine sends command to firmware and turn our chip to wake up mode from power save mode.
		Both RadioOn and .11 power save function needs to call this routine.
	Input:
		Level = GUIRADIO_OFF : call this function is from Radio Off to Radio On.  Need to restore PCI host value.
		Level = other value : normal wake up function.

	==========================================================================
 */
BOOLEAN RT28xxPciAsicRadioOn(RTMP_ADAPTER *pAd, UCHAR Level)
{
	if (pAd->OpMode == OPMODE_AP && Level == DOT11POWERSAVE)
		return FALSE;

	/* 2. Send wake up command.*/
	AsicSendCommandToMcu(pAd, 0x31, PowerWakeCID, 0x00, 0x02, FALSE);
	pAd->bPCIclkOff = FALSE;
	RTMP_ASIC_INTERRUPT_ENABLE(pAd);
	RTMP_CLEAR_FLAG(pAd, fRTMP_ADAPTER_IDLE_RADIO_OFF);

	if (Level == GUI_IDLE_POWER_SAVE) {
		/*2009/06/09: AP and stations need call the following function*/
#ifdef RELEASE_EXCLUDE
		/*
			Hook AsicReverseRfFromSleepMode:
			5592 5390 3883(RBUS) 35xx(3562 3572 3592 3062) 33xx 30xx 3593
			Condition:
			3572 (3592 3562 3062 3572) 3090 3593 3390
			Because 3883  and 3562will not call the following codes.
		*/
#endif /* RELEASE_EXCLUDE */
		/* this if defined is equivalent to ifndef RTMP_RBUS_SUPPORT */
#if defined(RTMP_PCI_SUPPORT) || defined(RTMP_USB_SUPPORT) || defined(RTMP_SDIO_SUPPORT)
		/* add by johnli, RF power sequence setup, load RF normal operation-mode setup*/
		RTMP_CHIP_OP *pChipOps = &pAd->chipOps;

		if (!IS_RBUS_INF(pAd) && pChipOps->AsicReverseRfFromSleepMode)
			pChipOps->AsicReverseRfFromSleepMode(pAd, FALSE);
		else
#endif /* defined(RTMP_PCI_SUPPORT) || defined(RTMP_USB_SUPPORT) || defined(RTMP_SDIO_SUPPORT) */
		{
			/* In Radio Off, we turn off RF clk, So now need to call ASICSwitchChannel again.*/
			hc_reset_radio(pAd);
		}
	}

	return TRUE;
}


/*
	==========================================================================
	Description:
		This routine sends command to firmware and turn our chip to power save mode.
		Both RadioOff and .11 power save function needs to call this routine.
	Input:
		Level = GUIRADIO_OFF  : GUI Radio Off mode
		Level = DOT11POWERSAVE  : 802.11 power save mode
		Level = RTMP_HALT  : When Disable device.

	==========================================================================
 */
BOOLEAN RT28xxPciAsicRadioOff(
	IN RTMP_ADAPTER *pAd,
	IN UCHAR Level,
	IN USHORT TbttNumToNextWakeUp)
{
#ifdef CONFIG_STA_SUPPORT
#ifdef RTMP_BBP
	UCHAR		i, tempBBP_R3 = 0;
#endif
#endif /* CONFIG_STA_SUPPORT */

	/* TODO: shiang-7603 */
	if (pAd->chipCap.hif_type == HIF_MT) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("%s(): Not support for HIF_MT yet!\n",
				 __func__));
		return FALSE;
	}

	return TRUE;
}


/*
========================================================================
Routine Description:
	Get a pci map buffer.

Arguments:
	pAd				- WLAN control block pointer
	*ptr			- Virtual address or TX control block
	size			- buffer size
	sd_idx			- 1: the ptr is TX control block
	direction		- RTMP_PCI_DMA_TODEVICE or RTMP_PCI_DMA_FROMDEVICE

Return Value:
	the PCI map buffer

Note:
========================================================================
*/
ra_dma_addr_t RtmpDrvPciMapSingle(
	IN RTMP_ADAPTER *pAd,
	IN VOID *ptr,
	IN size_t size,
	IN INT sd_idx,
	IN INT direction)
{
	ra_dma_addr_t SrcBufPA = 0;
	struct device *pdev  = ((POS_COOKIE)(pAd->OS_Cookie))->pDev;
	UCHAR ret = 0;

	if (sd_idx == 1) {
		TX_BLK *pTxBlk = (TX_BLK *)(ptr);

		if (pTxBlk->SrcBufLen) {
			SrcBufPA = PCI_MAP_SINGLE_DEV(pAd, pTxBlk->pSrcBufData, pTxBlk->SrcBufLen, 0, direction);
			pTxBlk->SrcBufPA = SrcBufPA;
		 } else {
			return (ra_dma_addr_t)0x0;
		}
	} else
		SrcBufPA = PCI_MAP_SINGLE_DEV(pAd, ptr, size, 0, direction);

	ret = dma_mapping_error(pdev, SrcBufPA);

	if (ret) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("%s: dma mapping error,ret=%d\n", __func__, ret));
		return (ra_dma_addr_t)0x0;
	} else
		return SrcBufPA;
}


int write_reg(RTMP_ADAPTER *ad, UINT32 base, UINT16 offset, UINT32 value)
{
	/* TODO: shiang-7603 */
	if (ad->chipCap.hif_type == HIF_MT) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("%s(): Not support for HIF_MT yet!\n",
				 __func__));
		return FALSE;
	}

	if (base == 0x40)
		RTMP_IO_WRITE32(ad, 0x10000 + offset, value);
	else if (base == 0x41)
		RTMP_IO_WRITE32(ad, offset, value);
	else
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("illegal base = %x\n", base));

	return 0;
}


int read_reg(RTMP_ADAPTER *ad, UINT32 base, UINT16 offset, UINT32 *value)
{
	/* TODO: shiang-7603 */
	if (ad->chipCap.hif_type == HIF_MT) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("%s(): Not support for HIF_MT yet!\n",
				 __func__));
		return FALSE;
	}

	if (base == 0x40)
		RTMP_IO_READ32(ad, 0x10000 + offset, value);
	else if (base == 0x41)
		RTMP_IO_READ32(ad, offset, value);
	else
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("illegal base = %x\n", base));

	return 0;
}


INT irq_init(RTMP_ADAPTER *pAd)
{
	unsigned long irqFlags;
	UINT_32 reg_mask;

	reg_mask = pAd->chipCap.int_enable_mask;

	if (!reg_mask) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_PCI, DBG_LVL_OFF, ("%s(): interrupt enable mask is not assigned\n", __func__));
		ASSERT(FALSE);
		return TRUE;
	}

	RTMP_INT_LOCK(&pAd->irq_lock, irqFlags);
	pAd->PciHif.IntEnableReg = reg_mask;
	pAd->PciHif.intDisableMask = 0;
	pAd->PciHif.IntPending = 0;
	RTMP_INT_UNLOCK(&pAd->irq_lock, irqFlags);

	/* init sub-layer interrupt enable mask, only for chips after P18 */
	if (pAd->chipOps.irq_init)
		pAd->chipOps.irq_init(pAd);

	return FALSE;
}

#ifdef CONFIG_FWOWN_SUPPORT
#define	FW_OWN_POLLING_COUNTER	300
INT32 MtAcquirePowerControl(RTMP_ADAPTER *pAd, UINT32 Offset)
{
	ULONG Flags = 0;
	INT32 Ret = 0;
	UINT32 Counter = 0;

	if (Offset == HIF_FUN_CAP) {
		/* These registers are accessible when Low Power */
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Access HIF_FUN_CAP, return\n", __func__));
		return 1;
	}

	RTMP_SPIN_LOCK_IRQSAVE(&pAd->DriverOwnLock, &Flags);
	pAd->bCRAccessing++;

	if (pAd->bDrvOwn) {
		/* all registers are accessible */
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Current is DrverOnw, return\n", __func__));
		RTMP_SPIN_UNLOCK_IRQRESTORE(&pAd->DriverOwnLock, &Flags);
		return 1;
	}

	RTMP_SPIN_UNLOCK_IRQRESTORE(&pAd->DriverOwnLock, &Flags);
	/* Write any value to HIF_SYS_REV clear FW own */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Wirte any value to HIF_SYS_REV to clear FW own\n", __func__));
	HIF_IO_WRITE32(pAd, HIF_SYS_REV, 1);

	/* Poll driver own status */
	while (Counter < FW_OWN_POLLING_COUNTER) {
		RtmpusecDelay(100);

		if (pAd->bDrvOwn == TRUE)
			break;

		Counter++;
	};

	if (pAd->bDrvOwn) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Successed to clear FW own\n", __func__));
		Ret = 1;
	} else {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Faile to clear FW own\n", __func__));
		Ret = 0;
		RTMP_SPIN_LOCK_IRQSAVE(&pAd->DriverOwnLock, &Flags);
		pAd->bCRAccessing--;	/* will not continue accessing HW */
		RTMP_SPIN_UNLOCK_IRQRESTORE(&pAd->DriverOwnLock, &Flags);
	}

	return Ret;
}


/* Drv give up own */
void MtReleasePowerControl(RTMP_ADAPTER *pAd, UINT32 Offset)
{
	ULONG Flags = 0;

	if (Offset == HIF_FUN_CAP) {
		/* These registers are accessible when Low Power */
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Access HIF_FUN_CAP, return\n", __func__));
		return;
	}

	RTMP_SPIN_LOCK_IRQSAVE(&pAd->DriverOwnLock, &Flags);
	pAd->bCRAccessing--;
	RTMP_SPIN_UNLOCK_IRQRESTORE(&pAd->DriverOwnLock, &Flags);
	return;
}

#if defined(MT7622)
void trigger_intr_to_mcu(BOOLEAN enable)
{
	unsigned long addr;
	unsigned int value;

	addr = (unsigned long)ioremap(HIF_INTR_BASE, HIF_REMAP_SIZE);
	RTMP_SYS_IO_READ32(addr, &value);

	/* write 0 to assert interrupt */
	if (enable == TRUE)
		value &= ~HIF_INTR_VALUE;
	else
		value |= HIF_INTR_VALUE;

	RTMP_SYS_IO_WRITE32(addr, value);
}
#endif

VOID FwOwn(RTMP_ADAPTER *pAd)
{
#if defined(MT7615) || defined(MT7637)
#ifdef MT7615

	if (MTK_REV_GTE(pAd, MT7615, MT7615E1) && MTK_REV_LT(pAd, MT7615, MT7615E3)) {
		/* Wirte any value to HIF_FUN_CAP to set FW own */
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Wirte any value to HIF_FUN_CAP to set FW own\n", __func__));
		HIF_IO_WRITE32(pAd, HIF_FUN_CAP, 1);
		pAd->bDrvOwn = FALSE;
	} else
#endif /* MT7615 */
	{
#ifdef MT7637
		UINT32 Value;
		UINT32 counter = 0;
		/* Poll W_FUNC for FW own back */
		HIF_IO_READ32(pAd, MT_CFG_LPCR_HOST, &Value);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Request FW-Own MT_CFG_LPCR_HOST: %x\n", __func__, Value));
		HIF_IO_WRITE32(pAd, MT_CFG_LPCR_HOST, MT_HOST_SET_OWN);
		HIF_IO_READ32(pAd, MT_CFG_LPCR_HOST, &Value);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Request FW-Own 1 MT_CFG_LPCR_HOST: %x\n", __func__, Value));

		while (!(Value & MT_HOST_SET_OWN)) {
			HIF_IO_READ32(pAd, MT_CFG_LPCR_HOST, &Value);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Request FW-Own processing: %x\n", __func__, Value));
			counter++;
			os_msec_delay(50);

			if (counter > 100) {
				MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s:  FW-Own Faiure\n", __func__));
				break;
			}
		}

		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Request FW-Own 2\n", __func__));
#endif /* MT7637 */
#ifdef MT7615

		if (IS_MT7615(pAd)) {
			if (pAd->bDrvOwn == FALSE) {
				MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Return since already in Fw Own...\n", __func__));
				return;
			}

			HIF_IO_WRITE32(pAd, MT_CFG_LPCR_HOST, MT_HOST_SET_OWN);
			pAd->bDrvOwn = FALSE;
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Set Fw Own\n", __func__));
		}

#endif /* MT7615 */
	}

#endif /* MT7615 || MT7637 */
#ifdef MT7622

	if (IS_MT7622(pAd)) {
		UINT32 counter, value;

		if (pAd->bDrvOwn == FALSE) {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()::Return since already in Fw Own...\n", __func__));
			return;
		}

		/* trigger hif interrupt to MCU */
		trigger_intr_to_mcu(TRUE);

		/* Wirte any value to HIF_FUN_CAP to set FW own */
		HIF_IO_WRITE32(pAd, MT_CFG_LPCR_HOST, MT_HOST_SET_OWN);

		/* Poll driver own status */
		counter = 0;

		while (counter < FW_OWN_POLLING_COUNTER) {
			RtmpusecDelay(1000);
			HIF_IO_READ32(pAd, MT_CFG_LPCR_HOST, &value);

			if (value & MT_HOST_SET_OWN) {
				pAd->bDrvOwn = FALSE;
				break;
			}

			counter++;
		}

		trigger_intr_to_mcu(FALSE);

		if (!pAd->bDrvOwn)
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()::Success to set FW Own\n", __func__));
		else
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()::Fail to set FW Own (%d)\n", __func__, counter));

		return;
	}

#endif /* MT7622 */

#if defined(P18) || defined(MT7663)
	if (IS_P18(pAd) || IS_MT7663(pAd)) {
		/* Wirte 1 to MT_CONN_HIF_ON_LPCTL bit 0 to set FW own */
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Wirte 1 to MT_CONN_HIF_ON_LPCTL bit 0 to set FW own\n", __func__));
		HIF_IO_WRITE32(pAd, MT_CONN_HIF_ON_LPCTL, MT_HOST_SET_OWN);
		pAd->bDrvOwn = FALSE;
		return;
	}

#endif /* defined(P18) || defined(MT7663) */
}

#ifdef MT7615
static VOID n9_wdt_reset(RTMP_ADAPTER *pAd)
{
#define WDT_SWRST_CR_PA 0x81080044
#define MCU_POWER_ON 0x01
#define HOST_TRIGGER_WDT_SWRST 0x1209
	UINT32 top_clock_gen0_value = 0;
	UINT32 top_clock_gen1_value = 0;
	UINT32 top_misc_value = 0;
	UINT32 origonal_remap_cr_value = 0;
	UINT32 remap_cr_record_base_address = 0;
	UINT32 offset_between_target_and_remap_cr_base = 0;
	/* switch hclk to XTAL source, 0x80021100[1:0] = 2'b00 */
	HW_IO_READ32(pAd, TOP_CKGEN0, &top_clock_gen0_value);
	top_clock_gen0_value &= ~(BIT0 | BIT1);
	HW_IO_WRITE32(pAd, TOP_CKGEN0, top_clock_gen0_value);
	/* Set HCLK divider to 1:1, 0x80021104[1:0] = 2'b00 */
	HW_IO_READ32(pAd, TOP_CKGEN1, &top_clock_gen1_value);
	top_clock_gen1_value &= ~(BIT0 | BIT1);
	HW_IO_WRITE32(pAd, TOP_CKGEN1, top_clock_gen1_value);
	/* disable HIF can be reset by WDT 0x80021130[30]=1'b0 */
	HW_IO_READ32(pAd, TOP_MISC, &top_misc_value);
	top_misc_value &= ~(BIT30);
	HW_IO_WRITE32(pAd, TOP_MISC, top_misc_value);
	/* enable WDT reset mode and trigger WDT reset 0x81080044 = 0x1209 */
	/* keep the origonal remap cr1 value for restore */
	HW_IO_READ32(pAd, MCU_PCIE_REMAP_1, &origonal_remap_cr_value);
	/* do PCI-E remap for CR4 PDMA physical base address to 0x40000 */
	HW_IO_WRITE32(pAd, MCU_PCIE_REMAP_1, WDT_SWRST_CR_PA);
	HW_IO_READ32(pAd, MCU_PCIE_REMAP_1, &remap_cr_record_base_address);

	if ((WDT_SWRST_CR_PA  - remap_cr_record_base_address) > REMAP_1_OFFSET_MASK) {
		/* restore the origonal remap cr1 value */
		HW_IO_WRITE32(pAd, MCU_PCIE_REMAP_1, origonal_remap_cr_value);
	}

	offset_between_target_and_remap_cr_base =
		((WDT_SWRST_CR_PA  - remap_cr_record_base_address) & REMAP_1_OFFSET_MASK);
	RTMP_IO_WRITE32(pAd, MT_PCI_REMAP_ADDR_1 + offset_between_target_and_remap_cr_base,
					HOST_TRIGGER_WDT_SWRST);
	/* restore the origonal remap cr1 value */
	HW_IO_WRITE32(pAd, MCU_PCIE_REMAP_1, origonal_remap_cr_value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::N9 WDT reset down\n", __func__));
}
#endif

INT32 DriverOwn(RTMP_ADAPTER *pAd)
{
	INT32 Ret = NDIS_STATUS_SUCCESS;
#if defined(MT7615) || defined(MT7637)
#ifdef MT7615
#define MAX_RETRY_CNT 4
	UINT32 retrycnt = 0;

	if (MTK_REV_GTE(pAd, MT7615, MT7615E1) && MTK_REV_LT(pAd, MT7615, MT7615E3)) {
		UINT32		Counter = 0;
		/* Write any value to HIF_SYS_REV clear FW own */
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): Wirte any value to HIF_SYS_REV to clear FW own\n", __func__));
		HIF_IO_WRITE32(pAd, HIF_SYS_REV, 1);

		/* Poll driver own status */
		while (Counter < FW_OWN_POLLING_COUNTER) {
			RtmpusecDelay(1000);

			if (pAd->bDrvOwn == TRUE)
				break;

			Counter++;
		};

		if (pAd->bDrvOwn)
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): Successed to clear FW own\n", __func__));
		else {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Fail to clear FW own (%d)\n", __func__, Counter));
			Ret = NDIS_STATUS_FAILURE;
		}
	} else
#endif /* MT7615 */
	{
		UINT32 counter = 0;
		UINT32 Value;
#ifdef MT7637
		/* Poll W_FUNC for FW own back */
		HIF_IO_READ32(pAd, MT_CFG_LPCR_HOST, &Value);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Request FW-Own back MT_CFG_LPCR_HOST: %x\n", __func__, Value));
		HIF_IO_WRITE32(pAd, MT_CFG_LPCR_HOST, MT_HOST_CLR_OWN);
		HIF_IO_READ32(pAd, MT_CFG_LPCR_HOST, &Value);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Request FW-Own back2 MT_CFG_LPCR_HOST: %x\n", __func__, Value));

		while (Value & MT_HOST_SET_OWN) {
			HIF_IO_READ32(pAd, MT_CFG_LPCR_HOST, &Value);
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Request FW-Own processing: %x\n", __func__, Value));
			counter++;
			os_msec_delay(50);

			if (counter > 100) {
				MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s:  FW-Own back Faiure\n", __func__));
				Ret = NDIS_STATUS_FAILURE;
				break;
			}
		}

		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Request FW-Own back3\n", __func__));
#endif /* MT7637 */
#ifdef MT7615

		if (IS_MT7615(pAd)) {
			do {
				retrycnt++;

				if (pAd->bDrvOwn == TRUE) {
					MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Return since already in Driver Own...\n", __func__));
					return Ret;
				}

				MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Try to Clear FW Own...\n", __func__));
				/* Write CR to get driver own */
				HIF_IO_WRITE32(pAd, MT_CFG_LPCR_HOST, MT_HOST_CLR_OWN);
				/* Poll driver own status */
				counter = 0;

				while (counter < FW_OWN_POLLING_COUNTER) {
					RtmpusecDelay(1000);

					if (pAd->bDrvOwn == TRUE)
						break;

					counter++;
				};

				if (counter == FW_OWN_POLLING_COUNTER) {
					HIF_IO_READ32(pAd, MT_CFG_LPCR_HOST, &Value);

					if (!(Value & MT_HOST_SET_OWN))
						pAd->bDrvOwn = TRUE;
				}

				if (pAd->bDrvOwn)
					MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Success to clear FW Own\n", __func__));
				else {
					MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Fail to clear FW Own (%d)\n", __func__, counter));

					if (retrycnt >= MAX_RETRY_CNT)
						Ret = NDIS_STATUS_FAILURE;
					else
						n9_wdt_reset(pAd);
				}
			} while (pAd->bDrvOwn == FALSE && retrycnt < MAX_RETRY_CNT);
		}

#endif /* MT7615 */
	}

#endif /* MT7615 || MT7637 */
#ifdef MT7622

	if (IS_MT7622(pAd)) {
		UINT32 counter, value;

		if (pAd->bDrvOwn == TRUE) {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()::Return since already in Driver Own...\n", __func__));
			return Ret;
		}

		/* trigger hif interrupt to MCU */
		trigger_intr_to_mcu(TRUE);

		/* Write CR to get driver own */
		HIF_IO_WRITE32(pAd, MT_CFG_LPCR_HOST, MT_HOST_CLR_OWN);

		/* Poll driver own status */
		counter = 0;

		while (counter < FW_OWN_POLLING_COUNTER) {
			RtmpusecDelay(1000);

			/* polling case */
			HIF_IO_READ32(pAd, MT_CFG_LPCR_HOST, &value);
			if (!(value & MT_HOST_SET_OWN)) {
				pAd->bDrvOwn = TRUE;
				break;
			}

			/* interrupt case */
			if (pAd->bDrvOwn)
				break;

			counter++;
		}

		trigger_intr_to_mcu(FALSE);

		if (pAd->bDrvOwn)
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()::Success to clear Fw Own\n", __func__));
		else {
			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()::Fail to clear Fw Own (%d)\n", __func__, counter));
			Ret = NDIS_STATUS_FAILURE;
		}
	}

#endif
#if defined(P18) || defined(MT7663)
#define MAX_RETRY_CNT 4
	UINT32 retrycnt = 0;

	if (IS_P18(pAd) || IS_MT7663(pAd)) {
		UINT32 counter = 0;
		UINT32 Value;

		do {
			retrycnt++;
			if (pAd->bDrvOwn == TRUE) {
				MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Return since already in Driver Own...\n", __func__));
				return Ret;
			}

			MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Try to Clear FW Own...\n", __func__));
			/* Write CR to get driver own */
			HIF_IO_WRITE32(pAd, MT_CONN_HIF_ON_LPCTL, MT_HOST_CLR_OWN);
			/* Poll driver own status */
			counter = 0;
			while (counter < FW_OWN_POLLING_COUNTER) {
				RtmpusecDelay(1000);

				if (pAd->bDrvOwn == TRUE)
					break;
				counter++;
			};

			if (counter == FW_OWN_POLLING_COUNTER) {
				HIF_IO_READ32(pAd, MT_CONN_HIF_ON_LPCTL, &Value);

				if (!(Value & MT_HOST_SET_OWN))
					pAd->bDrvOwn = TRUE;
			}

			if (pAd->bDrvOwn)
				MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Success to clear FW Own\n", __func__));
			else {
				MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Fail to clear FW Own (%d)\n", __func__, counter));

				if (retrycnt >= MAX_RETRY_CNT)
					Ret = NDIS_STATUS_FAILURE;
			}
		} while (pAd->bDrvOwn == FALSE && retrycnt < MAX_RETRY_CNT);
	}

#endif

	return Ret;
}

#if defined(MT7615) || defined(MT7622) || defined(P18) || defined(MT7663)
INT32 MakeFWOwn(RTMP_ADAPTER *pAd)
{
	ULONG Flags = 0;
	INT32 Ret = 0;
	UINT32 Value;
	UINT32 retry = 100;

	RTMP_SPIN_LOCK_IRQSAVE(&pAd->DriverOwnLock, &Flags);

	if (!pAd->bDrvOwn) {
		/* It is already FW own, do nothing */
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s()::Current is FwOwn, return\n", __func__));
		RTMP_SPIN_UNLOCK_IRQRESTORE(&pAd->DriverOwnLock, &Flags);
		return 1;
	}

	if (pAd->bSetFWOwnRunning) {
		RTMP_SPIN_UNLOCK_IRQRESTORE(&pAd->DriverOwnLock, &Flags);
		return 1;
	}

	pAd->bSetFWOwnRunning = 1;

	/* Make sure no CR access and enter FwOwn with Sleep Notify */
	while (pAd->bCRAccessing & retry) {
		RtmpusecDelay(100);
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("wait CRAccessing %d\n", pAd->bCRAccessing));
		retry--;
	}

	if (retry == 0) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("**************WARNING******************\n"));
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Can not set FW own! gbDrvOwn=%d\n", pAd->bDrvOwn));
		pAd->bSetFWOwnRunning = 0;
		RTMP_SPIN_UNLOCK_IRQRESTORE(&pAd->DriverOwnLock, &Flags);
		return 1;
	}

	/* Wirte any value to HIF_FUN_CAP to set FW own */
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Wirte any value to HIF_FUN_CAP to set FW own\n", __func__));
	HIF_IO_WRITE32(pAd, HIF_FUN_CAP, 1);
	pAd->bDrvOwn = FALSE;
	HIF_IO_READ32(pAd, 0x4014, &Value);
	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): Get 0x4014=0x%x\n", __func__, Value));
	pAd->bSetFWOwnRunning = 0;
	RTMP_SPIN_UNLOCK_IRQRESTORE(&pAd->DriverOwnLock, &Flags);
	return Ret;
}
#endif /* defined(MT7615) || defined(MT7622) */
#endif /* CONFIG_FWOWN_SUPPORT */

/*handle specific CR and forwarding to platform handle*/

VOID pci_io_read32(RTMP_ADAPTER *ad, UINT32 addr, UINT32 *value)
{
	if (ad->chipOps.hif_io_read32) {
		if (ad->chipOps.hif_io_read32(ad, addr, value) >= 0)
			return;
	}

	RTMP_IO_READ32(ad, addr, value);
}

VOID pci_io_write32(RTMP_ADAPTER *ad, UINT32 addr, UINT32 value)
{
	if (ad->chipOps.hif_io_write32) {
		if (ad->chipOps.hif_io_write32(ad, addr, value) >= 0)
			return;
	}

	RTMP_IO_WRITE32(ad, addr, value);
}
#endif /* RTMP_MAC_PCI */
