/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2004, Ralink Technology, Inc.
 *
 * All rights reserved. Ralink's source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of Ralink Tech. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	rtmp_init.c

	Abstract:
	Miniport generic portion header file

	Revision History:
	Who         When          What
	--------    ----------    ----------------------------------------------
*/
#include	"rt_config.h"

#if defined(RLM_CAL_CACHE_SUPPORT) || defined(PRE_CAL_TRX_SET2_SUPPORT)
#include "phy/rlm_cal_cache.h"
#endif /* RLM_CAL_CACHE_SUPPORT */


#ifdef OS_ABL_FUNC_SUPPORT
/* Os utility link: printk, scanf */
RTMP_OS_ABL_OPS RaOsOps, *pRaOsOps = &RaOsOps;
#endif /* OS_ABL_FUNC_SUPPORT */

UCHAR NUM_BIT8[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
#ifdef DBG
char *CipherName[] = {"none", "wep64", "wep128", "TKIP", "AES", "CKIP64", "CKIP128", "CKIP152", "SMS4", "WEP152"};
#endif


NDIS_STATUS RTMPAllocGlobalUtility(VOID)
{
#ifdef OS_ABL_FUNC_SUPPORT
	/* must put the function before any print message */
	/* init OS utilities provided from UTIL module */
	RtmpOsOpsInit(&RaOsOps);
#endif /* OS_ABL_FUNC_SUPPORT */
	/* init UTIL module */
	RtmpUtilInit();
	return NDIS_STATUS_SUCCESS;
}


/*
	========================================================================

	Routine Description:
		Allocate RTMP_ADAPTER data block and do some initialization

	Arguments:
		Adapter		Pointer to our adapter

	Return Value:
		NDIS_STATUS_SUCCESS
		NDIS_STATUS_FAILURE

	IRQL = PASSIVE_LEVEL

	Note:

	========================================================================
*/
NDIS_STATUS RTMPAllocAdapterBlock(VOID *handle, VOID **ppAdapter)
{
	RTMP_ADAPTER *pAd = NULL;
	NDIS_STATUS	 Status;
	INT index;
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("--> RTMPAllocAdapterBlock\n"));
	RTMPAllocGlobalUtility();
	*ppAdapter = NULL;

	do {
		/* Allocate RTMP_ADAPTER memory block*/
		Status = AdapterBlockAllocateMemory(handle, (PVOID *)&pAd, sizeof(RTMP_ADAPTER));

		if (Status != NDIS_STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Failed to allocate memory - ADAPTER\n"));
			break;
		} else {
			/* init resource list (must be after pAd allocation) */
			initList(&pAd->RscTimerMemList);
			initList(&pAd->RscTaskMemList);
			initList(&pAd->RscLockMemList);
			initList(&pAd->RscTaskletMemList);
			initList(&pAd->RscSemMemList);
			initList(&pAd->RscAtomicMemList);
			initList(&pAd->RscTimerCreateList);
			pAd->OS_Cookie = handle;
			((POS_COOKIE)(handle))->pAd_va = (LONG)pAd;
		}

		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n\n=== pAd = %p, size = %zu ===\n\n", pAd,
				 sizeof(RTMP_ADAPTER)));

		if (RtmpOsStatsAlloc(&pAd->stats, &pAd->iw_stats) == FALSE) {
			Status = NDIS_STATUS_FAILURE;
			break;
		}

		/*Allocate Timer Lock*/
		NdisAllocateSpinLock(pAd, &pAd->TimerSemLock);
		/*Allocate interface lock*/
		NdisAllocateSpinLock(pAd, &pAd->VirtualIfLock);
#ifdef MT_MAC
		NdisAllocateSpinLock(pAd, &pAd->PciHif.BcnRingLock);
#endif /* MT_MAC */
		/* Init spin locks*/
		NdisAllocateSpinLock(pAd, &pAd->PciHif.MgmtRingLock);
		NdisAllocateSpinLock(pAd, &pAd->WdevListLock);
		NdisAllocateSpinLock(pAd, &pAd->BssInfoIdxBitMapLock);
		NdisAllocateSpinLock(pAd, &pAd->irq_lock);
#ifdef WMM_ACM_SUPPORT
		NdisAllocateSpinLock(pAd, &pAd->AcmTspecSemLock);
		NdisAllocateSpinLock(pAd, &pAd->AcmTspecIrqLock);
#endif /* WMM_ACM_SUPPORT */
#ifdef CONFIG_FWOWN_SUPPORT
		NdisAllocateSpinLock(pAd, &pAd->DriverOwnLock);
#endif /* CONFIG_FWOWN_SUPPORT */
#ifdef CONFIG_AP_SUPPORT
#ifdef APCLI_SUPPORT
#ifdef MAC_REPEATER_SUPPORT
		NdisAllocateSpinLock(pAd, &pAd->ApCfg.ReptCliEntryLock);
		NdisAllocateSpinLock(pAd, &pAd->ApCfg.CliLinkMapLock);
#endif
#endif
#endif
#ifdef GREENAP_SUPPORT
		NdisAllocateSpinLock(pAd, &pAd->ApCfg.greenap.lock);
#endif /* GREENAP_SUPPORT */
		/*HIF related initial for pAd*/
		RTMPInitHifAdapterBlock(pAd);
#ifdef RLM_CAL_CACHE_SUPPORT
		rlmCalCacheInit(pAd, &pAd->rlmCalCache);
#endif /* RLM_CAL_CACHE_SUPPORT */
		*ppAdapter = (VOID *)pAd;
	} while (FALSE);

	if (Status != NDIS_STATUS_SUCCESS) {
		if (pAd) {
			if (pAd->stats) {
				os_free_mem(pAd->stats);
				pAd->stats = NULL;
			}

			if (pAd->iw_stats) {
				os_free_mem(pAd->iw_stats);
				pAd->iw_stats = NULL;
			}

			RtmpOsVfree(pAd);
		}

		return Status;
	}

	/* Init ProbeRespIE Table */
	for (index = 0; index < MAX_LEN_OF_BSS_TABLE; index++) {
		if (os_alloc_mem(pAd, &pAd->ProbeRespIE[index].pIe, MAX_VIE_LEN) == NDIS_STATUS_SUCCESS)
			RTMPZeroMemory(pAd->ProbeRespIE[index].pIe, MAX_VIE_LEN);
		else
			pAd->ProbeRespIE[index].pIe = NULL;
	}

	/*init WifiSys information structure*/
	wifi_sys_init(pAd);
	/*allocate wpf related memory*/
	wpf_config_init(pAd);
#ifdef MULTI_INF_SUPPORT
	Status = multi_inf_adapt_reg((VOID *) pAd);
#endif /* MULTI_INF_SUPPORT */
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("<-- RTMPAllocAdapterBlock, Status=%x\n", Status));
	return Status;
}

NDIS_STATUS alloc_chip_cap_dep_data(RTMP_ADAPTER *pAd)
{
#ifdef RTMP_MAC_PCI

	if (IS_RBUS_INF(pAd) || IS_PCI_INF(pAd)) {
		if (alloc_chip_cap_dep_data_pci(pAd) != NDIS_STATUS_SUCCESS)
			return NDIS_STATUS_FAILURE;
	}

#endif
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd)) {
		if (alloc_chip_cap_dep_data_usb(pAd) != NDIS_STATUS_SUCCESS)
			return NDIS_STATUS_FAILURE;
	}

#endif

	if (alloc_chip_cap_dep_data_cmm(pAd) != NDIS_STATUS_SUCCESS)
		return NDIS_STATUS_FAILURE;

	return NDIS_STATUS_SUCCESS;
}

VOID free_chip_cap_dep_data(RTMP_ADAPTER *pAd)
{
#ifdef RTMP_MAC_PCI

	if (IS_RBUS_INF(pAd) || IS_PCI_INF(pAd))
		free_chip_cap_dep_data_pci(pAd);

#endif
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd))
		free_chip_cap_dep_data_usb(pAd);

#endif
	free_chip_cap_dep_data_cmm(pAd);
}

NDIS_STATUS alloc_chip_cap_dep_data_cmm(RTMP_ADAPTER *pAd)
{
	INT index;
	UINT8 num_of_tx_ring = GET_NUM_OF_TX_RING(pAd->chipCap);
	BOOLEAN *pDeQueueRunning = NULL;
	NDIS_SPIN_LOCK *pDeQueueLock = NULL;
	QUEUE_HEADER *pTxSwQueue = NULL;
	NDIS_SPIN_LOCK *pTxSwQueueLock = NULL;
#if defined(MT_MAC) && defined(IP_ASSEMBLY)
	DL_LIST *pAssebQueue = NULL;
#endif
#ifdef BLOCK_NET_IF
	BLOCK_QUEUE_ENTRY *pBlockQueueTab;
#endif /* BLOCK_NET_IF */
#ifdef COMPOS_TESTMODE_WIN
	ULONG *pOneSecOsTxCount;
	ULONG *pOneSecDmaDoneCount;
#endif
	os_alloc_mem(pAd, (UCHAR **)&pDeQueueRunning, (num_of_tx_ring)*sizeof(BOOLEAN));

	if (pDeQueueRunning == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pDeQueueRunning, (num_of_tx_ring)*sizeof(BOOLEAN));
	pAd->DeQueueRunning = pDeQueueRunning;

	for (index = 0; index < num_of_tx_ring; index++)
		pAd->DeQueueRunning[index] = FALSE;

	os_alloc_mem(pAd, (UCHAR **)&pDeQueueLock, (num_of_tx_ring)*sizeof(NDIS_SPIN_LOCK));

	if (pDeQueueLock == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pDeQueueLock, (num_of_tx_ring)*sizeof(NDIS_SPIN_LOCK));
	pAd->DeQueueLock = pDeQueueLock;

	for (index = 0; index < num_of_tx_ring; index++)
		NdisAllocateSpinLock(pAd, &pAd->DeQueueLock[index]);

	os_alloc_mem(pAd, (UCHAR **)&pTxSwQueue, (num_of_tx_ring)*sizeof(QUEUE_HEADER));

	if (pTxSwQueue == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pTxSwQueue, (num_of_tx_ring)*sizeof(QUEUE_HEADER));
	pAd->TxSwQueue = pTxSwQueue;
	os_alloc_mem(pAd, (UCHAR **)&pTxSwQueueLock, (num_of_tx_ring)*sizeof(NDIS_SPIN_LOCK));

	if (pTxSwQueueLock == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pTxSwQueueLock, (num_of_tx_ring)*sizeof(NDIS_SPIN_LOCK));
	pAd->TxSwQueueLock = pTxSwQueueLock;

	for (index = 0; index < num_of_tx_ring; index++)
		NdisAllocateSpinLock(pAd, &pAd->TxSwQueueLock[index]);

#if defined(MT_MAC) && defined(IP_ASSEMBLY)
	os_alloc_mem(pAd, (UCHAR **)&pAssebQueue, (num_of_tx_ring)*sizeof(DL_LIST));

	if (pAssebQueue == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pAssebQueue, (num_of_tx_ring)*sizeof(DL_LIST));
	pAd->assebQueue = pAssebQueue;
	os_alloc_mem(
		pAd,
		(UCHAR **)&pAd->cur_ip_assem_data,
		(num_of_tx_ring)*sizeof(struct ip_assemble_data *));

	if (pAd->cur_ip_assem_data == NULL)
		return NDIS_STATUS_FAILURE;

	for (index = 0; index < num_of_tx_ring; index++)
		DlListInit(&pAd->assebQueue[index]);

#endif
#ifdef BLOCK_NET_IF
	os_alloc_mem(pAd, (UCHAR **)&pBlockQueueTab, (num_of_tx_ring)*sizeof(BLOCK_QUEUE_ENTRY));

	if (pBlockQueueTab == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pBlockQueueTab, (num_of_tx_ring)*sizeof(BLOCK_QUEUE_ENTRY));
	pAd->blockQueueTab = pBlockQueueTab;
#endif /* BLOCK_NET_IF */
#ifdef COMPOS_TESTMODE_WIN
	os_alloc_mem(pAd, (UCHAR **)&pOneSecOsTxCount, (num_of_tx_ring)*sizeof(ULONG));

	if (pOneSecOsTxCount == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pOneSecOsTxCount, (num_of_tx_ring)*sizeof(ULONG));
	pAd->RalinkCounters.OneSecOsTxCount = pOneSecOsTxCount;
	os_alloc_mem(pAd, (UCHAR **)&pOneSecDmaDoneCount, (num_of_tx_ring)*sizeof(ULONG));

	if (pOneSecDmaDoneCount == NULL)
		return NDIS_STATUS_FAILURE;

	NdisZeroMemory(pOneSecDmaDoneCount, (num_of_tx_ring)*sizeof(ULONG));
	pAd->RalinkCounters.OneSecDmaDoneCount = pOneSecDmaDoneCount;
#endif
	return NDIS_STATUS_SUCCESS;
}

VOID free_chip_cap_dep_data_cmm(RTMP_ADAPTER *pAd)
{
	INT index;
	UINT8 num_of_tx_ring = GET_NUM_OF_TX_RING(pAd->chipCap);

	/* spinlock must be freed before its data structure is freed */
	for (index = 0; index < num_of_tx_ring; index++)
		NdisFreeSpinLock(&pAd->DeQueueLock[index]);

	for (index = 0; index < num_of_tx_ring; index++)
		NdisFreeSpinLock(&pAd->TxSwQueueLock[index]);

	os_free_mem(pAd->DeQueueRunning);
	os_free_mem(pAd->DeQueueLock);
	os_free_mem(pAd->TxSwQueue);
	os_free_mem(pAd->TxSwQueueLock);
#if defined(MT_MAC) && defined(IP_ASSEMBLY)
	os_free_mem(pAd->assebQueue);
	os_free_mem(pAd->cur_ip_assem_data);
#endif
#ifdef BLOCK_NET_IF
	os_free_mem(pAd->blockQueueTab);
#endif
#ifdef COMPOS_TESTMODE_WIN
	os_free_mem(pAd->RalinkCounters.OneSecOsTxCount);
	os_free_mem(pAd->RalinkCounters.OneSecDmaDoneCount);
#endif
}

BOOLEAN RTMPCheckPhyMode(RTMP_ADAPTER *pAd, UINT8 band_cap, UCHAR *pPhyMode)
{
	BOOLEAN RetVal = TRUE;

	if (band_cap == RFIC_24GHZ) {
		if (!WMODE_2G_ONLY(*pPhyMode)) {
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("%s(): Warning! The board type is 2.4G only!\n",
					  __func__));
			RetVal =  FALSE;
		}
	} else if (band_cap == RFIC_5GHZ) {
		if (!WMODE_5G_ONLY(*pPhyMode)) {
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("%s(): Warning! The board type is 5G only!\n",
					  __func__));
			RetVal =  FALSE;
		}
	} else if (band_cap == RFIC_DUAL_BAND)
		RetVal = TRUE;
	else {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("%s(): Unknown supported band (%u), assume dual band used.\n",
				  __func__, band_cap));
		RetVal = TRUE;
	}

	if (RetVal == FALSE) {
#ifdef DOT11_N_SUPPORT

		if (band_cap == RFIC_5GHZ) /*5G ony: change to A/N mode */
			*pPhyMode = PHY_11AN_MIXED;
		else /* 2.4G only or Unknown supported band: change to B/G/N mode */
			*pPhyMode = PHY_11BGN_MIXED;

#else

		if (band_cap == RFIC_5GHZ) /*5G ony: change to A mode */
			*pPhyMode = PHY_11A;
		else /* 2.4G only or Unknown supported band: change to B/G mode */
			*pPhyMode = PHY_11BG_MIXED;

#endif /* !DOT11_N_SUPPORT */
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("%s(): Changed PhyMode to %u\n",
				  __func__, *pPhyMode));
	}

	return RetVal;
}


/*
	========================================================================

	Routine Description:
		Set default value from EEPROM

	Arguments:
		Adapter						Pointer to our adapter

	Return Value:
		None

	IRQL = PASSIVE_LEVEL

	Note:

	========================================================================
*/
VOID NICInitAsicFromEEPROM(RTMP_ADAPTER *pAd)
{
	EEPROM_NIC_CONFIG2_STRUC NicConfig2;
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("--> NICInitAsicFromEEPROM\n"));
	NicConfig2.word = pAd->NicConfig2.word;
	/* finally set primary ant */
	AntCfgInit(pAd);
	RTMP_CHIP_ASIC_INIT_TEMPERATURE_COMPENSATION(pAd);
#ifdef RTMP_RF_RW_SUPPORT
	/*Init RFRegisters after read RFIC type from EEPROM*/
	InitRFRegisters(pAd);
#endif /* RTMP_RF_RW_SUPPORT */
#ifdef ANT_DIVERSITY_SUPPORT

	if ((pAd->CommonCfg.bHWRxAntDiversity) &&
		(pAd->CommonCfg.RxAntDiversityCfg == ANT_HW_DIVERSITY_ENABLE) &&
		(pAd->chipOps.HwAntEnable))
		pAd->chipOps.HwAntEnable(pAd);

#endif

	if (NicConfig2.field.DynamicTxAgcControl == 1)
		pAd->bAutoTxAgcA = pAd->bAutoTxAgcG = TRUE;
	else
		pAd->bAutoTxAgcA = pAd->bAutoTxAgcG = FALSE;

#ifdef CONFIG_ATE
	RTMPCfgTssiGainFromEEPROM(pAd);
#endif /* CONFIG_ATE */
#ifndef MAC_INIT_OFFLOAD
	AsicSetRxStream(pAd, pAd->Antenna.field.RxPath, 0);
#endif
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		UCHAR bandIdx = HcGetBandByWdev(&pAd->StaCfg[MAIN_MSTA_ID].wdev);
		RTMPStaCfgRadioCtrlFromEEPROM(pAd, NicConfig2);
		AsicSetTxStream(pAd, pAd->Antenna.field.TxPath, OPMODE_STA, FALSE, bandIdx);
	}
#endif /* CONFIG_STA_SUPPORT */
	RTMP_EEPROM_ASIC_INIT(pAd);
	AsicBbpInitFromEEPROM(pAd);
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("TxPath = %d, RxPath = %d, RFIC=%d\n",
			 pAd->Antenna.field.TxPath, pAd->Antenna.field.RxPath, pAd->RfIcType));
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("<-- NICInitAsicFromEEPROM\n"));
}



INT32 WfHifSysInit(RTMP_ADAPTER *pAd, HIF_INFO_T *pHifInfo)
{
	NDIS_STATUS status;
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s()-->\n", __func__));
	RT28XXDMADisable(pAd);
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():Disable WPDMA\n", __func__));
#ifdef CONFIG_WIFI_PAGE_ALLOC_SKB
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Use dev_alloc_skb\n"));
#else
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Use alloc_skb\n"));
#endif
#ifdef RESOURCE_PRE_ALLOC
	status = RTMPInitTxRxRingMemory(pAd);
#else
	status = RTMPAllocTxRxRingMemory(pAd);
#endif /* RESOURCE_PRE_ALLOC */

	if (status != NDIS_STATUS_SUCCESS) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("RTMPAllocTxRxMemory failed, Status[=0x%08x]\n", status));
		goto err;
	}

#ifdef RTMP_MAC_USB
	pAd->CommonCfg.bMultipleIRP = FALSE;

	if (pAd->CommonCfg.bMultipleIRP)
		pAd->CommonCfg.NumOfBulkInIRP = RX_RING_SIZE;
	else
		pAd->CommonCfg.NumOfBulkInIRP = 1;

	pHifInfo->BulkInMaxPacketSize = pAd->BulkInMaxPacketSize;
#endif /* RTMP_MAC_USB */
#ifdef WLAN_SKB_RECYCLE
	skb_queue_head_init(&pAd->rx0_recycle);
#endif /* WLAN_SKB_RECYCLE */
err:
	return status;
}


INT32 WfHifSysExit(RTMP_ADAPTER *pAd)
{
	WLAN_HOOK_CALL(WLAN_HOOK_HIF_EXIT, pAd, NULL);
#ifdef RESOURCE_PRE_ALLOC
	RTMPResetTxRxRingMemory(pAd);
#else
	RTMPFreeTxRxRingMemory(pAd);
#endif /* RESOURCE_PRE_ALLOC */
	RT28XXDMAReset(pAd);
#ifdef CONFIG_FWOWN_SUPPORT
	FwOwn(pAd);
#endif
	return 0;
}


INT32 WfMcuSysInit(RTMP_ADAPTER *pAd)
{
	MCU_CTRL_INIT(pAd);
#ifdef MT_MAC

	if (pAd->chipOps.FwInit && (pAd->chipCap.hif_type == HIF_MT))
		pAd->chipOps.FwInit(pAd);

#endif /* MT_MAC */
	return NDIS_STATUS_SUCCESS;
}

INT32 WfMcuSysExit(RTMP_ADAPTER *pAd)
{
	MCUSysExit(pAd);
	return 0;
}


extern RTMP_STRING *mac;

INT32 WfEPROMSysInit(RTMP_ADAPTER *pAd)
{
	UCHAR RfIC;
	/* hook e2p operation */
	RtmpChipOpsEepromHook(pAd, pAd->infType, E2P_NONE);
	/* We should read EEPROM for all cases */
	/* TODO: shiang-7603, revise this! */
	NICReadEEPROMParameters(pAd, (RTMP_STRING *)mac);
	HcRadioInit(pAd, pAd->RfIcType, pAd->CommonCfg.dbdc_mode);
	/* +++Add by shiang for debug */
	RfIC = HcGetRadioRfIC(pAd);
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("%s():PhyCtrl=>RfIcType/rf_band_cap = 0x%x/0x%x\n",
			  __func__, pAd->RfIcType, RfIC));
	RTMP_NET_DEV_NICKNAME_INIT(pAd);
	return NDIS_STATUS_SUCCESS;
}


INT32 WfEPROMSysExit(RTMP_ADAPTER *pAd)
{
	return NDIS_STATUS_SUCCESS;
}

/*
	========================================================================

	Routine Description:
		Initialize NIC hardware

	Arguments:
		Adapter						Pointer to our adapter

	Return Value:
		None

	IRQL = PASSIVE_LEVEL

	Note:

	========================================================================
*/
NDIS_STATUS	NICInitializeAdapter(RTMP_ADAPTER *pAd)
{
	NDIS_STATUS ret = NDIS_STATUS_SUCCESS;
	ret = WfMacInit(pAd);

	if (ret != NDIS_STATUS_SUCCESS) {
		ret = NDIS_STATUS_FAILURE;
		goto err;
	}

	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("MAC Init Done!\n"));
	ret = WfPhyInit(pAd);

	if (ret != NDIS_STATUS_SUCCESS) {
		ret = NDIS_STATUS_FAILURE;
		goto err;
	}

	ret = NICInitializeAsic(pAd);
err:
	return ret;
}


INT rtmp_hif_cyc_init(RTMP_ADAPTER *pAd, UINT8 val)
{
	/* TODO: shiang-7603 */
	if (pAd->chipCap.hif_type == HIF_MT) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(%d): Not support for HIF_MT yet!\n",
				 __func__, __LINE__));
		return FALSE;
	}

	return TRUE;
}



/*
	========================================================================

	Routine Description:
		Initialize ASIC

	Arguments:
		Adapter						Pointer to our adapter

	Return Value:
		None

	IRQL = PASSIVE_LEVEL

	Note:

	========================================================================
*/
NDIS_STATUS NICInitializeAsic(RTMP_ADAPTER *pAd)
{
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("--> NICInitializeAsic\n"));
#ifdef RTMP_MAC_USB

	if (IS_USB_INF(pAd)) {
		/* TODO: shiang-usw, why USB need disableSync before change clock??? */
		AsicDisableSync(pAd, HW_BSSID_0);

		/* Default PCI clock cycle per ms is different as default setting, which is based on PCI.*/
		if (pAd->chipCap.hif_type == HIF_RTMP)
			rtmp_hif_cyc_init(pAd, 0x1e);
	}

#endif /* RTMP_MAC_USB */
#if 0
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		/* Add radio off control */
		if (pAd->StaCfg[0].bRadio == FALSE) {
			/* RTMP_IO_WRITE32(pAd, PWR_PIN_CFG, 0x00001818);*/
			RTMP_SET_FLAG(pAd, fRTMP_ADAPTER_RADIO_OFF);
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Set Radio Off\n"));
		}
	}
#endif /* CONFIG_STA_SUPPORT */
#endif
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("<-- NICInitializeAsic\n"));
	return NDIS_STATUS_SUCCESS;
}


/*
	========================================================================

	Routine Description:
		Reset NIC from error

	Arguments:
		Adapter						Pointer to our adapter

	Return Value:
		None

	IRQL = PASSIVE_LEVEL

	Note:
		Reset NIC from error state

	========================================================================
*/
static VOID NICResetFromErrorForRf(RTMP_ADAPTER *pAd)
{
#ifdef CONFIG_STA_SUPPORT
	PSTA_ADMIN_CONFIG pStaCfg = NULL;
	INT i;
#endif
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		for (i = 0; i < MAX_MULTI_STA; i++) {
			pStaCfg = &pAd->StaCfg[i];
			AsicStaBbpTuning(pAd, pStaCfg);
		}
	}
#endif /* CONFIG_STA_SUPPORT */
	hc_reset_radio(pAd);
}

VOID NICResetFromError(RTMP_ADAPTER *pAd)
{
	/* Reset BBP (according to alex, reset ASIC will force reset BBP*/
	/* Therefore, skip the reset BBP*/
	/* RTMP_IO_WRITE32(pAd, MAC_CSR1, 0x2);*/
	/* TODO: shaing-7603 */
	if (IS_MT7603(pAd) || IS_MT7628(pAd) || IS_MT76x6(pAd) || IS_MT7637(pAd)) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): for MT7603\n", __func__));
		NICInitializeAdapter(pAd);
		NICInitAsicFromEEPROM(pAd);
		RTMPEnableRxTx(pAd);
		return;
	}

#ifndef MT_MAC
	RTMP_IO_WRITE32(pAd, MAC_SYS_CTRL, 0x1);
	/* Remove ASIC from reset state*/
	RTMP_IO_WRITE32(pAd, MAC_SYS_CTRL, 0x0);
#endif /*ndef MT_MAC */
	NICInitializeAdapter(pAd);
	NICInitAsicFromEEPROM(pAd);
	NICResetFromErrorForRf(pAd);
}


VOID NICUpdateFifoStaCounters(RTMP_ADAPTER *pAd)
{
#ifdef CONFIG_ATE

	/* Nothing to do in ATE mode */
	if (ATE_ON(pAd))
		return;

#endif /* CONFIG_ATE */
#ifdef RTMP_MAC_USB
#ifdef CONFIG_STA_SUPPORT

	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_IDLE_RADIO_OFF))
		return;

#endif /* CONFIG_STA_SUPPORT */
#endif /* RTMP_MAC_USB */

	/* TODO: shiang-7603 */
	if (pAd->chipCap.hif_type == HIF_MT) {
		/* MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(%d): Not support for HIF_MT yet!\n", */
		/* __func__, __LINE__)); */
		return;
	}
}


int load_patch(RTMP_ADAPTER *ad)
{
	int ret = NDIS_STATUS_SUCCESS;
	ULONG Old, New, Diff;

	if (ad->chipOps.load_rom_patch) {
		RTMP_GetCurrentSystemTick(&Old);
		ret = NICLoadRomPatch(ad);
		RTMP_GetCurrentSystemTick(&New);
		Diff = (New - Old) * 1000 / OS_HZ;
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("load rom patch spent %ldms\n", Diff));
	}

	return ret;
}




/*
	========================================================================

	Routine Description:
		Compare two memory block

	Arguments:
		pSrc1		Pointer to first memory address
		pSrc2		Pointer to second memory address

	Return Value:
		0:			memory is equal
		1:			pSrc1 memory is larger
		2:			pSrc2 memory is larger

	IRQL = DISPATCH_LEVEL

	Note:

	========================================================================
*/
ULONG RTMPCompareMemory(VOID *pSrc1, VOID *pSrc2, ULONG Length)
{
	PUCHAR	pMem1;
	PUCHAR	pMem2;
	ULONG	Index = 0;
	pMem1 = (PUCHAR) pSrc1;
	pMem2 = (PUCHAR) pSrc2;

	for (Index = 0; Index < Length; Index++) {
		if (pMem1[Index] > pMem2[Index])
			return 1;
		else if (pMem1[Index] < pMem2[Index])
			return 2;
	}

	/* Equal*/
	return 0;
}


/*
	========================================================================

	Routine Description:
		Zero out memory block

	Arguments:
		pSrc1		Pointer to memory address
		Length		Size

	Return Value:
		None

	IRQL = PASSIVE_LEVEL
	IRQL = DISPATCH_LEVEL

	Note:

	========================================================================
*/
VOID RTMPZeroMemory(VOID *pSrc, ULONG Length)
{
	PUCHAR	pMem;
	ULONG	Index = 0;
	pMem = (PUCHAR) pSrc;

	for (Index = 0; Index < Length; Index++)
		pMem[Index] = 0x00;
}


/*
	========================================================================

	Routine Description:
		Copy data from memory block 1 to memory block 2

	Arguments:
		pDest		Pointer to destination memory address
		pSrc		Pointer to source memory address
		Length		Copy size

	Return Value:
		None

	IRQL = PASSIVE_LEVEL
	IRQL = DISPATCH_LEVEL

	Note:

	========================================================================
*/
VOID RTMPMoveMemory(VOID *pDest, VOID *pSrc, ULONG Length)
{
	PUCHAR	pMem1;
	PUCHAR	pMem2;
	UINT	Index;
	ASSERT((Length == 0) || (pDest && pSrc));
	pMem1 = (PUCHAR) pDest;
	pMem2 = (PUCHAR) pSrc;

	for (Index = 0; Index < Length; Index++) {
		if (pMem1 && pMem2)
			pMem1[Index] = pMem2[Index];
	}
}


VOID UserCfgExit(RTMP_ADAPTER *pAd)
{
#ifdef RT_CFG80211_SUPPORT
	/* Reset the CFG80211 Internal Flag */
	RTMP_DRIVER_80211_RESET(pAd);
#endif /* RT_CFG80211_SUPPORT */
#ifdef DOT11_N_SUPPORT
	BATableExit(pAd);
#endif /* DOT11_N_SUPPORT */
#ifdef WFA_WFD_SUPPORT
	pAd->WfdIeInBeaconLen = 0;

	if (pAd->pWfdIeInBeacon) {
		os_free_mem(pAd->pWfdIeInBeacon);
		pAd->pWfdIeInBeacon = NULL;
	}

	pAd->WfdIeInProbeReqLen = 0;

	if (pAd->pWfdIeInProbeReq) {
		os_free_mem(pAd->pWfdIeInProbeReq);
		pAd->pWfdIeInProbeReq = NULL;
	}

	pAd->WfdIeInProbeRspLen = 0;

	if (pAd->pWfdIeInProbeRsp) {
		os_free_mem(pAd->pWfdIeInProbeRsp);
		pAd->pWfdIeInProbeRsp = NULL;
	}

	pAd->WfdIeInActionPktLen = 0;

	if (pAd->pWfdIeInActionPkt) {
		os_free_mem(pAd->pWfdIeInActionPkt);
		pAd->pWfdIeInActionPkt = NULL;
	}

	pAd->WfdIeInAssocReqLen = 0;

	if (pAd->pWfdIeInAssocReq) {
		os_free_mem(pAd->pWfdIeInAssocReq);
		pAd->pWfdIeInAssocReq = NULL;
	}

	pAd->WfdIeInAssocRspLen = 0;

	if (pAd->pWfdIeInAssocRsp) {
		os_free_mem(pAd->pWfdIeInAssocRsp);
		pAd->pWfdIeInAssocRsp = NULL;
	}

#endif /* WFA_WFD_SUPPORT */
	NdisFreeSpinLock(&pAd->MacTabLock);
	RTMP_SEM_EVENT_DESTORY(&pAd->IndirectUpdateLock);
#ifdef CONFIG_AP_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
#ifdef BAND_STEERING

		if (pAd->ApCfg.BandSteering ||
			pAd->ApCfg.BndStrgTable.bEnabled)
			BndStrg_Release(pAd);

#endif /* BAND_STEERING */
#ifdef RADIUS_MAC_ACL_SUPPORT
		{
			PLIST_HEADER pListHeader = NULL;
			RT_LIST_ENTRY *pListEntry = NULL;
			UCHAR apidx = 0;

			for (apidx = 0; apidx < pAd->ApCfg.BssidNum; apidx++) {
				pListHeader = &pAd->ApCfg.MBSSID[apidx].wdev.SecConfig.RadiusMacAuthCache.cacheList;

				if (pListHeader->size == 0)
					continue;

				pListEntry = pListHeader->pHead;

				while (pListEntry != NULL) {
					removeHeadList(pListHeader);
					os_free_mem(pListEntry);
					pListEntry = pListHeader->pHead;
				}

				MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Clean [%d] Radius ACL Cache.\n", apidx));
			}
		}
#endif /* RADIUS_MAC_ACL_SUPPORT */
	}
#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT

	do {
		INT i;
		PSTA_ADMIN_CONFIG	pStaCfg = NULL;

		for (i = 0; i < MAX_MULTI_STA; i++) {
			pStaCfg = &pAd->StaCfg[i];

			if (pStaCfg->wdev.pEapolPktFromAP) {
				os_free_mem(pStaCfg->wdev.pEapolPktFromAP);
				pStaCfg->wdev.pEapolPktFromAP = NULL;
			}

#ifdef	WSC_STA_SUPPORT
			{
				PWSC_CTRL		pWscControl = NULL;
				pWscControl = &pStaCfg->wdev.WscControl;

				if (pWscControl->pWscRxBuf)
					os_free_mem(pWscControl->pWscRxBuf);

				pWscControl->pWscRxBuf = NULL;

				if (pWscControl->pWscTxBuf)
					os_free_mem(pWscControl->pWscTxBuf);

				pWscControl->pWscTxBuf = NULL;
			}
#endif /*WSC_STA_SUPPORT*/
		}
	} while (0);

#endif /* CONFIG_STA_SUPPORT */
	wdev_config_init(pAd);
#ifdef DOT11_SAE_SUPPORT
	sae_cfg_deinit(pAd, &pAd->SaeCfg);
#endif /* DOT11_SAE_SUPPORT */
}


/*
	========================================================================

	Routine Description:
		Initialize port configuration structure

	Arguments:
		Adapter						Pointer to our adapter

	Return Value:
		None

	IRQL = PASSIVE_LEVEL

	Note:

	========================================================================
*/
VOID UserCfgInit(RTMP_ADAPTER *pAd)
{
	UINT i;
	UINT key_index, bss_index;
#ifdef GREENAP_SUPPORT
	struct greenap_ctrl *greenap = &pAd->ApCfg.greenap;
#endif /* GREENAP_SUPPORT */
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("--> UserCfgInit\n"));
	/*init wifi profile*/
	wpf_init(pAd);
	pAd->IndicateMediaState = NdisMediaStateDisconnected;
	/* part I. intialize common configuration */
	pAd->CommonCfg.BasicRateBitmap = 0xF;
	pAd->CommonCfg.BasicRateBitmapOld = 0xF;
#ifdef NR_PD_DETECTION
	/* state machine state flag */
	pAd->fgLinkBw20State         = FALSE;
	pAd->fgLinkSingleRxState     = FALSE;
	pAd->fgACRstate              = FALSE;
	/* Rx Control Parameter */
	pAd->ucTestTimeoutCount      =     0;
	pAd->u4TempRxCount           =     0;
	pAd->ucLinkRssiTh            =    20;
	pAd->ucRssiTh                =    10;
	pAd->ucHighPowerRssiTh       =    25;
	pAd->ucLowPowerRssiTh        =    20;
	pAd->cLargePowerTh           =   -90;
	pAd->ucRxCountTh             =     5;
	pAd->ucTimeOutTh             =   200;  /* 20s */
	pAd->ucPerTh                 =    50;
	pAd->cNrRssiTh               =   -40;
	pAd->cChgTestPathTh          =   -30;
	/* ACR Control Parameter */
	pAd->ucACRConfidenceCnt      =     0;
	pAd->ucACRConfidenceCntTh    =    10;
	pAd->ucMaxInConfidenceCnt    =     0;
	pAd->ucMaxInConfidenceCntTh  =    10;
	pAd->cMaxInRssiTh            =   -40;
	/* Tx Control Parameter */
	pAd->ucCmwCheckCount         =     0;
	pAd->ucCmwCheckCountTh       =    20;  /* 2s */
	pAd->fgCmwInstrumBack4T      = FALSE;
	pAd->ucRssiBalanceCount      =     0;
	pAd->ucRssiIBalanceCountTh   =   100;  /* 10s */
	pAd->fgRssiBack4T            = FALSE;
	pAd->ucCableRssiTh           =    25;
	pAd->fgCmwLinkDone           = FALSE;
	pAd->ucLinkCount             =     0;
	pAd->ucLinkCountTh           =    30;
	pAd->fgLinkRSSICheck         = FALSE;
	pAd->fgWifiInitDone          = FALSE;
	pAd->fgChannelSwitchDone     = FALSE;
	pAd->fgPhyInitDone           = FALSE;
	pAd->ucCmwChannelBand        = CHANNEL_BAND_2G;
	pAd->fgApclientLink          = FALSE;
	/* Debug Log Parameter */
	pAd->u4RoundCount            =     0;
	/* manual command control function enable/disable flag */
	pAd->fgTxSpurEn              =  TRUE;
	pAd->fgNrFloating            =  TRUE;
	pAd->fgACREn                 =  TRUE;
#endif /* NR_PD_DETECTION */
#ifdef RF_LOCKDOWN
	/* disable QA Effuse Write back status by default */
	pAd->fgQAEffuseWriteBack = FALSE;
#endif /* RF_LOCKDOWN */
	/* Disable EPA flag */
	pAd->fgEPA = FALSE;
#ifdef RF_LOCKDOWN
	/* Apply Cal-Free Effuse value by default */
	pAd->fgCalFreeApply = TRUE;
	pAd->RFlockTempIdx  =    0;
	pAd->CalFreeTempIdx =    0;
#if 0
	/* ================================================== */
	/* Init the EPPROM Property Table */
	/* ================================================== */
	/*                        offset    RFlock   CalFree  */
	pAd->EEPROMCtrl[0x000] = { 0x000,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x001] = { 0x001,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x002] = { 0x002,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x003] = { 0x003,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x004] = { 0x004,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x005] = { 0x005,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x006] = { 0x006,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x007] = { 0x007,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x008] = { 0x008,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x009] = { 0x009,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x00A] = { 0x00A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x00B] = { 0x00B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x00C] = { 0x00C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x00D] = { 0x00D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x00E] = { 0x00E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x00F] = { 0x00F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x010] = { 0x010,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x011] = { 0x011,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x012] = { 0x012,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x013] = { 0x013,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x014] = { 0x014,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x015] = { 0x015,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x016] = { 0x016,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x017] = { 0x017,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x018] = { 0x018,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x019] = { 0x019,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x01A] = { 0x01A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x01B] = { 0x01B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x01C] = { 0x01C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x01D] = { 0x01D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x01E] = { 0x01E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x01F] = { 0x01F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x020] = { 0x020,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x021] = { 0x021,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x022] = { 0x022,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x023] = { 0x023,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x024] = { 0x024,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x025] = { 0x025,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x026] = { 0x026,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x027] = { 0x027,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x028] = { 0x028,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x029] = { 0x029,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x02A] = { 0x02A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x02B] = { 0x02B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x02C] = { 0x02C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x02D] = { 0x02D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x02E] = { 0x02E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x02F] = { 0x02F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x030] = { 0x030,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x031] = { 0x031,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x032] = { 0x032,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x033] = { 0x033,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x034] = { 0x034,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x035] = { 0x035,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x036] = { 0x036,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x037] = { 0x037,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x038] = { 0x038,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x039] = { 0x039,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x03A] = { 0x03A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x03B] = { 0x03B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x03C] = { 0x03C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x03D] = { 0x03D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x03E] = { 0x03E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x03F] = { 0x03F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x040] = { 0x040,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x041] = { 0x041,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x042] = { 0x042,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x043] = { 0x043,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x044] = { 0x044,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x045] = { 0x045,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x046] = { 0x046,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x047] = { 0x047,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x048] = { 0x048,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x049] = { 0x049,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x04A] = { 0x04A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x04B] = { 0x04B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x04C] = { 0x04C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x04D] = { 0x04D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x04E] = { 0x04E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x04F] = { 0x04F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x050] = { 0x050,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x051] = { 0x051,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x052] = { 0x052,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x053] = { 0x053,    FALSE,     TRUE};
	pAd->EEPROMCtrl[0x054] = { 0x054,    FALSE,     TRUE};
	pAd->EEPROMCtrl[0x055] = { 0x055,    FALSE,     TRUE};
	pAd->EEPROMCtrl[0x056] = { 0x056,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x057] = { 0x057,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x058] = { 0x058,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x059] = { 0x059,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x05A] = { 0x05A,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x05B] = { 0x05B,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x05C] = { 0x05C,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x05D] = { 0x05D,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x05E] = { 0x05E,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x05F] = { 0x05F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x060] = { 0x060,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x061] = { 0x061,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x062] = { 0x062,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x063] = { 0x063,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x064] = { 0x064,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x065] = { 0x065,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x066] = { 0x066,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x067] = { 0x067,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x068] = { 0x068,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x069] = { 0x069,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x06A] = { 0x06A,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x06B] = { 0x06B,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x06C] = { 0x06C,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x06D] = { 0x06D,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x06E] = { 0x06E,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x06F] = { 0x06F,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x070] = { 0x070,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x071] = { 0x071,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x072] = { 0x072,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x073] = { 0x073,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x074] = { 0x074,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x075] = { 0x075,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x076] = { 0x076,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x077] = { 0x077,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x078] = { 0x078,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x079] = { 0x079,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x07A] = { 0x07A,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x07B] = { 0x07B,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x07C] = { 0x07C,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x07D] = { 0x07D,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x07E] = { 0x07E,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x07F] = { 0x07F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x080] = { 0x080,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x081] = { 0x081,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x082] = { 0x082,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x083] = { 0x083,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x084] = { 0x084,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x085] = { 0x085,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x086] = { 0x086,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x087] = { 0x087,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x088] = { 0x088,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x089] = { 0x089,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x08A] = { 0x08A,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x08B] = { 0x08B,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x08C] = { 0x08C,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x08D] = { 0x08D,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x08E] = { 0x08E,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x08F] = { 0x08F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x090] = { 0x090,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x091] = { 0x091,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x092] = { 0x092,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x093] = { 0x093,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x094] = { 0x094,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x095] = { 0x095,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x096] = { 0x096,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x097] = { 0x097,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x098] = { 0x098,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x099] = { 0x099,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x09A] = { 0x09A,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x09B] = { 0x09B,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x09C] = { 0x09C,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x09D] = { 0x09D,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x09E] = { 0x09E,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x09F] = { 0x09F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0A0] = { 0x0A0,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0A1] = { 0x0A1,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0A2] = { 0x0A2,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0A3] = { 0x0A3,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0A4] = { 0x0A4,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0A5] = { 0x0A5,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0A6] = { 0x0A6,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0A7] = { 0x0A7,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0A8] = { 0x0A8,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0A9] = { 0x0A9,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0AA] = { 0x0AA,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0AB] = { 0x0AB,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0AC] = { 0x0AC,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0AD] = { 0x0AD,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0AE] = { 0x0AE,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0AF] = { 0x0AF,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0B0] = { 0x0B0,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0B1] = { 0x0B1,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0B2] = { 0x0B2,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0B3] = { 0x0B3,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0B4] = { 0x0B4,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0B5] = { 0x0B5,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0B6] = { 0x0B6,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0B7] = { 0x0B7,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0B8] = { 0x0B8,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0B9] = { 0x0B9,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0BA] = { 0x0BA,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x0BB] = { 0x0BB,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0BC] = { 0x0BC,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0BD] = { 0x0BD,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0BE] = { 0x0BE,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0BF] = { 0x0BF,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C0] = { 0x0C0,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C1] = { 0x0C1,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C2] = { 0x0C2,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C3] = { 0x0C3,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C4] = { 0x0C4,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C5] = { 0x0C5,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C6] = { 0x0C6,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C7] = { 0x0C7,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C8] = { 0x0C8,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0C9] = { 0x0C9,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0CA] = { 0x0CA,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0CB] = { 0x0CB,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0CC] = { 0x0CC,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0CD] = { 0x0CD,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0CE] = { 0x0CE,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0CF] = { 0x0CF,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D0] = { 0x0D0,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D1] = { 0x0D1,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D2] = { 0x0D2,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D3] = { 0x0D3,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D4] = { 0x0D4,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D5] = { 0x0D5,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D6] = { 0x0D6,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D7] = { 0x0D7,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D8] = { 0x0D8,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0D9] = { 0x0D9,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0DA] = { 0x0DA,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0DB] = { 0x0DB,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0DC] = { 0x0DC,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0DD] = { 0x0DD,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0DE] = { 0x0DE,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0DF] = { 0x0DF,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E0] = { 0x0E0,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E1] = { 0x0E1,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E2] = { 0x0E2,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E3] = { 0x0E3,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E4] = { 0x0E4,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E5] = { 0x0E5,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E6] = { 0x0E6,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E7] = { 0x0E7,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E8] = { 0x0E8,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0E9] = { 0x0E9,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0EA] = { 0x0EA,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0EB] = { 0x0EB,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0EC] = { 0x0EC,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0ED] = { 0x0ED,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0EE] = { 0x0EE,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0EF] = { 0x0EF,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0F0] = { 0x0F0,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0F1] = { 0x0F1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0F2] = { 0x0F2,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0F3] = { 0x0F3,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x0F4] = { 0x0F4,    FALSE,     TRUE};
	pAd->EEPROMCtrl[0x0F5] = { 0x0F5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0F6] = { 0x0F6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0F7] = { 0x0F7,    FALSE,     TRUE};
	pAd->EEPROMCtrl[0x0F8] = { 0x0F8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0F9] = { 0x0F9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0FA] = { 0x0FA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0FB] = { 0x0FB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0FC] = { 0x0FC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0FD] = { 0x0FD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0FE] = { 0x0FE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x0FF] = { 0x0FF,    FALSE,     TRUE};
	== == == == == == == == == == == == == == == == == == == == == == == == == == ==
	/*                        offset    RFlock   CalFree  */
	pAd->EEPROMCtrl[0x100] = { 0x100,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x101] = { 0x101,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x102] = { 0x102,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x103] = { 0x103,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x104] = { 0x104,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x105] = { 0x105,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x106] = { 0x106,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x107] = { 0x107,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x108] = { 0x108,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x109] = { 0x109,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x10A] = { 0x10A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x10B] = { 0x10B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x10C] = { 0x10C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x10D] = { 0x10D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x10E] = { 0x10E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x10F] = { 0x10F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x110] = { 0x110,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x111] = { 0x111,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x112] = { 0x112,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x113] = { 0x113,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x114] = { 0x114,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x115] = { 0x115,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x116] = { 0x116,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x117] = { 0x117,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x118] = { 0x118,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x119] = { 0x119,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x11A] = { 0x11A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x11B] = { 0x11B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x11C] = { 0x11C,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x11D] = { 0x11D,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x11E] = { 0x11E,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x11F] = { 0x11F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x120] = { 0x120,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x121] = { 0x121,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x122] = { 0x122,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x123] = { 0x123,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x124] = { 0x124,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x125] = { 0x125,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x126] = { 0x126,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x127] = { 0x127,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x128] = { 0x128,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x129] = { 0x129,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x12A] = { 0x12A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x12B] = { 0x12B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x12C] = { 0x12C,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x12D] = { 0x12D,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x12E] = { 0x12E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x12F] = { 0x12F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x130] = { 0x130,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x131] = { 0x131,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x132] = { 0x132,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x133] = { 0x133,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x134] = { 0x134,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x135] = { 0x135,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x136] = { 0x136,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x137] = { 0x137,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x138] = { 0x138,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x139] = { 0x139,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x13A] = { 0x13A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x13B] = { 0x13B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x13C] = { 0x13C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x13D] = { 0x13D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x13E] = { 0x13E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x13F] = { 0x13F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x140] = { 0x140,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x141] = { 0x141,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x142] = { 0x142,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x143] = { 0x143,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x144] = { 0x144,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x145] = { 0x145,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x146] = { 0x146,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x147] = { 0x147,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x148] = { 0x148,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x149] = { 0x149,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x14A] = { 0x14A,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x14B] = { 0x14B,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x14C] = { 0x14C,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x14D] = { 0x14D,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x14E] = { 0x14E,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x14F] = { 0x14F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x150] = { 0x150,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x151] = { 0x151,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x152] = { 0x152,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x153] = { 0x153,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x154] = { 0x154,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x155] = { 0x155,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x156] = { 0x156,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x157] = { 0x157,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x158] = { 0x158,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x159] = { 0x159,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x15A] = { 0x15A,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x15B] = { 0x15B,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x15C] = { 0x15C,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x15D] = { 0x15D,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x15E] = { 0x15E,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x15F] = { 0x15F,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x160] = { 0x160,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x161] = { 0x161,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x162] = { 0x162,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x163] = { 0x163,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x164] = { 0x164,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x165] = { 0x165,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x166] = { 0x166,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x167] = { 0x167,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x168] = { 0x168,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x169] = { 0x169,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x16A] = { 0x16A,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x16B] = { 0x16B,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x16C] = { 0x16C,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x16D] = { 0x16D,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x16E] = { 0x16E,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x16F] = { 0x16F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x170] = { 0x170,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x171] = { 0x171,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x172] = { 0x172,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x173] = { 0x173,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x174] = { 0x174,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x175] = { 0x175,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x176] = { 0x176,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x177] = { 0x177,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x178] = { 0x178,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x179] = { 0x179,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x17A] = { 0x17A,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x17B] = { 0x17B,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x17C] = { 0x17C,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x17D] = { 0x17D,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x17E] = { 0x17E,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x17F] = { 0x17F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x180] = { 0x180,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x181] = { 0x181,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x182] = { 0x182,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x183] = { 0x183,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x184] = { 0x184,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x185] = { 0x185,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x186] = { 0x186,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x187] = { 0x187,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x188] = { 0x188,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x189] = { 0x189,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x18A] = { 0x18A,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x18B] = { 0x18B,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x18C] = { 0x18C,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x18D] = { 0x18D,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x18E] = { 0x18E,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x18F] = { 0x18F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x190] = { 0x190,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x191] = { 0x191,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x192] = { 0x192,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x193] = { 0x193,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x194] = { 0x194,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x195] = { 0x195,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x196] = { 0x196,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x197] = { 0x197,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x198] = { 0x198,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x199] = { 0x199,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x19A] = { 0x19A,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x19B] = { 0x19B,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x19C] = { 0x19C,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x19D] = { 0x19D,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x19E] = { 0x19E,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x19F] = { 0x19F,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1A0] = { 0x1A0,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1A1] = { 0x1A1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1A2] = { 0x1A2,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1A3] = { 0x1A3,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1A4] = { 0x1A4,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1A5] = { 0x1A5,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1A6] = { 0x1A6,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1A7] = { 0x1A7,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1A8] = { 0x1A8,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1A9] = { 0x1A9,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1AA] = { 0x1AA,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1AB] = { 0x1AB,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1AC] = { 0x1AC,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1AD] = { 0x1AD,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1AE] = { 0x1AE,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1AF] = { 0x1AF,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1B0] = { 0x1B0,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1B1] = { 0x1B1,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1B2] = { 0x1B2,     TRUE,    FALSE};
	pAd->EEPROMCtrl[0x1B3] = { 0x1B3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1B4] = { 0x1B4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1B5] = { 0x1B5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1B6] = { 0x1B6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1B7] = { 0x1B7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1B8] = { 0x1B8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1B9] = { 0x1B9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1BA] = { 0x1BA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1BB] = { 0x1BB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1BC] = { 0x1BC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1BD] = { 0x1BD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1BE] = { 0x1BE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1BF] = { 0x1BF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C0] = { 0x1C0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C1] = { 0x1C1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C2] = { 0x1C2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C3] = { 0x1C3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C4] = { 0x1C4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C5] = { 0x1C5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C6] = { 0x1C6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C7] = { 0x1C7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C8] = { 0x1C8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1C9] = { 0x1C9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1CA] = { 0x1CA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1CB] = { 0x1CB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1CC] = { 0x1CC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1CD] = { 0x1CD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1CE] = { 0x1CE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1CF] = { 0x1CF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D0] = { 0x1D0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D1] = { 0x1D1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D2] = { 0x1D2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D3] = { 0x1D3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D4] = { 0x1D4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D5] = { 0x1D5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D6] = { 0x1D6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D7] = { 0x1D7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D8] = { 0x1D8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1D9] = { 0x1D9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1DA] = { 0x1DA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1DB] = { 0x1DB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1DC] = { 0x1DC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1DD] = { 0x1DD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1DE] = { 0x1DE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1DF] = { 0x1DF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E0] = { 0x1E0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E1] = { 0x1E1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E2] = { 0x1E2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E3] = { 0x1E3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E4] = { 0x1E4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E5] = { 0x1E5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E6] = { 0x1E6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E7] = { 0x1E7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E8] = { 0x1E8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1E9] = { 0x1E9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1EA] = { 0x1EA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1EB] = { 0x1EB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1EC] = { 0x1EC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1ED] = { 0x1ED,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1EE] = { 0x1EE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1EF] = { 0x1EF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F0] = { 0x1F0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F1] = { 0x1F1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F2] = { 0x1F2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F3] = { 0x1F3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F4] = { 0x1F4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F5] = { 0x1F5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F6] = { 0x1F6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F7] = { 0x1F7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F8] = { 0x1F8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1F9] = { 0x1F9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1FA] = { 0x1FA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1FB] = { 0x1FB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1FC] = { 0x1FC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1FD] = { 0x1FD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1FE] = { 0x1FE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x1FF] = { 0x1FF,    FALSE,    FALSE};
	== == == == == == == == == == == == == == == == == == == == == == == == == == ==
	/*                        offset    RFlock   CalFree  */
	pAd->EEPROMCtrl[0x200] = { 0x200,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x201] = { 0x201,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x202] = { 0x202,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x203] = { 0x203,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x204] = { 0x204,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x205] = { 0x205,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x206] = { 0x206,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x207] = { 0x207,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x208] = { 0x208,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x209] = { 0x209,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x20A] = { 0x20A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x20B] = { 0x20B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x20C] = { 0x20C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x20D] = { 0x20D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x20E] = { 0x20E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x20F] = { 0x20F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x210] = { 0x210,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x211] = { 0x211,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x212] = { 0x212,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x213] = { 0x213,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x214] = { 0x214,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x215] = { 0x215,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x216] = { 0x216,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x217] = { 0x217,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x218] = { 0x218,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x219] = { 0x219,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x21A] = { 0x21A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x21B] = { 0x21B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x21C] = { 0x21C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x21D] = { 0x21D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x21E] = { 0x21E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x21F] = { 0x21F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x220] = { 0x220,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x221] = { 0x221,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x222] = { 0x222,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x223] = { 0x223,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x224] = { 0x224,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x225] = { 0x225,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x226] = { 0x226,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x227] = { 0x227,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x228] = { 0x228,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x229] = { 0x229,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x22A] = { 0x22A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x22B] = { 0x22B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x22C] = { 0x22C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x22D] = { 0x22D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x22E] = { 0x22E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x22F] = { 0x22F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x230] = { 0x230,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x231] = { 0x231,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x232] = { 0x232,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x233] = { 0x233,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x234] = { 0x234,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x235] = { 0x235,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x236] = { 0x236,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x237] = { 0x237,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x238] = { 0x238,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x239] = { 0x239,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x23A] = { 0x23A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x23B] = { 0x23B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x23C] = { 0x23C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x23D] = { 0x23D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x23E] = { 0x23E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x23F] = { 0x23F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x240] = { 0x240,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x241] = { 0x241,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x242] = { 0x242,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x243] = { 0x243,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x244] = { 0x244,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x245] = { 0x245,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x246] = { 0x246,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x247] = { 0x247,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x248] = { 0x248,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x249] = { 0x249,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x24A] = { 0x24A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x24B] = { 0x24B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x24C] = { 0x24C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x24D] = { 0x24D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x24E] = { 0x24E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x24F] = { 0x24F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x250] = { 0x250,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x251] = { 0x251,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x252] = { 0x252,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x253] = { 0x253,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x254] = { 0x254,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x255] = { 0x255,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x256] = { 0x256,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x257] = { 0x257,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x258] = { 0x258,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x259] = { 0x259,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x25A] = { 0x25A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x25B] = { 0x25B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x25C] = { 0x25C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x25D] = { 0x25D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x25E] = { 0x25E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x25F] = { 0x25F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x260] = { 0x260,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x261] = { 0x261,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x262] = { 0x262,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x263] = { 0x263,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x264] = { 0x264,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x265] = { 0x265,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x266] = { 0x266,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x267] = { 0x267,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x268] = { 0x268,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x269] = { 0x269,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x26A] = { 0x26A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x26B] = { 0x26B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x26C] = { 0x26C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x26D] = { 0x26D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x26E] = { 0x26E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x26F] = { 0x26F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x270] = { 0x270,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x271] = { 0x271,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x272] = { 0x272,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x273] = { 0x273,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x274] = { 0x274,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x275] = { 0x275,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x276] = { 0x276,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x277] = { 0x277,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x278] = { 0x278,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x279] = { 0x279,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x27A] = { 0x27A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x27B] = { 0x27B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x27C] = { 0x27C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x27D] = { 0x27D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x27E] = { 0x27E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x27F] = { 0x27F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x280] = { 0x280,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x281] = { 0x281,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x282] = { 0x282,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x283] = { 0x283,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x284] = { 0x284,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x285] = { 0x285,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x286] = { 0x286,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x287] = { 0x287,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x288] = { 0x288,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x289] = { 0x289,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x28A] = { 0x28A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x28B] = { 0x28B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x28C] = { 0x28C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x28D] = { 0x28D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x28E] = { 0x28E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x28F] = { 0x28F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x290] = { 0x290,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x291] = { 0x291,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x292] = { 0x292,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x293] = { 0x293,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x294] = { 0x294,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x295] = { 0x295,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x296] = { 0x296,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x297] = { 0x297,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x298] = { 0x298,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x299] = { 0x299,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x29A] = { 0x29A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x29B] = { 0x29B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x29C] = { 0x29C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x29D] = { 0x29D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x29E] = { 0x29E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x29F] = { 0x29F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A0] = { 0x2A0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A1] = { 0x2A1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A2] = { 0x2A2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A3] = { 0x2A3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A4] = { 0x2A4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A5] = { 0x2A5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A6] = { 0x2A6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A7] = { 0x2A7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A8] = { 0x2A8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2A9] = { 0x2A9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2AA] = { 0x2AA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2AB] = { 0x2AB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2AC] = { 0x2AC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2AD] = { 0x2AD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2AE] = { 0x2AE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2AF] = { 0x2AF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B0] = { 0x2B0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B1] = { 0x2B1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B2] = { 0x2B2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B3] = { 0x2B3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B4] = { 0x2B4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B5] = { 0x2B5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B6] = { 0x2B6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B7] = { 0x2B7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B8] = { 0x2B8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2B9] = { 0x2B9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2BA] = { 0x2BA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2BB] = { 0x2BB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2BC] = { 0x2BC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2BD] = { 0x2BD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2BE] = { 0x2BE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2BF] = { 0x2BF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C0] = { 0x2C0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C1] = { 0x2C1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C2] = { 0x2C2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C3] = { 0x2C3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C4] = { 0x2C4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C5] = { 0x2C5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C6] = { 0x2C6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C7] = { 0x2C7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C8] = { 0x2C8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2C9] = { 0x2C9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2CA] = { 0x2CA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2CB] = { 0x2CB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2CC] = { 0x2CC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2CD] = { 0x2CD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2CE] = { 0x2CE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2CF] = { 0x2CF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D0] = { 0x2D0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D1] = { 0x2D1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D2] = { 0x2D2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D3] = { 0x2D3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D4] = { 0x2D4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D5] = { 0x2D5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D6] = { 0x2D6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D7] = { 0x2D7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D8] = { 0x2D8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2D9] = { 0x2D9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2DA] = { 0x2DA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2DB] = { 0x2DB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2DC] = { 0x2DC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2DD] = { 0x2DD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2DE] = { 0x2DE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2DF] = { 0x2DF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E0] = { 0x2E0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E1] = { 0x2E1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E2] = { 0x2E2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E3] = { 0x2E3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E4] = { 0x2E4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E5] = { 0x2E5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E6] = { 0x2E6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E7] = { 0x2E7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E8] = { 0x2E8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2E9] = { 0x2E9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2EA] = { 0x2EA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2EB] = { 0x2EB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2EC] = { 0x2EC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2ED] = { 0x2ED,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2EE] = { 0x2EE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2EF] = { 0x2EF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F0] = { 0x2F0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F1] = { 0x2F1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F2] = { 0x2F2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F3] = { 0x2F3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F4] = { 0x2F4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F5] = { 0x2F5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F6] = { 0x2F6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F7] = { 0x2F7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F8] = { 0x2F8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2F9] = { 0x2F9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2FA] = { 0x2FA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2FB] = { 0x2FB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2FC] = { 0x2FC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2FD] = { 0x2FD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2FE] = { 0x2FE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x2FF] = { 0x2FF,    FALSE,    FALSE};
	== == == == == == == == == == == == == == == == == == == == == == == == == == ==
	/*                        offset    RFlock   CalFree  */
	pAd->EEPROMCtrl[0x300] = { 0x300,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x301] = { 0x301,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x302] = { 0x302,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x303] = { 0x303,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x304] = { 0x304,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x305] = { 0x305,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x306] = { 0x306,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x307] = { 0x307,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x308] = { 0x308,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x309] = { 0x309,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x30A] = { 0x30A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x30B] = { 0x30B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x30C] = { 0x30C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x30D] = { 0x30D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x30E] = { 0x30E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x30F] = { 0x30F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x310] = { 0x310,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x311] = { 0x311,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x312] = { 0x312,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x313] = { 0x313,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x314] = { 0x314,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x315] = { 0x315,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x316] = { 0x316,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x317] = { 0x317,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x318] = { 0x318,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x319] = { 0x319,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x31A] = { 0x31A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x31B] = { 0x31B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x31C] = { 0x31C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x31D] = { 0x31D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x31E] = { 0x31E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x31F] = { 0x31F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x320] = { 0x320,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x321] = { 0x321,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x322] = { 0x322,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x323] = { 0x323,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x324] = { 0x324,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x325] = { 0x325,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x326] = { 0x326,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x327] = { 0x327,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x328] = { 0x328,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x329] = { 0x329,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x32A] = { 0x32A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x32B] = { 0x32B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x32C] = { 0x32C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x32D] = { 0x32D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x32E] = { 0x32E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x32F] = { 0x32F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x330] = { 0x330,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x331] = { 0x331,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x332] = { 0x332,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x333] = { 0x333,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x334] = { 0x334,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x335] = { 0x335,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x336] = { 0x336,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x337] = { 0x337,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x338] = { 0x338,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x339] = { 0x339,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x33A] = { 0x33A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x33B] = { 0x33B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x33C] = { 0x33C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x33D] = { 0x33D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x33E] = { 0x33E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x33F] = { 0x33F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x340] = { 0x340,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x341] = { 0x341,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x342] = { 0x342,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x343] = { 0x343,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x344] = { 0x344,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x345] = { 0x345,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x346] = { 0x346,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x347] = { 0x347,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x348] = { 0x348,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x349] = { 0x349,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x34A] = { 0x34A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x34B] = { 0x34B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x34C] = { 0x34C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x34D] = { 0x34D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x34E] = { 0x34E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x34F] = { 0x34F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x350] = { 0x350,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x351] = { 0x351,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x352] = { 0x352,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x353] = { 0x353,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x354] = { 0x354,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x355] = { 0x355,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x356] = { 0x356,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x357] = { 0x357,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x358] = { 0x358,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x359] = { 0x359,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x35A] = { 0x35A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x35B] = { 0x35B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x35C] = { 0x35C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x35D] = { 0x35D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x35E] = { 0x35E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x35F] = { 0x35F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x360] = { 0x360,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x361] = { 0x361,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x362] = { 0x362,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x363] = { 0x363,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x364] = { 0x364,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x365] = { 0x365,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x366] = { 0x366,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x367] = { 0x367,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x368] = { 0x368,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x369] = { 0x369,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x36A] = { 0x36A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x36B] = { 0x36B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x36C] = { 0x36C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x36D] = { 0x36D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x36E] = { 0x36E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x36F] = { 0x36F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x370] = { 0x370,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x371] = { 0x371,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x372] = { 0x372,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x373] = { 0x373,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x374] = { 0x374,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x375] = { 0x375,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x376] = { 0x376,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x377] = { 0x377,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x378] = { 0x378,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x379] = { 0x379,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x37A] = { 0x37A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x37B] = { 0x37B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x37C] = { 0x37C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x37D] = { 0x37D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x37E] = { 0x37E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x37F] = { 0x37F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x380] = { 0x380,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x381] = { 0x381,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x382] = { 0x382,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x383] = { 0x383,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x384] = { 0x384,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x385] = { 0x385,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x386] = { 0x386,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x387] = { 0x387,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x388] = { 0x388,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x389] = { 0x389,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x38A] = { 0x38A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x38B] = { 0x38B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x38C] = { 0x38C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x38D] = { 0x38D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x38E] = { 0x38E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x38F] = { 0x38F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x390] = { 0x390,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x391] = { 0x391,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x392] = { 0x392,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x393] = { 0x393,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x394] = { 0x394,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x395] = { 0x395,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x396] = { 0x396,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x397] = { 0x397,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x398] = { 0x398,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x399] = { 0x399,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x39A] = { 0x39A,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x39B] = { 0x39B,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x39C] = { 0x39C,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x39D] = { 0x39D,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x39E] = { 0x39E,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x39F] = { 0x39F,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A0] = { 0x3A0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A1] = { 0x3A1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A2] = { 0x3A2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A3] = { 0x3A3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A4] = { 0x3A4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A5] = { 0x3A5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A6] = { 0x3A6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A7] = { 0x3A7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A8] = { 0x3A8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3A9] = { 0x3A9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3AA] = { 0x3AA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3AB] = { 0x3AB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3AC] = { 0x3AC,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x3AD] = { 0x3AD,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x3AE] = { 0x3AE,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x3AF] = { 0x3AF,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x3B0] = { 0x3B0,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x3B1] = { 0x3B1,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x3B2] = { 0x3B2,     TRUE,     TRUE};
	pAd->EEPROMCtrl[0x3B3] = { 0x3B3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3B4] = { 0x3B4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3B5] = { 0x3B5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3B6] = { 0x3B6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3B7] = { 0x3B7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3B8] = { 0x3B8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3B9] = { 0x3B9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3BA] = { 0x3BA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3BB] = { 0x3BB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3BC] = { 0x3BC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3BD] = { 0x3BD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3BE] = { 0x3BE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3BF] = { 0x3BF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C0] = { 0x3C0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C1] = { 0x3C1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C2] = { 0x3C2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C3] = { 0x3C3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C4] = { 0x3C4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C5] = { 0x3C5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C6] = { 0x3C6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C7] = { 0x3C7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C8] = { 0x3C8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3C9] = { 0x3C9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3CA] = { 0x3CA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3CB] = { 0x3CB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3CC] = { 0x3CC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3CD] = { 0x3CD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3CE] = { 0x3CE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3CF] = { 0x3CF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D0] = { 0x3D0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D1] = { 0x3D1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D2] = { 0x3D2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D3] = { 0x3D3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D4] = { 0x3D4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D5] = { 0x3D5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D6] = { 0x3D6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D7] = { 0x3D7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D8] = { 0x3D8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3D9] = { 0x3D9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3DA] = { 0x3DA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3DB] = { 0x3DB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3DC] = { 0x3DC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3DD] = { 0x3DD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3DE] = { 0x3DE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3DF] = { 0x3DF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E0] = { 0x3E0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E1] = { 0x3E1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E2] = { 0x3E2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E3] = { 0x3E3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E4] = { 0x3E4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E5] = { 0x3E5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E6] = { 0x3E6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E7] = { 0x3E7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E8] = { 0x3E8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3E9] = { 0x3E9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3EA] = { 0x3EA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3EB] = { 0x3EB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3EC] = { 0x3EC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3ED] = { 0x3ED,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3EE] = { 0x3EE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3EF] = { 0x3EF,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F0] = { 0x3F0,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F1] = { 0x3F1,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F2] = { 0x3F2,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F3] = { 0x3F3,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F4] = { 0x3F4,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F5] = { 0x3F5,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F6] = { 0x3F6,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F7] = { 0x3F7,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F8] = { 0x3F8,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3F9] = { 0x3F9,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3FA] = { 0x3FA,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3FB] = { 0x3FB,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3FC] = { 0x3FC,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3FD] = { 0x3FD,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3FE] = { 0x3FE,    FALSE,    FALSE};
	pAd->EEPROMCtrl[0x3FF] = { 0x3FF,    FALSE,    FALSE};
	/* ================================================ */
#endif
#endif /* RF_LOCKDOWN */
#ifdef RTMP_MAC_USB
	pAd->BulkOutReq = 0;
	pAd->BulkOutComplete = 0;
	pAd->BulkOutCompleteOther = 0;
	pAd->BulkOutCompleteCancel = 0;
	pAd->bUsbTxBulkAggre = 0;
#ifdef LED_CONTROL_SUPPORT
	/* init as unsed value to ensure driver will set to MCU once.*/
	pAd->LedCntl.LedIndicatorStrength = 0xFF;
#endif /* LED_CONTROL_SUPPORT */
	pAd->CommonCfg.MaxPktOneTxBulk = 2;
	pAd->CommonCfg.TxBulkFactor = 1;
	pAd->CommonCfg.RxBulkFactor = 1;
	pAd->CommonCfg.TxPower = 100; /*mW*/
	NdisZeroMemory(pAd->CommonCfg.cTxPowerCompBackup, BAND_NUM * SKU_TABLE_BACKUP_VHT_NUM * sizeof(CHAR));
	NdisZeroMemory(&pAd->CommonCfg.IOTestParm, sizeof(pAd->CommonCfg.IOTestParm));
#endif /* RTMP_MAC_USB */

	for (key_index = 0; key_index < SHARE_KEY_NUM; key_index++) {
		for (bss_index = 0; bss_index < MAX_MBSSID_NUM(pAd) + MAX_P2P_NUM; bss_index++) {
			pAd->SharedKey[bss_index][key_index].KeyLen = 0;
			pAd->SharedKey[bss_index][key_index].CipherAlg = CIPHER_NONE;
		}
	}

	pAd->bLocalAdminMAC = FALSE;
	pAd->EepromAccess = FALSE;
	pAd->Antenna.word = 0;
#ifdef RTMP_MAC_PCI
#ifdef LED_CONTROL_SUPPORT
	pAd->LedCntl.LedIndicatorStrength = 0;
#endif /* LED_CONTROL_SUPPORT */
#endif /* RTMP_MAC_PCI */
	pAd->bAutoTxAgcA = FALSE;			/* Default is OFF*/
	pAd->bAutoTxAgcG = FALSE;			/* Default is OFF*/
#ifdef THERMAL_PROTECT_SUPPORT
	pAd->force_one_tx_stream = FALSE;
	pAd->last_thermal_pro_temp = 0;
#endif /* THERMAL_PROTECT_SUPPORT */
	pAd->RfIcType = RFIC_2820;
	/* Init timer for reset complete event*/
	pAd->bForcePrintTX = FALSE;
	pAd->bForcePrintRX = FALSE;
	pAd->bStaFifoTest = FALSE;
	pAd->bProtectionTest = FALSE;
	pAd->bHCCATest = FALSE;
	pAd->bGenOneHCCA = FALSE;
	pAd->CommonCfg.Dsifs = 10;      /* in units of usec */
	pAd->CommonCfg.TxPower = 100; /* mW*/
	pAd->CommonCfg.ucTxPowerPercentage[BAND0] = 100; /* AUTO*/
#ifdef DBDC_MODE
	pAd->CommonCfg.ucTxPowerPercentage[BAND1] = 100; /* AUTO*/
#endif /* DBDC_MODE */
	pAd->CommonCfg.ucTxPowerDefault[BAND0] = 100; /* AUTO*/
#ifdef DBDC_MODE
	pAd->CommonCfg.ucTxPowerDefault[BAND1] = 100; /* AUTO*/
#endif /* DBDC_MODE */
	pAd->CommonCfg.TxPreamble = Rt802_11PreambleAuto; /* use Long preamble on TX by defaut*/
	pAd->CommonCfg.bUseZeroToDisableFragment = FALSE;
	pAd->bDisableRtsProtect = FALSE;
	pAd->CommonCfg.UseBGProtection = 0;    /* 0: AUTO*/
	pAd->CommonCfg.bEnableTxBurst = TRUE; /* 0;	*/
	pAd->CommonCfg.SavedPhyMode = 0xff;
	pAd->CommonCfg.BandState = UNKNOWN_BAND;
	pAd->wmm_cw_min = 4;

	switch (pAd->OpMode) {
	case OPMODE_AP:
		pAd->wmm_cw_max = 6;
		break;

	case OPMODE_STA:
		pAd->wmm_cw_max = 10;
		break;
	}

#ifdef CONFIG_AP_SUPPORT
#ifdef AP_SCAN_SUPPORT
	os_zero_mem(&pAd->ApCfg.ACSCheckTime, sizeof(UINT32) * DBDC_BAND_NUM);
	os_zero_mem(&pAd->ApCfg.ACSCheckCount, sizeof(UINT32) * DBDC_BAND_NUM);
#endif /* AP_SCAN_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */

#ifdef CONFIG_AP_SUPPORT
	os_zero_mem(&pAd->AutoChSelCtrl, sizeof(AUTOCH_SEL_CTRL));
#endif/* CONFIG_AP_SUPPORT */

#ifdef CARRIER_DETECTION_SUPPORT
	pAd->CommonCfg.CarrierDetect.delta = CARRIER_DETECT_DELTA;
	pAd->CommonCfg.CarrierDetect.div_flag = CARRIER_DETECT_DIV_FLAG;
	pAd->CommonCfg.CarrierDetect.criteria = CARRIER_DETECT_CRITIRIA(pAd);
	pAd->CommonCfg.CarrierDetect.threshold = CARRIER_DETECT_THRESHOLD;
	pAd->CommonCfg.CarrierDetect.recheck1 = CARRIER_DETECT_RECHECK_TIME;
	pAd->CommonCfg.CarrierDetect.CarrierGoneThreshold = CARRIER_GONE_TRESHOLD;
	pAd->CommonCfg.CarrierDetect.VGA_Mask = CARRIER_DETECT_DEFAULT_MASK;
	pAd->CommonCfg.CarrierDetect.Packet_End_Mask = CARRIER_DETECT_DEFAULT_MASK;
	pAd->CommonCfg.CarrierDetect.Rx_PE_Mask = CARRIER_DETECT_DEFAULT_MASK;
#endif /* CARRIER_DETECTION_SUPPORT */
#ifdef DFS_SUPPORT
	pAd->CommonCfg.RadarDetect.bDfsInit = FALSE;
#endif /* DFS_SUPPORT */
	pAd->Dot11_H.ChMovingTime = 65;
#ifdef UAPSD_SUPPORT
#ifdef CONFIG_AP_SUPPORT
	{
		UINT32 IdMbss;

		for (IdMbss = 0; IdMbss < HW_BEACON_MAX_NUM; IdMbss++)
			UAPSD_INFO_INIT(&pAd->ApCfg.MBSSID[IdMbss].wdev.UapsdInfo);
	}
#endif /* CONFIG_AP_SUPPORT */
#endif /* UAPSD_SUPPORT */
	pAd->CommonCfg.bNeedSendTriggerFrame = FALSE;
	pAd->CommonCfg.TriggerTimerCount = 0;
	pAd->CommonCfg.bAPSDForcePowerSave = FALSE;
	/*pAd->CommonCfg.bCountryFlag = FALSE;*/
	/*pAd->CommonCfg.TxStream = 0;*/
	/*pAd->CommonCfg.RxStream = 0;*/
#ifdef DOT11_N_SUPPORT
	NdisZeroMemory(&pAd->CommonCfg.HtCapability, sizeof(pAd->CommonCfg.HtCapability));
	pAd->bBroadComHT = FALSE;
	pAd->CommonCfg.bRdg = FALSE;
#ifdef DOT11N_DRAFT3
	pAd->CommonCfg.Dot11OBssScanPassiveDwell = dot11OBSSScanPassiveDwell;	/* Unit : TU. 5~1000*/
	pAd->CommonCfg.Dot11OBssScanActiveDwell = dot11OBSSScanActiveDwell;	/* Unit : TU. 10~1000*/
	pAd->CommonCfg.Dot11BssWidthTriggerScanInt = dot11BSSWidthTriggerScanInterval;	/* Unit : Second	*/
	pAd->CommonCfg.Dot11OBssScanPassiveTotalPerChannel = dot11OBSSScanPassiveTotalPerChannel;	/* Unit : TU. 200~10000*/
	pAd->CommonCfg.Dot11OBssScanActiveTotalPerChannel = dot11OBSSScanActiveTotalPerChannel;	/* Unit : TU. 20~10000*/
	pAd->CommonCfg.Dot11BssWidthChanTranDelayFactor = dot11BSSWidthChannelTransactionDelayFactor;
	pAd->CommonCfg.Dot11OBssScanActivityThre = dot11BSSScanActivityThreshold;	/* Unit : percentage*/
	pAd->CommonCfg.Dot11BssWidthChanTranDelay = (pAd->CommonCfg.Dot11BssWidthTriggerScanInt *
			pAd->CommonCfg.Dot11BssWidthChanTranDelayFactor);
	pAd->CommonCfg.bBssCoexEnable =
		TRUE; /* by default, we enable this feature, you can disable it via the profile or ioctl command*/
	pAd->CommonCfg.BssCoexApCntThr = 0;
	pAd->CommonCfg.Bss2040NeedFallBack = 0;
#endif  /* DOT11N_DRAFT3 */
	pAd->CommonCfg.bRcvBSSWidthTriggerEvents = FALSE;
	pAd->CommonCfg.BACapability.field.MMPSmode = MMPS_DISABLE;
	pAd->CommonCfg.BACapability.field.MpduDensity = 0;
	pAd->CommonCfg.BACapability.field.Policy = IMMED_BA;
	pAd->CommonCfg.BACapability.field.RxBAWinLimit = 64; /*32;*/
	pAd->CommonCfg.BACapability.field.TxBAWinLimit = 64; /*32;*/
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("--> UserCfgInit. BACapability = 0x%x\n",
			 pAd->CommonCfg.BACapability.word));
	pAd->CommonCfg.BACapability.field.AutoBA = FALSE;
	BATableInit(pAd, &pAd->BATable);
	pAd->CommonCfg.bExtChannelSwitchAnnouncement = 1;
	pAd->CommonCfg.bMIMOPSEnable = TRUE;
	pAd->CommonCfg.bBADecline = FALSE;
	pAd->CommonCfg.bDisableReordering = FALSE;

	if (pAd->MACVersion == 0x28720200)
		pAd->CommonCfg.TxBASize = 13; /*by Jerry recommend*/
	else
		pAd->CommonCfg.TxBASize = 7;

	pAd->CommonCfg.REGBACapability.word = pAd->CommonCfg.BACapability.word;
#endif /* DOT11_N_SUPPORT */
	pAd->CommonCfg.TxRate = RATE_6;
	pAd->CommonCfg.BeaconPeriod = 100;     /* in mSec*/
#ifdef STREAM_MODE_SUPPORT

	if (pAd->chipCap.FlgHwStreamMode) {
		pAd->CommonCfg.StreamMode = 3;
		pAd->CommonCfg.StreamModeMCS = 0x0B0B;
		NdisMoveMemory(&pAd->CommonCfg.StreamModeMac[0][0],
					   BROADCAST_ADDR, MAC_ADDR_LEN);
	}

#endif /* STREAM_MODE_SUPPORT */
#ifdef TXBF_SUPPORT
	pAd->CommonCfg.ETxBfNoncompress = 0;
	pAd->CommonCfg.ETxBfIncapable = 0;
#endif /* TXBF_SUPPORT */
#if defined(NEW_RATE_ADAPT_SUPPORT) || defined(RATE_ADAPT_AGBS_SUPPORT)
	pAd->CommonCfg.lowTrafficThrd = 2;
	pAd->CommonCfg.TrainUpRule = 2; /* 1; */
	pAd->CommonCfg.TrainUpRuleRSSI = -70; /* 0; */
	pAd->CommonCfg.TrainUpLowThrd = 90;
	pAd->CommonCfg.TrainUpHighThrd = 110;
#endif /* defined(NEW_RATE_ADAPT_SUPPORT) || defined(RATE_ADAPT_AGBS_SUPPORT) */
#ifdef MCAST_RATE_SPECIFIC
	pAd->CommonCfg.MCastPhyMode.word = pAd->MacTab.Content[MCAST_WCID].HTPhyMode.word;
	pAd->CommonCfg.MCastPhyMode_5G.word = pAd->MacTab.Content[MCAST_WCID].HTPhyMode.word;
#endif /* MCAST_RATE_SPECIFIC */
	/* WFA policy - disallow TH rate in WEP or TKIP cipher */
	pAd->CommonCfg.HT_DisallowTKIP = TRUE;
	/* Frequency for rate adaptation */
	pAd->ra_interval = DEF_RA_TIME_INTRVAL;
	pAd->ra_fast_interval = DEF_QUICK_RA_TIME_INTERVAL;
#ifdef AGS_SUPPORT

	if (pAd->rateAlg == RATE_ALG_AGS)
		pAd->ra_fast_interval = AGS_QUICK_RA_TIME_INTERVAL;

#endif /* AGS_SUPPORT */
	pAd->CommonCfg.bRalinkBurstMode = FALSE;
	/* global variables mXXXX used in MAC protocol state machines*/
	OPSTATUS_SET_FLAG(pAd, fOP_STATUS_RECEIVE_DTIM);
	OPSTATUS_CLEAR_FLAG(pAd, fOP_STATUS_ADHOC_ON);
	/* PHY specification*/
	OPSTATUS_CLEAR_FLAG(pAd, fOP_STATUS_SHORT_PREAMBLE_INUSED);  /* CCK use LONG preamble*/
	/* Default for extra information is not valid*/
	pAd->ExtraInfo = EXTRA_INFO_CLEAR;
#ifdef CONFIG_AP_SUPPORT
	/* Default Config change flag*/
	pAd->bConfigChanged = FALSE;
#ifdef GREENAP_SUPPORT
	greenap_init(greenap);
#endif /* GREENAP_SUPPORT */
#endif
	/*
		part III. AP configurations
	*/
#ifdef CONFIG_AP_SUPPORT
#if defined(P2P_APCLI_SUPPORT) || defined(RT_CFG80211_P2P_SUPPORT) || defined(CFG80211_MULTI_STA)
#else
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd)
#endif /* P2P_APCLI_SUPPORT || RT_CFG80211_P2P_SUPPORT */
	{
		/* Set MBSS Default Configurations*/
		UCHAR j;
		pAd->ApCfg.BssidNum = MAX_MBSSID_NUM(pAd);

		for (j = BSS0; j < pAd->ApCfg.BssidNum; j++) {
			BSS_STRUCT *mbss = &pAd->ApCfg.MBSSID[j];
			struct wifi_dev *wdev = &pAd->ApCfg.MBSSID[j].wdev;
#ifdef DOT11V_WNM_SUPPORT
			WNM_CONFIG *wnm_cfg = &pAd->ApCfg.MBSSID[j].WnmCfg;
			wnm_cfg->bDot11vWNM_BSSEnable = 1;
#endif /* DOT11V_WNM_SUPPORT */
#ifdef DOT1X_SUPPORT
			/* PMK cache setting*/
			mbss->PMKCachePeriod = (10 * 60 * OS_HZ); /* unit : tick(default: 10 minute)*/
			/* dot1x related per BSS */
			mbss->wdev.SecConfig.radius_srv_num = 0;
			mbss->wdev.SecConfig.NasIdLen = 0;
			mbss->wdev.SecConfig.IEEE8021X = FALSE;
			mbss->wdev.SecConfig.PreAuth = FALSE;
#ifdef RADIUS_MAC_ACL_SUPPORT
			NdisZeroMemory(&mbss->wdev.SecConfig.RadiusMacAuthCache, sizeof(RT_802_11_RADIUS_ACL));
			/* Default Timeout Value for 1xDaemon Radius ACL Cache */
			mbss->wdev.SecConfig.RadiusMacAuthCacheTimeout = 30;
#endif /* RADIUS_MAC_ACL_SUPPORT */
#endif /* DOT1X_SUPPORT */
			/* VLAN related */
			mbss->wdev.VLAN_VID = 0;
			/* Default MCS as AUTO*/
			wdev->bAutoTxRateSwitch = TRUE;
			wdev->DesiredTransmitSetting.field.MCS = MCS_AUTO;
			/* Default is zero. It means no limit.*/
			mbss->MaxStaNum = 0;
			mbss->StaCount = 0;
#ifdef WSC_AP_SUPPORT
			wdev->WscSecurityMode = 0xff;
			{
				PWSC_CTRL pWscControl;
				INT idx;
#ifdef WSC_V2_SUPPORT
				PWSC_V2_INFO	pWscV2Info;
#endif /* WSC_V2_SUPPORT */
				/*
					WscControl cannot be zero here, because WscControl timers are initial in MLME Initialize
					and MLME Initialize is called before UserCfgInit.
				*/
				pWscControl = &wdev->WscControl;
				NdisZeroMemory(&pWscControl->RegData, sizeof(WSC_REG_DATA));
				NdisZeroMemory(&pAd->CommonCfg.WscStaPbcProbeInfo, sizeof(WSC_STA_PBC_PROBE_INFO));
				pWscControl->WscMode = 1;
				pWscControl->WscConfStatus = 1;
#ifdef WSC_V2_SUPPORT
				pWscControl->WscConfigMethods = 0x238C;
#else
				pWscControl->WscConfigMethods = 0x0084;
#endif /* WSC_V2_SUPPORT */
#ifdef WSC_NFC_SUPPORT
				pWscControl->WscConfigMethods |= WPS_CONFIG_METHODS_ENT;
#endif /* WSC_NFC_SUPPORT */
#ifdef P2P_SUPPORT
				pWscControl->WscConfigMethods |= 0x0108;
#endif /* P2P_SUPPORT */
				pWscControl->RegData.ReComputePke = 1;
				pWscControl->lastId = 1;
				/* pWscControl->EntryIfIdx = (MIN_NET_DEVICE_FOR_MBSSID | j); */
				pWscControl->WscRejectSamePinFromEnrollee = FALSE;
				pAd->CommonCfg.WscPBCOverlap = FALSE;
#ifdef P2P_SUPPORT
				/*
					Set defaule value of WscConfMode to be (WSC_REGISTRAR | WSC_ENROLLEE) for WiFi P2P.
				*/
				pWscControl->WscConfMode = (WSC_REGISTRAR | WSC_ENROLLEE);
#else /* P2P_SUPPORT */
				pWscControl->WscConfMode = 0;
#endif /* !P2P_SUPPORT */
				pWscControl->WscStatus = 0;
				pWscControl->WscState = 0;
				pWscControl->WscPinCode = 0;
				pWscControl->WscLastPinFromEnrollee = 0;
				pWscControl->WscEnrollee4digitPinCode = FALSE;
				pWscControl->WscEnrolleePinCode = 0;
				pWscControl->WscSelReg = 0;
				pWscControl->WscUseUPnP = 0;
				pWscControl->bWCNTest = FALSE;
				pWscControl->WscKeyASCII = 0; /* default, 0 (64 Hex) */

				/*
					Enrollee 192 random bytes for DH key generation
				*/
				for (idx = 0; idx < 192; idx++)
					pWscControl->RegData.EnrolleeRandom[idx] = RandomByte(pAd);

				/* Enrollee Nonce, first generate and save to Wsc Control Block*/
				for (idx = 0; idx < 16; idx++)
					pWscControl->RegData.SelfNonce[idx] = RandomByte(pAd);

				NdisZeroMemory(&pWscControl->WscDefaultSsid, sizeof(NDIS_802_11_SSID));
				NdisZeroMemory(&pWscControl->Wsc_Uuid_Str[0], UUID_LEN_STR);
				NdisZeroMemory(&pWscControl->Wsc_Uuid_E[0], UUID_LEN_HEX);
				pWscControl->bCheckMultiByte = FALSE;
				pWscControl->bWscAutoTigeer = FALSE;
				pWscControl->bWscFragment = FALSE;
				pWscControl->WscFragSize = 128;
#if 0
				/*
				    Carter move to rtmp_ap_init,
				    use ApCfg.BssidNum to allocate pkt for actually use number.
				    to aovid allocating pkt for non-use BSSID struct, then cause memory leak.
				*/
				pWscControl->WscRxBufLen = 0;
				pWscControl->pWscRxBuf = NULL;
				os_alloc_mem(pAd, &pWscControl->pWscRxBuf, MGMT_DMA_BUFFER_SIZE);

				if (pWscControl->pWscRxBuf)
					NdisZeroMemory(pWscControl->pWscRxBuf, MGMT_DMA_BUFFER_SIZE);

				pWscControl->WscTxBufLen = 0;
				pWscControl->pWscTxBuf = NULL;
				os_alloc_mem(pAd, &pWscControl->pWscTxBuf, MGMT_DMA_BUFFER_SIZE);

				if (pWscControl->pWscTxBuf)
					NdisZeroMemory(pWscControl->pWscTxBuf, MGMT_DMA_BUFFER_SIZE);

#endif
				initList(&pWscControl->WscPeerList);
				NdisAllocateSpinLock(pAd, &pWscControl->WscPeerListSemLock);
				pWscControl->PinAttackCount = 0;
				pWscControl->bSetupLock = FALSE;
#ifdef WSC_V2_SUPPORT
				pWscV2Info = &pWscControl->WscV2Info;
				pWscV2Info->bWpsEnable = TRUE;
				pWscV2Info->ExtraTlv.TlvLen = 0;
				pWscV2Info->ExtraTlv.TlvTag = 0;
				pWscV2Info->ExtraTlv.pTlvData = NULL;
				pWscV2Info->ExtraTlv.TlvType = TLV_ASCII;
				pWscV2Info->bEnableWpsV2 = TRUE;
				pWscControl->SetupLockTime = WSC_WPS_AP_SETUP_LOCK_TIME;
				pWscControl->MaxPinAttack = WSC_WPS_AP_MAX_PIN_ATTACK;
#ifdef WSC_NFC_SUPPORT
				pWscControl->NfcPasswdCaculate = 2;
#endif /* WSC_NFC_SUPPORT */
#endif /* WSC_V2_SUPPORT */
			}
#endif /* WSC_AP_SUPPORT */
#ifdef EASY_CONFIG_SETUP
			AutoProvisionGenWpsPTK(pAd, j);
			mbss->EasyConfigInfo.RssiThreshold = -50;
			mbss->EasyConfigInfo.bEnable = TRUE;
			NdisZeroMemory(mbss->EasyConfigInfo.WpsPinCode, MAC_ADDR_LEN);
#endif /* EASY_CONFIG_SETUP */
#ifdef WAC_SUPPORT
			mbss->EasyConfigInfo.bEnableWAC = TRUE;
			initList(&mbss->EasyConfigInfo.WAC_PeerList);
			NdisAllocateSpinLock(pAd, &mbss->EasyConfigInfo.WAC_PeerListSemLock);
#ifdef WAC_QOS_PRIORITY
			initList(&mbss->EasyConfigInfo.WAC_ForcePriorityList);
			NdisAllocateSpinLock(pAd, &mbss->EasyConfigInfo.WAC_ForcePriorityListSemLock);
#endif /* WAC_QOS_PRIORITY */
			mbss->EasyConfigInfo.pVendorInfoForBeacon = NULL;
			mbss->EasyConfigInfo.pVendorInfoForProbeRsp = NULL;
#endif /* WAC_SUPPORT */

			for (i = 0; i < WLAN_MAX_NUM_OF_TIM; i++)
				mbss->wdev.bcn_buf.TimBitmaps[i] = 0;
		}

#ifdef DOT1X_SUPPORT
		/* PMK cache setting*/
		NdisZeroMemory(&pAd->ApCfg.PMKIDCache, sizeof(NDIS_AP_802_11_PMKID));
#endif /* DOT1X_SUPPORT */
		pAd->ApCfg.DtimCount  = 0;
		pAd->ApCfg.DtimPeriod = DEFAULT_DTIM_PERIOD;
		pAd->ApCfg.ErpIeContent = 0;
		pAd->ApCfg.StaIdleTimeout = MAC_TABLE_AGEOUT_TIME;
		pAd->ApCfg.BANClass3Data = FALSE;
#ifdef IDS_SUPPORT
		/* Default disable IDS threshold and reset all IDS counters*/
		pAd->ApCfg.IdsEnable = FALSE;
		pAd->ApCfg.AuthFloodThreshold = 0;
		pAd->ApCfg.AssocReqFloodThreshold = 0;
		pAd->ApCfg.ReassocReqFloodThreshold = 0;
		pAd->ApCfg.ProbeReqFloodThreshold = 0;
		pAd->ApCfg.DisassocFloodThreshold = 0;
		pAd->ApCfg.DeauthFloodThreshold = 0;
		pAd->ApCfg.EapReqFloodThreshold = 0;
		RTMPClearAllIdsCounter(pAd);
#endif /* IDS_SUPPORT */
#ifdef WDS_SUPPORT
		APWdsInitialize(pAd);
#endif /* WDS_SUPPORT*/
#ifdef WSC_INCLUDED
		pAd->WriteWscCfgToDatFile = 0xFF;
		pAd->WriteWscCfgToAr9DatFile = FALSE;
#ifdef CONFIG_AP_SUPPORT
#if defined(RTMP_PCI_SUPPORT) && defined(RTMP_RBUS_SUPPORT)
#ifdef __ECOS
		pAd->bWscDriverAutoUpdateCfg = TRUE;
#else
		pAd->bWscDriverAutoUpdateCfg = (IS_RBUS_INF(pAd)) ? FALSE : TRUE;
#endif
#else
#ifdef RTMP_RBUS_SUPPORT
#ifdef __ECOS
		pAd->bWscDriverAutoUpdateCfg = TRUE;
#else
		pAd->bWscDriverAutoUpdateCfg = FALSE;
#endif /* __ECOS */
#else
		pAd->bWscDriverAutoUpdateCfg = TRUE;
#endif
#endif /* defined(RTMP_PCI_SUPPORT) && defined (RTMP_RBUS_SUPPORT) */
#endif /* CONFIG_AP_SUPPORT */
#endif /* WSC_INCLUDED */
#ifdef APCLI_SUPPORT
		pAd->ApCfg.FlgApCliIsUapsdInfoUpdated = FALSE;
#ifdef APCLI_CERT_SUPPORT
		pAd->bApCliCertTest = FALSE;
#endif /* APCLI_CERT_SUPPORT */
		pAd->ApCfg.ApCliNum = MAX_APCLI_NUM;

		for (j = 0; j < MAX_APCLI_NUM; j++) {
			APCLI_STRUCT *apcli_entry = &pAd->ApCfg.ApCliTab[j];
			struct wifi_dev *wdev = &apcli_entry->wdev;
#ifdef APCLI_AUTO_CONNECT_SUPPORT
			apcli_entry->AutoConnectFlag = FALSE;
#endif /* APCLI_AUTO_CONNECT_SUPPORT */
			wdev->bAutoTxRateSwitch = TRUE;
			wdev->DesiredTransmitSetting.field.MCS = MCS_AUTO;
			apcli_entry->wdev.UapsdInfo.bAPSDCapable = FALSE;
			apcli_entry->bBlockAssoc = FALSE;
#ifdef WPA_SUPPLICANT_SUPPORT
			apcli_entry->wdev.IEEE8021X = FALSE;
			apcli_entry->wpa_supplicant_info.IEEE8021x_required_keys = FALSE;
			apcli_entry->wpa_supplicant_info.bRSN_IE_FromWpaSupplicant = FALSE;
			apcli_entry->wpa_supplicant_info.bLostAp = FALSE;
			apcli_entry->bScanReqIsFromWebUI = FALSE;
			apcli_entry->bConfigChanged = FALSE;
			apcli_entry->wpa_supplicant_info.DesireSharedKeyId = 0;
			apcli_entry->wpa_supplicant_info.WpaSupplicantUP = WPA_SUPPLICANT_DISABLE;
			apcli_entry->wpa_supplicant_info.WpaSupplicantScanCount = 0;
			apcli_entry->wpa_supplicant_info.pWpsProbeReqIe = NULL;
			apcli_entry->wpa_supplicant_info.WpsProbeReqIeLen = 0;
			apcli_entry->wpa_supplicant_info.pWpaAssocIe = NULL;
			apcli_entry->wpa_supplicant_info.WpaAssocIeLen = 0;
			apcli_entry->SavedPMKNum = 0;
			RTMPZeroMemory(apcli_entry->SavedPMK, (PMKID_NO * sizeof(BSSID_INFO)));
#endif/*WPA_SUPPLICANT_SUPPORT*/
#ifdef APCLI_CONNECTION_TRIAL
			apcli_entry->TrialCh = 0;/* if the channel is 0, AP will connect the rootap is in the same channel with ra0. */
#endif /* APCLI_CONNECTION_TRIAL */
#ifdef APCLI_CERT_SUPPORT
			apcli_entry->NeedFallback = FALSE;
#endif /* APCLI_CERT_SUPPORT */
#ifdef WSC_AP_SUPPORT
			apcli_entry->WscControl.WscApCliScanMode = TRIGGER_FULL_SCAN;
#endif /* WSC_AP_SUPPORT */
		}

#endif /* APCLI_SUPPORT */
		pAd->ApCfg.EntryClientCount = 0;
	}
#endif /* CONFIG_AP_SUPPORT */
#ifdef ETH_CONVERT_SUPPORT

	if (pAd->OpMode == OPMODE_STA) {
		NdisZeroMemory(pAd->EthConvert.EthCloneMac, MAC_ADDR_LEN);
		pAd->EthConvert.ECMode = ETH_CONVERT_MODE_DISABLE;
		pAd->EthConvert.CloneMacVaild = FALSE;
		/*pAd->EthConvert.nodeCount = 0;*/
		NdisZeroMemory(pAd->EthConvert.SSIDStr, MAX_LEN_OF_SSID);
		pAd->EthConvert.SSIDStrLen = 0;
		pAd->EthConvert.macAutoLearn = FALSE;
	}

#endif /* ETH_CONVERT_SUPPORT */
	/*
		part IV. others
	*/
	/* dynamic BBP R66:sensibity tuning to overcome background noise*/
	pAd->BbpTuning.bEnable = TRUE;
	pAd->BbpTuning.FalseCcaLowerThreshold = 100;
	pAd->BbpTuning.FalseCcaUpperThreshold = 512;
	pAd->BbpTuning.R66Delta = 4;
	pAd->Mlme.bEnableAutoAntennaCheck = TRUE;
	/* Also initial R66CurrentValue, RTUSBResumeMsduTransmission might use this value.*/
	/* if not initial this value, the default value will be 0.*/
	pAd->BbpTuning.R66CurrentValue = 0x38;
#ifdef RTMP_BBP
	pAd->Bbp94 = BBPR94_DEFAULT;
#endif /* RTMP_BBP */
	pAd->BbpForCCK = FALSE;
	/* initialize MAC table and allocate spin lock*/
	NdisZeroMemory(&pAd->MacTab, sizeof(MAC_TABLE));
	InitializeQueueHeader(&pAd->MacTab.McastPsQueue);
	NdisAllocateSpinLock(pAd, &pAd->MacTabLock);
	/*RTMPInitTimer(pAd, &pAd->RECBATimer, RECBATimerTimeout, pAd, TRUE);*/
	/*RTMPSetTimer(&pAd->RECBATimer, REORDER_EXEC_INTV);*/
#ifdef MESH_SUPPORT
	pAd->MeshTab.wdev.AuthMode = Ndis802_11AuthModeOpen;
	pAd->MeshTab.wdev.WepStatus = Ndis802_11EncryptionDisabled;
	pAd->MeshTab.wdev.DefaultKeyId = 0;
#endif /* MESH_SUPPORT */
	pAd->CommonCfg.bWiFiTest = FALSE;
#ifdef RTMP_MAC_PCI
	pAd->bPCIclkOff = FALSE;
#endif /* RTMP_MAC_PCI */
#ifdef CONFIG_AP_SUPPORT
	pAd->ApCfg.EntryLifeCheck = MAC_ENTRY_LIFE_CHECK_CNT;
#ifdef DOT11R_FT_SUPPORT
	FT_CfgInitial(pAd);
#endif /* DOT11R_FT_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */
#ifdef DOT11_SAE_SUPPORT
	sae_cfg_init(pAd, &pAd->SaeCfg);
#endif /* DOT11_SAE_SUPPORT */
	pAd->RxAnt.Pair1PrimaryRxAnt = 0;
	pAd->RxAnt.Pair1SecondaryRxAnt = 1;
	pAd->RxAnt.EvaluatePeriod = 0;
	pAd->RxAnt.RcvPktNumWhenEvaluate = 0;
#ifdef CONFIG_AP_SUPPORT
	pAd->RxAnt.Pair1AvgRssiGroup1[0] = pAd->RxAnt.Pair1AvgRssiGroup1[1] = 0;
	pAd->RxAnt.Pair1AvgRssiGroup2[0] = pAd->RxAnt.Pair1AvgRssiGroup2[1] = 0;
#endif /* CONFIG_AP_SUPPORT */
#ifdef ANT_DIVERSITY_SUPPORT
	pAd->CommonCfg.RxAntDiversityCfg = ANT_DIVERSITY_DEFAULT;
	pAd->CommonCfg.bSWRxAntDiversity = FALSE;
	pAd->CommonCfg.bHWRxAntDiversity = FALSE;
	pAd->CommonCfg.nAntEval_Threshold = -55; /* dBm */
	pAd->CommonCfg.nAntMiss_Threshold = 7;	/* RX antenna mismatch threshold */
	pAd->CommonCfg.nAntMiss_Cnt = 0;		/* RX antenna mismatch count */
	pAd->CommonCfg.bAntEvalEnable = FALSE;
#endif /* ANT_DIVERSITY_SUPPORT */
#ifdef TXRX_SW_ANTDIV_SUPPORT
	pAd->chipCap.bTxRxSwAntDiv = FALSE;
#endif /* TXRX_SW_ANTDIV_SUPPORT */
#if 0
#ifdef CONFIG_STA_SUPPORT
	RTMP_SET_PSFLAG(pAd, fRTMP_PS_CAN_GO_SLEEP);
#endif /* CONFIG_STA_SUPPORT */
#endif
#if defined(AP_SCAN_SUPPORT) || defined(CONFIG_STA_SUPPORT)

	for (i = 0; i < MAX_LEN_OF_BSS_TABLE; i++) {
		BSS_ENTRY *pBssEntry = &pAd->ScanTab.BssEntry[i];

		if (pAd->ProbeRespIE[i].pIe)
			pBssEntry->pVarIeFromProbRsp = pAd->ProbeRespIE[i].pIe;
		else
			pBssEntry->pVarIeFromProbRsp = NULL;
	}

#endif /* defined(AP_SCAN_SUPPORT) || defined(CONFIG_STA_SUPPORT) */
#ifdef WSC_INCLUDED
	NdisZeroMemory(&pAd->CommonCfg.WscStaPbcProbeInfo, sizeof(WSC_STA_PBC_PROBE_INFO));
	pAd->CommonCfg.WscPBCOverlap = FALSE;
#endif /* WSC_INCLUDED */
#if defined(CONFIG_WIFI_PKT_FWD) || defined(CONFIG_WIFI_PKT_FWD_MODULE)

	if (IS_MT7615(pAd) || IS_MT7622(pAd) || IS_P18(pAd) || IS_MT7663(pAd))
		if (wf_fwd_set_cb_num != NULL)
			wf_fwd_set_cb_num(PACKET_BAND_CB, RECV_FROM_CB);

#endif /* CONFIG_WIFI_PKT_FWD */
#ifdef RMTP_RBUS_SUPPORT
#ifdef VIDEO_TURBINE_SUPPORT
	VideoConfigInit(pAd);
#endif /* VIDEO_TURBINE_SUPPORT */
#endif /* RMTP_RBUS_SUPPORT */
#ifdef P2P_SUPPORT
	P2pCfgInit(pAd);
#endif /* P2P_SUPPORT */
#ifdef WFD_SUPPORT
	WfdCfgInit(pAd);
#endif /* WFD_SUPPORT */
#if (defined(WOW_SUPPORT) && defined(RTMP_MAC_USB)) || defined(NEW_WOW_SUPPORT) || defined(MT_WOW_SUPPORT)
	pAd->WOW_Cfg.bEnable = FALSE;
	pAd->WOW_Cfg.bWOWFirmware = FALSE;	/* load normal firmware */
	pAd->WOW_Cfg.bInBand = TRUE;		/* use in-band signal */
	pAd->WOW_Cfg.nSelectedGPIO = 2;
	pAd->WOW_Cfg.nDelay = 3; /* (3+1)*3 = 12 sec */
	pAd->WOW_Cfg.nHoldTime = 1000;	/* unit is us */
	pAd->WOW_Cfg.nWakeupInterface = pAd->chipCap.nWakeupInterface; /* WOW_WAKEUP_BY_USB; */
	pAd->WOW_Cfg.bGPIOHighLow = WOW_GPIO_LOW_TO_HIGH;
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("WOW Enable %d, WOWFirmware %d\n", pAd->WOW_Cfg.bEnable,
			 pAd->WOW_Cfg.bWOWFirmware));
#endif /* (defined(WOW_SUPPORT) && defined(RTMP_MAC_USB)) || defined(NEW_WOW_SUPPORT) || defined(MT_WOW_SUPPORT) */
	/* 802.11H and DFS related params*/
	pAd->Dot11_H.CSCount = 0;
	pAd->Dot11_H.CSPeriod = 10;

	pAd->CommonCfg.ChGrpEn = 0;
	NdisZeroMemory(pAd->CommonCfg.ChGrpChannelList, (MAX_NUM_OF_CHANNELS)*sizeof(UCHAR));
	pAd->CommonCfg.ChGrpChannelNum = 0;

#ifdef MT_DFS_SUPPORT
	DfsParamInit(pAd);/* Jelly20150311 */
#endif
#ifdef CONFIG_AP_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd)
	pAd->Dot11_H.RDMode = RD_SILENCE_MODE;
#endif
	pAd->Dot11_H.wdev_count = 0;
	pAd->Dot11_H.ChMovingTime = 65;
	pAd->Dot11_H.bDFSIndoor = 1;
	PartialScanInit(pAd);
#ifdef APCLI_SUPPORT
#ifdef APCLI_AUTO_CONNECT_SUPPORT

	for (i = 0; i < MAX_APCLI_NUM; i++) {
		pAd->ApCfg.ApCliAutoConnectType[i] = TRIGGER_SCAN_BY_USER; /* User Trigger SCAN by default */
		pAd->ApCfg.ApCliAutoConnectRunning[i] = FALSE;
	}

	pAd->ApCfg.ApCliAutoConnectChannelSwitching = FALSE;
#endif /* APCLI_AUTO_CONNECT_SUPPORT */
	for (i = 0; i < MAX_APCLI_NUM; i++) {
		pAd->ApCfg.bPartialScanEnable[i] = FALSE;
		pAd->ApCfg.bPartialScanning[i] = FALSE;
	}
#endif /* APCLI_SUPPORT */
#ifdef DOT11_VHT_AC
#ifdef WFA_VHT_PF
	pAd->force_amsdu = FALSE;
	pAd->force_noack = FALSE;
	pAd->force_vht_op_mode = FALSE;
	pAd->vht_force_sgi = FALSE;
	pAd->vht_force_tx_stbc = FALSE;
	pAd->CommonCfg.vht_nss_cap = pAd->chipCap.max_nss;
	pAd->CommonCfg.vht_mcs_cap = pAd->chipCap.max_vht_mcs;
#endif /* WFA_VHT_PF */
#endif /* DOT11_VHT_AC */
#ifdef CONFIG_FPGA_MODE
	pAd->fpga_ctl.fpga_on = 0x0;
	pAd->fpga_ctl.tx_kick_cnt = 0;
	pAd->fpga_ctl.tx_data_phy = 0;
	pAd->fpga_ctl.tx_data_ldpc = 0;
	pAd->fpga_ctl.tx_data_mcs = 0;
	pAd->fpga_ctl.tx_data_bw = 0;
	pAd->fpga_ctl.tx_data_gi = 0;
	pAd->fpga_ctl.rx_data_phy = 0;
	pAd->fpga_ctl.rx_data_ldpc = 0;
	pAd->fpga_ctl.rx_data_mcs = 0;
	pAd->fpga_ctl.rx_data_bw = 0;
	pAd->fpga_ctl.rx_data_gi = 0;
#ifdef CAPTURE_MODE
	pAd->fpga_ctl.cap_type = 2; /* CAP_MODE_ADC8; */
	pAd->fpga_ctl.cap_trigger = 2; /* CAP_TRIGGER_AUTO; */
	pAd->fpga_ctl.trigger_offset = 200;
	pAd->fpga_ctl.cap_support = 0;
#endif /* CAPTURE_MODE */
#ifdef DMA_SCH_SUPPORT
	pAd->fpga_ctl.dma_mode = DMA_SCH_LMAC;
#endif /* DMA_SCH_SUPPORT */
#if defined(MT7615_FPGA) || defined(MT7622_FPGA) || defined(P18_FPGA) || defined(MT7663_FPGA)

	if (IS_MT7615(pAd) || IS_MT7622(pAd) || IS_P18(pAd) || IS_MT7663(pAd))
		pAd->fpga_ctl.no_bcn = 1;

#endif /* defined(MT7615_FPGA) || defined(MT7622_FPGA) || defined(P18_FPGA) || defined(MT7663_FPGA) */
#endif /* CONFIG_FPGA_MODE */
#ifdef MICROWAVE_OVEN_SUPPORT

	if (pAd->OpMode == OPMODE_AP)
		pAd->CommonCfg.MO_Cfg.bEnable = TRUE;
	else
		pAd->CommonCfg.MO_Cfg.bEnable = FALSE;

	pAd->CommonCfg.MO_Cfg.nFalseCCATh = MO_FALSE_CCA_TH;
#endif /* MICROWAVE_OVEN_SUPPORT */
#ifdef DYNAMIC_VGA_SUPPORT
	pAd->CommonCfg.lna_vga_ctl.bDyncVgaEnable = TRUE;
	pAd->CommonCfg.lna_vga_ctl.nFalseCCATh = 600;
	pAd->CommonCfg.lna_vga_ctl.nLowFalseCCATh = 100;
#endif /* DYNAMIC_VGA_SUPPORT */
#ifdef DOT11_VHT_AC
	pAd->CommonCfg.bNonVhtDisallow = FALSE;
#endif /* DOT11_VHT_AC */
#ifdef RTMP_USB_SUPPORT
	pAd->usb_ctl.usb_aggregation = TRUE;
#endif
#ifdef MT_MAC
	pAd->chipCap.TmrEnable = 0;
	RTMP_SEM_EVENT_INIT(&(pAd->IndirectUpdateLock), &pAd->RscSemMemList);
	pAd->PSEWatchDogEn = 0;
	pAd->RxPseCheckTimes = 0;
	pAd->PSEResetCount = 0;
	pAd->PSETriggerType1Count = 0;
	pAd->PSETriggerType1Count = 0;
	pAd->PSEResetFailCount = 0;
#endif
#ifdef RTMP_MAC_PCI
	pAd->PDMAWatchDogEn = 0;
	pAd->TxDMAResetCount = 0;
	pAd->RxDMAResetCount = 0;
	pAd->TxDMACheckTimes = 0;
	pAd->RxDMACheckTimes = 0;
	pAd->PDMAResetFailCount = 0;
#endif
#ifdef CONFIG_MULTI_CHANNEL
	pAd->Mlme.bStartMcc = FALSE;
	pAd->Mlme.bStartScc = FALSE;
	pAd->Mlme.channel_1st_staytime = 40;
	pAd->Mlme.channel_2nd_staytime = 40;
	pAd->Mlme.switch_idle_time = 10;
	pAd->Mlme.null_frame_count = 1;
	pAd->Mlme.channel_1st_bw = 0;
	pAd->Mlme.channel_2nd_bw = 0;
#endif /* CONFIG_MULTI_CHANNEL */
#ifdef CONFIG_SNIFFER_SUPPORT
	pAd->monitor_ctrl.CurrentMonitorMode = 0;
#endif /* CONFIG_SNIFFER_SUPPORT */
	pAd->bPS_Retrieve = 1;
	pAd->CommonCfg.bTXRX_RXV_ON = 0;
	pAd->parse_rxv_stat_enable = 0;
	pAd->AccuOneSecRxBand0FcsErrCnt = 0;
	pAd->AccuOneSecRxBand0MdrdyCnt = 0;
	pAd->AccuOneSecRxBand1FcsErrCnt = 0;
	pAd->AccuOneSecRxBand1MdrdyCnt = 0;
	pAd->CommonCfg.ManualTxop = 0;
	pAd->CommonCfg.ManualTxopThreshold = 10; /* Mbps */
	pAd->CommonCfg.ManualTxopUpBound = 20; /* Ratio */
	pAd->CommonCfg.ManualTxopLowBound = 5; /* Ratio */
#ifdef CONFIG_AP_SUPPORT
#ifdef VOW_SUPPORT
	/* VOW control */
	pAd->vow_cfg.en_bw_ctrl = FALSE;
	pAd->vow_cfg.en_bw_refill = TRUE;
	pAd->vow_cfg.en_airtime_fairness = TRUE;
	pAd->vow_cfg.en_txop_no_change_bss = TRUE;
	pAd->vow_cfg.dbdc0_search_rule = VOW_WMM_SET_FIRST;
	pAd->vow_cfg.dbdc1_search_rule = VOW_WMM_SET_FIRST;
	pAd->vow_cfg.refill_period = VOW_REFILL_PERIOD_32US; /* 32us */
	pAd->vow_cfg.per_bss_enable = 0xFFFF; /* enable all 16 group */
	pAd->vow_cfg.sta_max_wait_time = VOW_DEF_STA_MAX_WAIT_TIME;
	pAd->vow_cfg.group_max_wait_time = VOW_DEF_BSS_MAX_WAIT_TIME;
	pAd->vow_avg_num = 30; /* 20 packets */
#ifdef VOW_DVT
	pAd->vow_q_len = 0xff;
#endif /* VOW_DVT */

	/* group(BSS) configuration */
	for (i = 0; i < VOW_MAX_GROUP_NUM; i++) {
		pAd->vow_bss_cfg[i].min_rate = 10; /* Mbps */
		pAd->vow_bss_cfg[i].max_rate = 30; /* Mbps */
		pAd->vow_bss_cfg[i].min_airtime_ratio = 5; /* % */
		pAd->vow_bss_cfg[i].max_airtime_ratio = 10; /* % */
		pAd->vow_bss_cfg[i].min_ratebucket_size = VOW_DEF_MIN_RATE_BUCKET_SIZE;
		pAd->vow_bss_cfg[i].max_ratebucket_size = VOW_DEF_MAX_RATE_BUCKET_SIZE;
		pAd->vow_bss_cfg[i].max_backlog_size = VOW_DEF_BACKLOG_SIZE;
		pAd->vow_bss_cfg[i].min_airtimebucket_size = VOW_DEF_MIN_AIRTIME_BUCKET_SIZE;
		pAd->vow_bss_cfg[i].max_airtimebucket_size = VOW_DEF_MAX_AIRTIME_BUCKET_SIZE;
		pAd->vow_bss_cfg[i].max_wait_time = VOW_DEF_MAX_WAIT_TIME;
		pAd->vow_bss_cfg[i].dwrr_quantum = VOW_DEF_BSS_DWRR_QUANTUM;
		pAd->vow_bss_cfg[i].min_rate_token = vow_convert_rate_token(pAd, VOW_MIN, i);
		pAd->vow_bss_cfg[i].max_rate_token = vow_convert_rate_token(pAd, VOW_MAX, i);
		pAd->vow_bss_cfg[i].min_airtime_token = vow_convert_airtime_token(pAd, VOW_MIN, i);
		pAd->vow_bss_cfg[i].max_airtime_token = vow_convert_airtime_token(pAd, VOW_MAX, i);
		pAd->vow_bss_cfg[i].bw_on = FALSE;
		pAd->vow_bss_cfg[i].at_on = TRUE;
	}

	/* per station default configuration */
	for (i = 0; i < MAX_LEN_OF_MAC_TABLE; i++) {
		pAd->vow_sta_cfg[i].dwrr_quantum[WMM_AC_BK] = VOW_STA_DWRR_IDX2; /* 4ms */
		pAd->vow_sta_cfg[i].dwrr_quantum[WMM_AC_BE] = VOW_STA_DWRR_IDX2; /* 4ms */
		pAd->vow_sta_cfg[i].dwrr_quantum[WMM_AC_VI] = VOW_STA_DWRR_IDX1; /* 3ms */
		pAd->vow_sta_cfg[i].dwrr_quantum[WMM_AC_VO] = VOW_STA_DWRR_IDX0; /* 1.5ms */
		pAd->vow_sta_cfg[i].group = 0;
		pAd->vow_sta_cfg[i].wmm_idx = VOW_WMM_SET0;
		pAd->vow_sta_cfg[i].ac_change_rule = VOW_DEFAULT_AC;
		pAd->vow_sta_cfg[i].paused = FALSE;
	}

	/* station DWRR quantum value */
	pAd->vow_cfg.vow_sta_dwrr_quantum[0] = VOW_STA_DWRR_QUANTUM0;
	pAd->vow_cfg.vow_sta_dwrr_quantum[1] = VOW_STA_DWRR_QUANTUM1;
	pAd->vow_cfg.vow_sta_dwrr_quantum[2] = VOW_STA_DWRR_QUANTUM2;
	pAd->vow_cfg.vow_sta_dwrr_quantum[3] = VOW_STA_DWRR_QUANTUM3;
	pAd->vow_cfg.vow_sta_dwrr_quantum[4] = VOW_STA_DWRR_QUANTUM4;
	pAd->vow_cfg.vow_sta_dwrr_quantum[5] = VOW_STA_DWRR_QUANTUM5;
	pAd->vow_cfg.vow_sta_dwrr_quantum[6] = VOW_STA_DWRR_QUANTUM6;
	pAd->vow_cfg.vow_sta_dwrr_quantum[7] = VOW_STA_DWRR_QUANTUM7;
	/* RX airtime */
	pAd->vow_rx_time_cfg.rx_time_en = TRUE;
	pAd->vow_rx_time_cfg.ed_offset = VOW_DEF_ED_OFFSET;
	pAd->vow_rx_time_cfg.obss_backoff = VOW_DEF_ABAND_OBSS_BACKOFF;
	pAd->vow_rx_time_cfg.non_qos_backoff = VOW_DEF_NON_QOS_BACKOFF;

	/*FIXME: depends on real WMM set mapping */
	for (i = 0; i < VOW_MAX_WMM_SET_NUM; i++) {
		pAd->vow_rx_time_cfg.wmm_backoff[i][WMM_AC_BK] = VOW_DEF_ABAND_BK_BACKOFF;
		pAd->vow_rx_time_cfg.wmm_backoff[i][WMM_AC_BE] = VOW_DEF_ABAND_BE_BACKOFF;
		pAd->vow_rx_time_cfg.wmm_backoff[i][WMM_AC_VI] = VOW_DEF_ABAND_VI_BACKOFF;
		pAd->vow_rx_time_cfg.wmm_backoff[i][WMM_AC_VO] = VOW_DEF_ABAND_VO_BACKOFF;
		pAd->vow_rx_time_cfg.wmm_backoff_sel[i] = VOW_WMM_ONE2ONE_MAPPING;
	}

	/* for fast round robin */
	pAd->vow_sta_frr_quantum = 2;	/* 0.5ms */

	/*FIXME: depends on real WMM set mapping */
	pAd->vow_rx_time_cfg.om_wmm_backoff[WMM_AC_BK] = VOW_DEF_ABAND_BK_BACKOFF;
	pAd->vow_rx_time_cfg.om_wmm_backoff[WMM_AC_BE] = VOW_DEF_ABAND_BE_BACKOFF;
	pAd->vow_rx_time_cfg.om_wmm_backoff[WMM_AC_VI] = VOW_DEF_ABAND_VI_BACKOFF;
	pAd->vow_rx_time_cfg.om_wmm_backoff[WMM_AC_VO] = VOW_DEF_ABAND_VO_BACKOFF;
	/*FIXME: depends on real WMM set mapping */
	pAd->vow_rx_time_cfg.repeater_wmm_backoff[WMM_AC_BK] = VOW_DEF_ABAND_BK_BACKOFF;
	pAd->vow_rx_time_cfg.repeater_wmm_backoff[WMM_AC_BE] = VOW_DEF_ABAND_BE_BACKOFF;
	pAd->vow_rx_time_cfg.repeater_wmm_backoff[WMM_AC_VI] = VOW_DEF_ABAND_VI_BACKOFF;
	pAd->vow_rx_time_cfg.repeater_wmm_backoff[WMM_AC_VO] = VOW_DEF_ABAND_VO_BACKOFF;

	/*FIXME: depends on real BSS mapping */
	for (i = 0; i < VOW_MAX_GROUP_NUM; i++) {
		pAd->vow_rx_time_cfg.bssid2wmm_set[i] = VOW_WMM_SET0;   /* default WMM SET0 */
	}

	/* misc configuration */
	if (pAd->vow_gen.VOW_GEN == VOW_GEN_2) {
		pAd->vow_misc_cfg.rts_sta_lock = TRUE;
		pAd->vow_misc_cfg.keep_quantum = TRUE;
		pAd->vow_misc_cfg.tx_rr_count = 0;	/* default: disable */
		pAd->vow_misc_cfg.measurement_mode = TRUE;
		pAd->vow_misc_cfg.max_backoff_bound_en = TRUE;
		pAd->vow_misc_cfg.max_backoff_bound = 20; /* ms, for CCK */
		pAd->vow_misc_cfg.rts_failed_charge_time_en = FALSE; /* FALSE: charge time when RTS failed */
		pAd->vow_misc_cfg.zero_eifs_time = TRUE;
		pAd->vow_misc_cfg.rx_rifs_mode = TRUE;
		pAd->vow_misc_cfg.keep_vow_sram_setting = TRUE;
		pAd->vow_misc_cfg.keep_vow_sram_setting_bit = 26; /* bit 26 */
	}


#endif /* VOW_SUPPORT */
#ifdef APCLI_SUPPORT
#ifdef ROAMING_ENHANCE_SUPPORT
	pAd->ApCfg.bRoamingEnhance = FALSE;
#endif /* ROAMING_ENHANCE_SUPPORT */
#endif /* APCLI_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */
#ifdef RED_SUPPORT
	pAd->red_en = TRUE;
	pAd->red_targetdelay = 20000;
	pAd->red_atm_on_targetdelay = 15000;
	pAd->red_atm_off_targetdelay = 20000;
	pAd->red_sta_num = 0;
	pAd->red_in_use_sta = 0;
#endif /* RED_SUPPORT */
	pAd->cp_support = 2;
#if defined(INTERNAL_CAPTURE_SUPPORT) || defined(WIFI_SPECTRUM_SUPPORT)
	pAd->ICapMode = 0;
	pAd->SpectrumEventCnt = 0;
	pAd->ICapStatus = 0;
	pAd->ICapEventCnt = 0;
	pAd->ICapDataCnt = 0;
	pAd->ICapIdx = 0;
	pAd->ICapCapLen = 0;
	pAd->ICapL32Cnt = 0;
	pAd->ICapM32Cnt = 0;
	pAd->ICapH32Cnt = 0;
	pAd->pL32Bit = NULL;
	pAd->pM32Bit = NULL;
	pAd->pH32Bit = NULL;
	pAd->pSrc_IQ = "/tmp/WifiSpectrum_IQ.txt";
	pAd->pSrc_Gain = "/tmp/WifiSpectrum_LNA_LPF.txt";
	/* Dynamic allocate memory for pIQ_Array buffer */
	{
		UINT32 retval, Len;
		Len = MAX_ICAP_IQ_DATA_CNT * sizeof(RBIST_IQ_DATA_T);
		retval = os_alloc_mem(pAd, (UCHAR **)&pAd->pIQ_Array, Len);

		if (retval != NDIS_STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
					 ("%s : Not enough memory for dynamic allocating !!\n", __FUNCTION__));
		}

		os_zero_mem(pAd->pIQ_Array, Len);
	}
#endif /* defined(INTERNAL_CAPTURE_SUPPORT) || defined(WIFI_SPECTRUM_SUPPORT) */
	/* ===================================================== */
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		pAd->MSTANum = 1;
#ifdef RTMP_MAC_PCI
		pAd->RLnkCtrlOffset = 0;
		pAd->HostLnkCtrlOffset = 0;
		pAd->brt30xxBanMcuCmd = FALSE;
#endif
		RX_FILTER_SET_FLAG(pAd, fRX_FILTER_ACCEPT_DIRECT);
		RX_FILTER_CLEAR_FLAG(pAd, fRX_FILTER_ACCEPT_MULTICAST);
		RX_FILTER_SET_FLAG(pAd, fRX_FILTER_ACCEPT_BROADCAST);
		RX_FILTER_SET_FLAG(pAd, fRX_FILTER_ACCEPT_ALL_MULTICAST);
		pAd->CommonCfg.NdisRadioStateOff = FALSE;       /* New to support microsoft disable radio with OID command*/
		OPSTATUS_CLEAR_FLAG(pAd, fOP_STATUS_WAKEUP_NOW);
#ifdef PROFILE_STORE
		pAd->bWriteDat = FALSE;
#endif /* PROFILE_STORE */
#ifdef WFA_WFD_SUPPORT
		pAd->pWfdIeInBeacon = NULL;
		pAd->WfdIeInBeaconLen = 0;
		pAd->pWfdIeInProbeReq = NULL;
		pAd->WfdIeInProbeReqLen = 0;
		pAd->pWfdIeInProbeRsp = NULL;
		pAd->WfdIeInProbeRspLen = 0;
		pAd->pWfdIeInActionPkt = NULL;
		pAd->WfdIeInActionPktLen = 0;
		pAd->pWfdIeInAssocReq = NULL;
		pAd->WfdIeInAssocReqLen = 0;
		pAd->pWfdIeInAssocRsp = NULL;
		pAd->WfdIeInAssocRspLen = 0;
#endif /* WFA_WFD_SUPPORT */
		pAd->RxAnt.Pair1AvgRssi[0] = pAd->RxAnt.Pair1AvgRssi[1] = 0;
		pAd->Dot11_H.RDMode = RD_NORMAL_MODE;

		for (i = 0; i < MAX_MULTI_STA; i++) {
			PSTA_ADMIN_CONFIG pStaCfg = &pAd->StaCfg[i];
			pStaCfg->PwrMgmt.bDoze = FALSE;
			pStaCfg->CountDowntoPsm = 0;
#ifdef ETH_CONVERT_SUPPORT
			pStaCfg->bFragFlag = TRUE;
#endif
#ifdef RTMP_MAC_USB
			pStaCfg->Connectinfoflag = FALSE;
#endif
#ifdef UAPSD_SUPPORT
			pStaCfg->wdev.UapsdInfo.bAPSDCapable = FALSE;
#endif
			pStaCfg->PwrMgmt.Psm = PWR_ACTIVE;
			CLEAR_CIPHER(pStaCfg->PairwiseCipher);
			CLEAR_CIPHER(pStaCfg->GroupCipher);
			/* 802.1x port control*/
			pStaCfg->PrivacyFilter = Ndis802_11PrivFilter8021xWEP;
			pStaCfg->wdev.PortSecured = WPA_802_1X_PORT_NOT_SECURED;
			pStaCfg->LastMicErrorTime = 0;
			pStaCfg->MicErrCnt        = 0;
			pStaCfg->bBlockAssoc      = FALSE;
			pStaCfg->WpaState         = SS_NOTUSE;
			pStaCfg->RssiTrigger = 0;
			NdisZeroMemory(&pStaCfg->RssiSample, sizeof(RSSI_SAMPLE));
			pStaCfg->RssiTriggerMode = RSSI_TRIGGERED_UPON_BELOW_THRESHOLD;
			pStaCfg->AtimWin = 0;
			pStaCfg->DefaultListenCount = 3;/*default listen count;*/
#if defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT)
			pStaCfg->DefaultListenCount = 1;
#endif /* defined(DOT11Z_TDLS_SUPPORT) || defined(CFG_TDLS_SUPPORT) */
			pStaCfg->BssType = BSS_INFRA;  /* BSS_INFRA or BSS_ADHOC or BSS_MONITOR*/
			pStaCfg->bSkipAutoScanConn = FALSE;
			pStaCfg->wdev.bAutoTxRateSwitch = TRUE;
			pStaCfg->wdev.DesiredTransmitSetting.field.MCS = MCS_AUTO;
			pStaCfg->bAutoConnectIfNoSSID = FALSE;
			pStaCfg->wdev.bLinkUpDone = FALSE;

			if (!pStaCfg->wdev.pEapolPktFromAP)
				os_alloc_mem(NULL,
							 (UCHAR **)&pStaCfg->wdev.pEapolPktFromAP,
							 sizeof(*pStaCfg->wdev.pEapolPktFromAP));
			else
				MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_WARN,
						 ("non-NULL pEapolPktFromAP 0x%p\n",
						  pStaCfg->wdev.pEapolPktFromAP));

#ifdef EXT_BUILD_CHANNEL_LIST
			pStaCfg->IEEE80211dClientMode = Rt802_11_D_None;
#endif /* EXT_BUILD_CHANNEL_LIST */
#ifdef RELEASE_EXCLUDE
			/*
			    3090F could not execute any MCU commands after executing SLEEP comands exceptiong
			    RADIO_OFF and WakeUp or the chips will crash. Therefore, We use brt30xxBanMcuCmd to block MCU commands.
			*/
#endif /* RELEASE_EXCLUDE */
#ifdef RTMP_MAC_PCI
			pStaCfg->PSControl.field.EnableNewPS = FALSE;
#endif /* RTMP_MAC_PCI */
			STA_STATUS_CLEAR_FLAG(pStaCfg, fSTA_STATUS_INFRA_ON);
			/* user desired power mode*/
			pStaCfg->WindowsPowerMode = Ndis802_11PowerModeCAM;
			pStaCfg->WindowsBatteryPowerMode = Ndis802_11PowerModeCAM;
			pStaCfg->bWindowsACCAMEnable = FALSE;
			pStaCfg->bHwRadio = TRUE; /* Default Hardware Radio status is On*/
			pStaCfg->bSwRadio = TRUE; /* Default Software Radio status is On*/
			pStaCfg->bRadio = TRUE; /* bHwRadio && bSwRadio*/
			pStaCfg->bHardwareRadio = FALSE;        /* Default is OFF*/
			pStaCfg->bShowHiddenSSID = FALSE;       /* Default no show*/
			/* Nitro mode control*/
#if defined(NATIVE_WPA_SUPPLICANT_SUPPORT) || defined(RT_CFG80211_SUPPORT)
			pStaCfg->bAutoReconnect = FALSE;
#else
			pStaCfg->bAutoReconnect = TRUE;
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT || RT_CFG80211_SUPPORT*/
			/* Save the init time as last scan time, the system should do scan after 2 seconds.*/
			/* This patch is for driver wake up from standby mode, system will do scan right away.*/
			NdisGetSystemUpTime(&pStaCfg->LastScanTime);

			if (pStaCfg->LastScanTime > 10 * OS_HZ)
				pStaCfg->LastScanTime -= (10 * OS_HZ);

			NdisZeroMemory(pAd->nickname, IW_ESSID_MAX_SIZE + 1);
#ifdef WPA_SUPPLICANT_SUPPORT
			pStaCfg->wdev.SecConfig.IEEE8021X = FALSE;
			pStaCfg->wpa_supplicant_info.IEEE8021x_required_keys = FALSE;
			pStaCfg->wpa_supplicant_info.WpaSupplicantUP = WPA_SUPPLICANT_DISABLE;
			pStaCfg->wpa_supplicant_info.bRSN_IE_FromWpaSupplicant = FALSE;
#if defined(NATIVE_WPA_SUPPLICANT_SUPPORT) || defined(RT_CFG80211_SUPPORT)
			pStaCfg->wpa_supplicant_info.WpaSupplicantUP = WPA_SUPPLICANT_ENABLE;
#ifdef PROFILE_STORE
			pAd->bWriteDat = TRUE;
#endif /* PROFILE_STORE */
#endif /* NATIVE_WPA_SUPPLICANT_SUPPORT || RT_CFG80211_SUPPORT */
			pStaCfg->wpa_supplicant_info.bLostAp = FALSE;
			pStaCfg->wpa_supplicant_info.pWpsProbeReqIe = NULL;
			pStaCfg->wpa_supplicant_info.WpsProbeReqIeLen = 0;
			pStaCfg->wpa_supplicant_info.pWpaAssocIe = NULL;
			pStaCfg->wpa_supplicant_info.WpaAssocIeLen = 0;
			pStaCfg->wpa_supplicant_info.WpaSupplicantScanCount = 0;
#ifdef CFG_TDLS_SUPPORT
			NdisZeroMemory(&(pStaCfg->wpa_supplicant_info.CFG_Tdls_info), sizeof(CFG_TDLS_STRUCT));
			pStaCfg->wpa_supplicant_info.CFG_Tdls_info.bCfgTDLSCapable = 1;
			pStaCfg->wpa_supplicant_info.CFG_Tdls_info.TdlsChSwitchSupp = 1;
			pStaCfg->wpa_supplicant_info.CFG_Tdls_info.BaseChannelStayTime = 15;
			cfg_tdls_TimerInit(pAd);
			RTMPInitTimer(pAd, &(pStaCfg->wpa_supplicant_info.CFG_Tdls_info.BaseChannelSwitchTimer),
						  GET_TIMER_FUNCTION(cfg_tdls_BaseChannelTimeoutAction), pAd, FALSE);
#endif /* CFG_TDLS_SUPPORT */
#endif /* WPA_SUPPLICANT_SUPPORT */
#ifdef WSC_STA_SUPPORT
			{
				INT                 idx;
				PWSC_CTRL           pWscControl;
#ifdef STA_EASY_CONFIG_SETUP
				PEASY_CONFIG_INFO   pEasyConfig;
#endif /* STA_EASY_CONFIG_SETUP */
#ifdef WSC_V2_SUPPORT
				PWSC_V2_INFO    pWscV2Info;
#endif /* WSC_V2_SUPPORT */
				/*
				 WscControl cannot be zero here, because WscControl timers are initial in MLME Initialize
				 and MLME Initialize is called before UserCfgInit.
				*/
				pWscControl = &pStaCfg->wdev.WscControl;
				pWscControl->WscConfMode = WSC_DISABLE;
				pWscControl->WscMode = WSC_PIN_MODE;
				pWscControl->WscConfStatus = WSC_SCSTATE_UNCONFIGURED;
#ifdef WSC_V2_SUPPORT
				pWscControl->WscConfigMethods = 0x238C;
#else
				pWscControl->WscConfigMethods = 0x008C;
#endif /* WSC_V2_SUPPORT */
#ifdef P2P_SUPPORT
				pWscControl->WscConfigMethods |= 0x0100;
#endif /* P2P_SUPPORT */
				pWscControl->WscState = WSC_STATE_OFF;
				pWscControl->WscStatus = STATUS_WSC_NOTUSED;
				pWscControl->WscPinCode = 0;
				pWscControl->WscLastPinFromEnrollee = 0;
				pWscControl->WscEnrollee4digitPinCode = FALSE;
				pWscControl->WscEnrolleePinCode = 0;
				pWscControl->WscSelReg = 0;
				NdisZeroMemory(&pWscControl->RegData, sizeof(WSC_REG_DATA));
				NdisZeroMemory(&pWscControl->WscProfile, sizeof(WSC_PROFILE));
				pWscControl->WscUseUPnP = 0;
				pWscControl->WscEnAssociateIE = TRUE;
				pWscControl->WscEnProbeReqIE = TRUE;
				pWscControl->RegData.ReComputePke = 1;
				pWscControl->lastId = 1;
				pWscControl->EntryIfIdx = BSS0;
#ifdef DPA_T
				pWscControl->WscDriverAutoConnect = 0x00;   /* 2009-11-14 changed. */
#else /* DPA_T */
				pWscControl->WscDriverAutoConnect = 0x02;
#endif /* !DPA_T */
				pAd->WriteWscCfgToDatFile = 0xFF;
				pWscControl->WscRejectSamePinFromEnrollee = FALSE;
				pWscControl->WpsApBand = PREFERRED_WPS_AP_PHY_TYPE_AUTO_SELECTION;
				pWscControl->bCheckMultiByte = FALSE;
				pWscControl->bWscAutoTigeer = FALSE;

				/* Enrollee Nonce, first generate and save to Wsc Control Block*/
				for (idx = 0; idx < 16; idx++)
					pWscControl->RegData.SelfNonce[idx] = RandomByte(pAd);

				pWscControl->WscRxBufLen = 0;
				pWscControl->pWscRxBuf = NULL;
				os_alloc_mem(pAd, &pWscControl->pWscRxBuf, MGMT_DMA_BUFFER_SIZE);

				if (pWscControl->pWscRxBuf)
					NdisZeroMemory(pWscControl->pWscRxBuf, MGMT_DMA_BUFFER_SIZE);

				pWscControl->WscTxBufLen = 0;
				pWscControl->pWscTxBuf = NULL;
				os_alloc_mem(pAd, &pWscControl->pWscTxBuf, MGMT_DMA_BUFFER_SIZE);

				if (pWscControl->pWscTxBuf)
					NdisZeroMemory(pWscControl->pWscTxBuf, MGMT_DMA_BUFFER_SIZE);

				pWscControl->bWscFragment = FALSE;
				pWscControl->WscFragSize = 128;
				initList(&pWscControl->WscPeerList);
				NdisAllocateSpinLock(pAd, &pWscControl->WscPeerListSemLock);
#ifdef STA_EASY_CONFIG_SETUP
				pEasyConfig = &pStaCfg->EasyConfigInfo;
				AutoProvisionGenWpsPTK(pAd, BSS0);
				pEasyConfig->ModuleType = MODULE_UNKNOW;
				pEasyConfig->bRaAutoWpsAp = FALSE;
				pEasyConfig->bDoAutoWps = FALSE;
				pEasyConfig->RssiThreshold = -50;
				pEasyConfig->bEnable = TRUE;
				pEasyConfig->bChangeMode = FALSE;
#ifdef WAC_SUPPORT
				pEasyConfig->bEnableWAC = TRUE;
				pEasyConfig->DoAutoWAC = 0xFF;
				pEasyConfig->pVendorInfoForProbeReq = NULL;
#endif /* WAC_SUPPORT */
#endif /* STA_EASY_CONFIG_SETUP */
#ifdef WSC_V2_SUPPORT
				pWscV2Info = &pWscControl->WscV2Info;
				pWscV2Info->bWpsEnable = TRUE;
				pWscV2Info->ExtraTlv.TlvLen = 0;
				pWscV2Info->ExtraTlv.TlvTag = 0;
				pWscV2Info->ExtraTlv.pTlvData = NULL;
				pWscV2Info->ExtraTlv.TlvType = TLV_ASCII;
				pWscV2Info->bEnableWpsV2 = TRUE;
				pWscV2Info->bForceSetAP = FALSE;
#endif /* WSC_V2_SUPPORT */
#ifdef DPA_T

				for (idx = 0; idx < 8; idx++) {
					pWscControl->WpsVendorExt[idx].Length = 0;
					pWscControl->WpsVendorExt[idx].pData = NULL;
				}

				pStaCfg->bPriorityCtrl = FALSE;
				pStaCfg->WscPbcExtraScanCount = 0;
#endif /* DPA_T */
			}
#ifdef IWSC_SUPPORT
			IWSC_Init(pAd);
#endif /* IWSC_SUPPORT */
#endif /* WSC_STA_SUPPORT */
			NdisZeroMemory(pStaCfg->ReplayCounter, 8);
#ifdef DOT11R_FT_SUPPORT
			NdisZeroMemory(&pStaCfg->Dot11RCommInfo, sizeof(DOT11R_CMN_STRUC));
#endif /* DOT11R_FT_SUPPORT */
			pStaCfg->bAutoConnectByBssid = FALSE;
			pStaCfg->BeaconLostTime = BEACON_LOST_TIME;
			NdisZeroMemory(pStaCfg->WpaPassPhrase, 64);
			pStaCfg->WpaPassPhraseLen = 0;
			pStaCfg->bAutoRoaming = FALSE;
			pStaCfg->bForceTxBurst = FALSE;
			pStaCfg->bNotFirstScan = FALSE;
			pStaCfg->bImprovedScan = FALSE;
#ifdef DOT11_N_SUPPORT
			pStaCfg->bAdhocN = TRUE;
#endif /* DOT11_N_SUPPORT */
			pStaCfg->bFastConnect = FALSE;
			pStaCfg->bAdhocCreator = FALSE;
			pStaCfg->MlmeAux.OldChannel = 0;
#ifdef WIDI_SUPPORT
			pStaCfg->bWIDI = TRUE;
#endif /* WIDI_SUPPORT */
#ifdef IP_ASSEMBLY
			pStaCfg->bFragFlag = TRUE;
#endif /* IP_ASSEMBLY */
#ifdef DOT11Z_TDLS_SUPPORT
			pStaCfg->TdlsInfo.bTDLSCapable = FALSE;
			pStaCfg->TdlsInfo.TdlsChSwitchSupp = TRUE;
			pStaCfg->TdlsInfo.TdlsPsmSupp = FALSE;
			pStaCfg->TdlsInfo.TdlsKeyLifeTime = TDLS_LEY_LIFETIME;
#ifdef TDLS_AUTOLINK_SUPPORT
			initList(&pStaCfg->TdlsInfo.TdlsDiscovPeerList);
			NdisAllocateSpinLock(&pStaCfg->TdlsInfo.TdlsDiscovPeerListSemLock);
			initList(&pStaCfg->TdlsInfo.TdlsBlackList);
			NdisAllocateSpinLock(&pStaCfg->TdlsInfo.TdlsBlackListSemLock);
			pStaCfg->TdlsInfo.TdlsAutoSetupRssiThreshold = TDLS_AUTO_SETUP_RSSI_THRESHOLD;
			pStaCfg->TdlsInfo.TdlsAutoTeardownRssiThreshold = TDLS_AUTO_TEARDOWN_RSSI_THRESHOLD;
			pStaCfg->TdlsInfo.TdlsRssiMeasurementPeriod = TDLS_RSSI_MEASUREMENT_PERIOD;
			pStaCfg->TdlsInfo.TdlsDisabledPeriodByTeardown = TDLS_DISABLE_PERIOD_BY_TEARDOWN;
			pStaCfg->TdlsInfo.TdlsAutoDiscoveryPeriod = TDLS_AUTO_DISCOVERY_PERIOD;
#endif /* TDLS_AUTOLINK_SUPPORT */
#endif /* DOT11Z_TDLS_SUPPORT */
		}
	}
#endif
#ifdef SMART_CARRIER_SENSE_SUPPORT

	/* SCS Variable initialization */
	for (i = 0; i < DBDC_BAND_NUM; i++) {
		pAd->SCSCtrl.SCSEnable[i] = SCS_DISABLE;
		pAd->SCSCtrl.SCSTrafficThreshold[i] = TriggerTrafficeTh; /* 2M */
		pAd->SCSCtrl.SCSStatus[i] = PD_BLOCKING_OFF;
		pAd->SCSCtrl.OneSecTxByteCount[i] = 0;
		pAd->SCSCtrl.OneSecRxByteCount[i] = 0;
		pAd->SCSCtrl.CckPdBlkTh[i] = PdBlkCckThDefault;
		pAd->SCSCtrl.OfdmPdBlkTh[i] = PdBlkOfmdThDefault;
		pAd->SCSCtrl.SCSThTolerance[i] = ThTolerance;
		pAd->SCSCtrl.SCSMinRssiTolerance[i] = MinRssiTolerance;
		pAd->SCSCtrl.OfdmPdSupport[i] = TRUE;
		pAd->SCSCtrl.CckFalseCcaUpBond[i] = FalseCcaUpBondDefault;
		pAd->SCSCtrl.CckFalseCcaLowBond[i] = FalseCcaLowBondDefault;
		pAd->SCSCtrl.OfdmFalseCcaUpBond[i] = FalseCcaUpBondDefault;
		pAd->SCSCtrl.OfdmFalseCcaLowBond[i] = FalseCcaLowBondDefault;
		pAd->SCSCtrl.CckFixedRssiBond[i] = CckFixedRssiBondDefault;
		pAd->SCSCtrl.OfdmFixedRssiBond[i] = OfdmFixedRssiBondDefault;
	}

	if (IS_MT7615(pAd))
		pAd->SCSCtrl.SCSGeneration = SCS_Gen2;
	else if (IS_MT7622(pAd))
		pAd->SCSCtrl.SCSGeneration = SCS_Gen3;
	else
		pAd->SCSCtrl.SCSGeneration = SCS_Gen1;

	pAd->SCSCtrl.SCSEnable[DBDC_BAND0] = SCS_ENABLE;
#endif /* SMART_CARRIER_SENSE_SUPPORT */

	for (i = 0; i < DBDC_BAND_NUM; i++)
		pAd->CCI_ACI_TxOP_Value[i] = 0;

	pAd->g_mode_txop_wdev = NULL;
	pAd->G_MODE_INFRA_TXOP_RUNNING = FALSE;
	pAd->MUMIMO_TxOP_Value = 0;
	pAd->txop_ctl.multi_client_nums = 0;
	pAd->txop_ctl.cur_wdev = NULL;
	pAd->txop_ctl.multi_cli_txop_running = FALSE;
	pAd->txop_ctl.multi_client_nums_2g = 0;
	pAd->txop_ctl.cur_wdev_2g = NULL;
	pAd->txop_ctl.multi_cli_txop_2g_running = FALSE;
#ifdef PKT_BUDGET_CTRL_SUPPORT
	pAd->pbc_bound[PBC_AC_BE] = PBC_WMM_UP_DEFAULT_BE;
	pAd->pbc_bound[PBC_AC_BK] = PBC_WMM_UP_DEFAULT_BK;
	pAd->pbc_bound[PBC_AC_VO] = PBC_WMM_UP_DEFAULT_VO;
	pAd->pbc_bound[PBC_AC_VI] = PBC_WMM_UP_DEFAULT_VI;
	pAd->pbc_bound[PBC_AC_MGMT] = PBC_WMM_UP_DEFAULT_MGMT;
#endif /*PKT_BUDGET_CTRL_SUPPORT*/
#ifdef TX_AGG_ADJUST_WKR
	pAd->TxAggAdjsut = TRUE;
#endif /* TX_AGG_ADJUST_WKR */
#ifdef HTC_DECRYPT_IOT
	pAd->HTC_ICV_Err_TH = 5;
#endif /* HTC_DECRYPT_IOT */
#ifdef DHCP_UC_SUPPORT
	pAd->DhcpUcEnable = FALSE;
#endif /* DHCP_UC_SUPPORT */

	for (i = 0; i < DBDC_BAND_NUM; i++) {
		pAd->CommonCfg.ucEDCCACtrl[i] = TRUE; /* EDCCA default is ON. */
	}

#ifdef LINUX_NET_TXQ_SUPPORT
	pAd->tx_net_queue_len = LINUX_DEF_TX_QUEUE_LENGTH;/* for veriwave test */
#endif /* LINUX_NET_TXQ_SUPPORT */

	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("<-- UserCfgInit\n"));
}


/* IRQL = PASSIVE_LEVEL*/
UCHAR BtoH(RTMP_STRING ch)
{
	if (ch >= '0' && ch <= '9')
		return ch - '0';        /* Handle numerals*/

	if (ch >= 'A' && ch <= 'F')
		return ch - 'A' + 0xA;  /* Handle capitol hex digits*/

	if (ch >= 'a' && ch <= 'f')
		return ch - 'a' + 0xA;  /* Handle small hex digits*/

	return 255;
}


/*
	FUNCTION: AtoH(char *, UCHAR *, int)

	PURPOSE:  Converts ascii string to network order hex

	PARAMETERS:
		src    - pointer to input ascii string
		dest   - pointer to output hex
		destlen - size of dest

	COMMENTS:

		2 ascii bytes make a hex byte so must put 1st ascii byte of pair
		into upper nibble and 2nd ascii byte of pair into lower nibble.

	IRQL = PASSIVE_LEVEL
*/
void AtoH(RTMP_STRING *src, PUCHAR dest, int destlen)
{
	RTMP_STRING *srcptr;
	PUCHAR destTemp;
	srcptr = src;
	destTemp = (PUCHAR) dest;

	while (destlen--) {
		*destTemp = BtoH(*srcptr++) << 4;    /* Put 1st ascii byte in upper nibble.*/
		*destTemp += BtoH(*srcptr++);      /* Add 2nd ascii byte to above.*/
		destTemp++;
	}
}


/*
========================================================================
Routine Description:
	Add a timer to the timer list.

Arguments:
	pAd				- WLAN control block pointer
	pRsc			- the OS resource

Return Value:
	None

Note:
========================================================================
*/
VOID RTMP_TimerListAdd(RTMP_ADAPTER *pAd, VOID *pRsc)
{
	LIST_HEADER *pRscList = &pAd->RscTimerCreateList;
	LIST_RESOURCE_OBJ_ENTRY *pObj;
	/* try to find old entry */
	pObj = (LIST_RESOURCE_OBJ_ENTRY *)(pRscList->pHead);

	while (1) {
		if (pObj == NULL)
			break;

		if ((ULONG)(pObj->pRscObj) == (ULONG)pRsc)
			return;

		pObj = pObj->pNext;
	}

	/* allocate a timer record entry */
	os_alloc_mem(NULL, (UCHAR **) &(pObj), sizeof(LIST_RESOURCE_OBJ_ENTRY));

	if (pObj == NULL) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: alloc timer obj fail!\n", __func__));
		return;
	} else {
		pObj->pRscObj = pRsc;
		insertTailList(pRscList, (RT_LIST_ENTRY *)pObj);
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s: add timer obj %lx!\n", __func__, (ULONG)pRsc));
	}
}


VOID RTMP_TimerListRelease(RTMP_ADAPTER *pAd, VOID *pRsc)
{
	LIST_HEADER *pRscList = &pAd->RscTimerCreateList;
	LIST_RESOURCE_OBJ_ENTRY *pObj;
	RT_LIST_ENTRY *pListEntry;
	pListEntry = pRscList->pHead;
	pObj = (LIST_RESOURCE_OBJ_ENTRY *)pListEntry;

	while (pObj) {
		if ((ULONG)(pObj->pRscObj) == (ULONG)pRsc) {
			pListEntry = (RT_LIST_ENTRY *)pObj;
			break;
		}

		pListEntry = pListEntry->pNext;
		pObj = (LIST_RESOURCE_OBJ_ENTRY *)pListEntry;
	}

	if (pListEntry) {
		delEntryList(pRscList, pListEntry);
		/* free a timer record entry */
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s: release timer obj %lx!\n", __func__, (ULONG)pRsc));
		os_free_mem(pObj);
	}
}



/*
* Show Timer Information
*/
VOID RTMPShowTimerList(RTMP_ADAPTER *pAd)
{
	LIST_HEADER *pRscList = &pAd->RscTimerCreateList;
	LIST_RESOURCE_OBJ_ENTRY *pObj;
	RALINK_TIMER_STRUCT *pTimer;
	/* try to find old entry */
	pObj = (LIST_RESOURCE_OBJ_ENTRY *)(pRscList->pHead);
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Timer List Size:%d\n", pRscList->size));
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("=====================================\n"));

	while (1) {
		if (pObj == NULL)
			break;

		pTimer = (RALINK_TIMER_STRUCT *)pObj->pRscObj;
		pObj = pObj->pNext;
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Valid:%d\n", pTimer->Valid));
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("pObj:%lx\n", (ULONG)pTimer));
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("PeriodicType:%d\n", pTimer->PeriodicType));
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Repeat:%d\n", pTimer->Repeat));
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("State:%d\n", pTimer->State));
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("TimerValue:%ld\n", pTimer->TimerValue));
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("timer_lock:%lx\n", (ULONG)pTimer->timer_lock));
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("pCaller:%pS\n", pTimer->pCaller));
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("=====================================\n"));
	}
}



/*
========================================================================
Routine Description:
	Cancel all timers in the timer list.

Arguments:
	pAd				- WLAN control block pointer

Return Value:
	None

Note:
========================================================================
*/
VOID RTMP_AllTimerListRelease(RTMP_ADAPTER *pAd)
{
	LIST_HEADER *pRscList = &pAd->RscTimerCreateList;
	LIST_RESOURCE_OBJ_ENTRY *pObj, *pObjOld;
	BOOLEAN Cancel;
	RALINK_TIMER_STRUCT *pTimer;
	/* try to find old entry */
	pObj = (LIST_RESOURCE_OBJ_ENTRY *)(pRscList->pHead);
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: Size=%d\n", __func__, pRscList->size));

	while (1) {
		if (pObj == NULL)
			break;

		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: Cancel timer obj %lx!\n", __func__,
				 (ULONG)(pObj->pRscObj)));
		pObjOld = pObj;
		pObj = pObj->pNext;
		pTimer = (RALINK_TIMER_STRUCT *)pObjOld->pRscObj;
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: Timer is allocated by %pS,Valid:%d,Lock:%lx,State:%d\n",
				 __func__,
				 pTimer->pCaller, pTimer->Valid, (ULONG)pTimer->timer_lock, pTimer->State));
		RTMPReleaseTimer(pObjOld->pRscObj, &Cancel);
	}

	/* reset TimerList */
	initList(&pAd->RscTimerCreateList);
}


/*
	========================================================================

	Routine Description:
		Init timer objects

	Arguments:
		pAd			Pointer to our adapter
		pTimer				Timer structure
		pTimerFunc			Function to execute when timer expired
		Repeat				Ture for period timer

	Return Value:
		None

	Note:

	========================================================================
*/
VOID RTMPInitTimer(
	IN	RTMP_ADAPTER *pAd,
	IN	RALINK_TIMER_STRUCT *pTimer,
	IN	VOID *pTimerFunc,
	IN	VOID *pData,
	IN	BOOLEAN	 Repeat)
{
	pTimer->timer_lock = &pAd->TimerSemLock;
	RTMP_SEM_LOCK(pTimer->timer_lock);
	RTMP_TimerListAdd(pAd, pTimer);
	/* Set Valid to TRUE for later used.*/
	/* It will crash if we cancel a timer or set a timer */
	/* that we haven't initialize before.*/
	/* */
	pTimer->Valid      = TRUE;
	pTimer->PeriodicType = Repeat;
	pTimer->State      = FALSE;
	pTimer->cookie = (ULONG) pData;
	pTimer->pAd = pAd;
	pTimer->pCaller = (VOID *)OS_TRACE;
	RTMP_OS_Init_Timer(pAd, &pTimer->TimerObj,	pTimerFunc, (PVOID) pTimer, &pAd->RscTimerMemList);
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s: %lx\n", __func__, (ULONG)pTimer));
	RTMP_SEM_UNLOCK(pTimer->timer_lock);
}


/*
	========================================================================

	Routine Description:
		Init timer objects

	Arguments:
		pTimer				Timer structure
		Value				Timer value in milliseconds

	Return Value:
		None

	Note:
		To use this routine, must call RTMPInitTimer before.

	========================================================================
*/
VOID RTMPSetTimer(RALINK_TIMER_STRUCT *pTimer, ULONG Value)
{
	if (!pTimer->timer_lock)
		return;

	RTMP_SEM_LOCK(pTimer->timer_lock);

	if (pTimer->Valid) {
		RTMP_ADAPTER *pAd;
		pAd = (RTMP_ADAPTER *)pTimer->pAd;

		if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_HALT_IN_PROGRESS | fRTMP_ADAPTER_NIC_NOT_EXIST)) {
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("RTMPSetTimer failed, Halt in Progress!\n"));
			RTMP_SEM_UNLOCK(pTimer->timer_lock);
			return;
		}

		pTimer->TimerValue = Value;
		pTimer->State      = FALSE;

		if (pTimer->PeriodicType == TRUE) {
			pTimer->Repeat = TRUE;
			RTMP_SetPeriodicTimer(&pTimer->TimerObj, Value);
		} else {
			pTimer->Repeat = FALSE;
			RTMP_OS_Add_Timer(&pTimer->TimerObj, Value);
		}

		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s: %lx\n", __func__, (ULONG)pTimer));
	} else
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("RTMPSetTimer failed, Timer hasn't been initialize!\n"));

	RTMP_SEM_UNLOCK(pTimer->timer_lock);
}


/*
	========================================================================

	Routine Description:
		Init timer objects

	Arguments:
		pTimer				Timer structure
		Value				Timer value in milliseconds

	Return Value:
		None

	Note:
		To use this routine, must call RTMPInitTimer before.

	========================================================================
*/
VOID RTMPModTimer(RALINK_TIMER_STRUCT *pTimer, ULONG Value)
{
	BOOLEAN	Cancel;

	if (!pTimer->timer_lock)
		return;

	RTMP_SEM_LOCK(pTimer->timer_lock);

	if (pTimer->Valid) {
		pTimer->TimerValue = Value;
		pTimer->State      = FALSE;

		if (pTimer->PeriodicType == TRUE) {
			RTMP_SEM_UNLOCK(pTimer->timer_lock);
			RTMPCancelTimer(pTimer, &Cancel);
			RTMPSetTimer(pTimer, Value);
		} else {
			RTMP_OS_Mod_Timer(&pTimer->TimerObj, Value);
			RTMP_SEM_UNLOCK(pTimer->timer_lock);
		}

		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s: %lx\n", __func__, (ULONG)pTimer));
	} else {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("RTMPModTimer failed, Timer hasn't been initialize!\n"));
		RTMP_SEM_UNLOCK(pTimer->timer_lock);
	}
}


/*
	========================================================================

	Routine Description:
		Cancel timer objects

	Arguments:
		Adapter						Pointer to our adapter

	Return Value:
		None

	IRQL = PASSIVE_LEVEL
	IRQL = DISPATCH_LEVEL

	Note:
		1.) To use this routine, must call RTMPInitTimer before.
		2.) Reset NIC to initial state AS IS system boot up time.

	========================================================================
*/
VOID RTMPCancelTimer(RALINK_TIMER_STRUCT *pTimer, BOOLEAN *pCancelled)
{
	if (!pTimer->timer_lock)
		goto end;

	RTMP_SEM_LOCK(pTimer->timer_lock);

	if (pTimer->Valid) {
		if (pTimer->State == FALSE)
			pTimer->Repeat = FALSE;

		RTMP_SEM_UNLOCK(pTimer->timer_lock);
		RTMP_OS_Del_Timer(&pTimer->TimerObj, pCancelled);
		RTMP_SEM_LOCK(pTimer->timer_lock);

		if (*pCancelled == TRUE)
			pTimer->State = TRUE;

#ifdef RTMP_TIMER_TASK_SUPPORT
		/* We need to go-through the TimerQ to findout this timer handler and remove it if */
		/*		it's still waiting for execution.*/
		RtmpTimerQRemove(pTimer->pAd, pTimer);
#endif /* RTMP_TIMER_TASK_SUPPORT */
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s: %lx\n", __func__, (ULONG)pTimer));
	}

	RTMP_SEM_UNLOCK(pTimer->timer_lock);
	return;
end:
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("RTMPCancelTimer failed, Timer hasn't been initialize!\n"));
}


VOID RTMPReleaseTimer(RALINK_TIMER_STRUCT *pTimer, BOOLEAN *pCancelled)
{
	if (!pTimer->timer_lock)
		goto end;

	RTMP_SEM_LOCK(pTimer->timer_lock);

	if (pTimer->Valid) {
		if (pTimer->State == FALSE)
			pTimer->Repeat = FALSE;

		RTMP_SEM_UNLOCK(pTimer->timer_lock);
		RTMP_OS_Del_Timer(&pTimer->TimerObj, pCancelled);
		RTMP_SEM_LOCK(pTimer->timer_lock);

		if (*pCancelled == TRUE)
			pTimer->State = TRUE;

#ifdef RTMP_TIMER_TASK_SUPPORT
		/* We need to go-through the TimerQ to findout this timer handler and remove it if */
		/*		it's still waiting for execution.*/
		RtmpTimerQRemove(pTimer->pAd, pTimer);
#endif /* RTMP_TIMER_TASK_SUPPORT */
		/* release timer */
		RTMP_OS_Release_Timer(&pTimer->TimerObj);
		pTimer->Valid = FALSE;
		/* TODO: shiang-usw, merge this from NXTC, make sure if that's necessary here!! */
		RTMP_TimerListRelease(pTimer->pAd, pTimer);
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s: %lx\n", __func__, (ULONG)pTimer));
	}

	RTMP_SEM_UNLOCK(pTimer->timer_lock);
end:
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("RTMPReleasefailed, Timer hasn't been initialize!\n"));
}


/*
	========================================================================

	Routine Description:
		Enable RX

	Arguments:
		pAd						Pointer to our adapter

	Return Value:
		None

	IRQL <= DISPATCH_LEVEL

	Note:
		Before Enable RX, make sure you have enabled Interrupt.
	========================================================================
*/
VOID RTMPEnableRxTx(RTMP_ADAPTER *pAd)
{
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("==> RTMPEnableRxTx\n"));
	RT28XXDMAEnable(pAd);
	AsicSetRxFilter(pAd);

	if (pAd->CommonCfg.bTXRX_RXV_ON)
		AsicSetMacTxRx(pAd, ASIC_MAC_TXRX_RXV, TRUE);
	else
		AsicSetMacTxRx(pAd, ASIC_MAC_TXRX, TRUE);

	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("<== RTMPEnableRxTx\n"));
}


void CfgInitHook(RTMP_ADAPTER *pAd)
{
	/*pAd->bBroadComHT = TRUE;*/
}


static INT RtmpChipOpsRegister(RTMP_ADAPTER *pAd, INT infType)
{
	RTMP_CHIP_OP *pChipOps = &pAd->chipOps;
	int ret = 0;
	NdisZeroMemory(pChipOps, sizeof(RTMP_CHIP_OP));
	NdisZeroMemory(&pAd->chipCap, sizeof(RTMP_CHIP_CAP));
	ret = RtmpChipOpsHook(pAd);

	if (ret) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("chipOps hook error\n"));
		return ret;
	}

	/* MCU related */
	ChipOpsMCUHook(pAd, pAd->chipCap.MCUType);
	get_dev_config_idx(pAd);
	return ret;
}


#ifdef RTMP_USB_SUPPORT
BOOLEAN PairEP(RTMP_ADAPTER *pAd, UINT8 EP)
{
	RTMP_CHIP_CAP *pChipCap = &pAd->chipCap;
	int i;
	int found = 0;

	if (pChipCap->CommandBulkOutAddr == EP) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Endpoint(%x) is for In-band Command\n", EP));
		found = 1;
	}

	for (i = 0; i < 4; i++) {
		if (pChipCap->WMM0ACBulkOutAddr[i] == EP) {
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Endpoint(%x) is for WMM0 AC%d\n", EP, i));
			found = 1;
		}
	}

	if (pChipCap->WMM1ACBulkOutAddr == EP) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Endpoint(%x) is for WMM1 AC0\n", EP));
		found = 1;
	}

	if (pChipCap->DataBulkInAddr == EP) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Endpoint(%x) is for Data-In\n", EP));
		found = 1;
	}

	if (pChipCap->CommandRspBulkInAddr == EP) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Endpoint(%x) is for Command Rsp\n", EP));
		found = 1;
	}

	if (!found) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Endpoint(%x) do not pair\n", EP));
		return FALSE;
	} else
		return TRUE;
}
#endif /* RTMP_USB_SUPPORT */


PNET_DEV get_netdev_from_bssid(RTMP_ADAPTER *pAd, UCHAR wdev_idx)
{
	PNET_DEV dev_p = NULL;

	if (wdev_idx < WDEV_NUM_MAX)
		dev_p = pAd->wdev_list[wdev_idx]->if_dev;

	ASSERT((dev_p != NULL));
	return dev_p;
}


INT RtmpRaDevCtrlInit(VOID *pAdSrc, RTMP_INF_TYPE infType)
{
	RTMP_ADAPTER *pAd = (PRTMP_ADAPTER)pAdSrc;
#ifdef RTMP_MAC_USB
	UINT8 i;
#endif /* RTMP_MAC_USB */
#ifdef FW_DUMP_SUPPORT
	pAd->fw_dump_max_size = MAX_FW_DUMP_SIZE;
	RTMP_OS_FWDUMP_PROCINIT(pAd);
#endif
	/* Assign the interface type. We need use it when do register/EEPROM access.*/
	pAd->infType = infType;
#ifdef CONFIG_STA_SUPPORT
	pAd->OpMode = OPMODE_STA;
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("STA Driver version-%s\n", STA_DRIVER_VERSION));
#endif /* CONFIG_STA_SUPPORT */
#ifdef CONFIG_AP_SUPPORT
	pAd->OpMode = OPMODE_AP;
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("AP Driver version-%s\n", AP_DRIVER_VERSION));
#endif /* CONFIG_AP_SUPPORT */
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("pAd->infType=%d\n", pAd->infType));
#if defined(P2P_SUPPORT) || defined(RT_CFG80211_P2P_SUPPORT) || defined(CFG80211_MULTI_STA)
	pAd->OpMode = OPMODE_STA;
#endif /* P2P_SUPPORT || RT_CFG80211_P2P_SUPPORT || CFG80211_MULTI_STA */
	RTMP_SEM_EVENT_INIT(&(pAd->AutoRateLock), &pAd->RscSemMemList);
#ifdef RTMP_MAC_USB
	RTMP_SEM_EVENT_INIT(&(pAd->UsbVendorReq_semaphore), &pAd->RscSemMemList);
	RTMP_SEM_EVENT_INIT(&(pAd->reg_atomic), &pAd->RscSemMemList);
	RTMP_SEM_EVENT_INIT(&(pAd->hw_atomic), &pAd->RscSemMemList);
	RTMP_SEM_EVENT_INIT(&(pAd->cal_atomic), &pAd->RscSemMemList);
	RTMP_SEM_EVENT_INIT(&(pAd->tssi_lock), &pAd->RscSemMemList);

	if (pAd->UsbVendorReqBuf) {
		MTWF_LOG(DBG_CAT_HIF, CATHIF_USB, DBG_LVL_WARN,
				 ("%s UsbVendorReqBuf not null 0x%p, skip alloc\n",
				  __func__, pAd->UsbVendorReqBuf));
		goto skip_alloc_vrbuf;
	}

	os_alloc_mem(pAd, (PUCHAR *)&pAd->UsbVendorReqBuf, MAX_PARAM_BUFFER_SIZE - 1);

	if (pAd->UsbVendorReqBuf == NULL) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Allocate vendor request temp buffer failed!\n"));
		return FALSE;
	}

skip_alloc_vrbuf:
#endif /* RTMP_MAC_USB */
#ifdef MULTIPLE_CARD_SUPPORT
#ifdef RTMP_FLASH_SUPPORT
	/*	if ((IS_PCIE_INF(pAd))) */
	{
		/* specific for RT6855/RT6856 */
		pAd->E2P_OFFSET_IN_FLASH[0] = 0x40000;
		pAd->E2P_OFFSET_IN_FLASH[1] = 0x48000;
	}
#endif /* RTMP_FLASH_SUPPORT */
#endif /* MULTIPLE_CARD_SUPPORT */

	if (RtmpChipOpsRegister(pAd, infType))
		return FALSE;

	AsicGetMacInfo(pAd, &pAd->ChipID, &pAd->HWVersion, &pAd->FWVersion);
	/*initial wlan hook module*/
	WLAN_HOOK_INIT();

	/* dynamic allocation of ChipCap-dependent data structure */
	if (alloc_chip_cap_dep_data(pAd) != NDIS_STATUS_SUCCESS) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("Failed to allocate memory - ChipCap-dependent data structure\n"));
		return FALSE;
	}

	/*for HdevCfg*/
	HcCfgInit(pAd);
#ifdef RESOURCE_PRE_ALLOC

	/*
		move this function from mt_wifi_init() to here. now this function only allocate memory and
		leave the initialization job to RTMPInitTxRxRingMemory() which called in mt_wifi_init().
	*/
	if (RTMPAllocTxRxRingMemory(pAd) != NDIS_STATUS_SUCCESS) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Failed to allocate memory - TxRxRing\n"));
		return FALSE;
	}

#endif /* RESOURCE_PRE_ALLOC */
#ifdef RTMP_MAC_USB

	for (i = 0; i < 6; i++) {
		if (!PairEP(pAd, pAd->BulkOutEpAddr[i]))
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Invalid bulk out ep(%x)\n", pAd->BulkOutEpAddr[i]));
	}

	for (i = 0; i < 2; i++) {
		if (!PairEP(pAd, pAd->BulkInEpAddr[i]))
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Invalid bulk in ep(%x)\n", pAd->BulkInEpAddr[i]));
	}

#endif /* RTMP_MAC_USB */
#ifdef MULTIPLE_CARD_SUPPORT
	{
		extern BOOLEAN RTMP_CardInfoRead(PRTMP_ADAPTER pAd);
		/* find its profile path*/
		pAd->MC_RowID = -1; /* use default profile path*/
		RTMP_CardInfoRead(pAd);

		if (pAd->MC_RowID == -1)
#ifdef CONFIG_AP_SUPPORT
			strcpy(pAd->MC_FileName, AP_PROFILE_PATH);

#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
		strcpy(pAd->MC_FileName, STA_PROFILE_PATH);
#endif /* CONFIG_STA_SUPPORT */
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("MC> ROW = %d, PATH = %s\n", pAd->MC_RowID, pAd->MC_FileName));
	}
#endif /* MULTIPLE_CARD_SUPPORT */
#ifdef CONFIG_CSO_SUPPORT

	if (pAd->chipCap.asic_caps & fASIC_CAP_CSO)
		RTMP_SET_MORE_FLAG(pAd, fASIC_CAP_CSO);

#endif /* CONFIG_CSO_SUPPORT */
#ifdef MCS_LUT_SUPPORT

	if (pAd->chipCap.asic_caps & fASIC_CAP_MCS_LUT) {
		if (MAX_LEN_OF_MAC_TABLE < 128)
			RTMP_SET_MORE_FLAG(pAd, fASIC_CAP_MCS_LUT);
		else {
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s(): MCS_LUT not used becasue MacTb size(%d) > 128!\n",
					 __func__, MAX_LEN_OF_MAC_TABLE));
		}
	}

#endif /* MCS_LUT_SUPPORT */
#ifdef MT_MAC

	if (pAd->chipCap.hif_type != HIF_MT)
#endif
	{
		if (load_patch(pAd) != NDIS_STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("load patch failed!\n"));
			return FALSE;
		}
	}

	return 0;
}


BOOLEAN RtmpRaDevCtrlExit(IN VOID *pAdSrc)
{
	RTMP_ADAPTER *pAd = (RTMP_ADAPTER *)pAdSrc;
	INT index;
#ifdef MULTIPLE_CARD_SUPPORT
	extern UINT8  MC_CardUsed[MAX_NUM_OF_MULTIPLE_CARD];

	if ((pAd->MC_RowID >= 0) && (pAd->MC_RowID <= MAX_NUM_OF_MULTIPLE_CARD))
		MC_CardUsed[pAd->MC_RowID] = 0; /* not clear MAC address*/

#endif /* MULTIPLE_CARD_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
#ifdef CREDENTIAL_STORE
	NdisFreeSpinLock(&pAd->StaCtIf.Lock);
#endif /* CREDENTIAL_STORE */
#endif /* CONFIG_STA_SUPPORT */
	RTMP_SEM_EVENT_DESTORY(&(pAd->AutoRateLock));
#ifdef RTMP_MAC_SDIO
	RTMP_SEM_EVENT_DESTORY(&(pAd->PowerLock));
#endif
#ifdef RTMP_MAC_USB
	RTMP_SEM_EVENT_DESTORY(&(pAd->UsbVendorReq_semaphore));
	RTMP_SEM_EVENT_DESTORY(&(pAd->reg_atomic));
	RTMP_SEM_EVENT_DESTORY(&(pAd->hw_atomic));
	RTMP_SEM_EVENT_DESTORY(&(pAd->cal_atomic));
	RTMP_SEM_EVENT_DESTORY(&(pAd->tssi_lock));

	if (pAd->UsbVendorReqBuf) {
		os_free_mem(pAd->UsbVendorReqBuf);
		pAd->UsbVendorReqBuf = NULL;
	}

#endif /* RTMP_MAC_USB */

	/*
		Free ProbeRespIE Table
	*/
	for (index = 0; index < MAX_LEN_OF_BSS_TABLE; index++) {
		if (pAd->ProbeRespIE[index].pIe)
			os_free_mem(pAd->ProbeRespIE[index].pIe);
	}

#ifdef RESOURCE_PRE_ALLOC
	RTMPFreeTxRxRingMemory(pAd);
#endif /* RESOURCE_PRE_ALLOC */
#ifdef FW_DUMP_SUPPORT
	RTMP_OS_FWDUMP_PROCREMOVE(pAd);

	if (pAd->fw_dump_buffer) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: Free FW dump buffer\n", __func__));
		os_free_mem(pAd->fw_dump_buffer);
		pAd->fw_dump_buffer = 0;
		pAd->fw_dump_size = 0;
		pAd->fw_dump_read = 0;
	}

#endif
	HcCfgExit(pAd);
	free_chip_cap_dep_data(pAd);
	wpf_config_exit(pAd);
	RTMPFreeAdapter(pAd);
	return TRUE;
}


#ifdef CONFIG_AP_SUPPORT
#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
VOID RTMP_11N_D3_TimerInit(RTMP_ADAPTER *pAd)
{
	RTMPInitTimer(pAd, &pAd->CommonCfg.Bss2040CoexistTimer, GET_TIMER_FUNCTION(Bss2040CoexistTimeOut), pAd, FALSE);
}

VOID RTMP_11N_D3_TimerRelease(RTMP_ADAPTER *pAd)
{
	BOOLEAN Cancel;
	RTMPReleaseTimer(&pAd->CommonCfg.Bss2040CoexistTimer, &Cancel);
}

#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */


#ifdef VENDOR_FEATURE3_SUPPORT
VOID RTMP_IO_WRITE32(
	PRTMP_ADAPTER pAd,
	UINT32 Offset,
	UINT32 Value)
{
	_RTMP_IO_WRITE32(pAd, Offset, Value);
}
#endif /* VENDOR_FEATURE3_SUPPORT */


VOID AntCfgInit(RTMP_ADAPTER *pAd)
{
	/* TODO: shiang-7603 */
	if (pAd->chipCap.hif_type == HIF_MT) {
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(%d): Not support for HIF_MT yet!\n",
				 __func__, __LINE__));
		return;
	}

#ifdef RELEASE_EXCLUDE
	/* Because profile is read before efuse, so if profile didn't set up ant, it needs to set by efuse's setting. */
#endif
#ifdef ANT_DIVERSITY_SUPPORT
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s: RxAntDiversityCfg %d\n", __func__,
			 pAd->CommonCfg.RxAntDiversityCfg));

	/* determine EEPORM Ant Diversity Bit */
	if ((pAd->NicConfig2.word & 0x1800) == 0x800) {
		pAd->CommonCfg.bSWRxAntDiversity = TRUE;

		if (pAd->chipCap.FlgIsHwAntennaDiversitySup)
			pAd->CommonCfg.bHWRxAntDiversity = TRUE;
	}

#endif	/* ANT_DIVERSITY_SUPPORT */
#ifdef TXRX_SW_ANTDIV_SUPPORT
	/* EEPROM 0x34[15:12] = 0xF is invalid, 0x2~0x3 is TX/RX SW AntDiv */
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s: bTxRxSwAntDiv %d\n", __func__, pAd->chipCap.bTxRxSwAntDiv));

	if (pAd->chipCap.bTxRxSwAntDiv) {
#ifdef ANT_DIVERSITY_SUPPORT

		/* if PPAD and TXRX AntDiv are both on, only enable PPAD */
		if ((pAd->CommonCfg.bHWRxAntDiversity) && (pAd->chipCap.FlgIsHwAntennaDiversitySup))
			pAd->chipCap.bTxRxSwAntDiv = FALSE;		/* for GPIO switch */
		else
			pAd->CommonCfg.bSWRxAntDiversity = TRUE; /* for sw diversity capability */

#endif /* ANT_DIVERSITY_SUPPORT */
		MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("Antenna word %X/%d, AntDiv %d\n",
				 pAd->Antenna.word, pAd->Antenna.field.BoardType, pAd->NicConfig2.field.AntDiversity));
	}

#endif /* TXRX_SW_ANTDIV_SUPPORT */
#ifdef ANT_DIVERSITY_SUPPORT

	/* Because profile read before EEPROM, so profile can not determine what kind od diversity enable, */
	/* so postpone to select SW/HW Diversity, HW has the higher priority */
	if (pAd->CommonCfg.RxAntDiversityCfg == ANT_DIVERSITY_ENABLE) {
		if (pAd->CommonCfg.bHWRxAntDiversity)	/* EEPROM setting */
			pAd->CommonCfg.RxAntDiversityCfg = ANT_HW_DIVERSITY_ENABLE;	/* profile, ioctl setting */
		else if (pAd->CommonCfg.bSWRxAntDiversity)	/* EEPROM setting */
			pAd->CommonCfg.RxAntDiversityCfg = ANT_SW_DIVERSITY_ENABLE;	/* profile, ioctl setting */
		else
			pAd->CommonCfg.RxAntDiversityCfg = ANT_DIVERSITY_DEFAULT; /* by EEPROM */
	}

	if (pAd->CommonCfg.RxAntDiversityCfg == ANT_DIVERSITY_DEFAULT)
#endif
	{
		if (pAd->NicConfig2.field.AntOpt == 1) { /* ant selected by efuse */
			if (pAd->NicConfig2.field.AntDiversity == 0) { /* main */
				pAd->RxAnt.Pair1PrimaryRxAnt = 0;
				pAd->RxAnt.Pair1SecondaryRxAnt = 1;
			} else { /* aux */
				pAd->RxAnt.Pair1PrimaryRxAnt = 1;
				pAd->RxAnt.Pair1SecondaryRxAnt = 0;
			}
		} else if (pAd->NicConfig2.field.AntDiversity == 0) { /* Ant div off: default ant is main */
			pAd->RxAnt.Pair1PrimaryRxAnt = 0;
			pAd->RxAnt.Pair1SecondaryRxAnt = 1;
		} else if (pAd->NicConfig2.field.AntDiversity == 1) /* Ant div on */
#ifdef ANT_DIVERSITY_SUPPORT
			if (pAd->chipCap.FlgIsHwAntennaDiversitySup)
				pAd->CommonCfg.RxAntDiversityCfg = ANT_HW_DIVERSITY_ENABLE;

#else
		{/* eeprom on, but sw ant div support is not enabled: default ant is main */
			pAd->RxAnt.Pair1PrimaryRxAnt = 0;
			pAd->RxAnt.Pair1SecondaryRxAnt = 1;
		}
#endif
	}

	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s: primary/secondary ant %d/%d\n",
			 __func__,
			 pAd->RxAnt.Pair1PrimaryRxAnt,
			 pAd->RxAnt.Pair1SecondaryRxAnt));
#ifdef ANT_DIVERSITY_SUPPORT
	MTWF_LOG(DBG_CAT_INIT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s: RxAntDiv %d/%d\n",
			 __func__,
			 pAd->CommonCfg.bSWRxAntDiversity,
			 pAd->CommonCfg.bHWRxAntDiversity));
#endif
}


