/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 * (c) Copyright 2002, Ralink Technology, Inc.
 *
 * All rights reserved. Ralink's source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of Ralink Tech. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	cmm_sync.c

	Abstract:

	Revision History:
	Who			When			What
	--------	----------		----------------------------------------------
	John Chang	2004-09-01      modified for rt2561/2661
*/
#include "rt_config.h"

/*BaSizeArray follows the 802.11n definition as MaxRxFactor.  2^(13+factor) bytes. When factor =0, it's about Ba buffer size =8.*/
UCHAR BaSizeArray[4] = {8, 16, 32, 64};

extern COUNTRY_REGION_CH_DESC Country_Region_ChDesc_2GHZ[];
extern UINT16 const Country_Region_GroupNum_2GHZ;
extern COUNTRY_REGION_CH_DESC Country_Region_ChDesc_5GHZ[];
extern UINT16 const Country_Region_GroupNum_5GHZ;

/*
	==========================================================================
	Description:
		Update StaCfg[0]->ChannelList[] according to 1) Country Region 2) RF IC type,
		and 3) PHY-mode user selected.
		The outcome is used by driver when doing site survey.

	IRQL = PASSIVE_LEVEL
	IRQL = DISPATCH_LEVEL

	==========================================================================
 */
static UCHAR BuildChannelListFor2G(RTMP_ADAPTER *pAd, UCHAR index)
{
	UCHAR i, j, num = 0;
	PCH_DESC pChDesc = NULL;
	BOOLEAN bRegionFound = FALSE;
	PUCHAR pChannelList;
	PUCHAR pChannelListFlag;

	for (i = 0; i < Country_Region_GroupNum_2GHZ; i++) {
		if ((pAd->CommonCfg.CountryRegion & 0x7f) ==
			Country_Region_ChDesc_2GHZ[i].RegionIndex) {
			pChDesc = Country_Region_ChDesc_2GHZ[i].pChDesc;
			num = TotalChNum(pChDesc);
			pAd->CommonCfg.pChDesc2G = (PUCHAR)pChDesc;
			bRegionFound = TRUE;
			break;
		}
	}

	if (!bRegionFound) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("CountryRegion=%d not support", pAd->CommonCfg.CountryRegion));
		goto done;
	}

	if (num > 0) {
		os_alloc_mem(NULL, (UCHAR **)&pChannelList, num * sizeof(UCHAR));

		if (!pChannelList) {
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s:Allocate memory for ChannelList failed\n", __func__));
			goto done;
		}

		os_alloc_mem(NULL, (UCHAR **)&pChannelListFlag, num * sizeof(UCHAR));

		if (!pChannelListFlag) {
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s:Allocate memory for ChannelListFlag failed\n", __func__));
			os_free_mem(pChannelList);
			goto done;
		}

		for (i = 0; i < num; i++) {
			pChannelList[i] = GetChannel_2GHZ(pChDesc, i);
			pChannelListFlag[i] = GetChannelFlag(pChDesc, i);
		}

		for (i = 0; i < num; i++) {
			for (j = 0; j < MAX_NUM_OF_CHANNELS; j++) {
				if (pChannelList[i] == pAd->TxPower[j].Channel)
					os_move_mem(&pAd->ChannelList[index + i], &pAd->TxPower[j], sizeof(CHANNEL_TX_POWER));

				pAd->ChannelList[index + i].Flags = pChannelListFlag[i];
				/* TODO: shiang-7603, NdisMoveMemory may replace the pAd->ChannelList[index+i].Channel as other values! */
				pAd->ChannelList[index + i].Channel = pChannelList[i];
			}

			pAd->ChannelList[index + i].MaxTxPwr = 20;
#ifdef RT_CFG80211_SUPPORT
			CFG80211OS_ChanInfoInit(
				pAd->pCfg80211_CB,
				index + i,
				pAd->ChannelList[index + i].Channel,
				pAd->ChannelList[index + i].MaxTxPwr,
				TRUE,
				TRUE);
#endif /* RT_CFG80211_SUPPORT */
		}

		index += num;
		os_free_mem(pChannelList);
		os_free_mem(pChannelListFlag);
	}

#ifdef RT_CFG80211_SUPPORT

	if (CFG80211OS_UpdateRegRuleByRegionIdx(pAd->pCfg80211_CB, pChDesc, NULL) != 0)
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Update RegRule failed!\n"));

#endif /* RT_CFG80211_SUPPORT */
done:
	return index;
}


static UCHAR BuildChannelListFor5G(RTMP_ADAPTER *pAd, UCHAR index)
{
	UCHAR i, j, num = 0;
	PCH_DESC pChDesc = NULL;
	BOOLEAN bRegionFound = FALSE;
	PUCHAR pChannelList;
	PUCHAR pChannelListFlag;

	for (i = 0; i < Country_Region_GroupNum_5GHZ; i++) {
		if ((pAd->CommonCfg.CountryRegionForABand & 0x7f) ==
			Country_Region_ChDesc_5GHZ[i].RegionIndex) {
			pChDesc = Country_Region_ChDesc_5GHZ[i].pChDesc;
			num = TotalChNum(pChDesc);
			pAd->CommonCfg.pChDesc5G = (PUCHAR)pChDesc;
			bRegionFound = TRUE;
			break;
		}
	}

	if (!bRegionFound) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("CountryRegionABand=%d not support",
				 pAd->CommonCfg.CountryRegionForABand));
		goto done;
	}

	if (num > 0) {
		UCHAR RadarCh[16] = {52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144};

		UCHAR q = 0;

		os_alloc_mem(NULL, (UCHAR **)&pChannelList, num * sizeof(UCHAR));

		if (!pChannelList) {
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s:Allocate memory for ChannelList failed\n", __func__));
			goto done;
		}

		os_alloc_mem(NULL, (UCHAR **)&pChannelListFlag, num * sizeof(UCHAR));

		if (!pChannelListFlag) {
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s:Allocate memory for ChannelListFlag failed\n", __func__));
			os_free_mem(pChannelList);
			goto done;
		}

		for (i = 0; i < num; i++) {
			if ((pAd->CommonCfg.bIEEE80211H == 0) || ((pAd->CommonCfg.bIEEE80211H == 1)
				&& (pAd->CommonCfg.RDDurRegion != FCC))) {
				if (MTChGrpValid(pAd))	{
					if (MTChGrpChannelChk(pAd, GetChannel_5GHZ(pChDesc, i))) {
						pChannelList[q] = GetChannel_5GHZ(pChDesc, i);
						pChannelListFlag[q] = GetChannelFlag(pChDesc, i);
						q++;
					}
				} else {
			pChannelList[i] = GetChannel_5GHZ(pChDesc, i);
			pChannelListFlag[i] = GetChannelFlag(pChDesc, i);
		}
			}
		}

#ifdef CONFIG_AP_SUPPORT

		for (i = 0; i < num; i++) {
			if ((pAd->CommonCfg.bIEEE80211H == 0) || ((pAd->CommonCfg.bIEEE80211H == 1) && (pAd->CommonCfg.RDDurRegion != FCC))) {
				pChannelList[q] = GetChannel_5GHZ(pChDesc, i);
				pChannelListFlag[q] = GetChannelFlag(pChDesc, i);
				q++;
			}
			/*Based on the requiremnt of FCC, some channles could not be used anymore when test DFS function.*/
			else if ((pAd->CommonCfg.bIEEE80211H == 1) &&
					 (pAd->CommonCfg.RDDurRegion == FCC) &&
					 (pAd->Dot11_H.bDFSIndoor == 1)) {
				if ((GetChannel_5GHZ(pChDesc, i) < 116) || (GetChannel_5GHZ(pChDesc, i) > 128)) {
					if (MTChGrpValid(pAd)) {
						if (MTChGrpChannelChk(pAd, GetChannel_5GHZ(pChDesc, i))) {
							pChannelList[q] = GetChannel_5GHZ(pChDesc, i);
							pChannelListFlag[q] = GetChannelFlag(pChDesc, i);
							q++;
						}
						} else {
					pChannelList[q] = GetChannel_5GHZ(pChDesc, i);
					pChannelListFlag[q] = GetChannelFlag(pChDesc, i);
					q++;
				}
				}
			} else if ((pAd->CommonCfg.bIEEE80211H == 1) &&
					   (pAd->CommonCfg.RDDurRegion == FCC) &&
					   (pAd->Dot11_H.bDFSIndoor == 0)) {
				if ((GetChannel_5GHZ(pChDesc, i) < 100) || (GetChannel_5GHZ(pChDesc, i) > 140)) {
					if (MTChGrpValid(pAd)) {
						if (MTChGrpChannelChk(pAd, GetChannel_5GHZ(pChDesc, i))) {
					pChannelList[q] = GetChannel_5GHZ(pChDesc, i);
					pChannelListFlag[q] = GetChannelFlag(pChDesc, i);
					q++;
				}
				} else {
					pChannelList[q] = GetChannel_5GHZ(pChDesc, i);
					pChannelListFlag[q] = GetChannelFlag(pChDesc, i);
					q++;
				}
			}
			} else if (MTChGrpValid(pAd) && MTChGrpChannelChk(pAd, GetChannel_5GHZ(pChDesc, i))) {
				pChannelList[q] = GetChannel_5GHZ(pChDesc, i);
				pChannelListFlag[q] = GetChannelFlag(pChDesc, i);
				q++;
				}
		}

		num = q;
#endif /* CONFIG_AP_SUPPORT */

		for (i = 0; i < num; i++) {
			for (j = 0; j < MAX_NUM_OF_CHANNELS; j++) {
				if (pChannelList[i] == pAd->TxPower[j].Channel)
					os_move_mem(&pAd->ChannelList[index + i], &pAd->TxPower[j], sizeof(CHANNEL_TX_POWER));

				pAd->ChannelList[index + i].Flags = pChannelListFlag[i];
				/* TODO: shiang-7603, NdisMoveMemory may replace the pAd->ChannelList[index+i].Channel as other values! */
				pAd->ChannelList[index + i].Channel = pChannelList[i];
			}

			for (j = 0; j < 16; j++) {
				if (pChannelList[i] == RadarCh[j])
					pAd->ChannelList[index + i].DfsReq = TRUE;
			}

			pAd->ChannelList[index + i].MaxTxPwr = 20;
#ifdef RT_CFG80211_SUPPORT
			CFG80211OS_ChanInfoInit(
				pAd->pCfg80211_CB,
				index + i,
				pAd->ChannelList[index + i].Channel,
				pAd->ChannelList[index + i].MaxTxPwr,
				TRUE,
				TRUE);
#endif /*RT_CFG80211_SUPPORT*/
		}

		index += num;
		os_free_mem(pChannelList);
		os_free_mem(pChannelListFlag);
	}

#ifdef RT_CFG80211_SUPPORT

	if (CFG80211OS_UpdateRegRuleByRegionIdx(pAd->pCfg80211_CB, NULL, pChDesc) != 0)
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("Update RegRule failed!\n"));

#endif /*RT_CFG80211_SUPPORT*/
done:
	return index;
}


static bool Set_Diff_Bw(RTMP_ADAPTER *pAd, UCHAR wcid, UCHAR bw, UCHAR ext_ch)
{
	PMAC_TABLE_ENTRY pEntry = NULL;
	struct wifi_dev *wdev = NULL;
	UCHAR op_ht_bw, op_ext_ch;
	pEntry = &pAd->MacTab.Content[wcid];
	wdev = pEntry->wdev;

	if (!wdev)
		return FALSE;

	op_ht_bw = wlan_operate_get_ht_bw(wdev);
	op_ext_ch = wlan_operate_get_ext_cha(wdev);

	if (op_ht_bw != bw) {
		wlan_operate_set_ht_bw(wdev, bw, ext_ch);
		pEntry->HTPhyMode.field.BW = bw;
#ifdef RACTRL_FW_OFFLOAD_SUPPORT

		if (pAd->chipCap.fgRateAdaptFWOffload == TRUE) {
			CMD_STAREC_AUTO_RATE_UPDATE_T rRaParam;
			NdisZeroMemory(&rRaParam, sizeof(CMD_STAREC_AUTO_RATE_UPDATE_T));

			if (bw == HT_BW_40)
				rRaParam.u4Field = RA_PARAM_HT_2040_BACK;
			else
				rRaParam.u4Field = RA_PARAM_HT_2040_COEX;

			RAParamUpdate(pAd, pEntry, &rRaParam);
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("FallBack APClient BW to %s\n",
					 rRaParam.u4Field == (RA_PARAM_HT_2040_BACK) ? "BW_40" : "BW_20"));
		}

#endif /* RACTRL_FW_OFFLOAD_SUPPORT */
	}

	return TRUE;
}

VOID BuildChannelList(RTMP_ADAPTER *pAd)
{
	UCHAR index = 0, i;
	BOOLEAN Is2GRun = HcIsRfSupport(pAd, RFIC_24GHZ);
	BOOLEAN Is5GRun = HcIsRfSupport(pAd, RFIC_5GHZ);
#ifdef CONFIG_AP_SUPPORT
	pAd->AutoChSelCtrl.ChannelListNum2G = 0;
	pAd->AutoChSelCtrl.ChannelListNum5G = 0;
#endif/*CONFIG_AP_SUPPORT*/
#ifdef MT_DFS_SUPPORT
	DfsSaveNonOccupancy(pAd);/* Jelly20150323 */
#endif
	os_zero_mem(pAd->ChannelList, MAX_NUM_OF_CHANNELS * sizeof(CHANNEL_TX_POWER));

	if (Is2GRun) {
		index = BuildChannelListFor2G(pAd, index);
#ifdef CONFIG_AP_SUPPORT
		pAd->AutoChSelCtrl.ChannelListNum2G = index;
#endif/*CONFIG_AP_SUPPORT*/
	}

	if (Is5GRun) {
		index = BuildChannelListFor5G(pAd, index);
#ifdef CONFIG_AP_SUPPORT
		pAd->AutoChSelCtrl.ChannelListNum5G = index;
#endif/*CONFIG_AP_SUPPORT*/
	}

	pAd->ChannelListNum = index;
	/*Build Channel CAP, should after get ChannelListNum*/
#ifdef DOT11_N_SUPPORT

	for (i = 0; i < pAd->ChannelListNum; i++) {
		if (N_ChannelGroupCheck(pAd, pAd->ChannelList[i].Channel))
			pAd->ChannelList[i].Flags |= CHANNEL_40M_CAP;

#ifdef DOT11_VHT_AC

		if (vht80_channel_group(pAd, pAd->ChannelList[i].Channel))
			pAd->ChannelList[i].Flags |= CHANNEL_80M_CAP;

		if (vht160_channel_group(pAd, pAd->ChannelList[i].Channel))
			pAd->ChannelList[i].Flags |= CHANNEL_160M_CAP;

#endif /* DOT11_VHT_AC */
	}

#endif /* DOT11_N_SUPPORT */
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF,
			 ("CountryCode(2.4G/5G)=%d/%d, RFIC=%d, support %d channels\n",
			  pAd->CommonCfg.CountryRegion, pAd->CommonCfg.CountryRegionForABand, pAd->RfIcType, pAd->ChannelListNum));
#ifdef MT_DFS_SUPPORT
	DfsRecoverNonOccupancy(pAd); /* Jelly20150323 */
#endif
#ifdef DBG
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SupportedChannelList:\n"));

	for (i = 0; i < pAd->ChannelListNum; i++) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("\tChannel # %d: Pwr0/1 = %d/%d, Flags = %x\n ",
				 pAd->ChannelList[i].Channel,
				 pAd->ChannelList[i].Power,
				 pAd->ChannelList[i].Power2,
				 pAd->ChannelList[i].Flags));
	}

#endif
}

#ifdef CONFIG_AP_SUPPORT
/*
	==========================================================================
	Description:
	    This function is using for searching first channel in case of channel
	    list is cascaded by 2G + 5G.
	Return:
		ch - the first channel number of current phymode setting
	==========================================================================
 */
UCHAR GetFirstChByPhyMode(RTMP_ADAPTER *pAd, UCHAR PhyMode)
{
	UCHAR ChListNum;

	if (WMODE_CAP_2G(PhyMode)) {
		/* Return 2G first channel */
		return pAd->ChannelList[0].Channel;
	} else {
		ChListNum = pAd->AutoChSelCtrl.ChannelListNum2G;
		/* Return 5G first channel */
		return pAd->ChannelList[ChListNum].Channel;
	}
}
#endif/* CONFIG_AP_SUPPORT */

/*
	==========================================================================
	Description:
		This routine return the first channel number according to the country
		code selection and RF IC selection (signal band or dual band). It is called
		whenever driver need to start a site survey of all supported channels.
	Return:
		ch - the first channel number of current country code setting

	IRQL = PASSIVE_LEVEL

	==========================================================================
 */
UCHAR FirstChannel(RTMP_ADAPTER *pAd)
{
	return pAd->ChannelList[0].Channel;
}


/*
	==========================================================================
	Description:
		This routine returns the next channel number. This routine is called
		during driver need to start a site survey of all supported channels.
	Return:
		next_channel - the next channel number valid in current country code setting.
	Note:
		return 0 if no more next channel
	==========================================================================
 */
UCHAR NextChannel(RTMP_ADAPTER *pAd, UCHAR channel)
{
	int i;
	UCHAR next_channel = 0;
#ifdef P2P_SUPPORT
	UCHAR	CurrentChannel = channel;

	if (pAd->ScanCtrl.ScanType == SCAN_P2P_SEARCH) {
		if (IS_P2P_LISTEN(pAd)) {
			MTWF_LOG(DBG_CAT_PROTO, CATPROTO_SCAN, DBG_LVL_ERROR,
					 ("Error !! P2P Discovery state machine has change to Listen state during scanning !\n"));
			return next_channel;
		}

		for (i = 0; i < (pAd->P2pCfg.P2pProprietary.ListenChanelCount - 1); i++) {
			if (CurrentChannel == pAd->P2pCfg.P2pProprietary.ListenChanel[i])
				next_channel = pAd->P2pCfg.P2pProprietary.ListenChanel[i + 1];
		}

		P2P_INC_CHA_INDEX(pAd->P2pCfg.P2pProprietary.ListenChanelIndex, pAd->P2pCfg.P2pProprietary.ListenChanelCount);

		if (next_channel == CurrentChannel) {
			MTWF_LOG(DBG_CAT_PROTO, CATPROTO_SCAN, DBG_LVL_INFO, ("SYNC -  next_channel equals to CurrentChannel= %d\n",
					 next_channel));
			MTWF_LOG(DBG_CAT_PROTO, CATPROTO_SCAN, DBG_LVL_INFO, ("SYNC -  ListenChannel List : %d  %d  %d\n",
					 pAd->P2pCfg.P2pProprietary.ListenChanel[0],
					 pAd->P2pCfg.P2pProprietary.ListenChanel[1],
					 pAd->P2pCfg.P2pProprietary.ListenChanel[2]));
			next_channel = 0;
		}

		MTWF_LOG(DBG_CAT_PROTO, CATPROTO_SCAN, DBG_LVL_INFO, ("SYNC - P2P Scan return channel = %d. Listen Channel = %d.\n",
				 next_channel, channel));
		return next_channel;
	}

#endif /* P2P_SUPPORT */

	for (i = 0; i < (pAd->ChannelListNum - 1); i++) {
		if (channel == pAd->ChannelList[i].Channel) {
#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3

			/* Only scan effected channel if this is a SCAN_2040_BSS_COEXIST*/
			/* 2009 PF#2: Nee to handle the second channel of AP fall into affected channel range.*/
			if ((pAd->ScanCtrl.ScanType == SCAN_2040_BSS_COEXIST) && (pAd->ChannelList[i + 1].Channel > 14)) {
				channel = pAd->ChannelList[i + 1].Channel;
				continue;
			} else
#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */
			{
				/* Record this channel's idx in ChannelList array.*/
				next_channel = pAd->ChannelList[i + 1].Channel;
				break;
			}
		}
	}

	return next_channel;
}


/*
	==========================================================================
	Description:
		This routine is for Cisco Compatible Extensions 2.X
		Spec31. AP Control of Client Transmit Power
	Return:
		None
	Note:
	   Required by Aironet dBm(mW)
		   0dBm(1mW),   1dBm(5mW), 13dBm(20mW), 15dBm(30mW),
		  17dBm(50mw), 20dBm(100mW)

	   We supported
		   3dBm(Lowest), 6dBm(10%), 9dBm(25%), 12dBm(50%),
		  14dBm(75%),   15dBm(100%)

		The client station's actual transmit power shall be within +/- 5dB of
		the minimum value or next lower value.
	==========================================================================
 */
VOID ChangeToCellPowerLimit(RTMP_ADAPTER *pAd, UCHAR AironetCellPowerLimit)
{
	/*
	    valud 0xFF means that hasn't found power limit information
	    from the AP's Beacon/Probe response
	*/
	if (AironetCellPowerLimit == 0xFF)
		return;

	if (AironetCellPowerLimit < 6) { /*Used Lowest Power Percentage.*/
		pAd->CommonCfg.ucTxPowerPercentage[BAND0] = 6;
#ifdef DBDC_MODE
		pAd->CommonCfg.ucTxPowerPercentage[BAND1] = 6;
#endif /* DBDC_MODE */
	} else if (AironetCellPowerLimit < 9) {
		pAd->CommonCfg.ucTxPowerPercentage[BAND0] = 10;
#ifdef DBDC_MODE
		pAd->CommonCfg.ucTxPowerPercentage[BAND1] = 10;
#endif /* DBDC_MODE */
	} else if (AironetCellPowerLimit < 12) {
		pAd->CommonCfg.ucTxPowerPercentage[BAND0] = 25;
#ifdef DBDC_MODE
		pAd->CommonCfg.ucTxPowerPercentage[BAND1] = 25;
#endif /* DBDC_MODE */
	} else if (AironetCellPowerLimit < 14) {
		pAd->CommonCfg.ucTxPowerPercentage[BAND0] = 50;
#ifdef DBDC_MODE
		pAd->CommonCfg.ucTxPowerPercentage[BAND1] = 50;
#endif /* DBDC_MODE */
	} else if (AironetCellPowerLimit < 15) {
		pAd->CommonCfg.ucTxPowerPercentage[BAND0] = 75;
#ifdef DBDC_MODE
		pAd->CommonCfg.ucTxPowerPercentage[BAND1] = 75;
#endif /* DBDC_MODE */
	} else {
		pAd->CommonCfg.ucTxPowerPercentage[BAND0] = 100; /*else used maximum*/
#ifdef DBDC_MODE
		pAd->CommonCfg.ucTxPowerPercentage[BAND1] = 100;
#endif /* DBDC_MODE */
	}

	if (pAd->CommonCfg.ucTxPowerPercentage[BAND0] > pAd->CommonCfg.ucTxPowerDefault[BAND0])
		pAd->CommonCfg.ucTxPowerPercentage[BAND0] = pAd->CommonCfg.ucTxPowerDefault[BAND0];

#ifdef DBDC_MODE

	if (pAd->CommonCfg.ucTxPowerPercentage[BAND1] > pAd->CommonCfg.ucTxPowerDefault[BAND1])
		pAd->CommonCfg.ucTxPowerPercentage[BAND1] = pAd->CommonCfg.ucTxPowerDefault[BAND1];

#endif /* DBDC_MODE */
}

CHAR ConvertToRssi(RTMP_ADAPTER *pAd, struct raw_rssi_info *rssi_info, UCHAR rssi_idx)
{
	UCHAR RssiOffset, LNAGain;
	CHAR BaseVal;
	CHAR rssi, ret = 0;

	/* Rssi equals to zero or rssi_idx larger than 3 should be an invalid value*/
	if (rssi_idx >= pAd->Antenna.field.RxPath)
		return -99;

	rssi = rssi_info->raw_rssi[rssi_idx];

	if (rssi == 0)
		return -99;

	LNAGain = pAd->hw_cfg.lan_gain;

	if (pAd->LatchRfRegs.Channel > 14)
		RssiOffset = pAd->ARssiOffset[rssi_idx];
	else
		RssiOffset = pAd->BGRssiOffset[rssi_idx];

	BaseVal = -12;
#if defined(MT7603) || defined(MT7628) || defined(MT7636) || defined(MT7637) || defined(MT7615) || defined(MT7622) || \
defined(P18) || defined(MT7663)

	if (IS_MT7603(pAd) || IS_MT7628(pAd) || IS_MT76x6(pAd) || IS_MT7637(pAd) \
		|| IS_MT7615(pAd) || IS_MT7622(pAd) || IS_P18(pAd) || IS_MT7663(pAd)) {
		ret = (rssi + (CHAR)RssiOffset - (CHAR)LNAGain);
		return ret;
	}

#endif
	ret = (BaseVal - RssiOffset - LNAGain - rssi);
	return ret;
}


CHAR ConvertToSnr(RTMP_ADAPTER *pAd, UCHAR Snr)
{
	CHAR ret = 0;

	if (pAd->chipCap.SnrFormula == SNR_FORMULA2) {
		ret = (Snr * 3 + 8) >> 4;
		return ret;
	} else if (pAd->chipCap.SnrFormula == SNR_FORMULA3) {
		ret = (Snr * 3 / 16);
		return ret; /* * 0.1881 */
	} else {
		ret = ((0xeb	- Snr) * 3) /	16;
		return ret;
	}
}

BOOLEAN AdjustBwToSyncAp(RTMP_ADAPTER *pAd, BCN_IE_LIST *ie_list, UCHAR  Wcid, UCHAR fun_tb_idx)
{
	BOOLEAN bAdjust = FALSE;
#ifdef DOT11_N_SUPPORT
	PMAC_TABLE_ENTRY pEntry = NULL;
	struct wifi_dev *wdev = NULL;
	UCHAR op_ht_bw;
	UCHAR cfg_ht_bw;
	UCHAR ExtCha;
	pEntry = &pAd->MacTab.Content[Wcid];
	wdev = pEntry->wdev;

	if (!wdev || !ie_list)
		return FALSE;

	cfg_ht_bw = wlan_config_get_ht_bw(wdev);

	if (WMODE_CAP_N(wdev->PhyMode) && ie_list->AddHtInfoLen != 0 && wdev->channel < 14) {
		op_ht_bw = wlan_operate_get_ht_bw(wdev);
		ExtCha = wlan_operate_get_ext_cha(wdev);

		/* BW 40 -> 20 */
		if (op_ht_bw == HT_BW_40) {
			/* Check if root-ap change BW to 20 */
			if ((ie_list->AddHtInfo.AddHtInfo.ExtChanOffset == EXTCHA_NONE &&
				 ie_list->AddHtInfo.AddHtInfo.RecomWidth == 0)
				|| (ie_list->NewExtChannelOffset == 0x0)) {
				bAdjust = TRUE;
				Set_Diff_Bw(pAd, Wcid, BW_20, EXTCHA_NONE);
				MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("FallBack APClient BW to 20MHz\n"));
			}

			/* BW 20 -> 40 */
		} else if (op_ht_bw == HT_BW_20 && cfg_ht_bw != HT_BW_20) {
			/* Check if root-ap change BW to 40 */
			if (ie_list->AddHtInfo.AddHtInfo.ExtChanOffset != EXTCHA_NONE &&
				ie_list->AddHtInfo.AddHtInfo.RecomWidth == 1 &&
				ie_list->HtCapabilityLen > 0 &&
				ie_list->HtCapability.HtCapInfo.ChannelWidth == 1) {
				/* if extension channel is same with root ap else keep 20MHz */
				if (ExtCha == EXTCHA_NONE || ie_list->AddHtInfo.AddHtInfo.ExtChanOffset == ExtCha) {
					/* UCHAR RFChannel; */
					bAdjust = TRUE;
					Set_Diff_Bw(pAd, Wcid, BW_40, ie_list->AddHtInfo.AddHtInfo.ExtChanOffset);
					/*update channel for all of wdev belong this band*/
					wlan_operate_set_prim_ch(wdev, wdev->channel);
					MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("FallBack Client/APClient BW to 40MHz\n"));
				}
			}
		}

		if (bAdjust == TRUE) {
#ifdef MAC_REPEATER_SUPPORT

			if (pAd->ApCfg.bMACRepeaterEn) {
				UINT ifIndex;
				UCHAR CliIdx, update_bw, update_ext_ch;
				REPEATER_CLIENT_ENTRY *pReptEntry = NULL;
				RTMP_CHIP_CAP	 *cap = &pAd->chipCap;
				ifIndex = pEntry->func_tb_idx;
				update_bw = wlan_operate_get_ht_bw(wdev);
				update_ext_ch = wlan_operate_get_ext_cha(wdev);

				for (CliIdx = 0; CliIdx < GET_MAX_REPEATER_ENTRY_NUM(cap); CliIdx++) {
					pReptEntry = &pAd->ApCfg.pRepeaterCliPool[CliIdx];

					if ((pReptEntry->CliEnable) && (pReptEntry->CliValid) &&
						(pReptEntry->MatchApCliIdx == ifIndex)) {
						pEntry = &pAd->MacTab.Content[pReptEntry->MacTabWCID];

						if (pEntry)
							Set_Diff_Bw(pAd, pReptEntry->MacTabWCID, update_bw, update_ext_ch);
					}
				}

				MTWF_LOG(DBG_CAT_CLIENT, CATCLIENT_APCLI, DBG_LVL_TRACE, ("FallBack APClient BW to (%d)\n", update_bw));
			}

#endif /* MAC_REPEATER_SUPPORT */
		}
	}

#endif /* DOT11_N_SUPPORT */
	return bAdjust;
}

#ifdef WIDI_SUPPORT
#ifdef CONFIG_STA_SUPPORT
/*
	==========================================================================
	Description:
		SendProbeRequest
	==========================================================================
 */
VOID WidiSendProbeRequest(
	IN PRTMP_ADAPTER pAd,
	IN UCHAR *destMac,
	IN UCHAR ssidLen,
	IN CHAR *ssidStr,
	IN UCHAR *deviceName,
	IN UCHAR *primaryDeviceType,
	IN UCHAR *vendExt,
	IN USHORT vendExtLen,
	IN UCHAR channel)
{
	HEADER_802_11   Hdr80211;
	PUCHAR          pOutBuffer = NULL;
	NDIS_STATUS     NStatus;
	ULONG           FrameLen = 0;
	UCHAR           SsidLen = 0, ScanType = pAd->MlmeAux.ScanType;
	UINT			ScanTimeIn5gChannel = SHORT_CHANNEL_TIME;
	struct wifi_dev *wdev = &pAd->StaCfg[0].wdev;
	pAd->StaCfg[0].bSendingProbe = 1;
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		if (MONITOR_ON(pAd))
			return;
	}
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		/* BBP and RF are not accessible in PS mode, we has to wake them up first */
		if (pAd->StaCfg[0].PwrMgmt.bDoze)
			AsicWakeup(pAd, TRUE, &pAd->StaCfg[0]);

		/* leave PSM during scanning. otherwise we may lost ProbeRsp & BEACON */
		if (pAd->StaCfg[0].PwrMgmt.Psm == PWR_SAVE)
			RTMP_SET_PSM_BIT(pAd, &pAd->StaCfg[0], PWR_ACTIVE);
	}
	wdev->channel = channel;
	wlan_operate_set_prim_ch(wdev, channel);
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		if (pAd->MlmeAux.Channel > 14) {
			if ((pAd->CommonCfg.bIEEE80211H == 1) &&
				RadarChannelCheck(pAd, pAd->MlmeAux.Channel)) {
				ScanType = SCAN_PASSIVE;
				ScanTimeIn5gChannel = MIN_CHANNEL_TIME;
			}
		}

#ifdef CARRIER_DETECTION_SUPPORT /* Roger sync Carrier */

		/* carrier detection */
		if (pAd->CommonCfg.CarrierDetect.Enable == TRUE) {
			ScanType = SCAN_PASSIVE;
			ScanTimeIn5gChannel = MIN_CHANNEL_TIME;
		}

#endif /* CARRIER_DETECTION_SUPPORT */
	}

	/* Global country domain(ch1-11:active scan, ch12-14 passive scan) */
	if (((pAd->MlmeAux.Channel <= 14) &&
		 (pAd->MlmeAux.Channel >= 12) &&
		 ((pAd->CommonCfg.CountryRegion & 0x7f) == REGION_31_BG_BAND)) ||
		(CHAN_PropertyCheck(pAd, pAd->MlmeAux.Channel, CHANNEL_PASSIVE_SCAN) == TRUE))
		ScanType = SCAN_PASSIVE;

	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);  /* Get an unused nonpaged memory */

	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_LOG(DBG_CAT_PROTO, CATPROTO_SCAN, DBG_LVL_ERROR, ("%s():allocate memory fail\n", __func__));
		pAd->StaCfg[0].bSendingProbe = 0;
		return;
	}

	MgtMacHeaderInit(pAd, &Hdr80211,
					 SUBTYPE_PROBE_REQ, 0,
					 destMac,
					 pAd->CurrentAddress,
					 destMac);
	MakeOutgoingFrame(pOutBuffer,               &FrameLen,
					  sizeof(HEADER_802_11),    &Hdr80211,
					  1,                        &SsidIe,
					  1,                        &SsidLen,
					  ssidLen,			        ssidStr,
					  1,                        &SupRateIe,
					  1,                        &pAd->CommonCfg.SupRateLen,
					  pAd->CommonCfg.SupRateLen,  pAd->CommonCfg.SupRate,
					  END_OF_ARGS);

	if (pAd->CommonCfg.ExtRateLen) {
		ULONG Tmp;
		MakeOutgoingFrame(pOutBuffer + FrameLen,            &Tmp,
						  1,                                &ExtRateIe,
						  1,                                &pAd->CommonCfg.ExtRateLen,
						  pAd->CommonCfg.ExtRateLen,          pAd->CommonCfg.ExtRate,
						  END_OF_ARGS);
		FrameLen += Tmp;
	}

#ifdef WSC_STA_SUPPORT

	if (pAd->OpMode == OPMODE_STA) {
		/* Append WSC information in probe request if WSC state is running */
		if ((pAd->StaCfg[0].WscControl.WscEnProbeReqIE) &&
			(pAd->StaCfg[0].WscControl.WscConfMode != WSC_DISABLE))
			/* && (pAd->StaCfg[0].WscControl.bWscTrigger == TRUE)) */
		{
			UCHAR		*pWscBuf = NULL, WscIeLen = 0;
			ULONG		WscTmpLen = 0;

			if (os_alloc_mem(pAd, (UCHAR **)&pWscBuf, 512) == NDIS_STATUS_SUCCESS) {
				NdisZeroMemory(pWscBuf, 512);
				WscMakeProbeReqIEWithVendorExt(pAd, deviceName, primaryDeviceType,
											   vendExt, vendExtLen, pWscBuf, &WscIeLen);
				/* MTWF_LOG(DBG_CAT_PROTO, CATPROTO_SCAN, DBG_LVL_ERROR, ("Created WPS IE for Probe Request; Len = %d\n", WscIeLen)); */
				MakeOutgoingFrame(pOutBuffer + FrameLen,              &WscTmpLen,
								  WscIeLen,                             pWscBuf,
								  END_OF_ARGS);
				FrameLen += WscTmpLen;
				os_free_mem(pWscBuf);
			} else
				MTWF_LOG(DBG_CAT_PROTO, CATPROTO_SCAN, DBG_LVL_WARN, ("%s:: WscBuf Allocate failed!\n", __func__));
		}
	}

#endif /* WSC_STA_SUPPORT */
	/* MTWF_LOG(DBG_CAT_PROTO, CATPROTO_SCAN, DBG_LVL_ERROR, ("Really Sending out Probe Request\n")); */
	MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
	MlmeFreeMemory(pOutBuffer);
#if 0 /* fix toggle scan */
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd)
	pAd->Mlme.SyncMachine.CurrState = SCAN_LISTEN;
#endif
	pAd->StaCfg[0].bSendingProbe = 0;
}
#endif /* CONFIG_STA_SUPPORT */
#endif /* WIDI_SUPPORT */


#ifdef CONFIG_AP_SUPPORT
#ifdef DOT11_N_SUPPORT
extern int DetectOverlappingPeriodicRound;

VOID Handle_BSS_Width_Trigger_Events(RTMP_ADAPTER *pAd, UCHAR Channel)
{
	ULONG Now32;
	UCHAR i;
#ifdef DOT11N_DRAFT3

	if (pAd->CommonCfg.bBssCoexEnable == FALSE)
		return;

#endif /* DOT11N_DRAFT3 */

	if ((Channel <= 14)) {
		for (i = 0; i < WDEV_NUM_MAX; i++) {
			struct wifi_dev *wdev;
			UCHAR ht_bw;
			wdev = pAd->wdev_list[i];

			if (!wdev || (wdev->channel != Channel) || (wdev->wdev_type != WDEV_TYPE_AP))
				continue;

			ht_bw = wlan_operate_get_ht_bw(wdev);

			if (ht_bw < HT_BW_40)
				continue;

			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Rcv BSS Width Trigger Event: 40Mhz --> 20Mhz\n"));
			NdisGetSystemUpTime(&Now32);
			pAd->CommonCfg.LastRcvBSSWidthTriggerEventsTime = Now32;
			pAd->CommonCfg.bRcvBSSWidthTriggerEvents = TRUE;
			wlan_operate_set_ht_bw(wdev, HT_BW_20, EXTCHA_NONE);
#if (defined(WH_EZ_SETUP) && defined(EZ_NETWORK_MERGE_SUPPORT))

			if (wdev->enable_easy_setup && (wdev->wdev_type == WDEV_TYPE_AP)) {
				EZ_DEBUG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("\nHandle_BSS_Width_Trigger_Events: do fallback ****\n"));
				ez_set_ap_fallback_context(wdev, TRUE, wdev->channel);
			}

#endif /* WH_EZ_SETUP */
		}

		DetectOverlappingPeriodicRound = 31;
	}
}
#endif /* DOT11_N_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */

#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
VOID BuildEffectedChannelList(
	IN PRTMP_ADAPTER pAd,
	IN struct wifi_dev *wdev
)
{
	UCHAR		EChannel[11];
	UCHAR		i, j, k;
	UCHAR		UpperChannel = 0, LowerChannel = 0;
	UCHAR cen_ch_1 = wlan_operate_get_cen_ch_1(wdev);
#ifdef CONFIG_STA_SUPPORT
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

#endif /* CONFIG_STA_SUPPORT */
	RTMPZeroMemory(EChannel, 11);
	/* 802.11n D4 11.14.3.3: If no secondary channel has been selected, all channels in the frequency band shall be scanned. */
#if 0

	if (pEntry->HTPhyMode.field.BW == BW_20)
#endif
	{
		for (k = 0; k < pAd->ChannelListNum; k++) {
			if (pAd->ChannelList[k].Channel <= 14)
				pAd->ChannelList[k].bEffectedChannel = TRUE;
		}

		return;
	}

	i = 0;

	/* Find upper and lower channel according to 40MHz current operation. */
	if (cen_ch_1 < wdev->channel) {
		UpperChannel = wdev->channel;
		LowerChannel = cen_ch_1 - 2;
	} else if (cen_ch_1 > wdev->channel) {
		UpperChannel = cen_ch_1 + 2;
		LowerChannel = wdev->channel;
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("LinkUP 20MHz . No Effected Channel\n"));
		/* Now operating in 20MHz, doesn't find 40MHz effected channels */
		return;
	}

	DeleteEffectedChannelList(pAd);
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("BuildEffectedChannelList!LowerChannel ~ UpperChannel; %d ~ %d\n", LowerChannel, UpperChannel));

	/* Find all channels that are below lower channel.. */
	if (LowerChannel > 1) {
		EChannel[0] = LowerChannel - 1;
		i = 1;

		if (LowerChannel > 2) {
			EChannel[1] = LowerChannel - 2;
			i = 2;

			if (LowerChannel > 3) {
				EChannel[2] = LowerChannel - 3;
				i = 3;
			}
		}
	}

	/* Find all channels that are between  lower channel and upper channel. */
	for (k = LowerChannel; k <= UpperChannel; k++) {
		EChannel[i] = k;
		i++;
	}

	/* Find all channels that are above upper channel.. */
	if (UpperChannel < 14) {
		EChannel[i] = UpperChannel + 1;
		i++;

		if (UpperChannel < 13) {
			EChannel[i] = UpperChannel + 2;
			i++;

			if (UpperChannel < 12) {
				EChannel[i] = UpperChannel + 3;
				i++;
			}
		}
	}

	/*
	    Total i channels are effected channels.
	    Now find corresponding channel in ChannelList array.  Then set its bEffectedChannel= TRUE
	*/
	for (j = 0; j < i; j++) {
		for (k = 0; k < pAd->ChannelListNum; k++) {
			if (pAd->ChannelList[k].Channel == EChannel[j]) {
				pAd->ChannelList[k].bEffectedChannel = TRUE;
				MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, (" EffectedChannel[%d]( =%d)\n", k, EChannel[j]));
				break;
			}
		}
	}
}


VOID DeleteEffectedChannelList(
	IN PRTMP_ADAPTER pAd)
{
	UCHAR		i;

	/*Clear all bEffectedChannel in ChannelList array. */
	for (i = 0; i < pAd->ChannelListNum; i++)
		pAd->ChannelList[i].bEffectedChannel = FALSE;
}
#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */

UCHAR get_channel_bw_cap(struct _RTMP_ADAPTER *ad, UCHAR channel)
{
	BOOLEAN find = FALSE;
	UCHAR i;
	UCHAR cap = BW_20;
	UINT flag;

	for (i = 0; (i < ad->ChannelListNum) && (i < MAX_NUM_OF_CHANNELS); i++) {
		if (channel == ad->ChannelList[i].Channel) {
			find = TRUE;
			flag = ad->ChannelList[i].Flags;
			break;
		}
	}

	if (find) {
		if (flag & CHANNEL_160M_CAP)
			cap = BW_160;
		else if (flag & CHANNEL_80M_CAP)
			cap = BW_80;
		else if (flag & CHANNEL_40M_CAP)
			cap = BW_40;
		else
			cap = BW_20;
	}

	return cap;
}
