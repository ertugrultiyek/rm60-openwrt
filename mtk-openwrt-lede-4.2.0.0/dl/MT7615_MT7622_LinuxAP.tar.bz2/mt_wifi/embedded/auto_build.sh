if [ -d wifi_driver ]; then
    mkdir -p mt_wifi_ap
    mkdir -p mt_wifi_sta
    cp -a  wifi_driver/os/linux/Kconfig.mt_wifi_ap ./mt_wifi_ap/Kconfig
    cp -a  wifi_driver/os/linux/Makefile.mt_wifi_ap ./mt_wifi_ap/Makefile
    cp -a wifi_driver/os/linux/Kconfig.mt_wifi wifi_driver/embedded/Kconfig
    mv wifi_driver mt_wifi
elif [ -d rlt_wifi ]; then
    mkdir -p mt_wifi_ap
    mkdir -p mt_wifi_sta
    cp -a  rlt_wifi/os/linux/Kconfig.mt_wifi_ap ./mt_wifi_ap/Kconfig
    cp -a  rlt_wifi/os/linux/Makefile.mt_wifi_ap ./mt_wifi_ap/Makefile
    cp -a rlt_wifi/os/linux/Kconfig.mt_wifi rlt_wifi/embedded/Kconfig
    mv rlt_wifi mt_wifi
else
    exit 1
fi
