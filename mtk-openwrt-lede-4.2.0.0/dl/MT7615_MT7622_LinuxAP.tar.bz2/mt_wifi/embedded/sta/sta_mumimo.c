/*******************************************************************************
 * Copyright (c) 2014 MediaTek Inc.
 *
 *  All rights reserved. Copying, compilation, modification, distribution
 *  or any other use whatsoever of this material is strictly prohibited
 *  except in accordance with a Software License Agreement with
 *  MediaTek Inc.
 * ******************************************************************************
 */

/******************************************************************************
 * LEGAL DISCLAIMER
 *
 * BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND
 * AGREES THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK
 * SOFTWARE") RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE
 * PROVIDED TO BUYER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY
 * DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT
 * LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE
 * ANY WARRANTY WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY
 * WHICH MAY BE USED BY, INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK
 * SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY
 * WARRANTY CLAIM RELATING THERetO. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE
 * FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION OR TO
 * CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 * BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
 * LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL
 * BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT
 * ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY
 * BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 * WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT
 * OF LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING
 * THEREOF AND RELATED THERetO SHALL BE SETTLED BY ARBITRATION IN SAN
 * FRANCISCO, CA, UNDER THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE
 * (ICC).
 * ******************************************************************************
 */

#include "rt_config.h"

#if 0
#ifdef CFG_SUPPORT_MU_MIMO

enum {
	/* debug commands */
	MU_SET_STA_PARAM = 50,
	MU_GET_STA_PARAM,
	/* HQA STA commands */
	MU_HQA_SET_STA_PARAM = 60,
	MU_HQA_GET_STA_PARAM,
};

enum {
	MU_EVENT_MU_STA_PARAM = 50,
	MU_EVENT_HQA_GET_MU_STA_PARAM = 60,
};

typedef struct _MU_STRUCT_MU_STA_PARAM {
	UINT32 gid[2];
	UINT32 up[4];
} MU_STRUCT_MU_STA_PARAM, *P_MU_STRUCT_MU_STA_PARAM;

typedef struct _MU_STRUCT_MU_GET_STA_PARAM {
	long gid[2];
	long up[4];
} MU_STRUCT_MU_GET_STA_PARAM, *P_MU_STRUCT_MU_GET_STA_PARAM;


typedef struct _CMD_MU_SET_STA_PARAM {
	long gid[2];
	long up[4];
} CMD_MU_SET_STA_PARAM, *P_CMD_MU_SET_STA_PARAM;

typedef struct _EVENT_MU_GET_STA_PARAM {
	long gid[2];
	long up[4];
} EVENT_MU_GET_STA_PARAM, *P_EVENT_MU_GET_STA_PARAM;

typedef struct _EVENT_HQA_GET_MU_STA_PARAM {
	UINT_32 u4EventId;
	P_MU_STRUCT_MU_STA_PARAM pOutput;
	MU_STRUCT_MU_STA_PARAM param;
} EVENT_HQA_GET_MU_STA_PARAM, *P_EVENT_HQA_GET_MU_STA_PARAM;

typedef struct _CMD_HQA_SET_MU_STA_PARAM {
	MU_STRUCT_MU_STA_PARAM param;
} CMD_HQA_SET_MU_STA_PARAM, *P_CMD_HQA_SET_MU_STA_PARAM;


static VOID eventDispatcher(struct cmd_msg *msg, char *rsp_payload,
							UINT16 rsp_payload_len);

INT SetMuStaParamProc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	INT32 Ret = TRUE;
	/* prepare command message */
	struct cmd_msg *msg = NULL;
	PCHAR pLowGidUserMemberStatus = NULL;
	PCHAR pHighGidUserMemberStatus = NULL;
	PCHAR pLowGidUserPosition0 = NULL;
	PCHAR pLowGidUserPosition1 = NULL;
	PCHAR pHighGidUserPosition0 = NULL;
	PCHAR pHighGidUserPosition1 = NULL;
	PUINT8 pch = NULL;
	CMD_MU_SET_STA_PARAM param = {{0}, {0} };
	UINT32 cmd = 0;

	pch = strsep(&arg, "_");

	if (pch != NULL)
		pLowGidUserMemberStatus = pch;
	else {
		Ret = 0;
		goto error;
	}

	pch = strsep(&arg, "_");

	if (pch != NULL)
		pHighGidUserMemberStatus = pch;
	else {
		Ret = 0;
		goto error;
	}

	pch = strsep(&arg, "_");

	if (pch != NULL)
		pLowGidUserPosition0 = pch;
	else {
		Ret = 0;
		goto error;
	}

	pch = strsep(&arg, "_");

	if (pch != NULL)
		pLowGidUserPosition1 = pch;
	else {
		Ret = 0;
		goto error;
	}

	pch = strsep(&arg, "_");

	if (pch != NULL)
		pHighGidUserPosition0 = pch;
	else {
		Ret = 0;
		goto error;
	}

	pch = strsep(&arg, "");

	if (pch != NULL)
		pHighGidUserPosition1 = pch;
	else {
		Ret = 0;
		goto error;
	}

	MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("#################### %s\n", __func__));
	/* To we need change edian? */
	param.gid[0] = os_str_tol(pLowGidUserMemberStatus, 0, 16);
	param.gid[1] = os_str_tol(pHighGidUserMemberStatus, 0, 16);
	param.gid[0] = os_str_tol(pLowGidUserPosition0, 0, 16);
	param.gid[1] = os_str_tol(pLowGidUserPosition1, 0, 16);
	param.gid[2] = os_str_tol(pHighGidUserPosition0, 0, 16);
	param.gid[3] = os_str_tol(pHighGidUserPosition1, 0, 16);
	param.gid[0] = cpu2le32(param.gid[0]);
	param.gid[1] = cpu2le32(param.gid[1]);
	param.up[0] = cpu2le32(param.up[0]);
	param.up[1] = cpu2le32(param.up[1]);
	param.up[2] = cpu2le32(param.up[2]);
	param.up[3] = cpu2le32(param.up[3]);
	/* printk("#################### %s\n", __FUNCTION__); */
	/* printk("Values: %x %x %x %x %x %x\n", param.gid[0], param.gid[1], param.up[0], */
	/* param.up[1], param.up[2], param.up[3]); */
	cmd = MU_SET_STA_PARAM;
	/* Allocate memory for msg */
	msg = AndesAllocCmdMsg(pAd, sizeof(cmd) + sizeof(CMD_MU_SET_STA_PARAM));

	if (!msg) {
		Ret = 0;
		goto error;
	}

	AndesInitCmdMsg(msg, HOST2N9, EXT_CID, CMD_SET, EXT_CMD_ID_MU_MIMO,
					FALSE, 0, TRUE, FALSE, 0, NULL, NULL);
	AndesAppendCmdMsg(msg, (char *) &cmd, sizeof(cmd));
	AndesAppendCmdMsg(msg, (char *) &param, sizeof(CMD_MU_SET_STA_PARAM));
	AndesSendCmdMsg(pAd, msg);
	MTWF_LOG(DBG_CAT_CFG, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("msg is sent\n"));
error:
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s:(Ret = %d_\n", __func__, Ret));
	return Ret;
}

INT ShowMuStaParamProc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	INT32 Ret = TRUE;
	/* prepare command message */
	struct cmd_msg *msg = NULL;
	EVENT_MU_GET_STA_PARAM result = {{0}, {0} };
	UINT32 cmd = 0;
	/* Allocate memory for msg */
	msg = AndesAllocCmdMsg(pAd, sizeof(cmd) + sizeof(result));

	if (!msg) {
		Ret = FALSE;
		goto error;
	}

	cmd = MU_GET_STA_PARAM;
	AndesInitCmdMsg(msg, HOST2N9, EXT_CID, CMD_QUERY, EXT_CMD_ID_MU_MIMO,
					TRUE, 0, FALSE, TRUE, sizeof(result), (char *) &result, eventDispatcher);
	AndesAppendCmdMsg(msg, (char *) &cmd, sizeof(cmd));
	AndesAppendCmdMsg(msg, (char *) &result, sizeof(result));
	AndesSendCmdMsg(pAd, msg);
error:
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s:(Ret = %d_\n", __func__, Ret));
	return Ret;
}

static VOID ShowMuStaParamCallback(char *rsp_payload,
								   UINT16 rsp_payload_len)
{
	/* P_EVENT_MU_GET_STA_PARAM pGentry = (P_EVENT_MU_GET_STA_PARAM) rsp_payload; */
	/* printk("#################### %s\n", __FUNCTION__); */
	/* printk("GID User Membership Status [0] = %x\n", pGentry->gid[0]); */
	/* printk("GID User Membership Status [1] = %x\n", pGentry->gid[1]); */
	/* printk("GID User Position [0] = %x\n", pGentry->up[0]); */
	/* printk("GID User Position [1] = %x\n", pGentry->up[1]); */
	/* printk("GID User Position [2] = %x\n", pGentry->up[2]); */
	/* printk("GID User Position [3] = %x\n", pGentry->up[3]); */
	/* printk("######## END ##########"); */
}

static VOID hqa_wifi_test_mu_get_sta_gid_and_up_callback(char *rsp_payload,
		UINT16 rsp_payload_len)
{
	P_EVENT_HQA_GET_MU_STA_PARAM pEntry = (P_EVENT_HQA_GET_MU_STA_PARAM) rsp_payload;
	P_MU_STRUCT_MU_STA_PARAM pOutput = pEntry->pOutput;

	NdisCopyMemory(pOutput->gid, pEntry->param.gid, sizeof(pEntry->param.gid));
	NdisCopyMemory(pOutput->up, pEntry->param.up, sizeof(pEntry->param.up));
}

bool
hqa_wifi_test_mu_get_sta_gid_and_up(
	PRTMP_ADAPTER pAd,
	P_MU_STRUCT_MU_GET_STA_PARAM pOutput
)
{
	INT32 Ret = TRUE;
	/* prepare command message */
	struct cmd_msg *msg = NULL;
	EVENT_MU_GET_STA_PARAM result = {{0}, {0} };
	UINT32 cmd = 0;
	/* Allocate memory for msg */
	msg = AndesAllocCmdMsg(pAd, sizeof(cmd) + sizeof(result));

	if (!msg) {
		Ret = FALSE;
		goto error;
	}

	cmd = MU_HQA_GET_STA_PARAM;
	AndesInitCmdMsg(msg, HOST2N9, EXT_CID, CMD_QUERY, EXT_CMD_ID_MU_MIMO,
					TRUE, 0, FALSE, TRUE, sizeof(result), (char *) &result, eventDispatcher);
	AndesAppendCmdMsg(msg, (char *) &cmd, sizeof(cmd));
	AndesAppendCmdMsg(msg, (char *) &result, sizeof(result));
	AndesSendCmdMsg(pAd, msg);
error:
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s:(Ret = %d_\n", __func__, Ret));
	return Ret;
}

bool
hqa_wifi_test_mu_set_sta_gid_and_up(
	PRTMP_ADAPTER pAd,
	P_MU_STRUCT_MU_STA_PARAM ptr
)
{
	INT Ret = TRUE;
	struct cmd_msg *msg = NULL;
	UINT32 cmd = 0;
	CMD_HQA_SET_MU_STA_PARAM param;

	msg = AndesAllocCmdMsg(pAd, sizeof(cmd) + sizeof(param));

	if (!msg) {
		Ret = FALSE;
		goto error;
	}

	NdisCopyMemory(&param.param, ptr, sizeof(MU_STRUCT_MU_STA_PARAM));
	cmd = MU_HQA_SET_STA_PARAM;
	AndesInitCmdMsg(msg, HOST2N9, EXT_CID, CMD_SET, EXT_CMD_ID_MU_MIMO,
					FALSE, 0, TRUE, FALSE, 0, NULL, NULL);
	AndesAppendCmdMsg(msg, (char *) &cmd, sizeof(cmd));
	AndesAppendCmdMsg(msg, (char *) &param, sizeof(param));
	AndesSendCmdMsg(pAd, msg);
error:
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s:(Ret = %d_\n", __func__, Ret));
	return Ret;
}

static VOID eventDispatcher(struct cmd_msg *msg, char *rsp_payload,
							UINT16 rsp_payload_len)
{
	UINT32 u4EventId = (UINT32) rsp_payload[0];
	char *pData = (rsp_payload + sizeof(UINT32));
	UINT16 len = (rsp_payload_len - sizeof(UINT32));

	switch (u4EventId) {
	case MU_EVENT_MU_STA_PARAM:
		ShowMuStaParamCallback(pData, len);
		break;

	case MU_EVENT_HQA_GET_MU_STA_PARAM:
		hqa_wifi_test_mu_get_sta_gid_and_up_callback(pData, len);
		break;

	default:
		break;
	}
}
#endif
#endif
