/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2006, Ralink Technology, Inc.
 *
 * All rights reserved.	Ralink's source	code is	an unpublished work	and	the
 * use of a	copyright notice does not imply	otherwise. This	source code
 * contains	confidential trade secret material of Ralink Tech. Any attemp
 * or participation	in deciphering,	decoding, reverse engineering or in	any
 * way altering	the	source code	is stricitly prohibited, unless	the	prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:
	auth.c

	Abstract:

	Revision History:
	Who			When			What
	--------	----------		-------------------------------------------
*/
#include "rt_config.h"


/*
 *    ==========================================================================
 *    Description:
 *	function to be executed at timer thread when auth timer expires
 *    ==========================================================================
 */
VOID AuthTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	PTIMER_FUNC_CONTEXT pContext = (PTIMER_FUNC_CONTEXT)FunctionContext;
	RTMP_ADAPTER *pAd = pContext->pAd;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, pContext->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s():AuthTimeout\n", __func__));

	/* Do nothing if the driver is starting halt state. */
	/* This might happen when timer already been fired before cancel timer with mlmehalt */
	if (RTMP_TEST_FLAG(pAd, fRTMP_ADAPTER_HALT_IN_PROGRESS | fRTMP_ADAPTER_NIC_NOT_EXIST))
		return;

	/* send a de-auth to reset AP's state machine (Patch AP-Dir635) */
	if (pStaCfg->AuthMachine.CurrState == AUTH_WAIT_SEQ2)
		Cls2errAction(&pStaCfg->wdev, pStaCfg->MlmeAux.Bssid);

	MlmeEnqueueWithWdev(pAd, AUTH_STATE_MACHINE, MT2_AUTH_TIMEOUT, 0, NULL, 0, pContext->wdev);
	RTMP_MLME_HANDLER(pAd);
}


/*
 *    ==========================================================================
 *    Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *    ==========================================================================
 */
VOID MlmeAuthReqAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	if (AUTH_ReqSend(pAd, Elem, &pStaCfg->MlmeAux.AuthTimer, "AUTH", 1, NULL, 0))
		pStaCfg->AuthMachine.CurrState = AUTH_WAIT_SEQ2;
	else {
		USHORT Status;
		pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
		Status = MLME_INVALID_FORMAT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_AUTH_CONF, 2, &Status, 0, Elem->wdev);
	}
}

#ifdef DOT11_SAE_SUPPORT
/*
    ==========================================================================
    Description:

	IRQL = DISPATCH_LEVEL

    ==========================================================================
 */
VOID MlmeSaeAuthReqAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	STA_ADMIN_CONFIG *pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	/* SAE_MLME_AUTH_REQ_STRUCT *AuthReq = (SAE_MLME_AUTH_REQ_STRUCT *)Elem->Msg; */
	MLME_AUTH_REQ_STRUCT *AuthReq = (MLME_AUTH_REQ_STRUCT *)Elem->Msg;
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("==>%s()\n", __func__));
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	COPY_MAC_ADDR(pStaCfg->MlmeAux.Bssid, AuthReq->Addr);

	if (sae_auth_init(pAd, &pAd->SaeCfg, pStaCfg->wdev.if_addr, AuthReq->Addr,
					  pStaCfg->MlmeAux.Bssid, Elem->wdev->SecConfig.PSK, SAE_DEFAULT_GROUP))
		pStaCfg->AuthMachine.CurrState = AUTH_WAIT_SAE;
	else {
		USHORT Status;
		pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
		Status = MLME_INVALID_FORMAT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_AUTH_CONF, 2, &Status, 0, Elem->wdev);
	}
}


/*
    ==========================================================================
    Description:

	IRQL = DISPATCH_LEVEL

    ==========================================================================
 */
VOID MlmeSaeAuthRspAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	STA_ADMIN_CONFIG *pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	FRAME_802_11 *Fr = (FRAME_802_11 *)Elem->Msg;
	USHORT seq;
	USHORT status;
	UCHAR *pmk;
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	NdisMoveMemory(&seq,    &Fr->Octet[2], 2);
	NdisMoveMemory(&status, &Fr->Octet[4], 2);
	pmk = sae_handle_auth(pAd, &pAd->SaeCfg, Elem->Msg, Elem->MsgLen,
						  Elem->wdev->SecConfig.PSK,
						  seq, status);

	if (pmk != NULL) {
		USHORT Status;
		MAC_TABLE_ENTRY *pEntry = (MAC_TABLE_ENTRY *)pStaCfg->pAssociatedAPEntry;
		DebugLevel = DBG_LVL_TRACE;
		hex_dump("pmk:", (char *)pmk, LEN_PMK);
		DebugLevel = DBG_LVL_ERROR;

		if (pEntry) {
			NdisMoveMemory(pEntry->SecConfig.PMK, pmk, LEN_PMK);
			Status = MLME_SUCCESS;
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%s(): Security AKM = 0x%x, PairwiseCipher = 0x%x, GroupCipher = 0x%x\n",
					 __func__, pEntry->SecConfig.AKMMap, pEntry->SecConfig.PairwiseCipher, pEntry->SecConfig.GroupCipher));
		} else
			Status = MLME_UNSPECIFY_FAIL;

		/* pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE; */
		pStaCfg->CntlMachine.CurrState = CNTL_WAIT_AUTH;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_AUTH_CONF, 2, &Status, 0, Elem->wdev);
	}
}
#endif /* DOT11_SAE_SUPPORT */


/*
 *    ==========================================================================
 *    Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *    ==========================================================================
 */
VOID PeerAuthRspAtSeq2Action(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	UCHAR Addr2[MAC_ADDR_LEN];
	USHORT Seq, Status, RemoteStatus, Alg;
	UCHAR iv_hdr[4];
	UCHAR *ChlgText = NULL;
	UCHAR *CyperChlgText = NULL;
	ULONG c_len = 0;
	HEADER_802_11 AuthHdr;
	BOOLEAN TimerCancelled;
	PUCHAR pOutBuffer = NULL;
	NDIS_STATUS NStatus;
	ULONG FrameLen = 0;
	USHORT Status2;
	UCHAR ChallengeIe = IE_CHALLENGE_TEXT;
	UCHAR len_challengeText = CIPHER_TEXT_LEN;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	os_alloc_mem(NULL, (UCHAR **)&ChlgText, CIPHER_TEXT_LEN);

	if (ChlgText == NULL) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: alloc mem fail\n", __func__));
		return;
	}

	os_alloc_mem(NULL, (UCHAR **)&CyperChlgText, CIPHER_TEXT_LEN + 8 + 8);

	if (CyperChlgText == NULL) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s: CyperChlgText Allocate memory fail!!!\n",
				  __func__));
		os_free_mem(ChlgText);
		return;
	}

	if (PeerAuthSanity(pAd, Elem->Msg, Elem->MsgLen, Addr2, &Alg, &Seq, &Status, (PCHAR)ChlgText)) {
		if (MAC_ADDR_EQUAL(pStaCfg->MlmeAux.Bssid, Addr2) && Seq == 2) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("AUTH - Receive AUTH_RSP seq#2 to me (Alg=%d, Status=%d)\n",
					  Alg, Status));
			RTMPCancelTimer(&pStaCfg->MlmeAux.AuthTimer, &TimerCancelled);

			if (Status == MLME_SUCCESS) {
				/* Authentication Mode "LEAP" has allow for CCX 1.X */
				if (pStaCfg->MlmeAux.Alg == Ndis802_11AuthModeOpen) {
					pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
					MlmeEnqueueWithWdev(pAd,
										MLME_CNTL_STATE_MACHINE,
										MT2_AUTH_CONF, 2, &Status,
										0, Elem->wdev);
				} else {
					struct wifi_dev *wdev = Elem->wdev;
					PSEC_KEY_INFO  pKey;
					UINT default_key = wdev->SecConfig.PairwiseKeyId;
					pKey = &wdev->SecConfig.WepKey[default_key];
					/* 2. shared key, need to be challenged */
					Seq++;
					RemoteStatus = MLME_SUCCESS;
					/* Get an unused nonpaged memory */
					NStatus =
						MlmeAllocateMemory(pAd,
										   &pOutBuffer);

					if (NStatus != NDIS_STATUS_SUCCESS) {
						MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
								 ("AUTH - PeerAuthRspAtSeq2Action() allocate memory fail\n"));
						pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
						Status2 = MLME_FAIL_NO_RESOURCE;
						MlmeEnqueueWithWdev(pAd,
											MLME_CNTL_STATE_MACHINE,
											MT2_AUTH_CONF, 2,
											&Status2, 0, wdev);
						goto LabelOK;
					}

					MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
							 ("AUTH - Send AUTH request seq#3...\n"));
					MgtMacHeaderInit(pAd, &AuthHdr,
									 SUBTYPE_AUTH, 0, Addr2,
									 pStaCfg->wdev.if_addr,
									 pStaCfg->MlmeAux.Bssid);
					AuthHdr.FC.Wep = 1;
					/* TSC increment */
					INC_TX_TSC(pKey->TxTsc, LEN_WEP_TSC);
					/* Construct the 4-bytes WEP IV header */
					RTMPConstructWEPIVHdr(default_key, pKey->TxTsc, iv_hdr);
					Alg = cpu2le16(*(USHORT *)&Alg);
					Seq = cpu2le16(*(USHORT *)&Seq);
					RemoteStatus = cpu2le16(*(USHORT *) &RemoteStatus);
					/* Construct message text */
					MakeOutgoingFrame(CyperChlgText, &c_len,
									  2, &Alg,
									  2, &Seq,
									  2, &RemoteStatus,
									  1, &ChallengeIe,
									  1, &len_challengeText,
									  len_challengeText,
									  ChlgText,
									  END_OF_ARGS);

					if (RTMPSoftEncryptWEP(iv_hdr,
										   pKey,
										   CyperChlgText, c_len) == FALSE) {
						MlmeFreeMemory(pOutBuffer);
						pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
						Status2 = MLME_FAIL_NO_RESOURCE;
						MlmeEnqueueWithWdev(pAd,
											MLME_CNTL_STATE_MACHINE,
											MT2_AUTH_CONF, 2,
											&Status2, 0, wdev);
						goto LabelOK;
					}

					/* Update the total length for 4-bytes ICV */
					c_len += LEN_ICV;
					MakeOutgoingFrame(pOutBuffer, &FrameLen,
									  sizeof
									  (HEADER_802_11),
									  &AuthHdr,
									  LEN_WEP_IV_HDR,
									  iv_hdr, c_len,
									  CyperChlgText,
									  END_OF_ARGS);
					MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
					MlmeFreeMemory(pOutBuffer);
					RTMPSetTimer(&pStaCfg->MlmeAux.AuthTimer, AUTH_TIMEOUT);
					pStaCfg->AuthMachine.CurrState = AUTH_WAIT_SEQ4;
				}
			} else {
				pStaCfg->AuthFailReason = Status;
				COPY_MAC_ADDR(pStaCfg->AuthFailSta, Addr2);
				pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
				MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE,
									MT2_AUTH_CONF, 2, &Status, 0, Elem->wdev);
			}
		}
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("AUTH - PeerAuthSanity() sanity check fail\n"));
	}

LabelOK:

	if (ChlgText != NULL)
		os_free_mem(ChlgText);

	if (CyperChlgText != NULL)
		os_free_mem(CyperChlgText);
}


/*
 *    ==========================================================================
 *    Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *    ==========================================================================
 */
VOID PeerAuthRspAtSeq4Action(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	UCHAR Addr2[MAC_ADDR_LEN];
	USHORT Alg, Seq, Status;
	/*    CHAR          ChlgText[CIPHER_TEXT_LEN]; */
	CHAR *ChlgText = NULL;
	BOOLEAN TimerCancelled;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	/* allocate memory */
	os_alloc_mem(NULL, (UCHAR **)&ChlgText, CIPHER_TEXT_LEN);

	if (ChlgText == NULL) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s: ChlgText Allocate memory fail!!!\n",
				  __func__));
		return;
	}

	if (PeerAuthSanity
		(pAd, Elem->Msg, Elem->MsgLen, Addr2, &Alg, &Seq, &Status,
		 ChlgText)) {
		if (MAC_ADDR_EQUAL(pStaCfg->MlmeAux.Bssid, Addr2) && Seq == 4) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("AUTH - Receive AUTH_RSP seq#4 to me\n"));
			RTMPCancelTimer(&pStaCfg->MlmeAux.AuthTimer,
							&TimerCancelled);

			if (Status != MLME_SUCCESS) {
				pStaCfg->AuthFailReason = Status;
				COPY_MAC_ADDR(pStaCfg->AuthFailSta, Addr2);
				RTMPSendWirelessEvent(pAd, IW_SHARED_WEP_FAIL,
									  NULL, BSS0, 0);
			}

			pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
			MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_AUTH_CONF,
								2, &Status, 0, Elem->wdev);
		}
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("AUTH - PeerAuthRspAtSeq4Action() sanity check fail\n"));
	}

	if (ChlgText != NULL)
		os_free_mem(ChlgText);
}

/*
 *    ==========================================================================
 *    Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *    ==========================================================================
 */
VOID MlmeDeauthReqAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	MLME_DEAUTH_REQ_STRUCT *pInfo;
	HEADER_802_11 DeauthHdr;
	PUCHAR pOutBuffer = NULL;
	NDIS_STATUS NStatus;
	ULONG FrameLen = 0;
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	pInfo = (MLME_DEAUTH_REQ_STRUCT *) Elem->Msg;
	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);	/*Get an unused nonpaged memory */

	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("AUTH - MlmeDeauthReqAction() allocate memory fail\n"));
		pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
		Status = MLME_FAIL_NO_RESOURCE;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_DEAUTH_CONF, 2,
							&Status, 0, Elem->wdev);
		return;
	}

#ifdef WAPI_SUPPORT
	WAPI_InternalCmdAction(pAd,
						   pStaCfg->wdev.SecConfig.AKMMap,
						   BSS0, pStaCfg->MlmeAux.Bssid, WAI_MLME_DISCONNECT);
#endif /* WAPI_SUPPORT */
	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("AUTH - Send DE-AUTH request (Reason=%d)...\n",
			  pInfo->Reason));
	MgtMacHeaderInit(pAd, &DeauthHdr, SUBTYPE_DEAUTH, 0, pInfo->Addr,
					 pStaCfg->wdev.if_addr,
					 pStaCfg->MlmeAux.Bssid);
	MakeOutgoingFrame(pOutBuffer, &FrameLen, sizeof(HEADER_802_11),
					  &DeauthHdr, 2, &pInfo->Reason, END_OF_ARGS);
	MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
	MlmeFreeMemory(pOutBuffer);
	pStaCfg->DeauthReason = pInfo->Reason;
	COPY_MAC_ADDR(pStaCfg->DeauthSta, pInfo->Addr);
	pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
	Status = MLME_SUCCESS;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_DEAUTH_CONF, 2, &Status,
						0, Elem->wdev);
	/* send wireless event - for deauthentication */
	RTMPSendWirelessEvent(pAd, IW_DEAUTH_EVENT_FLAG, NULL, BSS0, 0);
}


/*
 *    ==========================================================================
 *    Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *    ==========================================================================
 */
VOID AuthTimeoutAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("AUTH - AuthTimeoutAction\n"));
	pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
	Status = MLME_REJ_TIMEOUT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_AUTH_CONF, 2, &Status, 0, Elem->wdev);
}


/*
 *    ==========================================================================
 *    Description:
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *    ==========================================================================
 */
VOID InvalidStateWhenAuth(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	USHORT Status;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("AUTH - InvalidStateWhenAuth (state=%ld), reset AUTH state machine\n",
			  pStaCfg->AuthMachine.CurrState));
	pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
	Status = MLME_STATE_MACHINE_REJECT;
	MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_AUTH_CONF, 2, &Status, 0, Elem->wdev);
}


/*
 *    ==========================================================================
 *    Description:
 *	Some STA/AP
 *    Note:
 *	This action should never trigger AUTH state transition, therefore we
 *	separate it from AUTH state machine, and make it as a standalone service
 *
 *	IRQL = DISPATCH_LEVEL
 *
 *    ==========================================================================
 */
VOID Cls2errAction(struct wifi_dev *wdev, UCHAR *pAddr)
{
	HEADER_802_11 DeauthHdr;
	PUCHAR pOutBuffer = NULL;
	NDIS_STATUS NStatus;
	ULONG FrameLen = 0;
	USHORT Reason = REASON_CLS2ERR;
	RTMP_ADAPTER *pAd = (RTMP_ADAPTER *)wdev->sys_handle;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);	/*Get an unused nonpaged memory */

	if (NStatus != NDIS_STATUS_SUCCESS)
		return;

	MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("AUTH - Class 2 error, Send DEAUTH frame...\n"));
	MgtMacHeaderInit(pAd, &DeauthHdr, SUBTYPE_DEAUTH, 0, pAddr,
					 pStaCfg->wdev.if_addr,
					 pStaCfg->MlmeAux.Bssid);
	MakeOutgoingFrame(pOutBuffer, &FrameLen, sizeof(HEADER_802_11),
					  &DeauthHdr, 2, &Reason, END_OF_ARGS);
	MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
	MlmeFreeMemory(pOutBuffer);
	pStaCfg->DeauthReason = Reason;
	COPY_MAC_ADDR(pStaCfg->DeauthSta, pAddr);
}


BOOLEAN AUTH_ReqSend(
	IN PRTMP_ADAPTER pAd,
	IN PMLME_QUEUE_ELEM pElem,
	IN PRALINK_TIMER_STRUCT pAuthTimer,
	IN RTMP_STRING * pSMName,
	IN USHORT SeqNo,
	IN PUCHAR pNewElement,
	IN ULONG ElementLen)
{
	USHORT Alg, Seq, Status;
	UCHAR Addr[6];
	ULONG Timeout;
	HEADER_802_11 AuthHdr;
	BOOLEAN TimerCancelled;
	NDIS_STATUS NStatus;
	PUCHAR pOutBuffer = NULL;
	ULONG FrameLen = 0, tmp = 0;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, pElem->wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return FALSE;

	/* Block all authentication request durning WPA block period */
	if (pStaCfg->bBlockAssoc == TRUE) {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("%s - Block Auth request durning WPA block period!\n",
				  pSMName));
		pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
		Status = MLME_STATE_MACHINE_REJECT;
		MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_AUTH_CONF, 2,
							&Status, 0, pElem->wdev);
	} else if (MlmeAuthReqSanity(pAd, pElem->wdev, pElem->Msg, pElem->MsgLen, Addr, &Timeout, &Alg)) {
		/* reset timer */
		RTMPCancelTimer(pAuthTimer, &TimerCancelled);
		COPY_MAC_ADDR(pStaCfg->MlmeAux.Bssid, Addr);
		pStaCfg->MlmeAux.Alg = Alg;
		Seq = SeqNo;
		Status = MLME_SUCCESS;
		NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);	/*Get an unused nonpaged memory */

		if (NStatus != NDIS_STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
					 ("%s - MlmeAuthReqAction(Alg:%d) allocate memory failed\n",
					  pSMName, Alg));
			pStaCfg->AuthMachine.CurrState = AUTH_REQ_IDLE;
			Status = MLME_FAIL_NO_RESOURCE;
			MlmeEnqueueWithWdev(pAd, MLME_CNTL_STATE_MACHINE, MT2_AUTH_CONF,
								2, &Status, 0, pElem->wdev);
			return FALSE;
		}

		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("%s - Send AUTH request seq#1 (Alg=%d)...\n",
				  pSMName, Alg));
		MgtMacHeaderInit(pAd, &AuthHdr, SUBTYPE_AUTH, 0, Addr,
						 pStaCfg->wdev.if_addr,
						 pStaCfg->MlmeAux.Bssid);
		MakeOutgoingFrame(pOutBuffer, &FrameLen, sizeof(HEADER_802_11),
						  &AuthHdr, 2, &Alg, 2, &Seq, 2, &Status,
						  END_OF_ARGS);

		if (pNewElement && ElementLen) {
			MakeOutgoingFrame(pOutBuffer + FrameLen, &tmp,
							  ElementLen, pNewElement, END_OF_ARGS);
			FrameLen += tmp;
		}

		MiniportMMRequest(pAd, 0, pOutBuffer, FrameLen);
		MlmeFreeMemory(pOutBuffer);
		RTMPSetTimer(pAuthTimer, Timeout);
		return TRUE;
	} else {
		MTWF_LOG(DBG_CAT_CLIENT, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): %s sanity check fail\n", __func__, pSMName));
		return FALSE;
	}

	return TRUE;
}


/*
 *    ==========================================================================
 *    Description:
 *	authenticate state machine init, including state transition and timer init
 *    Parameters:
 *	Sm - pointer to the auth state machine
 *    Note:
 *	The state machine looks like this
 *
 *    AUTH_REQ_IDLE           AUTH_WAIT_SEQ2                   AUTH_WAIT_SEQ4
 *    MT2_MLME_AUTH_REQ   mlme_auth_req_action    invalid_state_when_auth          invalid_state_when_auth
 *    MT2_PEER_AUTH_EVEN  drop                    peer_auth_even_at_seq2_action    peer_auth_even_at_seq4_action
 *    MT2_AUTH_TIMEOUT    Drop                    auth_timeout_action              auth_timeout_action
 *
 *	IRQL = PASSIVE_LEVEL
 *
 *    ==========================================================================
 */
void AuthStateMachineInit(
	IN RTMP_ADAPTER *pAd,
	IN struct wifi_dev *wdev,
	IN STATE_MACHINE * Sm,
	OUT STATE_MACHINE_FUNC Trans[])
{
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	StateMachineInit(Sm, Trans, MAX_AUTH_STATE, MAX_AUTH_MSG,
					 (STATE_MACHINE_FUNC) Drop, AUTH_REQ_IDLE,
					 AUTH_MACHINE_BASE);
	/* the first column */
	StateMachineSetAction(Sm, AUTH_REQ_IDLE, MT2_MLME_AUTH_REQ,
						  (STATE_MACHINE_FUNC) MlmeAuthReqAction);
	/* the second column */
	StateMachineSetAction(Sm, AUTH_WAIT_SEQ2, MT2_MLME_AUTH_REQ,
						  (STATE_MACHINE_FUNC) InvalidStateWhenAuth);
	StateMachineSetAction(Sm, AUTH_WAIT_SEQ2, MT2_PEER_AUTH_EVEN,
						  (STATE_MACHINE_FUNC) PeerAuthRspAtSeq2Action);
	StateMachineSetAction(Sm, AUTH_WAIT_SEQ2, MT2_AUTH_TIMEOUT,
						  (STATE_MACHINE_FUNC) AuthTimeoutAction);
	/* the third column */
	StateMachineSetAction(Sm, AUTH_WAIT_SEQ4, MT2_MLME_AUTH_REQ,
						  (STATE_MACHINE_FUNC) InvalidStateWhenAuth);
	StateMachineSetAction(Sm, AUTH_WAIT_SEQ4, MT2_PEER_AUTH_EVEN,
						  (STATE_MACHINE_FUNC) PeerAuthRspAtSeq4Action);
	StateMachineSetAction(Sm, AUTH_WAIT_SEQ4, MT2_AUTH_TIMEOUT,
						  (STATE_MACHINE_FUNC) AuthTimeoutAction);
#ifdef DOT11_SAE_SUPPORT
	StateMachineSetAction(Sm, AUTH_REQ_IDLE, MT2_MLME_SAE_AUTH_REQ,
						  (STATE_MACHINE_FUNC) MlmeSaeAuthReqAction);
	StateMachineSetAction(Sm, AUTH_WAIT_SAE, MT2_MLME_SAE_AUTH_COMMIT,
						  (STATE_MACHINE_FUNC) MlmeSaeAuthRspAction);
	StateMachineSetAction(Sm, AUTH_WAIT_SAE, MT2_MLME_SAE_AUTH_CONFIRM,
						  (STATE_MACHINE_FUNC) MlmeSaeAuthRspAction);
#endif /*DOT11_SAE_SUPPORT */
	pStaCfg->MlmeAux.AuthTimerFuncContext.pAd = pAd;
	pStaCfg->MlmeAux.AuthTimerFuncContext.wdev = wdev;
	RTMPInitTimer(pAd, &pStaCfg->MlmeAux.AuthTimer,
				  GET_TIMER_FUNCTION(AuthTimeout), &pStaCfg->MlmeAux.AuthTimerFuncContext, FALSE);
}
