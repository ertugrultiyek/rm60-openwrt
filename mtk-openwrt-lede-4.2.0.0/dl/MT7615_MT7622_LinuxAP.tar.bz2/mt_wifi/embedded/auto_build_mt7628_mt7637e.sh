if [ -d wifi_driver ]; then
mkdir -p mt_wifi_ap
    mkdir -p mt_wifi_sta
    cp -a  wifi_driver/os/linux/Kconfig.mt_wifi_ap ./mt_wifi_ap/Kconfig
    cp -a  wifi_driver/os/linux/Makefile.mt_wifi_ap ./mt_wifi_ap/Makefile
    cp -a wifi_driver/os/linux/Kconfig.mt_wifi wifi_driver/embedded/Kconfig
    mv wifi_driver mt_wifi
    echo "7637e mt_wifi autobuild"
    RT28xx_DIR=./mt_wifi
    CHIPSET=mt7637e
    RT28xx_MODE=AP
    HAS_WOW_SUPPORT=n
    HAS_FPGA_MODE=n
    export RT28xx_DIR CHIPSET RT28xx_MODE HAS_WOW_SUPPORT HAS_FPGA_MODE
    make -C mt_wifi/embedded build_tools
    ./mt_wifi/embedded/tools/bin2h

elif [ -d rlt_wifi ]; then
    mkdir -p rlt_wifi_ap
    mkdir -p rlt_wifi_sta
    cp -a  rlt_wifi/os/linux/Kconfig.rlt_wif_ap.7637e ./rlt_wifi_ap/Kconfig
    cp -a  rlt_wifi/os/linux/Makefile.rlt_wifi_ap.7637e ./rlt_wifi_ap/Makefile
    cp -a rlt_wifi/os/linux/Kconfig.rlt_wifi.7637e rlt_wifi/embedded/Kconfig
    #for fake rlt_wifi for SDK's build code flow case reference
    cp -a rlt_wifi/os/linux/Kconfig.rlt_wifi.7637e rlt_wifi/Kconfig

    echo "7637e rlt_wifi autobuild"
    RT28xx_DIR=./rlt_wifi
    CHIPSET=mt7637e
    RT28xx_MODE=AP
    HAS_WOW_SUPPORT=n
    HAS_FPGA_MODE=n
    export RT28xx_DIR CHIPSET RT28xx_MODE HAS_WOW_SUPPORT HAS_FPGA_MODE
    make -C rlt_wifi/embedded build_tools
    ./rlt_wifi/embedded/tools/bin2h
else
    exit 1
fi
