/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2004, Ralink Technology, Inc.
 *
 * All rights reserved. Ralink's source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of Ralink Tech. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of Ralink Technology, Inc. is obtained.
 ***************************************************************************

	Module Name:

	Abstract:

	Revision History:
	Who		When			What
	--------	----------		----------------------------------------------
*/


#include "rt_config.h"


#ifdef DOT11_N_SUPPORT

INT ht_support_bw_by_channel_boundary(RTMP_ADAPTER *pAd, MAC_TABLE_ENTRY *pEntry, IE_LISTS *peer_ie_list)
{
	struct wifi_dev *wdev = pEntry->wdev;
	UCHAR supported_bw;
	UCHAR ext_cha;

	if (!wdev)
		return HT_BW_20;

	supported_bw = wlan_operate_get_ht_bw(wdev);
	ext_cha = wlan_operate_get_ext_cha(wdev);
	if (!peer_ie_list)
		return supported_bw;

	MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s(), Channel = %d, supported_bw = %d, extcha = %d, PeerSupChlLen = %d\n", __func__,
			 wdev->channel,
			 supported_bw,
			 ext_cha,
			 peer_ie_list->SupportedChlLen));

	/* So far, only check 2.4G band */
	if ((wdev->channel <= 14) && (peer_ie_list->SupportedChlLen >= 2)) {
		UCHAR i;
		UCHAR peer_sup_chl_min_2g = 1;
		UCHAR peer_sup_chl_max_2g = 14;

		/* Get Min/Max 2.4G supported channels */
		for (i = 0; i < peer_ie_list->SupportedChlLen; i += 2) {
			if (peer_ie_list->SupportedChl[i] <= 14) {
				peer_sup_chl_min_2g = peer_ie_list->SupportedChl[i];
				peer_sup_chl_max_2g = peer_ie_list->SupportedChl[i] + peer_ie_list->SupportedChl[i + 1] - 1;
				MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("  peer_sup_chl_min_2g = %d, peer_sup_chl_max_2g = %d\n",
						 peer_sup_chl_min_2g, peer_sup_chl_max_2g));
			}
		}

		/* Check Min/Max 2.4G channel boundary in BW40 case */
		if ((supported_bw == BW_40) && (ext_cha != EXTCHA_NONE)) {
			if (((ext_cha == EXTCHA_ABOVE) && ((wdev->channel + 4) > peer_sup_chl_max_2g)) ||
				((ext_cha == EXTCHA_BELOW) && ((wdev->channel - 4) < peer_sup_chl_min_2g)))
				supported_bw = BW_20;
		}
	}

	return supported_bw;
}

INT ht_mode_adjust(RTMP_ADAPTER *pAd, MAC_TABLE_ENTRY *pEntry, IE_LISTS *peer_ie_list, HT_CAPABILITY_IE *peer, RT_HT_CAPABILITY *my)
{
	UCHAR supported_bw = ht_support_bw_by_channel_boundary(pAd, pEntry, peer_ie_list);
	struct wifi_dev *wdev = pEntry->wdev;
	ADD_HT_INFO_IE *addht;

	if (!wdev)
		return FALSE;

	addht = wlan_operate_get_addht(wdev);

	if ((peer->HtCapInfo.GF) && (my->GF))
		pEntry->MaxHTPhyMode.field.MODE = MODE_HTGREENFIELD;
	else {
		pEntry->MaxHTPhyMode.field.MODE = MODE_HTMIX;
		pAd->MacTab.fAnyStationNonGF = TRUE;
	}

	if ((peer->HtCapInfo.ChannelWidth) && (wlan_config_get_ht_bw(wdev)) && (wlan_operate_get_ht_bw(wdev)) && (supported_bw == BW_40)) {
		pEntry->MaxHTPhyMode.field.BW = BW_40;
		pEntry->MaxHTPhyMode.field.ShortGI = ((my->ShortGIfor40) & (peer->HtCapInfo.ShortGIfor40));
	} else {
		pEntry->MaxHTPhyMode.field.BW = BW_20;
		pEntry->MaxHTPhyMode.field.ShortGI = ((my->ShortGIfor20) & (peer->HtCapInfo.ShortGIfor20));
		pAd->MacTab.fAnyStation20Only = TRUE;
	}

	pEntry->MaxHTPhyMode.field.STBC = (peer->HtCapInfo.RxSTBC & (pAd->CommonCfg.DesiredHtPhy.TxSTBC));
	MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s(), MODE = %d, BW = %d, SGI = %d, STBC = %d\n", __func__,
			 pEntry->MaxHTPhyMode.field.MODE,
			 pEntry->MaxHTPhyMode.field.BW,
			 pEntry->MaxHTPhyMode.field.ShortGI,
			 pEntry->MaxHTPhyMode.field.STBC));
	return TRUE;
}


INT set_ht_fixed_mcs(RTMP_ADAPTER *pAd, MAC_TABLE_ENTRY *pEntry, UCHAR fixed_mcs, UCHAR mcs_bound)
{
	if (fixed_mcs == 32) {
		/* Fix MCS as HT Duplicated Mode */
		pEntry->MaxHTPhyMode.field.BW = 1;
		pEntry->MaxHTPhyMode.field.MODE = MODE_HTMIX;
		pEntry->MaxHTPhyMode.field.STBC = 0;
		pEntry->MaxHTPhyMode.field.ShortGI = 0;
		pEntry->MaxHTPhyMode.field.MCS = 32;
	} else if (pEntry->MaxHTPhyMode.field.MCS > mcs_bound) {
		/* STA supports fixed MCS */
		pEntry->MaxHTPhyMode.field.MCS = mcs_bound;
	}

	return TRUE;
}


INT get_ht_max_mcs(RTMP_ADAPTER *pAd, UCHAR *desire_mcs, UCHAR *cap_mcs)
{
	INT i, j;
	UCHAR bitmask;

	for (i = 31; i >= 0; i--) {
		j = i / 8;
		bitmask = (1 << (i - (j * 8)));

		if ((desire_mcs[j] & bitmask) && (cap_mcs[j] & bitmask)) {
			/*pEntry->MaxHTPhyMode.field.MCS = i; */
			/* find it !!*/
			break;
		}

		if (i == 0)
			break;
	}

	return i;
}


INT get_ht_cent_ch(RTMP_ADAPTER *pAd, UINT8 *rf_bw, UINT8 *ext_ch, UCHAR Channel)
{
	UCHAR op_ht_bw = HT_BW_20;
	UCHAR op_ext_cha = EXTCHA_NONE;
	UCHAR i;
	struct wifi_dev *wdev;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		wdev = pAd->wdev_list[i];

		if (!wdev)
			continue;

		/*check in the same band*/
		if (Channel == wdev->channel && wlan_operate_get_state(wdev) == WLAN_OPER_STATE_INVALID) {
			op_ht_bw = wlan_operate_get_ht_bw(wdev);
			op_ext_cha = wlan_operate_get_ext_cha(wdev);

			if (op_ht_bw == HT_BW_40)
				break;
		}
	}

	if ((op_ht_bw  == BW_40) &&
		(op_ext_cha == EXTCHA_ABOVE)
	   ) {
		*rf_bw = BW_40;
		*ext_ch = EXTCHA_ABOVE;
	} else if ((Channel > 2) &&
			   (op_ht_bw == BW_40) &&
			   (op_ext_cha == EXTCHA_BELOW)) {
		*rf_bw = BW_40;
		*ext_ch = EXTCHA_BELOW;

	} else
		return FALSE;

	return TRUE;
}

UCHAR cal_ht_cent_ch(UCHAR prim_ch, UCHAR phy_bw, UCHAR ext_cha, UCHAR *cen_ch)
{
	*cen_ch = prim_ch;

	if ((phy_bw  == BW_40) &&
		(ext_cha == EXTCHA_ABOVE)
	   )
		*cen_ch = prim_ch + 2;
	else if ((prim_ch > 2) &&
			 (phy_bw == BW_40) &&
			 (ext_cha == EXTCHA_BELOW)) {
		if (prim_ch == 14)
			*cen_ch = prim_ch - 1;
		else
			*cen_ch = prim_ch - 2;
	} else
		return FALSE;

	return TRUE;
}



UCHAR get_cent_ch_by_htinfo(
	RTMP_ADAPTER *pAd,
	ADD_HT_INFO_IE *ht_op,
	HT_CAPABILITY_IE *ht_cap)
{
	UCHAR cent_ch;

	if ((ht_op->ControlChan > 2) &&
		(ht_op->AddHtInfo.ExtChanOffset == EXTCHA_BELOW) &&
		(ht_cap->HtCapInfo.ChannelWidth == BW_40))
		cent_ch = ht_op->ControlChan - 2;
	else if ((ht_op->AddHtInfo.ExtChanOffset == EXTCHA_ABOVE) &&
			 (ht_cap->HtCapInfo.ChannelWidth == BW_40))
		cent_ch = ht_op->ControlChan + 2;
	else
		cent_ch = ht_op->ControlChan;

	return cent_ch;
}


UINT16 ht_max_mpdu_size[2] = {3839u, 7935u};

VOID set_sta_ht_cap(RTMP_ADAPTER *pAd, MAC_TABLE_ENTRY *entry, HT_CAPABILITY_IE *ht_ie)
{
	UCHAR ht_gi = GI_400;

	/* set HT capabilty flag for entry */
	CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_HT_CAPABLE);

	ht_gi = wlan_config_get_ht_gi(entry->wdev);
	if (ht_gi == GI_400) {
		if (ht_ie->HtCapInfo.ShortGIfor20)
			CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_SGI20_CAPABLE);

		if (ht_ie->HtCapInfo.ShortGIfor40)
			CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_SGI40_CAPABLE);
	}

	if (ht_ie->HtCapInfo.TxSTBC)
		CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_TxSTBC_CAPABLE);

	if (ht_ie->HtCapInfo.RxSTBC)
		CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_RxSTBC_CAPABLE);

	if (ht_ie->ExtHtCapInfo.PlusHTC) {
		CLIENT_CAP_SET_FLAG(entry, fCLIENT_STATUS_HTC_CAPABLE);
		CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_HTC_CAPABLE);
	}

	if (pAd->CommonCfg.bRdg && ht_ie->ExtHtCapInfo.RDGSupport)
		CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_RDG_CAPABLE);

	if (ht_ie->ExtHtCapInfo.MCSFeedback == 0x03)
		CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_MCSFEEDBACK_CAPABLE);

	if (wlan_config_get_ht_ldpc(entry->wdev) && (pAd->chipCap.phy_caps & fPHY_CAP_LDPC)) {
		if (ht_ie->HtCapInfo.ht_rx_ldpc)
			CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_HT_RX_LDPC_CAPABLE);
	}

	if (pAd->CommonCfg.DesiredHtPhy.AmsduEnable && (pAd->CommonCfg.REGBACapability.field.AutoBA == FALSE))
		CLIENT_STATUS_SET_FLAG(entry, fCLIENT_STATUS_AMSDU_INUSED);

	entry->MpduDensity = ht_ie->HtCapParm.MpduDensity;
	entry->MaxRAmpduFactor = ht_ie->HtCapParm.MaxRAmpduFactor;
	entry->MmpsMode = (UCHAR)ht_ie->HtCapInfo.MimoPs;
	entry->AMsduSize = (UCHAR)ht_ie->HtCapInfo.AMsduSize;

	if (entry->AMsduSize < (sizeof(ht_max_mpdu_size) / sizeof(ht_max_mpdu_size[0])))
		entry->amsdu_limit_len = ht_max_mpdu_size[entry->AMsduSize];
	else
		entry->amsdu_limit_len = 0;
	entry->amsdu_limit_len_adjust = entry->amsdu_limit_len;
}


/*
	========================================================================
	Routine Description:
		Caller ensures we has 802.11n support.
		Calls at setting HT from AP/STASetinformation

	Arguments:
		pAd - Pointer to our adapter
		phymode  -

	========================================================================
*/
VOID RTMPSetHT(
	IN RTMP_ADAPTER *pAd,
	IN OID_SET_HT_PHYMODE * pHTPhyMode,
	IN struct wifi_dev *wdev)
{
	INT idx;
	UCHAR ht_ldpc = 0, gf_support = 0, stbc = STBC_NONE, ht_gi = GI_800;
#ifdef CONFIG_MULTI_CHANNEL
#if defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT)
	BSS_STRUCT *pMbss = &pAd->ApCfg.MBSSID[CFG_GO_BSSID_IDX];
#endif /* defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT) */
#endif /* CONFIG_MULTI_CHANNEL */
	RT_HT_CAPABILITY *rt_ht_cap = &pAd->CommonCfg.DesiredHtPhy;
	HT_CAPABILITY_IE *ht_cap = (HT_CAPABILITY_IE *)wlan_config_get_ht_cap(wdev);
#ifdef CONFIG_AP_SUPPORT

	/* sanity check for extention channel */
	if (CHAN_PropertyCheck(pAd, pHTPhyMode->Channel,
						   CHANNEL_NO_FAT_BELOW | CHANNEL_NO_FAT_ABOVE) == TRUE) {
		/* only 20MHz is allowed */
		pHTPhyMode->BW = 0;
	} else if (pHTPhyMode->ExtOffset == EXTCHA_BELOW) {
		/* extension channel below this channel is not allowed */
		if (CHAN_PropertyCheck(pAd, pHTPhyMode->Channel,
							   CHANNEL_NO_FAT_BELOW) == TRUE)
			pHTPhyMode->ExtOffset = EXTCHA_ABOVE;
	} else if (pHTPhyMode->ExtOffset == EXTCHA_ABOVE) {
		/* extension channel above this channel is not allowed */
		if (CHAN_PropertyCheck(pAd, pHTPhyMode->Channel,
							   CHANNEL_NO_FAT_ABOVE) == TRUE)
			pHTPhyMode->ExtOffset = EXTCHA_BELOW;
	}

#endif /* CONFIG_AP_SUPPORT */
	MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("RTMPSetHT : HT_mode(%d), ExtOffset(%d), MCS(%d), BW(%d), STBC(%d), SHORTGI(%d)\n",
			 pHTPhyMode->HtMode, pHTPhyMode->ExtOffset,
			 pHTPhyMode->MCS, pHTPhyMode->BW,
			 pHTPhyMode->STBC, pHTPhyMode->SHORTGI));
	/* Don't zero supportedHyPhy structure.*/
	RTMPZeroMemory(ht_cap, sizeof(HT_CAPABILITY_IE));
	RTMPZeroMemory(&pAd->CommonCfg.NewExtChanOffset, sizeof(pAd->CommonCfg.NewExtChanOffset));
	RTMPZeroMemory(rt_ht_cap, sizeof(RT_HT_CAPABILITY));

	if (pAd->CommonCfg.bRdg) {
		ht_cap->ExtHtCapInfo.PlusHTC = 1;
		ht_cap->ExtHtCapInfo.RDGSupport = 1;
	} else {
		ht_cap->ExtHtCapInfo.PlusHTC = 0;
		ht_cap->ExtHtCapInfo.RDGSupport = 0;
	}

	ht_cap->HtCapParm.MaxRAmpduFactor = pAd->chipCap.AMPDUFactor;
	rt_ht_cap->MaxRAmpduFactor = pAd->chipCap.AMPDUFactor;
	MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("RTMPSetHT : RxBAWinLimit = %d\n", pAd->CommonCfg.BACapability.field.RxBAWinLimit));
	/* Mimo power save, A-MSDU size, */
	rt_ht_cap->AmsduEnable = (USHORT)pAd->CommonCfg.BACapability.field.AmsduEnable;
	rt_ht_cap->AmsduSize = (UCHAR)pAd->CommonCfg.BACapability.field.AmsduSize;
	rt_ht_cap->MimoPs = (UCHAR)pAd->CommonCfg.BACapability.field.MMPSmode;
	rt_ht_cap->MpduDensity = (UCHAR)pAd->CommonCfg.BACapability.field.MpduDensity;
	ht_cap->HtCapInfo.AMsduSize = (USHORT)pAd->CommonCfg.BACapability.field.AmsduSize;
	ht_cap->HtCapInfo.MimoPs = (USHORT)pAd->CommonCfg.BACapability.field.MMPSmode;

	ht_cap->HtCapParm.MpduDensity = (UCHAR)pAd->CommonCfg.BACapability.field.MpduDensity;
	MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("RTMPSetHT : AMsduSize = %d, MimoPs = %d, MpduDensity = %d, MaxRAmpduFactor = %d\n",
			 rt_ht_cap->AmsduSize,
			 rt_ht_cap->MimoPs,
			 rt_ht_cap->MpduDensity,
			 rt_ht_cap->MaxRAmpduFactor));

	ht_ldpc = (wlan_config_get_ht_ldpc(wdev) && (pAd->chipCap.phy_caps & fPHY_CAP_LDPC)) ? 1 : 0;
	wlan_config_set_ht_ldpc(wdev, ht_ldpc);

	gf_support = (pHTPhyMode->HtMode == HTMODE_GF) ? 1 : 0;
	wlan_config_set_gf(wdev, gf_support);
	rt_ht_cap->GF = gf_support;

	/* Decide Rx MCSSet*/
	switch (wlan_operate_get_rx_stream(wdev)) {
	case 4:
		ht_cap->MCSSet[3] =  0xff;

	case 3:
		ht_cap->MCSSet[2] =  0xff;

	case 2:
		ht_cap->MCSSet[1] =  0xff;

	case 1:
	default:
		ht_cap->MCSSet[0] =  0xff;
		break;
	}

	if (pAd->CommonCfg.bForty_Mhz_Intolerant && (pHTPhyMode->BW == BW_40)) {
		pHTPhyMode->BW = BW_20;
		wlan_config_set_40M_intolerant(wdev, 1);
	}

	/* TODO: shiang-6590, how about the "bw" when channel 14 for JP region??? */
	if (pHTPhyMode->BW == BW_40) {
		UCHAR ext_cha = (pHTPhyMode->ExtOffset == EXTCHA_BELOW) ? (EXTCHA_BELOW) : EXTCHA_ABOVE;

		ht_cap->MCSSet[4] = 0x1; /* MCS 32*/
		wlan_config_set_ht_bw(wdev, HT_BW_40);

		if (pHTPhyMode->Channel <= 14)
			ht_cap->HtCapInfo.CCKmodein40 = 1;

		wlan_operate_set_ht_bw(wdev, HT_BW_40, ext_cha);
	} else {
		wlan_operate_set_ht_bw(wdev, HT_BW_20, EXTCHA_NONE);
	}

#ifdef CONFIG_MULTI_CHANNEL
#if defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT)

	if ((pHTPhyMode->BW == BW_20) && (pHTPhyMode->Channel != 0)) {
		wlan_config_set_ht_bw(wdev, HT_BW_20);
		wlan_operate_set_ht_bw(wdev, HT_BW_20, EXTCHA_NONE);
	} else if (INFRA_ON(pAd)) {
		struct wifi_dev *p2p_dev = &pAd->StaCfg[0].wdev;
		UCHAR ht_bw = wlan_config_get_ht_bw(p2p_dev);
		UCHAR ext_cha = wlan_config_get_ext_cha(p2p_dev);

		wlan_operate_set_ht_bw(p2p_dev, ht_bw, ext_cha);
	}

#endif /* defined(RT_CFG80211_SUPPORT) && defined(CONFIG_AP_SUPPORT) */
#endif /* CONFIG_MULTI_CHANNEL */

	if (pHTPhyMode->STBC == STBC_USE) {
		if (pAd->Antenna.field.TxPath >= 2) {
			rt_ht_cap->TxSTBC = 1;
		} else {
			rt_ht_cap->TxSTBC = 0;
		}

		/*
			RxSTBC
				0: not support,
				1: support for 1SS
				2: support for 1SS, 2SS
				3: support for 1SS, 2SS, 3SS
		*/
		if (pAd->Antenna.field.RxPath >= 1) {
			rt_ht_cap->RxSTBC = 1;
		} else {
			rt_ht_cap->RxSTBC = 0;
		}
		stbc = STBC_USE;
	} else {
		rt_ht_cap->TxSTBC = 0;
		rt_ht_cap->RxSTBC = 0;
		stbc = STBC_NONE;
	}
	wlan_config_set_ht_stbc(wdev, stbc);

	if (pHTPhyMode->SHORTGI == GI_400) {
		rt_ht_cap->ShortGIfor20 = 1;
		ht_gi = GI_400;

		if (pHTPhyMode->BW == BW_40)
			rt_ht_cap->ShortGIfor40 = 1;
		else
			rt_ht_cap->ShortGIfor40 = 0;
	} else {
		rt_ht_cap->ShortGIfor20 = 0;
		rt_ht_cap->ShortGIfor40 = 0;
		ht_gi = GI_800;
	}
	wlan_config_set_ht_gi(wdev, ht_gi);

	/* 1, the extension channel above the control channel. */
#ifdef TXBF_SUPPORT

	if (pAd->chipCap.FlgHwTxBfCap) {
#ifdef MT_MAC
		/* Set ETxBF */
		mt_WrapSetETxBFCap(pAd, &ht_cap->TxBFCap);
		/* Check ITxBF */
#else
		/* Set ETxBF */
		setETxBFCap(pAd, &ht_cap->TxBFCap);
		/* Check ITxBF */
		pAd->CommonCfg.RegTransmitSetting.field.ITxBfEn &= rtmp_chk_itxbf_calibration(pAd);
#endif /* MT_MAC */
		/* Apply to ASIC */
#ifdef MT7636
		{
			TXBF_STATUS_INFO TxBfInfo;

			TxBfInfo.ucETxBfTxEn = (UCHAR) pAd->CommonCfg.ETxBfEnCond;
			TxBfInfo.ucITxBfTxEn  = pAd->CommonCfg.RegTransmitSetting.field.ITxBfEn;
			mt_asic_set_bf(pAd, &TxBfInfo);
		}
#endif
	}

#endif /* TXBF_SUPPORT */
#ifdef CONFIG_AP_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
		for (idx = 0; idx < pAd->ApCfg.BssidNum; idx++)
			RTMPSetIndividualHT(pAd, idx);

#if 0
#ifdef WDS_SUPPORT

		for (idx = 0; idx < MAX_WDS_ENTRY; idx++)
			RTMPSetIndividualHT(pAd, idx + MIN_NET_DEVICE_FOR_WDS);

#endif /* WDS_SUPPORT */
#endif
#ifdef APCLI_SUPPORT

		for (idx = 0; idx < MAX_APCLI_NUM; idx++)
			RTMPSetIndividualHT(pAd, idx + MIN_NET_DEVICE_FOR_APCLI);

#endif /* APCLI_SUPPORT */
	}
#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
#ifdef P2P_SUPPORT

		for (idx = 0; idx < pAd->ApCfg.BssidNum; idx++)
			RTMPSetIndividualHT(pAd, idx + MIN_NET_DEVICE_FOR_P2P_GO);

		for (idx = 0; idx < MAX_APCLI_NUM; idx++)
			RTMPSetIndividualHT(pAd, idx + MIN_NET_DEVICE_FOR_APCLI);

#endif /* P2P_SUPPORT */
#ifdef RT_CFG80211_P2P_SUPPORT

		for (idx = 0; idx < pAd->ApCfg.BssidNum; idx++)
			RTMPSetIndividualHT(pAd, idx + MIN_NET_DEVICE_FOR_CFG80211_VIF_P2P_GO);

#endif /* RT_CFG80211_P2P_SUPPORT */

		/* TODO: Pat: we initialize HT Cap even when 2nd STA is not yet initialized. */
		/* for (idx = 0; idx < pAd->MSTANum; idx++) */
		for (idx = 0; idx < pAd->MaxMSTANum; idx++)
			RTMPSetIndividualHT(pAd, idx);
	}
#endif /* CONFIG_STA_SUPPORT */
#ifdef MESH_SUPPORT
	RTMPSetIndividualHT(pAd, MIN_NET_DEVICE_FOR_MESH);
#endif /* MESH_SUPPORT */

	/*TODO: Hugo temp copy, finally need to remove */
	os_zero_mem(&pAd->CommonCfg.HtCapability, sizeof(HT_CAPABILITY_IE));
	os_move_mem(&pAd->CommonCfg.HtCapability, ht_cap, sizeof(HT_CAPABILITY_IE));
}

/*
	========================================================================
	Routine Description:
		Caller ensures we has 802.11n support.
		Calls at setting HT from AP/STASetinformation

	Arguments:
		pAd - Pointer to our adapter
		phymode  -

	========================================================================
*/
VOID RTMPSetIndividualHT(RTMP_ADAPTER *pAd, UCHAR apidx)
{
	RT_PHY_INFO *pDesired_ht_phy = NULL;
	UCHAR TxStream = 1;
	UCHAR DesiredMcs = MCS_AUTO;
	UINT32 encrypt_mode = 0;
	struct wifi_dev *wdev = NULL;
#ifdef CONFIG_STA_SUPPORT
	PSTA_ADMIN_CONFIG pStaCfg = NULL;
#endif
	UCHAR cfg_ht_bw;

	MTWF_LOG(DBG_CAT_AP, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("%s(): apidx=%d\n", __func__, apidx));

	do {
#ifdef RT_CFG80211_P2P_SUPPORT

		if (apidx >= MIN_NET_DEVICE_FOR_CFG80211_VIF_P2P_GO) {
			UCHAR idx = apidx - MIN_NET_DEVICE_FOR_CFG80211_VIF_P2P_GO;

			wdev = &pAd->ApCfg.MBSSID[idx].wdev;
			pDesired_ht_phy = &wdev->DesiredHtPhyInfo;
			DesiredMcs = wdev->DesiredTransmitSetting.field.MCS;
			encrypt_mode = wdev->SecConfig.PairwiseCipher;
			wdev->bWmmCapable = TRUE;
			wdev->bAutoTxRateSwitch = (DesiredMcs == MCS_AUTO) ? TRUE : FALSE;
			break;
		}

#endif /* RT_CFG80211_P2P_SUPPORT */
#ifdef P2P_SUPPORT

		if (apidx >= MIN_NET_DEVICE_FOR_P2P_GO) {
			UCHAR idx = apidx - MIN_NET_DEVICE_FOR_P2P_GO;

			wdev = &pAd->ApCfg.MBSSID[idx].wdev;
			pDesired_ht_phy = &wdev->DesiredHtPhyInfo;
			DesiredMcs = wdev->DesiredTransmitSetting.field.MCS;
			encrypt_mode = wdev->SecConfig.PairwiseCipher;
			wdev->bWmmCapable = TRUE;
			wdev->bAutoTxRateSwitch = (DesiredMcs == MCS_AUTO) ? TRUE : FALSE;
			break;
		}

#endif /* P2P_SUPPORT */
#ifdef MESH_SUPPORT

		if (apidx >= MIN_NET_DEVICE_FOR_MESH) {
			wdev = &pAd->MeshTab.wdev;
			pDesired_ht_phy = &wdev->DesiredHtPhyInfo;
			DesiredMcs = wdev->DesiredTransmitSetting.field.MCS;
			encrypt_mode = wdev->SecConfig.PairwiseCipher;
			wdev->bAutoTxRateSwitch = (DesiredMcs == MCS_AUTO) ? TRUE : FALSE;
			break;
		}

#endif /* MESH_SUPPORT */
#ifdef CONFIG_AP_SUPPORT
#ifdef APCLI_SUPPORT

		if (apidx >= MIN_NET_DEVICE_FOR_APCLI) {
			UCHAR	idx = apidx - MIN_NET_DEVICE_FOR_APCLI;

			if (idx < MAX_APCLI_NUM) {
				wdev = &pAd->ApCfg.ApCliTab[idx].wdev;
				pDesired_ht_phy = &wdev->DesiredHtPhyInfo;
				DesiredMcs = wdev->DesiredTransmitSetting.field.MCS;
				encrypt_mode = wdev->SecConfig.PairwiseCipher;
				wdev->bAutoTxRateSwitch = (DesiredMcs == MCS_AUTO) ? TRUE : FALSE;
				break;
			} else {
				MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: invalid idx(%d)\n", __func__, idx));
				return;
			}
		}

#endif /* APCLI_SUPPORT */
		IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
#ifdef WDS_SUPPORT

			if (apidx >= MIN_NET_DEVICE_FOR_WDS) {
				UCHAR	idx = apidx - MIN_NET_DEVICE_FOR_WDS;

				if (idx < MAX_WDS_ENTRY) {
					wdev = &pAd->WdsTab.WdsEntry[idx].wdev;
					pDesired_ht_phy = &wdev->DesiredHtPhyInfo;
					DesiredMcs = wdev->DesiredTransmitSetting.field.MCS;
					/*encrypt_mode = pAd->WdsTab.WdsEntry[idx].WepStatus;*/
					wdev->bAutoTxRateSwitch = (DesiredMcs == MCS_AUTO) ? TRUE : FALSE;
					break;
				} else {
					MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: invalid apidx(%d)\n", __func__, apidx));
					return;
				}
			}

#endif /* WDS_SUPPORT */

			if ((apidx < pAd->ApCfg.BssidNum) && (apidx < MAX_MBSSID_NUM(pAd)) && (apidx < HW_BEACON_MAX_NUM)) {
				wdev = &pAd->ApCfg.MBSSID[apidx].wdev;
				pDesired_ht_phy = &wdev->DesiredHtPhyInfo;
				DesiredMcs = wdev->DesiredTransmitSetting.field.MCS;
#ifdef WFA_VHT_PF

				/* TODO: Sigma, this code segment used to work around for Sigma Automation! */
				if (WMODE_CAP_AC(wdev->PhyMode) && (DesiredMcs != MCS_AUTO)) {
					DesiredMcs += ((wlan_operate_get_tx_stream(wdev) - 1) << 4);
					pAd->ApCfg.MBSSID[apidx].DesiredTransmitSetting.field.FixedTxMode = FIXED_TXMODE_VHT;
					RT_CfgSetAutoFallBack(pAd, "0");
				} else
					RT_CfgSetAutoFallBack(pAd, "1");

#endif /* WFA_VHT_PF */
				encrypt_mode = wdev->SecConfig.PairwiseCipher;
				wdev->bWmmCapable = TRUE;
				wdev->bAutoTxRateSwitch = (DesiredMcs == MCS_AUTO) ? TRUE : FALSE;
				break;
			}

			MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: invalid apidx(%d)\n", __func__, apidx));
			return;
		}
#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
		IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
			wdev = &pAd->StaCfg[apidx].wdev;
			pStaCfg = &pAd->StaCfg[apidx];
			pDesired_ht_phy = &wdev->DesiredHtPhyInfo;
			DesiredMcs = wdev->DesiredTransmitSetting.field.MCS;
			encrypt_mode = wdev->SecConfig.PairwiseCipher;
			break;
		}
#endif /* CONFIG_STA_SUPPORT */
	} while (FALSE);

	if (!wdev)
		return;

	if (pDesired_ht_phy == NULL) {
		MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: invalid apidx(%d)\n", __func__, apidx));
		return;
	}

	TxStream = wlan_operate_get_tx_stream(wdev);

	RTMPZeroMemory(pDesired_ht_phy, sizeof(RT_PHY_INFO));
	MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("RTMPSetIndividualHT : Desired MCS = %d\n", DesiredMcs));

	/* Check the validity of MCS */
	if ((TxStream == 1) && ((DesiredMcs >= MCS_8) && (DesiredMcs <= MCS_15))) {
		MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s: MCS(%d) is invalid in 1S, reset it as MCS_7\n", __func__, DesiredMcs));
		DesiredMcs = MCS_7;
	}

	cfg_ht_bw = wlan_config_get_ht_bw(wdev);

	if ((cfg_ht_bw == HT_BW_20) && (DesiredMcs == MCS_32)) {
		MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s: MCS_32 is only supported in 40-MHz, reset it as MCS_0\n", __func__));
		DesiredMcs = MCS_0;
	}

#ifdef CONFIG_STA_SUPPORT

	if ((pAd->OpMode == OPMODE_STA) && (pStaCfg->BssType == BSS_INFRA) && (apidx == MIN_NET_DEVICE_FOR_MBSSID))
		;
	else
#endif /* CONFIG_STA_SUPPORT */

		/*
			WFA recommend to restrict the encryption type in 11n-HT mode.
			So, the WEP and TKIP are not allowed in HT rate.
		*/
		if (pAd->CommonCfg.HT_DisallowTKIP && IS_INVALID_HT_SECURITY(encrypt_mode)) {
#ifdef CONFIG_STA_SUPPORT
			pStaCfg->bAdhocN = FALSE;
#endif /* CONFIG_STA_SUPPORT */
			MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s : Use legacy rate in WEP/TKIP encryption mode (apidx=%d)\n",
					 __func__, apidx));
			return;
		}

	if (pAd->CommonCfg.HT_Disable) {
#ifdef CONFIG_STA_SUPPORT
		pStaCfg->bAdhocN = FALSE;
#endif /* CONFIG_STA_SUPPORT */
		MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s : HT is disabled\n", __func__));
		return;
	}

	pDesired_ht_phy->bHtEnable = TRUE;

	/* Decide desired Tx MCS*/
	switch (TxStream) {
	case 1:
		if (DesiredMcs == MCS_AUTO)
			pDesired_ht_phy->MCSSet[0] = 0xff;
		else if (DesiredMcs <= MCS_7)
			pDesired_ht_phy->MCSSet[0] = 1 << DesiredMcs;

		break;

	case 2:
		if (DesiredMcs == MCS_AUTO) {
			pDesired_ht_phy->MCSSet[0] = 0xff;
			pDesired_ht_phy->MCSSet[1] = 0xff;
		} else if (DesiredMcs <= MCS_15) {
			ULONG mode;

			mode = DesiredMcs / 8;

			if (mode < 2)
				pDesired_ht_phy->MCSSet[mode] = (1 << (DesiredMcs - mode * 8));
		}

		break;

	case 3:
		if (DesiredMcs == MCS_AUTO) {
			/* MCS0 ~ MCS23, 3 bytes */
			pDesired_ht_phy->MCSSet[0] = 0xff;
			pDesired_ht_phy->MCSSet[1] = 0xff;
			pDesired_ht_phy->MCSSet[2] = 0xff;
		} else if (DesiredMcs <= MCS_23) {
			ULONG mode;

			mode = DesiredMcs / 8;

			if (mode < 3)
				pDesired_ht_phy->MCSSet[mode] = (1 << (DesiredMcs - mode * 8));
		}

		break;

	case 4:
		if (DesiredMcs == MCS_AUTO) {
			/* MCS0 ~ MCS31, 4 bytes */
			pDesired_ht_phy->MCSSet[0] = 0xff;
			pDesired_ht_phy->MCSSet[1] = 0xff;
			pDesired_ht_phy->MCSSet[2] = 0xff;
			pDesired_ht_phy->MCSSet[3] = 0xff;
		} else if (DesiredMcs <= MCS_31) {
			ULONG mode;

			mode = DesiredMcs / 8;

			if (mode < 4)
				pDesired_ht_phy->MCSSet[mode] = (1 << (DesiredMcs - mode * 8));
		}

		break;
	}

	if (cfg_ht_bw == HT_BW_40) {
		if (DesiredMcs == MCS_AUTO || DesiredMcs == MCS_32)
			pDesired_ht_phy->MCSSet[4] = 0x1;
	}

	/* update HT Rate setting */
	if (pAd->OpMode == OPMODE_STA) {
#ifdef P2P_SUPPORT

		if (apidx > BSS0)
			MlmeUpdateHtTxRates(pAd, apidx);
		else
#endif /* P2P_SUPPORT */
			MlmeUpdateHtTxRates(pAd, BSS0);
	} else
		MlmeUpdateHtTxRates(pAd, apidx);

#ifdef DOT11_VHT_AC

	if (WMODE_CAP_AC(wdev->PhyMode)) {
		pDesired_ht_phy->bVhtEnable = TRUE;
		rtmp_set_vht(pAd, wdev, pDesired_ht_phy);
	}

#endif /* DOT11_VHT_AC */
}

/*
	========================================================================
	Routine Description:
		Clear the desire HT info per interface

	Arguments:

	========================================================================
*/
VOID RTMPDisableDesiredHtInfo(RTMP_ADAPTER *pAd, UCHAR Channel)
{
#ifdef CONFIG_AP_SUPPORT
	UINT8 idx = 0;
	struct wifi_dev *wdev = NULL;

	IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
		for (idx = 0; idx < pAd->ApCfg.BssidNum; idx++) {
			wdev = &pAd->ApCfg.MBSSID[idx].wdev;

			if (Channel == wdev->channel)
				RTMPZeroMemory(&wdev->DesiredHtPhyInfo, sizeof(RT_PHY_INFO));
		}

#ifdef WDS_SUPPORT

		for (idx = 0; idx < MAX_WDS_ENTRY; idx++) {
			wdev = &pAd->WdsTab.WdsEntry[idx].wdev;

			if (Channel == wdev->channel)
				RTMPZeroMemory(&wdev->DesiredHtPhyInfo, sizeof(RT_PHY_INFO));
		}

#endif /* WDS_SUPPORT */
#ifdef APCLI_SUPPORT

		for (idx = 0; idx < MAX_APCLI_NUM; idx++) {
			wdev = &pAd->ApCfg.ApCliTab[idx].wdev;

			if (Channel == wdev->channel)
				RTMPZeroMemory(&wdev->DesiredHtPhyInfo, sizeof(RT_PHY_INFO));
		}

#endif /* APCLI_SUPPORT */
	}
#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
#ifdef P2P_SUPPORT
		UINT8 idx = 0;

		for (idx = 0; idx < pAd->ApCfg.BssidNum; idx++) {
			struct wifi_dev *wdev = NULL;

			wdev = &pAd->ApCfg.MBSSID[idx].wdev;
			RTMPZeroMemory(&wdev->DesiredHtPhyInfo, sizeof(RT_PHY_INFO));
		}

		for (idx = 0; idx < MAX_APCLI_NUM; idx++)
			RTMPZeroMemory(&pAd->ApCfg.ApCliTab[idx].wdev.DesiredHtPhyInfo, sizeof(RT_PHY_INFO));

#endif /* P2P_SUPPORT */
		RTMPZeroMemory(&pAd->StaCfg[0].wdev.DesiredHtPhyInfo, sizeof(RT_PHY_INFO));
	}
#endif /* CONFIG_STA_SUPPORT */
#ifdef MESH_SUPPORT
	RTMPZeroMemory(&pAd->MeshTab.wdev.DesiredHtPhyInfo, sizeof(RT_PHY_INFO));
#endif /* MESH_SUPPORT */
}


INT	SetCommonHT(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	OID_SET_HT_PHYMODE SetHT;
	UCHAR op_ht_bw = wlan_operate_get_ht_bw(wdev);
	UCHAR ext_cha = wlan_operate_get_ext_cha(wdev);

	if (!WMODE_CAP_N(wdev->PhyMode)) {
		/* Clear previous HT information */
		RTMPDisableDesiredHtInfo(pAd, wdev->channel);
		return FALSE;
	}

	SetHT.PhyMode = (RT_802_11_PHY_MODE)(wdev->PhyMode);
	SetHT.TransmitNo = ((UCHAR)pAd->Antenna.field.TxPath);
	SetHT.HtMode = (UCHAR)pAd->CommonCfg.RegTransmitSetting.field.HTMODE;
	SetHT.ExtOffset = ext_cha;
	SetHT.MCS = MCS_AUTO;
	SetHT.BW = (UCHAR)op_ht_bw;
	SetHT.STBC = wlan_config_get_ht_stbc(wdev);
	SetHT.SHORTGI = (UCHAR)wlan_config_get_ht_gi(wdev);
	SetHT.Channel = wdev->channel;
	SetHT.BandIdx = 0;
	RTMPSetHT(pAd, &SetHT, wdev);
#ifdef DOT11N_DRAFT3

	if (pAd->CommonCfg.bBssCoexEnable && pAd->CommonCfg.Bss2040NeedFallBack) {
		wlan_operate_set_ht_bw(wdev, HT_BW_20, EXTCHA_NONE);
		pAd->CommonCfg.LastBSSCoexist2040.field.BSS20WidthReq = 1;
		pAd->CommonCfg.Bss2040CoexistFlag |= BSS_2040_COEXIST_INFO_SYNC;
		pAd->CommonCfg.Bss2040NeedFallBack = 1;
	}

#endif /* DOT11N_DRAFT3 */
	return TRUE;
}

/*
	========================================================================
	Routine Description:
		Update HT IE from our capability.

	Arguments:
		Send all HT IE in beacon/probe rsp/assoc rsp/action frame.


	========================================================================
*/
VOID RTMPUpdateHTIE(
	IN RT_HT_CAPABILITY	*pRtHt,
	IN UCHAR *pMcsSet,
	IN struct wifi_dev *wdev,
	OUT HT_CAPABILITY_IE *pHtCapability,
	OUT ADD_HT_INFO_IE *pAddHtInfo)
{
	UCHAR cfg_ht_bw  = wlan_config_get_ht_bw(wdev);
	UCHAR op_ht_bw = wlan_config_get_ht_bw(wdev);

	RTMPZeroMemory(pHtCapability, sizeof(HT_CAPABILITY_IE));
	RTMPZeroMemory(pAddHtInfo, sizeof(ADD_HT_INFO_IE));
	pHtCapability->HtCapInfo.ChannelWidth = cfg_ht_bw;
	pHtCapability->HtCapInfo.MimoPs = pRtHt->MimoPs;
	pHtCapability->HtCapInfo.GF = pRtHt->GF;
	pHtCapability->HtCapInfo.ShortGIfor20 = pRtHt->ShortGIfor20;
	pHtCapability->HtCapInfo.ShortGIfor40 = pRtHt->ShortGIfor40;
	pHtCapability->HtCapInfo.TxSTBC = pRtHt->TxSTBC;
	pHtCapability->HtCapInfo.RxSTBC = pRtHt->RxSTBC;
	pHtCapability->HtCapInfo.AMsduSize = pRtHt->AmsduSize;
	pHtCapability->HtCapParm.MaxRAmpduFactor = pRtHt->MaxRAmpduFactor;
	pHtCapability->HtCapParm.MpduDensity = pRtHt->MpduDensity;
	pAddHtInfo->AddHtInfo.ExtChanOffset = pRtHt->ExtChanOffset;
	pAddHtInfo->AddHtInfo.RecomWidth = op_ht_bw;
	pAddHtInfo->AddHtInfo2.OperaionMode = pRtHt->OperaionMode;
	pAddHtInfo->AddHtInfo2.NonGfPresent = pRtHt->NonGfPresent;
	RTMPMoveMemory(pAddHtInfo->MCSSet, /*pRtHt->MCSSet*/pMcsSet, 4); /* rt2860 only support MCS max=32, no need to copy all 16 uchar.*/
	MTWF_LOG(DBG_CAT_MLME, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("RTMPUpdateHTIE <==\n"));
}

/*sta rec ht features decision*/
UINT32 starec_ht_feature_decision(struct wifi_dev *wdev, struct _MAC_TABLE_ENTRY *entry, UINT32 *feature)
{
	struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	UINT32 features = 0;

	if ((ad->chipCap.SupportAMSDU == TRUE) && (ad->CommonCfg.DesiredHtPhy.AmsduEnable)) {
		features |= STA_REC_AMSDU_FEATURE;
#ifdef HW_TX_AMSDU_SUPPORT
		/* notify FW the entry is support HW AMSDU and config HW AMSDU parameter (length and number) */
		features |= STA_REC_HW_AMSDU_FEATURE;
#endif
		entry->tx_amsdu_bitmap = 0xffff;
	} else {
		entry->tx_amsdu_bitmap = 0x0;
	}

	if (CLIENT_STATUS_TEST_FLAG(entry, fCLIENT_STATUS_HT_CAPABLE))
		features |= STA_REC_BASIC_HT_INFO_FEATURE;

	/*return value, must use or operation*/
	*feature |= features;
	return TRUE;
}

#endif /* DOT11_N_SUPPORT */

