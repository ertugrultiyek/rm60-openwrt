#include <striptool.h>

static struct _RTDefineTag DefineTagList[] = {
	{"WEXT_WPS", FALSE},
	{"RELEASE_EXCLUDE", FALSE},
	{"CRYPT_TESTPLAN", FALSE},
#ifdef INCLUDE_USE_GPL_ALGORITHM
	{"CRYPT_GPL_ALGORITHM", TRUE},
#else
	{"CRYPT_GPL_ALGORITHM", FALSE},
#endif /* INCLUDE_USE_GPL_ALGORITHM */

#ifndef INCLUDE_COC_SUPPORT
	{"COC_SUPPORT", FALSE},
#endif
#ifdef INCLUDE_AP
#ifndef CHIPSET_RBUS
#ifndef MODE_APSTA
	{"WPA_SUPPLICANT_SUPPORT", FALSE},
	{"NATIVE_WPA_SUPPLICANT_SUPPORT", FALSE},
	{"DOT11Z_TDLS_SUPPORT", FALSE},
#endif
#endif
#ifndef INCLUDE_NINTENDO_AP
	{"NINTENDO_AP", FALSE},
#endif
#ifndef INCLUDE_GEMTEK_ATE
	{"GEMTEK_ATE", FALSE},
#endif
#else
	{"CONFIG_AP_SUPPORT", FALSE},
	{"CONFIG_APSTA_SUPPORT", FALSE},
	{"GREENAP_SUPPORT", FALSE},
#endif /* INCLUDE_AP */
#ifndef INCLUDE_STA
	{"CONFIG_STA_SUPPORT", FALSE},
	{"CONFIG_APSTA_SUPPORT", FALSE},
#endif

#ifndef INCLUDE_SAMSUNG_SUPPORT
	{"EASY_CONFIG_SETUP", FALSE},
	{"CONFIG_SAMSUNG_REGULATORY_SUPPORT", FALSE},
	{"WAC_SUPPORT", FALSE},
	{"WAC_QOS_PRIORITY", FALSE},
#endif

#ifndef INCLUDE_SAMSUNG_STA_SUPPORT
	{"STA_EASY_CONFIG_SETUP", FALSE},
#endif

#ifndef SIGMATEL_SDK
	{"SIGMATEL_SDK", FALSE},
#endif

	/* Sort by interface */
#ifndef RTMP_USB_SUPPORT
	{"RTMP_USB_SUPPORT", FALSE},
#endif /* RTMP_USB_SUPPORT */

#ifndef RTMP_PCI_SUPPORT
	{"RTMP_PCI_SUPPORT", FALSE},
#endif /* RTMP_PCI_SUPPORT */

#ifndef RTMP_RBUS_SUPPORT
	{"RTMP_RBUS_SUPPORT", FALSE},
#endif /* RTMP_RBUS_SUPPORT */

#ifndef RTMP_SDIO_SUPPORT
	{"RTMP_SDIO_SUPPORT", FALSE},
#endif /* RTMP_SDIO_SUPPORT */

	/* Sort by mac type */
#ifndef RTMP_MAC_USB
	{"RTMP_MAC_USB", FALSE},
#endif /* RTMP_MAC_USB */

#ifndef RTMP_MAC_PCI
	{"RTMP_MAC_PCI", FALSE},
#endif /* RTMP_MAC_PCI */

	/* Sort by OS */
#ifndef LINUX
	{"LINUX", FALSE},
#endif /* LINUX */
#ifndef ECOS
	{"__ECOS", FALSE},
#endif /* ECOS */
#ifndef UCOS
	{"UCOS", FALSE},
#endif /* UCOS */
#ifndef VXWORKS
	{"VXWORKS", FALSE},
#endif /* VXWORKS */
#ifndef THREADX
	{"THREADX", FALSE},
#endif /* THREADX */

	{"NDIS_WINS", FALSE},
	/* Sort by chipset */
#ifndef RT2860
	{"RT2860", FALSE},
#endif

#ifndef RT2870
	{"RT2870", FALSE},
#endif

#ifndef RT30xx
	{"RT30xx", FALSE},
#endif

#ifndef RT3062
	{"RT3062", FALSE},
#endif

#ifndef RT3090
	{"RT3090", FALSE},
#endif

#ifndef RT3070
	{"RT3070", FALSE},
#endif

#ifndef RT2070
	{"RT2070", FALSE},
#endif

#ifndef RT2880
	{"RT2880", FALSE},
#endif

#ifndef RT2883
	{"RT2883", FALSE},
#endif

#ifndef RT3883
	{"RT3883", FALSE},
#endif

#ifndef RT35xx
	{"RT35xx", FALSE},
#endif

#ifndef RT305x
	{"RT305x", FALSE},
#endif

#ifndef RT3052
	{"RT3052", FALSE},
#endif

#ifndef RT33xx
	{"RT33xx", FALSE},
#endif

#ifndef RT3290
	{"RT3290", FALSE},
#endif

#ifndef RT3390
	{"RT3390", FALSE},
#endif

#ifndef RT3370
	{"RT3370", FALSE},
#endif

#ifndef RT3562
	{"RT3562", FALSE},
#endif

#ifndef RT3572
	{"RT3572", FALSE},
#endif

#ifndef RT3592
	{"RT3592", FALSE},
#endif

#ifndef RT3573
	{"RT3573", FALSE},
#endif

#ifndef RT3593
	{"RT3593", FALSE},
#endif

#ifndef RT5350
	{"RT5350", FALSE},
#endif

#ifndef RT5390
	{"RT5390", FALSE},
#endif

#ifndef RT5392
	{"RT5392", FALSE},
#endif

#ifndef RT5370
	{"RT5370", FALSE},
#endif

#ifndef RT5372
	{"RT5372", FALSE},
#endif

#ifndef RT5592
	{"RT5592", FALSE},
#endif

#ifndef RT5572
	{"RT5572", FALSE},
#endif

#ifndef RT3352
	{"RT3352", FALSE},
#endif

#ifndef RT8592
	{"RT8592", FALSE},
#endif

#ifndef RT6352
	{"RT6352", FALSE},
#endif

#ifndef RT65xx
	{"RT65xx", FALSE},
#endif

#ifdef CHIPSET_2070
	{"DOT11_N_SUPPORT", FALSE},
	{"DOT11N_DRAFT3", FALSE},
#endif

#ifndef MT7601
	{"MT7601", FALSE},
	{"MT7601U", FALSE},
	{"MT7601E", FALSE},
#endif

#ifndef MT76x0
	{"MT76x0", FALSE},
	{"MT7650", FALSE},
	{"MT7630", FALSE},
	{"MT7610", FALSE},
#endif

#ifndef MT76x2
	{"MT76x2", FALSE},
	{"MT7662", FALSE},
	{"MT7632", FALSE},
	{"MT7612", FALSE},
#endif

#ifndef MT7603
	{"MT7603", FALSE},
#endif

#ifndef MT7628
	{"MT7628", FALSE},
#endif

#ifndef MT7636
	{"MT7636", FALSE},
#endif

#ifndef MT7637
	{"MT7637", FALSE},
#endif

	/* Sort by Function */
#ifndef INCLUDE_WH_EASY_SETUP
	{"WH_EZ_SETUP", FALSE},
#endif
#ifndef INCLUDE_NEW_CONNECTION_ALGO
	{"NEW_CONNECTION_ALGO", FALSE},
#endif
#ifndef INCLUDE_EZ_NETWORK_MERGE_SUPPORT
	{"EZ_NETWORK_MERGE_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_EZ_DUAL_BAND_SUPPORT
	{"EZ_DUAL_BAND_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_EZ_ROAM_SUPPORT
	{"EZ_ROAM_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_DUAL_CHIP
	{"DUAL_CHIP", FALSE},
#endif
#ifndef INCLUDE_EZ_API_SUPPORT
	{"EZ_API_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_EZ_PUSH_BW_SUPPORT
	{"EZ_PUSH_BW_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_WPS
	{"WSC_INCLUDED", FALSE},
	{"WSC_STA_SUPPORT", FALSE},
	{"WSC_AP_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_WPS_V2
	{"WSC_V2_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_IWPS
	{"IWSC_SUPPORT", FALSE},
	{"IWSC_TEST_SUPPORT", FALSE},
#endif

#ifndef INCLUDE_HS
	{"CONFIG_HOTSPOT", FALSE},
	{"CONFIG_HOTSPOT_R2", FALSE},
#endif

#ifndef INCLUDE_11MC_LOCATION_SERVICE
	{"FTM_SUPPORT", FALSE},
	{"FTM_INITIATOR", FALSE},
#endif

#ifndef INCLUDE_DOT11U_INTERWORKING
	{"CONFIG_DOT11U_INTERWORKING", FALSE},
#endif

#ifndef INCLUDE_DOT11V_WNM
	{"CONFIG_DOT11V_WNM", FALSE},
#endif

#ifndef INCLUDE_MESH
	{"MESH_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_MAT
	{"MAT_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_ETH_CONVERT
	{"ETH_CONVERT_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_ADHOC_WPA2PSK
	{"ADHOC_WPA2PSK_SUPPORT", FALSE},
#endif
#ifndef INCLUDE_WAPI
	{"WAPI_SUPPORT", FALSE},
#endif /* INCLUDE_WAPI */

#ifndef INCLUDE_WOW
	{"WOW_SUPPORT", FALSE},
#endif /* INCLUDE_WOW */

#ifndef INCLUDE_ATE
	{"CONFIG_ATE", FALSE},
	{"CONFIG_QA", FALSE},
#endif /* INCLUDE_ATE */

#ifndef INCLUDE_TRACELOG_IPARP
	{"TRACELOG_IPARP", FALSE},
#endif /* INCLUDE_TRACELOG_IPARP */

#ifndef INCLUDE_TXBF
	{"TXBF_SUPPORT", FALSE},
	{"VHT_TXBF_SUPPORT", FALSE},
#endif /* INCLUDE_TXBF */

#ifndef INCLUDE_ACM
	{"WMM_ACM_SUPPORT", FALSE},
#endif /* INCLUDE_ACM */
#ifndef INCLUDE_11R_FT
	{"DOT11R_FT_SUPPORT", FALSE},
#endif /* INCLUDE_11R_FT */
#ifndef INCLUDE_CONFIG_SWMCU_SUPPORT
	{"CONFIG_SWMCU_SUPPORT", FALSE},
#endif /* INCLUDE_CONFIG_SWMCU_SUPPORT */
#ifndef INCLUDE_11K_RRM
	{"DOT11K_RRM_SUPPORT", FALSE},
#endif /* INCLUDE_11K_RRM */

#ifndef INCLUDE_11W_PMF
	{"DOT11W_PMF_SUPPORT", FALSE},
#endif /* INCLUDE_11W_PMF */

#ifndef RTMP_RF_RW_SUPPORT
	{"RTMP_RF_RW_SUPPORT", FALSE},
#endif /* RTMP_RF_RW_SUPPORT */
#ifndef INCLUDE_TDLS
	{"DOT11Z_TDLS_SUPPORT", FALSE},
#endif /* INCLUDE_TDLS */
#ifndef INCLUDE_ANT_DIVERSITY
	{"ANT_DIVERSITY_SUPPORT", FALSE},
#endif /* INCLUDE_ANT_DIVERSITY */
#ifndef INCLUDE_11V_WNM_SUPPORT
	{"DOT11V_WNM_SUPPORT", FALSE},
#endif /* INCLUDE_11V_WNM_SUPPORT // */

#ifndef INCLUDE_MT76XX_BT_COEXISTENCE_SUPPORT
	{"MT76XX_BTCOEX_SUPPORT", FALSE},
#endif /* INCLUDE_MT76XX_BT_COEXISTENCE_SUPPORT // */

#ifndef HUAWEI_ATE
	{"HUAWEI_ATE", FALSE},
#endif /* HUAWEI_ATE // */

#ifndef INCLUDE_LED_CONTROL_SUPPORT
	{"LED_CONTROL_SUPPORT", FALSE},
#endif /* INCLUDE_LED_CONTROL_SUPPORT // */

#ifndef INCLUDE_WIDI
	{"WIDI_SUPPORT", FALSE},
#endif /* INCLUDE_WIDI // */

#ifndef INCLUDE_INTEL_WFD
	{"INTEL_WFD_SUPPORT", FALSE},
#endif /* INCLUDE_INTEL_WFD // */

#ifndef INCLUDE_WFA_WFD
	{"WFA_WFD_SUPPORT", FALSE},
#endif /* INCLUDE_WFA_WFD // */

#ifndef INCLUDE_DFS
	{"DFS_SUPPORT", FALSE},
#endif /* INCLUDE_DFS // */

#ifdef INCLUDE_P2P
#ifndef CHIPSET_RBUS
#ifdef MODE_APSTA
	{"WDS_SUPPORT", FALSE},
#endif
#endif
#endif /* INCLUDE_P2P // */

#ifndef INCLUDE_P2P
	{"P2P_SUPPORT", FALSE},
	{"P2P_APCLI_SUPPORT", FALSE},
#endif /* INCLUDE_P2P // */

#ifndef INCLUDE_WFD
	{"WFD_SUPPORT", FALSE},
#endif /* INCLUDE_WFD // */

#ifndef INCLUDE_CSO_SUPPORT
	{"CONFIG_CSO_SUPPORT", FALSE},
#endif /* INCLUDE_CSO_SUPPORT // */

#ifndef INCLUDE_TSO_SUPPORT
	{"CONFIG_TSO_SUPPORT", FALSE},
#endif /* INCLUDE_TSO_SUPPORT // */

#ifndef IQ_CAL_SUPPORT
	{"IQ_CAL_SUPPORT", FALSE},
#endif /* IQ_CAL_SUPPORT // */

#ifndef RTMP_FREQ_CALIBRATION_SUPPORT
	{"RTMP_FREQ_CALIBRATION_SUPPORT", FALSE},
#endif /* RTMP_FREQ_CALIBRATION_SUPPORT // */

#ifndef INCLUDE_SNIFFER
	{"CONFIG_SNIFFER_SUPPORT", FALSE},
#endif /* INCLUDE_SNIFFER // */

#ifndef VCORECAL_SUPPORT
	{"VCORECAL_SUPPORT", FALSE},
#endif /* VCORECAL_SUPPORT // */

#ifndef SPECIFIC_BCN_BUF_SUPPORT
	{"SPECIFIC_BCN_BUF_SUPPORT", FALSE},
#endif /* SPECIFIC_BCN_BUF_SUPPORT // */

#ifndef INCLUDE_SMART_ANTENNA
	{"SMART_ANTENNA", FALSE},
#endif /* INCLUDE_SMART_ANTENNA // */

#ifdef INCLUDE_BAND_STEERING
	{"BNDSTRG_DAEMON", TRUE},
#endif /* INCLUDE_BAND_STEERING // */

#ifndef INCLUDE_MAC_REPEATER_SUPPORT
	{"MAC_REPEATER_SUPPORT", FALSE},
#endif /* INCLUDE_MAC_REPEATER_SUPPORT // */

#ifndef INCLUDE_FLASH
	{"RTMP_FLASH_SUPPORT", FALSE},
#endif /* INCLUDE_FLASH // */

#ifndef RTMP_EFUSE_SUPPORT
	{"RTMP_EFUSE_SUPPORT", FALSE},
#endif

#ifndef REDUCE_TCP_ACK_SUPPORT
	{"REDUCE_TCP_ACK_SUPPORT", FALSE},
#endif /* REDUCE_TCP_ACK_SUPPORT */

#ifndef INCLUDE_MWDS
	{"MWDS", FALSE},
	{"ROUTING_TAB_SUPPORT", FALSE},
#endif // INCLUDE_MWDS //

#ifndef INCLUDE_WH_EVENT_NOTIFIER
	{"WH_EVENT_NOTIFIER", FALSE},
#endif // INCLUDE_WH_EVENT_NOTIFIER  //

#ifndef INCLUDE_AIR_MONITOR
	{"AIR_MONITOR", FALSE},
#endif // INCLUDE_AIR_MONITOR  //

	/* Sort by mcu */
#ifndef INCLUDE_M8051_SUPPORT
	{"CONFIG_M8051_SUPPORT", FALSE},
#endif

#ifndef INCLUDE_ANDES_SUPPORT
	{"CONFIG_ANDES_SUPPORT", FALSE},
#endif

	/* Sort by company */
#ifndef INCLUDE_SAMSUNG_SUPPORT
	{"DPA_S", FALSE},
#endif

#ifndef INCLUDE_TOSHIBA_SUPPORT
	{"DPA_T", FALSE},
#endif
#ifndef INCLUDE_NTGR_SUPPORT
	{"VENDOR_FEATURE5_SUPPORT", FALSE},
#endif
	{"BRCM_256QAM", FALSE},

};

static struct _RTDefineTag FileList[] = {
	{".c", TRUE},
	{".h", TRUE},
	{".mk", TRUE},
	{".4", TRUE},
	{".6", TRUE},
	{".util", TRUE},
	{".netif", TRUE},
#ifdef MT_MAC
	{".mt_wifi_ap", TRUE},
	{".mt_wifi_sta", TRUE},
#endif

};

void fnCommStrip(char *pBuildDirectory, char *pReleasePath)
{
	FILE *ConfigFile;
	char Command[255], Line[2000], ReleaseEmbeddedPath[255];
	int index;
	/* Create Yacc config file */
	ConfigFile = fopen(YACC_CONFIG_FILE, "w+");

	if (ConfigFile == NULL) {
		printf("Error: create config file failure");
		return;
	}

	strncpy(ReleaseEmbeddedPath, pReleasePath, 255);
	strcat(ReleaseEmbeddedPath, "embedded");
	sprintf(Line, "SRC_ROOT_DIR = %s/\n", pBuildDirectory);
	fwrite(Line, 1, strlen(Line), ConfigFile);
	sprintf(Line, "OUTPUT_DIR = %s\n", pReleasePath);
	fwrite(Line, 1, strlen(Line), ConfigFile);
	sprintf(Line, "DEFINE_FLAGS = ");

	for (index = 0; index < sizeof(DefineTagList) / sizeof(struct _RTDefineTag); index++) {
		if (DefineTagList[index].IsDEF == TRUE)
			sprintf(Line, "%s %s", Line, DefineTagList[index].DefineTag);
	}

	sprintf(Line, "%s\n", Line);
	fwrite(Line, 1, strlen(Line), ConfigFile);
	sprintf(Line, "UNDEF_FLAGS = ");

	for (index = 0; index < sizeof(DefineTagList) / sizeof(struct _RTDefineTag); index++) {
		if (DefineTagList[index].IsDEF == FALSE)
			sprintf(Line, "%s %s", Line, DefineTagList[index].DefineTag);
	}

	sprintf(Line, "%s\n", Line);
	fwrite(Line, 1, strlen(Line), ConfigFile);
	sprintf(Line, "IFDEF_REMOVE = y\n");
	fwrite(Line, 1, strlen(Line), ConfigFile);
	sprintf(Line, "EVALUATE_NUM = y\n");
	fwrite(Line, 1, strlen(Line), ConfigFile);
	sprintf(Line, "FILTER_SUFFIX = ");

	for (index = 0; index < sizeof(FileList) / sizeof(struct _RTDefineTag); index++) {
		if (FileList[index].IsDEF == TRUE)
			sprintf(Line, "%s %s", Line, FileList[index].DefineTag);
	}

	sprintf(Line, "%s\n", Line);
	fwrite(Line, 1, strlen(Line), ConfigFile);
	fclose(ConfigFile);
#ifdef ECOS
	sprintf(Command, "mv %s/embedded/os/ecos/Makefile %s/embedded/os/ecos/Makefile.6", pBuildDirectory, pBuildDirectory);
	system(Command);
#endif /* ECOS */
	/* Execute Yacc */
	sprintf(Command, "mkdir -p %s", pReleasePath);
	system(Command);
	sprintf(Command, "striptool/parser < %s", YACC_CONFIG_FILE);
	system(Command);
#ifdef ECOS
	sprintf(Command, "mv %s/os/ecos/Makefile.6 %s/os/ecos/Makefile", ReleaseEmbeddedPath, ReleaseEmbeddedPath);
	system(Command);
#endif /* ECOS */
#if 1
	FILE *pReadFile, *pWriteFile;
	char ReadFileName[255], WriteFileName[255];
	char *ReadLine = NULL;
	size_t result, len;
	/* Handle Special Tags - Makefile */
	sprintf(Command, "mv %s/Makefile %s/Makefile.old", ReleaseEmbeddedPath, ReleaseEmbeddedPath);
	system(Command);
	sprintf(ReadFileName, "%s/Makefile.old", ReleaseEmbeddedPath);
	sprintf(WriteFileName, "%s/Makefile", ReleaseEmbeddedPath);
	pReadFile = fopen(ReadFileName, "r");
	pWriteFile = fopen(WriteFileName, "w+");

	if ((pReadFile != NULL) && (pWriteFile != NULL)) {
		fseek(pReadFile, 0, SEEK_END);
		rewind(pReadFile);

		while ((result = getline(&ReadLine, &len, pReadFile)) != -1) {
			if (!(((strlen(ReadLine) >= 5) && (memcmp(ReadLine, "#MODE", 5) == 0))
				  || ((strlen(ReadLine) >= 7) && (memcmp(ReadLine, "#TARTET", 7) == 0))
				  || ((strlen(ReadLine) >= 8) && (memcmp(ReadLine, "#CHIPSET", 8) == 0))))
				fwrite(ReadLine, 1, strlen(ReadLine), pWriteFile);
		}

		fclose(pReadFile);
		fclose(pWriteFile);
	}

	sprintf(Command, "rm -Rf %s/Makefile.old", ReleaseEmbeddedPath);
	system(Command);
	/* Handle Special Tags - os/linuc/config.mk */
	sprintf(Command, "mv %s%s %s%s.old", pReleasePath, CONFIG_MK, pReleasePath, CONFIG_MK);
	system(Command);
	sprintf(ReadFileName, "%s%s.old", pReleasePath, CONFIG_MK);
	sprintf(WriteFileName, "%s%s", pReleasePath, CONFIG_MK);
	pReadFile = fopen(ReadFileName, "r");
	pWriteFile = fopen(WriteFileName, "w+");

	if ((pReadFile != NULL) && (pWriteFile != NULL)) {
		fseek(pReadFile, 0, SEEK_END);
		rewind(pReadFile);

		while ((result = getline(&ReadLine, &len, pReadFile)) != -1) {
			if (!(((strlen(ReadLine) >= 5) && (memcmp(ReadLine, "#ifdef", 5) == 0))
				  || ((strlen(ReadLine) >= 5) && (memcmp(ReadLine, "#endif", 5) == 0))))
				fwrite(ReadLine, 1, strlen(ReadLine), pWriteFile);
		}

		fclose(pReadFile);
		fclose(pWriteFile);
	}

	sprintf(Command, "rm -Rf %s%s.old", pReleasePath, CONFIG_MK);
	system(Command);
#endif
}



