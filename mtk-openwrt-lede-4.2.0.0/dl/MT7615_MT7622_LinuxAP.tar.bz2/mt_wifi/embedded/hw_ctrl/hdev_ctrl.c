/*
 ***************************************************************************
 * MediaTek Inc.
 *
 * All rights reserved. source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attemp
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek, Inc. is obtained.
 ***************************************************************************

	Module Name:
	hdev_ctrl.c
*/
#include	"rt_config.h"
#include "hdev/hdev.h"

/*
* local function
*/
#ifdef DBDC_MODE
static VOID hcGetBandTypeName(UCHAR Type, UCHAR *Str)
{
	switch (Type) {
	case DBDC_TYPE_WMM:
		sprintf(Str, "%s", "WMM");
		break;

	case DBDC_TYPE_MGMT:
		sprintf(Str, "%s", "MGMT");
		break;

	case DBDC_TYPE_BSS:
		sprintf(Str, "%s", "BSS");
		break;

	case DBDC_TYPE_MBSS:
		sprintf(Str, "%s", "MBSS");
		break;

	case DBDC_TYPE_REPEATER:
		sprintf(Str, "%s", "REPEATER");
		break;

	case DBDC_TYPE_MU:
		sprintf(Str, "%s", "MU");
		break;

	case DBDC_TYPE_BF:
		sprintf(Str, "%s", "BF");
		break;

	case DBDC_TYPE_PTA:
		sprintf(Str, "%s", "PTA");
		break;
	}
}
#endif

/*
 *
*/
/*Only this function can use pAd*/
INT32 HcCfgInit(RTMP_ADAPTER *pAd)
{
	HD_CFG  *pHdevCfg = NULL;
	UINT32  ret;

	ret  =  os_alloc_mem(NULL, (UCHAR **)&pHdevCfg, sizeof(HD_CFG));

	if (pHdevCfg == NULL) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
				 ("%s(): Allocate Hardware device Configure  fail!!\n", __func__));
		return -1;
	}

	os_zero_mem(pHdevCfg, sizeof(HD_CFG));
	pHdevCfg->priv  = (VOID *)pAd;
	/*temporal will replace pAd->ChipCap,ChipOp*/
	os_move_mem(&pHdevCfg->chipCap, &pAd->chipCap, sizeof(RTMP_CHIP_CAP));
	os_move_mem(&pHdevCfg->ChipOps, &pAd->chipOps, sizeof(RTMP_CHIP_OP));
	/*initial hardware resource*/
	HdevHwResourceInit(pHdevCfg);
	pAd->pHdevCfg = (VOID *)pHdevCfg;
	return 0;
}


/*
 *
*/
VOID HcCfgExit(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdevCfg = (HD_CFG *) pAd->pHdevCfg;
	/*exist hw resource*/
	HdevHwResourceExit(pHdevCfg);
	/*exist hdevcfg*/
	pAd->pHdevCfg = NULL;
	os_free_mem(pHdevCfg);
}


/*
 *
*/
VOID HcDevExit(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdevCfg = (HD_CFG *) pAd->pHdevCfg;
	UCHAR i;
	HD_RESOURCE_CFG *pHwResourceCfg = &pHdevCfg->HwResourceCfg;

	for (i = 0; i < pHwResourceCfg->concurrent_bands; i++)
		HdevExit(pHdevCfg, i);
}

/*
*
*/
INT32 HcAcquireRadioForWdev(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	INT32 ret = HC_STATUS_OK;
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_DEV *pHdev = NULL;
	HD_DEV_OBJ *pObj = wdev->pHObj;

	pHdev = RcAcquiredBandForObj(pHdCfg, pObj, wdev->wdev_idx, wdev->PhyMode, wdev->channel, wdev->wdev_type);

	/*correct wdev configure, if configure is not sync with hdev */
	if (!wmode_band_equal(wdev->PhyMode, RcGetPhyMode(pHdev))) {
		wdev->PhyMode = RcGetPhyMode(pHdev);
		wdev->channel = RcGetChannel(pHdev);
	}

	/*temporal set, will be repaced by HcGetOmacIdx*/
	wdev->OmacIdx = pObj->OmacIdx;
	/*re-init operation*/
	wlan_operate_init(wdev);
	return ret;
}


/*
*
*/
INT32 HcReleaseRadioForWdev(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	INT32 ret = 0;
	HD_CFG *pHdCfg = pAd->pHdevCfg;
	HD_DEV_OBJ *pObj = wdev->pHObj;

	OS_SPIN_LOCK(&pObj->RefCntLock);

	if (pObj->RefCnt > 0) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_OFF,
				 ("%s(): there are other link reference the Obj\n", __func__));
		OS_SPIN_UNLOCK(&pObj->RefCntLock);
		return ret;
	}

	OS_SPIN_UNLOCK(&pObj->RefCntLock);
	RcReleaseBandForObj(pHdCfg, pObj);
	return ret;
}



/*
*
*/
UCHAR HcGetBandByWdev(struct wifi_dev *wdev)
{
	UCHAR BandIdx = 0;
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (hdev_obj_state_ready(pObj))
		BandIdx = RcGetBandIdx(pObj->pHdev);
	else
		BandIdx = 0;

	return BandIdx;
}


/*
*
*/
VOID HcSetRadioCurStatByWdev(struct wifi_dev *wdev, PHY_STATUS CurStat)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (hdev_obj_state_ready(pObj))
		RcSetRadioCurStat(pObj->pHdev, CurStat);
	else
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): obj is not ready!!\n", __func__));
}

/*
*
*/
VOID HcSetRadioCurStatByChannel(RTMP_ADAPTER *pAd, UCHAR Channel, PHY_STATUS CurStat)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_DEV *pHdev = NULL;

	pHdev = RcGetHdevByChannel(pHdCfg, Channel);

	if (!pHdev) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): no hdev parking on channel:%d !!!\n",
				 __func__, Channel));
		return;
	}

	RcSetRadioCurStat(pHdev, CurStat);
}

/*
*
*/
VOID HcSetAllSupportedBandsRadioOff(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResourceCfg =  &pHdCfg->HwResourceCfg;
	HD_DEV *pHdev = NULL;
	UCHAR i;

	for (i = 0; i < pHwResourceCfg->concurrent_bands; i++) {
		pHdev = &pHdCfg->Hdev[i];
		pHdev->pRadioCtrl->CurStat = PHY_RADIOOFF;
	}
}


/*
*
*/
VOID HcSetAllSupportedBandsRadioOn(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResourceCfg =  &pHdCfg->HwResourceCfg;
	HD_DEV *pHdev = NULL;
	UCHAR i;

	for (i = 0; i < pHwResourceCfg->concurrent_bands; i++) {
		pHdev = &pHdCfg->Hdev[i];
		pHdev->pRadioCtrl->CurStat = PHY_INUSE;
	}
}

/*
*
*/
BOOLEAN IsHcRadioCurStatOffByWdev(struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev_idx %d pObj is not ready, return TRUE !!!\n",
			__func__, wdev->wdev_idx));
		return TRUE;
	}

	if (RcGetRadioCurStat(pObj->pHdev) == PHY_RADIOOFF)
		return TRUE;
	else
		return FALSE;
}


/*
*
*/
BOOLEAN IsHcRadioCurStatOffByChannel(RTMP_ADAPTER *pAd, UCHAR Channel)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_DEV *pHdev = NULL;

	pHdev = RcGetHdevByChannel(pHdCfg, Channel);

	if (!pHdev) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s(): no hdev parking on channel:%d!!!\n",
				 __func__, Channel));
		return TRUE;
	}

	if (RcGetRadioCurStat(pHdev) == PHY_RADIOOFF)
		return TRUE;
	else
		return FALSE;
}


/*
*
*/
BOOLEAN IsHcAllSupportedBandsRadioOff(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResourceCfg =  &pHdCfg->HwResourceCfg;
	HD_DEV *pHdev = NULL;
	UCHAR i;
	BOOLEAN AllSupportedBandsRadioOff = TRUE;

	for (i = 0; i < pHwResourceCfg->concurrent_bands; i++) {
		pHdev = &pHdCfg->Hdev[i];

		if ((pHdev->pRadioCtrl->CurStat == PHY_INUSE) && (pHdev->pRadioCtrl->CurStat != PHY_RADIOOFF)) {
			AllSupportedBandsRadioOff = FALSE;
			break;
		}
	}

	return AllSupportedBandsRadioOff;
}

#ifdef GREENAP_SUPPORT
/*
*
*/
VOID HcSetGreenAPActiveByBand(RTMP_ADAPTER *pAd, UCHAR BandIdx, BOOLEAN bGreenAPActive)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_DEV *pHdev = NULL;

	if (!pHdCfg)
		return;

	pHdev = &pHdCfg->Hdev[BandIdx];

	if (!pHdev)
		return;

	pHdev->pRadioCtrl->bGreenAPActive = bGreenAPActive;
}


/*
*
*/
BOOLEAN IsHcGreenAPActiveByBand(RTMP_ADAPTER *pAd, UCHAR BandIdx)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_DEV *pHdev = NULL;

	if (!pHdCfg)
		return FALSE;

	pHdev = &pHdCfg->Hdev[BandIdx];

	if (!pHdev)
		return FALSE;

	return pHdev->pRadioCtrl->bGreenAPActive;
}


/*
*
*/
BOOLEAN IsHcGreenAPActiveByWdev(struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;
	HD_DEV *pHdev = NULL;

	if (!hdev_obj_state_ready(pObj))
		return FALSE;

	pHdev = pObj->pHdev;

	return pHdev->pRadioCtrl->bGreenAPActive;
}
#endif /* GREENAP_SUPPORT */

/*
*
*/
UCHAR HcGetChannelByBf(RTMP_ADAPTER *pAd)
{
	HD_DEV *pHdev = RcGetBandIdxByBf(pAd->pHdevCfg);

	if (pHdev == NULL) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s(): no hdev can support beamform!\n", __func__));
		return 0;
	}

	return pHdev->pRadioCtrl->Channel;
}


/*
*
*/
BOOLEAN HcIsBfCapSupport(struct wifi_dev *wdev)
{
	if (!hdev_obj_state_ready(wdev->pHObj))
		return FALSE;

	return RcIsBfCapSupport(wdev->pHObj);
}



#ifdef MAC_REPEATER_SUPPORT
/*
*
*/
INT32 HcAddRepeaterEntry(struct wifi_dev *wdev, UINT32 ReptIdx)
{
	INT32 ret = 0;
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return HC_STATUS_FAIL;
	}

	/*Acquire Repeater OMACIdx*/
	OcAddRepeaterEntry(pObj, ReptIdx);
	RcUpdateRepeaterEntry(pObj->pHdev, ReptIdx);
	return ret;
}


/*
*
*/
INT32 HcDelRepeaterEntry(struct wifi_dev *wdev, UINT32 ReptIdx)
{
	INT32 ret = 0;
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return HC_STATUS_FAIL;
	}

	/*Acquire Repeater OMACIdx*/
	OcDelRepeaterEntry(pObj, ReptIdx);
	return ret;
}


/*
*
*/
UCHAR HcGetRepeaterOmac(RTMP_ADAPTER *pAd, MAC_TABLE_ENTRY *pEntry)
{
	REPEATER_CLIENT_ENTRY *pReptEntry = NULL;
	HD_REPT_ENRTY *pHReptEntry = NULL;
	UCHAR ReptOmacIdx = 0xff;

	pReptEntry = RTMPLookupRepeaterCliEntry(
					 pAd,
					 FALSE,
					 pEntry->ReptCliAddr,
					 TRUE);

	if (pReptEntry) {
		pHReptEntry = OcGetRepeaterEntry(pReptEntry->wdev->pHObj, pReptEntry->MatchLinkIdx);

		if (pHReptEntry)
			ReptOmacIdx = pHReptEntry->ReptOmacIdx;
	}

	MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE,
			 ("%s(): Get ReptOmacIdx: %d!\n", __func__, ReptOmacIdx));
	return ReptOmacIdx;
}
#endif /*#MAC_REPEATER_SUPPORT*/


/*
*
*/
INT32 HcRadioInit(RTMP_ADAPTER *pAd, UCHAR RfIC, UCHAR DbdcMode)
{
	INT32 ret = 0;
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;

	RcRadioInit(pHdCfg, RfIC, DbdcMode);
	return ret;
}

/*
*
*/
INT32 HcUpdateCsaCntByChannel(RTMP_ADAPTER *pAd, UCHAR Channel)
{
	INT32 ret = 0;
	HD_DEV *pHdev = NULL;
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_DEV_OBJ *pObj;
	struct wifi_dev *wdev;

	pHdev = RcGetHdevByChannel(pHdCfg, Channel);
	if (!pHdev) {
		MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s(): Update Channel %d faild, not support this RF\n",
				  __func__, Channel));
		return -1;
	}

	DlListForEach(pObj, &pHdev->DevObjList, struct _HD_DEV_OBJ, list) {
		wdev = pAd->wdev_list[pObj->Idx];

		if (pAd->Dot11_H.RDMode != RD_SILENCE_MODE) {
			pAd->Dot11_H.wdev_count++;
			wdev->csa_count = pAd->Dot11_H.CSPeriod;
			UpdateBeaconHandler(pAd, wdev, BCN_UPDATE_IE_CHG);
		}
	}
	return ret;
}


#ifdef DBDC_MODE
/*
*
*/
VOID HcShowBandInfo(RTMP_ADAPTER *pAd)
{
	UINT32 i;
	BCTRL_INFO_T BctrlInfo;
	BCTRL_ENTRY_T *pEntry = NULL;
	CHAR TempStr[16] = "";

	os_zero_mem(&BctrlInfo, sizeof(BCTRL_INFO_T));
	AsicGetDbdcCtrl(pAd, &BctrlInfo);
	MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\tDbdcEnable: %d\n", BctrlInfo.DBDCEnable));

	for (i = 0; i < BctrlInfo.TotalNum; i++) {
		pEntry = &BctrlInfo.BctrlEntries[i];
		hcGetBandTypeName(pEntry->Type, TempStr);

		if (pEntry->Type != DBDC_TYPE_MBSS)
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\t(%s,%d): Band %d\n", TempStr, pEntry->Index, pEntry->BandIdx));
		else
			MTWF_LOG(DBG_CAT_ALL, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\t(%s,0-%d): Band %d\n", TempStr, pEntry->Index+1, pEntry->BandIdx));
	}
}
#endif

#ifdef GREENAP_SUPPORT
/*
 *
 */
VOID HcShowGreenAPInfo(RTMP_ADAPTER *pAd)
{
	struct greenap_ctrl *greenap = &pAd->ApCfg.greenap;

	greenap_show(pAd, greenap);
}
#endif /* GREENAP_SUPPORT */


/*
*
*/
void hc_show_edca_info(struct _RTMP_ADAPTER *ad)
{
	struct _HD_CFG *hd_cfg = (HD_CFG *) ad->pHdevCfg;

	WcShowEdca(hd_cfg);
}

/*
*
*/
void hc_show_radio_info(struct _RTMP_ADAPTER *ad)
{
	struct _HD_CFG *hd_cfg = (HD_CFG *) ad->pHdevCfg;

	HdevCfgShow(hd_cfg);
}

/*
*
*/
void hc_show_hdev_obj(struct wifi_dev *wdev)
{
	if (!hdev_obj_state_ready(wdev->pHObj))
		return;

	HdevObjShow(wdev->pHObj);
}

/*
*
*/
VOID HcAcquiredEdca(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, EDCA_PARM *pEdca)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return;
	}
	WcAcquiredEdca(pObj, pEdca);
}



/*
*
*/
VOID HcReleaseEdca(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return;
	}
	WcReleaseEdca(pObj);
}


/*
*
*/
VOID HcSetEdca(struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
				 ("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return;
	}
	WcSetEdca(pObj);
}


/*
*
*/
UCHAR HcGetOmacIdx(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return 0xff;
	}
	return pObj->OmacIdx;
}



/*
*  Need refine
*/


/*
* Only temporal usage, should remove when cmm_asic_xxx.c is not apply pAd
*/

UCHAR  HcGetChannelByRf(RTMP_ADAPTER *pAd, UCHAR RfIC)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResource = &pHdCfg->HwResourceCfg;
	UCHAR i;

	for (i = 0; i < pHwResource->concurrent_bands; i++) {
		if (pHwResource->PhyCtrl[i].rf_band_cap & RfIC)
			return pHwResource->PhyCtrl[i].RadioCtrl.Channel;
	}

	return 0;
}

/*
* for Single Band Usage
*/
UCHAR  HcGetRadioChannel(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResource = &pHdCfg->HwResourceCfg;

	return pHwResource->PhyCtrl[0].RadioCtrl.Channel;
}

/*
*
*/
UCHAR HcGetRadioPhyMode(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResource = &pHdCfg->HwResourceCfg;

	return pHwResource->PhyCtrl[0].RadioCtrl.PhyMode;
}

/*
*
*/
UCHAR HcGetRadioRfIC(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;

	return pHdCfg->HwResourceCfg.PhyCtrl[0].rf_band_cap;
}

/*
*
*/
BOOLEAN  HcIsRfSupport(RTMP_ADAPTER *pAd, UCHAR RfIC)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResource = &pHdCfg->HwResourceCfg;
	UCHAR i;

	for (i = 0; i < pHwResource->concurrent_bands; i++) {
		if (pHwResource->PhyCtrl[i].rf_band_cap & RfIC)
			return TRUE;
	}

	return FALSE;
}


/*
*
*/
BOOLEAN  HcIsRfRun(RTMP_ADAPTER *pAd, UCHAR RfIC)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResource = &pHdCfg->HwResourceCfg;
	HD_DEV *pHdev;
	UCHAR i;

	for (i = 0; i < pHwResource->concurrent_bands; i++) {
		pHdev = &pHdCfg->Hdev[i];

		if (WMODE_CAP_2G(pHdev->pRadioCtrl->PhyMode) && (RfIC & RFIC_24GHZ))
			return TRUE;
		else if (WMODE_CAP_5G(pHdev->pRadioCtrl->PhyMode) && (RfIC & RFIC_5GHZ))
			return TRUE;
	}

	return FALSE;
}



#ifdef CONFIG_AP_SUPPORT
#ifdef AP_QLOAD_SUPPORT
/*
*
*/
QLOAD_CTRL *HcGetQloadCtrlByRf(RTMP_ADAPTER *pAd, UINT32 RfIC)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResource = &pHdCfg->HwResourceCfg;
	UCHAR i;

	for (i = 0; i < pHwResource->concurrent_bands; i++) {
		if (pHwResource->PhyCtrl[i].rf_band_cap & RfIC)
			return &pHwResource->PhyCtrl[i].QloadCtrl;
	}

	return 0;
}


/*
*
*/
QLOAD_CTRL *HcGetQloadCtrl(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResource = &pHdCfg->HwResourceCfg;

	return &pHwResource->PhyCtrl[0].QloadCtrl;
}
#endif /*AP_QLOAD_SUPPORT*/

/*
*
*/
AUTO_CH_CTRL *HcGetAutoChCtrl(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_RESOURCE_CFG *pHwResource =  &pHdCfg->HwResourceCfg;

	return &pHwResource->PhyCtrl[0].AutoChCtrl;
}
#endif /*CONFIG_AP_SUPPORT*/

/*
*
*/
UCHAR HcGetBw(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return 0xff;
	}

	return RcGetBw(pObj->pHdev);
}

/*
*
*/
UINT32 HcGetMgmtQueueIdx(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, enum PACKET_TYPE pkt_type)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return TxQ_IDX_ALTX0;
	}

	return RcGetMgmtQueueIdx(pObj, pkt_type);
}

/*
*
*/
UINT32 HcGetBcnQueueIdx(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return TxQ_IDX_BCN0;
	}

	return RcGetBcnQueueIdx(pObj);
}


/*
*
*/
UINT32 HcGetTxRingIdx(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, enum PACKET_TYPE pkt_type, UCHAR q_idx)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return 0;
	}

	return RcGetTxRingIdx(pObj);
}



/*
*
*/
UINT32 HcGetWmmIdx(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return 0;
	}

	return RcGetWmmIdx(pObj);
}


/*
*
*/
UCHAR HcGetBandByChannel(RTMP_ADAPTER *pAd, UCHAR Channel)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	HD_DEV *pHdev = NULL;
	UCHAR BandIdx;

	pHdev = RcGetHdevByChannel(pHdCfg, Channel);

	if (!pHdev) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): no hdev parking on channel:%d!\n", __func__, Channel));
		return 0;
	}

	BandIdx = RcGetBandIdx(pHdev);
	return BandIdx;
}


/*
*
*/
EDCA_PARM *HcGetEdca(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	EDCA_PARM *pEdca = NULL;
	HD_DEV_OBJ *pObj = wdev->pHObj;
	HD_CFG *pHdCfg = pAd->pHdevCfg;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return NULL;
	}

	pEdca = WcGetWmmByIdx(pHdCfg, pObj->WmmIdx);
	return pEdca;
}


/*
*
*/
VOID HcCrossChannelCheck(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, UCHAR Channel)
{
	UCHAR PhyMode = wdev->PhyMode;
	UCHAR WChannel = wdev->channel;

	/*check channel is belong to differet band*/
	if (Channel > 14 && WChannel > 14)
		return;

	if (Channel <= 14 && WChannel <= 14)
		return;

	/*is mixed mode, change default channel and */
	if (!WMODE_5G_ONLY(PhyMode)	|| !WMODE_2G_ONLY(PhyMode)) {
		/*update wdev channel to new band*/
		wdev->channel = Channel;
		/*need change to other band*/
		HcAcquireRadioForWdev(pAd, wdev);
	}

	return;
}


/*
 * Description:
 *
 * the function will check all enabled function,
 * check the bssid num is defined,
 *
 * preserve the group key wtbl num will be used.
 * then decide the max station number could be used.
 */
UCHAR HcGetMaxStaNum(RTMP_ADAPTER *pAd)
{
	UCHAR MaxStaNum = WtcGetMaxStaNum(pAd->pHdevCfg);

	if (MaxStaNum > MAX_LEN_OF_MAC_TABLE)
		MaxStaNum = MAX_NUMBER_OF_MAC;

	return MaxStaNum;
}



UCHAR HcSetMaxStaNum(RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;
	UCHAR BssidNum = 0, MSTANum = 0;
#ifdef CONFIG_AP_SUPPORT
	BssidNum = pAd->ApCfg.BssidNum;
#endif /*CONFIG_AP_SUPPORT*/
#ifdef CONFIG_STA_SUPPORT
	MSTANum = pAd->MSTANum;
#endif
	return WtcSetMaxStaNum(pHdCfg, BssidNum, MSTANum);
}



/*
*
*/
UCHAR HcAcquireGroupKeyWcid(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return INVAILD_WCID;
	}

	wdev->tr_tb_idx = WtcAcquireGroupKeyWcid(pAd->pHdevCfg, pObj);
	return wdev->tr_tb_idx;
}


/*
*
*/
VOID HcReleaseGroupKeyWcid(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, UCHAR idx)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return;
	}

	wdev->tr_tb_idx = WtcReleaseGroupKeyWcid(pAd->pHdevCfg, pObj, idx);
}


/*
*
*/
UCHAR HcGetWcidLinkType(RTMP_ADAPTER *pAd, UCHAR Wcid)
{
	return WtcGetWcidLinkType(pAd->pHdevCfg, Wcid);
}


/*
*
*/
UCHAR HcAcquireUcastWcid(RTMP_ADAPTER *pAd, struct wifi_dev *wdev)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return INVAILD_WCID;
	}

	return WtcAcquireUcastWcid(pAd->pHdevCfg, pObj);
}


/*
*
*/
UCHAR HcReleaseUcastWcid(RTMP_ADAPTER *pAd, struct wifi_dev *wdev, UCHAR idx)
{
	HD_DEV_OBJ *pObj = wdev->pHObj;

	if (!hdev_obj_state_ready(pObj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return INVAILD_WCID;
	}

	return WtcReleaseUcastWcid(pAd->pHdevCfg, pObj, idx);
}

/*
*
*/
VOID HcWtblRecDump(RTMP_ADAPTER *pAd)
{
	WtcRecDump(pAd->pHdevCfg);
}


/*
*
*/
BOOLEAN HcIsRadioAcq(struct wifi_dev *wdev)
{
	return hdev_obj_state_ready(wdev->pHObj);
}

UCHAR HcGetAmountOfBand(struct _RTMP_ADAPTER *pAd)
{
	HD_CFG *pHdCfg = (HD_CFG *)pAd->pHdevCfg;

	return pHdCfg->HwResourceCfg.concurrent_bands;
}

static INT32 HcSuspendMSDUTx(struct _HD_DEV *hdev)
{
	INT32 ret = 0;
	struct _HD_DEV_OBJ *obj;
	struct _HD_CFG *cfg = (struct _HD_CFG *) hdev->priv;
	struct _RTMP_ADAPTER *ad = cfg->priv;
	struct wifi_dev *wdev;

	/*update all of wdev*/
	DlListForEach(obj, &hdev->DevObjList, struct _HD_DEV_OBJ, list) {
		wdev = ad->wdev_list[obj->Idx];
		RTMPSuspendMsduTransmission(wdev->sys_handle, wdev);
	}
	return ret;
}

static INT32 HcUpdateMSDUTxAllow(struct _HD_DEV *hdev)
{
	INT32 ret = 0;
	struct _HD_DEV_OBJ *obj;
	struct _HD_CFG *cfg = (struct _HD_CFG *) hdev->priv;
	struct _RTMP_ADAPTER *ad = cfg->priv;
	struct wifi_dev *wdev;

	/*update all of wdev*/
	DlListForEach(obj, &hdev->DevObjList, struct _HD_DEV_OBJ, list) {
		wdev = ad->wdev_list[obj->Idx];

		if (wdev->channel == hdev->pRadioCtrl->Channel)
			RTMPResumeMsduTransmission(wdev->sys_handle, wdev);
		else
			RTMPSuspendMsduTransmission(wdev->sys_handle, wdev);
	}
	return ret;
}

/*
*
*/
static VOID hc_radio_update(struct wifi_dev *wdev, struct radio_res *res)
{
	HD_DEV_OBJ *obj = wdev->pHObj;
	struct _HD_DEV *hdev;
	struct freq_oper *oper = res->oper;
	BOOLEAN scan = (res->reason == REASON_NORMAL_SCAN) ? TRUE:FALSE;

	if (!hdev_obj_state_ready(obj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return;
	}
	hdev = obj->pHdev;
#ifdef CONFIG_AP_SUPPORT
#ifdef AP_QLOAD_SUPPORT
	/* clear all statistics count for QBSS Load */
	QBSS_LoadStatusClear(wdev->sys_handle, oper->prim_ch);
#endif /* AP_QLOAD_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */
	HcSuspendMSDUTx(hdev);
	AsicSwitchChannel(wdev->sys_handle, hdev->Idx, oper, scan);
	AsicSetBW(wdev->sys_handle, oper->bw, hdev->Idx);
	RcUpdateRadio(hdev, oper->bw, oper->cen_ch_1, oper->cen_ch_2, oper->ext_cha);
	RcUpdateChannel(hdev, oper->prim_ch);
	/*after update channel resum tx*/
	HcUpdateMSDUTxAllow(hdev);
}

/*
*
*/
BOOLEAN hc_radio_res_request(struct wifi_dev *wdev, struct radio_res *res)
{
	HD_DEV_OBJ *obj = wdev->pHObj;
	HD_DEV *dev;
#ifdef MT_WOW_SUPPORT
	struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
#endif /*MT_WOW_SUPPORT*/

	if (!hdev_obj_state_ready(obj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return FALSE;
	}

	dev = obj->pHdev;

	if (rc_radio_equal(dev, res->oper)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): radio is equal, prim_ch=%d!\n", __func__, res->oper->prim_ch));
		return TRUE;
	}

	if (rc_radio_res_acquire(dev, res) != TRUE) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): can't acquire radio resource!\n", __func__));
		return FALSE;
	}

#ifdef MT_WOW_SUPPORT

	if (ad->WOW_Cfg.bWoWRunning) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("[%s] WoW is running, skip!\n", __func__));
		return FALSE;
	}

#endif /*MT_WOW_SUPPORT*/
	/*update to radio resouce*/
	hc_radio_update(wdev, res);
	return TRUE;
}

/*
*
*/
UCHAR hc_reset_radio(struct _RTMP_ADAPTER *ad)
{
	struct _HD_CFG *cfg = ad->pHdevCfg;
	struct _HD_DEV *hdev = NULL;
	struct freq_oper freq;
	struct _RADIO_CTRL *radio_ctrl;
	UCHAR i;

	for (i = 0 ; i < cfg->HwResourceCfg.concurrent_bands; i++) {
		os_zero_mem(&freq, sizeof(freq));
		hdev = &cfg->Hdev[i];
		radio_ctrl = hdev->pRadioCtrl;
		freq.bw = radio_ctrl->Bw;
		freq.prim_ch = radio_ctrl->Channel;
		freq.cen_ch_1 = radio_ctrl->CentralCh;
		freq.cen_ch_2 = radio_ctrl->Channel2;
		AsicSwitchChannel(ad, i, &freq, FALSE);
	}
	return TRUE;
}

/*
*
*/
VOID hc_set_rrm_init(struct wifi_dev *wdev)
{
	struct _RTMP_ADAPTER *ad = wdev->sys_handle;
	UCHAR band_idx = HcGetBandByWdev(wdev);

	AsicSetTxStream(wdev->sys_handle, ad->Antenna.field.TxPath, OPMODE_AP, TRUE, band_idx);
	AsicSetRxStream(wdev->sys_handle, ad->Antenna.field.RxPath, band_idx);
}

/*
*
*/
INT  hc_radio_query_by_wdev(struct wifi_dev *wdev, struct freq_oper *oper)
{
	struct _HD_DEV_OBJ *obj = wdev->pHObj;
	struct _HD_DEV *hdev;
	struct _RADIO_CTRL *radio;

	if (!hdev_obj_state_ready(obj)) {
		MTWF_LOG(DBG_CAT_HW, DBG_SUBCAT_ALL, DBG_LVL_ERROR,
			("%s(): wdev=%d, hobj is not ready!\n", __func__, wdev->wdev_idx));
		return HC_STATUS_FAIL;
	}

	hdev = obj->pHdev;
	radio = hdev->pRadioCtrl;
	oper->bw = radio->Bw;
	oper->cen_ch_1 = radio->CentralCh;
	oper->cen_ch_2 = radio->Channel2;
	oper->ext_cha = radio->ExtCha;
	oper->prim_ch = radio->Channel;
	oper->ht_bw = (oper->bw > BW_20) ? HT_BW_40 : HT_BW_20;
	oper->vht_bw = rf_bw_2_vht_bw(oper->bw);
	return HC_STATUS_OK;
}

/*
*
*/
INT  hc_radio_query_by_channel(struct _RTMP_ADAPTER *ad, UCHAR channel, struct freq_oper *oper)
{
	INT ret = HC_STATUS_FAIL;
	struct _HD_CFG *cfg = ad->pHdevCfg;
	struct _HD_RESOURCE_CFG *res = &cfg->HwResourceCfg;
	struct _RADIO_CTRL *radio = NULL;
	UCHAR i;

	for (i = 0 ; i < res->concurrent_bands; i++) {
		radio = &res->PhyCtrl[i].RadioCtrl;
		if (radio->Channel == channel) {
			oper->bw = radio->Bw;
			oper->cen_ch_1 = radio->CentralCh;
			oper->cen_ch_2 = radio->Channel2;
			oper->ext_cha = radio->ExtCha;
			oper->prim_ch = radio->Channel;
			oper->ht_bw = (oper->bw > BW_20) ? HT_BW_40 : HT_BW_20;
			oper->vht_bw = rf_bw_2_vht_bw(oper->bw);
			ret = HC_STATUS_OK;
			break;
		}
	}
	return ret;
}

/*
* suggest only used by phy related features, others should use hc_radio_query_by_wdev
*/
INT  hc_radio_query_by_index(struct _RTMP_ADAPTER *ad, UCHAR index, struct freq_oper *oper)
{
	INT ret = HC_STATUS_OK;
	struct _HD_CFG *cfg = ad->pHdevCfg;
	struct _HD_RESOURCE_CFG *res = &cfg->HwResourceCfg;
	struct _RADIO_CTRL *radio = NULL;

	radio = &res->PhyCtrl[index].RadioCtrl;
	oper->bw = radio->Bw;
	oper->cen_ch_1 = radio->CentralCh;
	oper->cen_ch_2 = radio->Channel2;
	oper->ext_cha = radio->ExtCha;
	oper->prim_ch = radio->Channel;
	oper->ht_bw = (oper->bw > BW_20) ? HT_BW_40 : HT_BW_20;
	oper->vht_bw = rf_bw_2_vht_bw(oper->bw);
	return ret;
}

/*
* temporally use, only query first freq_oper by rfic, not support in 5G+5G or 2G+2G case
*/
INT hc_radio_query_by_rf(struct _RTMP_ADAPTER *ad, UCHAR rfic, struct freq_oper *oper)
{
	INT ret = HC_STATUS_FAIL;
	struct _HD_CFG *cfg = ad->pHdevCfg;
	struct _HD_RESOURCE_CFG *res = &cfg->HwResourceCfg;
	struct _RADIO_CTRL *radio = NULL;
	UCHAR i;

	for (i = 0 ; i < res->concurrent_bands; i++) {
		radio = &res->PhyCtrl[i].RadioCtrl;
		if (wmode_2_rfic(radio->PhyMode) & rfic) {
			oper->bw = radio->Bw;
			oper->cen_ch_1 = radio->CentralCh;
			oper->cen_ch_2 = radio->Channel2;
			oper->ext_cha = radio->ExtCha;
			oper->prim_ch = radio->Channel;
			oper->ht_bw = (oper->bw > BW_20) ? HT_BW_40 : HT_BW_20;
			oper->vht_bw = rf_bw_2_vht_bw(oper->bw);
			ret = HC_STATUS_OK;
			break;
		}
	}
	return ret;
}

/*
*
*/
INT hc_obj_init(struct wifi_dev *wdev, INT idx)
{
	struct _RTMP_ADAPTER *ad = wdev->sys_handle;
	struct _HD_CFG *cfg = ad->pHdevCfg;

	wdev->pHObj = &cfg->HObjList[idx];
	return HC_STATUS_OK;
}

/*
*
*/
VOID hc_obj_exit(struct wifi_dev *wdev)
{
	wdev->pHObj = NULL;
}
