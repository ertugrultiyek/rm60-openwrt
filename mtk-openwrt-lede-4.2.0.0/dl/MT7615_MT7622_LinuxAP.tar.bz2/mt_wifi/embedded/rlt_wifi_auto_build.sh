if [ -d rlt_wifi ]; then
	cd rlt_wifi
	## Regenerate Firmware ##
	rm include/mcu/mt7628_firmware.h
	make build_tools CHIPSET=mt7628
	cd ../
	cp -a  rlt_wifi/rlt_wifi_ap ./
else
	exit 1
fi
