#if defined(COMPOS_TESTMODE_WIN)
#include "config.h"
#else
#include "rt_config.h"
#endif

#if defined(RTMP_USB_SUPPORT) || defined(RTMP_PCI_SUPPORT) || defined(MTK_UART_SUPPORT)
INT32 ATECheckFWROMWiFiSysOn(RTMP_ADAPTER *pAd)
{
	INT32 ntStatus = STATUS_SUCCESS;
	UINT32 loop = 0;
	UINT32 value = 0;
	/* Step 1 polling 0x81021250 to 0 */
	/* poll SW_SYN0 == 0 */
	loop = 0;

	do {
		value = MtAsicGetFwSyncValue(pAd);

		if (value == 0x0)
			break;

		os_msec_delay(1);
		loop++;
	} while (loop <= 500);

	if (loop > 500) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: 2. SW_SYN0 is not at init. state (SW_SYN0 = %d)\n", __func__, value));
		ntStatus = STATUS_UNSUCCESSFUL;
	}

	/* power on WiFi SYS*/
	MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s: 2. power on WiFi SYS\n", __func__));
	ntStatus = MtCmdPowerOnWiFiSys(pAd);

	if (ntStatus)
		ntStatus = STATUS_UNSUCCESSFUL;

	/* poll SW_SYN0 == 1*/
	loop = 0;

	do {
		value = MtAsicGetFwSyncValue(pAd);

		if (value == 0x1)
			break;

		os_msec_delay(1);
		loop++;
	} while (loop <= 500);

	if (loop > 500) {
		MTWF_LOG(DBG_CAT_FW, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: SW_SYN0 is not at init. state (SW_SYN0 = %d)\n", __func__, value));
		ntStatus = STATUS_UNSUCCESSFUL;
	}

	return ntStatus;
}
#endif

INT32 CheckFWROMWiFiSysOn(IN  RTMP_ADAPTER *pAd)
{
	INT32 ntStatus = STATUS_SUCCESS;
#ifdef RTMP_SDIO_SUPPORT
	ntStatus = SDIOCheckFWROMWiFiSysOn(pAd);
#endif
#if defined(RTMP_USB_SUPPORT) || defined(RTMP_PCI_SUPPORT) || defined(MTK_UART_SUPPORT)
	ntStatus = ATECheckFWROMWiFiSysOn(pAd);
#endif
	return ntStatus;
}
INT32 FWSwitchToROM(
	IN  RTMP_ADAPTER *pAd
)
{
	INT32		ntStatus = STATUS_SUCCESS;

	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s\n", __func__));
#ifdef COMPOS_TESTMODE_WIN		/* Linux ready in FWRAM */

	if (pAd->FWMode == FWROM)
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s: FWMode is already ROM\n", __func__));
	else if (pAd->FWMode == FWRAM)
#endif
	{
		/* Step 1 set firmware to ROM mode */
		/* ntStatus = FirmwareCommnadRestartDownloadFW(pAd); */
		/* if(ntStatus != STATUS_SUCCESS) */
		/* { */
		/* MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR,("%s, RestartDownloadFW cmd failed\n",__FUNCTION__)); */
		/* } */
		NICRestartFirmware(pAd);
		ntStatus = CheckFWROMWiFiSysOn(pAd);

		if (ntStatus != STATUS_SUCCESS)
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s, CheckFWROMWiFiSysOn  failed\n", __func__));
	}

	return ntStatus;
}
void LoopBack_Start(RTMP_ADAPTER *pAd, struct _LOOPBACK_SETTING *pSetting)
{
	NTSTATUS ntStatus = STATUS_SUCCESS;
	/* UINT16 BreakCount = 0; */
#ifdef COMPOS_TESTMODE_WIN		/* TODO::Fix the strcture */
#ifdef RTMP_USB_SUPPORT
	U3DMA_WLCFG         UDMACfg;
	UINT32				UDMACfg1;
#endif
#endif
	/* UINT32				Length = 0; */
	/* UINT32				RepeatIdx = 0; */
	UINT32				RxQ = 1;
	/* RtlCopyMemory(&pAd->LoopBackSetting, pSetting,sizeof(struct _LOOPBACK_SETTING)); */
	os_move_mem(&pAd->LbCtrl.LoopBackSetting, pSetting, sizeof(struct _LOOPBACK_SETTING));
	/* RtlZeroMemory(&pAd->LoopBackTxRaw, LOOPBACK_SIZE); */
	os_zero_mem(&pAd->LbCtrl.LoopBackTxRaw, LOOPBACK_SIZE);
	/* RtlZeroMemory(&pAd->LoopBackRxRaw, LOOPBACK_SIZE); */
	os_zero_mem(&pAd->LbCtrl.LoopBackRxRaw, LOOPBACK_SIZE);
	/* RtlZeroMemory(&pAd->LoopBackResult, sizeof(struct _LOOPBACK_RESULT)); */
	os_zero_mem(&pAd->LbCtrl.LoopBackResult, sizeof(struct _LOOPBACK_RESULT));

	if (pSetting->StartLen < sizeof(TMAC_TXD_L)) {
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_WARN, ("%s startLength(0x%x) is shorter than sizeof(TMAC_TXD_L) (0x%lx)\n", __func__, pSetting->StartLen, (ULONG)sizeof(TMAC_TXD_L)));
		return;
	}

	pAd->LbCtrl.LoopBackWaitRx = FALSE;
	pAd->LbCtrl.LoopBackRunning = TRUE;
	pAd->LbCtrl.LoopBackResult.Status = RUNNING;
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s\n", __func__));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("IsDefaultPattern	%d\n", pSetting->IsDefaultPattern));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("RepeatTimes		%u, %u\n", pSetting->RepeatTimes, pAd->LbCtrl.LoopBackSetting.RepeatTimes));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("StartLen			%d\n", pSetting->StartLen));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("StopLen			%d\n", pSetting->StopLen));
	pAd->LbCtrl.LoopBackDefaultPattern = (BOOLEAN)pSetting->IsDefaultPattern;

	if (pAd->LbCtrl.DebugMode) {
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("In LoopBack Debug Mode\n"));
		goto ATE_LPBK_DEBUG;
	}

	if (!pAd->LbCtrl.LoopBackUDMA) {
		ntStatus = FWSwitchToROM(pAd);

		if (ntStatus != STATUS_SUCCESS)
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s, Switch to ROM failed (0x%x)\n", __func__, ntStatus));

		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s FWSwitchToROM\n", __func__));
	}

#ifdef RTMP_USB_SUPPORT
	/* Step II config dma scheduler */
#ifdef COMPOS_TESTMODE_WIN		/* TODO::Fix the code in linux */

	if (pAd->LbCtrl.LoopBackUDMA)
		RTMP_IO_WRITE32(pAd, UDMA_WLCFG_0, 0xd40000);
	else {
		UINT8 Qid = 0;

		Qid = (UINT8)pSetting->BulkOutNumber;
		ntStatus = ConfigDMAScheduler(pAd, Qid);

		if (ntStatus != STATUS_SUCCESS)
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s, PowerOnWiFiSys\n", __func__));

		pAd->LbCtrl.LoopBackBulkoutNumber = GetBulkoutNumber(pAd);
		/* Step III program UDMA */
		UDMACfg1 = pSetting->RxAggPktLmt;
		RTMP_IO_WRITE32(pAd, UDMA_WLCFG_1, UDMACfg1);
		RTMP_IO_READ32(pAd, UDMA_WLCFG_0, &UDMACfg.word);
		UDMACfg.Default.WL_TX_EN = 1;
		UDMACfg.Default.WL_RX_EN = 1;
		UDMACfg.Default.WL_RX_AGG_TO = pSetting->RxAggTO;
		UDMACfg.Default.WL_RX_AGG_LMT = pSetting->RxAggLmt;
		UDMACfg.Default.WL_RX_AGG_EN = pSetting->RxAggEnable;
		RTMP_IO_WRITE32(pAd, UDMA_WLCFG_0, UDMACfg.word);
	}

	RXStartStop(pAd, START, BULKIN_PIPENUMBER_0);
	RXStartStop(pAd, START, BULKIN_PIPENUMBER_1);
	RxQ = pSetting->BulkInNumber;
#else
	ASSERT(0);	/* Not yet */
#endif
#endif

	if (!pAd->LbCtrl.LoopBackUDMA)
		MtCmdHIFLoopBackTest(pAd, 1, (UINT8)RxQ);

ATE_LPBK_DEBUG:
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("***************************************%s @#@# Rx[%d]***************************************\n", __func__, RxQ));
	/* pAd->LbCtrl.LoopBackTxThread = NULL; */
	/*
	 * ntStatus =  PsCreateSystemThread(&pAd->LbCtrl.LoopBackTxTask.hThread,
	 *								(ACCESS_MASK) 0L,
	 *								NULL,
	 *								NULL,
	 *								NULL,
	 *								LoopBack_TxThread,
	 *								pAd);
	*/
	ntStatus =  RtmpOSTaskAttach(&pAd->LbCtrl.LoopBackTxTask, LoopBack_TxThread, (ULONG)&pAd->LbCtrl.LoopBackTxTask);

	if (ntStatus != STATUS_SUCCESS)
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s, thread create fail\n", __func__));
}
void LoopBack_Stop(RTMP_ADAPTER *pAd)
{
	UINT32 BreakCount = 0;

	while (pAd->LbCtrl.LoopBackWaitRx == TRUE) {
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, @#@#BreakCount = %d\n", __func__, BreakCount));

		if (BreakCount > 100)
			break;

#ifdef COMPOS_TESTMODE_WIN
		RTMPusecDelay(300);
#else
		RtmpusecDelay(300);
#endif
		BreakCount++;
	}

	if (pAd->LbCtrl.LoopBackResult.Status == RUNNING) {
		pAd->LbCtrl.LoopBackResult.Status = PASS;
		pAd->LbCtrl.LoopBackResult.FailReason = NO_ERROR;
	}

	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("***************************************%s @#@#***************************************\n", __func__));
	pAd->LbCtrl.LoopBackRunning = FALSE;

	if (pAd->LbCtrl.DebugMode)
		goto ATE_LB_DEBUG_STOP;

#ifdef RTMP_USB_SUPPORT

	if (pAd->LbCtrl.LoopBackUDMA)
		RTMP_IO_WRITE32(pAd, UDMA_WLCFG_0, 0xc00000);
	else {
		NTSTATUS ntStatus = STATUS_SUCCESS;
		UINT32 Idx = 0;

		/* restore CR */
		if (pAd->LbCtrl.LoopBackSetting.BulkOutNumber == EPALLQID) {
			if (pAd->LbCtrl.LoopBackResult.Status == PASS) {
				for (Idx = 0; Idx < 35; Idx++) {
#ifdef COMPOS_TESTMODE_WIN		/* TODO::Unify */
					RTMP_IO_WRITE32(pAd, 0x50000540 + Idx * 4, pAd->BackupCR[Idx]);
					MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s @@BACKUP 0x50000540 + %d*4 = 0x%x\n", __func__, Idx, pAd->BackupCR[Idx]));
#else
					ASSERT(0);
#endif
				}

				ntStatus = ConfigDMAScheduler(pAd, EP8QID);
			}
		} else
			ntStatus = ConfigDMAScheduler(pAd, EP8QID);
	}

#endif

	if (!pAd->LbCtrl.LoopBackUDMA)
		MtCmdHIFLoopBackTest(pAd, 0, 0);

ATE_LB_DEBUG_STOP:
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s,\n", __func__));
}
void LoopBack_Status(RTMP_ADAPTER *pAd, struct _LOOPBACK_RESULT *pResult)
{
	os_move_mem(pResult, &pAd->LbCtrl.LoopBackResult, sizeof(struct _LOOPBACK_RESULT));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s\n", __func__));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, Status: %d\n", __func__, pAd->LbCtrl.LoopBackResult.Status));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, FailReason: %d\n", __func__, pAd->LbCtrl.LoopBackResult.FailReason));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, RxByteCount: %d\n", __func__, pAd->LbCtrl.LoopBackResult.RxByteCount));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, RxPktCount: %d\n", __func__, pAd->LbCtrl.LoopBackResult.RxPktCount));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, TxByteCount: %d\n", __func__, pAd->LbCtrl.LoopBackResult.TxByteCount));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, TxPktCount: %d\n", __func__, pAd->LbCtrl.LoopBackResult.TxPktCount));
}
void LoopBack_RawData(RTMP_ADAPTER *pAd, UINT32  *pLength, BOOLEAN IsTx, UCHAR *RawData)
{
	if (*pLength > LOOPBACK_SIZE) {
		*pLength = LOOPBACK_SIZE;
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, max length is %d\n", __func__, LOOPBACK_SIZE));
	}

	if (IsTx) {
		*pLength = pAd->LbCtrl.LoopBackTxRawLen;
		/* RtlCopyMemory(RawData, &pAd->LoopBackTxRaw,*pLength); */
		os_move_mem(RawData, &pAd->LbCtrl.LoopBackTxRaw, *pLength);
	} else {
		*pLength = pAd->LbCtrl.LoopBackRxRawLen;
		/* RtlCopyMemory(RawData, &pAd->LoopBackRxRaw,*pLength); */
		os_move_mem(RawData, &pAd->LbCtrl.LoopBackRxRaw, *pLength);
	}

	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, Length = 0x%x\n", __func__, *pLength));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, LoopBackRxRawLen = 0x%x\n", __func__, pAd->LbCtrl.LoopBackRxRawLen));
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, LoopBackTxRawLen = 0x%x\n", __func__, pAd->LbCtrl.LoopBackTxRawLen));
}
void LoopBack_ExpectRx(RTMP_ADAPTER *pAd, UINT32 Length, UINT8 *pRawData)
{
	PULONG ptr;
	UINT8	i = 0;

	if (Length > LOOPBACK_SIZE) {
		Length = LOOPBACK_SIZE;
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, max length is %d\n", __func__, LOOPBACK_SIZE));
	}

	/* (&pAd->LbCtrl.LoopBackExpectRx, pRawData, Length); */
	os_move_mem(&pAd->LbCtrl.LoopBackExpectRx, pRawData, Length);
	ptr = (PULONG)(&pAd->LbCtrl.LoopBackExpectRx);
	/* Length = ptr[0] & 0xffff; */
	pAd->LbCtrl.LoopBackExpectRxLen = Length;
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, Length = %d\n", __func__, Length));

	for (i = 0; i < 20; i++)
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("TXD(TXWI) %d 0x%08lX\n", i, *(ptr + i)));

	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s,\n", __func__));
}

void LoopBack_ExpectTx(RTMP_ADAPTER *pAd, UINT32 Length, UINT8 *pRawData)
{
	PULONG ptr;
	UINT8	i = 0;

	if (Length > LOOPBACK_SIZE) {
		Length = LOOPBACK_SIZE;
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, max length is %d\n", __func__, LOOPBACK_SIZE));
	}

	/* RtlCopyMemory(&pAd->LoopBackExpectTx, pRawData, Length); */
	os_move_mem(&pAd->LbCtrl.LoopBackExpectTx, pRawData, Length);
	ptr = (PULONG)(&pAd->LbCtrl.LoopBackExpectTx);
	/* Length = ptr[0] & 0xffff; */
	pAd->LbCtrl.LoopBackExpectTxLen = Length;
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, Length = %d\n", __func__, Length));

	for (i = 0; i < 20; i++)
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("TXD(TXWI) %d 0x%08lX\n", i, *(ptr + i)));

	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s,\n", __func__));
}

void LoopBack_Run(RTMP_ADAPTER *pAd, struct _LOOPBACK_SETTING *pSetting, UINT32 Length)
{
	if (Length > LOOPBACK_SIZE) {
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, LOOPBACK length too long\n", __func__));
		return;
	}

#ifdef RTMP_USB_SUPPORT
	USBLoopBack_Run(pAd, pSetting, Length);
#endif
#ifdef RTMP_SDIO_SUPPORT
	SDIOLoopBack_Run(pAd, pSetting, Length);
#endif
#ifdef _RTMP_PCI_SUPPORT
	PCILoopBack_Run(pAd, pSetting, Length);
#endif
#ifdef MTK_UART_SUPPORT
	UARTLoopBack_Run(pAd, pSetting, Length);
#endif
}
void LoopBack_BitTrueCheck(RTMP_ADAPTER *pAd)
{
	if (!pAd->LbCtrl.LoopBackDefaultPattern) { /* Rx compare expect Rx */
		if (pAd->LbCtrl.LoopBackExpectRxLen != pAd->LbCtrl.LoopBackRxRawLen) {
			LoopBack_Fail(pAd, BIT_TRUE_FAIL);
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### TX/RX Length not equal ####################\n", __func__));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ExpectRxLen = %d, RxRawLen = %d\n", __func__, pAd->LbCtrl.LoopBackExpectRxLen, pAd->LbCtrl.LoopBackRxRawLen));
		} else if (RTMPEqualMemory((PVOID)&pAd->LbCtrl.LoopBackExpectRx, (PVOID)&pAd->LbCtrl.LoopBackRxRaw, pAd->LbCtrl.LoopBackRxRawLen) == 0) {
			if (pAd->LbCtrl.DebugMode) {
				UINT32 j = 0;

				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("RxExpect Dump(%u): ", pAd->LbCtrl.LoopBackRxRawLen));

				for (j = 0; j < pAd->LbCtrl.LoopBackRxRawLen; j++)
					MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%02x", pAd->LbCtrl.LoopBackExpectRx[j]));

				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n"));
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("RxBackRaw Dump: "));

				for (j = 0; j < pAd->LbCtrl.LoopBackRxRawLen; j++)
					MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("%02x", pAd->LbCtrl.LoopBackRxRaw[j]));

				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_OFF, ("\n"));
			}

			LoopBack_Fail(pAd, BIT_TRUE_FAIL);
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### BIT_TRUE_FAIL ####################\n", __func__));
		} else
			pAd->LbCtrl.LoopBackResult.FailReason = NO_ERROR;
	} else { /* Rx compare Tx */
		if (pAd->LbCtrl.LoopBackTxRawLen != pAd->LbCtrl.LoopBackRxRawLen) {
			LoopBack_Fail(pAd, BIT_TRUE_FAIL);
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### TX/RX Length not equal ####################\n", __func__));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, TxRawLen = %d, RxRawLen = %d\n", __func__, pAd->LbCtrl.LoopBackTxRawLen, pAd->LbCtrl.LoopBackRxRawLen));
		} else if (RTMPEqualMemory((PVOID)&pAd->LbCtrl.LoopBackTxRaw, (PVOID)&pAd->LbCtrl.LoopBackRxRaw, pAd->LbCtrl.LoopBackTxRawLen) == 0) {
			if (pAd->LbCtrl.DebugMode) {
				UINT32 j = 0;

				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("TxExpect Dump(%u): ", pAd->LbCtrl.LoopBackTxRawLen));

				for (j = 0; j < pAd->LbCtrl.LoopBackRxRawLen; j++)
					MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%02x", pAd->LbCtrl.LoopBackTxRaw[j]));

				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("\n"));
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("RxBackRaw Dump: "));

				for (j = 0; j < pAd->LbCtrl.LoopBackRxRawLen; j++)
					MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%02x", pAd->LbCtrl.LoopBackRxRaw[j]));

				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("\n"));
			}

			LoopBack_Fail(pAd, BIT_TRUE_FAIL);
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### BIT_TRUE_FAIL ####################\n", __func__));
		} else {
			pAd->LbCtrl.LoopBackResult.FailReason = NO_ERROR;
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### BIT_TRUE OK ####################\n", __func__));
		}
	}
}

void LoopBack_Fail(RTMP_ADAPTER *pAd, enum _LOOPBACK_FAIL FailNum)
{
	if (pAd->LbCtrl.LoopBackResult.Status == RUNNING) {
		pAd->LbCtrl.LoopBackResult.FailReason = FailNum;
		pAd->LbCtrl.LoopBackResult.Status = FAIL;
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, FailReason = %d\n", __func__, FailNum));
	}
}

#ifdef COMPOS_TESTMODE_WIN
INT LoopBack_TxThread(IN OUT PVOID Context)
#else
INT LoopBack_TxThread(ULONG Context)
#endif
{
#ifdef COMPOS_TESTMODE_WIN
	RTMP_ADAPTER	*pAd = (RTMP_ADAPTER *)Context;
#else
	RTMP_OS_TASK *pTask = (RTMP_OS_TASK *)Context;
	RTMP_ADAPTER *pAd = (PRTMP_ADAPTER)RTMP_OS_TASK_DATA_GET(pTask);
#endif
	struct _LOOPBACK_SETTING *pSetting = &pAd->LbCtrl.LoopBackSetting;
	UINT32 RepeatIdx = 0;
	UINT32 Length = 0;
	UINT32 BreakCount = 0;
	UINT32 DbgCount = 0;
	/* KIRQL Irql; */
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, Repeat:%u\n", __func__, pSetting->RepeatTimes));

	if (pSetting->RepeatTimes == 0)
		pSetting->RepeatTimes = 0xffffffff;

	for (RepeatIdx = 0; RepeatIdx < pSetting->RepeatTimes ; RepeatIdx++) {
		if (pSetting->RepeatTimes == 0xffffffff)
			RepeatIdx = 0;

		for (Length = pSetting->StartLen; Length <= pSetting->StopLen; Length++) {
			while (pAd->LbCtrl.LoopBackWaitRx) {
				BreakCount++;
#ifdef COMPOS_TESTMODE_WIN
				RTMPusecDelay(50);
#else
				RtmpusecDelay(50);
#endif

				if (BreakCount > 2000) {
					MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s, no Rx come back  Stop1!!!\n", __func__));
					break;
				}

				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s, no Rx BreakCount = %d\n", __func__, BreakCount));
			}

			if (BreakCount > 2000) {
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s, no Rx come back  Stop2!!!\n", __func__));
				LoopBack_Fail(pAd, RX_TIMEOUT);
				break;
			}

			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s, Length =  %d\n", __func__, Length));
			BreakCount = 0;

			if (pAd->LbCtrl.LoopBackRunning == FALSE || pAd->LbCtrl.LoopBackResult.Status != RUNNING)
				break;

			if (!pSetting->IsDefaultPattern)
				Length = pAd->LbCtrl.LoopBackExpectTxLen;

			if (pAd->LbCtrl.LoopBackResult.Status == RUNNING) {
				/* KeAcquireSpinLock(&pAd->LoopBackLock, &Irql); */
				OS_SPIN_LOCK(&pAd->LbCtrl.LoopBackLock);
				pAd->LbCtrl.LoopBackWaitRx = TRUE;
				/* KeReleaseSpinLock(&pAd->LoopBackLock, Irql); */
				OS_SPIN_UNLOCK(&pAd->LbCtrl.LoopBackLock);
				LoopBack_Run(pAd, pSetting, Length);

				if (pAd->LbCtrl.LoopBackRunning == FALSE || pAd->LbCtrl.LoopBackResult.Status != RUNNING)
					break;
			}

#ifdef COMPOS_TESTMODE_WIN
			RTMPusecDelay(200);
#else
			RtmpusecDelay(200);
#endif
			DbgCount++;
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s, DbgCount =  %d\n", __func__, DbgCount));

			if (!pSetting->IsDefaultPattern) {
				/* use script file does not need to auto increase length */
				break;
			}
		}

		if (pAd->LbCtrl.LoopBackRunning == FALSE || pAd->LbCtrl.LoopBackResult.Status != RUNNING)
			break;
	}

	if (pAd->LbCtrl.LoopBackRunning)
		LoopBack_Stop(pAd);

	/* pAd->LbCtrl.LoopBackTxThread = NULL; */
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_INFO, ("+ + + + Control Thread Terminated + + + +\n"));
	/* DecrementIoCount(pAd); */
	/* PsTerminateSystemThread(STATUS_SUCCESS); */
	RtmpOSTaskNotifyToExit(&pAd->LbCtrl.LoopBackTxTask);
	return 0;
}

VOID LoopBack_Rx(RTMP_ADAPTER *pAd, UINT32 pktlen, UINT8 *pData)
{
	if (!pAd->LbCtrl.LoopBackRunning && !pAd->LbCtrl.LoopBackWaitRx)
		return;

	{
		UINT32 LPLength = 0;
		INT32 TotalLength = (INT32)pktlen;
		UINT8  *ptr = pData;
		EVENT_RXD EvnRxD;

		/* FwCMDRspTxD_STRUC FwCMDRspTxD; */
		if (pAd->LbCtrl.DebugMode) {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, Debug Mode, Total Len:%d\n", __func__, TotalLength));
			LPLength = pktlen;
		} else {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Driver Rx LoopBackRunning\n"));
			/* os_move_mem(&FwCMDRspTxD,ptr,sizeof(FwCMDRspTxD)); */
			os_move_mem(&EvnRxD, ptr, sizeof(EvnRxD));
			/* LPLength = FwCMDRspTxD.FwEventTxD.u2RxByteCount; */
			LPLength = EvnRxD.fw_rxd_0.field.length;

			if (LPLength > LOOPBACK_SIZE) {
				LPLength = LOOPBACK_SIZE;
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, max length is %d\n", __func__, LOOPBACK_SIZE));
			}
		}

#ifdef RTMP_USB_SUPPORT			/* Rx Agg */

		if (TotalLength > (INT32)LPLength && pAd->LbCtrl.LoopBackSetting.IsDefaultPattern && pAd->LbCtrl.LoopBackSetting.RxAggEnable) {
			INT32 padding = 4;
			UINT32 RawLength = 0;
			UINT8 *Rawptr = pAd->LbCtrl.LoopBackRxRaw;

			TotalLength += 4;

			do {
				/* os_move_mem(&FwCMDRspTxD,ptr,sizeof(FwCMDRspTxD)); */
				os_move_mem(&EvnRxD, ptr, sizeof(EvnRxD));
				/* LPLength = FwCMDRspTxD.FwEventTxD.u2RxByteCount; */
				LPLength = EvnRxD.fw_rxd_0.field.length;

				if (LPLength % 4 != 0)
					padding = 4 + 4 - (INT32)LPLength % 4;

				/* pAdapter->LoopBackResult.RxByteCount += LPLength; */
				pAd->LbCtrl.LoopBackResult.RxByteCount += LPLength;
				/* pAdapter->LoopBackResult.RxPktCount ++; */
				pAd->LbCtrl.LoopBackResult.RxPktCount++;
				os_move_mem(Rawptr, ptr, LPLength);
				TotalLength = TotalLength - (INT32)LPLength - padding;
				RawLength += LPLength;
				ptr += LPLength + padding;
				Rawptr += LPLength;
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, Total Length = %d, padding is %d\n", __func__, TotalLength, padding));
			} while (TotalLength > 0);

			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, RawLength = %d\n", __func__, RawLength));
			pAd->LbCtrl.LoopBackRxRawLen = RawLength;
		} else
#endif
		{
#ifdef COMPOS_TESTMODE_WIN	/* Windows First -4 for padding bits and then add back here,Linux(?) */

			if (!pAd->LbCtrl.LoopBackSetting.IsDefaultPattern)
				LPLength = TotalLength + 4;

#endif
			/* RtlCopyMemory(&FwCMDRspTxD,ptr,sizeof(FwCMDRspTxD)); */
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, Total Length = %d, LPLength is %d, bytecount = %d\n",
					 __func__, TotalLength, LPLength, EvnRxD.fw_rxd_0.field.length));
			/* LPLength = FwCMDRspTxD.FwEventTxD.u2RxByteCount; */
			pAd->LbCtrl.LoopBackResult.RxByteCount += LPLength;
			pAd->LbCtrl.LoopBackResult.RxPktCount++;
			os_move_mem(&pAd->LbCtrl.LoopBackRxRaw, ptr, LPLength);
			pAd->LbCtrl.LoopBackRxRawLen = LPLength;
		}

		if (pAd->LbCtrl.LoopBackUDMA == FALSE)
			LoopBack_BitTrueCheck(pAd);

		/* KeAcquireSpinLock(&pAdapter->LoopBackLock, &Irql); */
		OS_SPIN_LOCK(&pAd->LbCtrl.LoopBackLock);
		pAd->LbCtrl.LoopBackWaitRx = FALSE;
		/* KeReleaseSpinLock(&pAdapter->LoopBackLock, Irql); */
		OS_SPIN_UNLOCK(&pAd->LbCtrl.LoopBackLock);
#ifdef RTMP_USB_SUPPORT

		if (pAd->LbCtrl.LoopBackSetting.BulkOutNumber == EPALLQID)
			RTMP_OS_COMPLETE(&pAd->LbCtrl.LoopBackEvent);

#endif
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, RxPktCount = %d\n", __func__, pAd->LbCtrl.LoopBackResult.RxPktCount));
	}
}

#ifdef RTMP_USB_SUPPORT
/* this function return a value to fill in 0x50000588 for USB loopback test all bulkout endpoints */
UINT32 GetRGPageSize(RTMP_ADAPTER *pAd, UINT32 PSEBufferControl)
{
	/* read pse page size information */
	UINT32 tmp = 0x00000288;
	UINT32 value;

	RTMP_IO_READ32(pAd, PSEBufferControl, &value);

	switch (GET_PAGE_SIZE_CFG(value)) {
	case 0: /* 128 */
		tmp |= (2 << RG_PAGE_SIZE_SHFT);
		break;

	case 1: /* 256 */
		tmp |= (3 << RG_PAGE_SIZE_SHFT);
		break;

	case 2: /* 512 */
		tmp |= (4 << RG_PAGE_SIZE_SHFT);
		break;

	case 3: /* 1024 */
		tmp |= (5 << RG_PAGE_SIZE_SHFT);
		break;

	default:
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("FAIL. no match page size setting.\n"));
		ASSERT(0);
		break;
	}

	return tmp;
} /* UINT32 GetRGPageSize(RTMP_ADAPTER *pAd, UINT PSE_BC) */

void UDMA_LoopBack(RTMP_ADAPTER *pAd, BOOLEAN IsStart)
{
	if (IsStart) {
		RTMPZeroMemory(&pAd->LbCtrl.LoopBackSetting, sizeof(pAd->LbCtrl.LoopBackSetting));
		pAd->LbCtrl.LoopBackSetting.BulkInNumber = 0;
		pAd->LbCtrl.LoopBackSetting.BulkOutNumber = EP4QID;
		pAd->LbCtrl.LoopBackSetting.RepeatTimes = 0;
		pAd->LbCtrl.LoopBackSetting.IsDefaultPattern = TRUE;
		pAd->LbCtrl.LoopBackSetting.StartLen = 10240 * 5;
		pAd->LbCtrl.LoopBackSetting.StopLen = 10240 * 5;
		pAd->LbCtrl.LoopBackUDMA = TRUE;
		LoopBack_Start(pAd, &pAd->LbCtrl.LoopBackSetting);
	} else {
		LoopBack_Stop(pAd);
		pAd->LbCtrl.LoopBackUDMA = FALSE;
	}
}

UINT32 ConfigDMAScheduler(RTMP_ADAPTER *pAd, UINT8 Qid)
{
	UINT32 ntStatus = STATUS_SUCCESS;
	union _SCHEDULER_REGISTER4 SchedulerRegister4;
	UINT32 Idx = 0;

	if (Qid < EPALLQID) {
#ifdef COMPOS_TESTMODE_WIN
		ntStatus = RTMP_IO_READ32(pAd, SCH_REG4, &SchedulerRegister4.word);
#else
		RTMP_IO_READ32(pAd, SCH_REG4, (UINT32 *)&SchedulerRegister4.word);	/* TODO::Possible issue from type convert */
#endif

		if (ntStatus != STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s Read Mac Register SCH_REG4 failed\n", __func__));
			return STATUS_UNSUCCESSFUL;
		}

		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("SchedulerRegister4 = %lx\n", SchedulerRegister4.word));
		{
			SchedulerRegister4.Default.ForceQid = Qid;
			/* SchedulerRegister4.Default.ForceMode = 1; */
		}
		SchedulerRegister4.Default.BypassMode = 1;
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("2 SchedulerRegister4 = %lx\n", SchedulerRegister4.word));
		/* if(Qid == EP4QID) */
#ifdef COMPOS_TESTMODE_WIN
		ntStatus = RTMP_IO_WRITE32(pAd, SCH_REG4, SchedulerRegister4.word);
#else
		RTMP_IO_READ32(pAd, SCH_REG4, (UINT32 *)&SchedulerRegister4.word);	/* TODO::Possible issue from type convert */
#endif

		if (ntStatus != STATUS_SUCCESS) {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s Write Mac Register SCH_REG4 failed\n", __func__));
			return STATUS_UNSUCCESSFUL;
		}
	} else if (Qid == EPALLQID) { /* all bulk out */
		/* backup CR */
		for (Idx = 0; Idx < 35; Idx++) {
#ifdef COMPOS_TESTMODE_WIN
			RTMP_IO_READ32(pAd, 0x50000540 + Idx * 4, &pAd->BackupCR[Idx]);
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_ERROR, ("%s @@BACKUP 0x50000540 + %d*4 = 0x%x\n", __func__, Idx, pAd->BackupCR[Idx]));
#else
			ASSERT(0);
#endif
		}

		if (IS_MT7637(pAd)) {
			RTMP_IO_WRITE32(pAd, 0x50000500, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000504, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000508, 0x0);
			RTMP_IO_WRITE32(pAd, 0x5000050C, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000510, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000514, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000518, 0x0);
			RTMP_IO_WRITE32(pAd, 0x5000051C, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000520, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000524, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000528, 0x0);
			RTMP_IO_WRITE32(pAd, 0x5000052C, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000530, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000534, 0x0);
			RTMP_IO_WRITE32(pAd, 0x50000538, 0x0);
			RTMP_IO_WRITE32(pAd, 0x5000053C, 0x0);
		}

		RTMP_IO_WRITE32(pAd, 0x50000540, 0xe);
		RTMP_IO_WRITE32(pAd, 0x50000544, 0xe);
		RTMP_IO_WRITE32(pAd, 0x50000548, 0xe);
		RTMP_IO_WRITE32(pAd, 0x5000054c, 0xe);
		RTMP_IO_WRITE32(pAd, 0x50000550, 0xe);
		RTMP_IO_WRITE32(pAd, 0x50000554, 0x20);
		RTMP_IO_WRITE32(pAd, 0x50000558, 0x0);
		RTMP_IO_WRITE32(pAd, 0x5000055c, 0xe);
		RTMP_IO_WRITE32(pAd, 0x50000560, 0x32);
		RTMP_IO_WRITE32(pAd, 0x50000564, 0x0);
		RTMP_IO_WRITE32(pAd, 0x50000568, 0x0);
		RTMP_IO_WRITE32(pAd, 0x5000056c, 0x0);
		RTMP_IO_WRITE32(pAd, 0x50000570, 0x0);
		RTMP_IO_WRITE32(pAd, 0x50000574, 0x0);
		RTMP_IO_WRITE32(pAd, 0x50000578, 0x0);
		RTMP_IO_WRITE32(pAd, 0x5000057c, 0x0);
		RTMP_IO_WRITE32(pAd, 0x50000580, 0x2b1a096e);
		RTMP_IO_WRITE32(pAd, 0x50000584, 0x785f4d3c);

		if (IS_MT7637(pAd))
			RTMP_IO_WRITE32(pAd, 0x50000588, GetRGPageSize(pAd, MT7636_MT7637_BC));
		else {
			/* MT7636 */
			RTMP_IO_WRITE32(pAd, 0x50000588, 0x20000288);
		}

		RTMP_IO_WRITE32(pAd, 0x5000058c, 0xe);
		RTMP_IO_WRITE32(pAd, 0x50000590, 0x0);
		RTMP_IO_WRITE32(pAd, 0x50000594, 0x40);
		RTMP_IO_WRITE32(pAd, 0x50000598, 0x27a);
		RTMP_IO_WRITE32(pAd, 0x5000059c, 0xe);
		RTMP_IO_WRITE32(pAd, 0x500005a0, 0x0);
		RTMP_IO_WRITE32(pAd, 0x500005a4, 0x0);
		RTMP_IO_WRITE32(pAd, 0x500005a8, 0x0);
		RTMP_IO_WRITE32(pAd, 0x500005ac, 0x0);
		RTMP_IO_WRITE32(pAd, 0x500005b0, 0x80ff7f);
		RTMP_IO_WRITE32(pAd, 0x500005b4, 0x0);
		RTMP_IO_WRITE32(pAd, 0x500005b8, 0x0);
		RTMP_IO_WRITE32(pAd, 0x500005bc, 0x2b1a096e);
		RTMP_IO_WRITE32(pAd, 0x500005c0, 0x785f4d3c);
		RTMP_IO_WRITE32(pAd, 0x500005c4, 0xffffffff);
		RTMP_IO_WRITE32(pAd, 0x500005c8, 0x1e2);
	} else
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Qid exceed limit\n"));

	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s,\n", __func__));
	return ntStatus;
}

void USBLoopBack_Run(RTMP_ADAPTER *pAd, struct _LOOPBACK_SETTING *pSetting, UINT32 length)
{
#ifdef COMPOS_TESTMODE_WIN	/* TODO::Linux need to fix size */
	/* TX_WI_STRUC pTxWI; */
	TMAC_TXD_L TxD;
	UINT32 bulkoutpipe = 0, pipenum = 0;
	PUCHAR ptr;/* = pAd->TxBuffer[pSetting->BulkOutNumber] + sizeof(TX_WI_STRUC); */
	UINT32 count = 0;
	/* UINT32 length = pSetting->StartLen; */
	/* UINT32 Startlength = pSetting->StartLen; */
	/* UINT32 Stoplength = pSetting->StopLen; */
	UINT8 alignment = 0;
	/* LARGE_INTEGER       TimeOut1Second; */
	UINT32 TimeOut1Second = 100;
	/* TimeOut1Second.QuadPart = 0; */
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s,\n", __func__));

	/* length = 1024; */
	switch (pSetting->BulkOutNumber) {
	case EP4QID:
		bulkoutpipe = 0x02;
		pipenum = 1;
		break;

	case EP5QID:
		bulkoutpipe = 0x04;
		pipenum = 2;
		break;

	case EP6QID:
		bulkoutpipe = 0x08;
		pipenum = 3;
		break;

	case EP7QID:
		bulkoutpipe = 0x10;
		pipenum = 4;
		break;

	case EP8QID:
		bulkoutpipe = 0x01;
		pipenum = 0;
		break;

	case EP9QID:
		bulkoutpipe = 0x20;
		pipenum = 5;
		break;

	case EPALLQID:
		bulkoutpipe = 0x3f;
		/* bulkoutpipe = 0x01; */
		pipenum = 0;
		break;

	default:
		bulkoutpipe = 0;
	}

	/* Packet formation for Loopback Tx */
	if (pSetting->IsDefaultPattern) {
		/* TODO::Linux need to fix size */
		os_zero_mem(pAd->TxBuffer[pipenum], USB_BULK_BUFFER_COUNT * USB_BULK_BUFFER_SIZE);
		os_zero_mem(&TxD, sizeof(TxD));
		ptr = pAd->TxBuffer[pipenum] + sizeof(TxD);

		for (count = 0; count < length - sizeof(TxD); count++)
			ptr[count] = count % 16;

		/* set pkt content */
		/* pTxWI.P_IDX= 1; */
		TxD.TxD0.PIdx = 1;
		/* pTxWI.Q_IDX= 0; */
		TxD.TxD0.QIdx = 0;
		/* pTxWI.TXByteCount =  length; */
		TxD.TxD0.TxByteCount = length;
		/* pTxWI.FT = 1; */
		TxD.TxD1.TxDFmt = 1;
		/* pTxWI.HF = 1; */
		TxD.TxD1.HdrFmt = 1;
		os_move_mem(pAd->TxBuffer[pipenum], &TxD, sizeof(TxD));
		os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, pAd->TxBuffer[pipenum], length);
		pAd->LbCtrl.LoopBackTxRawLen = length;
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, length = %d\n", __func__, length));
	} else {
		os_move_mem(pAd->TxBuffer[pipenum], &pAd->LbCtrl.LoopBackExpectTx, LOOPBACK_SIZE);
		os_zero_mem(pAd->TxBuffer[pipenum] + length, LOOPBACK_SIZE - length);
		os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, pAd->TxBuffer[pipenum], length);
		pAd->LbCtrl.LoopBackTxRawLen = pAd->LbCtrl.LoopBackExpectTxLen;
	}

	/* Tx Aggregation only in IsDefaultPattern */
	if (pSetting->IsDefaultPattern) {
		if (pSetting->TxAggNumber > 1 && pSetting->TxAggNumber <= 16) {
			ptr = pAd->TxBuffer[pipenum] + length;

			for (count = 1; count < pSetting->TxAggNumber; count++) {
				if (length * count > USB_BULK_BUFFER_COUNT * USB_BULK_BUFFER_SIZE - 7)
					break;/* exceed size limit */

				os_move_mem(ptr, pAd->TxBuffer[pipenum], length);
				ptr += length;
			}

			length = pSetting->TxAggNumber * length;
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, Loopback agg number = %d, size = %d\n", __func__, count, length));
			/* Tx Agg need to update for Bit true check */
			os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, pAd->TxBuffer[pipenum], length);
			pAd->LbCtrl.LoopBackTxRawLen = length;
		}

		if (length % 4 != 0)
			alignment = 4 - (length % 4);
	}

	if (pSetting->BulkOutNumber == EPALLQID) {
		UINT8 idx = 0;

		for (idx = 0; idx < 6; idx++) {
			/* pAd->TxBufferLength[idx] = sizeof(TX_WI_STRUC) + length + alignment + 4 ; */
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, start tx idx = %d\n", __func__, idx));

			if (pSetting->IsDefaultPattern) {
				pAd->TxBufferLength[idx] = length + alignment + 4;
				os_move_mem(pAd->TxBuffer[idx], pAd->TxBuffer[pipenum], length + alignment + 4);
			} else if (!pSetting->IsDefaultPattern) {
				pAd->TxBufferLength[idx] = length;
				os_move_mem(pAd->TxBuffer[idx], pAd->TxBuffer[pipenum], length);
			}

			/* ptr = pAd->TxBuffer[idx] + sizeof(TX_WI_STRUC); */
			/* ptr[0] = idx; */
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, LP length = %d, alignment = %d\n", __func__, length, alignment));
			/* pAd->TxBufferLength[idx] = length + alignment + 4 ; */
			pAd->LbCtrl.LoopBackResult.LastBulkOut = pSetting->BulkOutNumber;
			pAd->LbCtrl.LoopBackResult.TxByteCount += length;/* pAd->TxBufferLength[pipenum] - 4; */

			if (pSetting->IsDefaultPattern)
				pAd->LbCtrl.LoopBackResult.TxPktCount += pSetting->TxAggNumber;
			else
				pAd->LbCtrl.LoopBackResult.TxPktCount++;

#ifdef COMPOS_TESTMODE_WIN
			/* todo: somebody modify 0x50000594 to 0x60 but I cannot find it, hardcoded here for test purpose, need to be removed. */
			RTMP_IO_WRITE32(pAd, 0x50000594, 0x40);
			StartTx(pAd, 1, 0x1 << idx);
#endif

			/* if(STATUS_SUCCESS != Event_Wait(pAd, &pAd->LbCtrl.LoopBackTxEvent[idx],TimeOut1Second)) */
			/* cannot pass UINT32 TimeOut1Second = 100; to wait_event, it will not wait.. workaround use 0 (1second instead of TimeOut1Second) */
			if (RTMP_OS_WAIT_FOR_COMPLETION_TIMEOUT(&pAd->LbCtrl.LoopBackUSBTxEvent[idx], 0) != STATUS_SUCCESS) {
				LoopBack_Fail(pAd, TX_TIMEOUT);
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### TX_TIMEOUT ####################\n", __func__));
				break;
			}

			/* if(STATUS_SUCCESS != Event_Wait(pAd, &pAd->LbCtrl.LoopBackEvent,TimeOut1Second)) */
			/* cannot pass UINT32 TimeOut1Second = 100; to wait_event, it will not wait.. workaround use 0 (1second instead of TimeOut1Second) */
			if (RTMP_OS_WAIT_FOR_COMPLETION_TIMEOUT(&pAd->LbCtrl.LoopBackEvent, 0) != STATUS_SUCCESS) {
				LoopBack_Fail(pAd, RX_TIMEOUT);
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### RX_TIMEOUT ####################\n", __func__));
				break;
			}
		}
	} else {
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, LP length = %d, alignment = %d\n", __func__, length, alignment));

		if (pSetting->IsDefaultPattern)
			pAd->TxBufferLength[pipenum] = length + alignment + 4;
		else if (!pSetting->IsDefaultPattern)
			pAd->TxBufferLength[pipenum] = length;

		pAd->LbCtrl.LoopBackResult.LastBulkOut = pSetting->BulkOutNumber;
		pAd->LbCtrl.LoopBackResult.TxByteCount += length;/* pAd->TxBufferLength[pipenum] - 4; */

		if (pSetting->IsDefaultPattern)
			pAd->LbCtrl.LoopBackResult.TxPktCount += pSetting->TxAggNumber;
		else
			pAd->LbCtrl.LoopBackResult.TxPktCount++;

#ifdef COMPOS_TESTMODE_WIN
		StartTx(pAd, 1, bulkoutpipe);
#endif

		/* if(STATUS_SUCCESS != Event_Wait(pAd, &pAd->LbCtrl.LoopBackTxEvent[pipenum],TimeOut1Second)) */
		/* if(STATUS_SUCCESS != RTMP_OS_WAIT_FOR_COMPLETION_TIMEOUT(&pAd->LbCtrl.LoopBackUSBTxEvent[pipenum], TimeOut1Second)) */
		/* cannot pass UINT32 TimeOut1Second = 100; to wait_event, it will not wait.. workaround use 0 (1second instead of TimeOut1Second) */
		if (RTMP_OS_WAIT_FOR_COMPLETION_TIMEOUT(&pAd->LbCtrl.LoopBackUSBTxEvent[pipenum], 0) != STATUS_SUCCESS) {
			LoopBack_Fail(pAd, TX_TIMEOUT);
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### TX_TIMEOUT ####################\n", __func__));
		}
	}

#else
	ASSERT(0);
#endif
}
#endif/*RTMP_USB_SUPPORT*/

#ifdef RTMP_SDIO_SUPPORT
INT32 SDIOCheckFWROMWiFiSysOn(IN  RTMP_ADAPTER   *pAd)
{
	INT32	ntStatus = STATUS_SUCCESS;
	UINT32 Value = 0;
	UINT32 counter = 0;

	RTMP_SDIO_READ32(pAd, WCIR, &Value);
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): WCIR: 0x%x Value & W_FUNC_RDY = 0x%x\n", __func__, Value, Value & W_FUNC_RDY));

	while (Value & W_FUNC_RDY) {
		RTMP_SDIO_READ32(pAd, WCIR, &Value);
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): WCIR: 0x%x\n", __func__, Value));
		counter++;

		if (counter > 100) {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("W_FUNC_RDY != .\n"));
			return STATUS_UNSUCCESSFUL;
		}

		os_msec_delay(30);/* 30ms */
	}

	counter = 0;

	while (!(0x100 & Value)) {
		RTMP_SDIO_WRITE32(pAd, WHLPCR, W_FW_OWN_REQ_CLR);
		RTMP_SDIO_READ32(pAd, WHLPCR, &Value);
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s(): Request FW-Own processing: 0x%x\n", __func__, Value));
		counter++;

		if (counter > 50) {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s:  FW-Own back Faiure\n", __func__));
			ntStatus = STATUS_UNSUCCESSFUL;
			break;
		}

		os_usec_delay(2);
	}

	return ntStatus;
}

void SDIOLoopBack_Run(RTMP_ADAPTER *pAd, struct _LOOPBACK_SETTING *pSetting, UINT32 length)
{
	UINT32 count = 0;
	/* TX_WI_STRUC pTxWI; */
	TMAC_TXD_L TxD;
	PUCHAR ptr;
	UINT8 alignment = 0;
	/* LARGE_INTEGER, TimeOut1Second; */
	UINT32 TimeOut1Second = 100;
	/* TimeOut1Second.QuadPart = 0; */
	UCHAR *TxDataBuffer = NULL;
	UINT32 *TxDataBufferLength;
	UINT32 BUF_SIZE = 0;
#ifdef COMPOS_TESTMODE_WIN
	TxDataBuffer = &pAd->TxDataBuffer;
	BUF_SIZE = BUFFER_SIZE;
	TxDataBufferLength = &pAd->TxDataBufferLength;
#else
	TxDataBuffer = pAd->ATECtrl.pate_pkt;
	BUF_SIZE = ATE_TESTPKT_LEN;
	TxDataBufferLength = &pAd->ATECtrl.TxLength;
#endif

	/* length = 1024; */
	if (pSetting->IsDefaultPattern) {
		os_zero_mem(TxDataBuffer, BUF_SIZE);
		os_zero_mem(&TxD, sizeof(TxD));
		ptr = &TxDataBuffer[sizeof(TxD)];

		for (count = 0; count < length - sizeof(TxD); count++)
			ptr[count] = count % 16;

		/* set pkt content */
		/* pTxWI.P_IDX= 1; */
		TxD.TxD0.PIdx = 1;
		/* pTxWI.Q_IDX= 0; */
		TxD.TxD0.QIdx = 0;
		/* pTxWI.TXByteCount =  length; */
		TxD.TxD0.TxByteCount = length;
		/* pTxWI.FT = 1; */
		TxD.TxD1.TxDFmt = 1;
		/* pTxWI.HF = 1; */
		TxD.TxD1.HdrFmt = 1;
		os_move_mem(TxDataBuffer, &TxD, sizeof(TxD));
		os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, TxDataBuffer, LOOPBACK_SIZE);
		pAd->LbCtrl.LoopBackTxRawLen = length;
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, length = %d\n", __func__, length));

		if (length > 32) {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("===buffer===\n"));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[3], TxDataBuffer[2], TxDataBuffer[1], TxDataBuffer[0]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[7], TxDataBuffer[6], TxDataBuffer[5], TxDataBuffer[4]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[11], TxDataBuffer[10], TxDataBuffer[9], TxDataBuffer[8]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[15], TxDataBuffer[14], TxDataBuffer[13], TxDataBuffer[12]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[19], TxDataBuffer[18], TxDataBuffer[17], TxDataBuffer[16]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[23], TxDataBuffer[22], TxDataBuffer[21], TxDataBuffer[20]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[27], TxDataBuffer[26], TxDataBuffer[25], TxDataBuffer[24]));
		}

		if (length % 4 != 0)
			alignment = 4 - (length % 4);

		/* pAd->TxDataBufferLength = length + alignment + 4 ; */
		*TxDataBufferLength = length + alignment + 4;
	} else {
		os_move_mem(TxDataBuffer, &pAd->LbCtrl.LoopBackExpectTx, LOOPBACK_SIZE);
		os_zero_mem(TxDataBuffer[length], LOOPBACK_SIZE - length);
		os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, TxDataBuffer, length);
		pAd->LbCtrl.LoopBackTxRawLen = pAd->LbCtrl.LoopBackExpectTxLen;
		/* pAd->LoopBackExpectRxLen = length; */
	}

	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, LP length = %d, alignment = %d\n", __func__, length, alignment));
	pAd->LbCtrl.LoopBackResult.TxByteCount += length;/* pAd->TxBufferLength[pipenum] - 4; */
	pAd->LbCtrl.LoopBackResult.TxPktCount++;
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, RxPktCount = %d\n", __func__, pAd->LbCtrl.LoopBackResult.RxPktCount));
#ifdef COMPOS_TESTMODE_WIN
	StartTx(pAd, 1, 0);
#endif

	/* cannot pass UINT32 TimeOut1Second = 100; to wait_event, it will not wait.. workaround use 0 (1second instead of TimeOut1Second) */
	if (RTMP_OS_WAIT_FOR_COMPLETION_TIMEOUT(&pAd->LbCtrl.LoopBackSDIOTxEvent, 0) != STATUS_SUCCESS) { /* (pAd, &pAd->LbCtrl.LoopBackSDIOTxEvent,TimeOut1Second) */
		LoopBack_Fail(pAd, TX_TIMEOUT);
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### TX_TIMEOUT ####################3\n", __func__));
	}
}
#endif/*RTMP_SDIO_SUPPORT*/
/* currently not implement PCIE loopback */
#ifdef _RTMP_PCI_SUPPORT
void PCILoopBack_Run(RTMP_ADAPTER *pAd, struct _LOOPBACK_SETTING *pSetting, UINT32 length)
{
	UINT32 count = 0;
	TMAC_TXD_L TxD;
	PUCHAR ptr;
	UINT8 alignment = 0;
	/* UINT32 TimeOut1Second = 100; */
	UCHAR *TxDataBuffer = NULL;
	UINT32 *TxDataBufferLength;
	UINT32 BUF_SIZE = 0;
#ifdef COMPOS_TESTMODE_WIN
	TxDataBuffer = pAd->TxDataBuffer;
	BUF_SIZE = BUFFER_SIZE;
	TxDataBufferLength = &pAd->TxDataBufferLength;
#else
	struct _ATE_CTRL *ate_ctrl = &(pAd->ATECtrl);

	TxDataBuffer = pAd->ATECtrl.pate_pkt;
	BUF_SIZE = ATE_TESTPKT_LEN;
	TxDataBufferLength = &pAd->ATECtrl.TxLength;
#endif

	/* length = 1024; */
	if (pSetting->IsDefaultPattern) {
		os_zero_mem(TxDataBuffer, BUF_SIZE);
		os_zero_mem(&TxD, sizeof(TxD));
		ptr = TxDataBuffer + sizeof(TxD);

		for (count = 0; count < length - sizeof(TxD); count++)
			ptr[count] = count % 16;

		/* set pkt content */
		TxD.TxD0.TxByteCount = length;
#ifndef MT7615
		TxD.TxD0.PIdx = 1;
		TxD.TxD0.QIdx = 0;
		TxD.TxD1.TxDFmt = 1;
		TxD.TxD1.HdrFmt = 1;
#endif
		os_move_mem(TxDataBuffer, &TxD, sizeof(TxD));
		os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, TxDataBuffer, LOOPBACK_SIZE);
		pAd->LbCtrl.LoopBackTxRawLen = length;
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, length = %d\n", __func__, length));

		if (length > 32) {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("===buffer===\n"));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[3], TxDataBuffer[2], TxDataBuffer[1], TxDataBuffer[0]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[7], TxDataBuffer[6], TxDataBuffer[5], TxDataBuffer[4]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[11], TxDataBuffer[10], TxDataBuffer[9], TxDataBuffer[8]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[15], TxDataBuffer[14], TxDataBuffer[13], TxDataBuffer[12]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[19], TxDataBuffer[18], TxDataBuffer[17], TxDataBuffer[16]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[23], TxDataBuffer[22], TxDataBuffer[21], TxDataBuffer[20]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[27], TxDataBuffer[26], TxDataBuffer[25], TxDataBuffer[24]));
		}

		if (length % 4 != 0)
			alignment = 4 - (length % 4);

		if (pAd->LbCtrl.DebugMode) {
			int j = 0;

			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("Tx Dump: "));

			for (j = 0; j < length; j++)
				MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%02x", TxDataBuffer[j]));

			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("\n"));
		}

		/* pAd->TxDataBufferLength = length + alignment + 4 ; */
		*TxDataBufferLength = length + alignment + 4;
	} else {
#if 0
		os_move_mem(&TxDataBuffer, &pAd->LbCtrl.LoopBackExpectTx, LOOPBACK_SIZE);
		os_zero_mem(&TxDataBuffer + length, LOOPBACK_SIZE - length);
		os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, &TxDataBuffer, length);
#else
		os_move_mem(TxDataBuffer, &pAd->LbCtrl.LoopBackExpectTx, pAd->LbCtrl.LoopBackExpectTxLen);
		os_zero_mem(TxDataBuffer + length, pAd->LbCtrl.LoopBackExpectTxLen - length);
		os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, TxDataBuffer, length);
#endif
		pAd->LbCtrl.LoopBackTxRawLen = pAd->LbCtrl.LoopBackExpectTxLen;
		/* pAd->LoopBackExpectRxLen = length; */
	}

	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, LP length = %d, alignment = %d\n", __func__, length, alignment));
	pAd->LbCtrl.LoopBackResult.TxByteCount += length;
	pAd->LbCtrl.LoopBackResult.TxPktCount++;
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, RxPktCount = %d\n", __func__, pAd->LbCtrl.LoopBackResult.RxPktCount));
#ifdef COMPOS_TESTMODE_WIN
	StartTx(pAd, 1, 0);
#else
	ate_ctrl->TxLength = length;
	MT_ATETxPkt(pAd, TESTMODE_BAND0);
#endif

	/* cannot pass UINT32 TimeOut1Second = 100; to wait_event, it will not wait.. workaround use 0 (1second instead of TimeOut1Second) */
	if (!pAd->LbCtrl.DebugMode)
		if (RTMP_OS_WAIT_FOR_COMPLETION_TIMEOUT(&pAd->LbCtrl.LoopBackPCITxEvent, 0) != STATUS_SUCCESS) {
			LoopBack_Fail(pAd, TX_TIMEOUT);
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### TX_TIMEOUT ####################3\n", __func__));
		}
}
#endif

#ifdef MTK_UART_SUPPORT
void UARTLoopBack_Run(RTMP_ADAPTER *pAd, struct _LOOPBACK_SETTING *pSetting, UINT32 length)
{
	UINT32 count = 0;
	/* TX_WI_STRUC pTxWI; */
	TMAC_TXD_L TxD;
	PUCHAR ptr;
	UINT8 alignment = 0;
	/* LARGE_INTEGER       TimeOut1Second; */
	UINT32 TimeOut1Second = 100;
	/* TimeOut1Second.QuadPart = 0; */
	UCHAR *TxDataBuffer = NULL;
	UINT32 *TxDataBufferLength;
	UINT32 BUF_SIZE = 0;
#ifdef COMPOS_TESTMODE_WIN
	TxDataBuffer = &pAd->TxDataBuffer;
	BUF_SIZE = BUFFER_SIZE;
	TxDataBufferLength = &pAd->TxDataBufferLength;
#else
	TxDataBuffer = pAd->ATECtrl.pate_pkt;
	BUF_SIZE = ATE_TESTPKT_LEN;
	TxDataBufferLength = &pAd->ATECtrl.TxLength;
#endif

	/* length = 1024; */
	if (pSetting->IsDefaultPattern) {
		os_zero_mem(TxDataBuffer, BUF_SIZE);
		os_zero_mem(&TxD, sizeof(TxD));
		ptr = &TxDataBuffer[sizeof(TxD)];

		for (count = 0; count < length - sizeof(TxD); count++)
			ptr[count] = count % 16;

		/* set pkt content */
		/* pTxWI.P_IDX= 1; */
		TxD.TxD0.PIdx = 1;
		/* pTxWI.Q_IDX= 0; */
		TxD.TxD0.QIdx = 0;
		/* pTxWI.TXByteCount =  length; */
		TxD.TxD0.TxByteCount = length;
		/* pTxWI.FT = 1; */
		TxD.TxD1.TxDFmt = 1;
		/* pTxWI.HF = 1; */
		TxD.TxD1.HdrFmt = 1;
		os_move_mem(TxDataBuffer, &TxD, sizeof(TxD));
		os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, TxDataBuffer, LOOPBACK_SIZE);
		pAd->LbCtrl.LoopBackTxRawLen = length;
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, length = %d\n", __func__, length));

		if (length > 32) {
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("===buffer===\n"));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[3], TxDataBuffer[2], TxDataBuffer[1], TxDataBuffer[0]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[7], TxDataBuffer[6], TxDataBuffer[5], TxDataBuffer[4]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[11], TxDataBuffer[10], TxDataBuffer[9], TxDataBuffer[8]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[15], TxDataBuffer[14], TxDataBuffer[13], TxDataBuffer[12]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[19], TxDataBuffer[18], TxDataBuffer[17], TxDataBuffer[16]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[23], TxDataBuffer[22], TxDataBuffer[21], TxDataBuffer[20]));
			MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("0x%x 0x%x 0x%x 0x%x\n", TxDataBuffer[27], TxDataBuffer[26], TxDataBuffer[25], TxDataBuffer[24]));
		}

		if (length % 4 != 0)
			alignment = 4 - (length % 4);

		/* pAd->TxDataBufferLength = length + alignment + 4 ; */
		*TxDataBufferLength = length + alignment + 4;
	} else {
		os_move_mem(TxDataBuffer, &pAd->LbCtrl.LoopBackExpectTx, LOOPBACK_SIZE);
		os_zero_mem(TxDataBuffer[length], LOOPBACK_SIZE - length);
		os_move_mem(&pAd->LbCtrl.LoopBackTxRaw, TxDataBuffer, length);
		pAd->LbCtrl.LoopBackTxRawLen = pAd->LbCtrl.LoopBackExpectTxLen;
		/* pAd->LoopBackExpectRxLen = length; */
	}

	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, LP length = %d, alignment = %d\n", __func__, length, alignment));
	pAd->LbCtrl.LoopBackResult.TxByteCount += length;/* pAd->TxBufferLength[pipenum] - 4; */
	pAd->LbCtrl.LoopBackResult.TxPktCount++;
	MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, RxPktCount = %d\n", __func__, pAd->LbCtrl.LoopBackResult.RxPktCount));
#ifdef COMPOS_TESTMODE_WIN
	StartTx(pAd, 1, 0);
#endif

	/* cannot pass UINT32 TimeOut1Second = 100; to wait_event, it will not wait.. workaround use 0 (1second instead of TimeOut1Second) */
	if (RTMP_OS_WAIT_FOR_COMPLETION_TIMEOUT(&pAd->LbCtrl.LoopBackUARTTxEvent, 0) != STATUS_SUCCESS) { /* (pAd, &pAd->LbCtrl.LoopBackSDIOTxEvent,TimeOut1Second) */
		LoopBack_Fail(pAd, TX_TIMEOUT);
		MTWF_LOG(DBG_CAT_TEST, DBG_SUBCAT_ALL, DBG_LVL_TRACE, ("%s, ####################### TX_TIMEOUT ####################3\n", __func__));
	}
}
#endif /* MTK_UART_SUPPORT */
