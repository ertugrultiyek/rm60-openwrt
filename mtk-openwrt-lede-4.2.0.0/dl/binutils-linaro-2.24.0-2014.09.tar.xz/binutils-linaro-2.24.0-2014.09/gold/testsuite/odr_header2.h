struct OdrBase {
  virtual ~OdrBase() {
  }
};
