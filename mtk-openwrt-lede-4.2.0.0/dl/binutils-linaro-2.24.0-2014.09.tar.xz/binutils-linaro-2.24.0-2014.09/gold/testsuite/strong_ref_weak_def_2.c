// strong_ref_weak_def_2.c -- test a strong reference to a weak definition
// in a DSO.

// Copyright 2010 Free Software Foundation, Inc.
// Written by Doug Kwan <dougkwan@google.com>.

// This file is part of gold.

// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street - Fifth Floor, Boston,
// MA 02110-1301, USA.

// We test that we correctly deal with a non-weak reference to
// a weak symbol in an DSO.  We need to make sure that reference
// is not turned into a weak one.

// This source is used to build a shared library that defines a
// weak symbol.

void weak_def (void);

void
__attribute__((weak))
weak_def (void)
{
}
