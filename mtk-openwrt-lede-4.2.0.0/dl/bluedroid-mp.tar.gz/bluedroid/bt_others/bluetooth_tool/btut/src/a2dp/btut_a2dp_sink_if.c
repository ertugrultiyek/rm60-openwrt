#include <stdlib.h>
#include <string.h>
#include <hardware/bluetooth.h>
#include <hardware/bt_av.h>
#include <hardware/bt_rc.h>

#include "btut_cli.h"
#include "btut_debug.h"
#include "btut_a2dp_sink_if.h"
#include "btut_gap_if.h"
#include "util.h"

extern const void *btut_gap_get_profile_interface(const char *profile_id);

// Callback functions
static void btut_a2dp_sink_connection_state_cb(btav_connection_state_t state, bt_bdaddr_t *bd_addr);
static void btut_a2dp_sink_audio_state_cb(btav_audio_state_t state, bt_bdaddr_t *bd_addr);
static void btut_a2dp_sink_audio_config_cb(bt_bdaddr_t *bd_addr, uint32_t sample_rate, uint8_t channel_count);

// CLI handler
static int btut_a2dp_sink_connect_int_handler(int argc, char *argv[]);
static int btut_a2dp_sink_disconnect_handler(int argc, char *argv[]);

static btav_interface_t *g_bt_a2dp_sink_interface = NULL;
static btav_callbacks_t g_bt_a2dp_sink_callbacks =
{
    sizeof(btav_callbacks_t),
    btut_a2dp_sink_connection_state_cb,
    btut_a2dp_sink_audio_state_cb,
    btut_a2dp_sink_audio_config_cb,
};

static BTUT_CLI bt_a2dp_sink_cli_commands[] =
{
    {"connect",                      btut_a2dp_sink_connect_int_handler,                     " = connect ([addr])"},
    {"disconnect",                btut_a2dp_sink_disconnect_handler,                       " = disconnect ([addr])"},
    {NULL, NULL, NULL},
};

static void btut_a2dp_sink_connection_state_cb(btav_connection_state_t state, bt_bdaddr_t *bd_addr)
{
    BTUT_Logd("%s", __func__);
    BTUT_Logi("[A2DP] state: %s(%d) ",
            (state == BTAV_CONNECTION_STATE_DISCONNECTED) ? "SIGNALLING CHANNEL DISCONNECTED" :
            (state == BTAV_CONNECTION_STATE_CONNECTING) ? "CONNECTING" :
            (state == BTAV_CONNECTION_STATE_CONNECTED) ? "SIGNALLING CHANNEL CONNECTED" :
            (state == BTAV_CONNECTION_STATE_DISCONNECTING) ? "DISCONNECTING" : "UNKNOWN",
            state);
}

static void btut_a2dp_sink_audio_state_cb(btav_audio_state_t state, bt_bdaddr_t *bd_addr)
{
    BTUT_Logd("%s", __func__);
    BTUT_Logi("[A2DP] state: %s(%d) ",
            (state == BTAV_AUDIO_STATE_STARTED) ? "STARTED" :
            (state == BTAV_AUDIO_STATE_STOPPED) ? "STOPPED" :
            (state == BTAV_AUDIO_STATE_REMOTE_SUSPEND) ? "SUSPEND" : "UNKNOWN",
            state);
    BTUT_Logi("BDADDR = %02X:%02X:%02X:%02X:%02X:%02X\n",
        bd_addr->address[0], bd_addr->address[1], bd_addr->address[2],
        bd_addr->address[3], bd_addr->address[4], bd_addr->address[5]);
}

static void btut_a2dp_sink_audio_config_cb(bt_bdaddr_t *bd_addr, uint32_t sample_rate, uint8_t channel_mode)
{
    BTUT_Logd("%s", __func__);
    BTUT_Logi("[A2DP] sample_rate: %d, channel_mode: %d", sample_rate, channel_mode);

    if (sample_rate & 0x10)
    {
        BTUT_Logi(" 48000Hz");
    }
    if (sample_rate & 0x20)
    {
        BTUT_Logi(" 44100Hz");
    }
    if (channel_mode& 0x1)
    {
        BTUT_Logi(" stereo");
    }
    if (channel_mode& 0x2)
    {
        BTUT_Logi(" dual channel");
    }
    if (channel_mode & 0x4)
    {
        BTUT_Logi(" mono");
    }
}

static int btut_a2dp_sink_connect_int_handler(int argc, char *argv[])
{
    char *ptr;
    bt_bdaddr_t bdaddr;

    BTUT_Logi("[A2DP] %s()\n", __func__);

    if (argc < 1)
    {
        BTUT_Loge("[A2DP] [USAGE] A2DP_connect [BD_ADDR]");
        return -1;
    }

    ptr = argv[0];
    util_btaddr_stoh(ptr, &bdaddr);
    BTUT_Logi("A2DP connected to %02X:%02X:%02X:%02X:%02X:%02X\n",
            bdaddr.address[0], bdaddr.address[1], bdaddr.address[2],
            bdaddr.address[3], bdaddr.address[4], bdaddr.address[5]);
    g_bt_a2dp_sink_interface->connect(&bdaddr);

    return 0;
}

static int btut_a2dp_sink_disconnect_handler(int argc, char *argv[])
{
    char *ptr;
    bt_bdaddr_t bdaddr;

    BTUT_Logi("[A2DP] %s()\n", __func__);

    if (argc < 1)
    {
        return -1;
    }

    ptr = argv[0];
    util_btaddr_stoh(ptr, &bdaddr);
    BTUT_Logi("A2DP disconnected to %02X:%02X:%02X:%02X:%02X:%02X\n",
            bdaddr.address[0], bdaddr.address[1], bdaddr.address[2],
            bdaddr.address[3], bdaddr.address[4], bdaddr.address[5]);

    g_bt_a2dp_sink_interface->disconnect(&bdaddr);
    return 0;
}

int btut_a2dp_sink_cmd_handler(int argc, char **argv)
{
    BTUT_CLI *cmd, *match = NULL;
    int ret = 0;
    int count = 0;

    BTUT_Logd("[A2DP] %s argc: %d, argv[0]: %s\n", __func__, argc, argv[0]);

    cmd = bt_a2dp_sink_cli_commands;
    while (cmd->cmd)
    {
        if (!strcmp(cmd->cmd, argv[0]))
        {
            match = cmd;
            count = 1;
            break;
        }
        cmd++;
    }

    if (count == 0)
    {
        BTUT_Logd("[A2DP] Unknown command '%s'\n", argv[0]);

        btut_print_cmd_help(CMD_KEY_A2DP_SINK, bt_a2dp_sink_cli_commands);
        ret = -1;
    }
    else
    {
        match->handler(argc - 1, &argv[1]);
    }

    return ret;
}

int btut_a2dp_sink_init()
{
    int ret = 0;
    BTUT_MOD a2dp_sink_mod = {0};

    g_bt_a2dp_sink_interface = (btav_interface_t *) btut_gap_get_profile_interface(BT_PROFILE_ADVANCED_AUDIO_SINK_ID);
    if (g_bt_a2dp_sink_interface == NULL)
    {
        BTUT_Loge("[A2DP] Failed to get A2DP SINK interface\n");
        return -1;
    }

    if (g_bt_a2dp_sink_interface->init(&g_bt_a2dp_sink_callbacks) != BT_STATUS_SUCCESS)
    {
        BTUT_Loge("[A2DP] Failed to init A2DP SINK interface\n");
        return -1;
    }

    a2dp_sink_mod.mod_id = BTUT_MOD_A2DP_SINK;
    strncpy(a2dp_sink_mod.cmd_key, CMD_KEY_A2DP_SINK, sizeof(a2dp_sink_mod.cmd_key));
    a2dp_sink_mod.cmd_handler = btut_a2dp_sink_cmd_handler;
    a2dp_sink_mod.cmd_tbl = bt_a2dp_sink_cli_commands;

    ret = btut_register_mod(&a2dp_sink_mod);
    BTUT_Logd("[A2DP] btut_register_mod() for SINK returns: %d\n", ret);

    return ret;
}

int btut_a2dp_sink_deinit()
{
    if (g_bt_a2dp_sink_interface != NULL)
    {
        g_bt_a2dp_sink_interface->cleanup();
    }

    return 0;
}
