LOCAL_PATH:=$(call my-dir)
include $(CLEAR_VARS)
#LOCAL_ARM_MODE:=arm
LOCAL_SHARED_LIBRARIES:= libc libcutils libcustom_nvram libnvram_sec libnvram_platform

ifeq ($(strip $(MTK_INTERNAL_LOG_ENABLE)),yes)
    LOCAL_CFLAGS += -DMTK_INTERNAL_LOG_ENABLE
endif

LOCAL_SRC_FILES:= \
	libnvram.c
#	custom/common/cgen/inc/CFG_file_info.c \
#	custom/$(MTK_PROJECT)/cgen/inc/CFG_file_info_custom.c \
#	libnvram.c
LOCAL_C_INCLUDES:= \
      $(MTK_PATH_CUSTOM)/cgen/inc \
      $(MTK_PATH_SOURCE)/external/nvram/libnvram \
      $(MTK_PATH_SOURCE)/external/nvram/libfile_op \
      $(MTK_PATH_SOURCE)/protect-bsp/external/nvram/libnvram_sec \
      $(MTK_PATH_SOURCE)/external/seclib

# pass the include path of system/core/include/private/android_filesystem_config.h
LOCAL_C_INCLUDES += system/core/include/private

#	$(MTK_PATH_CUSTOM)/cgen/cfgfileinc \
#	$(MTK_PATH_CUSTOM)/cgen/cfgdefault \
#	$(MTK_PATH_CUSTOM)/cgen/inc \
#	$(MTK_PATH_CUSTOM)/cgen/cfgfileinc \
#	$(MTK_PATH_CUSTOM)/cgen/cfgdefault	
#	mediatek/custom/oppo/cgen/inc \
#	mediatek/custom/oppo/cgen/cfgfileinc \
#	mediatek/custom/oppo/cgen/cfgdefault
LOCAL_MODULE:=libnvram
LOCAL_MODULE_TAGS := optional
LOCAL_PRELINK_MODULE:= false
include $(BUILD_SHARED_LIBRARY)


